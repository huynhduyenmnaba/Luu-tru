USER

Điều 1, Khoản 2 (Đối tượng áp dụng): Có quy định "Đối với người lao động hợp đồng, nhà trường căn cứ hợp đồng lao động... để đánh giá...". Quy định này rất mở và nhân văn. Tuy nhiên, lưu ý người lao động hợp đồng (ví dụ: bảo vệ, cấp dưỡng theo Nghị định 111/2022/NĐ-CP) sẽ đánh giá mức độ hoàn thành công việc theo Luật Lao động, không dùng danh xưng "viên chức" để xếp loại vào hồ sơ viên chức. có góp ý cho nọi dung hình ảnh như trên, với vai trò hiệu trưởng bạn điều chỉnh văn bản thế nào cho hợp lý

---

ASSISTANT

📌 **Đề xuất điều chỉnh khoản 2 Điều 1 – Đối tượng áp dụng**

Với vai trò Hiệu trưởng, tôi thống nhất với ý kiến góp ý và đề xuất **giữ nguyên tinh thần đánh giá công bằng đối với tất cả các đối tượng làm việc tại trường, nhưng phân biệt rõ việc đánh giá viên chức và người lao động hợp đồng.**

Việc điều chỉnh cần bảo đảm hai nguyên tắc:

- **Đối với viên chức:** Thực hiện đánh giá, xếp loại chất lượng theo quy định của pháp luật về viên chức.
- **Đối với người lao động hợp đồng:** Đánh giá mức độ hoàn thành công việc căn cứ hợp đồng lao động, nhiệm vụ được giao và quy định có liên quan; không áp dụng hình thức xếp loại chất lượng viên chức.

Cách quy định này vừa bảo đảm tính pháp lý, vừa tạo thuận lợi cho nhà trường trong công tác đánh giá, quản lý và sử dụng đội ngũ.

## 📖 Căn cứ pháp lý cần cập nhật

Theo quy định có hiệu lực từ ngày 01/7/2026:

- **Luật Viên chức số 129/2025/QH15** và **Nghị định số 233/2026/NĐ-CP** quy định về đánh giá, xếp loại chất lượng viên chức. Đặc biệt, khoản 2 Điều 20 Nghị định 233/2026/NĐ-CP cho phép người đứng đầu đơn vị sự nghiệp công lập quyết định việc áp dụng nghị định đối với lao động hợp đồng. [Toàn văn: LUẬT VIÊN CHỨC](<https://xaydungchinhsach.chinhphu.vn/toan-van-luat-vien-chuc-so-129-2025-qh15-119260107101503932.htm>); [Nghị định số 233/2026/NĐ\-CP của Chính phủ: Quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức](<https://vanban.chinhphu.vn/?classid=1&docid=218616&pageid=27160>); [Nghị định 233/2026/NĐ\-CP quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức](<https://vnlawfirm.vn/van-ban/nghi-dinh-233-2026-nd-cp-quy-dinh-ve-danh-gia-xep-loai-chat-luong-doi-voi-don-vi-su-nghiep-cong-lap-va-vien-chuc/>)
- **Nghị định số 235/2026/NĐ-CP** quy định về hợp đồng thực hiện công việc trong đơn vị sự nghiệp công lập đã thay thế các quy định liên quan đến hợp đồng trong đơn vị sự nghiệp công lập tại Nghị định 111/2022/NĐ-CP. [Nghị định số 235/2026/NĐ\-CP về hợp đồng công việc trong đơn vị sự nghiệp công lập](<https://xaydungchinhsach.chinhphu.vn/nghi-dinh-so-235-2026-nd-cp-ve-hop-dong-thuc-hien-cong-viec-trong-don-vi-su-nghiep-cong-lap-119260630131355603.htm>); [Nghị định 235/2026/NĐ\-CP hợp đồng thực hiện công việc trong đơn vị sự nghiệp công lập mới nhất](<https://thuvienphapluat.vn/van-ban/Lao-dong-Tien-luong/Nghi-dinh-235-2026-ND-CP-hop-dong-thuc-hien-cong-viec-trong-don-vi-su-nghiep-cong-lap-712594.aspx?anchor=dieu_11>)

## 🔍 Nội dung đề xuất chỉnh sửa để đưa trực tiếp vào Quy chế

> **writing · document**
>
> **2. Đối tượng áp dụng**
>
> a) Viên chức thuộc phạm vi quản lý, sử dụng của nhà trường, bao gồm viên chức giữ chức vụ quản lý, giáo viên, nhân viên là viên chức và các viên chức khác. Việc đánh giá, xếp loại chất lượng được thực hiện theo quy định của pháp luật về viên chức và Quy chế này.
>
> b) Đối với người làm việc theo chế độ hợp đồng lao động trực tiếp với nhà trường (nếu có), việc đánh giá mức độ hoàn thành công việc được thực hiện căn cứ vào hợp đồng lao động, nhiệm vụ được giao, nội quy, quy chế của nhà trường và các quy định pháp luật có liên quan. Hiệu trưởng xem xét, quyết định việc áp dụng các quy định về theo dõi, đánh giá, xếp loại chất lượng theo Nghị định số 233/2026/NĐ-CP đối với người lao động hợp đồng theo thẩm quyền. Kết quả đánh giá được quản lý riêng trong hồ sơ người lao động hợp đồng, không đồng nhất với kết quả xếp loại chất lượng viên chức.

## 💡 Vì sao nên điều chỉnh như trên?

Cách viết này khắc phục được điểm chưa rõ của nội dung ban đầu: không mặc nhiên xem mọi giáo viên, nhân viên đều là viên chức mà xác định theo tư cách pháp lý của từng người.

Đồng thời, nhà trường vẫn có cơ sở đánh giá công bằng đối với nhân viên bảo vệ, cấp dưỡng và người lao động hợp đồng khác, nhưng không nhầm lẫn về hồ sơ và chế độ quản lý.

**Lưu ý:** Nếu bảo vệ hoặc nhân viên phục vụ do doanh nghiệp cung cấp theo *hợp đồng dịch vụ*, nhà trường cần đánh giá chất lượng thực hiện hợp đồng dịch vụ, không trực tiếp xếp loại họ như người lao động ký hợp đồng với trường.

## ✅ Kết luận

Với vai trò Hiệu trưởng, tôi đề xuất **sử dụng nội dung chỉnh sửa trên** vì vừa tiếp thu được ý kiến góp ý, vừa bảo đảm quyền quản lý, đánh giá đội ngũ của nhà trường.

Nếu văn bản đang xây dựng có tên là **“Quy chế đánh giá, xếp loại chất lượng viên chức”**, cần đặc biệt lưu ý rằng các quy định áp dụng riêng cho người lao động hợp đồng phải được phân định rõ, không làm thay đổi phạm vi và đối tượng xếp loại viên chức theo pháp luật.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đã kiểm tra thêm quy định áp dụng từ ngày 01/7/2026. Có điểm quan trọng cần cập nhật: quy định mới cho phép hiệu trưởng quyết định áp dụng cơ chế đánh giá của Nghị định 233/2026/NĐ-CP đối với lao động hợp đồng. Tôi sẽ thể hiện rõ quyền này trong câu chữ, đồng thời tránh nhầm lẫn họ với viên chức.

---

ASSISTANT

---

ASSISTANT

---

USER

Nội dung văn bản hoàn thành xuất sắc nhiệm vụ phải có minh chứng vượt 30%. Tuy nhiên trong quy chế khi xây dựng mình thiếu nội dung đó. bạn giúp mình bổ sung nhưng không ảnh hưởng nhiều đến quy chế

---

ASSISTANT

Tôi sẽ đối chiếu điều kiện “vượt 30%” trong Nghị định 233 với Quy chế đã gửi, rồi bổ sung đúng vị trí trong bản Word. Tôi sẽ giữ nguyên bố cục, thang điểm và các phụ lục, chỉ sửa phần thật sự cần thiết.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

📌 **Đề xuất bổ sung quy định về minh chứng hoàn thành xuất sắc nhiệm vụ vào Quy chế năm học 2026–2027**

Tôi đã đối chiếu Quy chế của Trường Mầm non An Bình với Nghị định số 233/2026/NĐ-CP. Theo tôi, **chỉ cần bổ sung một khoản tại Điều 10**, không phải thay đổi thang điểm, các mức xếp loại hoặc phụ lục KPI.

### 1. Một điểm pháp lý cần phân biệt

- **Điểm a khoản 1 Điều 7:** Đối với *đơn vị sự nghiệp công lập*, mức Hoàn thành xuất sắc nhiệm vụ yêu cầu có ít nhất 30% số nhiệm vụ hoàn thành vượt mức yêu cầu, cùng các điều kiện khác.
- **Khoản 1 Điều 12:** Đối với *viên chức*, mức Hoàn thành xuất sắc nhiệm vụ được quy định từ 90 điểm trở lên, không có điều kiện bắt buộc mỗi viên chức phải vượt 30% số nhiệm vụ. [Source unavailable: turn119941search0]; [Source unavailable: turn119941search5]

Vì Quy chế hiện tại của trường là **Quy chế đánh giá, xếp loại chất lượng viên chức**, chúng ta cần diễn đạt rõ để không áp dụng nhầm điều kiện của nhà trường sang từng giáo viên, nhân viên.

### 2. Nội dung bổ sung đề xuất

**Vị trí:** Cuối Điều 10 – *Giao nhiệm vụ và minh chứng đánh giá* \(trang 7 của bản Quy chế), bổ sung khoản 4 như sau:

> **writing · document**
>
> **4. Minh chứng đối với mức hoàn thành xuất sắc nhiệm vụ**
>
> Đối với viên chức được đề nghị xếp loại “Hoàn thành xuất sắc nhiệm vụ”, việc đánh giá phải căn cứ vào kết quả thực hiện nhiệm vụ, sản phẩm công việc và các minh chứng cụ thể, bảo đảm khách quan, thực chất, đúng tiêu chí và tỷ lệ theo quy định.
>
> Đối với việc đánh giá, xếp loại chất lượng nhà trường ở mức “Hoàn thành xuất sắc nhiệm vụ”, phải có minh chứng hoàn thành 100% nhiệm vụ được giao, đúng thời hạn, bảo đảm chất lượng, hiệu quả; trong đó có ít nhất 30% số nhiệm vụ hoàn thành vượt mức yêu cầu theo điểm a khoản 1 Điều 7 Nghị định số 233/2026/NĐ-CP.
>
> Minh chứng được xác định trên cơ sở kế hoạch, chỉ tiêu, nhiệm vụ được giao và kết quả thực hiện thực tế; sử dụng hồ sơ, báo cáo, sản phẩm và tài liệu hiện có, không làm phát sinh hồ sơ mang tính hình thức. Quy định về tỷ lệ 30% áp dụng đối với đánh giá, xếp loại chất lượng nhà trường, không phải điều kiện bắt buộc đối với từng viên chức.

### 3. Cách thực hiện để không ảnh hưởng Quy chế

| Nội dung | Hướng xử lý |
|--------|--------|
| Điều 3 – Thang điểm và mức xếp loại | Giữ nguyên |
| Điều 4 – Tỷ lệ xếp loại xuất sắc | Giữ nguyên |
| Điều 10 – Minh chứng đánh giá | Bổ sung khoản 4 |
| Phụ lục KPI giáo viên, nhân viên | Giữ nguyên |
| Tổng điểm đánh giá | Vẫn là 100 điểm |

### 4. Lưu ý khi thực hiện

Tỷ lệ 30% có nghĩa là **ít nhất 30% số nhiệm vụ hoàn thành vượt mức yêu cầu**, không có nghĩa mỗi nhiệm vụ phải đạt 130% chỉ tiêu.

Ví dụ, nhà trường được giao 10 nhiệm vụ thì cần có minh chứng ít nhất 3 nhiệm vụ hoàn thành vượt mức yêu cầu. Việc xác định phải dựa vào chỉ tiêu, nhiệm vụ đã được giao, không tự đặt thêm nhiệm vụ để tăng tỷ lệ.

✅ **Kết luận:** Tôi đề xuất bổ sung khoản 4 Điều 10 như trên. Đây là phương án thay đổi ít, có căn cứ pháp lý và không làm xáo trộn hệ thống đánh giá viên chức đã xây dựng.

Tuy nhiên, nếu mục đích của nhà trường là quy định **mỗi giáo viên, nhân viên muốn được xếp loại Hoàn thành xuất sắc nhiệm vụ đều phải có ít nhất 30% nhiệm vụ vượt mức**, thì không nên đưa vào dưới danh nghĩa yêu cầu bắt buộc của Nghị định 233, vì Điều 12 không quy định điều kiện này.

---

