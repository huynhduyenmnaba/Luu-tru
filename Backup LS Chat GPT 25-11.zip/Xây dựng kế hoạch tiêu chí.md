USER

với vai trò hiệu trưởng trường mầm non có nhiều năm kinh nghiệm. và các văn bản đính kèm . Bạn hãy giúp tôi  hoàn thành kế hoạch xây dựng bộ tiêu chí đáp ứng các yêu cầu trong văn bản. Đảm bảo nội dung, cấu trúc, phù hợp thực tiễn giáo dục mầm non. logic, lặp luận chặt chẽ và dễ hiểu, phù hợp thực tế

---

ASSISTANT

Tôi sẽ đối chiếu bốn văn bản đính kèm, đặc biệt là Bộ tiêu chí gồm 5 nhóm, 21 tiêu chí và 70 chỉ báo, để xây dựng dự thảo phù hợp với Trường Mầm non An Bình. Tôi sẽ làm rõ mục tiêu, cách tự đánh giá, nội dung ưu tiên, lộ trình đến năm 2030 và trách nhiệm thực hiện; đồng thời bảo đảm không phát sinh hồ sơ, thủ tục ngoài yêu cầu của ngành.

---

ASSISTANT

# 📌 KẾ HOẠCH TRIỂN KHAI BỘ TIÊU CHÍ ĐỔI MỚI, NÂNG CAO CHẤT LƯỢNG GIÁO DỤC MẦM NON GIAI ĐOẠN 2026–2030

Tôi đã đối chiếu 4 văn bản đính kèm của Bộ Giáo dục và Đào tạo, Sở Giáo dục và Đào tạo Đồng Tháp, UBND phường An Bình và Phòng Văn hóa - Xã hội.

Có ba yêu cầu quan trọng cần bảo đảm khi xây dựng kế hoạch cho **Trường Mầm non An Bình**:

1. **Sử dụng đúng Bộ tiêu chí của Bộ Giáo dục và Đào tạo**, gồm 5 nhóm, 21 tiêu chí và 70 chỉ báo. Nhà trường không cần xây dựng một bộ tiêu chí mới, mà phải cụ thể hóa các nội dung phù hợp với thực trạng, điều kiện và định hướng phát triển của trường.
2. **Lựa chọn nội dung ưu tiên trên cơ sở tự đánh giá thực chất**, tập trung vào những chuyển biến về chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ, quản trị nhà trường và phát triển đội ngũ; không triển khai dàn trải hoặc chạy theo hình thức.
3. **Lồng ghép nhiệm vụ vào kế hoạch năm học và các hoạt động chuyên môn hiện có**, không làm phát sinh hồ sơ, sổ sách ngoài quy định; đồng thời thực hiện yêu cầu rà soát, báo cáo hằng tháng của UBND phường An Bình.

Dưới đây là dự thảo kế hoạch theo văn phong hành chính, có mục tiêu, nhiệm vụ, giải pháp, tiến độ, phân công trách nhiệm và nội dung đối chiếu đủ 21 tiêu chí. Những chỉ tiêu cần dữ liệu thực tế sẽ được xác định sau khi nhà trường hoàn thành tự đánh giá ban đầu.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **DỰ THẢO NỘI DUNG LỒNG GHÉP VÀO KẾ HOẠCH NĂM HỌC, KẾ HOẠCH PHÁT TRIỂN NHÀ TRƯỜNG**
>
> # KẾ HOẠCH
> **Triển khai thực hiện Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030**
>
> ## I. CĂN CỨ XÂY DỰNG KẾ HOẠCH
>
> Căn cứ Công văn số 5890/BGDĐT-GDMN ngày 28 tháng 8 năm 2026 của Bộ Giáo dục và Đào tạo về việc hướng dẫn triển khai thí điểm xây dựng mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030;
>
> Căn cứ Phụ lục Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 ban hành kèm theo Công văn số 5890/BGDĐT-GDMN;
>
> Căn cứ Công văn số 3763/SGDĐT-GDMN ngày 28 tháng 9 năm 2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp về việc hướng dẫn triển khai thí điểm xây dựng mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 tại các cơ sở giáo dục mầm non trên địa bàn tỉnh;
>
> Căn cứ Công văn số 3074/UBND ngày 30 tháng 9 năm 2026 của Ủy ban nhân dân phường An Bình về việc triển khai thí điểm xây dựng mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 tại cơ sở giáo dục mầm non;
>
> Căn cứ nhiệm vụ năm học 2026–2027, định hướng phát triển nhà trường giai đoạn 2026–2030 và điều kiện thực tế về đội ngũ, cơ sở vật chất, quy mô nhóm lớp, chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ;
>
> Trường Mầm non An Bình xây dựng nội dung triển khai Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030, cụ thể như sau:
>
> ## II. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> Tổ chức nghiên cứu, vận dụng Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 làm công cụ tự đánh giá, xác định thực trạng, nhận diện điểm mạnh, hạn chế và những vấn đề cần ưu tiên cải tiến trong hoạt động quản lý, nuôi dưỡng, chăm sóc, giáo dục trẻ của nhà trường.
>
> Nâng cao năng lực quản trị nhà trường theo hướng chủ động, dân chủ, minh bạch, hiệu quả; phát huy vai trò, trách nhiệm và năng lực sáng tạo của đội ngũ cán bộ quản lý, giáo viên, nhân viên trong thực hiện nhiệm vụ; từng bước hình thành văn hóa tự đánh giá, hợp tác và cải tiến chất lượng liên tục.
>
> Đẩy mạnh đổi mới nội dung, phương pháp và hình thức tổ chức hoạt động giáo dục theo quan điểm lấy trẻ làm trung tâm; tăng cường học thông qua vui chơi, trải nghiệm; tôn trọng sự khác biệt, nhu cầu, khả năng và nhịp độ phát triển của từng trẻ; bảo đảm các điều kiện phát triển toàn diện về thể chất, tinh thần, nhận thức, ngôn ngữ, tình cảm và kỹ năng xã hội.
>
> Phát triển môi trường giáo dục an toàn, thân thiện, hạnh phúc; sử dụng hiệu quả cơ sở vật chất, thiết bị, học liệu và các nguồn lực; đẩy mạnh ứng dụng công nghệ số trong quản lý và hoạt động chuyên môn, giảm áp lực hành chính, tạo điều kiện để giáo viên tập trung nâng cao chất lượng chăm sóc, giáo dục trẻ.
>
> Xây dựng lộ trình đổi mới phù hợp với điều kiện của nhà trường đến năm 2030; chủ động học tập, lựa chọn, vận dụng những giải pháp hiệu quả từ các đơn vị thực hiện thí điểm, góp phần nâng cao chất lượng giáo dục mầm non của địa phương.
>
> ### 2. Yêu cầu
>
> Việc triển khai Bộ tiêu chí phải bảo đảm đúng mục đích, nội dung, cấu trúc và định hướng của Bộ Giáo dục và Đào tạo; đồng thời phù hợp với thực trạng, điều kiện và khả năng huy động nguồn lực của nhà trường.
>
> Tổ chức rà soát đầy đủ 05 nhóm tiêu chí, 21 tiêu chí và 70 chỉ báo để nhận diện thực trạng. Trên cơ sở kết quả tự đánh giá, chủ động lựa chọn nội dung cần ưu tiên cải tiến; không triển khai đồng loạt tất cả các nội dung khi chưa bảo đảm điều kiện thực hiện.
>
> Đánh giá trung thực, khách quan, chú trọng hiệu quả hoạt động và những chuyển biến thực tế; không đánh giá đơn thuần dựa trên số lượng hồ sơ, sản phẩm hoặc hình thức tổ chức hoạt động. Không sử dụng kết quả tự đánh giá để xếp hạng, so sánh nhà trường với cơ sở giáo dục khác hoặc tạo áp lực thành tích đối với giáo viên.
>
> Các nhiệm vụ, giải pháp được lồng ghép vào kế hoạch thực hiện nhiệm vụ năm học, kế hoạch phát triển nhà trường, kế hoạch chuyên môn và các hoạt động thường xuyên. Khai thác hồ sơ, thông tin và dữ liệu hiện có; không phát sinh kế hoạch, hồ sơ, sổ sách hoặc quy trình hành chính riêng ngoài quy định.
>
> Phân công nhiệm vụ phù hợp với chức năng, năng lực và trách nhiệm của từng cá nhân, bộ phận; bảo đảm sự phối hợp giữa nhà trường, gia đình, cộng đồng và cơ quan quản lý trong quá trình triển khai.
>
> Tổ chức theo dõi, rà soát, đánh giá định kỳ để kịp thời điều chỉnh mục tiêu, giải pháp và lộ trình; ưu tiên những hoạt động có tác động thiết thực, lâu dài đến chất lượng nuôi dưỡng, chăm sóc và giáo dục trẻ.
>
> ## III. MỤC TIÊU THỰC HIỆN
>
> ### 1. Mục tiêu chung
>
> Đến năm 2030, Trường Mầm non An Bình từng bước hình thành và phát triển mô hình giáo dục mầm non đổi mới theo hướng **an toàn, hạnh phúc, lấy trẻ làm trung tâm, quản trị hiệu quả và cải tiến chất lượng liên tục**.
>
> Tập trung tạo chuyển biến thực chất trong tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ; nâng cao chất lượng đội ngũ; xây dựng môi trường giáo dục an toàn, thân thiện; sử dụng hiệu quả các nguồn lực và đẩy mạnh chuyển đổi số phù hợp với đặc điểm của cơ sở giáo dục mầm non.
>
> ### 2. Mục tiêu cụ thể
>
> **2.1. Về tự đánh giá và cải tiến chất lượng**
>
> - Tổ chức rà soát 100% các chỉ báo thuộc Bộ tiêu chí để xác định mức độ thực hiện, điểm mạnh, hạn chế, nguyên nhân và nội dung cần cải tiến.
> - Xác định các nhiệm vụ ưu tiên theo từng năm học trên cơ sở kết quả tự đánh giá, nhu cầu phát triển của trẻ, khả năng đáp ứng của đội ngũ và điều kiện thực tế.
> - Hằng năm tổ chức rà soát kết quả thực hiện, ghi nhận những chuyển biến tích cực, điều chỉnh các giải pháp chưa phù hợp; từng bước nâng cao mức độ đáp ứng của những chỉ báo được lựa chọn ưu tiên.
>
> **2.2. Về chất lượng nuôi dưỡng, chăm sóc và giáo dục trẻ**
>
> - Bảo đảm trẻ được theo dõi sức khỏe, tình trạng dinh dưỡng và đánh giá sự phát triển theo quy định; kịp thời phối hợp với gia đình thực hiện các biện pháp hỗ trợ phù hợp đối với trẻ có nhu cầu đặc biệt.
> - Tăng cường tổ chức các hoạt động vui chơi, trải nghiệm, khám phá, vận động, giao tiếp và hợp tác; phát huy tính tích cực, chủ động của trẻ trong các hoạt động hằng ngày.
> - Thực hiện đánh giá vì sự tiến bộ của từng trẻ; sử dụng kết quả quan sát, đánh giá để điều chỉnh kế hoạch giáo dục, môi trường, phương pháp và hình thức tổ chức hoạt động.
> - Tiếp tục xây dựng môi trường giáo dục an toàn, thân thiện, hạnh phúc; chủ động phòng ngừa các nguy cơ gây mất an toàn, bạo lực và tổn thương thể chất, tinh thần của trẻ.
>
> **2.3. Về phát triển đội ngũ và đổi mới quản trị**
>
> - Phấn đấu 100% cán bộ quản lý, giáo viên, nhân viên có liên quan được tiếp cận, nghiên cứu những nội dung của Bộ tiêu chí phù hợp với nhiệm vụ được giao.
> - Nâng cao chất lượng sinh hoạt chuyên môn thông qua dự giờ, quan sát hoạt động của trẻ, phân tích tình huống thực tiễn, trao đổi kinh nghiệm và hỗ trợ đồng nghiệp.
> - Phát huy quyền chủ động của giáo viên trong xây dựng môi trường, lựa chọn phương pháp và tổ chức hoạt động giáo dục; gắn quyền chủ động với trách nhiệm và hiệu quả thực hiện nhiệm vụ.
> - Từng bước tinh gọn các khâu xử lý công việc trùng lặp, tăng cường quản trị dựa trên thông tin, dữ liệu và kết quả thực hiện.
>
> **2.4. Về cơ sở vật chất, nguồn lực và chuyển đổi số**
>
> - Rà soát, sắp xếp và khai thác hiệu quả các không gian, thiết bị, đồ dùng, đồ chơi và học liệu hiện có; ưu tiên bổ sung, cải tạo những điều kiện trực tiếp ảnh hưởng đến an toàn và chất lượng hoạt động của trẻ.
> - Tăng cường ứng dụng công nghệ trong quản lý, trao đổi thông tin, tổ chức hoạt động chuyên môn và phối hợp với cha mẹ trẻ.
> - Bảo đảm việc quản lý, lưu trữ, khai thác dữ liệu và sử dụng công nghệ, trí tuệ nhân tạo phù hợp với quy định về an toàn thông tin và bảo vệ dữ liệu cá nhân.
> - Huy động, phân bổ và sử dụng các nguồn lực hợp pháp theo hướng công khai, minh bạch, tiết kiệm, đúng mục đích và hiệu quả.
>
> ### 3. Định hướng kết quả đến năm 2030
>
> Nhà trường duy trì các kết quả đã thực hiện tốt; từng bước cải thiện mức độ phát triển chất lượng của các chỉ báo được lựa chọn ưu tiên, hướng tới thực hiện hiệu quả và cải tiến thường xuyên.
>
> Các chỉ tiêu cụ thể cho từng năm học, đặc biệt là mức độ cải thiện dự kiến của từng chỉ báo, được xác định sau khi có kết quả tự đánh giá ban đầu; không đặt ra yêu cầu tất cả các chỉ báo phải đạt mức cao nhất hoặc cùng một mức độ trong thời gian giống nhau.
>
> ## IV. NỘI DUNG VÀ GIẢI PHÁP THỰC HIỆN
>
> ### 1. Tổ chức nghiên cứu, rà soát và tự đánh giá thực trạng theo Bộ tiêu chí
>
> **1.1. Nội dung thực hiện**
>
> Tổ chức nghiên cứu, phổ biến mục đích, cấu trúc, nội dung và hướng dẫn sử dụng Bộ tiêu chí đến cán bộ quản lý, giáo viên, nhân viên thông qua các cuộc họp, sinh hoạt chuyên môn và hoạt động quản lý đang thực hiện.
>
> Phân công các cá nhân, bộ phận liên quan rà soát 05 nhóm tiêu chí, 21 tiêu chí và 70 chỉ báo theo chức năng, nhiệm vụ.
>
> Nội dung rà soát tập trung vào kết quả thực hiện thực tế, các điều kiện bảo đảm chất lượng, những khó khăn, hạn chế và mức độ tác động đến hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ.
>
> **1.2. Phương pháp tự đánh giá**
>
> Áp dụng 05 mức độ phát triển chất lượng theo hướng dẫn của Bộ Giáo dục và Đào tạo:
>
> | Mức | Tên mức độ | Nội dung nhận diện |
> |---|---|---|
> | 1 | Chưa triển khai | Chưa thực hiện hoặc mới chuẩn bị; kết quả, tác động còn hạn chế. |
> | 2 | Bước đầu triển khai | Đã tổ chức thực hiện nhưng chưa thường xuyên, chưa đồng bộ, hiệu quả chưa rõ nét. |
> | 3 | Đáp ứng yêu cầu | Thực hiện phù hợp điều kiện thực tế, đáp ứng yêu cầu cơ bản và có kết quả tích cực. |
> | 4 | Thực hiện hiệu quả, có cải tiến | Chủ động tổ chức thực hiện, thường xuyên rà soát, điều chỉnh và tạo chuyển biến rõ nét. |
> | 5 | Đổi mới, phát triển bền vững | Có giải pháp sáng tạo, hiệu quả, được duy trì, phát triển và có khả năng chia sẻ, nhân rộng. |
>
> Việc xác định mức độ của từng chỉ báo phải căn cứ mô tả cụ thể của Bộ tiêu chí và tình hình thực tế của nhà trường. Trường hợp kết quả nằm giữa hai mức nhưng chưa đáp ứng đầy đủ yêu cầu của mức cao hơn thì xác định ở mức thấp hơn, đồng thời ghi nhận những kết quả đã đạt để tiếp tục cải tiến.
>
> Thông tin phục vụ tự đánh giá được khai thác từ kế hoạch giáo dục, kết quả theo dõi sự phát triển của trẻ, hồ sơ sức khỏe, kết quả sinh hoạt chuyên môn, dữ liệu quản lý, kiểm tra nội bộ, phản hồi của cha mẹ trẻ và các nguồn thông tin hợp pháp hiện có.
>
> **1.3. Sử dụng kết quả**
>
> Trên cơ sở tổng hợp kết quả tự đánh giá, xác định:
>
> - Những nội dung đã thực hiện hiệu quả để tiếp tục duy trì, phát huy.
> - Những hạn chế, khó khăn và nguyên nhân cần khắc phục.
> - Những nội dung có tác động trực tiếp đến sức khỏe, an toàn, hạnh phúc và sự phát triển của trẻ cần được ưu tiên.
> - Những giải pháp có khả năng triển khai ngay bằng nguồn lực hiện có và những nội dung cần tham mưu hỗ trợ.
>
> Kết quả tự đánh giá được sử dụng để xác định, điều chỉnh nhiệm vụ trong kế hoạch năm học, kế hoạch chuyên môn và định hướng phát triển của nhà trường; không lập hệ thống hồ sơ đánh giá riêng ngoài yêu cầu.
>
> ### 2. Lựa chọn các nội dung ưu tiên cải tiến trong năm học 2026–2027
>
> Căn cứ định hướng của Bộ tiêu chí, đặc điểm hoạt động giáo dục mầm non và yêu cầu triển khai của địa phương, nhà trường dự kiến tập trung vào 06 tiêu chí trọng tâm sau đây. Danh mục này được rà soát, điều chỉnh sau khi hoàn thành tự đánh giá thực trạng.
>
> | Tiêu chí | Nội dung ưu tiên | Định hướng giải pháp |
> |---|---|---|
> | 1.2 | Nâng cao sức khỏe thể chất, tinh thần cho trẻ | Theo dõi sức khỏe, dinh dưỡng; tăng cường vận động; quan tâm cảm xúc và nhu cầu hỗ trợ của trẻ. |
> | 1.3 | Đổi mới hoạt động giáo dục lấy trẻ làm trung tâm | Đẩy mạnh học qua chơi, trải nghiệm, tạo cơ hội lựa chọn và thể hiện ý tưởng của trẻ. |
> | 1.4 | Đổi mới theo dõi, đánh giá sự phát triển của trẻ | Quan sát tiến bộ của từng trẻ, sử dụng kết quả để điều chỉnh giáo dục và phối hợp với gia đình. |
> | 2.3 | Xây dựng môi trường làm việc dân chủ, hợp tác, sáng tạo | Trao quyền cho tổ chuyên môn, giáo viên; nâng cao sinh hoạt chuyên môn; giảm công việc hành chính trùng lặp. |
> | 3.4 | Xây dựng môi trường giáo dục an toàn, thân thiện, hạnh phúc | Tăng cường tương tác tích cực, phòng ngừa bạo lực, tôn trọng sự khác biệt và quyền tham gia của trẻ. |
> | 4.2 | Quản lý và khai thác dữ liệu số phục vụ cải tiến chất lượng | Chuẩn hóa dữ liệu hiện có; sử dụng dữ liệu trong quản lý, theo dõi, đánh giá; bảo đảm an toàn thông tin. |
>
> Việc xác định các tiêu chí ưu tiên không có nghĩa là tạm dừng thực hiện những tiêu chí còn lại. Nhà trường tiếp tục duy trì đầy đủ các hoạt động thường xuyên, bảo đảm yêu cầu chuyên môn và các điều kiện chất lượng theo quy định.
>
> ### 3. Triển khai các nhiệm vụ, giải pháp theo 05 nhóm tiêu chí
>
> #### 3.1. Nhóm 1. Đổi mới, phát triển chương trình giáo dục và tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục
>
> Tổ chức rà soát chương trình giáo dục của nhà trường trên cơ sở Chương trình giáo dục mầm non, kết quả đánh giá sự phát triển của trẻ và điều kiện thực tiễn. Điều chỉnh nội dung, phương pháp, hình thức tổ chức hoạt động bảo đảm phù hợp độ tuổi, khả năng, nhu cầu, hứng thú và nhịp độ phát triển của trẻ.
>
> Đẩy mạnh tổ chức hoạt động giáo dục theo quan điểm lấy trẻ làm trung tâm; phát huy ưu thế của hoạt động vui chơi, trải nghiệm, khám phá môi trường xung quanh. Khuyến khích giáo viên tận dụng điều kiện thực tế, nguyên vật liệu an toàn, gần gũi để tạo các cơ hội học tập đa dạng; không đặt nặng hình thức trang trí hoặc đầu tư thiết bị tốn kém.
>
> Nâng cao chất lượng chăm sóc sức khỏe, dinh dưỡng, vệ sinh, vận động và hỗ trợ tinh thần cho trẻ. Tăng cường quan sát, nhận diện sớm những biểu hiện khó khăn về cảm xúc, hành vi, khả năng giao tiếp, thích nghi; phối hợp gia đình và người có chuyên môn phù hợp để hỗ trợ trẻ, không tự ý chẩn đoán những vấn đề vượt phạm vi chuyên môn của giáo viên.
>
> Đổi mới hoạt động đánh giá trẻ theo hướng thường xuyên, khách quan, vì sự tiến bộ của từng trẻ. Sử dụng thông tin quan sát và đánh giá để điều chỉnh kế hoạch giáo dục, tổ chức môi trường, lựa chọn phương pháp và tăng cường phối hợp với cha mẹ trẻ.
>
> **Kết quả hướng tới:** Trẻ được chăm sóc, giáo dục phù hợp hơn với nhu cầu cá nhân; tích cực, tự tin và chủ động tham gia hoạt động; những khó khăn trong quá trình phát triển được nhận diện và hỗ trợ kịp thời.
>
> #### 3.2. Nhóm 2. Đổi mới quản trị cơ sở giáo dục mầm non theo hướng hiệu quả, tăng cường tự chủ gắn với trách nhiệm giải trình
>
> Thực hiện quản trị nhà trường theo hướng lấy chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ làm trọng tâm; sử dụng thông tin, dữ liệu và kết quả thực hiện nhiệm vụ để xác định vấn đề, lựa chọn giải pháp và điều chỉnh hoạt động quản lý.
>
> Phân công nhiệm vụ rõ người, rõ việc, rõ thời gian, rõ trách nhiệm và kết quả cần đạt; phát huy quyền chủ động của tổ chuyên môn, giáo viên và nhân viên trong thực hiện nhiệm vụ được giao.
>
> Đổi mới nội dung, phương thức sinh hoạt hội đồng và sinh hoạt chuyên môn; tăng cường trao đổi, giải quyết những vấn đề thực tế tại nhóm, lớp. Rà soát, giảm các nội dung họp, biểu mẫu hoặc thao tác trùng lặp không bắt buộc, dành thêm thời gian cho hoạt động chuyên môn.
>
> Thực hiện công khai, minh bạch trong quản lý và sử dụng nguồn lực; tăng cường tiếp nhận, phân tích ý kiến của đội ngũ và cha mẹ trẻ; kịp thời điều chỉnh những nội dung chưa phù hợp.
>
> **Kết quả hướng tới:** Công tác điều hành chủ động, thống nhất, hiệu quả; giáo viên được hỗ trợ và có điều kiện phát huy sáng tạo; nhiệm vụ được giải quyết kịp thời, giảm áp lực hành chính không cần thiết.
>
> #### 3.3. Nhóm 3. Phát triển các điều kiện bảo đảm chất lượng, tạo môi trường giáo dục phát triển toàn diện cho trẻ
>
> Rà soát việc phân công, sử dụng và phát triển đội ngũ phù hợp với vị trí việc làm, năng lực, yêu cầu nhiệm vụ và điều kiện thực tế. Chú trọng bồi dưỡng tại chỗ, hỗ trợ đồng nghiệp, sinh hoạt chuyên môn dựa trên thực hành và giải quyết vấn đề.
>
> Quan tâm sức khỏe thể chất, tinh thần, điều kiện làm việc và động lực nghề nghiệp của cán bộ quản lý, giáo viên, nhân viên; kịp thời nhận diện những áp lực để có biện pháp hỗ trợ phù hợp.
>
> Tiếp tục hoàn thiện môi trường giáo dục xanh, sạch, an toàn, thân thiện; bố trí không gian hoạt động linh hoạt, thuận tiện, bảo đảm cơ hội tham gia cho trẻ. Ưu tiên sử dụng hiệu quả cơ sở vật chất hiện có, từng bước cải tạo, bổ sung theo khả năng nguồn lực.
>
> Phát triển học liệu mở, đồ dùng, đồ chơi đa chức năng; lựa chọn nguyên vật liệu tự nhiên, vật liệu tái sử dụng bảo đảm an toàn. Tăng cơ hội để trẻ được tự lựa chọn, thao tác, khám phá và sáng tạo.
>
> Duy trì môi trường giao tiếp tích cực, tôn trọng sự khác biệt; xây dựng mối quan hệ hợp tác, yêu thương giữa giáo viên với trẻ, giữa trẻ với trẻ và giữa nhà trường với cha mẹ trẻ.
>
> Thực hiện quản lý, huy động và sử dụng các nguồn lực theo đúng quy định, công khai, minh bạch, tiết kiệm; ưu tiên những nội dung trực tiếp nâng cao chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> **Kết quả hướng tới:** Môi trường giáo dục an toàn, thân thiện và đáp ứng tốt hơn nhu cầu phát triển của trẻ; đội ngũ nâng cao năng lực chuyên môn; cơ sở vật chất và học liệu được khai thác hiệu quả.
>
> #### 3.4. Nhóm 4. Chuyển đổi số, ứng dụng công nghệ thông tin và trí tuệ nhân tạo
>
> Rà soát, sử dụng thống nhất các phần mềm, hệ thống thông tin và kênh trao đổi hiện có để phục vụ quản lý, điều hành, phối hợp công việc; hạn chế nhập liệu trùng lặp, ưu tiên khai thác dữ liệu đã được cập nhật.
>
> Từng bước sử dụng dữ liệu số về trẻ em, đội ngũ, cơ sở vật chất, các hoạt động nuôi dưỡng, chăm sóc, giáo dục làm căn cứ theo dõi, phân tích, đánh giá và điều chỉnh hoạt động của nhà trường.
>
> Khuyến khích cán bộ quản lý, giáo viên sử dụng công nghệ và công cụ trí tuệ nhân tạo phù hợp để tham khảo ý tưởng, hỗ trợ xây dựng kế hoạch, thiết kế hoạt động giáo dục và tổng hợp thông tin. Nội dung do công nghệ tạo ra phải được người sử dụng kiểm tra, lựa chọn và điều chỉnh trước khi áp dụng.
>
> Không đưa thông tin cá nhân, hình ảnh riêng tư, dữ liệu sức khỏe hoặc thông tin nhạy cảm của trẻ lên các công cụ trí tuệ nhân tạo công khai khi chưa có cơ sở và điều kiện bảo vệ dữ liệu phù hợp. Việc sử dụng thiết bị số trong hoạt động giáo dục phải phù hợp độ tuổi, có kiểm soát và không thay thế vui chơi, vận động, giao tiếp trực tiếp của trẻ.
>
> Tăng cường hướng dẫn đội ngũ về an toàn thông tin, quyền riêng tư, giao tiếp có trách nhiệm và phòng ngừa các nguy cơ trên môi trường số.
>
> **Kết quả hướng tới:** Ứng dụng công nghệ góp phần giảm thao tác hành chính, nâng cao hiệu quả quản trị và hỗ trợ giáo viên; dữ liệu được quản lý an toàn, sử dụng thiết thực.
>
> #### 3.5. Nhóm 5. Hợp tác và hội nhập quốc tế
>
> Khuyến khích cán bộ quản lý, giáo viên tham gia các hoạt động giao lưu, trao đổi, chia sẻ chuyên môn trong các mạng lưới, cộng đồng học tập, hội nghị, hội thảo phù hợp.
>
> Chủ động tiếp cận tài liệu, học liệu và kinh nghiệm giáo dục tiên tiến từ nguồn đáng tin cậy; lựa chọn, vận dụng phù hợp với Chương trình giáo dục mầm non, đặc điểm trẻ, điều kiện thực tế và giá trị văn hóa Việt Nam.
>
> Tăng cường phối hợp với chuyên gia, cơ sở giáo dục và các tổ chức có liên quan khi có điều kiện và đúng quy định; ưu tiên những hoạt động hỗ trợ giải quyết vấn đề chuyên môn thực tế của nhà trường.
>
> Lồng ghép giáo dục những giá trị văn hóa tích cực, tinh thần tôn trọng sự khác biệt, giữ gìn và phát huy bản sắc văn hóa dân tộc, văn hóa địa phương thông qua các hoạt động phù hợp với độ tuổi.
>
> **Kết quả hướng tới:** Đội ngũ được mở rộng cơ hội học tập, tiếp cận kinh nghiệm mới; những cách làm phù hợp được vận dụng và chia sẻ, góp phần nâng cao chất lượng giáo dục mà không tạo áp lực phải tổ chức hợp tác quốc tế ngoài khả năng của nhà trường.
>
> ## V. LỘ TRÌNH THỰC HIỆN GIAI ĐOẠN 2026–2030
>
> | Thời gian | Nội dung trọng tâm | Kết quả hướng tới |
> |---|---|---|
> | Tháng 10–12/2026 | Phổ biến Bộ tiêu chí; rà soát toàn bộ 70 chỉ báo; xác định thực trạng, điểm mạnh, hạn chế và nội dung ưu tiên. | Nhận diện được mức độ thực hiện từng chỉ báo, xác định nhiệm vụ ưu tiên và lồng ghép vào kế hoạch nhà trường. |
> | Tháng 01–5/2027 | Tập trung triển khai, theo dõi các giải pháp cải tiến thuộc 06 tiêu chí ưu tiên; duy trì những hoạt động thường xuyên của các nhóm tiêu chí còn lại. | Hình thành những chuyển biến bước đầu trong hoạt động giáo dục, môi trường an toàn, sinh hoạt chuyên môn và khai thác dữ liệu. |
> | Tháng 6–7/2027 | Đánh giá kết quả năm học, phân tích mức độ cải thiện, khó khăn và tính khả thi của các giải pháp; tham khảo kết quả thí điểm cấp tỉnh. | Xác định những giải pháp hiệu quả cần duy trì, những nội dung phải điều chỉnh và định hướng năm học tiếp theo. |
> | Năm học 2027–2028 | Tiếp tục củng cố các tiêu chí ưu tiên; tăng cường đổi mới chương trình, phát triển đội ngũ, môi trường giáo dục và quản trị số; học tập có chọn lọc từ các cơ sở thí điểm. | Những giải pháp phù hợp được duy trì, mở rộng trong hoạt động thường xuyên. |
> | Năm học 2028–2029 | Nâng cao hiệu quả quản trị, phát triển và sử dụng nguồn lực; đẩy mạnh ứng dụng công nghệ, học liệu và các phương pháp giáo dục phù hợp; mở rộng cơ hội trao đổi chuyên môn. | Chất lượng hoạt động được cải thiện đồng bộ hơn, các giải pháp được điều chỉnh dựa trên kết quả thực tế. |
> | Năm học 2029–2030 | Củng cố kết quả đổi mới; tiếp tục điều chỉnh các nội dung còn hạn chế; nâng cao tính bền vững của mô hình. | Hình thành các giải pháp có hiệu quả ổn định, có khả năng chia sẻ và vận dụng lâu dài. |
> | Năm 2030 | Đánh giá kết quả thực hiện giai đoạn 2026–2030, xác định những nội dung cần duy trì và đề xuất định hướng phát triển tiếp theo. | Tổng hợp kết quả cải tiến, bài học kinh nghiệm, khó khăn và kiến nghị phù hợp. |
>
> Lộ trình được điều chỉnh hằng năm trên cơ sở kết quả tự đánh giá, điều kiện thực tế, nguồn lực và các hướng dẫn tiếp theo của cơ quan quản lý giáo dục.
>
> ## VI. THEO DÕI, ĐÁNH GIÁ VÀ ĐIỀU CHỈNH
>
> ### 1. Nội dung theo dõi
>
> Tập trung vào ba nội dung chính:
>
> **Thứ nhất, mức độ thực hiện:** Xác định nhiệm vụ đã được triển khai đến đâu, có phù hợp với kế hoạch, điều kiện thực tế và nhu cầu của trẻ hay không.
>
> **Thứ hai, hiệu quả thực hiện:** Xem xét những tác động thực tế đến sức khỏe, sự an toàn, cảm xúc, sự tham gia và tiến bộ của trẻ; năng lực của đội ngũ; hiệu quả quản lý, sử dụng nguồn lực và tổ chức hoạt động.
>
> **Thứ ba, khả năng cải tiến:** Xác định những giải pháp có hiệu quả cần duy trì, những khó khăn chưa được giải quyết và những nội dung cần điều chỉnh hoặc tiếp tục hỗ trợ.
>
> ### 2. Phương thức theo dõi
>
> Lồng ghép việc theo dõi các tiêu chí vào kiểm tra nội bộ, dự giờ, sinh hoạt chuyên môn, đánh giá trẻ, rà soát điều kiện an toàn, công tác quản lý và các hoạt động thường xuyên của nhà trường.
>
> Đối với từng nội dung ưu tiên, xác định rõ kết quả cần đạt, người phụ trách, thời gian thực hiện và nguồn thông tin dùng để xem xét mức độ chuyển biến.
>
> Khai thác hồ sơ, dữ liệu và sản phẩm hoạt động hiện có; chú trọng quan sát thực tế, trao đổi với giáo viên, cha mẹ trẻ và xem xét hiệu quả sử dụng những giải pháp đã triển khai.
>
> ### 3. Rà soát, báo cáo và điều chỉnh
>
> Hằng tháng, bộ phận được phân công tổng hợp ngắn gọn tiến độ, kết quả thực hiện, khó khăn và đề xuất giải pháp trong nội dung báo cáo định kỳ của nhà trường; thực hiện yêu cầu báo cáo UBND phường An Bình thông qua Phòng Văn hóa - Xã hội theo Công văn số 3074/UBND.
>
> Cuối mỗi học kỳ và năm học, nhà trường tổ chức rà soát những nội dung ưu tiên, đối chiếu với kết quả tự đánh giá trước đó để xác định mức độ chuyển biến và nhiệm vụ tiếp theo.
>
> Nội dung đánh giá được tích hợp vào kết quả thực hiện nhiệm vụ năm học, báo cáo chuyên môn và dữ liệu quản lý hiện có; không thiết lập thêm hệ thống biểu mẫu, hồ sơ, báo cáo trùng lặp.
>
> ## VII. PHÂN CÔNG TRÁCH NHIỆM
>
> ### 1. Hiệu trưởng
>
> Chịu trách nhiệm chỉ đạo chung việc triển khai, sử dụng Bộ tiêu chí; tổ chức rà soát thực trạng, lựa chọn nội dung ưu tiên, xác định mục tiêu và lộ trình cải tiến.
>
> Phân công, điều phối nhiệm vụ giữa các bộ phận; bảo đảm các điều kiện cần thiết trong phạm vi nguồn lực và thẩm quyền; kịp thời tham mưu cơ quan quản lý về những khó khăn vượt khả năng giải quyết của nhà trường.
>
> Chỉ đạo lồng ghép nội dung cải tiến vào các kế hoạch, hoạt động hiện có; định kỳ theo dõi, đánh giá, điều chỉnh giải pháp và chịu trách nhiệm về tính thực chất, hiệu quả triển khai.
>
> ### 2. Phó Hiệu trưởng
>
> Căn cứ lĩnh vực được phân công, phối hợp tổ chức nghiên cứu, tự đánh giá và triển khai các tiêu chí liên quan đến hoạt động chuyên môn, nuôi dưỡng, chăm sóc, giáo dục trẻ, cơ sở vật chất và điều kiện bảo đảm chất lượng.
>
> Hướng dẫn tổ chuyên môn, giáo viên, nhân viên lựa chọn giải pháp phù hợp; theo dõi kết quả thực hiện, phát hiện khó khăn và đề xuất điều chỉnh kịp thời.
>
> ### 3. Tổ trưởng chuyên môn
>
> Tổ chức lồng ghép các nội dung đổi mới vào sinh hoạt chuyên môn, kế hoạch giáo dục và hoạt động tại nhóm, lớp.
>
> Hướng dẫn giáo viên rà soát, điều chỉnh môi trường giáo dục, phương pháp tổ chức hoạt động, cách theo dõi và đánh giá sự phát triển của trẻ; tăng cường chia sẻ những cách làm hiệu quả.
>
> Phản ánh các khó khăn, nhu cầu hỗ trợ và đề xuất giải pháp cải tiến phù hợp với điều kiện thực tế.
>
> ### 4. Giáo viên
>
> Chủ động nghiên cứu những tiêu chí, chỉ báo liên quan đến nhiệm vụ; tham gia tự đánh giá, đề xuất và thực hiện giải pháp cải tiến tại nhóm, lớp.
>
> Tổ chức hoạt động nuôi dưỡng, chăm sóc, giáo dục bảo đảm an toàn, phù hợp với nhu cầu, khả năng, hứng thú và sự phát triển của trẻ.
>
> Thường xuyên quan sát, đánh giá trẻ, sử dụng kết quả để điều chỉnh hoạt động; phối hợp với gia đình trong chăm sóc, hỗ trợ sự phát triển toàn diện của trẻ.
>
> ### 5. Nhân viên và các bộ phận liên quan
>
> Căn cứ chức năng, nhiệm vụ được giao, tham gia rà soát và thực hiện các nội dung liên quan đến sức khỏe, dinh dưỡng, vệ sinh, an toàn, tài chính, tài sản, cơ sở vật chất, dữ liệu số và những điều kiện bảo đảm chất lượng.
>
> Chủ động đề xuất giải pháp sử dụng hiệu quả nguồn lực, bảo đảm an toàn và nâng cao chất lượng phục vụ hoạt động của nhà trường.
>
> ### 6. Phối hợp với cha mẹ trẻ và các lực lượng liên quan
>
> Phối hợp trao đổi thông tin về sức khỏe, nhu cầu, khả năng, cảm xúc và sự phát triển của trẻ; thống nhất những biện pháp hỗ trợ phù hợp giữa gia đình và nhà trường.
>
> Khuyến khích cha mẹ trẻ tham gia góp ý, chia sẻ thông tin, đồng hành trong các hoạt động giáo dục theo điều kiện và quy định hiện hành.
>
> Chủ động phối hợp với Phòng Văn hóa - Xã hội, chính quyền địa phương, cơ sở y tế và các đơn vị liên quan để được hướng dẫn, hỗ trợ giải quyết những khó khăn trong quá trình triển khai.
>
> ## VIII. KINH PHÍ VÀ ĐIỀU KIỆN THỰC HIỆN
>
> Việc triển khai được thực hiện trên cơ sở khai thác hiệu quả nhân lực, cơ sở vật chất, thiết bị và các nguồn lực hiện có của nhà trường.
>
> Kinh phí thực hiện được cân đối từ nguồn kinh phí được giao và các nguồn hợp pháp khác theo quy định; ưu tiên các nhiệm vụ trực tiếp bảo đảm an toàn, sức khỏe, chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> Việc huy động, phân bổ, quản lý và sử dụng nguồn lực phải bảo đảm đúng quy định, công khai, minh bạch, tiết kiệm, hiệu quả; không đặt ra yêu cầu đóng góp bắt buộc đối với cha mẹ trẻ để thực hiện Bộ tiêu chí.
>
> Đối với những nội dung vượt khả năng của nhà trường, chủ động rà soát nhu cầu, báo cáo và tham mưu UBND phường An Bình, Phòng Văn hóa - Xã hội xem xét, hỗ trợ theo thẩm quyền.
>
> ## IX. TỔ CHỨC THỰC HIỆN
>
> Căn cứ nội dung kế hoạch này, Hiệu trưởng chỉ đạo các bộ phận triển khai thực hiện các nhiệm vụ phù hợp với chức năng, trách nhiệm được giao; xác định mục tiêu và nội dung ưu tiên trong kế hoạch năm học và các hoạt động chuyên môn hiện có.
>
> Các Phó Hiệu trưởng, tổ trưởng chuyên môn, giáo viên và nhân viên chủ động phối hợp, thực hiện, theo dõi kết quả và đề xuất giải pháp điều chỉnh; bảo đảm hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ được duy trì ổn định, an toàn, hiệu quả.
>
> Định kỳ rà soát kết quả thực hiện, đối chiếu với các chỉ báo đã lựa chọn ưu tiên; kịp thời phát hiện những khó khăn, hạn chế, điều chỉnh nhiệm vụ và cách thức tổ chức thực hiện.
>
> Nhà trường chủ động cập nhật, trao đổi, học tập các giải pháp phù hợp từ Trường Mầm non Lê Thị Hồng Gấm và Trường Mầm non Cao Lãnh là hai cơ sở được tỉnh lựa chọn thí điểm trong năm học 2026–2027; không áp dụng máy móc, sao chép mô hình khi chưa phù hợp với điều kiện của đơn vị.
>
> Trong quá trình thực hiện, nếu phát sinh khó khăn, vướng mắc vượt thẩm quyền, các bộ phận kịp thời phản ánh để Hiệu trưởng tổng hợp, báo cáo cơ quan quản lý theo phân cấp.
>
> Việc triển khai Bộ tiêu chí phải hướng tới mục tiêu cuối cùng là nâng cao chất lượng quản trị, chất lượng đội ngũ và điều kiện giáo dục, qua đó bảo đảm mọi trẻ em được chăm sóc, nuôi dưỡng, giáo dục trong môi trường an toàn, thân thiện, hạnh phúc và có cơ hội phát triển phù hợp với khả năng của bản thân.
>
> ---
>
> # PHỤ LỤC
> **ĐỊNH HƯỚNG TRIỂN KHAI 21 TIÊU CHÍ THUỘC BỘ TIÊU CHÍ MÔ HÌNH ĐỔI MỚI, NÂNG CAO CHẤT LƯỢNG GIÁO DỤC MẦM NON GIAI ĐOẠN 2026–2030**
>
> *Bảng dưới đây cụ thể hóa hướng thực hiện cho Trường Mầm non An Bình. Nội dung, mã số và số lượng chỉ báo thực hiện theo Bộ tiêu chí gốc của Bộ Giáo dục và Đào tạo, không thay thế hoặc sửa đổi 70 chỉ báo đã ban hành.*
>
> ## Nhóm 1. Đổi mới, phát triển chương trình giáo dục và tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục
>
> **Gồm 04 tiêu chí, 12 chỉ báo.**
>
> | Mã tiêu chí | Nội dung triển khai tại trường | Kết quả cần theo dõi |
> |---|---|---|
> | 1.1 | Rà soát, phát triển chương trình giáo dục phù hợp với trẻ, điều kiện nhà trường và đặc điểm địa phương. | Mức độ phù hợp của chương trình; hiệu quả điều chỉnh từ đánh giá trẻ và phản hồi của các bên. |
> | 1.2 | Nâng cao chất lượng nuôi dưỡng, chăm sóc sức khỏe thể chất, tinh thần; tăng cường hoạt động vận động. | Tình trạng sức khỏe, dinh dưỡng, sự tham gia vận động và hiệu quả hỗ trợ từng trẻ. |
> | 1.3 | Tăng cường học qua chơi, trải nghiệm, giáo dục lấy trẻ làm trung tâm, tôn trọng sự khác biệt. | Mức độ chủ động, hứng thú, tương tác, lựa chọn và tham gia hoạt động của trẻ. |
> | 1.4 | Đổi mới quan sát, theo dõi, đánh giá sự phát triển và sử dụng kết quả để điều chỉnh giáo dục. | Sự tiến bộ của từng trẻ; các điều chỉnh trong chăm sóc, giáo dục dựa trên kết quả đánh giá. |
>
> ## Nhóm 2. Đổi mới quản trị cơ sở giáo dục mầm non
>
> **Gồm 04 tiêu chí, 16 chỉ báo.**
>
> | Mã tiêu chí | Nội dung triển khai tại trường | Kết quả cần theo dõi |
> |---|---|---|
> | 2.1 | Nâng cao tính chủ động, trách nhiệm, công khai, minh bạch trong thực hiện nhiệm vụ theo thẩm quyền. | Hiệu quả xử lý công việc, quyết định quản lý và trách nhiệm giải trình. |
> | 2.2 | Xác định mục tiêu phát triển, nhiệm vụ ưu tiên và giải pháp đột phá trên cơ sở thực trạng. | Tính phù hợp của mục tiêu và mức độ cải thiện chất lượng thực tế. |
> | 2.3 | Phát huy quyền chủ động của đội ngũ, xây dựng môi trường hợp tác, sáng tạo; tinh gọn công việc. | Sự tham gia của giáo viên, chất lượng phối hợp và thời gian dành cho chuyên môn. |
> | 2.4 | Đổi mới điều hành theo hướng linh hoạt, sử dụng dữ liệu và kết quả thực hiện để ra quyết định. | Mức độ kịp thời, chính xác và hiệu quả của hoạt động quản lý. |
>
> ## Nhóm 3. Phát triển các điều kiện bảo đảm chất lượng và môi trường giáo dục
>
> **Gồm 05 tiêu chí, 20 chỉ báo.**
>
> | Mã tiêu chí | Nội dung triển khai tại trường | Kết quả cần theo dõi |
> |---|---|---|
> | 3.1 | Phát triển năng lực đội ngũ, bồi dưỡng tại chỗ, hỗ trợ đổi mới, quan tâm sức khỏe nghề nghiệp. | Sự tiến bộ về năng lực, khả năng vận dụng trong thực tiễn và điều kiện làm việc của đội ngũ. |
> | 3.2 | Rà soát, tổ chức không gian giáo dục an toàn, xanh, mở, linh hoạt; sử dụng hiệu quả cơ sở vật chất. | Hiệu quả sử dụng các không gian, cơ hội trải nghiệm và điều kiện an toàn của trẻ. |
> | 3.3 | Phát triển và sử dụng thiết bị, học liệu mở, đồ chơi đa chức năng, học liệu số phù hợp. | Mức độ phù hợp, an toàn, hiệu quả sử dụng và khả năng phát huy tính sáng tạo của trẻ. |
> | 3.4 | Xây dựng môi trường giáo dục an toàn, thân thiện, hạnh phúc, tôn trọng cảm xúc và sự tham gia của trẻ. | Chất lượng tương tác, cảm giác an toàn, sự được tôn trọng và tham gia của trẻ. |
> | 3.5 | Quản lý, phân bổ, sử dụng hiệu quả các nguồn lực; thực hiện công khai, minh bạch. | Mức độ đáp ứng nhu cầu ưu tiên, hiệu quả sử dụng và tính minh bạch của nguồn lực. |
>
> ## Nhóm 4. Chuyển đổi số, ứng dụng công nghệ thông tin và trí tuệ nhân tạo
>
> **Gồm 04 tiêu chí, 11 chỉ báo.**
>
> | Mã tiêu chí | Nội dung triển khai tại trường | Kết quả cần theo dõi |
> |---|---|---|
> | 4.1 | Sử dụng hệ thống, công cụ số trong quản lý, điều hành, phối hợp và trao đổi thông tin. | Hiệu quả liên thông, xử lý công việc và giảm thao tác thủ công. |
> | 4.2 | Cập nhật, quản lý, khai thác dữ liệu số chính xác, thống nhất; bảo vệ thông tin cá nhân. | Chất lượng dữ liệu, khả năng khai thác phục vụ quản lý và an toàn thông tin. |
> | 4.3 | Sử dụng công nghệ, trí tuệ nhân tạo và học liệu số phù hợp trong hoạt động nghề nghiệp. | Hiệu quả hỗ trợ giáo viên; tính phù hợp, an toàn và hiệu quả thực tiễn của ứng dụng. |
> | 4.4 | Xây dựng và thực hiện các quy tắc bảo đảm môi trường số an toàn, lành mạnh. | Khả năng phòng ngừa, phát hiện, xử lý nguy cơ và bảo vệ trẻ trên môi trường số. |
>
> ## Nhóm 5. Hợp tác và hội nhập quốc tế
>
> **Gồm 04 tiêu chí, 11 chỉ báo.**
>
> | Mã tiêu chí | Nội dung triển khai tại trường | Kết quả cần theo dõi |
> |---|---|---|
> | 5.1 | Tham gia mạng lưới, cộng đồng học tập, hoạt động trao đổi và chia sẻ chuyên môn phù hợp. | Kiến thức, kinh nghiệm tiếp cận được và khả năng vận dụng tại trường. |
> | 5.2 | Tiếp cận có chọn lọc các học liệu, phương pháp và kinh nghiệm giáo dục trong nước, quốc tế. | Tính khoa học, phù hợp và hiệu quả thực tế của nội dung vận dụng. |
> | 5.3 | Hợp tác, trao đổi chuyên môn với chuyên gia, tổ chức giáo dục và các đối tác phù hợp. | Khả năng giải quyết vấn đề chuyên môn và tác động đến cải tiến chất lượng. |
> | 5.4 | Tiếp cận các giá trị văn hóa tích cực, giữ gìn và phát huy bản sắc văn hóa Việt Nam, văn hóa địa phương. | Sự phù hợp và hiệu quả của việc tích hợp các giá trị văn hóa trong hoạt động giáo dục. |
>
> **Tổng cộng: 05 nhóm, 21 tiêu chí, 70 chỉ báo.**
>
> **Nguyên tắc sử dụng phụ lục:** Nhà trường đối chiếu với đầy đủ 70 chỉ báo và các mức độ đánh giá của Bộ tiêu chí gốc. Bảng định hướng này chỉ hỗ trợ phân công, lựa chọn nội dung cải tiến và theo dõi kết quả; không được sử dụng thay thế mô tả chính thức của các chỉ báo.
>
> **HIỆU TRƯỞNG**  
> *(Ký, ghi rõ họ tên khi nội dung được phê duyệt hoặc ban hành theo hình thức phù hợp)*

## 💡 Những nội dung cần hoàn thiện trước khi áp dụng

Dự thảo trên đã bao quát yêu cầu của bốn văn bản, nhưng để kế hoạch thực sự sát Trường Mầm non An Bình, tôi đề xuất rà soát thêm ba điểm:

**Thứ nhất, xác định mức xuất phát của từng chỉ báo.** Hiện chưa có số liệu thực tế về quy mô, đội ngũ, cơ sở vật chất và kết quả tự đánh giá của trường. Vì vậy, sáu tiêu chí ưu tiên và các mục tiêu định lượng trong dự thảo là đề xuất ban đầu, chưa phải kết luận về điểm yếu của nhà trường.

**Thứ hai, phân biệt triển khai tại địa phương với thí điểm cấp tỉnh.** Công văn 3763 xác định hai cơ sở thí điểm cấp tỉnh là Trường Mầm non Lê Thị Hồng Gấm và Trường Mầm non Cao Lãnh. Trường Mầm non An Bình thực hiện nhiệm vụ theo chỉ đạo của UBND phường và chủ động học tập kết quả của các đơn vị thí điểm. Do đó, kế hoạch không xác định An Bình là một trong hai đơn vị thí điểm được Sở lựa chọn.

**Thứ ba, hoàn thiện thể thức và căn cứ trước khi sử dụng.** Bản Công văn 3763 gốc ghi ngày 28/9/2026, trong khi Công văn 3074/UBND dẫn ngày 25/9/2026. Dự thảo sử dụng ngày 28/9/2026 theo văn bản gốc; nhà trường nên kiểm tra lại khi hoàn thiện căn cứ. Đồng thời, nên tích hợp nội dung này vào kế hoạch năm học và kế hoạch phát triển đang có, đúng yêu cầu không phát sinh kế hoạch riêng.

## ✅ Đề xuất bước tiếp theo

**Điểm quyết định chất lượng của kế hoạch không nằm ở việc viết đủ 70 chỉ báo, mà là xác định đúng thực trạng và lựa chọn được những nội dung cải tiến có hiệu quả đối với trẻ.**

Để tôi tiếp tục hoàn thiện thành **bản kế hoạch chính thức, với mục tiêu và chỉ tiêu cụ thể cho từng năm đến 2030**, cô cho tôi biết thêm một nội dung:

**Trường Mầm non An Bình đã có kết quả tự đánh giá theo 70 chỉ báo chưa, hay đây là kế hoạch đầu tiên để nhà trường bắt đầu triển khai Bộ tiêu chí?**

---

USER

bạn có thể làm thành 1 kế hoa5ch và có bộ tiêu chí đính kèm phụ lục (tương tự mẫu nhé)

---

ASSISTANT

Tôi sẽ gộp thành **một kế hoạch hoàn chỉnh của Trường Mầm non An Bình**, kèm **phụ lục Bộ tiêu chí theo đúng 5 nhóm, 21 tiêu chí, 70 chỉ báo** như mẫu của Bộ. Tôi sẽ giữ nguyên nội dung chỉ báo, đồng thời bổ sung phần hướng dẫn tự đánh giá và xác định nội dung ưu tiên để nhà trường có thể sử dụng ngay.

---

ASSISTANT

Tôi sẽ trình bày thành **một văn bản thống nhất**, gồm phần Kế hoạch của Trường Mầm non An Bình và phần Phụ lục Bộ tiêu chí đính kèm ngay sau phần ký tên.

Bố cục được xây dựng như sau:

- **Phần I – Kế hoạch:** Căn cứ pháp lý; mục đích, yêu cầu; mục tiêu; nội dung và giải pháp; lộ trình 2026–2030; theo dõi, đánh giá; phân công trách nhiệm và tổ chức thực hiện.
- **Phần II – Phụ lục:** Bảng gồm 3 cột *Mã – Tên tiêu chí – Chỉ báo*, trình bày đầy đủ **5 nhóm, 21 tiêu chí, 70 chỉ báo** theo mẫu Bộ Giáo dục và Đào tạo.

Một điểm cần lưu ý về tên văn bản: Bộ Giáo dục và Đào tạo đã ban hành Bộ tiêu chí, nên nhà trường cần lập **Kế hoạch triển khai sử dụng Bộ tiêu chí**, không xây dựng lại hoặc thay đổi nội dung Bộ tiêu chí của Bộ.

Dưới đây là bản thảo thống nhất để đưa vào Word, hoàn thiện số văn bản, ngày ký và trình Hiệu trưởng xem xét.

> **writing · document**
>
> **ỦY BAN NHÂN DÂN PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> Số: ……/KH-MNAB
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập - Tự do - Hạnh phúc**
>
> *An Bình, ngày …… tháng …… năm 2026*
>
> # KẾ HOẠCH
> **Triển khai sử dụng Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030**
>
> ## I. CĂN CỨ XÂY DỰNG KẾ HOẠCH
>
> Căn cứ Công văn số 5890/BGDĐT-GDMN ngày 28 tháng 8 năm 2026 của Bộ Giáo dục và Đào tạo về việc hướng dẫn triển khai thí điểm xây dựng mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030;
>
> Căn cứ Phụ lục Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 ban hành kèm theo Công văn số 5890/BGDĐT-GDMN của Bộ Giáo dục và Đào tạo;
>
> Căn cứ Công văn số 3763/SGDĐT-GDMN ngày 28 tháng 9 năm 2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp về việc hướng dẫn triển khai thí điểm xây dựng mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 tại các cơ sở giáo dục mầm non trên địa bàn tỉnh;
>
> Căn cứ Công văn số 3074/UBND ngày 30 tháng 9 năm 2026 của Ủy ban nhân dân phường An Bình về việc triển khai thí điểm xây dựng mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 tại cơ sở giáo dục mầm non;
>
> Căn cứ nhiệm vụ năm học 2026–2027, định hướng phát triển nhà trường và điều kiện thực tế của đơn vị;
>
> Trường Mầm non An Bình xây dựng Kế hoạch triển khai sử dụng Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030, cụ thể như sau:
>
> ## II. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> Tổ chức triển khai sử dụng Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 làm công cụ tự đánh giá thực trạng, nhận diện những điểm mạnh, hạn chế và xác định các nội dung cần ưu tiên đổi mới, cải tiến chất lượng trong hoạt động quản lý, nuôi dưỡng, chăm sóc và giáo dục trẻ.
>
> Nâng cao năng lực quản trị, tính chủ động, trách nhiệm và hiệu quả hoạt động của nhà trường; phát huy vai trò, năng lực nghề nghiệp, tinh thần hợp tác và đổi mới sáng tạo của đội ngũ cán bộ quản lý, giáo viên, nhân viên.
>
> Tiếp tục đổi mới việc thực hiện Chương trình giáo dục mầm non theo hướng linh hoạt, phù hợp với điều kiện thực tế, lấy trẻ làm trung tâm; tăng cường học thông qua vui chơi, trải nghiệm, tôn trọng sự khác biệt, phát huy tính tích cực, chủ động và khả năng phát triển của từng trẻ.
>
> Từng bước phát triển các điều kiện bảo đảm chất lượng, xây dựng môi trường giáo dục an toàn, thân thiện, hạnh phúc; đẩy mạnh ứng dụng công nghệ thông tin, chuyển đổi số và tiếp cận có chọn lọc các phương pháp, kinh nghiệm giáo dục phù hợp.
>
> Xây dựng lộ trình đổi mới, nâng cao chất lượng giáo dục mầm non đến năm 2030 phù hợp với nhu cầu phát triển, năng lực đội ngũ và điều kiện thực tế; hình thành văn hóa tự đánh giá, điều chỉnh và cải tiến chất lượng thường xuyên, bền vững.
>
> ### 2. Yêu cầu
>
> Việc triển khai Bộ tiêu chí phải bảo đảm đúng mục đích, cấu trúc và nội dung theo hướng dẫn của Bộ Giáo dục và Đào tạo; thực hiện nghiêm túc, khách quan, thiết thực, tránh hình thức và chạy theo thành tích.
>
> Tổ chức rà soát đầy đủ 05 nhóm tiêu chí, 21 tiêu chí và 70 chỉ báo; căn cứ kết quả tự đánh giá để lựa chọn nội dung ưu tiên, xây dựng mục tiêu, nhiệm vụ, giải pháp và lộ trình phù hợp. Không nhất thiết triển khai đồng thời tất cả các nội dung của Bộ tiêu chí.
>
> Việc tự đánh giá tập trung vào mức độ thực hiện, hiệu quả hoạt động và những chuyển biến thực tế; không chỉ căn cứ vào việc có kế hoạch, hồ sơ, tài liệu hoặc tổ chức hoạt động. Bộ tiêu chí không sử dụng để xếp hạng, so sánh giữa các cơ sở giáo dục mầm non.
>
> Nội dung đổi mới, cải tiến chất lượng được lồng ghép vào kế hoạch phát triển nhà trường, kế hoạch thực hiện nhiệm vụ năm học, kế hoạch chuyên môn và các hoạt động thường xuyên theo quy định. Khai thác, sử dụng thông tin, dữ liệu và minh chứng hiện có; không làm phát sinh thêm hồ sơ, sổ sách hoặc thủ tục hành chính ngoài quy định.
>
> Bảo đảm sự tham gia, phối hợp và trách nhiệm của cán bộ quản lý, giáo viên, nhân viên, cha mẹ trẻ và các lực lượng liên quan; tạo sự thống nhất trong nhận thức, hành động và tổ chức thực hiện.
>
> Thường xuyên rà soát, đánh giá kết quả triển khai để điều chỉnh mục tiêu, giải pháp và lộ trình phù hợp với điều kiện thực tế, hướng tới nâng cao chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ.
>
> ## III. MỤC TIÊU
>
> ### 1. Mục tiêu chung
>
> Đến năm 2030, Trường Mầm non An Bình từng bước đổi mới toàn diện hoạt động quản trị, nuôi dưỡng, chăm sóc và giáo dục trẻ theo hướng hiện đại, linh hoạt, hiệu quả; phát triển đội ngũ có năng lực chuyên môn, khả năng thích ứng và đổi mới sáng tạo; xây dựng môi trường giáo dục an toàn, thân thiện, hạnh phúc, lấy trẻ làm trung tâm.
>
> Duy trì và phát huy những kết quả đã đạt được, tập trung cải tiến những lĩnh vực còn hạn chế; hình thành các giải pháp đổi mới thiết thực, có khả năng duy trì lâu dài và chia sẻ kinh nghiệm, góp phần nâng cao chất lượng giáo dục mầm non của nhà trường và địa phương.
>
> ### 2. Mục tiêu cụ thể
>
> **2.1. Về tự đánh giá và cải tiến chất lượng**
>
> - 100% các chỉ báo thuộc Bộ tiêu chí được tổ chức rà soát, đối chiếu với thực trạng nhà trường, xác định mức độ thực hiện, điểm mạnh, hạn chế và nội dung cần cải tiến.
> - 100% cán bộ quản lý, giáo viên, nhân viên có nhiệm vụ liên quan được phổ biến, hướng dẫn và tham gia triển khai các nội dung phù hợp.
> - Hằng năm lựa chọn các nội dung ưu tiên cải tiến trên cơ sở kết quả tự đánh giá, nhu cầu phát triển và nguồn lực thực tế.
> - Thực hiện theo dõi, rà soát và điều chỉnh thường xuyên; phấn đấu nâng cao mức độ phát triển chất lượng của những chỉ báo được lựa chọn ưu tiên.
>
> **2.2. Về chất lượng nuôi dưỡng, chăm sóc và giáo dục trẻ**
>
> - Bảo đảm thực hiện đầy đủ các yêu cầu về chăm sóc sức khỏe, dinh dưỡng, vệ sinh, an toàn và đánh giá sự phát triển của trẻ theo quy định.
> - Tăng cường tổ chức hoạt động giáo dục theo quan điểm lấy trẻ làm trung tâm, học thông qua vui chơi, trải nghiệm và khám phá.
> - Thực hiện theo dõi, đánh giá sự phát triển của từng trẻ theo quá trình, sử dụng kết quả để điều chỉnh hoạt động chăm sóc, giáo dục và phối hợp với gia đình.
> - Xây dựng môi trường giáo dục an toàn, thân thiện, hạnh phúc, tạo điều kiện để mỗi trẻ được tôn trọng, yêu thương và phát triển phù hợp với khả năng.
>
> **2.3. Về đổi mới quản trị và phát triển đội ngũ**
>
> - Nâng cao tính chủ động và trách nhiệm của cán bộ quản lý, tổ chuyên môn, giáo viên, nhân viên trong thực hiện nhiệm vụ.
> - Đổi mới sinh hoạt chuyên môn theo hướng nghiên cứu, chia sẻ, hỗ trợ đồng nghiệp và giải quyết các vấn đề thực tiễn.
> - Tăng cường bồi dưỡng năng lực chuyên môn, ứng dụng công nghệ và khả năng đổi mới sáng tạo của đội ngũ.
> - Từng bước tinh gọn quy trình, giảm các công việc hành chính trùng lặp, nâng cao hiệu quả phối hợp và xử lý công việc.
>
> **2.4. Về điều kiện bảo đảm chất lượng và chuyển đổi số**
>
> - Rà soát, sử dụng hiệu quả cơ sở vật chất, thiết bị, đồ dùng, đồ chơi, học liệu và các nguồn lực hiện có.
> - Từng bước cải thiện môi trường giáo dục theo hướng an toàn, xanh, mở, linh hoạt, phù hợp với nhu cầu của trẻ.
> - Đẩy mạnh ứng dụng công nghệ thông tin, quản lý và khai thác dữ liệu số phục vụ điều hành, quản lý và tổ chức hoạt động giáo dục.
> - Bảo đảm an toàn thông tin, bảo vệ dữ liệu cá nhân và quyền riêng tư của trẻ em, đội ngũ khi sử dụng công nghệ số.
>
> ## IV. NỘI DUNG VÀ GIẢI PHÁP THỰC HIỆN
>
> ### 1. Tổ chức nghiên cứu, phổ biến Bộ tiêu chí
>
> Tổ chức phổ biến nội dung Công văn số 5890/BGDĐT-GDMN, Công văn số 3763/SGDĐT-GDMN, Công văn số 3074/UBND và Phụ lục Bộ tiêu chí đến cán bộ quản lý, giáo viên, nhân viên thông qua các cuộc họp, sinh hoạt chuyên môn và hoạt động quản lý hiện có.
>
> Tập trung làm rõ mục đích, ý nghĩa, cấu trúc Bộ tiêu chí; phương pháp tự đánh giá theo 05 mức độ phát triển chất lượng; nguyên tắc lựa chọn nội dung ưu tiên, xây dựng lộ trình và cải tiến chất lượng liên tục.
>
> Phân công cán bộ quản lý, tổ chuyên môn và các bộ phận nghiên cứu những tiêu chí, chỉ báo thuộc lĩnh vực phụ trách, bảo đảm việc triển khai thống nhất và phù hợp với nhiệm vụ thực tế.
>
> ### 2. Rà soát, tự đánh giá thực trạng theo Bộ tiêu chí
>
> #### 2.1. Nội dung tự đánh giá
>
> Tổ chức rà soát toàn bộ 05 nhóm tiêu chí, 21 tiêu chí và 70 chỉ báo, gồm:
>
> | Nhóm | Nội dung | Số tiêu chí | Số chỉ báo |
> |---|---|---:|---:|
> | 1 | Đổi mới, phát triển chương trình giáo dục và tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục đáp ứng mục tiêu giáo dục mầm non | 04 | 12 |
> | 2 | Đổi mới quản trị cơ sở giáo dục mầm non theo hướng hiệu quả, tăng cường tự chủ gắn với trách nhiệm giải trình bảo đảm chất lượng | 04 | 16 |
> | 3 | Phát triển các điều kiện bảo đảm chất lượng, tạo môi trường giáo dục phát triển toàn diện cho trẻ em | 05 | 20 |
> | 4 | Chuyển đổi số, ứng dụng công nghệ thông tin và trí tuệ nhân tạo | 04 | 11 |
> | 5 | Hợp tác và hội nhập quốc tế | 04 | 11 |
> | **Tổng** | | **21** | **70** |
>
> #### 2.2. Phương pháp và mức độ tự đánh giá
>
> Thực hiện tự đánh giá từng chỉ báo theo 05 mức độ phát triển chất lượng quy định trong Bộ tiêu chí:
>
> **Mức 1 – Chưa triển khai:** Nội dung chưa được thực hiện hoặc mới được nhận diện, chuẩn bị; kết quả và tác động còn hạn chế.
>
> **Mức 2 – Bước đầu triển khai:** Đã xác định định hướng, có tổ chức thực hiện nhưng chưa thường xuyên, chưa đồng bộ; hiệu quả chưa rõ nét.
>
> **Mức 3 – Đáp ứng yêu cầu:** Được triển khai phù hợp với điều kiện thực tế, đáp ứng yêu cầu cơ bản của chỉ báo và tạo được kết quả tích cực.
>
> **Mức 4 – Thực hiện hiệu quả, có cải tiến:** Được triển khai chủ động, linh hoạt; có rà soát, điều chỉnh, hoàn thiện giải pháp và tạo chuyển biến rõ nét về chất lượng.
>
> **Mức 5 – Đổi mới, phát triển bền vững:** Có cách làm đổi mới, sáng tạo, hiệu quả; kết quả được duy trì, phát triển, có khả năng chia sẻ, lan tỏa và nhân rộng.
>
> Việc xác định mức độ căn cứ vào kết quả thực hiện và những chuyển biến thực tế. Trường hợp chưa đáp ứng đầy đủ mô tả của mức cao hơn thì xác định ở mức thấp hơn và ghi nhận những nội dung đã đạt được để tiếp tục cải tiến.
>
> Các thông tin, minh chứng phục vụ tự đánh giá được khai thác từ hồ sơ quản lý, kế hoạch giáo dục, kết quả theo dõi sự phát triển của trẻ, hồ sơ sức khỏe, kết quả sinh hoạt chuyên môn, dữ liệu số, phản hồi của cha mẹ trẻ và các hoạt động thường xuyên.
>
> #### 2.3. Tổng hợp và sử dụng kết quả
>
> Trên cơ sở tự đánh giá, xác định những nội dung đã thực hiện tốt cần tiếp tục duy trì, phát huy; những nội dung còn hạn chế, nguyên nhân, khó khăn và các vấn đề cần ưu tiên giải quyết.
>
> Kết quả tự đánh giá được sử dụng để xây dựng, điều chỉnh mục tiêu, nhiệm vụ, giải pháp trong kế hoạch năm học và các hoạt động chuyên môn. Không sử dụng kết quả để xếp hạng hoặc tạo áp lực thành tích đối với cá nhân, bộ phận.
>
> ### 3. Xác định các nội dung ưu tiên đổi mới, cải tiến chất lượng
>
> Việc lựa chọn nội dung ưu tiên được thực hiện sau khi rà soát thực trạng, trên cơ sở xem xét:
>
> - Mức độ ảnh hưởng đến sức khỏe, sự an toàn, hạnh phúc và sự phát triển của trẻ.
> - Những hạn chế, khó khăn đang ảnh hưởng trực tiếp đến chất lượng hoạt động của nhà trường.
> - Mức độ cần thiết và khả năng tạo chuyển biến thực tế.
> - Năng lực đội ngũ, cơ sở vật chất, nguồn lực và điều kiện tổ chức thực hiện.
> - Khả năng duy trì, phát triển và cải tiến trong những năm tiếp theo.
>
> Căn cứ đặc điểm hoạt động giáo dục mầm non, nhà trường dự kiến quan tâm các nội dung sau:
>
> | STT | Nội dung dự kiến ưu tiên | Tiêu chí liên quan | Định hướng cải tiến |
> |---|---|---|---|
> | 1 | Nâng cao chất lượng chăm sóc sức khỏe thể chất, tinh thần của trẻ | 1.2 | Tăng cường theo dõi sức khỏe, dinh dưỡng, vận động và hỗ trợ cảm xúc của trẻ. |
> | 2 | Đổi mới hoạt động giáo dục lấy trẻ làm trung tâm | 1.3 | Tăng cơ hội vui chơi, trải nghiệm, lựa chọn, khám phá và sáng tạo. |
> | 3 | Nâng cao hiệu quả đánh giá sự phát triển của trẻ | 1.4 | Sử dụng kết quả quan sát, đánh giá để điều chỉnh chăm sóc, giáo dục. |
> | 4 | Đổi mới quản trị, phát huy năng lực đội ngũ | 2.3 | Tăng cường trao quyền, hợp tác, chia sẻ chuyên môn và giảm công việc trùng lặp. |
> | 5 | Xây dựng môi trường giáo dục an toàn, hạnh phúc | 3.4 | Tăng cường tương tác tích cực, tôn trọng sự khác biệt và phòng ngừa nguy cơ gây tổn thương trẻ. |
> | 6 | Nâng cao hiệu quả quản lý, khai thác dữ liệu số | 4.2 | Sử dụng dữ liệu phục vụ quản lý, theo dõi và cải tiến chất lượng. |
>
> Danh mục trên là định hướng dự kiến, được điều chỉnh sau khi hoàn thành tự đánh giá thực trạng. Các tiêu chí còn lại tiếp tục được triển khai lồng ghép trong hoạt động thường xuyên phù hợp với nhu cầu và điều kiện thực tế.
>
> ### 4. Triển khai các giải pháp theo nhóm tiêu chí
>
> #### 4.1. Nhóm 1. Đổi mới, phát triển chương trình giáo dục và tổ chức hoạt động nuôi dưỡng, chăm sóc, giáo dục
>
> Rà soát, điều chỉnh chương trình giáo dục nhà trường phù hợp với Chương trình giáo dục mầm non, nhu cầu và khả năng phát triển của trẻ, đặc điểm địa phương và điều kiện thực tiễn.
>
> Tăng cường tổ chức các hoạt động giáo dục theo hướng mở, linh hoạt; phát huy vai trò chủ động của trẻ thông qua vui chơi, trải nghiệm, vận động, khám phá, giao tiếp và giải quyết những vấn đề gần gũi trong cuộc sống.
>
> Nâng cao hiệu quả công tác chăm sóc sức khỏe, dinh dưỡng và hỗ trợ tinh thần cho trẻ; quan tâm trẻ có nhu cầu hỗ trợ đặc biệt, trẻ khuyết tật, trẻ suy dinh dưỡng, thừa cân, béo phì và trẻ gặp khó khăn trong quá trình phát triển.
>
> Đổi mới hoạt động theo dõi, đánh giá sự phát triển của từng trẻ; sử dụng kết quả để điều chỉnh kế hoạch, môi trường, nội dung, phương pháp giáo dục và phối hợp với gia đình.
>
> #### 4.2. Nhóm 2. Đổi mới quản trị cơ sở giáo dục mầm non
>
> Tăng cường năng lực quản trị, điều hành dựa trên kết quả thực hiện nhiệm vụ và dữ liệu thực tế; xác định rõ mục tiêu, nhiệm vụ ưu tiên, trách nhiệm và kết quả cần đạt.
>
> Phát huy dân chủ, công khai, minh bạch; khuyến khích cán bộ quản lý, giáo viên, nhân viên chủ động đề xuất và triển khai các giải pháp phù hợp.
>
> Đổi mới nội dung, phương thức sinh hoạt chuyên môn, trao đổi, phối hợp công việc; rà soát, tinh gọn những quy trình, thao tác hành chính không cần thiết hoặc trùng lặp.
>
> Tăng cường phối hợp với cha mẹ trẻ, chính quyền địa phương và các lực lượng liên quan; sử dụng phản hồi để điều chỉnh, cải tiến chất lượng hoạt động.
>
> #### 4.3. Nhóm 3. Phát triển điều kiện bảo đảm chất lượng
>
> Rà soát việc phân công, bố trí đội ngũ; tạo điều kiện để cán bộ quản lý, giáo viên, nhân viên học tập, bồi dưỡng và phát triển năng lực nghề nghiệp liên tục.
>
> Tăng cường sinh hoạt chuyên môn theo hướng nghiên cứu hoạt động thực tiễn, hỗ trợ đồng nghiệp, chia sẻ những giải pháp sáng tạo, phù hợp.
>
> Khai thác và sử dụng hiệu quả cơ sở vật chất, không gian giáo dục, thiết bị, đồ dùng, đồ chơi và học liệu; ưu tiên cải thiện những điều kiện trực tiếp phục vụ an toàn, sức khỏe và sự phát triển của trẻ.
>
> Xây dựng môi trường giáo dục xanh, an toàn, thân thiện, hạnh phúc; tôn trọng sự khác biệt, nhu cầu, cảm xúc và quyền tham gia của trẻ.
>
> Huy động, phân bổ và sử dụng các nguồn lực hợp pháp đúng quy định, công khai, minh bạch, tiết kiệm, hiệu quả.
>
> #### 4.4. Nhóm 4. Chuyển đổi số, ứng dụng công nghệ thông tin và trí tuệ nhân tạo
>
> Tăng cường ứng dụng công nghệ số trong quản lý, điều hành, trao đổi, xử lý công việc và phối hợp với cha mẹ trẻ.
>
> Rà soát, cập nhật, quản lý dữ liệu số về trẻ em, đội ngũ, cơ sở vật chất và các hoạt động giáo dục; sử dụng thông tin, dữ liệu để theo dõi, đánh giá và cải tiến chất lượng.
>
> Hướng dẫn đội ngũ sử dụng phù hợp các công cụ công nghệ, trí tuệ nhân tạo hỗ trợ xây dựng kế hoạch, thiết kế hoạt động và thực hiện nhiệm vụ; bảo đảm kiểm tra, lựa chọn và điều chỉnh nội dung trước khi áp dụng.
>
> Thực hiện các yêu cầu về bảo vệ dữ liệu cá nhân, quyền riêng tư, an toàn thông tin và sử dụng công nghệ phù hợp với trẻ mầm non; không để công nghệ thay thế hoạt động vui chơi, vận động, giao tiếp và trải nghiệm thực tế của trẻ.
>
> #### 4.5. Nhóm 5. Hợp tác và hội nhập quốc tế
>
> Tăng cường kết nối, trao đổi và chia sẻ chuyên môn thông qua các cộng đồng học tập, mạng lưới nghề nghiệp trong nước và quốc tế phù hợp với điều kiện thực tế.
>
> Chủ động tiếp cận, lựa chọn và vận dụng các tri thức, học liệu, phương pháp và kinh nghiệm giáo dục tiên tiến trên cơ sở bảo đảm tính khoa học, phù hợp với mục tiêu Chương trình giáo dục mầm non và văn hóa Việt Nam.
>
> Khuyến khích đội ngũ học tập, trao đổi chuyên môn, nâng cao năng lực ngoại ngữ và năng lực tiếp cận tài liệu phù hợp.
>
> Tích hợp những giá trị văn hóa tích cực, giữ gìn và phát huy bản sắc văn hóa dân tộc, văn hóa địa phương trong môi trường và hoạt động giáo dục.
>
> ## V. LỘ TRÌNH THỰC HIỆN
>
> | Thời gian | Nội dung trọng tâm | Kết quả hướng tới |
> |---|---|---|
> | Tháng 10–12/2026 | Phổ biến Bộ tiêu chí; tự đánh giá 70 chỉ báo; xác định điểm mạnh, hạn chế, nguyên nhân và nội dung ưu tiên; lồng ghép nhiệm vụ vào kế hoạch năm học. | Xác định được mức độ thực hiện các chỉ báo và nhiệm vụ cần cải tiến. |
> | Tháng 01–5/2027 | Triển khai các nhiệm vụ ưu tiên; tăng cường hỗ trợ chuyên môn, theo dõi kết quả và điều chỉnh giải pháp. | Có chuyển biến bước đầu về chất lượng quản trị, nuôi dưỡng, chăm sóc, giáo dục và môi trường giáo dục. |
> | Tháng 6–7/2027 | Đánh giá kết quả thực hiện; rà soát các giải pháp và tham khảo kinh nghiệm từ hai đơn vị thí điểm của tỉnh. | Xác định những giải pháp hiệu quả cần duy trì, những nội dung cần điều chỉnh. |
> | Năm học 2027–2028 | Tiếp tục cải tiến các nội dung ưu tiên; vận dụng có chọn lọc những kinh nghiệm, giải pháp hiệu quả từ các đơn vị thí điểm. | Nâng cao tính ổn định, hiệu quả của các giải pháp đổi mới. |
> | Năm học 2028–2029 | Củng cố, mở rộng các giải pháp phù hợp; phát triển đội ngũ, môi trường giáo dục, quản trị và chuyển đổi số. | Từng bước cải thiện các chỉ báo, nâng cao chất lượng hoạt động nhà trường. |
> | Năm học 2029–2030 | Duy trì, phát triển những giải pháp hiệu quả; tiếp tục cải tiến những nội dung còn hạn chế. | Hình thành các giải pháp có hiệu quả bền vững và khả năng chia sẻ. |
> | Năm 2030 | Đánh giá kết quả thực hiện giai đoạn 2026–2030; tổng hợp kinh nghiệm, đề xuất định hướng tiếp theo. | Xác định kết quả, bài học kinh nghiệm và định hướng phát triển giai đoạn tiếp theo. |
>
> ## VI. THEO DÕI, ĐÁNH GIÁ VÀ ĐIỀU CHỈNH
>
> ### 1. Nội dung theo dõi, đánh giá
>
> Theo dõi mức độ triển khai, kết quả thực hiện và những chuyển biến thực tế đối với các nội dung được lựa chọn ưu tiên.
>
> Chú trọng đánh giá tác động của giải pháp đối với chất lượng quản trị, năng lực đội ngũ, điều kiện bảo đảm chất lượng và sự phát triển của trẻ.
>
> Xác định những nội dung thực hiện tốt để duy trì, phát huy; những khó khăn, hạn chế cần điều chỉnh, khắc phục.
>
> ### 2. Phương thức thực hiện
>
> Lồng ghép theo dõi, đánh giá vào sinh hoạt chuyên môn, kiểm tra nội bộ, hoạt động quản lý và công tác sơ kết, tổng kết nhiệm vụ năm học.
>
> Sử dụng thông tin, dữ liệu, kết quả hoạt động và minh chứng hiện có; không yêu cầu xây dựng thêm hồ sơ, sổ sách hoặc biểu mẫu không cần thiết.
>
> Hằng tháng tổ chức rà soát tiến độ, kết quả và khó khăn; thực hiện báo cáo UBND phường An Bình thông qua Phòng Văn hóa - Xã hội theo yêu cầu tại Công văn số 3074/UBND, bảo đảm ngắn gọn, thiết thực, tránh trùng lặp với các báo cáo hiện hành.
>
> Cuối học kỳ, năm học tổ chức đánh giá mức độ chuyển biến, sử dụng kết quả để điều chỉnh mục tiêu, giải pháp và nhiệm vụ trong thời gian tiếp theo.
>
> ## VII. PHÂN CÔNG TRÁCH NHIỆM
>
> ### 1. Hiệu trưởng
>
> Chịu trách nhiệm chỉ đạo chung việc nghiên cứu, sử dụng Bộ tiêu chí, tổ chức tự đánh giá, xác định nội dung ưu tiên và lộ trình đổi mới, nâng cao chất lượng giáo dục mầm non.
>
> Phân công nhiệm vụ, điều phối các nguồn lực, chỉ đạo lồng ghép nội dung cải tiến vào các kế hoạch hiện hành; thường xuyên kiểm tra, theo dõi, đánh giá, điều chỉnh giải pháp phù hợp.
>
> Chủ động tham mưu, báo cáo UBND phường An Bình, Phòng Văn hóa - Xã hội về kết quả thực hiện, những khó khăn và nhu cầu hỗ trợ theo thẩm quyền.
>
> ### 2. Phó Hiệu trưởng
>
> Căn cứ lĩnh vực được phân công, hướng dẫn các tổ chuyên môn, giáo viên, nhân viên rà soát các tiêu chí, chỉ báo liên quan.
>
> Chỉ đạo, hỗ trợ đổi mới các hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ; phát triển đội ngũ, môi trường giáo dục và điều kiện bảo đảm chất lượng.
>
> Theo dõi, tổng hợp kết quả, đề xuất những giải pháp phù hợp với thực trạng và nhu cầu phát triển của nhà trường.
>
> ### 3. Tổ trưởng chuyên môn
>
> Tổ chức nghiên cứu, trao đổi các nội dung Bộ tiêu chí trong sinh hoạt chuyên môn; hướng dẫn giáo viên tự đánh giá, lựa chọn và thực hiện các giải pháp cải tiến.
>
> Tăng cường hỗ trợ đồng nghiệp, chia sẻ kinh nghiệm và đề xuất những cách làm hiệu quả trong tổ chức hoạt động giáo dục lấy trẻ làm trung tâm.
>
> ### 4. Giáo viên
>
> Chủ động nghiên cứu, thực hiện các nội dung tiêu chí liên quan đến nhiệm vụ được giao.
>
> Đổi mới tổ chức hoạt động giáo dục, quan sát, đánh giá sự phát triển của trẻ; phối hợp với gia đình trong chăm sóc, giáo dục và hỗ trợ từng trẻ.
>
> Tham gia tự đánh giá, phản ánh khó khăn, đề xuất giải pháp cải tiến phù hợp với điều kiện nhóm, lớp.
>
> ### 5. Nhân viên và các bộ phận liên quan
>
> Tham gia thực hiện các nội dung thuộc lĩnh vực phụ trách về sức khỏe, dinh dưỡng, vệ sinh, an toàn, tài chính, cơ sở vật chất, thiết bị, dữ liệu và các điều kiện bảo đảm chất lượng.
>
> Phối hợp cung cấp thông tin hiện có, tham gia tự đánh giá và đề xuất giải pháp nâng cao hiệu quả công việc.
>
> ### 6. Ban đại diện cha mẹ trẻ và các lực lượng phối hợp
>
> Phối hợp với nhà trường trong trao đổi thông tin về sức khỏe, nhu cầu và sự phát triển của trẻ.
>
> Tham gia đóng góp ý kiến, phối hợp triển khai các hoạt động giáo dục phù hợp; đồng hành cùng nhà trường trong xây dựng môi trường giáo dục an toàn, thân thiện, hạnh phúc theo đúng quy định.
>
> ## VIII. KINH PHÍ THỰC HIỆN
>
> Kinh phí thực hiện được cân đối từ nguồn kinh phí được giao và các nguồn hợp pháp khác theo quy định; gắn với các nhiệm vụ thường xuyên và kế hoạch phát triển của nhà trường.
>
> Ưu tiên khai thác, sử dụng hiệu quả các điều kiện và nguồn lực hiện có; tập trung nguồn lực cho những nhiệm vụ thiết thực, trực tiếp nâng cao chất lượng nuôi dưỡng, chăm sóc, giáo dục và bảo đảm an toàn cho trẻ.
>
> Việc huy động, quản lý và sử dụng các nguồn lực phải bảo đảm đúng quy định, công khai, minh bạch, tiết kiệm và hiệu quả; không đặt ra các khoản đóng góp bắt buộc ngoài quy định.
>
> Đối với những nội dung vượt khả năng của nhà trường, chủ động rà soát, tham mưu và đề xuất cơ quan quản lý xem xét hỗ trợ theo thẩm quyền.
>
> ## IX. TỔ CHỨC THỰC HIỆN
>
> Căn cứ nội dung kế hoạch, Hiệu trưởng chỉ đạo các bộ phận tổ chức triển khai sử dụng Bộ tiêu chí gắn với thực hiện nhiệm vụ năm học 2026–2027 và định hướng phát triển nhà trường giai đoạn 2026–2030.
>
> Các bộ phận được phân công có trách nhiệm chủ động phối hợp, triển khai, theo dõi và đánh giá kết quả thực hiện; kịp thời báo cáo những khó khăn, vướng mắc và đề xuất giải pháp điều chỉnh phù hợp.
>
> Nhà trường chủ động cập nhật, học tập kinh nghiệm triển khai từ Trường Mầm non Lê Thị Hồng Gấm, phường Mỹ Tho và Trường Mầm non Cao Lãnh, phường Cao Lãnh là hai cơ sở được tỉnh lựa chọn thí điểm trong năm học 2026–2027; lựa chọn, vận dụng những giải pháp phù hợp với điều kiện thực tế, không sao chép máy móc mô hình của đơn vị khác.
>
> Định kỳ rà soát kết quả tự đánh giá, điều chỉnh mục tiêu, nhiệm vụ và giải pháp; duy trì và phát huy những kết quả đạt được, tiếp tục cải tiến những nội dung còn hạn chế.
>
> Quá trình triển khai phải bảo đảm tính thiết thực, hiệu quả, không phát sinh hồ sơ, thủ tục hành chính ngoài quy định; không ảnh hưởng đến hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ và nhiệm vụ thường xuyên của nhà trường.
>
> Trên đây là Kế hoạch triển khai sử dụng Bộ tiêu chí mô hình đổi mới, nâng cao chất lượng giáo dục mầm non giai đoạn 2026–2030 của Trường Mầm non An Bình. Đề nghị cán bộ quản lý, giáo viên, nhân viên và các bộ phận liên quan phối hợp tổ chức thực hiện nghiêm túc, hiệu quả./.
>
> **Nơi nhận:**
> - UBND phường An Bình (báo cáo);
> - Phòng Văn hóa - Xã hội (phối hợp);
> - Ban Giám hiệu;
> - Các tổ chuyên môn, bộ phận;
> - Lưu: VT.
>
> **HIỆU TRƯỞNG**  
> *(Ký, ghi rõ họ tên và đóng dấu)*
>
> ---
>
> # PHỤ LỤC
> # BỘ TIÊU CHÍ MÔ HÌNH ĐỔI MỚI, NÂNG CAO CHẤT LƯỢNG GIÁO DỤC MẦM NON GIAI ĐOẠN 2026–2030
>
> *Kèm theo Kế hoạch số ……/KH-MNAB ngày …… tháng …… năm 2026 của Trường Mầm non An Bình.*
>
> *Nội dung các tiêu chí, chỉ báo được trình bày theo Phụ lục ban hành kèm theo Công văn số 5890/BGDĐT-GDMN ngày 28/8/2026 của Bộ Giáo dục và Đào tạo.*
>
> ## NHÓM 1. ĐỔI MỚI, PHÁT TRIỂN CHƯƠNG TRÌNH GIÁO DỤC VÀ TỔ CHỨC CÁC HOẠT ĐỘNG NUÔI DƯỠNG, CHĂM SÓC, GIÁO DỤC ĐÁP ỨNG MỤC TIÊU GIÁO DỤC MẦM NON
>
> | Mã | Tên tiêu chí | Chỉ báo |
> |---|---|---|
> | **1.1** | **Đổi mới phát triển Chương trình giáo dục bảo đảm linh hoạt, phù hợp với bối cảnh nhằm phát triển ở trẻ các năng lực nền tảng ban đầu của hệ giá trị cốt lõi con người Việt Nam** | **1.1.1.** Phát triển chương trình giáo dục của cơ sở giáo dục mầm non theo hướng mở, linh hoạt, phù hợp với Chương trình giáo dục mầm non, điều kiện thực tiễn của địa phương và đặc điểm, nhu cầu, khả năng của trẻ, hướng tới thực hiện mục tiêu phát triển toàn diện trẻ em. |
> | | | **1.1.2.** Rà soát, cập nhật, điều chỉnh chương trình giáo dục của cơ sở dựa trên kết quả thực hiện, dữ liệu theo dõi sự phát triển của trẻ, ý kiến phản hồi của giáo viên, cha mẹ trẻ và những thay đổi của điều kiện thực tiễn. |
> | | | **1.1.3.** Tăng cường sự tham gia, phối hợp của cha mẹ của trẻ em, cộng đồng và các lực lượng liên quan trong phát triển Chương trình giáo dục của cơ sở, bảo đảm phù hợp với nhu cầu phát triển của trẻ, trẻ em có hoàn cảnh đặc biệt, văn hóa địa phương và các giá trị tốt đẹp của con người Việt Nam. |
> | **1.2** | **Nâng cao thể lực, tầm vóc, tăng chiều cao trung bình của trẻ em; đảm bảo sức khỏe thể chất, tinh thần cho trẻ** | **1.2.1.** Theo dõi tình trạng dinh dưỡng, sức khỏe và sự phát triển của từng trẻ để điều chỉnh chế độ nuôi dưỡng, chăm sóc và hỗ trợ phù hợp; chú trọng trẻ có nhu cầu hỗ trợ đặc biệt, trẻ khuyết tật, trẻ suy dinh dưỡng, thừa cân, béo phì hoặc có nguy cơ chậm phát triển. |
> | | | **1.2.2.** Tổ chức đa dạng các hoạt động phát triển vận động, tạo cơ hội để trẻ tích cực, chủ động tham gia; bảo đảm phù hợp với độ tuổi, thể trạng, khả năng, nhu cầu vận động của từng trẻ và điều kiện thực tiễn của cơ sở. |
> | | | **1.2.3.** Theo dõi sức khỏe tinh thần của trẻ; kịp thời nhận diện những biểu hiện khó khăn về cảm xúc, tâm lý, hành vi và thực hiện các hình thức hỗ trợ phù hợp nhằm bảo đảm sức khỏe tinh thần và sự phát triển lành mạnh của trẻ. |
> | | | **1.2.4.** Phối hợp gia đình và cộng đồng trong tổ chức hoạt động nuôi dưỡng và chăm sóc bảo đảm sức khỏe thể chất, tinh thần cho trẻ. |
> | **1.3** | **Đổi mới tổ chức hoạt động giáo dục lấy trẻ làm trung tâm, tăng cường học qua chơi và trải nghiệm, tôn trọng sự khác biệt và phát huy tính chủ động của trẻ** | **1.3.1.** Tổ chức hoạt động giáo dục đa dạng, linh hoạt, phù hợp với nhu cầu, khả năng, hứng thú, sự phát triển của từng trẻ; tăng cường học qua chơi và trải nghiệm, tạo cơ hội để trẻ chủ động lựa chọn, tham gia, bày tỏ ý tưởng và phát huy khả năng của bản thân. |
> | | | **1.3.2.** Vận dụng phù hợp, có chọn lọc các phương pháp, cách tiếp cận giáo dục tiên tiến trong tổ chức hoạt động; khuyến khích và tạo cơ hội để trẻ giao tiếp, hợp tác, giải quyết vấn đề, sáng tạo và tham gia vào những hoạt động có liên quan đến bản thân, cuộc sống của trẻ hằng ngày, đáp ứng với mục tiêu Chương trình giáo dục mầm non và đặc điểm phát triển của trẻ. |
> | | | **1.3.3.** Phối hợp giữa cơ sở giáo dục mầm non với gia đình và cộng đồng trong tạo môi trường giáo dục, cơ hội và các tình huống giáo dục phù hợp để trẻ được tôn trọng, lắng nghe, bày tỏ cảm xúc, nhu cầu và ý kiến; hình thành tính tự lập, tự chủ và khả năng tự bảo vệ phù hợp với độ tuổi; biết nhận diện một số nguy cơ không an toàn, biết từ chối, tìm kiếm sự trợ giúp và có hành vi phù hợp để bảo vệ bản thân trong môi trường thực và môi trường số. |
> | **1.4** | **Theo dõi, đánh giá sự phát triển của từng trẻ theo quá trình; sử dụng kết quả đánh giá để điều chỉnh kịp thời hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ** | **1.4.1.** Theo dõi, đánh giá tình trạng dinh dưỡng, sức khỏe và an toàn của từng trẻ bằng các hình thức phù hợp; sử dụng kết quả để nhận diện, kịp thời điều chỉnh chế độ nuôi dưỡng, chăm sóc, hỗ trợ trẻ và phối hợp với gia đình phù hợp với nhu cầu, tình trạng sức khỏe và sự phát triển của trẻ. |
> | | | **1.4.2.** Theo dõi, đánh giá thường xuyên, liên tục quá trình phát triển và sự tiến bộ của từng trẻ bằng các phương pháp, hình thức phù hợp; sử dụng kết quả đánh giá để nhận diện, kịp thời điều chỉnh kế hoạch, môi trường giáo dục, nội dung, phương pháp và hình thức tổ chức hoạt động giáo dục phù hợp nhu cầu, khả năng, hứng thú và nhịp độ phát triển của trẻ; thông tin đánh giá được sử dụng thiết thực, phù hợp, bảo đảm qui định về quản lý dữ liệu cá nhân; không so sánh giữa các trẻ; không tạo áp lực thành tích; bảo đảm đánh giá vì sự tiến bộ của từng trẻ. |
>
> ## NHÓM 2. ĐỔI MỚI QUẢN TRỊ CƠ SỞ GIÁO DỤC MẦM NON THEO HƯỚNG HIỆU QUẢ, TĂNG CƯỜNG TỰ CHỦ GẮN VỚI TRÁCH NHIỆM GIẢI TRÌNH VÀ BẢO ĐẢM CHẤT LƯỢNG
>
> | Mã | Tên tiêu chí | Chỉ báo |
> |---|---|---|
> | **2.1** | **Nâng cao năng lực hành động, tính chủ động và trách nhiệm trong thực hiện chức năng, nhiệm vụ theo phân cấp, thẩm quyền** | **2.1.1.** Chủ động đánh giá thực trạng, xác định điểm mạnh, điểm yếu, yêu cầu và các nội dung cần ưu tiên về điều kiện bảo đảm chất lượng, thực hiện Chương trình giáo dục mầm non; sử dụng kết quả để xây dựng, điều chỉnh và tổ chức thực hiện kế hoạch phù hợp với điều kiện thực tiễn của cơ sở. |
> | | | **2.1.2.** Chủ động ra quyết định và chịu trách nhiệm trong quản trị, điều hành các hoạt động theo thẩm quyền trên cơ sở thông tin, dữ liệu và kết quả thực hiện; bảo đảm phù hợp với quy định pháp luật và điều kiện thực tiễn của cơ sở. |
> | | | **2.1.3.** Chủ động cập nhật, phổ biến, phân tích tác động của các quy định, chính sách mới và những thay đổi của thực tiễn để lựa chọn cách thức tổ chức thực hiện, kịp thời điều chỉnh hoạt động của cơ sở phù hợp với yêu cầu và điều kiện thực tế. |
> | | | **2.1.4.** Chủ động phối hợp với gia đình, cộng đồng, chính quyền địa phương và các tổ chức, cá nhân có liên quan; tạo điều kiện để các bên tham gia, đồng hành phù hợp trong xây dựng kế hoạch, tổ chức hoạt động và cải tiến chất lượng của cơ sở. |
> | | | **2.1.5.** Chủ động thực hiện công khai, minh bạch và trách nhiệm giải trình về việc thực hiện nhiệm vụ, sử dụng nguồn lực và kết quả hoạt động theo quy định. |
> | **2.2** | **Hoạch định chiến lược và dẫn dắt sự phát triển của cơ sở theo yêu cầu đổi mới giáo dục mầm non** | **2.2.1.** Xây dựng định hướng, mục tiêu và kế hoạch phát triển của cơ sở phù hợp với từng giai đoạn; xác định rõ các mục tiêu ưu tiên về phát triển chương trình, tổ chức hoạt động nuôi dưỡng, chăm sóc, giáo dục và các điều kiện bảo đảm chất lượng. |
> | | | **2.2.2.** Đẩy mạnh việc lồng ghép các mục tiêu chuyển đổi số, ứng dụng công nghệ, giáo dục xanh, hội nhập và các yêu cầu đổi mới giáo dục vào các kế hoạch và hoạt động; bảo đảm triển khai thống nhất, phù hợp với điều kiện thực tiễn; không làm phát sinh các kế hoạch riêng không cần thiết. |
> | | | **2.2.3.** Lựa chọn và tổ chức thực hiện các nhiệm vụ trọng tâm, nhiệm vụ đột phá trên cơ sở kết quả đánh giá thực trạng, nhằm phát huy điểm mạnh, tháo gỡ những điểm nghẽn và tạo chuyển biến về chất lượng. |
> | | | **2.2.4.** Theo dõi, đánh giá kết quả thực hiện các mục tiêu phát triển; sử dụng kết quả đánh giá để kịp thời điều chỉnh kế hoạch và giải pháp phù hợp với yêu cầu phát triển và điều kiện thực tiễn của cơ sở. |
> | **2.3** | **Kiến tạo môi trường làm việc theo hướng trao quyền, dân chủ, minh bạch, hợp tác, trách nhiệm, thúc đẩy đổi mới sáng tạo và thích ứng trong tổ chức của cơ sở** | **2.3.1.** Trao quyền, tạo điều kiện để tổ chuyên môn, nhóm/lớp và cá nhân chủ động xây dựng, thực hiện và điều chỉnh kế hoạch giáo dục, tổ chức các hoạt động phù hợp với điều kiện thực tiễn của cơ sở và nhu cầu của trẻ; gắn quyền chủ động với trách nhiệm về kết quả thực hiện. |
> | | | **2.3.2.** Tạo môi trường chia sẻ tri thức, học tập lẫn nhau; khuyến khích, ghi nhận, thử nghiệm và lan tỏa các sáng kiến, giải pháp đổi mới trong hoạt động nuôi dưỡng, chăm sóc, giáo dục và quản trị cơ sở. |
> | | | **2.3.3.** Rà soát, tinh gọn quy trình làm việc; cắt giảm các cuộc họp, hồ sơ, báo cáo và thủ tục hành chính không cần thiết hoặc trùng lặp; đổi mới phương thức trao đổi, phối hợp và xử lý công việc, dành thời gian cho hoạt động chuyên môn và nuôi dưỡng, chăm sóc, giáo dục trẻ. |
> | | | **2.3.4.** Xác định rõ trách nhiệm của cá nhân trong thực hiện và phối hợp thực hiện nhiệm vụ; phát huy sự tham gia và trí tuệ tập thể trong giải quyết vấn đề, đề xuất giải pháp và cải tiến hoạt động của cơ sở. |
> | **2.4** | **Đẩy mạnh phương thức điều hành theo hướng quản trị hiện đại, linh hoạt, hiệu quả** | **2.4.1.** Điều hành hoạt động dựa trên kết quả và dữ liệu; phân tích và sử dụng kết quả thực hiện và thông tin phản hồi của đội ngũ nhân sự bên trong cơ sở, cha mẹ trẻ em và các bên liên quan để kịp thời điều chỉnh, cải tiến hoạt động của cơ sở và của các nhóm, lớp. |
> | | | **2.4.2.** Tổ chức phối hợp công việc giữa trường chính, phân hiệu, điểm trường, các cá nhân, tổ, bộ phận theo hướng liên thông, đồng bộ, rõ người, rõ việc, rõ thời gian, rõ kết quả, bảo đảm tính linh hoạt và hiệu quả trong thực hiện nhiệm vụ. |
> | | | **2.4.3.** Tổ chức quản trị, điều hành theo hướng tăng cường xử lý công việc trên môi trường số, giảm xử lý thủ công dựa trên minh chứng hồ sơ, sổ sách, giấy tờ, bảo đảm kịp thời, chính xác và hiệu quả. |
>
> ## NHÓM 3. PHÁT TRIỂN CÁC ĐIỀU KIỆN BẢO ĐẢM CHẤT LƯỢNG, TẠO MÔI TRƯỜNG GIÁO DỤC PHÁT TRIỂN TOÀN DIỆN CHO TRẺ TRONG CƠ SỞ GIÁO DỤC MẦM NON
>
> | Mã | Tên tiêu chí | Chỉ báo |
> |---|---|---|
> | **3.1** | **Phát triển đội ngũ nhà giáo, cán bộ quản lý và nhân sự hỗ trợ giáo dục có năng lực nghề nghiệp, khả năng thích ứng, sáng tạo và đáp ứng yêu cầu nâng cao chất lượng GDMN** | **3.1.1.** Phân công, bố trí và sử dụng đội ngũ nhà giáo, cán bộ quản lý và nhân sự hỗ trợ giáo dục theo vị trí việc làm, yêu cầu nhiệm vụ, năng lực, điều kiện thực tiễn của cơ sở; điều chỉnh kịp thời khi yêu cầu nhiệm vụ và điều kiện thực tiễn thay đổi. |
> | | | **3.1.2.** Tổ chức và tạo điều kiện để đội ngũ học tập, bồi dưỡng, tự học, tự bồi dưỡng và phát triển nghề nghiệp liên tục thông qua thực hành, trao đổi, chia sẻ kinh nghiệm và giải quyết các vấn đề thực tiễn trong quá trình thực hiện nhiệm vụ. |
> | | | **3.1.3.** Hướng dẫn, hỗ trợ đội ngũ vận dụng phù hợp, có chọn lọc các phương pháp, cách tiếp cận giáo dục tiên tiến; tổ chức hoạt động và môi trường giáo dục linh hoạt, phù hợp với điều kiện thực tiễn, nhu cầu, khả năng, hứng thú và sự phát triển của trẻ. |
> | | | **3.1.4.** Hỗ trợ đội ngũ khai thác, sử dụng công nghệ, học liệu số, thiết bị và các công cụ hỗ trợ trong hoạt động nghề nghiệp nhằm nâng cao năng lực số; chú trọng năng lực bảo đảm an toàn thông tin, bảo vệ dữ liệu cá nhân, chuẩn mực về hành vi trên môi trường số. |
> | | | **3.1.5.** Tạo điều kiện, khuyến khích đội ngũ chủ động đề xuất, thực nghiệm, điều chỉnh và lan tỏa các cách làm phù hợp, sáng tạo trong tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ và thực hiện nhiệm vụ. |
> | | | **3.1.6.** Xây dựng môi trường làm việc và tổ chức các hoạt động hỗ trợ sức khỏe thể chất, tinh thần và sức khỏe nghề nghiệp của đội ngũ; kịp thời nhận diện, hỗ trợ giảm áp lực và phòng ngừa căng thẳng nghề nghiệp trong quá trình thực hiện nhiệm vụ. |
> | **3.2** | **Phát triển cơ sở vật chất, môi trường tổ chức các hoạt động theo hướng chuẩn hóa, an toàn, xanh, linh hoạt, hiện đại và đáp ứng yêu cầu nuôi dưỡng, chăm sóc, giáo dục trẻ** | **3.2.1.** Sắp xếp, bố trí các khu vực, không gian và môi trường tổ chức hoạt động giáo dục theo hướng mở, kết nối, đa chức năng, thân thiện, thẩm mỹ, phù hợp độ tuổi của trẻ và yêu cầu thực hiện Chương trình giáo dục mầm non. |
> | | | **3.2.2.** Khai thác, sử dụng linh hoạt, hiệu quả các khu vực, không gian giáo dục nhằm mở rộng cơ hội cho trẻ chủ động lựa chọn, tham gia, trải nghiệm, khám phá, tương tác và vận động trong các hoạt động hằng ngày. |
> | | | **3.2.3.** Thường xuyên rà soát, cải tạo, bổ sung và nâng cấp cơ sở vật chất và hoàn thiện môi trường giáo dục theo hướng an toàn, xanh, hiện đại, thuận tiện trong sử dụng, phù hợp với nhu cầu của trẻ và yêu cầu tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ. |
> | **3.3** | **Phát triển thiết bị, học liệu, đồ dùng, đồ chơi theo hướng hiện đại, thông minh, đa dạng, mở, an toàn, phù hợp và phát huy tính chủ động, khám phá, trải nghiệm, sáng tạo của trẻ** | **3.3.1.** Lựa chọn và bố trí thiết bị, học liệu, đồ dùng, đồ chơi phù hợp với mục tiêu giáo dục, nội dung hoạt động, độ tuổi, nhu cầu, khả năng và đặc điểm phát triển của trẻ, đáp ứng yêu cầu thực hiện Chương trình giáo dục của cơ sở. |
> | | | **3.3.2.** Khai thác, sử dụng linh hoạt, hiệu quả học liệu mở, vật liệu tự nhiên, vật liệu tái sử dụng, đồ dùng, đồ chơi đa chức năng và các nguồn học liệu đa dạng; tạo cơ hội cho trẻ chủ động lựa chọn, thao tác, trải nghiệm, khám phá và sáng tạo trong các hoạt động hằng ngày. |
> | | | **3.3.3.** Lựa chọn, quản lý và sử dụng học liệu số, phương tiện tương tác, thiết bị và các công cụ hỗ trợ phù hợp với độ tuổi, mục đích và nội dung hoạt động; bảo đảm an toàn và hỗ trợ trẻ tham gia, trải nghiệm phù hợp trong môi trường số. |
> | | | **3.3.4.** Thường xuyên rà soát, bổ sung, thay thế và nâng cấp thiết bị, học liệu, đồ dùng, đồ chơi trên cơ sở nhu cầu, mức độ và hiệu quả sử dụng; bảo đảm chất lượng, an toàn, thuận tiện và thích ứng với sự đổi mới không ngừng của phương thức giáo dục hiện đại. |
> | **3.4** | **Xây dựng môi trường giáo dục an toàn, thân thiện, hạnh phúc, lấy trẻ làm trung tâm, tôn trọng sự khác biệt, bảo đảm sự tham gia và phát triển của trẻ** | **3.4.1.** Xây dựng và duy trì môi trường giáo dục an toàn, thân thiện, tôn trọng sự khác biệt, trong đó mỗi trẻ được quan tâm, tôn trọng và có cơ hội tham gia phù hợp với nhu cầu, khả năng của mình. |
> | | | **3.4.2.** Duy trì các mối quan hệ và tương tác tích cực, tạo cho trẻ cảm giác an toàn, được tôn trọng, yêu thương và hỗ trợ về cảm xúc; chủ động phòng ngừa các hành vi bạo lực, quát mắng, gây áp lực hoặc tổn thương trẻ. |
> | | | **3.4.3.** Lắng nghe, ghi nhận và phản hồi phù hợp đối với ý kiến, cảm xúc, nhu cầu của trẻ; tôn trọng và xem xét ý kiến của trẻ trong tổ chức môi trường giáo dục và các hoạt động có liên quan đến trẻ phù hợp với độ tuổi. |
> | | | **3.4.4.** Duy trì trao đổi, chia sẻ thông tin hai chiều với cha mẹ trẻ em và các bên liên quan về nhu cầu, cảm xúc, hành vi và những vấn đề cần hỗ trợ của trẻ; phối hợp xây dựng môi trường giao tiếp, ứng xử tích cực, thống nhất trong hỗ trợ trẻ ở cơ sở, gia đình và cộng đồng. |
> | **3.5** | **Phát triển và sử dụng hiệu quả các nguồn lực, gắn với nhiệm vụ trọng tâm và mục tiêu phát triển của cơ sở** | **3.5.1.** Xây dựng và tổ chức thực hiện kế hoạch thu hút, huy động, phân bổ, sử dụng nguồn lực phù hợp với nhu cầu, điều kiện thực tiễn, nhiệm vụ trọng tâm, mục tiêu chiến lược của cơ sở. |
> | | | **3.5.2.** Phân bổ, quản lý và sử dụng nguồn lực theo các nhiệm vụ, nội dung ưu tiên; theo dõi hiệu quả sử dụng để kịp thời điều chỉnh, bảo đảm công khai, minh bạch, tiết kiệm và phục vụ thiết thực việc nâng cao chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ. |
> | | | **3.5.3.** Công khai thông tin và tạo điều kiện để các bên liên quan tiếp cận thông tin, tham gia góp ý, giám sát việc huy động, quản lý và sử dụng nguồn lực theo quy định. |
>
> ## NHÓM 4. CHUYỂN ĐỔI SỐ, ỨNG DỤNG CÔNG NGHỆ THÔNG TIN VÀ TRÍ TUỆ NHÂN TẠO
>
> | Mã | Tên tiêu chí | Chỉ báo |
> |---|---|---|
> | **4.1** | **Phát triển môi trường quản trị số, hỗ trợ điều hành, phối hợp và xử lý công việc liên thông, linh hoạt, hiệu quả** | **4.1.1.** Thiết lập và vận hành hệ thống quản lý số thống nhất trong cơ sở giáo dục mầm non; bảo đảm kết nối, liên thông giữa cán bộ quản lý, giáo viên, nhân sự hỗ trợ giáo dục, các tổ chuyên môn và bộ phận liên quan. |
> | | | **4.1.2.** Tiếp nhận, xử lý, trao đổi, lưu chuyển thông tin và triển khai các nhiệm vụ trên môi trường số; theo dõi tiến độ, xử lý công việc, tăng tính liên thông, kịp thời, minh bạch và giảm xử lý thủ công. |
> | | | **4.1.3.** Tổ chức các dịch vụ hỗ trợ giáo dục và tương tác với cha mẹ trẻ, các bên liên quan trên môi trường số; trao đổi thông tin, tiếp nhận và phản hồi ý kiến, phối hợp xử lý các yêu cầu, giao dịch và thanh toán điện tử; bảo đảm thuận tiện, minh bạch, an toàn và phù hợp với điều kiện thực tiễn. |
> | **4.2** | **Tăng cường quản lý, kết nối và khai thác dữ liệu số phục vụ theo dõi, đánh giá và cải tiến chất lượng** | **4.2.1.** Số hóa, cập nhật và quản lý dữ liệu về trẻ em, đội ngũ, cơ sở vật chất, tài chính, tài sản và các hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ em trên hệ thống số bảo đảm đầy đủ, chính xác, thống nhất và thuận tiện trong khai thác, sử dụng. |
> | | | **4.2.2.** Kết nối, đồng bộ và chia sẻ dữ liệu giữa trường chính, phân hiệu, điểm trường, các bộ phận, hoạt động và hệ thống quản lý của cơ sở; bảo đảm dữ liệu thống nhất và thuận tiện trong khai thác, sử dụng. |
> | | | **4.2.3.** Sử dụng dữ liệu số để theo dõi, tổng hợp, phân tích, phát hiện vấn đề và dự báo nhu cầu; hỗ trợ đánh giá, điều chỉnh, cải tiến hoạt động và xây dựng kế hoạch phát triển của cơ sở phù hợp với tình hình thực tiễn. |
> | | | **4.2.4.** Phân quyền và kiểm soát việc truy cập, khai thác, sử dụng, lưu trữ và chia sẻ dữ liệu; bảo vệ thông tin, dữ liệu cá nhân, hình ảnh và quyền riêng tư của trẻ em, đội ngũ theo quy định. |
> | **4.3** | **Thúc đẩy ứng dụng công nghệ số, trí tuệ nhân tạo và các công cụ thông minh, hỗ trợ hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ** | **4.3.1.** Sử dụng trí tuệ nhân tạo phù hợp để hỗ trợ xây dựng kế hoạch, thiết kế hoạt động, tổng hợp thông tin và đề xuất các phương án hỗ trợ trẻ; nội dung do trí tuệ nhân tạo tạo ra hoặc gợi ý được xem xét, lựa chọn, điều chỉnh phù hợp với mục tiêu giáo dục, đặc điểm của trẻ và điều kiện thực tiễn trước khi sử dụng. |
> | | | **4.3.2.** Sử dụng phù hợp ứng dụng công nghệ, thiết bị, công cụ thông minh và học liệu số để hỗ trợ trẻ khám phá, trải nghiệm, sáng tạo, giải quyết vấn đề và tham gia các hoạt động; kiểm soát thời gian và mức độ sử dụng phù hợp với độ tuổi, bảo đảm an toàn, gắn với trải nghiệm thực và không thay thế sự tham gia vui chơi, vận động, giao tiếp, tương tác trực tiếp của trẻ. |
> | **4.4** | **Xây dựng môi trường số an toàn, lành mạnh, có trách nhiệm và phù hợp với trẻ** | **4.4.1.** Xây dựng, rà soát và cập nhật các quy định, quy tắc bảo đảm an toàn trên môi trường số, trong đó xác định yêu cầu về quản lý dữ liệu, bảo vệ trẻ em, giao tiếp, ứng xử, phòng ngừa và xử lý các nguy cơ, rủi ro phát sinh, phù hợp với sự thay đổi của công nghệ và thực tiễn. |
> | | | **4.4.2.** Tổ chức thực hiện thống nhất các quy định, quy tắc bảo đảm an toàn trên môi trường số với sự tham gia của cán bộ quản lý, giáo viên, nhân sự hỗ trợ giáo dục, trẻ em, gia đình và các bên liên quan; phối hợp phát hiện, phòng ngừa và xử lý các nguy cơ, tình huống không an toàn liên quan đến trẻ. |
>
> ## NHÓM 5. HỢP TÁC VÀ HỘI NHẬP QUỐC TẾ
>
> | Mã | Tên tiêu chí | Chỉ báo |
> |---|---|---|
> | **5.1** | **Mở rộng kết nối, học tập và chia sẻ chuyên môn thông qua các mạng lưới, cộng đồng nghề nghiệp trong nước và quốc tế phù hợp với nhu cầu và điều kiện của cơ sở** | **5.1.1.** Tìm kiếm, lựa chọn các mạng lưới, diễn đàn, cộng đồng học tập và kênh kết nối chuyên môn phù hợp với nhu cầu phát triển, điều kiện và khả năng tham gia của cơ sở, bảo đảm thiết thực và đúng quy định. |
> | | | **5.1.2.** Tham gia, kết nối, trao đổi và chia sẻ chuyên môn trong các mạng lưới, diễn đàn, cộng đồng học tập bằng hình thức phù hợp, tạo cơ hội cập nhật kiến thức, kinh nghiệm và xu hướng phát triển giáo dục mầm non. |
> | | | **5.1.3.** Chia sẻ, lan tỏa kiến thức, kinh nghiệm và cách làm tiếp cận được từ các mạng lưới, cộng đồng chuyên môn, góp phần mở rộng cơ hội học tập, trao đổi và phát triển chuyên môn của cơ sở, đồng thời phát triển ngoại ngữ. |
> | **5.2** | **Tăng cường tiếp cận và vận dụng có chọn lọc các tri thức, học liệu, kinh nghiệm giáo dục phù hợp với thực tiễn giáo dục mầm non Việt Nam** | **5.2.1.** Tìm kiếm, cập nhật các nguồn tri thức, tài liệu, học liệu, mô hình và kinh nghiệm giáo dục trong nước và quốc tế từ các nguồn phù hợp, tin cậy, theo quy định. |
> | | | **5.2.2.** Lựa chọn và vận dụng các tri thức, học liệu, mô hình và kinh nghiệm giáo dục bảo đảm tính khoa học, phù hợp với mục tiêu Chương trình giáo dục mầm non, đặc điểm của trẻ, điều kiện thực tiễn và giá trị văn hóa Việt Nam. |
> | | | **5.2.3.** Theo dõi, đánh giá hiệu quả vận dụng đối với chất lượng nuôi dưỡng, chăm sóc, giáo dục và sự phát triển của trẻ; điều chỉnh phù hợp với thực tiễn của cơ sở. |
> | **5.3** | **Thúc đẩy hợp tác chuyên môn với chuyên gia, tổ chức giáo dục và các đối tác trong nước và quốc tế nhằm hỗ trợ phát triển và cải tiến chất lượng giáo dục của cơ sở** | **5.3.1.** Xác định nhu cầu hợp tác chuyên môn và lựa chọn chuyên gia, tổ chức giáo dục, đối tác phù hợp với nội dung cần hỗ trợ, định hướng phát triển và điều kiện thực tiễn của cơ sở. |
> | | | **5.3.2.** Tổ chức các hoạt động hợp tác với chuyên gia, tổ chức giáo dục và đối tác bằng hình thức phù hợp để tư vấn, hỗ trợ chuyên môn, chia sẻ kinh nghiệm và cùng giải quyết các vấn đề thực tiễn trong nuôi dưỡng, chăm sóc, giáo dục và quản trị cơ sở. |
> | | | **5.3.3.** Theo dõi, đánh giá kết quả hợp tác và điều chỉnh nội dung, hình thức phối hợp phù hợp, chú trọng hiệu quả đối với cải tiến chất lượng nuôi dưỡng, chăm sóc, giáo dục và sự phát triển của trẻ. |
> | **5.4** | **Tăng cường hội nhập có chọn lọc các giá trị văn hóa phù hợp với thực tiễn, yêu cầu, quy định của giáo dục mầm non Việt Nam và phát huy bản sắc văn hóa dân tộc** | **5.4.1.** Chủ động tìm hiểu, lựa chọn các giá trị văn hóa tích cực của các quốc gia, dân tộc phù hợp với giá trị văn hóa Việt Nam, đặc điểm địa phương và định hướng phát triển của cơ sở. |
> | | | **5.4.2.** Tích hợp và thường xuyên rà soát việc vận dụng các giá trị văn hóa được lựa chọn trong chương trình giáo dục, môi trường giáo dục, văn hóa tổ chức, các mối quan hệ và hoạt động hợp tác của cơ sở, bảo đảm phù hợp với thực tiễn, yêu cầu, quy định của giáo dục mầm non Việt Nam, giữ gìn và phát huy bản sắc văn hóa dân tộc, văn hóa địa phương. |
>
> ---
>
> ## TỔNG HỢP CẤU TRÚC BỘ TIÊU CHÍ
>
> | Nhóm tiêu chí | Số tiêu chí | Số chỉ báo |
> |---|---:|---:|
> | Nhóm 1. Đổi mới chương trình và hoạt động nuôi dưỡng, chăm sóc, giáo dục | 4 | 12 |
> | Nhóm 2. Đổi mới quản trị cơ sở giáo dục mầm non | 4 | 16 |
> | Nhóm 3. Phát triển điều kiện bảo đảm chất lượng và môi trường giáo dục | 5 | 20 |
> | Nhóm 4. Chuyển đổi số, ứng dụng công nghệ thông tin và trí tuệ nhân tạo | 4 | 11 |
> | Nhóm 5. Hợp tác và hội nhập quốc tế | 4 | 11 |
> | **TỔNG CỘNG** | **21** | **70** |
>
> **HƯỚNG DẪN SỬ DỤNG PHỤ LỤC**
>
> 1. Các bộ phận, cá nhân có liên quan nghiên cứu các tiêu chí, chỉ báo thuộc phạm vi nhiệm vụ được phân công; đối chiếu thực trạng để xác định mức độ thực hiện theo hướng dẫn của Bộ Giáo dục và Đào tạo.
> 2. Sử dụng kết quả thực hiện, hồ sơ, thông tin và dữ liệu sẵn có làm căn cứ đánh giá; chú trọng hiệu quả và những chuyển biến thực tế.
> 3. Tổng hợp những nội dung đã thực hiện tốt, những hạn chế, khó khăn, nguyên nhân và đề xuất nội dung cần ưu tiên cải tiến.
> 4. Lồng ghép nội dung cải tiến vào kế hoạch và hoạt động thường xuyên; theo dõi, rà soát và điều chỉnh phù hợp.
> 5. Không sử dụng Bộ tiêu chí để xếp hạng, so sánh giữa các cơ sở giáo dục mầm non; không yêu cầu xây dựng thêm hồ sơ, sổ sách, báo cáo hoặc quy trình hành chính ngoài quy định.
>
> *Kết thúc phụ lục.*

## ✅ Lưu ý trước khi hoàn thiện và ban hành

Bản thảo đã gộp phần kế hoạch và toàn bộ 70 chỉ báo vào cùng một tài liệu. Khi trình bày trong Word, nên cho **Phụ lục bắt đầu ở trang mới**, giữ nguyên ba cột *Mã – Tên tiêu chí – Chỉ báo*, gộp các ô cùng tiêu chí và lặp lại hàng tiêu đề bảng ở mỗi trang để thuận tiện tra cứu.

Về nội dung, sáu tiêu chí ưu tiên trong kế hoạch hiện là **đề xuất**, chưa phải kết quả đánh giá chính thức của Trường Mầm non An Bình. Nhà trường cần đối chiếu kết quả rà soát ban đầu trước khi xác định nhiệm vụ trọng tâm và mức độ cải tiến dự kiến. Phần phụ lục cũng cần được đối chiếu lần cuối với PDF gốc của Bộ trước khi phát hành chính thức.

Văn bản này nên được sử dụng theo hướng **lồng ghép vào hệ thống kế hoạch, hồ sơ hiện có**, đúng tinh thần Công văn 3763/SGDĐT-GDMN, thay vì tạo thêm một quy trình hành chính riêng.

---

USER

xuất file word giúp mình nhé

---

ASSISTANT

Tôi sẽ xuất bản Word với đầy đủ kế hoạch và phụ lục 70 chỉ báo, trình bày theo thể thức văn bản hành chính, có bảng dễ tra cứu và chừa các vị trí cần điền số kế hoạch, ngày ký, chữ ký Hiệu trưởng.

---

ASSISTANT

Tôi đã chuẩn bị đầy đủ nội dung **Kế hoạch triển khai Bộ tiêu chí giai đoạn 2026–2030 của Trường Mầm non An Bình**, kèm phụ lục **5 nhóm, 21 tiêu chí và 70 chỉ báo** ở phản hồi trước.

Tuy nhiên, hiện tại tôi chưa thể tạo và đính kèm trực tiếp tệp Word `.docx` để tải xuống trong phiên này.

Để lưu thành file Word, bạn có thể:

1. Nhấn **Sao chép** tại khối tài liệu ở phản hồi trước.
2. Dán vào Microsoft Word.
3. Định dạng khổ A4, phông Times New Roman, cỡ chữ 13–14; đặt phụ lục bắt đầu từ trang mới.
4. Chọn **Lưu thành → Word Document (.docx)**.

**Lưu ý:** Trước khi ban hành, cần điền số kế hoạch, ngày ký, tên Hiệu trưởng và rà soát lần cuối nội dung phụ lục với bản gốc của Bộ Giáo dục và Đào tạo.

---

USER

xuất file word giúp mìnhdễ in ấn nhé

---

ASSISTANT

Tôi hiểu bạn cần **một file Word (.docx) hoàn chỉnh, dễ in ấn**, gồm Kế hoạch của Trường Mầm non An Bình và Phụ lục đầy đủ 5 nhóm, 21 tiêu chí, 70 chỉ báo.

Hiện tại, tôi chưa thể tạo và đính kèm trực tiếp file `.docx` trong phiên trò chuyện này.

Nội dung hoàn chỉnh đã có ở khối tài liệu phía trên. Để trình bày trong Word đẹp và đúng thể thức, tôi đề xuất:

| Nội dung | Định dạng |
|--------|--------|
| Khổ giấy | A4 |
| Phần kế hoạch | Trang dọc |
| Phần phụ lục | Trang ngang để bảng dễ đọc |
| Phông chữ | Times New Roman |
| Cỡ chữ | 13 |
| Lề trái | 3 cm |
| Lề phải | 2 cm |
| Lề trên, dưới | 2 cm |
| Bảng phụ lục | 3 cột, lặp lại tiêu đề trên mỗi trang |

**Cách nhanh nhất để có file:** Nếu tài khoản của bạn có chế độ ChatGPT Work, hãy chuyển sang Work và yêu cầu xuất toàn bộ kế hoạch cùng phụ lục trong cuộc trò chuyện này thành file Word theo định dạng trên.

Tôi xin lưu ý rằng tài liệu cần giữ nguyên đầy đủ 70 chỉ báo của Bộ Giáo dục và Đào tạo, không rút gọn phần phụ lục khi xuất để in và sử dụng tại trường.

---

