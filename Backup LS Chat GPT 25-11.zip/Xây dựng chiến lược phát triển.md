USER

[**Thông tư 19/2023/TT-BGDĐT**](https://thuvienphapluat.vn/van-ban/Lao-dong-Tien-luong/Thong-tu-19-2023-TT-BGDDT-co-cau-vien-chuc-theo-chuc-danh-nghe-nghiep-giao-duc-mam-non-cong-lap-508175.aspx) , Nghị định 232/2026/NĐ-CP, Thông tư 93/2026/TT-BGDĐT. Với vai trò hiệu trưởng có hơn 20 năm kinh nghiệm bạn giúp tôi Chiến lược phát triển nhà trường, giai đoạn 2026 - 2030 lặp luận logic, chặt chẽ và thuyết phục.

---

ASSISTANT

Tôi sẽ đối chiếu các văn bản pháp lý anh/chị nêu với Quyết định 1705/QĐ-TTg trong tài liệu đính kèm, sau đó xây dựng bản chiến lược theo hướng có thể dùng làm dự thảo chính thức: xác định tầm nhìn, mục tiêu, chỉ tiêu đến năm 2030, giải pháp và lộ trình thực hiện. Tôi sẽ để rõ những thông tin cần điền theo thực trạng của trường, tránh đặt chỉ tiêu thiếu căn cứ.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# CHIẾN LƯỢC PHÁT TRIỂN TRƯỜNG MẦM NON GIAI ĐOẠN 2026–2030

*Định hướng phát triển nhà trường an toàn, chất lượng, hiện đại, lấy trẻ làm trung tâm và phát triển bền vững.*

Tôi đề xuất xây dựng chiến lược theo tư duy quản trị nhà trường, không chỉ xác định những việc cần làm trong 5 năm mà phải làm rõ **nhà trường đang ở đâu, muốn đạt đến vị thế nào vào năm 2030, cần những nguồn lực gì và đánh giá kết quả bằng tiêu chí nào**.

## I. Những định hướng pháp lý cần đưa vào chiến lược

Qua đối chiếu các văn bản, có bốn định hướng quan trọng:

| Văn bản | Ý nghĩa đối với chiến lược nhà trường |
|--------|--------|
| **Quyết định 1705/QĐ-TTg ngày 31/12/2024** | Xác định mục tiêu phát triển giáo dục đến năm 2030, trọng tâm là phổ cập, nâng cao chất lượng chăm sóc, giáo dục, phát triển đội ngũ và cơ sở vật chất. |
| **Thông tư 19/2023/TT-BGDĐT** | Là căn cứ chuyên ngành về vị trí việc làm, cơ cấu viên chức và định mức số lượng người làm việc tại cơ sở giáo dục mầm non công lập. |
| **Nghị định 232/2026/NĐ-CP ngày 26/6/2026** | Quy định về vị trí việc làm viên chức, bản mô tả công việc, khung năng lực và bậc nghề nghiệp; có hiệu lực từ ngày 01/7/2026. |
| **Thông tư 93/2026/TT-BGDĐT ngày 30/10/2026** | Sửa đổi quy định liên quan đến chuẩn nghề nghiệp, bổ nhiệm chức danh và xếp lương nhà giáo, trong đó có giáo viên mầm non. |

Đặc biệt, theo thông tin hướng dẫn công bố ngày 10/11/2026, việc bổ nhiệm và xếp lương theo các quy định sửa đổi tại Thông tư 93 cần hoàn thành trước ngày **31/12/2026**. Đây là nhiệm vụ cần ưu tiên xử lý ngay, không nên để đến các năm sau của chiến lược. [Quyết định 1705/QĐ\-TTg: CHIẾN LƯỢC PHÁT TRIỂN GIÁO DỤC đến năm 2030, tầm nhìn 2045](<https://xaydungchinhsach.chinhphu.vn/quyet-dinh-1705-qd-ttg-chien-luoc-phat-trien-giao-duc-den-nam-2030-tam-nhin-2045-119250102173414127.htm>); [Thông tư số 19/2023/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Hướng dẫn về vị trí việc làm, cơ cấu viên chức theo chức danh nghề nghiệp và định mức số lượng người làm việc trong các cơ sở giáo dục mầm non công lập](<https://chinhphu.vn/?classid=1&docid=208995&pageid=27160&typegroupid=6>); [Nghị định số 232/2026/NĐ\-CP của Chính phủ: Quy định về vị trí việc làm viên chức](<https://vanban.chinhphu.vn/?classid=1&docid=218617&orggroupid=2&pageid=27160>); [Thông tư 93/2026/TT\-BGDĐT sửa đổi quy định chuẩn nghề nghiệp, bổ nhiệm chức danh, xếp lương nhà giáo](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-93-2026-tt-bgddt-sua-quy-dinh-chuan-nghe-nghiep-bo-nhiem-chuc-danh-va-xep-luong-voi-nha-giao-11926110515235074.htm>)

Về chuyên môn, Quyết định 1705/QĐ-TTg xác định mục tiêu quốc gia đến năm 2030: huy động 38% trẻ độ tuổi nhà trẻ, 97% trẻ độ tuổi mẫu giáo đến trường; phấn đấu 99,5% trẻ mầm non đến trường được học 2 buổi/ngày; 100% giáo viên đạt chuẩn trình độ đào tạo và tỷ lệ phòng học kiên cố đạt 100%. Đây là **mục tiêu cấp quốc gia**, nhà trường cần cụ thể hóa thành chỉ tiêu phù hợp với địa bàn, quy mô và điều kiện thực tế. [Quyết định số 1705/QĐ\-TTg của Thủ tướng Chính phủ: Phê duyệt Chiến lược phát triển giáo dục đến năm 2030, tầm nhìn đến năm 2045](<https://vanban.chinhphu.vn/?classid=0&docid=212235&pageid=27160>); [Quyết định 1705/QĐ\-TTg: CHIẾN LƯỢC PHÁT TRIỂN GIÁO DỤC đến năm 2030, tầm nhìn 2045](<https://xaydungchinhsach.chinhphu.vn/quyet-dinh-1705-qd-ttg-chien-luoc-phat-trien-giao-duc-den-nam-2030-tam-nhin-2045-119250102173414127.htm>)

Bản dự thảo dưới đây được thiết kế cho **trường mầm non công lập**, có thể điều chỉnh thành văn bản trình Hội đồng trường và cấp quản lý có thẩm quyền theo quy định hiện hành. Các nội dung trong dấu `[...]` cần bổ sung từ số liệu, hồ sơ thực tế trước khi ban hành.

Một điểm quan trọng nữa là **Nghị định 232/2026/NĐ-CP đặt thời hạn chậm nhất ngày 01/7/2027** để cơ quan có thẩm quyền hoàn thành phê duyệt vị trí việc làm và bố trí viên chức theo quy định chuyển tiếp. Vì vậy, giai đoạn 2026–2027 phải được xem là thời kỳ chuẩn hóa tổ chức và nhân sự, làm nền tảng cho các mục tiêu nâng cao chất lượng từ năm 2028 đến 2030. [Nghị định 232/2026/NĐ\-CP vị trí việc làm viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-232-2026-ND-CP-vi-tri-viec-lam-vien-chuc-712592.aspx>); [Nghị định số 232/2026/NĐ\-CP của Chính phủ: Quy định về vị trí việc làm viên chức](<https://vanban.chinhphu.vn/?classid=1&docid=218617&orggroupid=2&pageid=27160>)

Tôi cũng bổ sung những căn cứ trực tiếp có liên quan: Thông tư 28/2026/TT-BGDĐT về chuẩn nghề nghiệp giáo viên mầm non, Thông tư 31/2026/TT-BGDĐT về bổ nhiệm chức danh và xếp lương nhà giáo, Điều lệ trường mầm non đã được sửa đổi năm 2026, cùng Nghị quyết 218/2025/QH15 và Nghị định 277/2025/NĐ-CP về phổ cập giáo dục mầm non cho trẻ từ 3 đến 5 tuổi. [Thông tư số 28/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Quy định Chuẩn nghề nghiệp giáo viên mầm non](<https://vanban.chinhphu.vn/?docid=217730&pageid=27160>); [Thông tư số 31/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Quy định mã số, bổ nhiệm chức danh và xếp lương đối với nhà giáo trong cơ sở giáo dục công lập](<https://vanban.chinhphu.vn/?classid=0&docid=217840&pageid=27160>); [Văn bản hợp nhất số 09/2026/VBHN\-TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Ban hành Điều lệ Trường mầm non](<https://vanban.chinhphu.vn/?classid=0&docid=219018&pageid=27160>); [Nghị quyết số 218/2025/QH15 của Quốc hội: Về phổ cập giáo dục mầm non cho trẻ em từ 3 đến 5 tuổi](<https://chinhphu.vn/?classid=1&docid=214400&pageid=27160>); [Nghị định số 277/2025/NĐ\-CP của Chính phủ: Quy định chi tiết thi hành Nghị quyết số 218/2025/QH15 ngày 26 tháng 6 năm 2025 của Quốc hội về phổ cập giáo dục mầm non cho trẻ em từ 3 đến 5 tuổi](<https://vanban.chinhphu.vn/?classid=1&docid=215677&pageid=27160&typegroupid=4>)

## II. Dự thảo Chiến lược phát triển nhà trường giai đoạn 2026–2030

Bố cục dưới đây bám sát định hướng của Quyết định 1705/QĐ-TTg, đặc biệt là mục tiêu giáo dục mầm non tại trang 3; các nhiệm vụ đổi mới quản trị, phương pháp giáo dục, phát triển đội ngũ và chuyển đổi số tại trang 6–14 của tài liệu đính kèm.

> **writing · document**
>
> **ỦY BAN NHÂN DÂN [ĐƠN VỊ QUẢN LÝ]**  
> **TRƯỜNG MẦM NON [TÊN TRƯỜNG]**
>
> Số: …/CLPT-MN…
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *[Địa danh], ngày … tháng … năm 2026*
>
> # CHIẾN LƯỢC PHÁT TRIỂN NHÀ TRƯỜNG
> ## GIAI ĐOẠN 2026–2030
>
> ### PHẦN THỨ NHẤT. CĂN CỨ VÀ CƠ SỞ XÂY DỰNG CHIẾN LƯỢC
>
> **I. Căn cứ pháp lý**
>
> Căn cứ Luật Giáo dục số 43/2019/QH14 và các văn bản sửa đổi, bổ sung hiện hành;
>
> Căn cứ Luật Nhà giáo số 73/2025/QH15;
>
> Căn cứ Luật Viên chức số 129/2025/QH15;
>
> Căn cứ Quyết định số 1705/QĐ-TTg ngày 31/12/2024 của Thủ tướng Chính phủ phê duyệt Chiến lược phát triển giáo dục đến năm 2030, tầm nhìn đến năm 2045;
>
> Căn cứ Nghị quyết số 218/2025/QH15 ngày 26/6/2025 của Quốc hội về phổ cập giáo dục mầm non cho trẻ em từ 3 đến 5 tuổi và Nghị định số 277/2025/NĐ-CP ngày 20/10/2025 của Chính phủ;
>
> Căn cứ Thông tư số 19/2023/TT-BGDĐT ngày 30/10/2023 của Bộ Giáo dục và Đào tạo hướng dẫn về vị trí việc làm, cơ cấu viên chức theo chức danh nghề nghiệp và định mức số lượng người làm việc trong các cơ sở giáo dục mầm non công lập;
>
> Căn cứ Nghị định số 232/2026/NĐ-CP ngày 26/6/2026 của Chính phủ quy định về vị trí việc làm viên chức;
>
> Căn cứ Thông tư số 28/2026/TT-BGDĐT ngày 09/4/2026 của Bộ Giáo dục và Đào tạo quy định Chuẩn nghề nghiệp giáo viên mầm non;
>
> Căn cứ Thông tư số 31/2026/TT-BGDĐT ngày 14/4/2026 và Thông tư số 93/2026/TT-BGDĐT ngày 30/10/2026 của Bộ Giáo dục và Đào tạo về các quy định liên quan đến bổ nhiệm chức danh, chuẩn nghề nghiệp và xếp lương nhà giáo;
>
> Căn cứ Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT, được sửa đổi, bổ sung bởi Thông tư số 51/2026/TT-BGDĐT;
>
> Căn cứ Chương trình Giáo dục mầm non hiện hành; các quy định về kiểm định chất lượng giáo dục, trường đạt chuẩn quốc gia và bảo đảm an toàn trường học;
>
> Căn cứ kế hoạch phát triển kinh tế – xã hội, định hướng phát triển giáo dục của địa phương và các văn bản chỉ đạo của cấp có thẩm quyền;
>
> Căn cứ kết quả thực hiện nhiệm vụ của Trường Mầm non [Tên trường] giai đoạn trước và thực trạng nhà trường năm 2026.
>
> **II. Sự cần thiết xây dựng chiến lược**
>
> Giai đoạn 2026–2030 là thời kỳ có ý nghĩa quan trọng đối với sự phát triển của giáo dục mầm non. Những yêu cầu mới về phổ cập giáo dục, bảo đảm chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ, chuẩn nghề nghiệp nhà giáo, quản lý viên chức theo vị trí việc làm, chuyển đổi số và trách nhiệm giải trình đặt ra yêu cầu đổi mới toàn diện hoạt động quản trị nhà trường.
>
> Trong bối cảnh đó, phát triển nhà trường không chỉ được đánh giá qua sự gia tăng quy mô tuyển sinh, số lượng phòng học hoặc kết quả thi đua mà phải được thể hiện bằng những chuyển biến thực chất về chất lượng giáo dục, sự an toàn và phát triển của trẻ, năng lực nghề nghiệp của đội ngũ, hiệu quả sử dụng nguồn lực và mức độ tin tưởng của cha mẹ trẻ.
>
> Việc xây dựng Chiến lược phát triển nhà trường giai đoạn 2026–2030 nhằm xác lập định hướng phát triển dài hạn, thống nhất nhận thức và hành động trong toàn trường; đồng thời làm căn cứ xây dựng kế hoạch năm học, kế hoạch phát triển đội ngũ, đầu tư cơ sở vật chất và tổ chức kiểm tra, đánh giá kết quả thực hiện.
>
> Chiến lược phải khắc phục được tình trạng lập kế hoạch theo từng năm học thiếu tính kế thừa; chuyển từ quản lý chủ yếu dựa vào hoạt động sang quản trị dựa trên mục tiêu, kết quả và minh chứng; bảo đảm mọi quyết định phát triển đều xuất phát từ nhu cầu thực tế của trẻ và điều kiện thực hiện của nhà trường.
>
> **III. Quan điểm phát triển**
>
> 1. **Lấy trẻ em làm trung tâm, an toàn là điều kiện tiên quyết.** Mọi chủ trương, kế hoạch và hoạt động của nhà trường phải hướng đến bảo vệ quyền, lợi ích hợp pháp của trẻ; tôn trọng sự khác biệt và tạo cơ hội phát triển toàn diện cho từng trẻ.
>
> 2. **Phát triển chất lượng gắn với bảo đảm điều kiện thực hiện.** Không mở rộng quy mô vượt quá khả năng đáp ứng về đội ngũ, cơ sở vật chất, dinh dưỡng và các điều kiện bảo đảm an toàn.
>
> 3. **Phát triển đội ngũ là giải pháp có tính quyết định.** Đổi mới quản trị nhân sự theo vị trí việc làm, khung năng lực và yêu cầu nhiệm vụ; kết hợp thực hiện đúng chế độ, chính sách với bồi dưỡng, động viên, khuyến khích sáng tạo.
>
> 4. **Quản trị dân chủ, công khai, có trách nhiệm giải trình.** Mọi hoạt động phải bảo đảm đúng thẩm quyền, rõ trách nhiệm, sử dụng hiệu quả nguồn lực và có cơ chế kiểm tra, giám sát.
>
> 5. **Đổi mới có chọn lọc, phù hợp thực tiễn.** Ứng dụng công nghệ và phương pháp giáo dục tiên tiến trên cơ sở khoa học, phù hợp lứa tuổi, điều kiện địa phương và khả năng tổ chức của nhà trường; không chạy theo hình thức hoặc thành tích.
>
> ### PHẦN THỨ HAI. PHÂN TÍCH BỐI CẢNH VÀ THỰC TRẠNG NHÀ TRƯỜNG
>
> **I. Đặc điểm tình hình**
>
> Trường Mầm non [Tên trường] là cơ sở giáo dục mầm non công lập thuộc [cơ quan quản lý trực tiếp], thực hiện nhiệm vụ nuôi dưỡng, chăm sóc, giáo dục trẻ theo Chương trình Giáo dục mầm non và quy định của pháp luật.
>
> Nhà trường có nhiệm vụ bảo đảm chất lượng giáo dục mầm non, tham gia thực hiện mục tiêu phổ cập giáo dục trên địa bàn, đáp ứng nhu cầu gửi trẻ của nhân dân và thực hiện các nhiệm vụ giáo dục do cấp có thẩm quyền giao.
>
> **II. Thực trạng tại thời điểm xây dựng chiến lược**
>
> Nhà trường tổ chức rà soát và xác lập số liệu gốc năm 2026 theo các nhóm sau:
>
> | Nội dung | Số liệu thực trạng năm 2026 |
> |---|---|
> | Quy mô | […] điểm trường; […] nhóm/lớp; […] trẻ |
> | Huy động trẻ | Nhà trẻ: […]%; mẫu giáo: […]%; trẻ 5 tuổi: […]% |
> | Đội ngũ | […] cán bộ quản lý; […] giáo viên; […] nhân viên |
> | Nhân sự theo vị trí việc làm | Số lượng cần theo định mức […]; hiện có […]; còn thiếu/thừa […] |
> | Trình độ đào tạo | Giáo viên đạt chuẩn […]%; trên chuẩn […]% |
> | Cơ sở vật chất | […] phòng học; […] phòng kiên cố; […] phòng cần cải tạo |
> | Chất lượng chăm sóc, giáo dục | Tỷ lệ chuyên cần […]; trẻ suy dinh dưỡng […]; kết quả đánh giá sự phát triển […] |
> | Bảo đảm chất lượng | Kết quả kiểm định […]; chuẩn quốc gia […]; thời hạn công nhận […] |
> | Chuyển đổi số | Phần mềm đang sử dụng […]; tỷ lệ hồ sơ được số hóa […] |
> | Nguồn lực tài chính | Kinh phí được giao […]; nhu cầu đầu tư bổ sung […] |
>
> Số liệu sử dụng phải được đối chiếu với hồ sơ trẻ, hồ sơ viên chức, cơ sở dữ liệu phổ cập, kiểm kê tài sản, báo cáo tài chính và kết quả đánh giá chất lượng của nhà trường.
>
> **III. Phân tích điểm mạnh, hạn chế, cơ hội và thách thức**
>
> *1. Điểm mạnh*
>
> Nhà trường xác định những lợi thế cần tiếp tục phát huy trên cơ sở minh chứng thực tế, tập trung vào: sự quan tâm của cấp ủy, chính quyền địa phương; sự ổn định và tinh thần trách nhiệm của đội ngũ; kết quả chăm sóc, giáo dục đã đạt được; điều kiện cơ sở vật chất và sự phối hợp của cha mẹ trẻ.
>
> Các điểm mạnh nổi bật được xác định sau khảo sát: [ghi từ 3 đến 5 điểm mạnh có minh chứng].
>
> *2. Hạn chế và nguyên nhân*
>
> Tập trung đánh giá các nội dung có khả năng ảnh hưởng trực tiếp đến mục tiêu phát triển:
>
> - Mức độ đáp ứng của đội ngũ so với định mức, cơ cấu và yêu cầu năng lực của từng vị trí việc làm.
> - Chất lượng tổ chức hoạt động giáo dục giữa các nhóm, lớp; năng lực quan sát, đánh giá và hỗ trợ sự phát triển của trẻ.
> - Mức độ đáp ứng của cơ sở vật chất, thiết bị, đồ dùng, đồ chơi; đặc biệt là các hạng mục liên quan đến an toàn và chăm sóc trẻ.
> - Hiệu quả quản lý dữ liệu, kiểm tra nội bộ, sử dụng nguồn lực và phối hợp với gia đình.
>
> Đối với mỗi hạn chế, cần phân tích rõ nguyên nhân chủ quan, khách quan, mức độ tác động và khả năng khắc phục. Không quy toàn bộ khó khăn về thiếu kinh phí hoặc thiếu biên chế khi chưa đánh giá hiệu quả tổ chức, phân công và sử dụng nguồn lực hiện có.
>
> *3. Cơ hội*
>
> Chủ trương ưu tiên phát triển giáo dục mầm non, thực hiện phổ cập giáo dục mầm non cho trẻ từ 3 đến 5 tuổi; các chính sách phát triển đội ngũ, đổi mới quản trị và chuyển đổi số tạo cơ sở để nhà trường tham mưu đầu tư, chuẩn hóa tổ chức và nâng cao chất lượng hoạt động.
>
> *4. Thách thức*
>
> Sự biến động quy mô trẻ theo địa bàn, yêu cầu ngày càng cao của cha mẹ trẻ, áp lực bảo đảm đủ nhân lực, nhu cầu đầu tư cơ sở vật chất, nguy cơ mất an toàn, dịch bệnh, thiên tai và sự thay đổi của hệ thống chính sách đòi hỏi nhà trường phải chủ động thích ứng.
>
> **IV. Xác định những vấn đề chiến lược**
>
> Từ phân tích thực trạng, nhà trường tập trung giải quyết năm vấn đề cốt lõi:
>
> 1. Bảo đảm mọi trẻ em được tiếp cận giáo dục mầm non công bằng, phù hợp khả năng đáp ứng của nhà trường.
> 2. Nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục và bảo vệ trẻ bằng những kết quả có thể kiểm chứng.
> 3. Chuẩn hóa tổ chức và đội ngũ theo vị trí việc làm, năng lực thực hiện nhiệm vụ và yêu cầu pháp luật mới.
> 4. Tập trung nguồn lực để hoàn thiện những điều kiện thiết yếu, tránh đầu tư dàn trải.
> 5. Hình thành cơ chế quản trị hiện đại, minh bạch, dựa trên dữ liệu và trách nhiệm giải trình.
>
> Đây là những vấn đề phải được ưu tiên xuyên suốt giai đoạn 2026–2030; đồng thời là căn cứ để lựa chọn nhiệm vụ trọng tâm từng năm.
>
> ### PHẦN THỨ BA. ĐỊNH HƯỚNG CHIẾN LƯỢC ĐẾN NĂM 2030
>
> **I. Tầm nhìn**
>
> Đến năm 2030, Trường Mầm non [Tên trường] phát triển thành cơ sở giáo dục mầm non công lập an toàn, thân thiện, có chất lượng chăm sóc, nuôi dưỡng và giáo dục ổn định, ngày càng được nâng cao; có đội ngũ nhà giáo vững vàng về chuyên môn, trách nhiệm với nghề nghiệp, chủ động đổi mới; có môi trường giáo dục xanh, sạch, an toàn, phù hợp với sự phát triển của trẻ và đáp ứng sự tin tưởng của cha mẹ trẻ, cộng đồng.
>
> **II. Sứ mệnh**
>
> Tạo dựng môi trường giáo dục an toàn, yêu thương, tôn trọng sự khác biệt; bảo đảm mọi trẻ được chăm sóc, nuôi dưỡng, vui chơi, trải nghiệm và phát triển theo khả năng, nhu cầu của bản thân; phối hợp chặt chẽ với gia đình và cộng đồng trong việc đặt nền móng cho sự hình thành nhân cách, phát triển những năng lực ban đầu và chuẩn bị tâm thế phù hợp cho trẻ bước vào giai đoạn học tập tiếp theo.
>
> **III. Giá trị cốt lõi**
>
> **An toàn – Yêu thương – Tôn trọng – Trách nhiệm – Hợp tác – Đổi mới.**
>
> Các giá trị này được cụ thể hóa trong quy tắc ứng xử, quy trình chăm sóc trẻ, phân công nhiệm vụ, đánh giá đội ngũ và văn hóa giao tiếp với cha mẹ trẻ.
>
> **IV. Mục tiêu tổng quát**
>
> Xây dựng và phát triển Trường Mầm non [Tên trường] theo hướng chuẩn hóa, hiện đại hóa phù hợp điều kiện thực tế; bảo đảm công bằng trong tiếp cận giáo dục; nâng cao chất lượng nuôi dưỡng, chăm sóc và giáo dục toàn diện; xây dựng đội ngũ đủ về số lượng theo định mức được áp dụng, hợp lý về cơ cấu, đáp ứng yêu cầu năng lực nghề nghiệp; từng bước hoàn thiện cơ sở vật chất và đẩy mạnh chuyển đổi số.
>
> Phấn đấu đến năm 2030, nhà trường có sự chuyển biến rõ nét về chất lượng giáo dục và năng lực quản trị; hoạt động ổn định, hiệu quả, minh bạch, đáp ứng yêu cầu phổ cập giáo dục mầm non và định hướng phát triển giáo dục của địa phương.
>
> **V. Các mục tiêu cụ thể và chỉ tiêu phấn đấu đến năm 2030**
>
> *Các chỉ tiêu sau là khung đề xuất. Chỉ tiêu cuối cùng phải được xác định trên cơ sở số liệu năm 2026, chỉ tiêu cấp trên giao và khả năng bảo đảm nguồn lực của nhà trường.*
>
> | Lĩnh vực | Chỉ tiêu phấn đấu đến năm 2030 |
> |---|---|
> | **1. Huy động trẻ** | Đạt hoặc vượt chỉ tiêu huy động trẻ được giao; góp phần thực hiện mục tiêu phổ cập trẻ mẫu giáo 3–5 tuổi của địa phương. |
> | **2. Trẻ 5 tuổi** | Bảo đảm 100% trẻ 5 tuổi thuộc phạm vi quản lý được điều tra, cập nhật thông tin và có giải pháp huy động phù hợp. |
> | **3. Học 2 buổi/ngày** | Phấn đấu 100% trẻ đang học tại trường được tổ chức học 2 buổi/ngày khi đáp ứng đủ điều kiện. |
> | **4. An toàn trường học** | 100% nhóm, lớp được kiểm tra điều kiện an toàn định kỳ; các nguy cơ nghiêm trọng được xử lý kịp thời. |
> | **5. Chăm sóc sức khỏe** | 100% trẻ được theo dõi sức khỏe, tình trạng dinh dưỡng và có hồ sơ theo quy định. |
> | **6. Dinh dưỡng** | Giảm tỷ lệ suy dinh dưỡng so với năm 2026; mức giảm cụ thể được xác định theo từng nhóm tuổi và tình hình thực tế. |
> | **7. Chất lượng giáo dục** | 100% nhóm, lớp thực hiện chương trình giáo dục mầm non; trẻ được quan sát, đánh giá và hỗ trợ phát triển theo quy định. |
> | **8. Giáo dục hòa nhập** | 100% trẻ có nhu cầu hỗ trợ đặc biệt được xem xét, xây dựng biện pháp hỗ trợ phù hợp và phối hợp với gia đình. |
> | **9. Trình độ giáo viên** | 100% giáo viên đáp ứng chuẩn trình độ đào tạo theo quy định hiện hành. |
> | **10. Chuẩn nghề nghiệp** | 100% giáo viên được đánh giá theo quy định và xây dựng kế hoạch phát triển năng lực nghề nghiệp. |
> | **11. Vị trí việc làm** | 100% nhân sự được quản lý, bố trí theo danh mục vị trí việc làm và quyết định của cấp có thẩm quyền sau khi được phê duyệt. |
> | **12. Bồi dưỡng đội ngũ** | 100% cán bộ quản lý, giáo viên, nhân viên được bồi dưỡng các nội dung bắt buộc, phù hợp nhiệm vụ. |
> | **13. Cơ sở vật chất** | 100% phòng học đáp ứng điều kiện an toàn; phấn đấu hoàn thiện hệ thống phòng học kiên cố theo quy hoạch, nguồn vốn được bố trí. |
> | **14. Chuyển đổi số** | 100% dữ liệu quản lý thiết yếu được cập nhật trên hệ thống theo quy định; giảm hồ sơ, thao tác trùng lặp. |
> | **15. Sự hài lòng** | Phấn đấu từ 95% cha mẹ trẻ tham gia khảo sát hài lòng về chất lượng phục vụ, chăm sóc, giáo dục. |
> | **16. Bảo đảm chất lượng** | Duy trì, cải tiến kết quả kiểm định; phấn đấu đạt hoặc giữ vững chuẩn quốc gia theo điều kiện và kế hoạch được phê duyệt. |
>
> Nhà trường tổ chức lượng hóa các chỉ tiêu hằng năm; không lấy kết quả thi đua hoặc tỷ lệ hồ sơ hoàn thành làm căn cứ duy nhất để đánh giá chất lượng.
>
> ### PHẦN THỨ TƯ. NHIỆM VỤ VÀ GIẢI PHÁP CHIẾN LƯỢC
>
> **I. Phát triển quy mô hợp lý, thực hiện hiệu quả công tác phổ cập giáo dục mầm non**
>
> **1. Mục tiêu**
>
> Bảo đảm cơ hội tiếp cận giáo dục mầm non cho trẻ trên địa bàn; duy trì và nâng cao chất lượng phổ cập trẻ 5 tuổi, tham gia thực hiện phổ cập giáo dục mầm non cho trẻ từ 3 đến 5 tuổi; phát triển quy mô phù hợp với khả năng đáp ứng của nhà trường.
>
> **2. Giải pháp**
>
> Phối hợp với chính quyền địa phương và các đơn vị liên quan rà soát, cập nhật số trẻ trong độ tuổi; phân tích biến động dân số, nhu cầu gửi trẻ, điều kiện đi lại và đặc điểm của từng khu vực tuyển sinh.
>
> Xây dựng phương án huy động trẻ theo từng độ tuổi, chú trọng trẻ thuộc gia đình khó khăn, trẻ khuyết tật, trẻ có hoàn cảnh đặc biệt và những trẻ có nguy cơ không được đến trường.
>
> Dự báo quy mô nhóm, lớp hằng năm trên cơ sở đồng thời xem xét nhu cầu của người dân, khả năng bố trí giáo viên, diện tích và điều kiện phòng học, cơ sở vật chất và các tiêu chuẩn an toàn.
>
> Tham mưu cấp có thẩm quyền bổ sung phòng học, nhân sự và các điều kiện cần thiết nếu nhu cầu huy động tăng nhưng nhà trường chưa đủ năng lực tiếp nhận.
>
> Phối hợp thực hiện đầy đủ chính sách hỗ trợ trẻ đúng đối tượng, công khai các điều kiện được hưởng chính sách, bảo đảm công bằng và không phân biệt đối xử.
>
> **3. Kết quả kỳ vọng**
>
> Quy mô trường, lớp phát triển hợp lý; tỷ lệ huy động trẻ đạt chỉ tiêu được giao; hạn chế tình trạng trẻ thuộc diện phổ cập chưa được tiếp cận giáo dục; không phát sinh tăng quy mô vượt khả năng đáp ứng điều kiện chăm sóc và an toàn.
>
> **II. Nâng cao chất lượng chăm sóc, nuôi dưỡng và bảo đảm an toàn cho trẻ**
>
> **1. Mục tiêu**
>
> Xây dựng môi trường chăm sóc an toàn, khoa học, phù hợp đặc điểm lứa tuổi; bảo vệ sức khỏe thể chất và tinh thần của trẻ, kiểm soát các nguy cơ mất an toàn trong mọi hoạt động.
>
> **2. Giải pháp**
>
> Rà soát, hoàn thiện và thực hiện nghiêm các quy trình đón, trả trẻ, tổ chức ăn, ngủ, vệ sinh, vui chơi, hoạt động ngoài trời; phòng chống tai nạn thương tích; phòng chống bạo lực, xâm hại trẻ em; phòng chống dịch bệnh và xử lý tình huống khẩn cấp.
>
> Tổ chức kiểm tra an toàn theo từng khu vực và từng thời điểm; lập sổ hoặc hệ thống theo dõi nguy cơ, biện pháp khắc phục, thời hạn hoàn thành và người chịu trách nhiệm.
>
> Đổi mới công tác quản lý bán trú, bảo đảm kiểm soát nguồn cung cấp thực phẩm, quy trình giao nhận, chế biến, bảo quản và lưu mẫu theo quy định; xây dựng thực đơn phù hợp độ tuổi, cân đối dinh dưỡng và khả năng cung ứng.
>
> Theo dõi sức khỏe và tình trạng dinh dưỡng của trẻ, phân tích nguyên nhân suy dinh dưỡng, thừa cân, béo phì; xây dựng biện pháp phối hợp với cha mẹ trẻ phù hợp từng trường hợp.
>
> Bồi dưỡng giáo viên, nhân viên kỹ năng phòng ngừa rủi ro, sơ cấp cứu ban đầu, phát hiện dấu hiệu bất thường về sức khỏe, nhận diện và ứng phó các nguy cơ mất an toàn.
>
> **3. Kết quả kỳ vọng**
>
> Các quy trình chăm sóc, nuôi dưỡng được thực hiện thống nhất và có kiểm soát; nguy cơ mất an toàn được phát hiện sớm; chất lượng dinh dưỡng, sức khỏe và sự an tâm của cha mẹ trẻ được cải thiện.
>
> **III. Đổi mới hoạt động giáo dục, phát triển toàn diện trẻ và nâng cao chất lượng chuyên môn**
>
> **1. Mục tiêu**
>
> Chuyển trọng tâm từ việc tổ chức đủ hoạt động theo kế hoạch sang nâng cao chất lượng trải nghiệm, sự tham gia và mức độ phát triển của từng trẻ.
>
> **2. Giải pháp**
>
> Thực hiện đầy đủ Chương trình Giáo dục mầm non hiện hành; chủ động cập nhật, triển khai chương trình và hướng dẫn mới theo lộ trình của cơ quan có thẩm quyền.
>
> Xây dựng kế hoạch giáo dục phù hợp đặc điểm từng độ tuổi, điều kiện lớp học và nhu cầu thực tế của trẻ; tăng cường hoạt động vui chơi, trải nghiệm, khám phá, vận động, giao tiếp, nghệ thuật và phát triển kỹ năng tự phục vụ.
>
> Tổ chức môi trường giáo dục mở, thân thiện, có khả năng kích thích trẻ chủ động lựa chọn, khám phá và hợp tác; sử dụng hiệu quả vật liệu an toàn, đồ dùng và đồ chơi phù hợp lứa tuổi.
>
> Đổi mới sinh hoạt chuyên môn theo hướng nghiên cứu hoạt động giáo dục và sự phát triển của trẻ; khuyến khích giáo viên cùng quan sát, phân tích tình huống, điều chỉnh phương pháp và chia sẻ kinh nghiệm.
>
> Nâng cao năng lực quan sát, đánh giá sự phát triển của trẻ; sử dụng kết quả đánh giá để điều chỉnh hoạt động giáo dục, không tạo áp lực học trước chương trình tiểu học.
>
> Quan tâm giáo dục hòa nhập, xây dựng biện pháp hỗ trợ cá nhân khi cần thiết, bảo đảm sự phối hợp giữa giáo viên, cha mẹ trẻ và các lực lượng hỗ trợ phù hợp.
>
> **3. Kết quả kỳ vọng**
>
> Hoạt động giáo dục có chất lượng thực chất; trẻ tích cực, tự tin, hứng thú tham gia; giáo viên chủ động điều chỉnh phương pháp; các nhóm, lớp từng bước giảm chênh lệch về chất lượng tổ chức hoạt động.
>
> **IV. Phát triển đội ngũ và đổi mới quản trị nhân sự theo vị trí việc làm**
>
> **1. Mục tiêu**
>
> Xây dựng đội ngũ đủ về số lượng theo định mức được áp dụng và chỉ tiêu được giao; phù hợp về cơ cấu, năng lực và nhiệm vụ; bảo đảm quyền lợi hợp pháp của viên chức, tạo động lực phát triển nghề nghiệp lâu dài.
>
> **2. Giải pháp trọng tâm**
>
> *a) Rà soát và hoàn thiện phương án vị trí việc làm*
>
> Căn cứ Thông tư 19/2023/TT-BGDĐT và Nghị định 232/2026/NĐ-CP, rà soát danh mục vị trí việc làm, chức năng, nhiệm vụ, khối lượng công việc, số lượng nhân sự cần bố trí và khả năng đáp ứng của đội ngũ hiện có.
>
> Xây dựng, cập nhật bản mô tả công việc và khung năng lực theo quy định; xác định rõ nhiệm vụ chính, sản phẩm đầu ra, yêu cầu năng lực và trách nhiệm của từng vị trí.
>
> Lập phương án bố trí, sử dụng và đề xuất bổ sung nhân sự theo định mức, nhu cầu thực tế, khả năng ngân sách và thẩm quyền quản lý. Không tự đặt thêm vị trí việc làm ngoài danh mục được phép.
>
> Hoàn thiện hồ sơ thuộc trách nhiệm nhà trường, trình cấp có thẩm quyền và phối hợp thực hiện quy định chuyển tiếp về vị trí việc làm trong thời hạn pháp luật quy định.
>
> *b) Thực hiện đúng chế độ bổ nhiệm chức danh và xếp lương nhà giáo*
>
> Rà soát hồ sơ viên chức theo từng trường hợp, đối chiếu chức danh đã được bổ nhiệm, quá trình đào tạo, thời gian công tác và các quyết định liên quan.
>
> Tổ chức thực hiện hoặc trình cấp có thẩm quyền xem xét việc bổ nhiệm, chuyển xếp, xếp lại lương theo Thông tư 31/2026/TT-BGDĐT và Thông tư 93/2026/TT-BGDĐT.
>
> Phân biệt rõ việc chuyển xếp chức danh tương ứng, việc xét thăng hạng và việc chuyển sang bậc nghề nghiệp theo vị trí việc làm; không đồng nhất các quy trình hoặc áp dụng giới hạn cơ cấu hạng không đúng đối tượng.
>
> Chủ động kiểm tra tiến độ thực hiện, kịp thời phát hiện trường hợp có nguy cơ ảnh hưởng quyền và lợi ích hợp pháp của giáo viên; phối hợp cơ quan có thẩm quyền giải quyết đúng quy định.
>
> *c) Phát triển năng lực nghề nghiệp*
>
> Xây dựng kế hoạch bồi dưỡng đội ngũ theo kết quả đánh giá chuẩn nghề nghiệp, yêu cầu vị trí việc làm và những hạn chế phát hiện qua kiểm tra chuyên môn.
>
> Tập trung bồi dưỡng các năng lực thiết yếu: chăm sóc và bảo vệ trẻ; thiết kế môi trường giáo dục; tổ chức hoạt động lấy trẻ làm trung tâm; quan sát và đánh giá trẻ; giáo dục hòa nhập; ứng dụng công nghệ số; giao tiếp, hợp tác với gia đình.
>
> Tổ chức bồi dưỡng tại trường, sinh hoạt chuyên môn theo nghiên cứu bài học, hướng dẫn đồng nghiệp, tự học có kiểm chứng kết quả và chia sẻ sản phẩm chuyên môn.
>
> Khuyến khích giáo viên có năng lực hỗ trợ đồng nghiệp; tạo cơ hội phát triển công bằng, phù hợp năng lực và điều kiện thực tế, không gây áp lực thành tích.
>
> *d) Đổi mới phương pháp đánh giá và sử dụng đội ngũ*
>
> Thực hiện phân công công việc trên cơ sở năng lực, yêu cầu vị trí và đặc điểm hoạt động của nhà trường.
>
> Đánh giá kết quả thực hiện nhiệm vụ dựa trên chất lượng công việc, tinh thần trách nhiệm, mức độ tiến bộ và minh chứng thực tế; tránh đánh giá hình thức dựa trên số lượng hồ sơ hoặc số tiết dự giờ đơn thuần.
>
> Kết hợp kiểm tra, hỗ trợ, hướng dẫn và động viên; xây dựng môi trường làm việc dân chủ, hợp tác và tôn trọng nhà giáo.
>
> **3. Kết quả kỳ vọng**
>
> Hình thành cơ chế quản trị nhân sự rõ chức năng, đúng thẩm quyền, phù hợp năng lực; giảm chồng chéo nhiệm vụ; nâng cao chất lượng đội ngũ và bảo đảm việc thực hiện chế độ, chính sách theo quy định.
>
> **V. Phát triển cơ sở vật chất, thiết bị và huy động nguồn lực hợp pháp**
>
> **1. Mục tiêu**
>
> Từng bước xây dựng môi trường giáo dục an toàn, xanh, sạch, phù hợp sự phát triển của trẻ; ưu tiên nguồn lực cho các điều kiện thiết yếu và những hạng mục có tác động trực tiếp đến chất lượng chăm sóc, giáo dục.
>
> **2. Giải pháp**
>
> Rà soát tổng thể đất đai, phòng học, công trình vệ sinh, hệ thống điện, nước, khu vực bếp ăn, sân chơi, đồ chơi ngoài trời, thiết bị và phương tiện phục vụ giáo dục.
>
> Phân loại nhu cầu đầu tư theo thứ tự ưu tiên:
>
> - Ưu tiên 1: Khắc phục ngay những nguy cơ mất an toàn.
> - Ưu tiên 2: Bảo đảm điều kiện tối thiểu để thực hiện chương trình, chăm sóc, nuôi dưỡng và phổ cập giáo dục.
> - Ưu tiên 3: Nâng cao chất lượng môi trường giáo dục, thiết bị và không gian hoạt động.
> - Ưu tiên 4: Đầu tư các hạng mục phát triển nâng cao khi có đủ nguồn lực.
>
> Xây dựng danh mục đầu tư trung hạn và kế hoạch hằng năm, xác định rõ nhu cầu, hiệu quả sử dụng, dự kiến kinh phí, nguồn vốn, thời gian thực hiện và cơ quan có thẩm quyền phê duyệt.
>
> Tăng cường bảo quản, kiểm kê, sửa chữa và sử dụng hiệu quả tài sản công; tránh mua sắm không phù hợp, thiếu đồng bộ hoặc sử dụng không hết công năng.
>
> Thực hiện vận động và tiếp nhận các nguồn hỗ trợ hợp pháp theo nguyên tắc tự nguyện, công khai, minh bạch; không đặt ra khoản đóng góp bắt buộc trái quy định.
>
> **3. Kết quả kỳ vọng**
>
> Các điều kiện thiết yếu từng bước được hoàn thiện; nguồn lực đầu tư tập trung, hiệu quả; môi trường giáo dục ngày càng đáp ứng tốt hơn yêu cầu chăm sóc và phát triển trẻ.
>
> **VI. Đổi mới quản trị nhà trường, chuyển đổi số và xây dựng văn hóa chất lượng**
>
> **1. Mục tiêu**
>
> Hình thành phương thức quản trị dựa trên kế hoạch, dữ liệu, kết quả và trách nhiệm giải trình; nâng cao hiệu quả điều hành và giảm những công việc hành chính trùng lặp.
>
> **2. Giải pháp**
>
> Rà soát, hoàn thiện quy chế làm việc, quy chế dân chủ, quy trình chuyên môn, quy trình kiểm tra nội bộ và cơ chế phối hợp giữa các bộ phận.
>
> Xây dựng hệ thống chỉ tiêu quản lý thống nhất; phân công người phụ trách, nguồn dữ liệu, phương pháp tính và thời điểm báo cáo cho từng chỉ tiêu.
>
> Từng bước số hóa hồ sơ quản lý phù hợp quy định; ưu tiên hồ sơ trẻ, đội ngũ, phổ cập, tài sản, kế hoạch chuyên môn và những dữ liệu phục vụ ra quyết định.
>
> Sử dụng công nghệ để phân tích tình hình huy động trẻ, tỷ lệ chuyên cần, nhân sự, chất lượng chăm sóc, tiến độ đầu tư và phản hồi của cha mẹ trẻ.
>
> Tăng cường kiểm tra nội bộ theo mức độ rủi ro; tập trung vào những lĩnh vực có nguy cơ ảnh hưởng quyền lợi, sự an toàn của trẻ, chất lượng giáo dục, tài chính và tài sản.
>
> Xây dựng môi trường làm việc đề cao trách nhiệm, sáng tạo, hợp tác và sự phát triển nghề nghiệp; giải quyết vướng mắc kịp thời, công khai theo đúng thẩm quyền.
>
> Bảo vệ dữ liệu cá nhân của trẻ, cha mẹ trẻ và đội ngũ; kiểm soát việc sử dụng hình ảnh trẻ trên môi trường số và trong hoạt động truyền thông.
>
> **3. Kết quả kỳ vọng**
>
> Công tác điều hành có căn cứ rõ ràng, quyết định kịp thời hơn, hồ sơ và dữ liệu thống nhất; giáo viên giảm thời gian cho những nhiệm vụ hành chính không cần thiết, tập trung hơn vào chăm sóc, giáo dục trẻ.
>
> **VII. Tăng cường phối hợp với gia đình, cộng đồng và bảo đảm công bằng giáo dục**
>
> Duy trì cơ chế trao đổi hai chiều giữa nhà trường và cha mẹ trẻ về sức khỏe, sự phát triển, nhu cầu hỗ trợ và những vấn đề phát sinh.
>
> Đổi mới nội dung tuyên truyền theo hướng thiết thực; ưu tiên hướng dẫn cha mẹ kỹ năng chăm sóc, dinh dưỡng, bảo vệ trẻ, hỗ trợ phát triển ngôn ngữ, cảm xúc và kỹ năng tự phục vụ.
>
> Tổ chức khảo sát mức độ hài lòng, tiếp nhận ý kiến và công khai kết quả khắc phục những nội dung thuộc trách nhiệm nhà trường.
>
> Phối hợp với chính quyền, cơ quan chuyên môn và các tổ chức liên quan để hỗ trợ trẻ có hoàn cảnh khó khăn, trẻ khuyết tật và những trẻ có nguy cơ bị hạn chế cơ hội tiếp cận giáo dục.
>
> Xây dựng hình ảnh nhà trường dựa trên chất lượng phục vụ và sự tin cậy, không sử dụng truyền thông mang tính phô trương hoặc gây áp lực đối với trẻ, giáo viên và cha mẹ trẻ.
>
> ### PHẦN THỨ NĂM. CÁC CHƯƠNG TRÌNH HÀNH ĐỘNG ƯU TIÊN
>
> Để tránh phân tán nguồn lực, nhà trường lựa chọn năm chương trình hành động xuyên suốt:
>
> | Chương trình | Sản phẩm chủ yếu |
> |---|---|
> | **1. Trường mầm non an toàn và chăm sóc chất lượng** | Hệ thống quy trình an toàn; kế hoạch kiểm soát rủi ro; hồ sơ theo dõi sức khỏe, dinh dưỡng và cải tiến hoạt động bán trú. |
> | **2. Nâng cao chất lượng giáo dục lấy trẻ làm trung tâm** | Kế hoạch phát triển chuyên môn; môi trường giáo dục phù hợp; minh chứng về sự tham gia và tiến bộ của trẻ. |
> | **3. Phát triển đội ngũ theo vị trí việc làm và năng lực** | Hồ sơ vị trí việc làm; phương án nhân sự; kế hoạch phát triển năng lực cá nhân; hồ sơ chế độ, chính sách đúng quy định. |
> | **4. Hoàn thiện điều kiện bảo đảm chất lượng** | Danh mục đầu tư ưu tiên; kế hoạch cải tạo, sửa chữa, bổ sung thiết bị; hồ sơ tự đánh giá và cải tiến chất lượng. |
> | **5. Quản trị số và kết nối gia đình – nhà trường** | Hệ thống dữ liệu quản lý; bộ chỉ số theo dõi; cơ chế thông tin hai chiều và đánh giá mức độ hài lòng. |
>
> Mỗi chương trình được cụ thể hóa bằng kế hoạch hằng năm, trong đó xác định ít nhất các yếu tố: mục tiêu, nhiệm vụ, sản phẩm, người phụ trách, kinh phí, thời hạn và minh chứng đánh giá.
>
> ### PHẦN THỨ SÁU. LỘ TRÌNH THỰC HIỆN GIAI ĐOẠN 2026–2030
>
> | Năm | Trọng tâm chiến lược | Kết quả cần đạt |
> |---|---|---|
> | **2026 – Rà soát, chuẩn hóa nền tảng** | Đánh giá toàn diện thực trạng; rà soát nhân sự, chức danh, xếp lương; chuẩn bị hồ sơ vị trí việc làm; xác lập các chỉ tiêu gốc và kế hoạch triển khai. | Hoàn thành các nhiệm vụ có thời hạn pháp lý trong năm; có hệ thống số liệu gốc và danh mục ưu tiên phát triển. |
> | **2027 – Hoàn thiện tổ chức và điều kiện thiết yếu** | Phối hợp hoàn thành phê duyệt, bố trí nhân sự theo vị trí việc làm; triển khai bồi dưỡng theo năng lực; ưu tiên khắc phục thiếu hụt cơ sở vật chất và tăng cường phổ cập. | Cơ cấu nhân sự, phân công nhiệm vụ được chuẩn hóa; các quy trình chuyên môn và an toàn được thực hiện thống nhất. |
> | **2028 – Tạo chuyển biến về chất lượng** | Tập trung nâng cao chất lượng chăm sóc, giáo dục; đổi mới sinh hoạt chuyên môn; đẩy mạnh chuyển đổi số; tổ chức đánh giá giữa kỳ. | Có minh chứng rõ về tiến bộ của trẻ, năng lực giáo viên, chất lượng môi trường giáo dục; điều chỉnh các mục tiêu chưa phù hợp. |
> | **2029 – Củng cố và phát triển chiều sâu** | Nhân rộng các giải pháp hiệu quả; hoàn thiện điều kiện kiểm định và chuẩn quốc gia; nâng cao hiệu quả nguồn lực và trách nhiệm giải trình. | Chất lượng được duy trì ổn định, giảm chênh lệch giữa các nhóm, lớp; các hạng mục ưu tiên đạt tiến độ theo kế hoạch. |
> | **2030 – Hoàn thành và đánh giá chiến lược** | Đánh giá toàn diện mục tiêu, chỉ tiêu, kết quả và tác động; tổ chức tổng kết, công khai kết quả; đề xuất định hướng giai đoạn tiếp theo. | Có báo cáo tổng kết dựa trên dữ liệu và minh chứng; xác định rõ kết quả đạt được, hạn chế, nguyên nhân và định hướng phát triển tiếp theo. |
>
> ### PHẦN THỨ BẢY. NGUỒN LỰC THỰC HIỆN
>
> **I. Nguồn lực con người**
>
> Phát huy vai trò lãnh đạo, điều hành của hiệu trưởng, trách nhiệm chuyên môn của các phó hiệu trưởng, tổ trưởng, giáo viên, nhân viên; tăng cường phối hợp giữa các tổ chức và bộ phận trong nhà trường.
>
> Cân đối việc phân công, sử dụng nhân sự phù hợp vị trí việc làm, định mức và nhiệm vụ; xây dựng kế hoạch phát triển nguồn nhân lực gắn với nhu cầu thực tế từng năm.
>
> **II. Nguồn lực tài chính**
>
> Nguồn kinh phí thực hiện chiến lược gồm ngân sách nhà nước được giao; nguồn vốn đầu tư theo các chương trình, kế hoạch được phê duyệt; các khoản thu và nguồn hỗ trợ hợp pháp khác theo quy định.
>
> Nhà trường lập kế hoạch kinh phí theo từng nhiệm vụ, dự án và năm thực hiện. Việc bố trí, sử dụng nguồn lực tuân thủ quy định về ngân sách, tài chính, tài sản công và cơ chế tự chủ hiện hành.
>
> **III. Nguyên tắc phân bổ nguồn lực**
>
> Ưu tiên nguồn lực cho bảo đảm an toàn, thực hiện chương trình giáo dục, chế độ chính sách của đội ngũ và điều kiện phổ cập.
>
> Chỉ triển khai các hoạt động phát triển nâng cao sau khi đã đáp ứng những yêu cầu thiết yếu hoặc có phương án bảo đảm tương ứng.
>
> Đối với những nhiệm vụ vượt khả năng cân đối của nhà trường, lập hồ sơ tham mưu, đề xuất cấp có thẩm quyền quyết định; không đưa các hạng mục chưa có nguồn vốn bảo đảm vào kế hoạch thực hiện bắt buộc.
>
> ### PHẦN THỨ TÁM. QUẢN LÝ RỦI RO VÀ CƠ CHẾ ĐIỀU CHỈNH CHIẾN LƯỢC
>
> **I. Những rủi ro chủ yếu**
>
> | Nguy cơ | Biện pháp phòng ngừa, ứng phó |
> |---|---|
> | Thiếu giáo viên, nhân viên | Dự báo nhu cầu theo quy mô trẻ; rà soát định mức; chủ động tham mưu nhân sự và điều chỉnh quy mô tiếp nhận phù hợp. |
> | Chậm triển khai các quy định nhân sự mới | Rà soát hồ sơ từ đầu giai đoạn; lập tiến độ theo thời hạn pháp luật; phân công đầu mối theo dõi, phối hợp cấp có thẩm quyền. |
> | Thiếu nguồn kinh phí đầu tư | Phân kỳ đầu tư; ưu tiên hạng mục thiết yếu; chuẩn bị dự toán, hồ sơ minh chứng và phương án sử dụng hiệu quả nguồn lực hiện có. |
> | Nguy cơ mất an toàn cho trẻ | Kiểm tra theo mức độ rủi ro; xử lý kịp thời; bồi dưỡng kỹ năng ứng phó; tạm dừng hoạt động ở khu vực chưa bảo đảm an toàn khi cần thiết. |
> | Biến động số lượng trẻ | Cập nhật dữ liệu dân số, tuyển sinh; dự báo quy mô hằng năm; linh hoạt đề xuất điều chỉnh nhóm, lớp theo quy định. |
> | Chuyển đổi số hình thức, tăng áp lực hồ sơ | Chọn công cụ thiết thực, thống nhất dữ liệu, phân quyền sử dụng và đánh giá mức giảm thao tác hành chính. |
>
> **II. Cơ chế điều chỉnh**
>
> Chiến lược được rà soát hằng năm và điều chỉnh khi có thay đổi lớn về chính sách, quy mô trẻ, nhân sự, nguồn lực hoặc điều kiện kinh tế – xã hội của địa phương.
>
> Việc điều chỉnh phải dựa trên số liệu, đánh giá tác động và được thực hiện theo thẩm quyền, quy trình quy định. Không tự ý thay đổi các mục tiêu cốt lõi về bảo đảm an toàn, quyền trẻ em hoặc thực hiện chế độ, chính sách của nhà giáo.
>
> ### PHẦN THỨ CHÍN. TỔ CHỨC THỰC HIỆN VÀ ĐÁNH GIÁ
>
> **I. Trách nhiệm thực hiện**
>
> **1. Hiệu trưởng**
>
> Chịu trách nhiệm chung về tổ chức triển khai chiến lược; chỉ đạo xây dựng kế hoạch hằng năm; quản lý và sử dụng nguồn lực; phân công nhiệm vụ; kiểm tra, đánh giá, điều chỉnh và báo cáo kết quả theo quy định.
>
> Chủ động tham mưu các vấn đề vượt thẩm quyền, nhất là phát triển quy mô, vị trí việc làm, nhân sự, cơ sở vật chất và nguồn lực tài chính.
>
> **2. Phó hiệu trưởng**
>
> Căn cứ phân công của hiệu trưởng, tham mưu và chịu trách nhiệm theo dõi các lĩnh vực: chuyên môn giáo dục, chăm sóc nuôi dưỡng, an toàn, kiểm tra nội bộ, phát triển đội ngũ và các chương trình hành động được giao.
>
> Định kỳ đánh giá tiến độ, chất lượng công việc và đề xuất giải pháp điều chỉnh.
>
> **3. Tổ chuyên môn, tổ văn phòng**
>
> Cụ thể hóa nhiệm vụ chiến lược thành kế hoạch của tổ, bộ phận; theo dõi chất lượng thực hiện; phát hiện vướng mắc và đề xuất giải pháp cải tiến.
>
> **4. Giáo viên, nhân viên**
>
> Thực hiện nhiệm vụ theo vị trí việc làm, phân công và quy trình chuyên môn; chủ động học tập, đổi mới phương pháp; bảo đảm an toàn cho trẻ và phối hợp với gia đình trong chăm sóc, giáo dục.
>
> **5. Các tổ chức, đoàn thể và cha mẹ trẻ**
>
> Phối hợp tuyên truyền, vận động, giám sát, đóng góp ý kiến và hỗ trợ thực hiện các mục tiêu phát triển nhà trường theo chức năng, nhiệm vụ và quy định của pháp luật.
>
> **II. Kiểm tra, giám sát và đánh giá**
>
> Việc đánh giá thực hiện chiến lược được tiến hành theo ba cấp độ:
>
> - **Theo dõi thường xuyên:** Cập nhật tiến độ các nhiệm vụ, chỉ tiêu và vấn đề phát sinh theo tháng, học kỳ hoặc thời điểm phù hợp.
> - **Đánh giá hằng năm:** Đối chiếu kết quả đạt được với mục tiêu năm, phân tích nguyên nhân và xác định nhiệm vụ ưu tiên cho năm tiếp theo.
> - **Đánh giá giữa kỳ và cuối kỳ:** Tổ chức đánh giá giữa kỳ vào năm 2028 và tổng kết chiến lược vào năm 2030.
>
> Kết quả đánh giá phải xác định được mức độ hoàn thành chỉ tiêu, chất lượng và tác động thực tế, hiệu quả sử dụng nguồn lực, những hạn chế cần khắc phục, trách nhiệm liên quan và phương án cải tiến.
>
> Nhà trường thực hiện công khai các nội dung thuộc diện phải công khai; tăng cường sự tham gia của tập thể trong giám sát và cải tiến chất lượng.
>
> ### PHẦN THỨ MƯỜI. KẾT LUẬN
>
> Chiến lược phát triển Trường Mầm non [Tên trường] giai đoạn 2026–2030 là định hướng quan trọng nhằm xây dựng nhà trường phát triển ổn định, nâng cao chất lượng và thích ứng với yêu cầu đổi mới giáo dục mầm non.
>
> Chiến lược xác định rõ quan điểm **phát triển chất lượng là trọng tâm, bảo đảm an toàn cho trẻ là điều kiện tiên quyết, phát triển đội ngũ là giải pháp quyết định, đổi mới quản trị là động lực và sử dụng hiệu quả nguồn lực là điều kiện để phát triển bền vững**.
>
> Việc thực hiện chiến lược đòi hỏi sự thống nhất, trách nhiệm và nỗ lực của tập thể nhà trường; sự phối hợp của cha mẹ trẻ, cộng đồng; đồng thời cần sự quan tâm, chỉ đạo và hỗ trợ của cơ quan quản lý có thẩm quyền.
>
> Với phương châm hành động thiết thực, có lộ trình và trách nhiệm rõ ràng, Trường Mầm non [Tên trường] quyết tâm thực hiện các mục tiêu giai đoạn 2026–2030, tạo chuyển biến thực chất về chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ, góp phần thực hiện mục tiêu phát triển giáo dục mầm non của địa phương.
>
> **Nơi nhận:**  
> - Cơ quan quản lý có thẩm quyền;  
> - Hội đồng trường và các bộ phận liên quan;  
> - Lưu: VT.
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên và đóng dấu)*
>
> [Họ và tên]

## III. Đề xuất để chiến lược có tính khả thi và thuyết phục cao hơn

Với góc nhìn quản lý, bản chiến lược chỉ thực sự có giá trị khi từng mục tiêu đều được liên kết với nguồn lực, thời hạn và kết quả đo lường. Tôi đề xuất bổ sung một **bảng điều hành chiến lược** để hiệu trưởng theo dõi thực hiện:

| Trụ cột | Chỉ số cần theo dõi | Trách nhiệm chính |
|--------|--------|--------|
| Quy mô và phổ cập | Trẻ trong độ tuổi, tỷ lệ huy động, tỷ lệ chuyên cần | Hiệu trưởng, bộ phận phổ cập |
| Chất lượng chăm sóc | An toàn, dinh dưỡng, sức khỏe, phản hồi phụ huynh | Phó hiệu trưởng phụ trách |
| Chất lượng giáo dục | Sự tiến bộ của trẻ, thực hiện chương trình, cải tiến chuyên môn | Phó hiệu trưởng chuyên môn |
| Phát triển đội ngũ | Định mức, vị trí việc làm, năng lực, kết quả bồi dưỡng | Hiệu trưởng, tổ trưởng |
| Cơ sở vật chất | Tình trạng công trình, thiết bị, tiến độ đầu tư | Hiệu trưởng, kế toán |
| Quản trị và chuyển đổi số | Tiến độ nhiệm vụ, chất lượng dữ liệu, kết quả kiểm tra | Ban giám hiệu |

### Bốn việc cần ưu tiên thực hiện

**Từ nay đến 31/12/2026 – Rà soát nhân sự**

Kiểm tra hồ sơ bổ nhiệm, xếp lương theo Thông tư 93/2026/TT-BGDĐT; xác định đúng đối tượng, thẩm quyền và các trường hợp chuyển tiếp được quy định tại Điều 7.

**Chậm nhất 01/7/2027 – Chuẩn hóa vị trí việc làm**

Hoàn thiện hồ sơ đề xuất, phối hợp cơ quan có thẩm quyền phê duyệt vị trí việc làm và thực hiện bố trí viên chức theo Nghị định 232/2026/NĐ-CP.

**Trong năm 2027 – Hoàn thiện bộ chỉ tiêu**

Từ số liệu gốc năm 2026, xác định các mục tiêu theo từng năm, bảo đảm phù hợp quy mô trẻ, đội ngũ và nguồn kinh phí thực tế.

**Năm 2028 và 2030 – Đánh giá kết quả thực chất**

Đánh giá giữa kỳ và cuối kỳ bằng minh chứng về sự phát triển của trẻ, chất lượng đội ngũ, điều kiện giáo dục và hiệu quả quản trị, không chỉ bằng thành tích thi đua.

## IV. Những thông tin cần bổ sung để hoàn thiện bản chính thức

Bản trên đã có khung nội dung chuyên môn và căn cứ pháp lý. Tuy nhiên, để có thể ban hành và sử dụng làm công cụ quản trị thực tế, cần bổ sung số liệu năm 2026 về quy mô trường lớp, số trẻ, đội ngũ, kết quả kiểm định, cơ sở vật chất và nguồn kinh phí dự kiến.

Đặc biệt, không nên giữ các mục tiêu định lượng theo đề xuất nếu chúng không phù hợp thực trạng; mọi chỉ tiêu phải được xác nhận và phân kỳ theo từng năm.

**Định hướng quan trọng nhất:** Chiến lược 2026–2030 không nên chỉ hướng tới một ngôi trường *đạt nhiều thành tích hơn*, mà phải chứng minh được rằng đến năm 2030, **trẻ được chăm sóc và giáo dục tốt hơn, giáo viên được phát triển nghề nghiệp tốt hơn, cha mẹ trẻ tin tưởng hơn và nhà trường vận hành hiệu quả hơn**. Đó là cơ sở thuyết phục nhất khi trình bày chiến lược trước Hội đồng trường và cơ quan quản lý.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

USER

lấy số liệu trường an bình nhé. XUẤT FILE word giúp mình để tiện in và lưu trữ

---

ASSISTANT

Tôi sẽ tìm số liệu thực tế của Trường Mầm non An Bình trong các tài liệu đã có, đối chiếu căn cứ pháp lý, rồi xuất bản Word theo thể thức văn bản hành chính để in và lưu trữ. Những chỉ tiêu chưa có số liệu xác thực tôi sẽ ghi rõ, không tự điền số liệu của trường.

---

ASSISTANT

---

ASSISTANT

Tôi đã tìm được hồ sơ thực tế của **Trường Mầm non An Bình, phường An Bình, tỉnh Đồng Tháp** và sẽ sử dụng số liệu của trường sau sáp nhập, không lấy riêng số liệu của An Bình A.

Các số liệu đã xác định để đưa vào chiến lược:

| Nội dung | Thực trạng năm 2026 |
|--------|--------|
| Thành lập sau sáp nhập | Ngày 13/8/2026, theo Quyết định 1861/QĐ-UBND |
| Đơn vị hợp nhất | Mầm non An Bình A, An Bình B và An Lộc |
| Đội ngũ tháng 10/2026 | 83 người: 4 cán bộ quản lý, 60 giáo viên, 19 nhân viên |
| Trẻ nhà trẻ | 58/356 trẻ, đạt 16,29% |
| Trẻ mẫu giáo 3–5 tuổi | 642/735 trẻ, đạt 87,35% |
| Trẻ 5 tuổi | 296/296 trẻ, đạt 100% |

Số liệu đội ngũ lấy theo Báo cáo số 250 ngày 27/10/2026; số liệu huy động lấy theo Báo cáo số 192 ngày 24/9/2026. Hai kỳ báo cáo sẽ được ghi rõ để tránh nhầm lẫn.  

Chiến lược sẽ đặc biệt chú trọng **ổn định quản trị sau sáp nhập, nâng tỷ lệ huy động trẻ nhà trẻ và mẫu giáo, cân đối giáo viên giữa các điểm trường, cải thiện cơ sở vật chất và nâng cao chất lượng giáo dục đến năm 2030**.

Tôi đã đối chiếu thể thức với **Nghị định 30/2020/NĐ-CP**, đặc biệt là mẫu văn bản hành chính có tên loại tại Phụ lục III. Với trường hợp này, tôi chọn tên loại **KẾ HOẠCH**, trích yếu là *Chiến lược phát triển Trường Mầm non An Bình giai đoạn 2026–2030*, ký hiệu dự kiến `/KH-MNAB`. Phần căn cứ của loại văn bản này sử dụng chữ đứng, không in nghiêng. [Nghị định số 30/2020/NĐ\-CP quy định về công tác văn thư, quản lý văn bản; thể thức, kỹ thuật trình bày văn bản; mẫu trình bày văn bản hành chính](<https://xaydungchinhsach.chinhphu.vn/quy-dinh-ve-cong-tac-van-thu-quan-ly-van-ban-the-thuc-ky-thuat-trinh-bay-van-ban-ban-sao-van-ban-viet-hoa-mau-trinh-bay-van-ban-hanh-chinh-119251023153016706.htm>); [Phần căn cứ ban hành văn bản chữ nghiêng hay thường?](<https://baochinhphu.vn/phan-can-cu-ban-hanh-van-ban-chu-nghieng-hay-thuong-102230425132226725.htm>)

Hiện tôi chưa thể tạo tệp `.docx` đính kèm trực tiếp trong phiên này. Tôi đã chuẩn bị bản dự thảo hoàn chỉnh dưới đây để có thể sao chép sang Word, chỉnh sửa và lưu trữ.

> **writing · document**
>
> | **ỦY BAN NHÂN DÂN PHƯỜNG AN BÌNH** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |:---:|:---:|
> | **TRƯỜNG MẦM NON AN BÌNH** | **Độc lập - Tự do - Hạnh phúc** |
>
> Số: …/KH-MNAB
>
> *An Bình, ngày … tháng … năm 2026*
>
> # KẾ HOẠCH
> **Chiến lược phát triển Trường Mầm non An Bình giai đoạn 2026–2030**
>
> Căn cứ Luật Giáo dục số 43/2019/QH14 ngày 14 tháng 6 năm 2019 và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Luật Nhà giáo số 73/2025/QH15; Luật Viên chức số 129/2025/QH15;
>
> Căn cứ Quyết định số 1705/QĐ-TTg ngày 31 tháng 12 năm 2024 của Thủ tướng Chính phủ phê duyệt Chiến lược phát triển giáo dục đến năm 2030, tầm nhìn đến năm 2045;
>
> Căn cứ Nghị quyết số 218/2025/QH15 về phổ cập giáo dục mầm non cho trẻ em từ 3 đến 5 tuổi và Nghị định số 277/2025/NĐ-CP;
>
> Căn cứ Thông tư số 19/2023/TT-BGDĐT ngày 30 tháng 10 năm 2023 của Bộ Giáo dục và Đào tạo hướng dẫn về vị trí việc làm, cơ cấu viên chức theo chức danh nghề nghiệp và định mức số lượng người làm việc trong các cơ sở giáo dục mầm non công lập;
>
> Căn cứ Nghị định số 232/2026/NĐ-CP ngày 26 tháng 6 năm 2026 của Chính phủ quy định về vị trí việc làm viên chức;
>
> Căn cứ Thông tư số 28/2026/TT-BGDĐT về chuẩn nghề nghiệp giáo viên mầm non; Thông tư số 31/2026/TT-BGDĐT và Thông tư số 93/2026/TT-BGDĐT về các quy định liên quan đến bổ nhiệm chức danh và xếp lương nhà giáo;
>
> Căn cứ Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Quyết định số 1861/QĐ-UBND ngày 13 tháng 8 năm 2026 của Ủy ban nhân dân phường An Bình về việc sáp nhập Trường Mầm non An Bình A, Trường Mầm non An Bình B và Trường Mầm non An Lộc thành Trường Mầm non An Bình;
>
> Căn cứ Kế hoạch số 129/KH-MNAB ngày 11 tháng 9 năm 2026 của Trường Mầm non An Bình về thực hiện nhiệm vụ năm học 2026–2027;
>
> Căn cứ Báo cáo số 192/BC-MNAB ngày 24 tháng 9 năm 2026; Báo cáo số 250/BC-MNAB ngày 27 tháng 10 năm 2026 và kết quả đánh giá tình hình thực tế nhà trường sau sáp nhập;
>
> Trường Mầm non An Bình xây dựng Kế hoạch chiến lược phát triển nhà trường giai đoạn 2026–2030 với các nội dung sau:
>
> ## I. SỰ CẦN THIẾT VÀ QUAN ĐIỂM PHÁT TRIỂN
>
> ### 1. Sự cần thiết
>
> Giai đoạn 2026–2030 là thời kỳ quan trọng trong quá trình đổi mới và phát triển giáo dục mầm non, với yêu cầu nâng cao chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ, thực hiện phổ cập giáo dục mầm non cho trẻ từ 3 đến 5 tuổi, phát triển đội ngũ nhà giáo và đổi mới quản trị theo hướng hiện đại, hiệu quả.
>
> Đối với Trường Mầm non An Bình, giai đoạn này còn có ý nghĩa đặc biệt khi nhà trường được thành lập trên cơ sở sáp nhập ba đơn vị có điều kiện hoạt động, đội ngũ, cơ sở vật chất và phương thức quản lý khác nhau. Việc sáp nhập tạo cơ hội tập trung nguồn lực, kế thừa kinh nghiệm và nâng cao hiệu quả quản trị; đồng thời đặt ra yêu cầu cấp thiết về thống nhất tổ chức, bảo đảm chất lượng đồng đều giữa các điểm trường và sử dụng hiệu quả các nguồn lực hiện có.
>
> Vì vậy, việc xây dựng chiến lược phát triển giai đoạn 2026–2030 là cần thiết nhằm xác định tầm nhìn, mục tiêu, nhiệm vụ ưu tiên và lộ trình thực hiện; tạo cơ sở cho công tác quản lý, điều hành, phân bổ nguồn lực và đánh giá kết quả phát triển nhà trường.
>
> Chiến lược phải bảo đảm tính kế thừa, đồng bộ, khả thi, có khả năng đo lường và điều chỉnh; không chạy theo thành tích hình thức mà hướng đến sự chuyển biến thực chất trong chất lượng chăm sóc, giáo dục trẻ và năng lực quản trị của nhà trường.
>
> ### 2. Quan điểm phát triển
>
> **2.1. Lấy trẻ làm trung tâm, an toàn làm nền tảng.**
>
> Mọi chủ trương, quyết định và hoạt động phát triển nhà trường phải bảo đảm quyền, lợi ích hợp pháp của trẻ; lấy sự an toàn, sức khỏe, niềm vui và sự phát triển toàn diện của trẻ làm thước đo chất lượng.
>
> **2.2. Phát triển chất lượng gắn với bảo đảm điều kiện thực hiện.**
>
> Việc mở rộng quy mô phải phù hợp khả năng đáp ứng về nhân lực, phòng học, thiết bị và điều kiện chăm sóc. Ưu tiên nâng cao chất lượng thực chất trước khi phát triển các hoạt động nâng cao.
>
> **2.3. Phát triển đội ngũ là giải pháp quyết định.**
>
> Tập trung xây dựng đội ngũ có năng lực, trách nhiệm và tinh thần hợp tác; thực hiện quản trị nhân sự theo vị trí việc làm, bảo đảm chế độ, chính sách và tạo động lực phát triển nghề nghiệp.
>
> **2.4. Thống nhất quản trị, phát huy đặc thù từng điểm trường.**
>
> Thực hiện thống nhất về mục tiêu, quy trình, tiêu chuẩn chất lượng và trách nhiệm giải trình; đồng thời bảo đảm tính linh hoạt trong tổ chức hoạt động phù hợp với đặc điểm trẻ và điều kiện từng điểm trường.
>
> **2.5. Phát triển bền vững trên cơ sở đổi mới và sử dụng hiệu quả nguồn lực.**
>
> Đẩy mạnh chuyển đổi số, cải tiến quy trình, tăng cường phối hợp gia đình và cộng đồng; thực hiện đầu tư có trọng tâm, tiết kiệm, công khai và đúng quy định.
>
> ## II. PHÂN TÍCH BỐI CẢNH VÀ THỰC TRẠNG NHÀ TRƯỜNG
>
> ### 1. Khái quát chung
>
> Trường Mầm non An Bình trực thuộc Ủy ban nhân dân phường An Bình, được thành lập theo Quyết định số 1861/QĐ-UBND ngày 13 tháng 8 năm 2026 trên cơ sở sáp nhập Trường Mầm non An Bình A, Trường Mầm non An Bình B và Trường Mầm non An Lộc.
>
> Nhà trường tổ chức hoạt động tại ba điểm quản lý: An Bình, An Bình A và An Lộc; kế thừa đội ngũ, cơ sở vật chất, thiết bị và kết quả thực hiện nhiệm vụ giáo dục của ba đơn vị trước sáp nhập.
>
> Việc hình thành đơn vị mới tạo điều kiện thống nhất định hướng phát triển, điều phối nguồn lực và tổ chức các hoạt động chuyên môn có quy mô lớn hơn. Tuy nhiên, sự khác biệt giữa các điểm trường đòi hỏi phải có giải pháp quản trị phù hợp, nhất là trong phân công đội ngũ, sử dụng cơ sở vật chất, tổ chức lớp ghép và kiểm soát chất lượng chăm sóc, giáo dục.
>
> ### 2. Thực trạng quy mô và huy động trẻ
>
> Theo Báo cáo số 192/BC-MNAB ngày 24 tháng 9 năm 2026, tình hình huy động trẻ của nhà trường được ghi nhận như sau:
>
> | Độ tuổi | Số trẻ huy động | Số trẻ trong độ tuổi | Tỷ lệ |
> |---|---:|---:|---:|
> | Nhà trẻ | 58 | 356 | 16,29% |
> | Mẫu giáo 3–5 tuổi | 642 | 735 | 87,35% |
> | Riêng trẻ 5 tuổi | 296 | 296 | 100% |
>
> Kết quả trên cho thấy nhà trường đã có nền tảng thuận lợi trong công tác huy động trẻ 5 tuổi, góp phần duy trì kết quả phổ cập giáo dục mầm non trên địa bàn.
>
> Tuy nhiên, tỷ lệ huy động trẻ nhà trẻ còn thấp; tỷ lệ huy động trẻ mẫu giáo 3–5 tuổi vẫn còn khoảng cách so với mục tiêu phát triển giáo dục đến năm 2030. Đây là một trong những vấn đề chiến lược cần ưu tiên giải quyết.
>
> Việc nâng tỷ lệ huy động cần căn cứ nhu cầu thực tế của gia đình, khả năng tiếp nhận của các cơ sở giáo dục trên địa bàn và điều kiện bảo đảm của nhà trường; không chỉ dựa vào công tác tuyên truyền, vận động mà còn phải nâng cao chất lượng chăm sóc, niềm tin của phụ huynh và điều kiện phục vụ.
>
> ### 3. Thực trạng đội ngũ
>
> Theo Báo cáo số 250/BC-MNAB ngày 27 tháng 10 năm 2026, tổng số cán bộ quản lý, giáo viên, nhân viên toàn trường là **83 người**, gồm:
>
> | Thành phần | Số lượng |
> |---|---:|
> | Hiệu trưởng | 01 |
> | Phó Hiệu trưởng | 03 |
> | Giáo viên | 60 |
> | Nhân viên | 19 |
> | **Tổng cộng** | **83** |
>
> Đội ngũ cơ bản được bố trí để thực hiện các hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ và phục vụ hoạt động của nhà trường.
>
> Tuy nhiên, việc đánh giá mức độ đáp ứng định mức nhân sự không thể chỉ căn cứ vào tổng số người hiện có mà phải đối chiếu với số nhóm, lớp thực tế, độ tuổi trẻ, hình thức tổ chức, khối lượng công việc và danh mục vị trí việc làm được cấp có thẩm quyền phê duyệt.
>
> Sau sáp nhập, yêu cầu trọng tâm là rà soát và điều phối đội ngũ hợp lý giữa các điểm trường; giải quyết tình trạng thiếu hụt hoặc phân bố chưa cân đối; đồng thời thực hiện đầy đủ chế độ, chính sách và phát triển năng lực nghề nghiệp cho giáo viên.
>
> ### 4. Thực trạng cơ sở vật chất
>
> Qua kết quả tổng kết năm học 2025–2026 của các đơn vị trước sáp nhập:
>
> Điểm An Bình A có các cơ sở tại khóm An Thịnh, An Lợi; báo cáo ghi nhận 9 phòng phục vụ nuôi dưỡng, chăm sóc, giáo dục và kết quả công nhận trường đạt chuẩn quốc gia mức độ 2 năm 2020.
>
> Điểm An Lộc có 10 phòng học kiên cố phục vụ 10 nhóm, lớp; hồ sơ báo cáo ghi nhận kết quả đạt chuẩn quốc gia mức độ 2.
>
> Điểm An Bình đã được địa phương quan tâm hỗ trợ sửa chữa phòng học và các công trình phục vụ hoạt động giáo dục; đang thực hiện các nhiệm vụ chuẩn bị kiểm định, đánh giá chất lượng.
>
> Tuy nhiên, việc sáp nhập đặt ra yêu cầu đánh giá lại điều kiện cơ sở vật chất trên phạm vi toàn trường. Kết quả công nhận của từng đơn vị trước sáp nhập cần được đối chiếu với quyết định, thời hạn và quy định áp dụng đối với đơn vị mới.
>
> Những hạn chế cần ưu tiên khắc phục gồm: sự thiếu đồng đều về thiết bị, đồ chơi ngoài trời, không gian vận động và trải nghiệm; điều kiện phục vụ tại các điểm lẻ; nhu cầu cải tạo, sắp xếp một số cơ sở và yêu cầu bảo đảm an toàn trong quá trình sử dụng.
>
> ### 5. Đánh giá điểm mạnh, hạn chế, cơ hội và thách thức
>
> **5.1. Điểm mạnh**
>
> Nhà trường nhận được sự quan tâm của cấp ủy, chính quyền địa phương và sự phối hợp của cha mẹ trẻ.
>
> Đội ngũ có kinh nghiệm trong tổ chức hoạt động giáo dục mầm non; các đơn vị trước sáp nhập đã hình thành những cách làm phù hợp trong tổ chức bán trú, giáo dục hòa nhập, sinh hoạt chuyên môn và xây dựng môi trường giáo dục.
>
> Công tác huy động trẻ 5 tuổi đạt kết quả tích cực; hoạt động chăm sóc, nuôi dưỡng, giáo dục được duy trì; một số cơ sở đã có nền tảng về kiểm định và trường đạt chuẩn quốc gia.
>
> **5.2. Hạn chế**
>
> Tỷ lệ huy động trẻ nhà trẻ còn thấp, chưa đáp ứng định hướng phát triển dài hạn.
>
> Điều kiện tổ chức hoạt động, sĩ số và bố trí nhân sự chưa đồng đều giữa các điểm trường; một số lớp ghép, lớp đông cần tiếp tục được hỗ trợ chuyên môn.
>
> Việc quản lý tại nhiều điểm trường làm tăng yêu cầu phối hợp, kiểm tra và giám sát trực tiếp.
>
> Một số hạng mục cơ sở vật chất, sân chơi, thiết bị và học liệu chưa đáp ứng đồng đều. Dữ liệu, quy trình và hồ sơ quản lý của ba đơn vị trước sáp nhập cần tiếp tục được chuẩn hóa, đồng bộ.
>
> **5.3. Cơ hội**
>
> Các chính sách phát triển giáo dục mầm non, phổ cập giáo dục mầm non cho trẻ 3–5 tuổi, phát triển đội ngũ nhà giáo và đổi mới quản trị tạo cơ sở để nhà trường tham mưu nguồn lực và nâng cao chất lượng.
>
> Việc sáp nhập cho phép tập trung năng lực chuyên môn, tổ chức các hoạt động hỗ trợ giữa các điểm trường và sử dụng hiệu quả hơn cơ sở vật chất, thiết bị hiện có.
>
> **5.4. Thách thức**
>
> Nhu cầu gửi trẻ có thể biến động theo tình hình kinh tế, điều kiện việc làm và khả năng chi trả của gia đình.
>
> Việc thực hiện các quy định mới về vị trí việc làm, chuẩn nghề nghiệp, chức danh và xếp lương đòi hỏi quản lý hồ sơ chính xác, phối hợp chặt chẽ với cơ quan có thẩm quyền.
>
> Nguồn lực đầu tư có giới hạn, trong khi yêu cầu bảo đảm an toàn, cải thiện cơ sở vật chất và nâng cao chất lượng ngày càng cao.
>
> ### 6. Xác định vấn đề chiến lược
>
> Trên cơ sở phân tích thực trạng, nhà trường xác định năm vấn đề cần tập trung giải quyết:
>
> Thứ nhất, nâng cao tỷ lệ huy động trẻ nhà trẻ và mẫu giáo, góp phần thực hiện mục tiêu phổ cập trên địa bàn.
>
> Thứ hai, thống nhất và nâng cao chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ giữa các điểm trường.
>
> Thứ ba, xây dựng đội ngũ đáp ứng yêu cầu vị trí việc làm, năng lực nghề nghiệp và quy mô phát triển.
>
> Thứ tư, hoàn thiện cơ sở vật chất theo thứ tự ưu tiên, bảo đảm an toàn và hiệu quả sử dụng.
>
> Thứ năm, đổi mới quản trị, ứng dụng công nghệ số và xây dựng văn hóa chất lượng, trách nhiệm giải trình.
>
> ## III. TẦM NHÌN, SỨ MỆNH VÀ GIÁ TRỊ CỐT LÕI
>
> ### 1. Tầm nhìn
>
> Đến năm 2030, Trường Mầm non An Bình trở thành cơ sở giáo dục mầm non công lập có chất lượng chăm sóc, nuôi dưỡng và giáo dục ổn định, phát triển theo hướng hiện đại, an toàn, thân thiện; có đội ngũ nhà giáo vững vàng về chuyên môn, trách nhiệm, sáng tạo; có môi trường giáo dục đáp ứng nhu cầu phát triển của trẻ và tạo được sự tin tưởng của cha mẹ trẻ, cộng đồng.
>
> ### 2. Sứ mệnh
>
> Xây dựng môi trường giáo dục an toàn, yêu thương và tôn trọng sự khác biệt; tạo cơ hội để mọi trẻ được vui chơi, trải nghiệm, khám phá và phát triển toàn diện phù hợp với đặc điểm lứa tuổi; phối hợp chặt chẽ với gia đình, cộng đồng trong việc hình thành nền tảng nhân cách, phát triển các năng lực ban đầu và chuẩn bị tâm thế cho trẻ vào lớp Một.
>
> ### 3. Giá trị cốt lõi
>
> **An toàn – Yêu thương – Tôn trọng – Trách nhiệm – Hợp tác – Đổi mới.**
>
> ## IV. MỤC TIÊU CHIẾN LƯỢC
>
> ### 1. Mục tiêu tổng quát
>
> Xây dựng Trường Mầm non An Bình phát triển ổn định, chất lượng và bền vững; thực hiện hiệu quả các mục tiêu phổ cập giáo dục mầm non; nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ; phát triển đội ngũ và từng bước hoàn thiện điều kiện bảo đảm chất lượng.
>
> Đến năm 2030, nhà trường phấn đấu có chuyển biến thực chất về chất lượng giáo dục, năng lực quản trị, hiệu quả sử dụng nguồn lực và mức độ hài lòng của cha mẹ trẻ; đáp ứng yêu cầu đổi mới giáo dục mầm non của địa phương.
>
> ### 2. Mục tiêu cụ thể
>
> **2.1. Quy mô và phổ cập**
>
> Duy trì kết quả huy động trẻ 5 tuổi đạt 100% theo phạm vi, phương pháp thống kê được giao.
>
> Phấn đấu nâng tỷ lệ huy động trẻ nhà trẻ từ 16,29% năm 2026 lên mức phù hợp với mục tiêu 38% vào năm 2030; nâng tỷ lệ huy động trẻ mẫu giáo 3–5 tuổi từ 87,35% lên mức phù hợp với mục tiêu 97% vào năm 2030.
>
> Các tỷ lệ trên là chỉ tiêu định hướng để xây dựng phương án huy động, phải được điều chỉnh theo dân số, địa bàn, nhu cầu thực tế và điều kiện tiếp nhận của các cơ sở giáo dục.
>
> **2.2. Chất lượng nuôi dưỡng, chăm sóc và an toàn**
>
> Phấn đấu 100% trẻ được theo dõi sức khỏe và tình trạng dinh dưỡng theo quy định; có biện pháp hỗ trợ phù hợp đối với trẻ suy dinh dưỡng, thừa cân, béo phì hoặc có nhu cầu chăm sóc đặc biệt.
>
> Bảo đảm các điều kiện an toàn trong hoạt động của nhà trường; chủ động phòng ngừa tai nạn thương tích, bạo hành, xâm hại trẻ em, ngộ độc thực phẩm và dịch bệnh.
>
> Nâng cao chất lượng tổ chức bán trú theo nhu cầu gia đình và khả năng phục vụ; bảo đảm dinh dưỡng, vệ sinh an toàn thực phẩm và công khai theo quy định.
>
> **2.3. Chất lượng giáo dục**
>
> 100% nhóm, lớp thực hiện Chương trình Giáo dục mầm non và các yêu cầu chuyên môn hiện hành.
>
> 100% trẻ được quan sát, theo dõi, đánh giá và hỗ trợ phát triển phù hợp độ tuổi, đặc điểm cá nhân.
>
> Đổi mới phương pháp tổ chức hoạt động lấy trẻ làm trung tâm, tăng cường vui chơi, trải nghiệm, giáo dục kỹ năng sống, kỹ năng tự phục vụ và giáo dục hòa nhập.
>
> **2.4. Phát triển đội ngũ**
>
> 100% giáo viên đáp ứng chuẩn trình độ đào tạo theo quy định và được đánh giá, bồi dưỡng theo chuẩn nghề nghiệp.
>
> Hoàn thiện việc rà soát, đề xuất vị trí việc làm, cơ cấu nhân sự và nhu cầu nhân lực theo quy định.
>
> Phấn đấu bố trí đủ nhân sự theo định mức được áp dụng và số lượng người làm việc được cấp có thẩm quyền giao; ưu tiên giải quyết những vị trí ảnh hưởng trực tiếp đến chất lượng và an toàn.
>
> **2.5. Cơ sở vật chất và bảo đảm chất lượng**
>
> Tập trung khắc phục những nguy cơ mất an toàn; hoàn thiện điều kiện thiết yếu về phòng học, vệ sinh, nước sạch, bếp ăn, thiết bị, sân chơi và học liệu.
>
> Rà soát hiện trạng theo hệ thống tiêu chuẩn, tiêu chí hiện hành; xây dựng lộ trình cải tiến chất lượng và kiểm định phù hợp với đơn vị sau sáp nhập.
>
> **2.6. Quản trị và chuyển đổi số**
>
> Thực hiện thống nhất hệ thống quy chế, quy trình và cơ chế kiểm tra, giám sát toàn trường.
>
> 100% dữ liệu quản lý thiết yếu được cập nhật, đối chiếu và sử dụng đúng quy định; giảm trùng lặp hồ sơ, tăng hiệu quả khai thác dữ liệu phục vụ công tác quản lý.
>
> Tăng cường công khai, dân chủ, trách nhiệm giải trình và khảo sát sự hài lòng của cha mẹ trẻ; phấn đấu tỷ lệ hài lòng đạt từ 95% vào năm 2030 theo phương pháp khảo sát thống nhất.
>
> ## V. NHIỆM VỤ VÀ GIẢI PHÁP CHỦ YẾU
>
> ### 1. Phát triển quy mô hợp lý, nâng cao chất lượng công tác phổ cập
>
> Tăng cường phối hợp với Ủy ban nhân dân phường An Bình và các bộ phận liên quan trong điều tra, rà soát, cập nhật trẻ trong độ tuổi, xác định chính xác tình hình trẻ đã đi học, chưa đi học và nguyên nhân chưa đến trường.
>
> Xây dựng kế hoạch huy động trẻ theo từng độ tuổi, từng địa bàn; chú trọng trẻ nhà trẻ, trẻ mẫu giáo 3–4 tuổi, trẻ có hoàn cảnh khó khăn và trẻ có nhu cầu hỗ trợ đặc biệt.
>
> Phân tích nhu cầu gửi trẻ của gia đình, khả năng phục vụ của các điểm trường và điều kiện bán trú để lựa chọn giải pháp phù hợp.
>
> Tham mưu tăng cường cơ sở vật chất, nhân lực và các điều kiện cần thiết khi nhu cầu tiếp nhận tăng. Không phát triển quy mô vượt quá khả năng bảo đảm an toàn và chất lượng.
>
> ### 2. Nâng cao chất lượng chăm sóc, nuôi dưỡng và an toàn
>
> Chuẩn hóa quy trình đón, trả trẻ, quản lý trẻ trong ngày; tổ chức ăn, ngủ, vệ sinh, hoạt động ngoài trời và xử lý tình huống khẩn cấp.
>
> Thực hiện kiểm tra, đánh giá nguy cơ mất an toàn tại từng điểm trường, nhóm, lớp; xác định người chịu trách nhiệm và thời hạn khắc phục.
>
> Tăng cường quản lý thực phẩm, nguồn cung cấp, chế biến, bảo quản và lưu mẫu theo quy định; xây dựng thực đơn cân đối, phù hợp độ tuổi, đặc điểm trẻ và điều kiện thực tế.
>
> Theo dõi sức khỏe, dinh dưỡng của trẻ; phối hợp gia đình điều chỉnh chế độ ăn, vận động và chăm sóc phù hợp với những trẻ có nguy cơ về dinh dưỡng.
>
> Tổ chức bồi dưỡng kỹ năng sơ cấp cứu ban đầu, phòng chống tai nạn thương tích, bạo lực và xâm hại trẻ em cho đội ngũ.
>
> ### 3. Đổi mới hoạt động chuyên môn, phát triển toàn diện trẻ
>
> Thực hiện có chất lượng Chương trình Giáo dục mầm non; xây dựng kế hoạch giáo dục phù hợp độ tuổi, nhu cầu và khả năng của trẻ.
>
> Đổi mới sinh hoạt chuyên môn theo hướng nghiên cứu hoạt động giáo dục, tập trung vào khó khăn thực tế của giáo viên: tổ chức lớp ghép, lớp đông, đánh giá trẻ, giáo dục hòa nhập và xây dựng môi trường giáo dục.
>
> Tăng cường dự giờ, hỗ trợ đồng nghiệp giữa các điểm trường; phát huy giáo viên có kinh nghiệm, chia sẻ học liệu và những cách làm hiệu quả.
>
> Ứng dụng STEM/STEAM và công nghệ phù hợp đặc điểm tâm sinh lý lứa tuổi, bảo đảm mục tiêu chương trình và tránh gây áp lực cho trẻ.
>
> Sử dụng kết quả quan sát, đánh giá trẻ làm căn cứ cải tiến hoạt động giáo dục; không lấy kết quả hội thi hoặc số lượng hoạt động làm thước đo duy nhất.
>
> ### 4. Chuẩn hóa đội ngũ theo vị trí việc làm
>
> Rà soát cơ cấu cán bộ quản lý, giáo viên, nhân viên theo danh mục vị trí việc làm, định mức và số lượng người làm việc được giao.
>
> Xây dựng hoặc cập nhật hồ sơ vị trí việc làm, bản mô tả công việc, khung năng lực và phương án bố trí nhân sự thuộc trách nhiệm của nhà trường.
>
> Phối hợp cơ quan có thẩm quyền thực hiện các nhiệm vụ chuyển tiếp theo Nghị định số 232/2026/NĐ-CP; chủ động chuẩn bị hồ sơ để việc phê duyệt, bố trí nhân sự được thực hiện đúng thời hạn.
>
> Rà soát hồ sơ bổ nhiệm chức danh, xếp lương nhà giáo theo Thông tư số 31/2026/TT-BGDĐT và Thông tư số 93/2026/TT-BGDĐT; bảo đảm việc thực hiện đúng đối tượng, thẩm quyền, điều kiện và quyền lợi hợp pháp của giáo viên.
>
> Xây dựng kế hoạch bồi dưỡng đội ngũ dựa trên kết quả đánh giá chuẩn nghề nghiệp và yêu cầu nhiệm vụ; chú trọng năng lực tổ chức giáo dục, chăm sóc trẻ, ứng dụng công nghệ và phối hợp gia đình.
>
> Đổi mới đánh giá đội ngũ theo chất lượng, hiệu quả công việc; bảo đảm công bằng, dân chủ, khách quan và có minh chứng.
>
> ### 5. Phát triển cơ sở vật chất, bảo đảm chất lượng giáo dục
>
> Tổ chức kiểm kê, đánh giá toàn diện hiện trạng đất đai, công trình, phòng học, phòng chức năng, khu vực bếp ăn, công trình vệ sinh, sân chơi, trang thiết bị và học liệu.
>
> Xây dựng kế hoạch đầu tư theo bốn mức ưu tiên: xử lý nguy cơ mất an toàn; bảo đảm điều kiện thiết yếu; nâng cao chất lượng môi trường giáo dục; đầu tư phát triển nâng cao khi đủ nguồn lực.
>
> Đối với điểm An Bình A, tiếp tục rà soát phương án sắp xếp, cải tạo các cơ sở tại An Thịnh, An Lợi theo quy hoạch và quyết định của cấp có thẩm quyền.
>
> Đối với điểm An Lộc, ưu tiên rà soát, cải thiện không gian vận động, trải nghiệm, thiết bị và điều kiện tổ chức hoạt động phù hợp số trẻ thực tế.
>
> Đối với điểm An Bình, tiếp tục triển khai các nội dung cải tiến chất lượng, chuẩn bị đánh giá theo kế hoạch được phê duyệt.
>
> Thực hiện kiểm định chất lượng giáo dục và xây dựng trường đạt chuẩn quốc gia trên cơ sở điều kiện thực tế của toàn trường sau sáp nhập, không mặc nhiên kế thừa mức công nhận của từng đơn vị trước đây.
>
> ### 6. Đổi mới quản trị, tăng cường chuyển đổi số
>
> Xây dựng và thực hiện thống nhất quy chế làm việc, quy chế chuyên môn, quy chế dân chủ, quy trình phối hợp và quản lý tài sản trong toàn trường.
>
> Phân công Ban giám hiệu phụ trách lĩnh vực và điểm trường; bảo đảm rõ người, rõ việc, rõ trách nhiệm, rõ thời hạn và rõ kết quả.
>
> Ứng dụng phần mềm, dữ liệu số trong quản lý trẻ, đội ngũ, công tác phổ cập, chuyên môn, dinh dưỡng, tài chính và tài sản theo quy định.
>
> Từng bước xây dựng kho học liệu, tài liệu chuyên môn dùng chung; khuyến khích giáo viên ứng dụng công nghệ để giảm công việc hành chính, tăng thời gian tổ chức hoạt động cho trẻ.
>
> Tăng cường kiểm tra nội bộ theo mức độ rủi ro, chú trọng an toàn, dinh dưỡng, chuyên môn, tài chính, tài sản và thực hiện chế độ, chính sách.
>
> ### 7. Tăng cường phối hợp gia đình và cộng đồng
>
> Đổi mới hoạt động truyền thông giáo dục mầm non, tập trung hướng dẫn cha mẹ trẻ kỹ năng chăm sóc sức khỏe, dinh dưỡng, bảo vệ trẻ và phối hợp phát triển kỹ năng phù hợp độ tuổi.
>
> Thực hiện trao đổi hai chiều với cha mẹ trẻ; kịp thời tiếp nhận, phản hồi và giải quyết các kiến nghị thuộc thẩm quyền.
>
> Tăng cường phối hợp địa phương và các tổ chức liên quan trong thực hiện phổ cập, hỗ trợ trẻ khó khăn và xây dựng môi trường giáo dục an toàn, thân thiện.
>
> Việc vận động, huy động và tiếp nhận các nguồn hỗ trợ phải đúng quy định, tự nguyện, công khai, minh bạch, không tạo áp lực đóng góp.
>
> ## VI. LỘ TRÌNH THỰC HIỆN
>
> ### 1. Năm 2026 – Ổn định tổ chức và chuẩn hóa nền tảng
>
> Tập trung hoàn thiện việc tiếp nhận, bàn giao, kiểm kê và thống nhất quản lý sau sáp nhập.
>
> Rà soát số liệu trẻ, đội ngũ, tài sản và các chỉ tiêu chất lượng; hoàn thiện hệ thống quy chế, quy trình và phân công trách nhiệm tại các điểm trường.
>
> Ưu tiên rà soát, thực hiện hoặc trình cấp có thẩm quyền việc bổ nhiệm chức danh, xếp lương theo Thông tư số 93/2026/TT-BGDĐT đúng thời hạn.
>
> Xây dựng hồ sơ, phương án vị trí việc làm và kế hoạch phát triển đội ngũ; xác định những nhu cầu đầu tư cấp thiết.
>
> ### 2. Năm 2027 – Hoàn thiện tổ chức và điều kiện thiết yếu
>
> Phối hợp thực hiện nhiệm vụ phê duyệt, bố trí nhân sự theo vị trí việc làm đúng quy định.
>
> Tăng cường công tác huy động trẻ, nâng cao chất lượng bán trú, chuẩn hóa quy trình chăm sóc, giáo dục và bảo đảm an toàn.
>
> Ưu tiên khắc phục những điều kiện cơ sở vật chất còn thiếu; tổ chức bồi dưỡng giáo viên theo nhu cầu thực tế.
>
> ### 3. Năm 2028 – Tạo chuyển biến về chất lượng
>
> Tập trung cải tiến hoạt động giáo dục, nâng cao chất lượng sinh hoạt chuyên môn và hỗ trợ giáo viên tại từng nhóm, lớp.
>
> Đẩy mạnh xây dựng môi trường giáo dục, phát triển kho học liệu dùng chung và ứng dụng dữ liệu trong quản trị.
>
> Tổ chức đánh giá giữa kỳ chiến lược; phân tích kết quả, nguyên nhân và điều chỉnh các mục tiêu chưa phù hợp.
>
> ### 4. Năm 2029 – Phát triển chiều sâu và củng cố chất lượng
>
> Tiếp tục nâng cao tỷ lệ huy động trẻ và chất lượng chăm sóc, giáo dục; giảm chênh lệch về điều kiện và kết quả giữa các điểm trường.
>
> Hoàn thiện các nội dung cải tiến chất lượng, chuẩn bị kiểm định, công nhận trường đạt chuẩn quốc gia theo điều kiện và kế hoạch được phê duyệt.
>
> Đánh giá hiệu quả sử dụng đội ngũ, cơ sở vật chất, tài chính và kết quả chuyển đổi số.
>
> ### 5. Năm 2030 – Hoàn thành và đánh giá chiến lược
>
> Tổ chức đánh giá toàn diện các mục tiêu, chỉ tiêu và nhiệm vụ chiến lược.
>
> Đối chiếu kết quả phát triển với số liệu gốc năm 2026 và các chỉ tiêu đã được phê duyệt.
>
> Tổng kết những kết quả đạt được, hạn chế, nguyên nhân, bài học kinh nghiệm; xác định định hướng phát triển cho giai đoạn tiếp theo.
>
> ## VII. NGUỒN LỰC THỰC HIỆN
>
> ### 1. Nguồn lực con người
>
> Sử dụng và phát huy hiệu quả đội ngũ cán bộ quản lý, giáo viên, nhân viên hiện có; xây dựng kế hoạch bồi dưỡng, phát triển nguồn nhân lực theo vị trí việc làm và yêu cầu phát triển nhà trường.
>
> ### 2. Nguồn lực tài chính
>
> Sử dụng kinh phí ngân sách nhà nước được giao, các nguồn kinh phí hợp pháp và nguồn hỗ trợ được phê duyệt theo quy định.
>
> Việc đầu tư, mua sắm, sửa chữa và sử dụng nguồn lực phải có kế hoạch, dự toán, nguồn kinh phí, thẩm quyền quyết định và cơ chế kiểm tra, giám sát.
>
> ### 3. Nguyên tắc phân bổ nguồn lực
>
> Ưu tiên cho nhiệm vụ bảo đảm an toàn, chăm sóc, nuôi dưỡng, thực hiện chương trình giáo dục, phát triển đội ngũ và công tác phổ cập.
>
> Không đầu tư dàn trải; thực hiện điều chuyển, sử dụng chung các thiết bị phù hợp trước khi đề xuất mua sắm bổ sung.
>
> Đối với nhiệm vụ vượt quá khả năng cân đối, nhà trường lập phương án tham mưu cấp có thẩm quyền xem xét, quyết định.
>
> ## VIII. KIỂM TRA, GIÁM SÁT VÀ ĐÁNH GIÁ CHIẾN LƯỢC
>
> Hiệu trưởng chỉ đạo xây dựng bộ chỉ số theo dõi thực hiện chiến lược, xác định rõ số liệu gốc, mức cần đạt, thời điểm đánh giá, nguồn minh chứng và trách nhiệm phụ trách.
>
> Việc đánh giá được thực hiện theo ba cấp độ: theo dõi thường xuyên; đánh giá hằng năm; đánh giá giữa kỳ năm 2028 và tổng kết năm 2030.
>
> Kết quả đánh giá tập trung vào sự phát triển của trẻ, chất lượng đội ngũ, hiệu quả quản trị, điều kiện giáo dục và mức độ hài lòng của cha mẹ trẻ.
>
> Những chỉ tiêu không đạt phải được phân tích nguyên nhân, xác định trách nhiệm, nguồn lực cần bổ sung và giải pháp khắc phục; không điều chỉnh chỉ tiêu chỉ nhằm thuận lợi cho công tác đánh giá.
>
> ## IX. TỔ CHỨC THỰC HIỆN
>
> ### 1. Hiệu trưởng
>
> Chịu trách nhiệm chung về tổ chức triển khai chiến lược; chỉ đạo xây dựng kế hoạch hằng năm, bố trí và sử dụng nguồn lực, kiểm tra, đánh giá, điều chỉnh và báo cáo kết quả thực hiện.
>
> ### 2. Các Phó Hiệu trưởng
>
> Căn cứ lĩnh vực được phân công, tham mưu và tổ chức thực hiện các nhiệm vụ chuyên môn, chăm sóc nuôi dưỡng, an toàn, phát triển đội ngũ, kiểm tra nội bộ và các chương trình hành động của nhà trường.
>
> ### 3. Các tổ chuyên môn, tổ văn phòng
>
> Cụ thể hóa mục tiêu, nhiệm vụ chiến lược thành kế hoạch hằng năm của tổ, bộ phận; theo dõi chất lượng thực hiện, phát hiện khó khăn và đề xuất giải pháp cải tiến.
>
> ### 4. Giáo viên, nhân viên
>
> Thực hiện nhiệm vụ theo vị trí việc làm và sự phân công; chủ động học tập, nâng cao năng lực nghề nghiệp, bảo đảm an toàn cho trẻ và phối hợp với gia đình trong chăm sóc, giáo dục.
>
> ### 5. Các tổ chức, đoàn thể và cha mẹ trẻ
>
> Phối hợp tuyên truyền, giám sát, đóng góp ý kiến, hỗ trợ nhà trường thực hiện các mục tiêu theo chức năng, nhiệm vụ và quy định.
>
> ## X. KẾT LUẬN
>
> Chiến lược phát triển Trường Mầm non An Bình giai đoạn 2026–2030 là cơ sở định hướng hoạt động của nhà trường trong thời kỳ mới, bảo đảm sự phát triển có kế hoạch, có trọng tâm và phù hợp yêu cầu đổi mới giáo dục mầm non.
>
> Việc thực hiện chiến lược phải hướng đến kết quả thực chất, trong đó sự an toàn và phát triển của trẻ là mục tiêu cao nhất; chất lượng đội ngũ là yếu tố quyết định; đổi mới quản trị là động lực; sự phối hợp của gia đình và cộng đồng là điều kiện quan trọng để phát triển bền vững.
>
> Nhà trường phát huy tinh thần đoàn kết, trách nhiệm, chủ động, sáng tạo của tập thể; sử dụng hiệu quả các nguồn lực, phấn đấu hoàn thành các mục tiêu đến năm 2030, góp phần nâng cao chất lượng giáo dục mầm non trên địa bàn phường An Bình.
>
> Trên đây là Kế hoạch chiến lược phát triển Trường Mầm non An Bình giai đoạn 2026–2030. Đề nghị các bộ phận, tổ chuyên môn, giáo viên, nhân viên căn cứ nhiệm vụ được phân công triển khai thực hiện nghiêm túc, hiệu quả./.
>
> | **Nơi nhận:** | **HIỆU TRƯỞNG** |
> |---|:---:|
> | - UBND phường An Bình (báo cáo); | |
> | - Phòng Văn hóa - Xã hội (phối hợp); | |
> | - Các tổ, bộ phận (thực hiện); | |
> | - Lưu: VT. | **Huỳnh Hồng Loan** |
>
> ---
>
> # PHỤ LỤC I
> **BỘ CHỈ TIÊU THEO DÕI CHIẾN LƯỢC PHÁT TRIỂN GIAI ĐOẠN 2026–2030**
>
> *(Kèm theo Kế hoạch số …/KH-MNAB ngày … tháng … năm 2026 của Trường Mầm non An Bình)*
>
> ### 1. Lộ trình huy động trẻ đề xuất
>
> | Chỉ tiêu | 2026 (gốc) | 2027 | 2028 | 2029 | 2030 |
> |---|---:|---:|---:|---:|---:|
> | Nhà trẻ (%) | 16,29 | ≥22 | ≥28 | ≥33 | ≥38 |
> | Mẫu giáo 3–5 tuổi (%) | 87,35 | ≥90 | ≥93 | ≥95 | ≥97 |
> | Trẻ 5 tuổi (%) | 100 | 100 | 100 | 100 | 100 |
>
> *Ghi chú:* Các mức từ năm 2027 đến 2030 là chỉ tiêu phấn đấu đề xuất, không phải số liệu được cấp trên phê duyệt. Khi xây dựng kế hoạch từng năm phải cập nhật mẫu số dân số, phạm vi huy động, số trẻ học tại các cơ sở khác và khả năng đáp ứng thực tế. Không áp dụng tỷ lệ trên như yêu cầu nhà trường phải trực tiếp tiếp nhận toàn bộ trẻ trong độ tuổi trên địa bàn.
>
> ### 2. Các chỉ tiêu quản trị và chất lượng
>
> | Nội dung | Chỉ tiêu đến năm 2030 | Minh chứng |
> |---|---|---|
> | An toàn trường học | 100% nhóm, lớp được kiểm tra, kiểm soát nguy cơ | Biên bản kiểm tra, hồ sơ khắc phục |
> | Chăm sóc sức khỏe | 100% trẻ được theo dõi theo quy định | Sổ sức khỏe, dữ liệu y tế |
> | Chương trình giáo dục | 100% nhóm, lớp thực hiện đầy đủ | Kế hoạch, kiểm tra chuyên môn |
> | Đánh giá trẻ | 100% trẻ được theo dõi, hỗ trợ phát triển | Hồ sơ đánh giá trẻ |
> | Đội ngũ giáo viên | 100% đạt chuẩn trình độ đào tạo theo quy định | Hồ sơ viên chức |
> | Chuẩn nghề nghiệp | 100% giáo viên được đánh giá và lập kế hoạch phát triển | Hồ sơ đánh giá, bồi dưỡng |
> | Vị trí việc làm | Hoàn thành quản lý, bố trí nhân sự theo quyết định có thẩm quyền | Hồ sơ vị trí việc làm |
> | Cơ sở vật chất | Hoàn thành các hạng mục thiết yếu theo kế hoạch được duyệt | Kiểm kê, nghiệm thu |
> | Chuyển đổi số | 100% dữ liệu quản lý thiết yếu được cập nhật theo quy định | Cơ sở dữ liệu ngành |
> | Sự hài lòng của phụ huynh | Phấn đấu đạt từ 95% | Khảo sát hằng năm |
> | Bảo đảm chất lượng | Hoàn thành các nhiệm vụ kiểm định, cải tiến theo lộ trình được duyệt | Hồ sơ kiểm định |
>
> # PHỤ LỤC II
> **CÁC NHIỆM VỤ ƯU TIÊN CẦN HOÀN THÀNH SAU SÁP NHẬP**
>
> | Nhiệm vụ | Thời gian | Chủ trì |
> |---|---|---|
> | Rà soát hồ sơ bổ nhiệm chức danh, xếp lương theo Thông tư 93/2026/TT-BGDĐT | Năm 2026, theo thời hạn pháp luật | Hiệu trưởng |
> | Hoàn thiện hồ sơ, phương án vị trí việc làm theo Nghị định 232/2026/NĐ-CP | 2026–2027 | Hiệu trưởng, bộ phận liên quan |
> | Đối chiếu, chuẩn hóa dữ liệu trẻ, nhóm lớp, đội ngũ | 2026 và hằng năm | Ban giám hiệu, bộ phận thống kê |
> | Kiểm kê, đánh giá cơ sở vật chất toàn trường | 2026–2027 | Hiệu trưởng, kế toán, các bộ phận |
> | Xây dựng kế hoạch nâng tỷ lệ huy động trẻ | Hằng năm | Ban giám hiệu, bộ phận phổ cập |
> | Thống nhất quy trình chăm sóc, giáo dục tại các điểm | 2026–2027 | Phó Hiệu trưởng phụ trách |
> | Kiểm định, cải tiến chất lượng sau sáp nhập | 2027–2030 | Ban giám hiệu |
> | Đánh giá giữa kỳ chiến lược | 2028 | Hiệu trưởng |
> | Tổng kết chiến lược, đề xuất giai đoạn mới | 2030 | Hiệu trưởng |
>
> **Ghi chú quản lý số liệu:** Trước khi ký ban hành cần đối chiếu lại số nhóm/lớp toàn trường, quy mô trẻ đang học tại cùng một thời điểm, số lượng người làm việc theo từng loại hình, kết quả công nhận chuẩn quốc gia của đơn vị mới, danh mục tài sản và nhu cầu đầu tư. Không gộp số liệu khác kỳ hoặc mặc nhiên chuyển kết quả công nhận từ các đơn vị trước sáp nhập sang trường mới.

## Thiết lập trong Word để in đúng thể thức

Khổ giấy

**A4, chiều dọc**

Phông chữ

**Times New Roman, Unicode**

Cỡ chữ nội dung

**13–14 pt**

Giãn dòng

**1,15 dòng**

---

Căn lề khuyến nghị

Trên

**2 cm**

Dưới

**2 cm**

Trái

**3,5 cm**

Phải

**2 cm**

Khi đưa sang Word, cần đặt quốc hiệu và tên cơ quan thành hai cột không viền; căn đều hai lề phần nội dung, thụt đầu dòng 1 cm, giãn cách đoạn phù hợp và đặt số trang ở giữa phần lề trên. Đây là các thiết lập nằm trong giới hạn quy định tại Phụ lục I Nghị định 30/2020/NĐ-CP. [Bộ Nội vụ](<https://vbpl.moj.gov.vn/bonoivu/Pages/vbpq-toanvan.aspx?ItemID=141142&dvid=320>); [CHÍNH PHỦ

CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM  
Độ](<https://sxd.dienbien.gov.vn/Cms_Data/Contents/SOXAYDUNG/Folders/QLThongBao/~contents/8PQ2N8TX48DVKV9E/nghi-dinh-30-2020-nd-cp-ve-cong-tac-van-thu.pdf>)

Bản dự thảo đã sử dụng số liệu có nguồn xác định của trường và phân biệt rõ số liệu thực tế với chỉ tiêu đề xuất. **Trước khi ký ban hành**, cần kiểm tra lại những thông tin còn chênh lệch giữa các hồ sơ sau sáp nhập, đặc biệt là số nhóm lớp, tổng số trẻ đang học và tình trạng công nhận chuẩn quốc gia của Trường Mầm non An Bình mới.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

ASSISTANT

Tôi đã xác minh thêm một điểm quan trọng: sau sáp nhập, số liệu đội ngũ tháng 9 và tháng 10 có thay đổi từ 84 xuống 83 người. Tôi cũng tìm thấy thông tin về 27 nhóm/lớp trong một tài liệu chuyên đề, nhưng số trẻ ở các hồ sơ chưa hoàn toàn thống nhất. Bản chiến lược sẽ dùng số liệu đã có nguồn rõ ràng và ghi nội dung cần đối chiếu trước khi ký ban hành.

---

USER

trình bày văn bản theo nghị định 30 cho chuẩn nhé

---

ASSISTANT

Tôi sẽ trình bày theo **Nghị định 30/2020/NĐ-CP về công tác văn thư**: đúng quốc hiệu – tiêu ngữ, tên cơ quan, số ký hiệu, địa danh và ngày tháng, tên loại văn bản, căn lề, phông chữ, đề mục và phần ký của hiệu trưởng. Tôi cũng sẽ dùng thể loại văn bản hành chính phù hợp để bản chiến lược có thể đưa vào hồ sơ chính thức của trường.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

USER

xuất file word giúp mình

---

ASSISTANT

Tôi đã chuẩn bị nội dung **Chiến lược phát triển Trường Mầm non An Bình giai đoạn 2026–2030**, có sử dụng số liệu thực tế của trường sau sáp nhập và trình bày theo **Nghị định 30/2020/NĐ-CP**.

Hiện tại, tôi chưa thể tạo và đính kèm trực tiếp tệp Word `.docx` trong phiên trò chuyện này.

Để lưu thành file Word, bạn có thể sao chép toàn bộ bản dự thảo ở câu trả lời ngay phía trên vào Microsoft Word, sau đó chọn **File → Save As → Word Document (.docx)**.

Thiết lập in: khổ A4, Times New Roman cỡ 13–14, lề trái 3,5 cm, lề phải 2 cm, lề trên và dưới 2 cm.

**Tên file đề xuất:** `CHIEN_LUOC_PHAT_TRIEN_TRUONG_MAM_NON_AN_BINH_2026-2030.docx`

---

