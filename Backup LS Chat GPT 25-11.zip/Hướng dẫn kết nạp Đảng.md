USER

dựa vào thông tin văn bản trong ảnh bạn đối chiếu văn bản và hướng dẫn tôi cách tổ chức kết nạp đảng cho Đảng viên và lời tuyên thệ

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đã đối chiếu thông tin trong ảnh với nguồn văn bản hiện hành. Ảnh bạn gửi đúng là phần đầu của **Quy định số 208-QĐ/TW ngày 26/7/2026 của Ban Chấp hành Trung ương về thi hành Điều lệ Đảng**; văn bản có hiệu lực từ ngày 26/7/2026. [Source unavailable: turn1search1]; [Quy định số 208\-QĐ/TW ngày 26/7/2026 của Ban Chấp hành Trung ương Đảng về thi hành Điều lệ Đảng](<https://tulieuvankien.dangcongsan.vn/van-ban-cua-dang/quy-dinh-so-208-qd-tw-ngay-26-7-2026-cua-ban-chap-hanh-trung-uong-dang-ve-thi-hanh-dieu-le-dang.html?categoryId=102000092&utm_source=chatgpt.com>)

Để tổ chức **Lễ kết nạp đảng viên hiện nay**, ngoài Quy định 208-QĐ/TW, cần trực tiếp căn cứ **Hướng dẫn số 02-HD/TW ngày 07/8/2026 của Ban Bí thư**, đặc biệt **Mục 3.8 – Tổ chức lễ kết nạp đảng viên**. Hướng dẫn 02-HD/TW có hiệu lực từ ngày 07/8/2026 và hướng dẫn cụ thể việc thực hiện Quy định 208-QĐ/TW. [Source unavailable: turn2search1]; [Văn bản và Quy định](<https://danguy.ntu.edu.vn/van-ban-va-quy-%C4%91inh?utm_source=chatgpt.com>)

### Cách tổ chức Lễ kết nạp đảng viên

Theo Mục 3.8 Hướng dẫn 02-HD/TW, lễ phải được tổ chức **trang nghiêm**. Nếu trong cùng một buổi kết nạp từ hai người trở lên thì vẫn **tiến hành kết nạp từng người một**. [Source unavailable: turn2search1]

Phần trang trí, nhìn từ dưới lên, gồm: phía trên cùng là khẩu hiệu **“Đảng Cộng sản Việt Nam quang vinh muôn năm”**; cờ Đảng, cờ Tổ quốc, tượng hoặc ảnh Chủ tịch Hồ Chí Minh ở bên trái; ảnh Mác – Lênin ở bên phải; và tiêu đề **“LỄ KẾT NẠP ĐẢNG VIÊN”**. [Source unavailable: turn2search1]; [Văn bản và Quy định](<https://danguy.ntu.edu.vn/van-ban-va-quy-%C4%91inh?utm_source=chatgpt.com>)

**Chương trình chính thức nên thực hiện đúng thứ tự sau:**

1. **Chào cờ:** hát Quốc ca và Quốc tế ca.
2. **Tuyên bố lý do, giới thiệu đại biểu.**
3. **Bí thư chi bộ hoặc đại diện chi ủy đọc Quyết định kết nạp đảng viên** của cấp ủy có thẩm quyền.
4. **Đảng viên mới đọc lời tuyên thệ.**
5. **Bí thư chi bộ hoặc đại diện chi ủy** nói rõ nhiệm vụ, quyền hạn của đảng viên; nhiệm vụ của chi bộ; đồng thời phân công đảng viên chính thức giúp đỡ đảng viên dự bị.
6. **Đại diện cấp ủy cấp trên phát biểu** nếu có.
7. **Bế mạc:** hát Quốc ca và Quốc tế ca. [Source unavailable: turn2search1]; [Hướng dẫn Tổ chức lễ kết nạp đảng viên mới theo Hướng dẫn 02\-HD/TW ngày 07/8/2026 thay thế Hướng dẫn 01 ngày 19/5/2026 ra sao?](<https://thuvienphapluat.vn/phap-luat/huong-dan-to-chuc-le-ket-nap-dang-vien-moi-theo-huong-dan-02hdtw-ngay-0782026-thay-the-huong-dan-01-287627.html?utm_source=chatgpt.com>)

Một điểm cần lưu ý: theo Hướng dẫn 02-HD/TW mới, ở bước 5 văn bản ghi rõ **“Bí thư chi bộ hoặc đại diện chi uỷ”** thực hiện nội dung nói rõ nhiệm vụ, quyền hạn và phân công giúp đỡ đảng viên dự bị. [Source unavailable: turn2search1]

### Lời tuyên thệ của đảng viên mới

Hướng dẫn 02-HD/TW quy định trong chương trình phải có bước **“Đảng viên mới đọc lời tuyên thệ”**, nhưng tại Mục 3.8 không in nguyên văn một mẫu lời tuyên thệ. [Source unavailable: turn2search1] Vì vậy, cần phân biệt giữa **nội dung bắt buộc của nghi lễ theo văn bản** và **mẫu lời tuyên thệ đang được sử dụng phổ biến trong thực tế**.

Mẫu thông dụng gồm **4 nội dung**, tương ứng với các nhiệm vụ cơ bản của đảng viên. Nội dung thứ nhất bắt đầu bằng việc cam kết tuyệt đối trung thành với mục đích, lý tưởng cách mạng của Đảng, chấp hành Cương lĩnh, Điều lệ, nghị quyết, chỉ thị và pháp luật; các nội dung tiếp theo tập trung vào học tập, rèn luyện và đấu tranh chống chủ nghĩa cá nhân; gắn bó, phục vụ nhân dân; xây dựng, bảo vệ Đảng, giữ đoàn kết, tự phê bình và phê bình, phát triển đảng viên, sinh hoạt và đóng đảng phí. [Source unavailable: turn3search0]; [Mẫu lời tuyên thệ đảng viên mới nhất](<https://thuvienphapluat.vn/chinh-sach-phap-luat-moi/vn/ho-tro-phap-luat/tu-van-phap-luat/44581/mau-loi-tuyen-the-cua-dang-vien-moi-nhat?utm_source=chatgpt.com>)

Về nghi thức thường dùng, đảng viên mới **đứng quay mặt về cờ Tổ quốc, cờ Đảng và chân dung Chủ tịch Hồ Chí Minh**; sau từng nội dung tuyên thệ giơ nắm tay phải và hô **“Xin thề!”**; kết thúc nội dung cuối thường hô **“Xin thề! Xin thề! Xin thề!”**. [Source unavailable: turn3search1]

**Lưu ý quan trọng:** không nên tự thêm các phần như trao hoa, phát biểu cảm tưởng, giới thiệu quá trình phấn đấu... vào giữa trình tự bắt buộc nêu trên nếu làm thay đổi cấu trúc nghi lễ. Nếu đơn vị muốn có các nội dung bổ sung, nên bố trí phù hợp và thống nhất với cấp ủy quản lý.

Nếu bạn cần sử dụng ngay tại **Chi bộ Trường Mầm non An Bình**, tôi có thể soạn cho bạn **một kịch bản Lễ kết nạp đảng viên hoàn chỉnh theo Quy định 208-QĐ/TW và Hướng dẫn 02-HD/TW năm 2026**, gồm **lời dẫn MC từng bước + lời tuyên thệ đầy đủ + lời Bí thư giao nhiệm vụ + phần phân công đảng viên giúp đỡ + lời bế mạc**, chỉ cần thay tên đảng viên là có thể dùng.

---

