USER

hội thi “Sáng tạo học liệu số – Đồ dùng, đồ chơi thông minh” dành cho giáo viên hoặc nhóm thiết kế đồ dùng, đồ chơi và học liệu phục vụ chăm sóc, giáo dục trẻ có ứng dụng công nghệ số, như trò chơi tương tác, học liệu trực quan, video hướng dẫn sử dụng đồ chơi, mã QR giới thiệu cách chơi hoặc sản phẩm kết hợp vật liệu sẵn có với nội dung số. Sản phẩm phải phù hợp độ tuổi, mục tiêu giáo dục, an toàn, có khả năng áp dụng thực tế tại lớp. Các tổ chuyên môn giới thiệu, trao đổi và chia sẻ sản phẩm tiêu biểu để giáo viên khai thác trong hoạt động giáo dục; trưng bày hoặc trình chiếu trong buổi họp mặt.  bạn giúp tôi làm phụ lục thể lệ của Hội thi này bắt đầu từ ngày 16 đến ngày 30/11/2026

---

ASSISTANT

Tôi sẽ soạn phụ lục theo thể thức văn bản nhà trường, gồm đối tượng dự thi, yêu cầu sản phẩm, hồ sơ, tiến độ từ 16–30/11/2026, thang điểm và cách tổ chức chấm, trưng bày. Tôi cũng sẽ lưu ý các yêu cầu về an toàn của trẻ và bảo vệ hình ảnh, dữ liệu khi sử dụng học liệu số.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Có một điểm cần điều chỉnh trước khi ban hành: Công văn 5922/BGDĐT-GDPT ngày 03/9/2026 yêu cầu không tổ chức hội thi, phong trào giáo viên mầm non làm đồ dùng, đồ chơi; đồng thời khuyến khích hoạt động giao lưu, chia sẻ học liệu và ứng dụng công nghệ. Vì vậy, tôi sẽ giữ nguyên chủ đề và thời gian 16–30/11, nhưng soạn theo hình thức **trưng bày, giới thiệu và chia sẻ sản phẩm tự nguyện**, tránh chấm giải và gây áp lực cho giáo viên.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

📌 **PHỤ LỤC QUY ĐỊNH TỔ CHỨC HOẠT ĐỘNG “SÁNG TẠO HỌC LIỆU SỐ – ĐỒ DÙNG, ĐỒ CHƠI THÔNG MINH”**

**Thời gian: Từ ngày 16/11/2026 đến ngày 30/11/2026.**

**Lưu ý về quy định hiện hành:** Công văn số 5922/BGDĐT-GDPT ngày 03/9/2026 của Bộ Giáo dục và Đào tạo yêu cầu không tổ chức hội thi, phong trào giáo viên mầm non làm đồ dùng, đồ chơi; đồng thời khuyến khích giáo viên tự nguyện chia sẻ sáng kiến, học liệu và ứng dụng công nghệ số. [Source unavailable: turn243246search0]; [Source unavailable: turn366165search1]

Vì vậy, tôi đề xuất sử dụng **phụ lục quy định tham gia hoạt động giao lưu, trưng bày và chia sẻ sản phẩm** thay cho thể lệ hội thi chấm giải. Cách này vẫn giữ được mục tiêu sáng tạo, giới thiệu sản phẩm tiêu biểu và tổ chức trưng bày trong buổi họp mặt của nhà trường.

Dưới đây là nội dung có thể đưa trực tiếp vào kế hoạch.

> **writing · document**
>
> **TRƯỜNG MẦM NON …………………**
>
> # PHỤ LỤC
> ## QUY ĐỊNH TỔ CHỨC HOẠT ĐỘNG GIAO LƯU, TRƯNG BÀY VÀ CHIA SẺ
> ## “SÁNG TẠO HỌC LIỆU SỐ – ĐỒ DÙNG, ĐỒ CHƠI THÔNG MINH”
>
> *Thời gian thực hiện: Từ ngày 16/11/2026 đến ngày 30/11/2026*
>
> *(Kèm theo Kế hoạch số …/KH-… ngày … tháng 11 năm 2026 của Trường Mầm non …………………)*
>
> ### I. MỤC ĐÍCH, YÊU CẦU
>
> **1. Mục đích**
>
> - Khuyến khích giáo viên phát huy tinh thần sáng tạo, chủ động ứng dụng công nghệ số trong thiết kế, khai thác và sử dụng học liệu, đồ dùng, đồ chơi phục vụ hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ.
> - Tạo điều kiện để giáo viên, các tổ chuyên môn giới thiệu, trao đổi kinh nghiệm và chia sẻ những sản phẩm có giá trị giáo dục, phù hợp điều kiện thực tế của nhà trường.
> - Góp phần xây dựng kho học liệu số dùng chung, nâng cao hiệu quả tổ chức các hoạt động giáo dục theo quan điểm lấy trẻ làm trung tâm.
> - Phát hiện, giới thiệu và nhân rộng những ý tưởng, giải pháp sáng tạo có khả năng ứng dụng thiết thực trong các nhóm, lớp.
>
> **2. Yêu cầu**
>
> - Hoạt động được tổ chức trên tinh thần tự nguyện, thiết thực, tiết kiệm, không gây áp lực hoặc phát sinh hồ sơ, chi phí không cần thiết đối với giáo viên.
> - Sản phẩm phải phù hợp độ tuổi, mục tiêu giáo dục, bảo đảm tính khoa học, tính thẩm mỹ, an toàn và khả năng sử dụng thực tế.
> - Việc ứng dụng công nghệ số phải có giá trị hỗ trợ hoạt động giáo dục, không chạy theo hình thức hoặc lạm dụng thiết bị điện tử.
> - Khuyến khích chia sẻ, khai thác và cải tiến các sản phẩm đã có hiệu quả sử dụng; không bắt buộc giáo viên phải thiết kế sản phẩm mới.
>
> ### II. ĐỐI TƯỢNG VÀ HÌNH THỨC THAM GIA
>
> **1. Đối tượng**
>
> Giáo viên đang công tác tại nhà trường, tham gia theo hình thức cá nhân hoặc nhóm giáo viên có cùng ý tưởng thiết kế, xây dựng và khai thác sản phẩm.
>
> **2. Hình thức**
>
> - Cá nhân hoặc nhóm giáo viên tự nguyện đăng ký giới thiệu sản phẩm.
> - Các tổ chuyên môn lựa chọn, giới thiệu những sản phẩm tiêu biểu, có khả năng chia sẻ và áp dụng tại các nhóm, lớp.
> - Sản phẩm được giới thiệu thông qua trưng bày trực tiếp, trình chiếu, thao tác minh họa hoặc chia sẻ bằng đường liên kết, mã QR.
>
> ### III. NỘI DUNG VÀ LOẠI HÌNH SẢN PHẨM
>
> **1. Nội dung**
>
> Thiết kế, cải tiến hoặc khai thác học liệu số, đồ dùng, đồ chơi có ứng dụng công nghệ nhằm hỗ trợ trẻ học thông qua chơi, trải nghiệm, khám phá và tương tác tích cực.
>
> Nội dung gắn với các lĩnh vực phát triển của trẻ theo Chương trình Giáo dục mầm non, phù hợp đặc điểm tâm sinh lý và khả năng nhận thức của từng độ tuổi.
>
> **2. Các loại hình sản phẩm**
>
> a) **Trò chơi tương tác số:** Trò chơi nhận biết chữ cái, chữ số, màu sắc, hình dạng, phân loại, ghép đôi, tìm hiểu môi trường xung quanh hoặc phát triển các kỹ năng phù hợp độ tuổi; được thiết kế bằng PowerPoint hoặc phần mềm phù hợp.
>
> b) **Học liệu trực quan số:** Tranh ảnh tương tác, sách điện tử, câu chuyện số, bài trình chiếu, bộ thẻ học liệu có âm thanh, hình ảnh hoặc các tư liệu trực quan hỗ trợ giáo viên tổ chức hoạt động giáo dục.
>
> c) **Video giáo dục và hướng dẫn sử dụng đồ chơi:** Video giới thiệu cấu tạo, cách làm, cách sử dụng, tổ chức trò chơi hoặc hướng dẫn trẻ thực hiện các thao tác phù hợp.
>
> d) **Đồ dùng, đồ chơi tích hợp mã QR:** Sản phẩm có mã QR liên kết đến video hướng dẫn, trò chơi tương tác, âm thanh, câu chuyện, hình ảnh hoặc nội dung giáo dục bổ trợ.
>
> đ) **Sản phẩm kết hợp vật liệu sẵn có với công nghệ số:** Đồ dùng, đồ chơi tự tạo hoặc cải tiến từ vật liệu an toàn, dễ tìm, kết hợp học liệu số nhằm tăng khả năng tương tác, trải nghiệm và hứng thú của trẻ.
>
> ### IV. YÊU CẦU ĐỐI VỚI SẢN PHẨM
>
> **1. Về giá trị giáo dục**
>
> - Xác định rõ đối tượng sử dụng, độ tuổi, mục tiêu và nội dung giáo dục.
> - Phù hợp với khả năng nhận thức, nhu cầu, hứng thú của trẻ; tạo cơ hội cho trẻ được quan sát, thao tác, trải nghiệm và tương tác.
> - Có khả năng vận dụng vào một hoặc nhiều hoạt động chăm sóc, nuôi dưỡng, giáo dục tại lớp.
>
> **2. Về ứng dụng công nghệ số**
>
> - Có yếu tố ứng dụng công nghệ số rõ ràng, phù hợp mục đích sử dụng.
> - Hình ảnh, âm thanh, lời thoại rõ ràng; thao tác thuận tiện, dễ sử dụng.
> - Mã QR, đường liên kết, video hoặc tệp học liệu phải hoạt động khi giới thiệu.
> - Khuyến khích sản phẩm có thể sử dụng ngoại tuyến, không phụ thuộc hoàn toàn vào kết nối Internet.
> - Không sử dụng công nghệ chỉ mang tính trang trí, thiếu giá trị hỗ trợ giáo dục.
>
> **3. Về tính sáng tạo và khả thi**
>
> - Thể hiện ý tưởng sáng tạo hoặc giải pháp cải tiến có giá trị sử dụng.
> - Ưu tiên tận dụng thiết bị, phần mềm và vật liệu sẵn có, hạn chế chi phí phát sinh.
> - Dễ khai thác, bảo quản, điều chỉnh hoặc chia sẻ để giáo viên khác có thể sử dụng.
>
> **4. Về an toàn và bản quyền**
>
> - Đồ dùng, đồ chơi phải bảo đảm an toàn về vật liệu, cấu tạo, kích thước và cách sử dụng; không có chi tiết sắc nhọn, dễ gây thương tích hoặc nguy cơ mất an toàn đối với trẻ.
> - Học liệu số có nội dung lành mạnh, phù hợp văn hóa và thuần phong mỹ tục; không có quảng cáo hoặc đường liên kết không phù hợp.
> - Tôn trọng quyền tác giả, ghi rõ nguồn tài nguyên sử dụng khi cần thiết.
> - Bảo vệ thông tin, hình ảnh cá nhân của trẻ; việc sử dụng, chia sẻ hình ảnh hoặc video có trẻ phải tuân thủ quy định về bảo vệ dữ liệu cá nhân và quyền riêng tư của trẻ em.
>
> ### V. HỒ SƠ VÀ CÁCH THỨC GIỚI THIỆU SẢN PHẨM
>
> **1. Thành phần gửi giới thiệu**
>
> Mỗi cá nhân hoặc nhóm giáo viên gửi:
>
> - Tên sản phẩm; họ và tên người thực hiện; tổ chuyên môn.
> - Bản mô tả ngắn gọn về độ tuổi sử dụng, mục tiêu giáo dục, cách sử dụng và điểm sáng tạo của sản phẩm (khuyến khích trình bày không quá 01 trang A4).
> - Tệp sản phẩm số, video hoặc đường liên kết/mã QR truy cập sản phẩm.
> - Sản phẩm trực quan hoặc đồ dùng, đồ chơi thực tế (nếu có) để trưng bày, minh họa.
>
> **2. Hình thức tiếp nhận**
>
> Giáo viên gửi thông tin và sản phẩm về tổ trưởng chuyên môn. Tổ trưởng tổng hợp, chuyển bộ phận chuyên môn nhà trường để bố trí nội dung giới thiệu và trưng bày.
>
> **3. Hình thức chia sẻ tại buổi họp mặt**
>
> - Cá nhân hoặc đại diện nhóm giới thiệu sản phẩm trong khoảng 3–5 phút.
> - Minh họa thao tác sử dụng hoặc trình chiếu video, trò chơi, học liệu số.
> - Trao đổi cách khai thác, những thuận lợi, khó khăn và khả năng áp dụng tại các nhóm, lớp.
>
> ### VI. THỜI GIAN VÀ TIẾN ĐỘ THỰC HIỆN
>
> | Thời gian | Nội dung thực hiện | Bộ phận phụ trách |
> |---|---|---|
> | 16–18/11/2026 | Triển khai nội dung hoạt động; hướng dẫn giáo viên đăng ký, giới thiệu ý tưởng và sản phẩm | Ban giám hiệu, tổ chuyên môn |
> | 19–25/11/2026 | Giáo viên tự nguyện thiết kế, cải tiến, hoàn thiện sản phẩm; các tổ chuyên môn trao đổi, hỗ trợ | Giáo viên, nhóm thực hiện |
> | 26/11/2026 | Tiếp nhận thông tin và sản phẩm, hoàn thành trước 16 giờ | Tổ trưởng chuyên môn |
> | 27/11/2026 | Tổng hợp, rà soát nội dung và điều kiện an toàn; kiểm tra tệp trình chiếu, liên kết, mã QR; sắp xếp sản phẩm giới thiệu | Bộ phận chuyên môn, giáo viên phụ trách công nghệ |
> | 30/11/2026 | Tổ chức trưng bày, trình chiếu, giới thiệu và trao đổi kinh nghiệm trong buổi họp mặt; tổng hợp sản phẩm để tiếp tục khai thác, chia sẻ | Ban giám hiệu, các tổ chuyên môn |
>
> ### VII. NỘI DUNG TRAO ĐỔI, NHẬN XÉT SẢN PHẨM
>
> Các sản phẩm được giới thiệu, trao đổi và góp ý dựa trên những nội dung sau:
>
> | STT | Nội dung | Yêu cầu xem xét |
> |---|---|---|
> | 1 | Tính giáo dục | Phù hợp độ tuổi, mục tiêu, nội dung giáo dục |
> | 2 | Tính sáng tạo | Có ý tưởng hoặc giải pháp cải tiến thiết thực |
> | 3 | Hiệu quả ứng dụng công nghệ số | Công nghệ hỗ trợ rõ ràng việc tổ chức hoạt động và tương tác |
> | 4 | Tính an toàn, thẩm mỹ | An toàn, hấp dẫn, dễ sử dụng, nội dung phù hợp |
> | 5 | Tính thực tiễn và khả năng chia sẻ | Dễ áp dụng, tiết kiệm, có khả năng nhân rộng |
>
> Việc nhận xét tập trung vào giá trị sử dụng và đề xuất điều chỉnh, hoàn thiện sản phẩm; **không tổ chức chấm điểm, xếp hạng hoặc trao giải thi đua**.
>
> ### VIII. TỔ CHỨC THỰC HIỆN
>
> **1. Ban giám hiệu**
>
> - Chỉ đạo triển khai hoạt động bảo đảm phù hợp kế hoạch chuyên môn và các quy định hiện hành.
> - Phân công bộ phận chuyên môn chuẩn bị địa điểm, phương tiện trình chiếu và điều kiện tổ chức.
> - Chỉ đạo tổng hợp, lưu trữ, chia sẻ các sản phẩm phù hợp; thực hiện việc lựa chọn học liệu, đồ chơi để đưa vào sử dụng tại nhà trường theo quy định.
>
> **2. Các tổ chuyên môn**
>
> - Triển khai nội dung đến giáo viên, khuyến khích tham gia trên tinh thần tự nguyện.
> - Hỗ trợ giáo viên trao đổi ý tưởng, hoàn thiện sản phẩm.
> - Giới thiệu sản phẩm có tính ứng dụng cao, phù hợp nhu cầu chăm sóc, giáo dục trẻ tại các nhóm, lớp.
> - Tổ chức chia sẻ kinh nghiệm và đề xuất hình thức khai thác sản phẩm trong sinh hoạt chuyên môn.
>
> **3. Giáo viên, nhóm thực hiện**
>
> - Chủ động lựa chọn nội dung, hình thức sản phẩm phù hợp khả năng và điều kiện thực tế.
> - Chịu trách nhiệm về tính chính xác, an toàn, nguồn gốc và quyền sử dụng các nội dung trong sản phẩm.
> - Chuẩn bị phần giới thiệu ngắn gọn, minh họa rõ cách sử dụng và hiệu quả giáo dục dự kiến.
> - Sẵn sàng chia sẻ, tiếp thu góp ý và điều chỉnh sản phẩm để nâng cao chất lượng sử dụng.
>
> ### IX. TỔNG HỢP VÀ NHÂN RỘNG SẢN PHẨM
>
> Sau hoạt động, bộ phận chuyên môn tổng hợp những sản phẩm phù hợp để tiếp tục trao đổi, hoàn thiện, xây dựng nguồn học liệu dùng chung của nhà trường.
>
> Việc đưa đồ chơi, học liệu vào sử dụng chính thức tại các nhóm, lớp phải thực hiện theo quy trình lựa chọn và phê duyệt quy định tại Thông tư số 60/2026/TT-BGDĐT.
>
> Khuyến khích giáo viên tiếp tục cải tiến, bổ sung và chia sẻ các sản phẩm trong sinh hoạt chuyên môn định kỳ, góp phần nâng cao chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> **Trên đây là quy định tổ chức hoạt động giao lưu, trưng bày và chia sẻ “Sáng tạo học liệu số – Đồ dùng, đồ chơi thông minh” từ ngày 16/11/2026 đến ngày 30/11/2026. Đề nghị các tổ chuyên môn triển khai phù hợp điều kiện thực tế, bảo đảm tính tự nguyện, thiết thực và hiệu quả.**

### 💡 Lưu ý khi ban hành

Thông tư số 60/2026/TT-BGDĐT, có hiệu lực từ ngày 01/9/2026, quy định việc lựa chọn đồ chơi, học liệu sử dụng trong cơ sở giáo dục mầm non. Vì vậy, sản phẩm được trưng bày hoặc chia sẻ tại hoạt động chưa đồng nghĩa với việc được tự động phê duyệt sử dụng chính thức. [Source unavailable: turn756118search3]; [Source unavailable: turn480475view0]

**Đề xuất của tôi:** Nhà trường nên đưa hoạt động này vào nội dung sinh hoạt chuyên môn và buổi họp mặt ngày **30/11/2026**, tập trung vào giới thiệu, trải nghiệm, chia sẻ và nhân rộng sản phẩm. Cách tổ chức này vừa giữ được tinh thần đổi mới, sáng tạo của giáo viên, vừa phù hợp với định hướng giảm áp lực hội thi trong năm học 2026–2027.

---

USER

bạn làm rất tốt. tuy nhiên cần bổ sung thêm trao giải để khuyến khích tinh thần của các cô

---

ASSISTANT

Tôi sẽ bổ sung phần ghi nhận, khen thưởng để động viên các cô, đồng thời rà soát cách đặt tên giải và tiêu chí xét chọn để phù hợp với quy định về hoạt động làm đồ dùng, đồ chơi trong trường mầm non.

---

ASSISTANT

---

ASSISTANT

Tôi đồng ý nên có hình thức **tôn vinh và trao phần thưởng** để khích lệ tinh thần sáng tạo, ghi nhận sự đầu tư và đóng góp của giáo viên.

Tuy nhiên, có một điểm quan trọng: Công văn số 5922/BGDĐT-GDPT ngày 03/9/2026 của Bộ Giáo dục và Đào tạo quy định không tổ chức hội thi, phong trào giáo viên mầm non làm đồ dùng, đồ chơi; đồng thời khuyến khích giao lưu, chia sẻ sáng kiến và ứng dụng công nghệ số. [Source unavailable: turn651775search1]

Vì vậy, tôi đề xuất bổ sung **mục trao giải ghi nhận theo chủ đề**, không chấm điểm, không xếp Giải Nhất, Nhì, Ba và không sử dụng sản phẩm đồ chơi để đánh giá thi đua. Giáo viên vẫn được nhận giấy ghi nhận và phần quà động viên trong buổi họp mặt ngày 30/11/2026.

Dưới đây là nội dung bổ sung vào phụ lục, đặt sau Mục VII.

> **writing · document**
>
> **TRƯỜNG MẦM NON …………………**
>
> # PHỤ LỤC
> ## QUY ĐỊNH TỔ CHỨC HOẠT ĐỘNG GIAO LƯU, TRƯNG BÀY VÀ CHIA SẺ
> ## “SÁNG TẠO HỌC LIỆU SỐ – ĐỒ DÙNG, ĐỒ CHƠI THÔNG MINH”
>
> *Thời gian thực hiện: Từ ngày 16/11/2026 đến ngày 30/11/2026*
>
> *(Kèm theo Kế hoạch số …/KH-… ngày … tháng 11 năm 2026 của Trường Mầm non …………………)*
>
> ### I. MỤC ĐÍCH, YÊU CẦU
>
> **1. Mục đích**
>
> - Khuyến khích giáo viên phát huy tinh thần sáng tạo, chủ động ứng dụng công nghệ số trong thiết kế, khai thác và sử dụng học liệu, đồ dùng, đồ chơi phục vụ hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ.
> - Tạo điều kiện để giáo viên, các tổ chuyên môn giới thiệu, trao đổi kinh nghiệm và chia sẻ những sản phẩm có giá trị giáo dục, phù hợp điều kiện thực tế của nhà trường.
> - Góp phần xây dựng kho học liệu số dùng chung, nâng cao hiệu quả tổ chức các hoạt động giáo dục theo quan điểm lấy trẻ làm trung tâm.
> - Ghi nhận, biểu dương và động viên tinh thần đổi mới, sáng tạo, hợp tác và chia sẻ kinh nghiệm của đội ngũ giáo viên.
>
> **2. Yêu cầu**
>
> - Hoạt động được tổ chức trên tinh thần tự nguyện, thiết thực, tiết kiệm, không gây áp lực hoặc phát sinh hồ sơ, chi phí không cần thiết đối với giáo viên.
> - Sản phẩm phải phù hợp độ tuổi, mục tiêu giáo dục, bảo đảm tính khoa học, tính thẩm mỹ, an toàn và khả năng sử dụng thực tế.
> - Việc ứng dụng công nghệ số phải có giá trị hỗ trợ hoạt động giáo dục, không chạy theo hình thức hoặc lạm dụng thiết bị điện tử.
> - Khuyến khích chia sẻ, khai thác và cải tiến các sản phẩm đã có hiệu quả sử dụng; không bắt buộc giáo viên phải thiết kế sản phẩm mới.
>
> ### II. ĐỐI TƯỢNG VÀ HÌNH THỨC THAM GIA
>
> **1. Đối tượng**
>
> Giáo viên đang công tác tại nhà trường, tham gia theo hình thức cá nhân hoặc nhóm giáo viên có cùng ý tưởng thiết kế, xây dựng và khai thác sản phẩm.
>
> **2. Hình thức**
>
> - Cá nhân hoặc nhóm giáo viên tự nguyện đăng ký giới thiệu sản phẩm.
> - Các tổ chuyên môn lựa chọn, giới thiệu những sản phẩm tiêu biểu, có khả năng chia sẻ và áp dụng tại các nhóm, lớp.
> - Sản phẩm được giới thiệu thông qua trưng bày trực tiếp, trình chiếu, thao tác minh họa hoặc chia sẻ bằng đường liên kết, mã QR.
>
> ### III. NỘI DUNG VÀ LOẠI HÌNH SẢN PHẨM
>
> **1. Nội dung**
>
> Thiết kế, cải tiến hoặc khai thác học liệu số, đồ dùng, đồ chơi có ứng dụng công nghệ nhằm hỗ trợ trẻ học thông qua chơi, trải nghiệm, khám phá và tương tác tích cực.
>
> Nội dung gắn với các lĩnh vực phát triển của trẻ theo Chương trình Giáo dục mầm non, phù hợp đặc điểm tâm sinh lý và khả năng nhận thức của từng độ tuổi.
>
> **2. Các loại hình sản phẩm**
>
> a) **Trò chơi tương tác số:** Trò chơi nhận biết chữ cái, chữ số, màu sắc, hình dạng, phân loại, ghép đôi, tìm hiểu môi trường xung quanh hoặc phát triển các kỹ năng phù hợp độ tuổi; được thiết kế bằng PowerPoint hoặc phần mềm phù hợp.
>
> b) **Học liệu trực quan số:** Tranh ảnh tương tác, sách điện tử, câu chuyện số, bài trình chiếu, bộ thẻ học liệu có âm thanh, hình ảnh hoặc các tư liệu trực quan hỗ trợ giáo viên tổ chức hoạt động giáo dục.
>
> c) **Video giáo dục và hướng dẫn sử dụng đồ chơi:** Video giới thiệu cấu tạo, cách làm, cách sử dụng, tổ chức trò chơi hoặc hướng dẫn trẻ thực hiện các thao tác phù hợp.
>
> d) **Đồ dùng, đồ chơi tích hợp mã QR:** Sản phẩm có mã QR liên kết đến video hướng dẫn, trò chơi tương tác, âm thanh, câu chuyện, hình ảnh hoặc nội dung giáo dục bổ trợ.
>
> đ) **Sản phẩm kết hợp vật liệu sẵn có với công nghệ số:** Đồ dùng, đồ chơi tự tạo hoặc cải tiến từ vật liệu an toàn, dễ tìm, kết hợp học liệu số nhằm tăng khả năng tương tác, trải nghiệm và hứng thú của trẻ.
>
> ### IV. YÊU CẦU ĐỐI VỚI SẢN PHẨM
>
> **1. Về giá trị giáo dục**
>
> - Xác định rõ đối tượng sử dụng, độ tuổi, mục tiêu và nội dung giáo dục.
> - Phù hợp với khả năng nhận thức, nhu cầu, hứng thú của trẻ; tạo cơ hội cho trẻ được quan sát, thao tác, trải nghiệm và tương tác.
> - Có khả năng vận dụng vào một hoặc nhiều hoạt động chăm sóc, nuôi dưỡng, giáo dục tại lớp.
>
> **2. Về ứng dụng công nghệ số**
>
> - Có yếu tố ứng dụng công nghệ số rõ ràng, phù hợp mục đích sử dụng.
> - Hình ảnh, âm thanh, lời thoại rõ ràng; thao tác thuận tiện, dễ sử dụng.
> - Mã QR, đường liên kết, video hoặc tệp học liệu phải hoạt động khi giới thiệu.
> - Khuyến khích sản phẩm có thể sử dụng ngoại tuyến, không phụ thuộc hoàn toàn vào kết nối Internet.
> - Không sử dụng công nghệ chỉ mang tính trang trí, thiếu giá trị hỗ trợ giáo dục.
>
> **3. Về tính sáng tạo và khả thi**
>
> - Thể hiện ý tưởng sáng tạo hoặc giải pháp cải tiến có giá trị sử dụng.
> - Ưu tiên tận dụng thiết bị, phần mềm và vật liệu sẵn có, hạn chế chi phí phát sinh.
> - Dễ khai thác, bảo quản, điều chỉnh hoặc chia sẻ để giáo viên khác có thể sử dụng.
>
> **4. Về an toàn và bản quyền**
>
> - Đồ dùng, đồ chơi phải bảo đảm an toàn về vật liệu, cấu tạo, kích thước và cách sử dụng; không có chi tiết sắc nhọn, dễ gây thương tích hoặc nguy cơ mất an toàn đối với trẻ.
> - Học liệu số có nội dung lành mạnh, phù hợp văn hóa và thuần phong mỹ tục; không có quảng cáo hoặc đường liên kết không phù hợp.
> - Tôn trọng quyền tác giả, ghi rõ nguồn tài nguyên sử dụng khi cần thiết.
> - Bảo vệ thông tin, hình ảnh cá nhân của trẻ; việc sử dụng, chia sẻ hình ảnh hoặc video có trẻ phải tuân thủ quy định về bảo vệ dữ liệu cá nhân và quyền riêng tư của trẻ em.
>
> ### V. HỒ SƠ VÀ CÁCH THỨC GIỚI THIỆU SẢN PHẨM
>
> **1. Thành phần gửi giới thiệu**
>
> Mỗi cá nhân hoặc nhóm giáo viên gửi:
>
> - Tên sản phẩm; họ và tên người thực hiện; tổ chuyên môn.
> - Bản mô tả ngắn gọn về độ tuổi sử dụng, mục tiêu giáo dục, cách sử dụng và điểm sáng tạo của sản phẩm (khuyến khích trình bày không quá 01 trang A4).
> - Tệp sản phẩm số, video hoặc đường liên kết/mã QR truy cập sản phẩm.
> - Sản phẩm trực quan hoặc đồ dùng, đồ chơi thực tế (nếu có) để trưng bày, minh họa.
>
> **2. Hình thức tiếp nhận**
>
> Giáo viên gửi thông tin và sản phẩm về tổ trưởng chuyên môn. Tổ trưởng tổng hợp, chuyển bộ phận chuyên môn nhà trường để bố trí nội dung giới thiệu và trưng bày.
>
> **3. Hình thức chia sẻ tại buổi họp mặt**
>
> - Cá nhân hoặc đại diện nhóm giới thiệu sản phẩm trong khoảng 3–5 phút.
> - Minh họa thao tác sử dụng hoặc trình chiếu video, trò chơi, học liệu số.
> - Trao đổi cách khai thác, những thuận lợi, khó khăn và khả năng áp dụng tại các nhóm, lớp.
>
> ### VI. THỜI GIAN VÀ TIẾN ĐỘ THỰC HIỆN
>
> | Thời gian | Nội dung thực hiện | Bộ phận phụ trách |
> |---|---|---|
> | 16–18/11/2026 | Triển khai nội dung hoạt động; hướng dẫn giáo viên đăng ký, giới thiệu ý tưởng và sản phẩm | Ban giám hiệu, tổ chuyên môn |
> | 19–25/11/2026 | Giáo viên tự nguyện thiết kế, cải tiến, hoàn thiện sản phẩm; các tổ chuyên môn trao đổi, hỗ trợ | Giáo viên, nhóm thực hiện |
> | 26/11/2026 | Tiếp nhận thông tin và sản phẩm, hoàn thành trước 16 giờ | Tổ trưởng chuyên môn |
> | 27/11/2026 | Tổng hợp, rà soát nội dung và điều kiện an toàn; kiểm tra tệp trình chiếu, liên kết, mã QR; sắp xếp sản phẩm giới thiệu | Bộ phận chuyên môn, giáo viên phụ trách công nghệ |
> | 30/11/2026 | Tổ chức trưng bày, trình chiếu, giới thiệu, trao đổi kinh nghiệm; biểu dương, trao phần thưởng động viên và tổng hợp sản phẩm để tiếp tục chia sẻ | Ban giám hiệu, các tổ chuyên môn |
>
> ### VII. NỘI DUNG TRAO ĐỔI, NHẬN XÉT SẢN PHẨM
>
> Các sản phẩm được giới thiệu, trao đổi và góp ý dựa trên những nội dung sau:
>
> | STT | Nội dung | Yêu cầu xem xét |
> |---|---|---|
> | 1 | Tính giáo dục | Phù hợp độ tuổi, mục tiêu, nội dung giáo dục |
> | 2 | Tính sáng tạo | Có ý tưởng hoặc giải pháp cải tiến thiết thực |
> | 3 | Hiệu quả ứng dụng công nghệ số | Công nghệ hỗ trợ rõ ràng việc tổ chức hoạt động và tương tác |
> | 4 | Tính an toàn, thẩm mỹ | An toàn, hấp dẫn, dễ sử dụng, nội dung phù hợp |
> | 5 | Tính thực tiễn và khả năng chia sẻ | Dễ áp dụng, tiết kiệm, có khả năng nhân rộng |
>
> Việc nhận xét tập trung vào giá trị sử dụng và đề xuất điều chỉnh, hoàn thiện sản phẩm; **không tổ chức chấm điểm, xếp hạng hoặc trao giải thi đua đối với sản phẩm làm đồ dùng, đồ chơi.**
>
> ### VIII. HÌNH THỨC GHI NHẬN, TRAO GIẢI KHUYẾN KHÍCH VÀ ĐỘNG VIÊN
>
> **1. Mục đích**
>
> Ghi nhận tinh thần chủ động, sáng tạo, hợp tác và chia sẻ kinh nghiệm của giáo viên; tạo động lực để đội ngũ tiếp tục ứng dụng công nghệ số, đổi mới phương pháp tổ chức hoạt động giáo dục, góp phần nâng cao chất lượng chuyên môn của nhà trường.
>
> **2. Nguyên tắc thực hiện**
>
> - Việc ghi nhận, động viên được thực hiện trên tinh thần tự nguyện, công khai, tích cực và khuyến khích sự hợp tác.
> - Không tổ chức thi đua, chấm điểm, xếp hạng sản phẩm làm đồ dùng, đồ chơi hoặc sử dụng sản phẩm làm căn cứ đánh giá, xếp loại giáo viên.
> - Ưu tiên ghi nhận những đóng góp thực tế trong việc chia sẻ tài nguyên số, hướng dẫn đồng nghiệp, hỗ trợ tổ chuyên môn và lan tỏa kinh nghiệm ứng dụng công nghệ.
> - Không quy định số lượng giải cố định hoặc tạo sự cạnh tranh giữa cá nhân, nhóm giáo viên.
>
> **3. Các hình thức ghi nhận, trao giải khuyến khích**
>
> | STT | Tên hình thức ghi nhận | Nội dung |
> |---|---|---|
> | 1 | **Giải ghi nhận “Chia sẻ học liệu số sáng tạo”** | Dành cho cá nhân hoặc nhóm tích cực chia sẻ học liệu số, hướng dẫn sử dụng và hỗ trợ đồng nghiệp khai thác tài nguyên |
> | 2 | **Giải ghi nhận “Lan tỏa ứng dụng công nghệ”** | Dành cho cá nhân hoặc nhóm chủ động hướng dẫn, hỗ trợ giáo viên ứng dụng công nghệ số vào hoạt động giáo dục |
> | 3 | **Giải ghi nhận “Kết nối và hợp tác chuyên môn”** | Dành cho cá nhân hoặc nhóm có đóng góp tích cực trong trao đổi, góp ý, hỗ trợ đồng nghiệp và tổ chức chia sẻ kinh nghiệm |
> | 4 | **Quà tri ân tinh thần sáng tạo** | Dành cho các cá nhân, nhóm giáo viên tự nguyện tham gia giới thiệu và chia sẻ sản phẩm |
>
> Các tên gọi trên là hình thức ghi nhận nội bộ, không phải danh hiệu thi đua hoặc giải thưởng xếp hạng chất lượng sản phẩm đồ dùng, đồ chơi.
>
> **4. Hình thức trao tặng**
>
> - Giấy ghi nhận hoặc thư cảm ơn của nhà trường.
> - Phần quà lưu niệm hoặc phần thưởng động viên phù hợp với điều kiện kinh phí.
> - Tuyên dương tại buổi họp mặt, giới thiệu điển hình trong sinh hoạt chuyên môn và hoạt động truyền thông nội bộ của nhà trường.
>
> **5. Tổ chức ghi nhận, trao thưởng**
>
> - Ban giám hiệu phối hợp tổ chuyên môn tổng hợp những đóng góp trong quá trình giao lưu, chia sẻ.
> - Việc ghi nhận căn cứ vào tinh thần tham gia, hỗ trợ đồng nghiệp và đóng góp cho hoạt động chuyên môn; không dựa trên số lượng, chi phí hoặc việc xếp hạng chất lượng đồ dùng, đồ chơi.
> - Nội dung biểu dương và trao phần thưởng được thực hiện trong chương trình họp mặt ngày 30/11/2026.
> - Kinh phí thực hiện từ nguồn kinh phí hợp pháp của nhà trường, phù hợp quy chế chi tiêu nội bộ và các quy định liên quan; không bắt buộc giáo viên đóng góp.
>
> ### IX. TỔ CHỨC THỰC HIỆN
>
> **1. Ban giám hiệu**
>
> - Chỉ đạo triển khai hoạt động bảo đảm phù hợp kế hoạch chuyên môn và các quy định hiện hành.
> - Phân công bộ phận chuyên môn chuẩn bị địa điểm, phương tiện trình chiếu và điều kiện tổ chức.
> - Chỉ đạo thực hiện việc ghi nhận, biểu dương, trao phần thưởng động viên bảo đảm công khai, phù hợp quy định.
> - Chỉ đạo tổng hợp, lưu trữ, chia sẻ các sản phẩm phù hợp; thực hiện việc lựa chọn học liệu, đồ chơi để đưa vào sử dụng tại nhà trường theo quy định.
>
> **2. Các tổ chuyên môn**
>
> - Triển khai nội dung đến giáo viên, khuyến khích tham gia trên tinh thần tự nguyện.
> - Hỗ trợ giáo viên trao đổi ý tưởng, hoàn thiện sản phẩm.
> - Giới thiệu sản phẩm có tính ứng dụng cao, phù hợp nhu cầu chăm sóc, giáo dục trẻ tại các nhóm, lớp.
> - Tổ chức chia sẻ kinh nghiệm và đề xuất hình thức khai thác sản phẩm trong sinh hoạt chuyên môn.
> - Phối hợp ghi nhận những đóng góp tích cực của giáo viên trong hoạt động giao lưu, chia sẻ.
>
> **3. Giáo viên, nhóm thực hiện**
>
> - Chủ động lựa chọn nội dung, hình thức sản phẩm phù hợp khả năng và điều kiện thực tế.
> - Chịu trách nhiệm về tính chính xác, an toàn, nguồn gốc và quyền sử dụng các nội dung trong sản phẩm.
> - Chuẩn bị phần giới thiệu ngắn gọn, minh họa rõ cách sử dụng và hiệu quả giáo dục dự kiến.
> - Sẵn sàng chia sẻ, tiếp thu góp ý và điều chỉnh sản phẩm để nâng cao chất lượng sử dụng.
>
> ### X. TỔNG HỢP VÀ NHÂN RỘNG SẢN PHẨM
>
> Sau hoạt động, bộ phận chuyên môn tổng hợp những sản phẩm phù hợp để tiếp tục trao đổi, hoàn thiện, xây dựng nguồn học liệu dùng chung của nhà trường.
>
> Việc đưa đồ chơi, học liệu vào sử dụng chính thức tại các nhóm, lớp phải thực hiện theo quy trình lựa chọn và phê duyệt quy định tại Thông tư số 60/2026/TT-BGDĐT.
>
> Khuyến khích giáo viên tiếp tục cải tiến, bổ sung và chia sẻ các sản phẩm trong sinh hoạt chuyên môn định kỳ, góp phần nâng cao chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> **Trên đây là quy định tổ chức hoạt động giao lưu, trưng bày và chia sẻ “Sáng tạo học liệu số – Đồ dùng, đồ chơi thông minh” từ ngày 16/11/2026 đến ngày 30/11/2026. Đề nghị các tổ chuyên môn triển khai phù hợp điều kiện thực tế, bảo đảm tính tự nguyện, thiết thực và hiệu quả.**

💡 **Đề xuất thêm cho buổi họp mặt ngày 30/11:** Nhà trường có thể chuẩn bị giấy ghi nhận được thiết kế đẹp, có tên giáo viên hoặc nhóm giáo viên, kèm một phần quà nhỏ. Phần tuyên dương nên tập trung vào những đóng góp cụ thể, giúp các cô cảm nhận được sự trân trọng của nhà trường mà không tạo áp lực cạnh tranh thành tích.

Cách tổ chức này vẫn có nghi thức trao thưởng trang trọng, đồng thời tránh biến hoạt động giao lưu chuyên môn thành hội thi làm đồ dùng, đồ chơi trái với định hướng hiện hành.

---

USER

kế  hoạch tổ chức 20/11 sẽ kèm theo 2 phụ lục nội dung Thi nét đẹp và giao lưu chia sẻ sáng tạo học liệu số. bạn giúp mình hoàn chỉnh 2 nội dung này. bổ sung thêm phần khen thưởng động viên cho phần giao lưu, chia sẻ

---

ASSISTANT

Tôi đã đối chiếu ba tệp: Kế hoạch số 283/KH-MNAB ngày 13/11/2026, thể lệ thi ảnh và quy định giao lưu học liệu số. Tôi sẽ giữ cách chấm điểm, cơ cấu giải của hội thi ảnh; hoàn thiện phần ghi nhận, khen thưởng cho hoạt động giao lưu; đồng thời xử lý điểm chưa thống nhất là buổi họp mặt ngày 20/11 nhưng hoạt động học liệu số kéo dài đến 30/11.

---

ASSISTANT

---

ASSISTANT

Tôi đã rà soát và thống nhất nội dung của cả 3 văn bản Trường Mầm non An Bình cung cấp, lấy **Kế hoạch số 283/KH-MNAB ngày 13/11/2026** làm văn bản chính.

Đề xuất hoàn thiện thành 2 phụ lục:

1. **Phụ lục 01 – Thể lệ Hội thi ảnh “Khoảnh khắc yêu thương – Nét đẹp cô và trò mầm non”**: Giữ thang điểm 100, cơ cấu giải thưởng dự kiến 2.500.000 đồng và trao giải ngày 20/11/2026.
2. **Phụ lục 02 – Quy định hoạt động giao lưu, trưng bày và chia sẻ “Sáng tạo học liệu số – Đồ dùng, đồ chơi thông minh”**: Tổ chức từ ngày 16 đến 30/11/2026; bổ sung hình thức biểu dương, giấy ghi nhận, phần quà động viên và dự toán kinh phí.

**Một điểm cần thống nhất:** Kế hoạch chính tổ chức họp mặt lúc 14 giờ ngày 20/11, trong khi hoạt động học liệu số kết thúc ngày 30/11. Tôi đề xuất giới thiệu một số sản phẩm sẵn có trong buổi họp mặt 20/11 và tổ chức giao lưu, trưng bày, trao quà động viên chính thức vào ngày 30/11.

Theo Công văn 5922/BGDĐT-GDPT ngày 03/9/2026, giáo dục mầm non không tổ chức hội thi, phong trào giáo viên làm đồ dùng, đồ chơi; hình thức giao lưu, chia sẻ tự nguyện được khuyến khích. Vì vậy, phụ lục thứ hai sẽ **khen thưởng những đóng góp trong chia sẻ, hỗ trợ chuyên môn**, không chấm giải sản phẩm đồ chơi. Hội thi ảnh cũng cần được rà soát điều kiện tổ chức, thẩm quyền cho phép trước khi triển khai chấm giải. [Yêu cầu cơ sở giáo dục rà soát, cắt giảm các cuộc thi, hội thi](<https://xaydungchinhsach.chinhphu.vn/khong-to-chuc-hoi-thi-giao-vien-day-gioi-cap-truong-cap-xa-de-lay-thanh-tich-119260904180900716.htm>); [Công văn 5922/BGDĐT\-GDPT 2026 cắt giảm các cuộc thi hội họp báo cáo trung gian cơ sở giáo dục](<https://thuvienphapluat.vn/cong-van/Giao-duc/Cong-van-5922-BGDDT-GDPT-2026-cat-giam-cac-cuoc-thi-hoi-hop-bao-cao-trung-gian-co-so-giao-duc-723435.aspx?ac=emails>)

Dưới đây là hai phụ lục đã biên tập theo văn phong hành chính để đưa vào hồ sơ của nhà trường.

## PHỤ LỤC 01 – THỂ LỆ HỘI THI ẢNH

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**
>
> **TRƯỜNG MẦM NON AN BÌNH**
>
> # PHỤ LỤC 01
> ## THỂ LỆ HỘI THI ẢNH
> ## “KHOẢNH KHẮC YÊU THƯƠNG – NÉT ĐẸP CÔ VÀ TRÒ MẦM NON”
>
> *Chào mừng kỷ niệm 44 năm Ngày Nhà giáo Việt Nam (20/11/1982 – 20/11/2026)*
>
> *(Kèm theo Kế hoạch số 283/KH-MNAB ngày 13 tháng 11 năm 2026 của Trường Mầm non An Bình)*
>
> ### I. MỤC ĐÍCH, YÊU CẦU
>
> **1. Mục đích**
>
> - Tôn vinh hình ảnh người giáo viên mầm non tận tâm, trách nhiệm, yêu nghề, mến trẻ thông qua những khoảnh khắc chân thực, giàu cảm xúc trong hoạt động chăm sóc, nuôi dưỡng và giáo dục trẻ.
> - Ghi nhận, lan tỏa những việc làm đẹp, tình yêu thương đối với trẻ, tinh thần đoàn kết, trách nhiệm và sự sáng tạo của đội ngũ giáo viên tại ba điểm trường An Bình, An Lộc và An Bình A.
> - Tạo không khí vui tươi, phấn khởi, tăng cường sự gắn kết trong tập thể sư phạm nhân kỷ niệm Ngày Nhà giáo Việt Nam 20/11.
> - Xây dựng nguồn tư liệu hình ảnh phục vụ công tác truyền thông, giới thiệu những hoạt động và nét đẹp văn hóa của nhà trường.
>
> **2. Yêu cầu**
>
> - Hình ảnh dự thi phải chân thực, có ý nghĩa giáo dục, phản ánh đúng hoạt động thực tế của giáo viên và trẻ.
> - Việc tham gia trên tinh thần tự nguyện, không gây áp lực, không ảnh hưởng nhiệm vụ chăm sóc, nuôi dưỡng, giáo dục trẻ.
> - Bảo đảm công khai, công bằng, khách quan trong tiếp nhận, bình chọn và đánh giá tác phẩm.
> - Thực hiện nghiêm các quy định về bảo vệ thông tin cá nhân, quyền riêng tư và quyền hình ảnh của trẻ.
> - Việc tổ chức chấm giải được thực hiện khi đáp ứng điều kiện tổ chức hội thi theo quy định và chủ trương hiện hành của ngành.
>
> ### II. ĐỐI TƯỢNG, CHỦ ĐỀ VÀ HÌNH THỨC THAM GIA
>
> **1. Đối tượng**
>
> Giáo viên đang công tác tại Trường Mầm non An Bình, thuộc ba điểm trường An Bình, An Lộc và An Bình A.
>
> **2. Chủ đề**
>
> **“Khoảnh khắc đẹp – Tình yêu nghề mầm non”.**
>
> **3. Nội dung**
>
> Hình ảnh dự thi thể hiện một hoặc nhiều nội dung sau:
>
> - Nét đẹp của giáo viên trong hoạt động đón trẻ, chăm sóc bữa ăn, giấc ngủ, vệ sinh và bảo đảm an toàn cho trẻ.
> - Khoảnh khắc cô và trẻ cùng tham gia hoạt động học, vui chơi, khám phá, trải nghiệm.
> - Tình yêu thương, sự gần gũi, quan tâm, tôn trọng và khích lệ trẻ.
> - Sự sáng tạo, đổi mới trong tổ chức môi trường và hoạt động giáo dục.
> - Tinh thần đoàn kết, phối hợp, hỗ trợ đồng nghiệp trong thực hiện nhiệm vụ.
>
> **4. Hình thức dự thi**
>
> - Thi ảnh cá nhân.
> - Mỗi giáo viên gửi tối đa 02 ảnh để Ban Tổ chức lựa chọn 01 ảnh hợp lệ tham gia chấm giải.
> - Ảnh hợp lệ được đăng tải trên trang Facebook chính thức của nhà trường theo cùng một thời điểm để tổ chức bình chọn trực tuyến.
> - Mỗi tác phẩm được đánh giá kết hợp giữa điểm chuyên môn của Ban Giám khảo và điểm bình chọn trực tuyến.
>
> ### III. QUY ĐỊNH ĐỐI VỚI TÁC PHẨM DỰ THI
>
> **1. Yêu cầu về ảnh**
>
> - Ảnh được chụp trong năm học 2026–2027 tại Trường Mầm non An Bình, thể hiện hoạt động thực tế của giáo viên.
> - Ảnh rõ nét, bố cục hài hòa, ánh sáng phù hợp, nội dung tích cực, có giá trị truyền cảm hứng.
> - Không sử dụng ảnh lấy từ Internet, ảnh được tạo bằng trí tuệ nhân tạo hoặc ảnh đã qua chỉnh sửa làm sai lệch nội dung thực tế.
> - Được phép điều chỉnh độ sáng, màu sắc và cắt cúp hợp lý nhưng không được thay đổi bản chất hình ảnh.
> - Không sử dụng ảnh có nội dung phản cảm, vi phạm đạo đức nhà giáo hoặc không bảo đảm an toàn, quyền riêng tư của trẻ.
>
> **2. Yêu cầu về quyền sử dụng hình ảnh**
>
> - Ảnh có hình ảnh nhận diện trẻ phải bảo đảm điều kiện đồng ý hợp lệ của cha mẹ hoặc người giám hộ và các quy định có liên quan trước khi công bố trên mạng xã hội.
> - Không đăng tải thông tin cá nhân, hoàn cảnh riêng tư hoặc những hình ảnh có thể ảnh hưởng đến danh dự, nhân phẩm và sự an toàn của trẻ.
> - Ban Tổ chức có quyền từ chối đăng tải tác phẩm không đáp ứng yêu cầu về quyền riêng tư và điều kiện sử dụng hình ảnh.
>
> **3. Hồ sơ dự thi**
>
> Mỗi giáo viên gửi:
>
> - Ảnh dự thi dưới dạng tệp hình ảnh có chất lượng rõ nét.
> - Tên tác phẩm.
> - Lời giới thiệu ngắn gọn, từ 80 đến 150 từ, thể hiện ý nghĩa của hình ảnh.
> - Họ và tên giáo viên, lớp, điểm trường đang công tác.
>
> Hồ sơ gửi về Ban Truyền thông nhà trường thông qua tổ trưởng chuyên môn hoặc phương thức tiếp nhận do Ban Tổ chức thông báo.
>
> ### IV. TIÊU CHÍ VÀ PHƯƠNG PHÁP CHẤM ĐIỂM
>
> **1. Thang điểm đánh giá**
>
> Tổng điểm tối đa của mỗi tác phẩm là **100 điểm**.
>
> | STT | Tiêu chí | Điểm tối đa |
> |---|---|---:|
> | 1 | Nội dung bám sát chủ đề, phản ánh đúng hoạt động nghề nghiệp của giáo viên | 20 |
> | 2 | Thể hiện tình yêu thương, sự tận tâm và trách nhiệm nghề nghiệp | 25 |
> | 3 | Khoảnh khắc tự nhiên, chân thực, giàu cảm xúc | 15 |
> | 4 | Bố cục, ánh sáng, chất lượng hình ảnh | 10 |
> | 5 | Tên tác phẩm và lời giới thiệu phù hợp, có ý nghĩa | 10 |
> | 6 | Điểm bình chọn trực tuyến hợp lệ | 20 |
> | | **TỔNG CỘNG** | **100** |
>
> **2. Điểm Ban Giám khảo**
>
> - Ban Giám khảo đánh giá độc lập theo 05 tiêu chí đầu, tổng điểm tối đa 80 điểm.
> - Điểm chuyên môn của tác phẩm là trung bình cộng điểm của các thành viên Ban Giám khảo, làm tròn đến 02 chữ số thập phân.
> - Các thành viên Ban Giám khảo chấm điểm khách quan, đúng tiêu chí và chịu trách nhiệm về kết quả đánh giá.
>
> **3. Điểm bình chọn trực tuyến**
>
> Điểm bình chọn tối đa 20 điểm, căn cứ vào tổng lượt cảm xúc hợp lệ trên bài đăng chính thức của tác phẩm tại trang Facebook nhà trường.
>
> | Số lượt cảm xúc hợp lệ | Điểm bình chọn |
> |---|---:|
> | Từ 300 lượt trở lên | 20 |
> | Từ 200 đến 299 lượt | 15 |
> | Từ 100 đến 199 lượt | 10 |
> | Từ 50 đến 99 lượt | 5 |
> | Dưới 50 lượt | 2 |
>
> **Quy định về bình chọn:**
>
> - Chỉ tính các lượt cảm xúc hợp lệ trực tiếp trên bài đăng chính thức.
> - Không tính bình luận và lượt chia sẻ.
> - Không chấp nhận hành vi mua tương tác, sử dụng tài khoản ảo hoặc hình thức gian lận khác có căn cứ xác minh.
> - Ban Truyền thông thống kê, chụp và lưu minh chứng kết quả tại thời điểm khóa bình chọn.
> - Các tác phẩm được đăng trong cùng một thời điểm và áp dụng chung thời hạn bình chọn.
>
> **4. Phương pháp xếp giải**
>
> Tổng điểm xếp giải = Điểm trung bình của Ban Giám khảo + Điểm bình chọn trực tuyến.
>
> - Xếp giải theo tổng điểm từ cao xuống thấp.
> - Nếu bằng tổng điểm, ưu tiên tác phẩm có điểm Ban Giám khảo cao hơn.
> - Nếu vẫn bằng điểm, ưu tiên tác phẩm có điểm tiêu chí “Thể hiện tình yêu thương, sự tận tâm và trách nhiệm nghề nghiệp” cao hơn.
> - Những trường hợp đặc biệt do Ban Tổ chức xem xét, quyết định và lập biên bản.
>
> **5. Giải “Ảnh được yêu thích nhất”**
>
> Trao cho tác phẩm có số lượt cảm xúc hợp lệ cao nhất tại thời điểm khóa bình chọn.
>
> Tác phẩm nhận giải này vẫn được tham gia xét các giải Nhất, Nhì, Ba hoặc Khuyến khích.
>
> ### V. CƠ CẤU GIẢI THƯỞNG DỰ KIẾN
>
> | Giải thưởng | Số lượng | Mức thưởng | Thành tiền |
> |---|---:|---:|---:|
> | Giải Nhất | 01 | 500.000đ | 500.000đ |
> | Giải Nhì | 02 | 300.000đ | 600.000đ |
> | Giải Ba | 03 | 200.000đ | 600.000đ |
> | Giải Khuyến khích | 05 | 100.000đ | 500.000đ |
> | Ảnh được yêu thích nhất | 01 | 300.000đ | 300.000đ |
> | **Tổng cộng** | **12** | | **2.500.000đ** |
>
> Giáo viên được công nhận giải thưởng sẽ nhận giấy chứng nhận hoặc hình thức ghi nhận phù hợp và phần thưởng theo cơ cấu được phê duyệt.
>
> Cơ cấu giải thưởng có thể điều chỉnh căn cứ số lượng tác phẩm hợp lệ, chất lượng ảnh dự thi và nguồn kinh phí hợp pháp của nhà trường.
>
> ### VI. THỜI GIAN TỔ CHỨC
>
> | Thời gian | Nội dung thực hiện |
> |---|---|
> | 15–16/11/2026 | Triển khai thể lệ, hướng dẫn và tiếp nhận ảnh dự thi |
> | 17/11/2026 | Kiểm tra tính hợp lệ và đăng đồng loạt tác phẩm dự thi |
> | 17–19/11/2026 | Tổ chức bình chọn trực tuyến |
> | 19/11/2026 | Khóa bình chọn, chấm điểm chuyên môn, tổng hợp và xét kết quả |
> | 20/11/2026 | Công bố kết quả, biểu dương và trao thưởng tại buổi họp mặt kỷ niệm Ngày Nhà giáo Việt Nam |
>
> Thời điểm bắt đầu và kết thúc bình chọn trong ngày do Ban Tổ chức thông báo thống nhất, công khai trước khi đăng tải tác phẩm.
>
> ### VII. PHÂN CÔNG TỔ CHỨC THỰC HIỆN
>
> **1. Hiệu trưởng**
>
> Chỉ đạo chung; phê duyệt thể lệ, thành lập Ban Tổ chức, Ban Giám khảo; xem xét và quyết định công nhận kết quả, trao thưởng theo quy định.
>
> **2. Phó Hiệu trưởng phụ trách giáo dục**
>
> Tham mưu tổ chức; hướng dẫn các tổ chuyên môn triển khai; theo dõi tiến độ, kiểm tra việc thực hiện; tổng hợp kết quả báo cáo Hiệu trưởng.
>
> **3. Ban Truyền thông**
>
> Tiếp nhận ảnh và lời giới thiệu; rà soát tính hợp lệ và điều kiện sử dụng hình ảnh; đăng tải tác phẩm đồng loạt; theo dõi bình chọn, lưu minh chứng và tổng hợp số liệu.
>
> **4. Các tổ trưởng chuyên môn**
>
> Phổ biến thể lệ đến giáo viên; hướng dẫn hoàn thiện hồ sơ dự thi; phối hợp tiếp nhận và chuyển tác phẩm đúng thời hạn.
>
> **5. Ban Giám khảo**
>
> Thực hiện chấm điểm độc lập, khách quan; lập phiếu chấm và biên bản tổng hợp kết quả; đề xuất danh sách xét giải.
>
> **6. Bộ phận kế toán và hậu cần**
>
> Tham mưu nguồn kinh phí hợp pháp; chuẩn bị giấy chứng nhận, phần thưởng và các điều kiện phục vụ trao giải; thực hiện thủ tục tài chính theo quy định.
>
> ### VIII. TỔNG KẾT VÀ SỬ DỤNG TÁC PHẨM
>
> - Kết quả Hội thi được công bố trong chương trình họp mặt kỷ niệm Ngày Nhà giáo Việt Nam ngày 20/11/2026.
> - Những hình ảnh tiêu biểu, đáp ứng đầy đủ điều kiện sử dụng, được lựa chọn trưng bày, trình chiếu và lưu trữ phục vụ công tác truyền thông của nhà trường.
> - Ban Tổ chức tổng hợp kết quả, minh chứng và hồ sơ liên quan theo quy định.
>
> **Trên đây là Thể lệ Hội thi ảnh “Khoảnh khắc yêu thương – Nét đẹp cô và trò mầm non” chào mừng Ngày Nhà giáo Việt Nam 20/11/2026 của Trường Mầm non An Bình. Đề nghị các bộ phận, tổ chuyên môn và giáo viên phối hợp triển khai thực hiện.**

---

## PHỤ LỤC 02 – GIAO LƯU, CHIA SẺ SÁNG TẠO HỌC LIỆU SỐ

Phần này được hoàn chỉnh theo hướng tăng tính ứng dụng chuyên môn và có **khen thưởng động viên cụ thể**, không biến thành hoạt động thi làm đồ dùng, đồ chơi.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**
>
> **TRƯỜNG MẦM NON AN BÌNH**
>
> # PHỤ LỤC 02
> ## QUY ĐỊNH TỔ CHỨC HOẠT ĐỘNG GIAO LƯU, TRƯNG BÀY VÀ CHIA SẺ
> ## “SÁNG TẠO HỌC LIỆU SỐ – ĐỒ DÙNG, ĐỒ CHƠI THÔNG MINH”
>
> *Thời gian thực hiện: Từ ngày 16/11/2026 đến ngày 30/11/2026*
>
> *(Kèm theo Kế hoạch số 283/KH-MNAB ngày 13 tháng 11 năm 2026 của Trường Mầm non An Bình)*
>
> ### I. MỤC ĐÍCH, YÊU CẦU
>
> **1. Mục đích**
>
> - Khuyến khích giáo viên phát huy năng lực sáng tạo, chủ động ứng dụng công nghệ số trong thiết kế, khai thác và sử dụng học liệu, đồ dùng, đồ chơi phục vụ hoạt động chăm sóc, nuôi dưỡng và giáo dục trẻ.
> - Tạo diễn đàn để giáo viên và các tổ chuyên môn giới thiệu ý tưởng, trao đổi kinh nghiệm, chia sẻ những sản phẩm có giá trị giáo dục và khả năng áp dụng tại các nhóm, lớp.
> - Góp phần nâng cao năng lực chuyển đổi số của đội ngũ, đổi mới phương pháp tổ chức hoạt động giáo dục theo quan điểm lấy trẻ làm trung tâm.
> - Từng bước xây dựng kho học liệu số dùng chung của nhà trường, tạo điều kiện để giáo viên tiếp cận, khai thác và sử dụng hiệu quả các sản phẩm phù hợp.
> - Ghi nhận, biểu dương và động viên tinh thần tự học, sáng tạo, hợp tác và chia sẻ chuyên môn của giáo viên tại ba điểm trường An Bình, An Lộc và An Bình A.
>
> **2. Yêu cầu**
>
> - Hoạt động được tổ chức trên tinh thần tự nguyện, thiết thực, tiết kiệm, không gây áp lực hoặc phát sinh hồ sơ, kinh phí không cần thiết đối với giáo viên.
> - Sản phẩm giới thiệu phải phù hợp độ tuổi, mục tiêu giáo dục, có tính an toàn, thẩm mỹ, khả thi và giá trị sử dụng thực tế.
> - Công nghệ số được sử dụng phù hợp, có tác dụng hỗ trợ hoạt động giáo dục, không chạy theo hình thức hoặc lạm dụng thiết bị điện tử.
> - Khuyến khích chia sẻ những sản phẩm đang sử dụng hiệu quả, không bắt buộc giáo viên phải làm mới đồ dùng, đồ chơi.
> - Việc biểu dương, khen thưởng tập trung ghi nhận tinh thần tham gia, chia sẻ, hỗ trợ đồng nghiệp và đóng góp cho hoạt động chuyên môn; không chấm điểm, xếp hạng sản phẩm đồ dùng, đồ chơi.
>
> ### II. ĐỐI TƯỢNG VÀ HÌNH THỨC THAM GIA
>
> **1. Đối tượng**
>
> Giáo viên đang công tác tại Trường Mầm non An Bình, tham gia theo hình thức cá nhân hoặc nhóm giáo viên.
>
> **2. Hình thức tham gia**
>
> - Giáo viên tự nguyện đăng ký giới thiệu một hoặc nhiều ý tưởng, sản phẩm học liệu số, đồ dùng, đồ chơi có ứng dụng công nghệ.
> - Các tổ chuyên môn khuyến khích giáo viên trao đổi, hỗ trợ nhau hoàn thiện hoặc cải tiến sản phẩm.
> - Tổ chuyên môn tổng hợp những sản phẩm phù hợp để giới thiệu, trưng bày và chia sẻ trong hoạt động chung của nhà trường.
> - Sản phẩm được giới thiệu trực tiếp, trình chiếu, thao tác minh họa hoặc chia sẻ thông qua mã QR, đường liên kết và kho học liệu dùng chung.
>
> ### III. NỘI DUNG, LOẠI HÌNH VÀ YÊU CẦU ĐỐI VỚI SẢN PHẨM
>
> **1. Nội dung**
>
> Thiết kế, cải tiến, khai thác hoặc chia sẻ những học liệu, đồ dùng, đồ chơi có ứng dụng công nghệ số phục vụ hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ; tạo điều kiện để trẻ được học thông qua chơi, khám phá, trải nghiệm và tương tác tích cực.
>
> Sản phẩm gắn với các lĩnh vực phát triển thể chất, nhận thức, ngôn ngữ, tình cảm và kỹ năng xã hội, thẩm mỹ; phù hợp đặc điểm tâm sinh lý và khả năng của trẻ ở từng độ tuổi.
>
> **2. Các loại hình sản phẩm**
>
> a) **Trò chơi tương tác số:** Trò chơi nhận biết chữ cái, chữ số, màu sắc, hình dạng; phân loại, ghép đôi, nhận biết môi trường xung quanh, phát triển ngôn ngữ và các kỹ năng phù hợp độ tuổi.
>
> b) **Học liệu trực quan số:** Tranh ảnh tương tác, sách điện tử, câu chuyện số, bài trình chiếu, thẻ học liệu có âm thanh, hình ảnh và các tư liệu trực quan hỗ trợ tổ chức hoạt động giáo dục.
>
> c) **Video giáo dục và hướng dẫn sử dụng đồ chơi:** Video giới thiệu cấu tạo, cách làm, cách sử dụng, cách tổ chức trò chơi hoặc hướng dẫn các thao tác đơn giản, phù hợp với trẻ.
>
> d) **Đồ dùng, đồ chơi tích hợp mã QR:** Sản phẩm có mã QR liên kết đến video hướng dẫn, âm thanh, trò chơi tương tác, câu chuyện hoặc nội dung giáo dục bổ trợ.
>
> đ) **Sản phẩm kết hợp vật liệu sẵn có với công nghệ số:** Đồ dùng, đồ chơi tự tạo hoặc cải tiến từ vật liệu an toàn, dễ tìm, kết hợp học liệu số nhằm tăng tính trực quan, tương tác và khả năng trải nghiệm của trẻ.
>
> **3. Yêu cầu đối với sản phẩm**
>
> **3.1. Tính giáo dục**
>
> - Có mục tiêu giáo dục rõ ràng, phù hợp độ tuổi và nội dung Chương trình Giáo dục mầm non.
> - Khuyến khích trẻ tích cực tham gia hoạt động, thao tác và trải nghiệm.
> - Hỗ trợ giáo viên tổ chức một hoặc nhiều hoạt động chăm sóc, nuôi dưỡng, giáo dục.
>
> **3.2. Tính sáng tạo và ứng dụng công nghệ**
>
> - Có ý tưởng, giải pháp thiết kế, cải tiến hoặc cách khai thác sáng tạo.
> - Việc ứng dụng công nghệ phải góp phần tăng tính trực quan, hỗ trợ tương tác hoặc nâng cao hiệu quả tổ chức hoạt động giáo dục.
> - Hình ảnh, âm thanh, lời thoại rõ ràng; nội dung và thao tác sử dụng phù hợp.
> - Đường liên kết, mã QR và tệp học liệu có khả năng truy cập, sử dụng thuận tiện.
>
> **3.3. Tính thực tiễn**
>
> - Dễ sử dụng, dễ bảo quản, phù hợp với trang thiết bị và điều kiện của nhà trường.
> - Có khả năng áp dụng thực tế tại các nhóm, lớp.
> - Khuyến khích tận dụng vật liệu, thiết bị và phần mềm sẵn có, hạn chế chi phí phát sinh.
> - Có thể chia sẻ, điều chỉnh hoặc phát triển để đồng nghiệp cùng khai thác.
>
> **3.4. Tính an toàn và phù hợp**
>
> - Bảo đảm an toàn khi sử dụng đồ dùng, đồ chơi; không có vật liệu độc hại, chi tiết sắc nhọn hoặc nguy cơ gây thương tích.
> - Nội dung số phù hợp văn hóa, thuần phong mỹ tục và đặc điểm tâm lý trẻ mầm non.
> - Không có quảng cáo, hình ảnh hoặc đường liên kết không phù hợp.
> - Tôn trọng quyền tác giả và nguồn tài nguyên sử dụng.
> - Bảo đảm quyền riêng tư, bảo vệ hình ảnh và dữ liệu cá nhân của trẻ theo quy định.
>
> ### IV. HỒ SƠ VÀ CÁCH THỨC GIỚI THIỆU, CHIA SẺ SẢN PHẨM
>
> **1. Nội dung gửi giới thiệu**
>
> Mỗi cá nhân hoặc nhóm tham gia chuẩn bị:
>
> - Tên sản phẩm, họ tên giáo viên hoặc các thành viên trong nhóm, tổ chuyên môn.
> - Thông tin ngắn gọn về độ tuổi sử dụng, mục tiêu giáo dục, cách sử dụng và điểm nổi bật của sản phẩm.
> - Tệp học liệu số, video, đường liên kết hoặc mã QR truy cập.
> - Sản phẩm trực quan, đồ dùng, đồ chơi thực tế nếu có.
>
> Không yêu cầu xây dựng hồ sơ phức tạp; khuyến khích bản mô tả ngắn gọn, tối đa 01 trang A4 hoặc trình bày trực tiếp khi giới thiệu.
>
> **2. Cách thức tiếp nhận**
>
> Giáo viên gửi thông tin, sản phẩm về tổ trưởng chuyên môn. Tổ trưởng tổng hợp, phối hợp bộ phận chuyên môn sắp xếp nội dung giới thiệu, trình chiếu và trưng bày.
>
> **3. Hình thức giao lưu, chia sẻ**
>
> - Cá nhân hoặc đại diện nhóm trình bày sản phẩm trong khoảng 3–5 phút.
> - Giới thiệu mục tiêu giáo dục, đối tượng sử dụng, thao tác thực hiện và cách tổ chức hoạt động với trẻ.
> - Minh họa bằng sản phẩm thực tế, trò chơi tương tác, video hoặc học liệu trình chiếu.
> - Trao đổi thuận lợi, khó khăn, kinh nghiệm sử dụng và những điểm có thể cải tiến.
> - Chia sẻ sản phẩm phù hợp để giáo viên các nhóm, lớp tham khảo, sử dụng theo quy định.
>
> ### V. THỜI GIAN VÀ TIẾN ĐỘ THỰC HIỆN
>
> | Thời gian | Nội dung thực hiện | Bộ phận phụ trách |
> |---|---|---|
> | 16–18/11/2026 | Triển khai hoạt động; hướng dẫn giáo viên đăng ký, giới thiệu ý tưởng và sản phẩm | Ban giám hiệu, tổ chuyên môn |
> | 19–25/11/2026 | Giáo viên tự nguyện thiết kế, cải tiến, hoàn thiện sản phẩm; các tổ hỗ trợ, trao đổi kinh nghiệm | Giáo viên, nhóm thực hiện |
> | 26/11/2026 | Tiếp nhận thông tin, sản phẩm; hoàn thành trước 16 giờ | Tổ trưởng chuyên môn |
> | 27/11/2026 | Rà soát nội dung, tính an toàn; kiểm tra mã QR, tệp trình chiếu, đường liên kết | Bộ phận chuyên môn, giáo viên phụ trách công nghệ |
> | 28–29/11/2026 | Tổng hợp, sắp xếp, chuẩn bị sản phẩm và phương tiện giới thiệu | Ban giám hiệu, các tổ chuyên môn |
> | 30/11/2026 | Tổ chức giao lưu, trưng bày, chia sẻ; biểu dương, trao quà động viên và tổng hợp sản phẩm để tiếp tục khai thác | Ban giám hiệu, các tổ chuyên môn |
>
> Đối với buổi họp mặt kỷ niệm Ngày Nhà giáo Việt Nam ngày 20/11/2026, nhà trường có thể giới thiệu một số hình ảnh, ý tưởng hoặc sản phẩm đã sẵn có. Hoạt động giao lưu, chia sẻ và biểu dương tổng kết được tổ chức vào ngày 30/11/2026.
>
> ### VI. NỘI DUNG TRAO ĐỔI, NHẬN XÉT SẢN PHẨM
>
> Việc trao đổi, nhận xét tập trung vào các nội dung sau:
>
> | STT | Nội dung | Yêu cầu xem xét |
> |---|---|---|
> | 1 | Giá trị giáo dục | Phù hợp độ tuổi, mục tiêu và nội dung giáo dục |
> | 2 | Tính sáng tạo | Có ý tưởng, giải pháp cải tiến hoặc cách sử dụng thiết thực |
> | 3 | Hiệu quả ứng dụng công nghệ số | Công nghệ có tác dụng hỗ trợ hoạt động giáo dục |
> | 4 | Tính an toàn, thẩm mỹ | An toàn, hấp dẫn, phù hợp đặc điểm trẻ mầm non |
> | 5 | Tính thực tiễn, khả năng chia sẻ | Dễ sử dụng, tiết kiệm, có khả năng áp dụng tại lớp |
>
> Các nội dung trên được sử dụng để trao đổi, góp ý, hoàn thiện và giới thiệu cách khai thác sản phẩm; không tổ chức chấm điểm, xếp hạng hoặc xét giải thi đua đối với đồ dùng, đồ chơi.
>
> ### VII. BIỂU DƯƠNG, KHEN THƯỞNG VÀ ĐỘNG VIÊN
>
> **1. Mục đích**
>
> Ghi nhận những đóng góp tích cực của giáo viên trong hoạt động chia sẻ học liệu số, hỗ trợ đồng nghiệp và lan tỏa kinh nghiệm ứng dụng công nghệ vào chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Kịp thời động viên tinh thần tự học, sáng tạo, trách nhiệm và hợp tác, góp phần xây dựng môi trường chuyên môn tích cực, đoàn kết, cùng phát triển.
>
> **2. Nguyên tắc thực hiện**
>
> - Bảo đảm công khai, thiết thực, phù hợp điều kiện thực tế của nhà trường.
> - Ghi nhận đóng góp trong hoạt động chia sẻ, hỗ trợ chuyên môn; không lấy chất lượng, số lượng hoặc mức độ đầu tư đồ dùng, đồ chơi làm căn cứ xếp hạng.
> - Không sử dụng sản phẩm làm đồ dùng, đồ chơi làm căn cứ đánh giá, xếp loại hoặc thi đua đối với giáo viên khi không có quy định của cấp có thẩm quyền.
> - Việc tham gia và nhận ghi nhận không mang tính bắt buộc, không tạo áp lực cạnh tranh giữa giáo viên và các tổ chuyên môn.
>
> **3. Các hình thức biểu dương, ghi nhận**
>
> **a) Biểu dương “Tinh thần sáng tạo và chia sẻ học liệu số”**
>
> Dành cho cá nhân hoặc nhóm giáo viên tích cực giới thiệu, chia sẻ tài nguyên số, kinh nghiệm thiết kế, khai thác và hướng dẫn đồng nghiệp sử dụng học liệu trong hoạt động giáo dục.
>
> **b) Biểu dương “Lan tỏa ứng dụng công nghệ trong giáo dục”**
>
> Dành cho cá nhân hoặc nhóm giáo viên có đóng góp tích cực trong hướng dẫn, hỗ trợ đồng nghiệp tiếp cận, ứng dụng công nghệ số và nâng cao năng lực sử dụng học liệu.
>
> **c) Biểu dương “Đồng hành và hợp tác chuyên môn”**
>
> Dành cho cá nhân hoặc nhóm giáo viên tích cực hỗ trợ, góp ý, chia sẻ kinh nghiệm, phối hợp tổ chức hoạt động giao lưu và xây dựng nguồn học liệu dùng chung.
>
> **d) Quà động viên giáo viên tham gia giao lưu, chia sẻ**
>
> Dành cho các cá nhân hoặc nhóm giáo viên tự nguyện tham gia giới thiệu, hướng dẫn sử dụng và chia sẻ kinh nghiệm, góp phần tạo không khí tích cực trong hoạt động chuyên môn.
>
> **4. Hình thức khen thưởng, động viên**
>
> - Tặng giấy ghi nhận hoặc thư cảm ơn đối với cá nhân, nhóm có đóng góp tích cực.
> - Trao phần quà lưu niệm, phần thưởng động viên phù hợp khả năng kinh phí của nhà trường.
> - Biểu dương công khai tại buổi giao lưu, tổng kết ngày 30/11/2026.
> - Giới thiệu các hoạt động, cách làm hiệu quả trong sinh hoạt chuyên môn và truyền thông nội bộ của nhà trường.
>
> Các hình thức biểu dương nêu trên là ghi nhận đóng góp chuyên môn, không phải giải thưởng xếp hạng sản phẩm làm đồ dùng, đồ chơi.
>
> **5. Cách thức đề xuất và ghi nhận**
>
> - Tổ trưởng chuyên môn tổng hợp, giới thiệu cá nhân hoặc nhóm có đóng góp thực tế trong việc chia sẻ, hỗ trợ và phối hợp tổ chức hoạt động.
> - Ban giám hiệu xem xét, thống nhất danh sách biểu dương căn cứ mức độ tham gia, tinh thần trách nhiệm và những đóng góp cụ thể.
> - Không bắt buộc mỗi tổ phải có người được biểu dương theo từng hình thức; khuyến khích ghi nhận cả đóng góp cá nhân và tập thể.
> - Việc ghi nhận không làm phát sinh hồ sơ thi đua riêng hoặc yêu cầu giáo viên cung cấp thêm minh chứng không cần thiết.
>
> **6. Dự kiến kinh phí động viên**
>
> | Nội dung | Số lượng dự kiến | Mức quà | Thành tiền |
> |---|---:|---:|---:|
> | Quà biểu dương cá nhân/nhóm có đóng góp tích cực trong chia sẻ và hỗ trợ chuyên môn | 03 phần | 200.000đ | 600.000đ |
> | Quà động viên cá nhân/nhóm tham gia giới thiệu, giao lưu, chia sẻ | 10 phần | 100.000đ | 1.000.000đ |
> | **Tổng kinh phí dự kiến** | **13 phần** | | **1.600.000đ** |
>
> Số lượng và mức quà trên là dự kiến để nhà trường cân đối kinh phí, không phải cơ cấu giải thưởng hoặc chỉ tiêu bắt buộc.
>
> Căn cứ số lượng người tham gia, kết quả tổ chức và nguồn kinh phí thực tế, Hiệu trưởng xem xét điều chỉnh số phần quà, hình thức biểu dương phù hợp. Không trao trùng nhiều phần quà cho cùng một đóng góp nếu không có lý do cụ thể.
>
> Kinh phí thực hiện từ nguồn kinh phí hợp pháp của đơn vị, được phê duyệt và thực hiện theo quy định tài chính, quy chế chi tiêu nội bộ; không huy động kinh phí bắt buộc từ giáo viên, trẻ hoặc cha mẹ trẻ.
>
> ### VIII. PHÂN CÔNG TỔ CHỨC THỰC HIỆN
>
> **1. Hiệu trưởng**
>
> - Chỉ đạo chung, phê duyệt nội dung và điều kiện tổ chức hoạt động.
> - Chỉ đạo thực hiện việc biểu dương, động viên, trao quà bảo đảm phù hợp quy định.
> - Kiểm tra kết quả thực hiện, chỉ đạo việc tổng hợp và nhân rộng những cách làm có hiệu quả.
>
> **2. Phó Hiệu trưởng phụ trách giáo dục**
>
> - Tham mưu triển khai hoạt động; hướng dẫn các tổ chuyên môn thực hiện.
> - Tổng hợp danh sách cá nhân, nhóm tham gia và sản phẩm giới thiệu.
> - Phối hợp kiểm tra nội dung, giá trị giáo dục, điều kiện an toàn và khả năng chia sẻ.
> - Tham mưu nội dung giao lưu, biểu dương và tổng hợp kết quả hoạt động.
>
> **3. Phó Hiệu trưởng phụ trách cơ sở vật chất**
>
> Phối hợp chuẩn bị địa điểm, trang thiết bị trình chiếu, hệ thống điện, mạng Internet, âm thanh và các điều kiện phục vụ trưng bày, giao lưu.
>
> **4. Các tổ trưởng chuyên môn**
>
> - Triển khai nội dung đến giáo viên trên tinh thần tự nguyện.
> - Khuyến khích trao đổi, hỗ trợ đồng nghiệp xây dựng và khai thác sản phẩm.
> - Tổng hợp sản phẩm giới thiệu đúng thời gian.
> - Phối hợp đề xuất các hình thức ghi nhận đóng góp của giáo viên, nhóm giáo viên.
>
> **5. Giáo viên, nhóm tham gia**
>
> - Chủ động lựa chọn nội dung, hình thức sản phẩm phù hợp điều kiện thực tế.
> - Bảo đảm nội dung giáo dục, an toàn và quyền sử dụng tài nguyên.
> - Chuẩn bị phần giới thiệu ngắn gọn, dễ hiểu, có thể minh họa trực tiếp.
> - Tích cực trao đổi, chia sẻ kinh nghiệm và tiếp thu ý kiến góp ý.
>
> **6. Bộ phận kế toán, văn phòng**
>
> - Tham mưu dự toán kinh phí, chuẩn bị quà tặng, giấy ghi nhận và các điều kiện phục vụ.
> - Thực hiện thanh quyết toán theo quy định.
> - Phối hợp lưu trữ tài liệu và kết quả hoạt động.
>
> ### IX. TỔNG KẾT VÀ NHÂN RỘNG SẢN PHẨM
>
> - Sau hoạt động, bộ phận chuyên môn tổng hợp những học liệu, đồ dùng, đồ chơi có giá trị sử dụng để tiếp tục trao đổi, hoàn thiện.
> - Khuyến khích giáo viên chia sẻ tệp học liệu, đường liên kết và hướng dẫn sử dụng trong kho học liệu số dùng chung của nhà trường.
> - Việc lựa chọn đồ chơi, học liệu đưa vào sử dụng chính thức tại các nhóm, lớp phải bảo đảm các nguyên tắc, yêu cầu và quy trình lựa chọn theo Thông tư số 60/2026/TT-BGDĐT ngày 17/7/2026 của Bộ Giáo dục và Đào tạo.
> - Tiếp tục lồng ghép chia sẻ học liệu số, kinh nghiệm khai thác công nghệ trong sinh hoạt chuyên môn định kỳ.
>
> **Trên đây là Quy định tổ chức hoạt động giao lưu, trưng bày và chia sẻ “Sáng tạo học liệu số – Đồ dùng, đồ chơi thông minh” từ ngày 16/11/2026 đến ngày 30/11/2026 của Trường Mầm non An Bình. Đề nghị các bộ phận, tổ chuyên môn và giáo viên phối hợp thực hiện, bảo đảm thiết thực, an toàn, tiết kiệm và hiệu quả.**

---

## 📋 Những nội dung cần điều chỉnh trong Kế hoạch số 283/KH-MNAB

Để hai phụ lục thống nhất với kế hoạch chính, tôi đề xuất điều chỉnh các nội dung sau:

| Vị trí trong kế hoạch chính | Nội dung cần thống nhất |
|--------|--------|
| Mục II.2 – Tuyên truyền, giáo dục truyền thống | Sử dụng thống nhất tên Hội thi ảnh theo Phụ lục 01, thời gian công bố và trao giải 20/11/2026 |
| Mục II.5 – Ứng dụng chuyển đổi số | Đổi “Tổ chức hội thi Sáng tạo học liệu số…” thành hoạt động giao lưu, trưng bày và chia sẻ, thực hiện 16–30/11/2026 |
| Mục III – Phân công nhiệm vụ | Thay các cụm từ “hội thi học liệu số, đồ dùng, đồ chơi” bằng “hoạt động giao lưu, trưng bày và chia sẻ học liệu số” |
| Mục IV – Kinh phí | Bổ sung kinh phí hội thi ảnh và phần quà động viên hoạt động giao lưu |
| Mục V – Tổ chức thực hiện | Phân biệt thời điểm tổng kết Hội thi ảnh ngày 20/11 và hoạt động giao lưu ngày 30/11 |

Về kinh phí, dự toán hiện có trong kế hoạch chính là 27.000.000 đồng, chưa thể hiện hai khoản thưởng nói trên. Nếu sử dụng mức đề xuất tại các phụ lục:

DỰ TOÁN TỔNG HỢP SAU KHI BỔ SUNG

| Hoạt động họp mặt và tri ân (dự toán gốc) | 27.000.000đ |
|--------|--------|
| Khen thưởng Hội thi ảnh | 2.500.000đ |
| Quà ghi nhận, động viên giao lưu học liệu số | 1.600.000đ |
| **Tổng dự kiến** | **31.100.000đ** |

Số liệu đề xuất để cân đối, chưa phải dự toán điều chỉnh đã được phê duyệt.

Do Kế hoạch số 283/KH-MNAB đã ghi ngày ban hành 13/11/2026, nhà trường nên thực hiện việc điều chỉnh, bổ sung theo trình tự văn bản phù hợp, không chỉ thay nội dung trong bản đã ký. Ngoài ra, phụ lục dự toán kinh phí đang có ở cuối kế hoạch có thể đổi thành **Phụ lục 03**, để hồ sơ có thứ tự thống nhất.

✅ **Kết luận:** Hai phụ lục trên giữ được nội dung trọng tâm từ các bản nhà trường đã chuẩn bị. Phụ lục 01 có tiêu chí, cách chấm và cơ cấu giải thưởng rõ ràng; Phụ lục 02 bổ sung phần ghi nhận, khen thưởng động viên với kinh phí dự kiến, đồng thời phù hợp định hướng giao lưu, chia sẻ chuyên môn của ngành.

Việc lựa chọn học liệu để sử dụng chính thức cũng được tách khỏi hoạt động trưng bày, theo quy định của Thông tư 60/2026/TT-BGDĐT, có hiệu lực từ ngày 01/9/2026. [Thông tư số 60/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non](<https://chinhphu.vn/?docid=218922&orggroupid=4&pageid=27160>); [Thông tư số 60/2026/TT\-BGDĐT quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non](<https://congbao.chinhphu.vn/van-ban/thong-tu-so-60-2026-tt-bgddt-470131.htm>)

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

trao giải phải khớp nd này chứ

---

ASSISTANT

Đúng rồi! Phần cơ cấu trao thưởng phải **khớp hoàn toàn với 04 hình thức ghi nhận** đã quy định trong phụ lục của nhà trường. Ở bản trước, tôi đã thay đổi tên một số hình thức ghi nhận nên chưa thống nhất.

Tôi điều chỉnh lại như sau, giữ nguyên tên gọi và nội dung trong bảng của cô, đồng thời bổ sung số lượng và mức thưởng cụ thể.

> **writing · document**
>
> ### 3. Các hình thức ghi nhận, trao giải khuyến khích
>
> | STT | Tên hình thức ghi nhận | Nội dung |
> |---|---|---|
> | 1 | **Giải ghi nhận “Chia sẻ học liệu số sáng tạo”** | Dành cho cá nhân hoặc nhóm tích cực chia sẻ học liệu số, hướng dẫn sử dụng và hỗ trợ đồng nghiệp khai thác tài nguyên. |
> | 2 | **Giải ghi nhận “Lan tỏa ứng dụng công nghệ”** | Dành cho cá nhân hoặc nhóm chủ động hướng dẫn, hỗ trợ giáo viên ứng dụng công nghệ số vào hoạt động giáo dục. |
> | 3 | **Giải ghi nhận “Kết nối và hợp tác chuyên môn”** | Dành cho cá nhân hoặc nhóm có đóng góp tích cực trong trao đổi, góp ý, hỗ trợ đồng nghiệp và tổ chức chia sẻ kinh nghiệm. |
> | 4 | **Quà tri ân tinh thần sáng tạo** | Dành cho các cá nhân, nhóm giáo viên tự nguyện tham gia giới thiệu và chia sẻ sản phẩm. |
>
> Các hình thức ghi nhận nhằm biểu dương, khích lệ tinh thần sáng tạo, hợp tác và chia sẻ chuyên môn; không tổ chức chấm điểm, xếp hạng chất lượng sản phẩm đồ dùng, đồ chơi.
>
> ### 4. Cơ cấu và mức thưởng động viên (dự kiến)
>
> | STT | Hình thức ghi nhận, trao thưởng | Số lượng | Mức thưởng | Thành tiền |
> |---|---|---:|---:|---:|
> | 1 | Giải ghi nhận “Chia sẻ học liệu số sáng tạo” | 01 | 200.000đ | 200.000đ |
> | 2 | Giải ghi nhận “Lan tỏa ứng dụng công nghệ” | 01 | 200.000đ | 200.000đ |
> | 3 | Giải ghi nhận “Kết nối và hợp tác chuyên môn” | 01 | 200.000đ | 200.000đ |
> | 4 | Quà tri ân tinh thần sáng tạo | 10 | 100.000đ | 1.000.000đ |
> | | **Tổng cộng** | **13** | | **1.600.000đ** |
>
> **5. Tổ chức ghi nhận và trao thưởng**
>
> - Ban Giám hiệu phối hợp với các tổ chuyên môn xem xét, lựa chọn cá nhân hoặc nhóm giáo viên có đóng góp tích cực, phù hợp với từng hình thức ghi nhận.
> - Mỗi hình thức ghi nhận từ mục 1 đến mục 3 dự kiến trao cho 01 cá nhân hoặc nhóm tiêu biểu; việc lựa chọn căn cứ vào những đóng góp thực tế trong hoạt động chia sẻ và hỗ trợ chuyên môn, không dựa trên việc chấm điểm sản phẩm.
> - Quà tri ân tinh thần sáng tạo được trao nhằm động viên các cá nhân, nhóm giáo viên tự nguyện tham gia giới thiệu, giao lưu và chia sẻ sản phẩm.
> - Tổ chức biểu dương, trao giấy ghi nhận và phần thưởng động viên tại buổi giao lưu, tổng kết ngày 30/11/2026.
> - Cơ cấu, số lượng và mức thưởng có thể điều chỉnh theo tình hình thực tế, số lượng người tham gia và nguồn kinh phí hợp pháp được phê duyệt của nhà trường.

**Như vậy, cơ cấu thống nhất là 03 giải ghi nhận theo đúng tên trong thể lệ và 10 phần quà tri ân**, với tổng kinh phí dự kiến 1.600.000 đồng.

Tôi cũng đề xuất trong biên bản xét ghi nhận và chương trình trao thưởng ngày 30/11 phải sử dụng đúng 04 tên gọi này, không đổi thành “Giải sáng tạo nhất”, “Giải ứng dụng hiệu quả nhất” hoặc “Giải Nhất, Nhì, Ba”, để bảo đảm thống nhất toàn bộ hồ sơ và đúng tính chất giao lưu, chia sẻ chuyên môn.

---

USER

bạn giúp mình điều chỉnh phụ lục 1 thành triển lãm ảnh "nét đẹp giáo viên mầm non" nhé

---

ASSISTANT

Tôi điều chỉnh **Phụ lục 01 từ Hội thi ảnh sang Triển lãm ảnh “Nét đẹp giáo viên mầm non”**, phù hợp với tính chất hoạt động chào mừng Ngày Nhà giáo Việt Nam 20/11 của Trường Mầm non An Bình.

Nội dung mới sẽ giữ mục tiêu tôn vinh hình ảnh giáo viên, lan tỏa tình yêu nghề, mến trẻ; đồng thời **bỏ chấm điểm, bình chọn Facebook, xếp giải Nhất – Nhì – Ba**, thay bằng lựa chọn ảnh tiêu biểu, trưng bày, trình chiếu và ghi nhận sự đóng góp của giáo viên.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**
>
> **TRƯỜNG MẦM NON AN BÌNH**
>
> # PHỤ LỤC 01
> ## QUY ĐỊNH TỔ CHỨC TRIỂN LÃM ẢNH
> ## “NÉT ĐẸP GIÁO VIÊN MẦM NON”
>
> *Chào mừng kỷ niệm 44 năm Ngày Nhà giáo Việt Nam (20/11/1982 – 20/11/2026)*
>
> *(Kèm theo Kế hoạch số 283/KH-MNAB ngày 13 tháng 11 năm 2026 của Trường Mầm non An Bình)*
>
> ### I. MỤC ĐÍCH, YÊU CẦU
>
> **1. Mục đích**
>
> - Tôn vinh hình ảnh người giáo viên mầm non tận tâm, trách nhiệm, yêu nghề, mến trẻ thông qua những khoảnh khắc chân thực, ý nghĩa trong hoạt động chăm sóc, nuôi dưỡng và giáo dục trẻ.
> - Ghi nhận, lan tỏa những việc làm đẹp, sự sáng tạo, tinh thần trách nhiệm và tình yêu thương của đội ngũ giáo viên đối với trẻ; góp phần xây dựng hình ảnh người giáo viên mầm non thân thiện, mẫu mực, giàu lòng nhân ái.
> - Tạo không khí vui tươi, phấn khởi, tăng cường sự đoàn kết, gắn bó giữa cán bộ, giáo viên, nhân viên tại ba điểm trường An Bình, An Lộc và An Bình A nhân kỷ niệm Ngày Nhà giáo Việt Nam 20/11.
> - Giới thiệu những hình ảnh đẹp, hoạt động giáo dục tiêu biểu của nhà trường đến cán bộ, giáo viên, nhân viên, đại biểu và khách mời; góp phần xây dựng nguồn tư liệu phục vụ công tác truyền thông.
>
> **2. Yêu cầu**
>
> - Hoạt động triển lãm được tổ chức thiết thực, trang trọng, tiết kiệm, phù hợp điều kiện thực tế của nhà trường; không làm ảnh hưởng đến công tác chăm sóc, nuôi dưỡng và giáo dục trẻ.
> - Hình ảnh trưng bày phải chân thực, có ý nghĩa giáo dục, phản ánh đúng hoạt động nghề nghiệp của giáo viên và môi trường giáo dục của nhà trường.
> - Khuyến khích giáo viên tham gia trên tinh thần tự nguyện, không gây áp lực về số lượng ảnh, thành tích hoặc kinh phí.
> - Việc lựa chọn, trưng bày và sử dụng hình ảnh phải bảo đảm tính phù hợp, thẩm mỹ, quyền tác giả, quyền riêng tư và bảo vệ hình ảnh của trẻ theo quy định.
>
> ### II. ĐỐI TƯỢNG, CHỦ ĐỀ VÀ NỘI DUNG TRIỂN LÃM
>
> **1. Đối tượng tham gia**
>
> Giáo viên đang công tác tại Trường Mầm non An Bình, thuộc ba điểm trường An Bình, An Lộc và An Bình A.
>
> **2. Chủ đề triển lãm**
>
> **“Nét đẹp giáo viên mầm non”**
>
> Thông điệp: *“Mỗi khoảnh khắc đẹp – Một tình yêu nghề”.*
>
> **3. Nội dung hình ảnh**
>
> Hình ảnh tham gia triển lãm tập trung thể hiện những nét đẹp trong hoạt động nghề nghiệp của giáo viên, cụ thể:
>
> - **Nét đẹp trong chăm sóc, nuôi dưỡng trẻ:** Những khoảnh khắc cô giáo ân cần đón trẻ, chăm sóc bữa ăn, giấc ngủ, vệ sinh cá nhân, quan tâm sức khỏe và bảo đảm an toàn cho trẻ.
> - **Nét đẹp trong tổ chức hoạt động giáo dục:** Hình ảnh giáo viên cùng trẻ tham gia hoạt động học, vui chơi, khám phá, trải nghiệm, hoạt động ngoài trời và các hoạt động giáo dục phù hợp lứa tuổi.
> - **Nét đẹp của tình yêu thương và sự tận tâm:** Những cử chỉ ân cần, ánh mắt yêu thương, sự động viên, khích lệ, tôn trọng và đồng hành cùng trẻ trong các hoạt động hằng ngày.
> - **Nét đẹp của sự sáng tạo, đổi mới:** Hình ảnh giáo viên sáng tạo trong xây dựng môi trường giáo dục, tổ chức hoạt động trải nghiệm, ứng dụng công nghệ và sử dụng học liệu phù hợp nhằm nâng cao chất lượng chăm sóc, giáo dục trẻ.
> - **Nét đẹp của tinh thần đoàn kết, trách nhiệm:** Hình ảnh giáo viên tích cực phối hợp, hỗ trợ đồng nghiệp, chia sẻ kinh nghiệm, tham gia các hoạt động tập thể và xây dựng môi trường sư phạm thân thiện.
>
> ### III. HÌNH THỨC VÀ QUY ĐỊNH THAM GIA
>
> **1. Hình thức tham gia**
>
> - Giáo viên tự nguyện lựa chọn, giới thiệu những hình ảnh đẹp, có ý nghĩa trong quá trình thực hiện nhiệm vụ.
> - Mỗi giáo viên gửi tối đa 02 ảnh; bộ phận phụ trách lựa chọn 01 ảnh phù hợp để giới thiệu trong không gian triển lãm chung.
> - Các tổ chuyên môn phối hợp tổng hợp, giới thiệu hình ảnh tiêu biểu tại các nhóm, lớp, bảo đảm phản ánh đa dạng hoạt động chăm sóc, nuôi dưỡng và giáo dục trẻ.
> - Hình ảnh được trưng bày trực tiếp hoặc trình chiếu bằng phương tiện điện tử trong buổi họp mặt kỷ niệm Ngày Nhà giáo Việt Nam 20/11/2026.
>
> **2. Yêu cầu đối với hình ảnh**
>
> - Ảnh được chụp thực tế trong năm học 2026–2027 tại Trường Mầm non An Bình.
> - Hình ảnh rõ nét, bố cục phù hợp, phản ánh trung thực nội dung hoạt động, có tính thẩm mỹ và ý nghĩa giáo dục.
> - Không sử dụng hình ảnh sao chép từ Internet, hình ảnh do trí tuệ nhân tạo tạo ra hoặc chỉnh sửa làm sai lệch nội dung, bối cảnh thực tế.
> - Có thể điều chỉnh độ sáng, màu sắc, cắt cúp ảnh hợp lý nhưng không làm thay đổi bản chất hình ảnh.
> - Không sử dụng ảnh gây phản cảm, thiếu tính sư phạm hoặc ảnh có nội dung ảnh hưởng đến danh dự, nhân phẩm và sự an toàn của trẻ.
> - Đối với ảnh có trẻ, phải bảo đảm quyền hình ảnh, quyền riêng tư và điều kiện đồng ý phù hợp trước khi trưng bày, trình chiếu hoặc đăng tải công khai.
>
> **3. Thông tin gửi kèm hình ảnh**
>
> Mỗi hình ảnh giới thiệu cần có:
>
> - Tên tác phẩm.
> - Họ và tên giáo viên, lớp, điểm trường.
> - Lời giới thiệu ngắn gọn, khoảng 80–150 từ, nêu rõ nội dung, ý nghĩa hoặc thông điệp của hình ảnh.
>
> Ảnh và lời giới thiệu gửi về tổ trưởng chuyên môn để tổng hợp, chuyển Ban Truyền thông nhà trường theo thời gian quy định.
>
> ### IV. LỰA CHỌN, TRƯNG BÀY VÀ GIỚI THIỆU HÌNH ẢNH
>
> **1. Lựa chọn hình ảnh**
>
> - Ban Truyền thông phối hợp với các tổ chuyên môn rà soát, lựa chọn những hình ảnh đáp ứng yêu cầu về nội dung, chất lượng, tính chân thực và điều kiện sử dụng.
> - Ưu tiên hình ảnh có nội dung rõ ràng, giàu cảm xúc, thể hiện nét đẹp nghề nghiệp, sự tận tâm và tình yêu thương của giáo viên đối với trẻ.
> - Bảo đảm sự đa dạng về nội dung hoạt động và sự tham gia của giáo viên tại ba điểm trường.
> - Việc lựa chọn ảnh nhằm phục vụ triển lãm, không tổ chức chấm điểm, bình chọn, xếp hạng hoặc trao giải theo chất lượng tác phẩm.
>
> **2. Hình thức trưng bày**
>
> - Tổ chức không gian triển lãm ảnh tại khu vực họp mặt kỷ niệm Ngày Nhà giáo Việt Nam 20/11/2026 tại điểm trường chính An Bình.
> - Hình ảnh được sắp xếp khoa học, hài hòa, phù hợp điều kiện cơ sở vật chất; có thể trưng bày bằng khung ảnh, bảng ảnh, pano hoặc trình chiếu trên màn hình.
> - Mỗi ảnh trưng bày có tên tác phẩm, tên giáo viên và thông điệp ngắn gọn.
> - Khuyến khích bố trí hình ảnh theo các nhóm nội dung: yêu thương và chăm sóc trẻ; sáng tạo trong giáo dục; niềm vui cô và trẻ; đoàn kết và trách nhiệm nghề nghiệp.
> - Lựa chọn hình ảnh tiêu biểu để trình chiếu trong chương trình họp mặt, góp phần tạo không khí trang trọng, ấm áp và lan tỏa những giá trị tích cực của nghề giáo.
>
> **3. Giới thiệu và chia sẻ**
>
> - Ban Tổ chức giới thiệu ý nghĩa, thông điệp của triển lãm ảnh trong chương trình họp mặt.
> - Khuyến khích giáo viên trao đổi, chia sẻ câu chuyện, kỷ niệm hoặc những cảm xúc gắn với hình ảnh được trưng bày.
> - Những hình ảnh phù hợp, đáp ứng đầy đủ điều kiện sử dụng có thể được lựa chọn đăng tải trên các kênh truyền thông chính thức của nhà trường.
>
> ### V. THỜI GIAN VÀ TIẾN ĐỘ THỰC HIỆN
>
> | Thời gian | Nội dung thực hiện | Bộ phận phụ trách |
> |---|---|---|
> | 15–16/11/2026 | Triển khai nội dung triển lãm; hướng dẫn giáo viên lựa chọn và gửi ảnh | Ban giám hiệu, tổ chuyên môn |
> | 17/11/2026 | Tiếp nhận, rà soát và lựa chọn hình ảnh phù hợp | Ban Truyền thông, tổ chuyên môn |
> | 18–19/11/2026 | Biên tập tên ảnh, lời giới thiệu; thiết kế, chuẩn bị hình ảnh và không gian trưng bày, trình chiếu | Ban Truyền thông, bộ phận hậu cần |
> | 20/11/2026 | Tổ chức triển lãm, giới thiệu và trình chiếu hình ảnh trong chương trình họp mặt kỷ niệm 44 năm Ngày Nhà giáo Việt Nam | Ban giám hiệu, các bộ phận liên quan |
>
> ### VI. GHI NHẬN VÀ LAN TỎA HÌNH ẢNH ĐẸP
>
> - Nhà trường ghi nhận, biểu dương tinh thần hưởng ứng, sự tích cực và trách nhiệm của giáo viên trong việc lưu giữ, chia sẻ những khoảnh khắc đẹp của nghề.
> - Có thể thực hiện hình thức cảm ơn, ghi nhận phù hợp đối với các cá nhân, tổ chuyên môn tích cực hỗ trợ công tác sưu tầm, biên tập, tổ chức trưng bày và giới thiệu hình ảnh.
> - Việc ghi nhận nhằm động viên tinh thần tham gia, đóng góp cho hoạt động chung, không gắn với việc chấm điểm hoặc xếp hạng tác phẩm.
> - Các hình ảnh có giá trị giáo dục và truyền thông được lựa chọn lưu trữ trong kho tư liệu của nhà trường khi đáp ứng điều kiện sử dụng, phục vụ công tác tuyên truyền, giới thiệu hình ảnh đội ngũ và hoạt động giáo dục.
>
> ### VII. PHÂN CÔNG TỔ CHỨC THỰC HIỆN
>
> **1. Hiệu trưởng**
>
> - Chỉ đạo chung, phê duyệt nội dung, hình thức và điều kiện tổ chức triển lãm.
> - Phân công các bộ phận phối hợp thực hiện, bảo đảm hoạt động trang trọng, thiết thực, tiết kiệm và hiệu quả.
>
> **2. Phó Hiệu trưởng phụ trách giáo dục**
>
> - Tham mưu triển khai hoạt động đến các tổ chuyên môn.
> - Hướng dẫn, theo dõi tiến độ lựa chọn, tổng hợp hình ảnh.
> - Phối hợp Ban Truyền thông rà soát nội dung, lựa chọn hình ảnh phù hợp để trưng bày và trình chiếu.
>
> **3. Ban Truyền thông**
>
> - Tiếp nhận, tổng hợp và biên tập hình ảnh, tên tác phẩm, lời giới thiệu.
> - Rà soát nội dung, chất lượng và điều kiện sử dụng hình ảnh.
> - Thiết kế, sắp xếp các nhóm hình ảnh, chuẩn bị nội dung trình chiếu, giới thiệu tại buổi họp mặt.
> - Lưu trữ hình ảnh và tư liệu phục vụ hoạt động truyền thông theo quy định.
>
> **4. Các tổ trưởng chuyên môn**
>
> - Triển khai nội dung đến giáo viên trong tổ.
> - Khuyến khích giáo viên lựa chọn, giới thiệu hình ảnh đẹp, có ý nghĩa.
> - Rà soát thông tin tác phẩm, tổng hợp và gửi về Ban Truyền thông đúng thời gian.
> - Phối hợp hỗ trợ việc trưng bày, giới thiệu hình ảnh của tổ.
>
> **5. Giáo viên các lớp**
>
> - Chủ động lựa chọn và gửi hình ảnh phù hợp chủ đề trên tinh thần tự nguyện.
> - Bảo đảm tính chân thực của hình ảnh và các yêu cầu về quyền riêng tư, quyền sử dụng hình ảnh.
> - Phối hợp cung cấp thông tin, lời giới thiệu, chia sẻ ý nghĩa của tác phẩm khi được đề nghị.
>
> **6. Bộ phận cơ sở vật chất, hậu cần**
>
> - Chuẩn bị khu vực trưng bày, bảng ảnh, màn hình, máy chiếu và các điều kiện cần thiết.
> - Phối hợp sắp xếp, trang trí không gian triển lãm bảo đảm trang trọng, hài hòa, an toàn và tiết kiệm.
>
> ### VIII. TỔ CHỨC THỰC HIỆN
>
> Các bộ phận, tổ chuyên môn và giáo viên căn cứ nội dung quy định để phối hợp triển khai thực hiện. Những khó khăn, vướng mắc trong quá trình thực hiện kịp thời phản ánh về Ban Giám hiệu để được hướng dẫn, giải quyết.
>
> Kết thúc hoạt động, Ban Truyền thông phối hợp với các tổ chuyên môn tổng hợp, lưu trữ hình ảnh phù hợp, phục vụ công tác tuyên truyền và xây dựng hình ảnh tích cực của nhà trường.
>
> **Trên đây là Quy định tổ chức Triển lãm ảnh “Nét đẹp giáo viên mầm non” chào mừng kỷ niệm 44 năm Ngày Nhà giáo Việt Nam 20/11/2026 của Trường Mầm non An Bình. Đề nghị các bộ phận, tổ chuyên môn và giáo viên phối hợp thực hiện, bảo đảm thiết thực, ý nghĩa và hiệu quả.**

## 📋 Những nội dung cần điều chỉnh trong Kế hoạch số 283/KH-MNAB

Vì kế hoạch chính hiện đang ghi “Hội thi ảnh”, khi sử dụng phụ lục mới, nhà trường cần chỉnh sửa đồng bộ:

| Vị trí | Nội dung điều chỉnh |
|--------|--------|
| Mục II.2 | Đổi thành “Tổ chức Triển lãm ảnh ‘Nét đẹp giáo viên mầm non’” |
| Mục II.3 | Bổ sung giới thiệu, trình chiếu hình ảnh triển lãm trong buổi họp mặt ngày 20/11 |
| Mục III.2 và III.5 | Thay nhiệm vụ chỉ đạo, triển khai hội thi ảnh bằng hoạt động triển lãm ảnh |
| Mục V | Điều chỉnh nội dung thực hiện từ hội thi ảnh sang lựa chọn, trưng bày và giới thiệu hình ảnh |
| Dự toán kinh phí | Bỏ khoản giải thưởng Hội thi ảnh 2.500.000 đồng; chỉ dự toán kinh phí trưng bày, in ảnh nếu thực tế phát sinh |

**Đề xuất cuối cùng:** Nhà trường giữ hai hoạt động riêng biệt trong Kế hoạch 20/11:

- **Phụ lục 01:** Triển lãm ảnh “Nét đẹp giáo viên mầm non” – tổ chức ngày 20/11/2026, mang tính tôn vinh, lan tỏa.
- **Phụ lục 02:** Giao lưu, trưng bày và chia sẻ “Sáng tạo học liệu số – Đồ dùng, đồ chơi thông minh” – kết thúc ngày 30/11/2026, có 03 giải ghi nhận và quà tri ân tinh thần sáng tạo theo cơ cấu đã thống nhất.

Như vậy, hai hoạt động vừa có nét đặc trưng riêng, vừa thống nhất mục tiêu chào mừng Ngày Nhà giáo Việt Nam, tôn vinh đội ngũ và khuyến khích đổi mới chuyên môn.

---

