USER

Với vai trò bí thư chi bộ bạn giúp tôi  nhận xét phần chứng nhận của cấp ủy cơ sở cho hồ sơ đảng viên mới

---

ASSISTANT

Mình sẽ vận dụng hướng dẫn của Cố vấn công tác Đảng để soạn lời nhận xét trang trọng, ngắn gọn, phù hợp với phần chứng nhận của cấp ủy cơ sở.

---

ASSISTANT

Nếu bạn đang điền phần **“Chứng nhận của cấp ủy cơ sở” trong lý lịch của đảng viên mới được kết nạp**, có thể sử dụng lời chứng nhận dưới đây, tùy việc cấp ủy đã thực hiện:

**1. Trường hợp đã đối chiếu, thống nhất với lý lịch người xin vào Đảng:**

> **writing · standard**
>
> Chứng nhận lý lịch của đồng chí ........................................................ theo đúng lý lịch của người xin vào Đảng.

**2. Trường hợp cấp ủy đã thẩm tra và kết luận nội dung khai đúng sự thật:**

> **writing · standard**
>
> Chứng nhận lý lịch của đồng chí ........................................................ khai tại ........................................................ là đúng sự thật.

Hai cách ghi này tương ứng với việc đối khớp hồ sơ hoặc đã thẩm tra, kết luận; cần chọn đúng với thực tế cấp ủy đã thực hiện. https://files.ubdt.gov.vn/ContentFolder/ecm/source_files/2017/12/15/14451564_09-HD_BTCTW%20ngay%205%20thang%206%20n%C4%83m%202017_17-12-15.pdf
https://files.ubdt.gov.vn/ContentFolder/ecm/source_files/2017/12/15/14451564_09-HD_BTCTW%20ngay%205%20thang%206%20n%C4%83m%202017_17-12-15.pdf?utm_source=chatgpt.com

Bạn gửi **ảnh trang có phần chứng nhận** để mình xác định đúng loại hồ sơ và hoàn chỉnh lời ghi cho bạn, tránh nhầm giữa *lý lịch người xin vào Đảng* và *lý lịch đảng viên*.

---

USER

---

ASSISTANT

Mình sẽ kiểm tra lại hai ảnh bạn gửi để xem đúng phần chứng nhận cần ghi.

---

ASSISTANT

Mình đã đọc được hai ảnh. **Hai trang có bố cục khác nhau nên cần ghi lời chứng nhận phù hợp với từng loại lý lịch.**

**1. Ảnh trang 24 — phần chứng nhận trong lý lịch đảng viên của đồng chí Nguyễn Thị Thanh Ngân**

Nếu cấp ủy đã đối chiếu với lý lịch người xin vào Đảng và thấy thống nhất, bạn ghi:

> **writing · standard**
>
> Chứng nhận lý lịch của đồng chí Nguyễn Thị Thanh Ngân theo đúng lý lịch của người xin vào Đảng.

Phần dưới ghi **T/M ĐẢNG ỦY**, chức vụ người ký và ngày, tháng, năm chứng nhận thực tế.

**2. Ảnh trang 32 — có cả “Nhận xét của chi ủy” và “Chứng nhận của cấp ủy cơ sở”**

Trang này có bố cục của **lý lịch người xin vào Đảng**. Nếu đúng tên sổ như vậy, và cấp ủy đã thẩm định, kết luận đủ điều kiện, có thể dự thảo:

> **writing · standard**
>
> Chứng nhận lý lịch của quần chúng ........................................ khai tại Đảng bộ Trường Mầm non An Bình là đúng sự thật. Qua thẩm định kết quả thẩm tra, xác minh, cấp ủy kết luận quần chúng ........................................ không có vấn đề về lịch sử chính trị và chính trị hiện nay; đủ điều kiện để xem xét kết nạp vào Đảng.

**Đoạn thứ hai chỉ sử dụng khi đúng với kết luận của cấp ủy**, không tự bổ sung nhận định về chính trị khi hồ sơ chưa có căn cứ. Bạn gửi thêm ảnh bìa của sổ có trang 32 để mình chốt chính xác lời chứng nhận cho trang này.

---

USER

cụ thể dùm mình cách viết trang 24 và trang 32 nhe

---

ASSISTANT

Bạn có thể ghi cụ thể như dưới đây. **Trang 24 là lời chứng nhận lý lịch đảng viên; trang 32 có hai phần riêng: nhận xét của chi ủy và chứng nhận của cấp ủy cơ sở.** Nội dung dự thảo sử dụng khi hồ sơ đã được thẩm tra, đối chiếu và cấp ủy đã có kết luận tương ứng.

**1. Trang 24 — Chứng nhận của cấp ủy cơ sở**

Nếu lý lịch đảng viên đã được đối chiếu và thống nhất với lý lịch người xin vào Đảng, ghi:

> **writing · standard**
>
> Chứng nhận lý lịch của đồng chí Nguyễn Thị Thanh Ngân theo đúng lý lịch của người xin vào Đảng.

Phần ký ghi:

- **Ngày … tháng … năm …:** ghi ngày chứng nhận thực tế.
- **T/M ĐẢNG ỦY**
- **BÍ THƯ**
- **Huỳnh Hồng Loan**

**2. Trang 32 — Nếu đây là sổ “Lý lịch của người xin vào Đảng”**

**Phần “Nhận xét của chi ủy”**, có thể ghi khi kết quả thẩm tra xác nhận đúng các nội dung sau:

> **writing · standard**
>
> Chi ủy Chi bộ An Bình A nhận xét: Quần chúng Nguyễn Thị Thanh Ngân đã khai lý lịch đầy đủ, rõ ràng, trung thực. Qua thẩm tra, xác minh, nội dung lý lịch phù hợp với kết quả xác minh; bản thân và gia đình chấp hành tốt chủ trương của Đảng, chính sách, pháp luật của Nhà nước.

Phần ký: ghi ngày nhận xét thực tế; **T/M CHI BỘ AN BÌNH A – BÍ THƯ**, họ tên người ký đúng như hồ sơ.

**Phần “Chứng nhận của cấp ủy cơ sở”**, ghi khi cấp ủy đã xem xét, kết luận đủ điều kiện:

> **writing · standard**
>
> Chứng nhận lý lịch của quần chúng Nguyễn Thị Thanh Ngân khai tại Đảng bộ Trường Mầm non An Bình là đúng sự thật; không có vấn đề về lịch sử chính trị và chính trị hiện nay theo quy định của Bộ Chính trị. Quần chúng Nguyễn Thị Thanh Ngân đủ điều kiện để xem xét kết nạp vào Đảng.

Phần ký ghi: **An Bình, ngày … tháng … năm …; T/M ĐẢNG ỦY – BÍ THƯ – Huỳnh Hồng Loan.**

**Lưu ý:** Mình điền tên Nguyễn Thị Thanh Ngân cho cả hai trang với giả định cùng một người. Riêng trang 32, ảnh chưa thể hiện tên sổ nên bạn cần kiểm tra đúng là **“Lý lịch của người xin vào Đảng”** trước khi chép nội dung trên.

---

