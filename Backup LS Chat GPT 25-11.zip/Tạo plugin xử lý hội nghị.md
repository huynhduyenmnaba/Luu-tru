USER

[@Plugin Creator](plugin://plugin_connector_1p_e1a10c53223481918a42f1510ec46c1e) giúp tôi tạo một plugin với vai trò hiệu trưởng xử lý các tình huống trong hội nghị theo các văn bản quy chế đính kèm

---

ASSISTANT

Tôi sẽ dùng Plugin Creator để tạo plugin hỗ trợ hiệu trưởng xử lý tình huống trong hội nghị, đối chiếu các quy chế được cung cấp và soạn câu trả lời rõ ràng, sát thực tế trường mầm non.

---

ASSISTANT

Tôi sẽ thiết kế plugin theo vai trò hiệu trưởng mầm non có hơn 20 năm kinh nghiệm: phân tích ý kiến tại hội nghị, đối chiếu quy chế, đề xuất hướng xử lý và soạn lời giải đáp để phát biểu trực tiếp.

Hiện tin nhắn này chưa có tệp quy chế đính kèm. Tôi sẽ tạo trước plugin với nguyên tắc phải đọc văn bản được cung cấp, không tự đặt điều khoản hay kết luận khi thiếu căn cứ.

---

ASSISTANT

Đã tạo plugin **[Hiệu trưởng xử lý tình huống hội nghị](https://chatgpt.com/plugins/Plugin_9b5c5059484c8191bc1a4f49f00a529a)**.

Plugin hỗ trợ cô:

- Đối chiếu ý kiến với các quy chế được cung cấp.
- Phân tích, đề xuất hướng xử lý sát thực tế trường mầm non.
- Soạn lời giải đáp ngắn gọn, logic, có thể phát biểu ngay tại hội nghị.
- Viết nội dung tiếp thu, giải trình, kết luận và đề xuất sửa quy chế.

**Hiện chưa có tệp quy chế trong tin nhắn này.** Cô gửi các văn bản cần áp dụng để tôi bổ sung vào plugin, giúp việc giải đáp bám đúng quy định của trường nhé.

---

