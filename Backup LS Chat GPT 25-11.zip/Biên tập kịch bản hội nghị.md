USER

Bạn giúp tôi biên tập để dẫn chương chương trình hội nghị đảng ủy. Mình có gửi chưng trình để bạntham khảo. tuy nhiên bạn cố gắng điều chỉnh cho phù hợp nhé

---

ASSISTANT

Tôi sẽ lấy chương trình Hội nghị Đảng ủy làm khung chính, sử dụng tài liệu hội nghị chi bộ để tham khảo cách dẫn và lời chuyển ý. Tôi sẽ viết thành kịch bản có thể đọc trực tiếp, tách rõ lời dẫn với phần điều hành của đồng chí Bí thư, đồng thời tránh nhầm giữa mức đề xuất xếp loại và kết quả do cấp có thẩm quyền quyết định.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đã đối chiếu thêm quy định mới và thấy một điểm cần lưu ý: Quy định 227-QĐ/TW ban hành tháng 10/2026 nhưng có điều khoản chuyển tiếp riêng cho kỳ kiểm điểm năm 2026. Vì vậy, kịch bản sẽ không áp dụng máy móc quy trình dành cho năm 2027 hoặc đưa sẵn mức xếp loại khi hội nghị chưa thảo luận.

---

ASSISTANT

---

ASSISTANT

Tôi đã nghiên cứu hai tài liệu bạn gửi, gồm chương trình Hội nghị Đảng ủy và kịch bản điều hành Hội nghị kiểm điểm của Chi bộ An Bình A.

Tôi đề xuất biên tập thành **kịch bản dẫn và điều hành Hội nghị Ban Chấp hành Đảng ủy Trường Mầm non An Bình năm 2026**, với lời dẫn trang trọng, tự nhiên, mạch lạc, không quá nặng về nghi thức. Đặc biệt, cần tách rõ phần dẫn chương trình, phần chủ trì kiểm điểm, thảo luận và phần xem xét đề xuất xếp loại của các chi bộ.

**Lưu ý quan trọng về căn cứ:** Tôi đã đối chiếu Quy định số 227-QĐ/TW ngày 19/10/2026. Theo điều khoản chuyển tiếp, việc kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 tiếp tục thực hiện theo Quy định số 366-QĐ/TW ngày 30/8/2025 và các hướng dẫn liên quan, trừ trường hợp tổ chức đảng có điều chỉnh theo Quy định số 208-QĐ/TW. Quy định 227 có hiệu lực từ ngày 01/01/2027. [Quy định số 227\-QĐ/TW ngày 19/10/2026 của Bộ Chính trị về kiểm điểm và đánh giá, xếp loại chất \.\.\.](<https://tulieuvankien.dangcongsan.vn/he-thong-van-ban/van-ban-cua-dang/quy-dinh-so-227-qd-tw-ngay-19-10-2026-cua-bo-chinh-tri-ve-kiem-diem-va-danh-gia-xep-loai-chat-luong-doi-voi-tap-the-ca-n.html?categoryId=102000092>); [Quy định số 366\-QĐ/TW ngày 30/8/2025 của Bộ Chính trị về việc kiểm điểm và đánh giá, xếp loại chất \.\.\.](<https://tulieuvankien.dangcongsan.vn/he-thong-van-ban/van-ban-cua-dang/quy-dinh-so-366-qdtw-ngay-3082025-cua-bo-chinh-tri-ve-viec-kiem-diem-va-danh-gia-xep-loai-chat-luong-doi-voi-tap-the-11785>); [Quy định của Bộ Chính trị về kiểm điểm và đánh giá, xếp loại chất lượng đối với tập thể, cá nhân \.\.\.](<https://dangcongsan.vn/tin-hoat-dong/quy-dinh-cua-bo-chinh-tri-ve-kiem-diem-va-danh-gia-xep-loai-chat-luong-doi-voi-tap-the-ca-nhan-trong-he-thong-chinh-tri.html>)

Dưới đây là bản lời dẫn đã biên tập theo đúng sáu nội dung làm việc trong chương trình Hội nghị Đảng ủy bạn cung cấp.

> **writing · document**
>
> # KỊCH BẢN DẪN VÀ ĐIỀU HÀNH HỘI NGHỊ
>
> **Kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026**
>
> **ĐẢNG ỦY TRƯỜNG MẦM NON AN BÌNH**
>
> - **Thời gian:** 15 giờ 00 phút, ngày 10 tháng 11 năm 2026.
> - **Địa điểm:** Phòng họp Trường Mầm non An Bình.
> - **Chủ trì:** Đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy.
> - **Thư ký dự kiến:** Đồng chí Phan Thị Mỹ Hạnh.
>
> *Ghi chú: Các nội dung in nghiêng là hướng dẫn điều hành, không đọc tại Hội nghị. Những vị trí trong dấu [ ] cần bổ sung thông tin hoặc kết quả thực tế.*
>
> ---
>
> # A. PHẦN MỞ ĐẦU
>
> ## 1. Tuyên bố lý do, giới thiệu đại biểu
>
> **Người dẫn chương trình:**
>
> Kính thưa đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy Trường Mầm non An Bình!
>
> Kính thưa các đồng chí trong Ban Chấp hành Đảng ủy!
>
> Kính thưa toàn thể Hội nghị!
>
> Thực hiện kế hoạch kiểm điểm, đánh giá, xếp loại chất lượng tổ chức đảng, đảng viên năm 2026 và sự chỉ đạo của cấp ủy cấp trên, hôm nay, Đảng ủy Trường Mầm non An Bình tổ chức Hội nghị kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026.
>
> Đây là dịp để tập thể Ban Chấp hành Đảng ủy nhìn nhận, đánh giá toàn diện kết quả lãnh đạo, chỉ đạo trong năm; làm rõ những ưu điểm, kết quả đạt được, đồng thời nghiêm túc chỉ ra những hạn chế, khuyết điểm, nguyên nhân và trách nhiệm trong tổ chức thực hiện nhiệm vụ.
>
> Thông qua Hội nghị, Ban Chấp hành Đảng ủy tiếp tục phát huy tinh thần tự phê bình và phê bình; nâng cao trách nhiệm của từng đồng chí cấp ủy viên; đồng thời xem xét, đánh giá khách quan, thực chất kết quả hoạt động của các chi ủy, chi bộ và đảng viên trực thuộc, làm cơ sở thực hiện việc đánh giá, xếp loại chất lượng theo quy định.
>
> Với tinh thần nghiêm túc, dân chủ, khách quan và trách nhiệm, Hội nghị hôm nay có ý nghĩa quan trọng trong việc nhìn lại kết quả thực hiện nhiệm vụ năm 2026, xác định những vấn đề cần tập trung lãnh đạo, chỉ đạo và đề ra giải pháp thực hiện trong năm 2027.
>
> Đó là lý do của Hội nghị hôm nay.
>
> **Về thành phần tham dự Hội nghị, tôi xin trân trọng giới thiệu:**
>
> - Đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy Trường Mầm non An Bình, chủ trì Hội nghị.
> - Các đồng chí Ủy viên Ban Chấp hành Đảng ủy Trường Mầm non An Bình.
> - Cùng các đồng chí đại biểu được mời tham dự Hội nghị, nếu có.
>
> *Trường hợp có đại diện cấp ủy cấp trên dự Hội nghị thì giới thiệu cụ thể họ tên, chức vụ trước khi giới thiệu các đồng chí trong Đảng ủy.*
>
> Xin trân trọng chào mừng các đồng chí đã đến tham dự Hội nghị hôm nay!
>
> ## 2. Báo cáo số lượng tham dự và cử thư ký
>
> Kính thưa Hội nghị!
>
> Trước khi tiến hành các nội dung làm việc, tôi xin báo cáo số lượng thành viên Ban Chấp hành Đảng ủy tham dự Hội nghị như sau:
>
> - Tổng số Ủy viên Ban Chấp hành Đảng ủy: [....] đồng chí.
> - Có mặt: [....] đồng chí.
> - Vắng mặt: [....] đồng chí; lý do: [....].
>
> Tiếp theo, Hội nghị tiến hành cử thư ký ghi biên bản.
>
> Được sự thống nhất về dự kiến nhân sự, xin đề xuất đồng chí **Phan Thị Mỹ Hạnh** làm thư ký Hội nghị.
>
> Xin ý kiến các đồng chí trong Ban Chấp hành Đảng ủy.
>
> *Dừng để Hội nghị cho ý kiến.*
>
> Nếu không có ý kiến khác, xin Hội nghị biểu quyết thống nhất cử đồng chí Phan Thị Mỹ Hạnh làm thư ký Hội nghị.
>
> Đồng chí nào thống nhất, xin cho biểu quyết bằng hình thức giơ tay.
>
> Có đồng chí nào không thống nhất hoặc có ý kiến khác không?
>
> *Sau khi ghi nhận kết quả thực tế:*
>
> Như vậy, Hội nghị đã thống nhất cử đồng chí Phan Thị Mỹ Hạnh làm thư ký Hội nghị.
>
> Đề nghị đồng chí thư ký ghi chép đầy đủ diễn biến Hội nghị, các ý kiến thảo luận, nội dung tiếp thu, giải trình, kết luận của chủ trì và kết quả lấy ý kiến, biểu quyết theo từng nội dung.
>
> ## 3. Thông qua chương trình Hội nghị
>
> Kính thưa các đồng chí!
>
> Theo chương trình đã được chuẩn bị, ngoài phần mở đầu và kết thúc, Hội nghị hôm nay tập trung thực hiện 06 nội dung chính:
>
> **Thứ nhất,** kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> **Thứ hai,** tự chấm điểm, thảo luận và đề xuất mức xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy.
>
> **Thứ ba,** kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy trong thực hiện chức trách, nhiệm vụ được phân công.
>
> **Thứ tư,** xem xét hồ sơ, kết quả kiểm điểm, đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc.
>
> **Thứ năm,** xem xét riêng các tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”.
>
> **Thứ sáu,** thống nhất kết quả xem xét, hoàn thiện hồ sơ và phân công nhiệm vụ sau Hội nghị.
>
> Trên đây là những nội dung trọng tâm của Hội nghị.
>
> Xin ý kiến các đồng chí về chương trình làm việc.
>
> *Dừng để Hội nghị cho ý kiến; thực hiện biểu quyết nếu được chủ trì yêu cầu.*
>
> Nếu không có ý kiến điều chỉnh, xin Hội nghị thống nhất thực hiện theo chương trình đã trình bày.
>
> ## 4. Mời đồng chí Bí thư Đảng ủy quán triệt yêu cầu Hội nghị
>
> Kính thưa Hội nghị!
>
> Để việc kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 được thực hiện nghiêm túc, khách quan, đúng nguyên tắc và đạt chất lượng, tiếp theo chương trình, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy**, chủ trì Hội nghị, phát biểu quán triệt một số yêu cầu và định hướng các nội dung kiểm điểm, đánh giá, xếp loại chất lượng năm 2026.
>
> Xin trân trọng kính mời đồng chí!
>
> ### Nội dung gợi ý phát biểu của đồng chí Bí thư
>
> Kính thưa các đồng chí!
>
> Hội nghị kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 là một nội dung quan trọng trong công tác xây dựng Đảng, đồng thời là dịp để tập thể Ban Chấp hành và từng đồng chí cấp ủy viên nhìn nhận đầy đủ hơn kết quả thực hiện nhiệm vụ trong năm.
>
> Để Hội nghị đạt yêu cầu đề ra, tôi đề nghị các đồng chí tập trung thực hiện tốt một số nội dung:
>
> **Một là,** phát huy tinh thần tự phê bình và phê bình, bảo đảm dân chủ, khách quan, trung thực, thẳng thắn và xây dựng; đánh giá đúng ưu điểm, không né tránh hạn chế, khuyết điểm, đồng thời giữ gìn sự đoàn kết, thống nhất trong Đảng ủy.
>
> **Hai là,** việc kiểm điểm phải gắn với kết quả thực hiện nghị quyết, chương trình công tác, nhiệm vụ được giao và trách nhiệm của từng đồng chí. Những nhận định, đánh giá cần có cơ sở, minh chứng cụ thể, tránh hình thức và chung chung.
>
> **Ba là,** tập trung làm rõ vai trò lãnh đạo của Ban Chấp hành Đảng ủy đối với công tác xây dựng Đảng và nhiệm vụ chính trị của nhà trường; nhất là công tác chăm sóc, nuôi dưỡng, giáo dục trẻ, bảo đảm an toàn trường học, xây dựng đội ngũ và thực hiện các nhiệm vụ trọng tâm trong năm.
>
> **Bốn là,** đối với việc xem xét kết quả đánh giá, xếp loại của các chi bộ và đảng viên, đề nghị các đồng chí nghiên cứu kỹ hồ sơ, đối chiếu tiêu chí, điều kiện và kết quả thực hiện nhiệm vụ; bảo đảm đánh giá công tâm, đúng thực chất, đúng thẩm quyền.
>
> **Năm là,** sau kiểm điểm phải xác định được những hạn chế cần khắc phục, trách nhiệm thực hiện, biện pháp cụ thể và thời gian hoàn thành. Kết quả kiểm điểm phải thực sự góp phần cải thiện chất lượng lãnh đạo, chỉ đạo trong thời gian tới.
>
> Với tinh thần đó, đề nghị các đồng chí phát huy trách nhiệm của người cấp ủy viên, tập trung nghiên cứu tài liệu và tham gia ý kiến có trọng tâm để Hội nghị hoàn thành tốt các nội dung đề ra.
>
> Sau đây, chúng ta chuyển sang phần nội dung làm việc.
>
> ---
>
> # B. PHẦN NỘI DUNG HỘI NGHỊ
>
> ## I. KIỂM ĐIỂM TẬP THỂ BAN CHẤP HÀNH ĐẢNG ỦY
>
> ### 1. Trình bày dự thảo Báo cáo kiểm điểm
>
> **Người dẫn chương trình:**
>
> Kính thưa Hội nghị!
>
> Mở đầu phần nội dung, Hội nghị tiến hành kiểm điểm tập thể Ban Chấp hành Đảng ủy Trường Mầm non An Bình năm 2026.
>
> Đây là nội dung trọng tâm nhằm đánh giá kết quả lãnh đạo, chỉ đạo và tổ chức thực hiện nhiệm vụ của Ban Chấp hành trong năm; làm rõ những kết quả đạt được, những vấn đề còn hạn chế, trách nhiệm của tập thể và phương hướng khắc phục.
>
> Sau đây, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy**, thay mặt Ban Chấp hành, trình bày dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> Xin trân trọng kính mời đồng chí!
>
> *Đồng chí Bí thư trình bày báo cáo.*
>
> ### 2. Gợi ý thảo luận, đóng góp ý kiến
>
> **Đồng chí chủ trì:**
>
> Kính thưa các đồng chí!
>
> Hội nghị vừa nghe dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> Để việc thảo luận có trọng tâm, đề nghị các đồng chí tập trung góp ý vào một số vấn đề sau:
>
> Thứ nhất, đánh giá kết quả lãnh đạo thực hiện nhiệm vụ chính trị của Đảng bộ và nhà trường trong năm 2026, nhất là những chỉ tiêu, nhiệm vụ đã đề ra trong nghị quyết và chương trình công tác năm.
>
> Thứ hai, việc thực hiện nguyên tắc tập trung dân chủ, quy chế làm việc, chế độ sinh hoạt cấp ủy, phân công trách nhiệm và giữ gìn đoàn kết nội bộ.
>
> Thứ ba, kết quả lãnh đạo công tác xây dựng Đảng; giáo dục chính trị, tư tưởng; quản lý đảng viên; kiểm tra, giám sát và nâng cao chất lượng hoạt động của các chi bộ trực thuộc.
>
> Thứ tư, vai trò và trách nhiệm của Ban Chấp hành trong lãnh đạo thực hiện nhiệm vụ chuyên môn; những chuyển biến đã đạt được và những vấn đề cần tiếp tục quan tâm trong công tác chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Thứ năm, những hạn chế, khuyết điểm trong lãnh đạo, chỉ đạo; nguyên nhân khách quan, chủ quan; trách nhiệm của tập thể Ban Chấp hành và những giải pháp cần tập trung thực hiện trong năm 2027.
>
> Đề nghị các đồng chí phát biểu thẳng thắn, khách quan, có căn cứ; tập trung vào những nội dung cần bổ sung, điều chỉnh, tránh lặp lại toàn bộ những kết quả đã được nêu trong báo cáo.
>
> Sau đây, xin mời các đồng chí tham gia ý kiến.
>
> *Chủ trì lần lượt mời các đồng chí phát biểu. Nếu còn nội dung chưa được làm rõ thì gợi ý bổ sung; nếu có ý kiến đại diện cấp trên, mời phát biểu tại thời điểm phù hợp.*
>
> ### 3. Tiếp thu, giải trình và kết luận phần kiểm điểm tập thể
>
> **Đồng chí chủ trì:**
>
> Xin cảm ơn các đồng chí đã tham gia thảo luận, đóng góp ý kiến đối với dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy.
>
> Các ý kiến tại Hội nghị là cơ sở quan trọng để Ban Chấp hành tiếp tục rà soát, đánh giá đầy đủ hơn kết quả lãnh đạo, chỉ đạo và trách nhiệm của tập thể trong năm 2026.
>
> Đối với những nội dung các đồng chí đã góp ý, tôi xin tiếp thu và trao đổi, làm rõ thêm một số vấn đề như sau:
>
> *[Chủ trì tiếp thu, giải trình từng nội dung cần làm rõ.]*
>
> Trên cơ sở báo cáo kiểm điểm và kết quả thảo luận, tôi đề nghị thống nhất một số nội dung:
>
> **Về ưu điểm:** [Khái quát những kết quả nổi bật đã được Hội nghị thống nhất.]
>
> **Về hạn chế, khuyết điểm:** [Nêu rõ những nội dung cần bổ sung hoặc xác định trách nhiệm.]
>
> **Về nguyên nhân và trách nhiệm:** [Làm rõ những vấn đề thuộc trách nhiệm tập thể và cá nhân có liên quan.]
>
> **Về biện pháp khắc phục:** [Xác định những nhiệm vụ, giải pháp trọng tâm cần thực hiện.]
>
> Đề nghị đồng chí thư ký ghi nhận đầy đủ các ý kiến và nội dung kết luận để bổ sung, hoàn thiện báo cáo kiểm điểm.
>
> Như vậy, Hội nghị đã hoàn thành nội dung thảo luận, kiểm điểm tập thể Ban Chấp hành Đảng ủy.
>
> Chúng ta chuyển sang nội dung tiếp theo.
>
> ---
>
> ## II. TỰ CHẤM ĐIỂM, TỰ NHẬN VÀ ĐỀ XUẤT XẾP LOẠI CHẤT LƯỢNG TẬP THỂ BAN CHẤP HÀNH ĐẢNG ỦY
>
> **Đồng chí chủ trì:**
>
> Kính thưa các đồng chí!
>
> Trên cơ sở kết quả kiểm điểm tập thể vừa được Hội nghị thảo luận, tiếp theo, Ban Chấp hành Đảng ủy tiến hành xem xét kết quả tự chấm điểm và đề xuất mức xếp loại chất lượng tập thể Ban Chấp hành năm 2026.
>
> Việc tự đánh giá, đề xuất xếp loại phải căn cứ vào kết quả thực hiện nhiệm vụ, các tiêu chí đánh giá, điều kiện xếp loại và những hạn chế, khuyết điểm đã được làm rõ tại Hội nghị.
>
> Sau đây, xin mời đồng chí [người được phân công] trình bày kết quả tự chấm điểm, các căn cứ đánh giá và mức tự nhận xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy.
>
> Xin mời đồng chí!
>
> *Người được phân công báo cáo bảng chấm điểm và mức đề xuất.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí trong Ban Chấp hành nghiên cứu, đối chiếu kết quả tự chấm điểm với những nội dung vừa được kiểm điểm; cho ý kiến về tính đầy đủ của minh chứng, mức độ hoàn thành nhiệm vụ và sự phù hợp của mức xếp loại được đề xuất.
>
> Sau đây, xin mời các đồng chí tham gia ý kiến.
>
> *Hội nghị thảo luận.*
>
> Xin cảm ơn các đồng chí!
>
> Trên cơ sở các ý kiến phát biểu, Hội nghị tiến hành thống nhất mức tự nhận, đề xuất xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy năm 2026 theo hình thức lấy ý kiến, biểu quyết được xác định phù hợp với hướng dẫn của cấp có thẩm quyền.
>
> *Chủ trì nêu cụ thể mức đề xuất, tổ chức lấy ý kiến hoặc biểu quyết theo quy trình áp dụng; thư ký ghi rõ số lượng, kết quả và các ý kiến khác nếu có.*
>
> Kết quả lấy ý kiến, biểu quyết của Hội nghị: [....].
>
> Đề nghị đồng chí thư ký ghi nhận đầy đủ kết quả để hoàn thiện hồ sơ trình cấp có thẩm quyền xem xét, quyết định.
>
> Tôi nhấn mạnh rằng mức xếp loại vừa được thống nhất là **mức tự nhận, đề xuất của tập thể Ban Chấp hành Đảng ủy**, chưa thay thế kết quả đánh giá, xếp loại của cấp có thẩm quyền.
>
> ---
>
> ## III. KIỂM ĐIỂM TRÁCH NHIỆM CÁC ĐỒNG CHÍ ỦY VIÊN BAN CHẤP HÀNH ĐẢNG ỦY
>
> **Đồng chí chủ trì:**
>
> Kính thưa Hội nghị!
>
> Tiếp theo chương trình, Hội nghị tiến hành kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy trong thực hiện chức trách, nhiệm vụ được phân công năm 2026.
>
> Đề nghị từng đồng chí tập trung báo cáo những kết quả nổi bật trong lĩnh vực được giao phụ trách, tinh thần trách nhiệm trong tham gia công tác lãnh đạo của Đảng ủy, việc chấp hành nguyên tắc và quy chế làm việc; đồng thời làm rõ những hạn chế, nguyên nhân và biện pháp khắc phục.
>
> Đối với các ý kiến góp ý, đề nghị tập trung vào trách nhiệm của từng đồng chí với tư cách là thành viên Ban Chấp hành Đảng ủy; bảo đảm khách quan, thẳng thắn, chân thành và xây dựng.
>
> ### 1. Kiểm điểm trách nhiệm đồng chí Bí thư Đảng ủy
>
> *Đề xuất phân công một đồng chí phù hợp trong Ban Chấp hành điều hành riêng phần kiểm điểm của đồng chí Bí thư, bảo đảm việc góp ý được khách quan, thuận lợi.*
>
> **Đồng chí được phân công điều hành:**
>
> Kính thưa các đồng chí!
>
> Trước hết, Hội nghị tiến hành kiểm điểm trách nhiệm của đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy trong thực hiện chức trách, nhiệm vụ được giao năm 2026.
>
> Xin trân trọng kính mời đồng chí Huỳnh Hồng Loan trình bày nội dung kiểm điểm trách nhiệm cá nhân.
>
> *Đồng chí Bí thư trình bày.*
>
> Xin cảm ơn đồng chí!
>
> Sau đây, đề nghị các đồng chí Ủy viên Ban Chấp hành tham gia góp ý đối với nội dung kiểm điểm của đồng chí Bí thư, tập trung vào vai trò, trách nhiệm người đứng đầu, công tác lãnh đạo, chỉ đạo, điều hành và việc thực hiện nhiệm vụ được phân công.
>
> Xin mời các đồng chí!
>
> *Hội nghị thảo luận, góp ý.*
>
> Xin cảm ơn các đồng chí!
>
> Xin mời đồng chí Bí thư tiếp thu và giải trình các nội dung được góp ý.
>
> *Đồng chí Bí thư tiếp thu, giải trình.*
>
> Trên cơ sở bản kiểm điểm và các ý kiến đóng góp, đề nghị đồng chí nghiêm túc tiếp thu, bổ sung, hoàn thiện nội dung kiểm điểm; tiếp tục phát huy ưu điểm và xác định rõ biện pháp khắc phục những hạn chế đã được chỉ ra.
>
> ### 2. Kiểm điểm trách nhiệm các đồng chí Ủy viên Ban Chấp hành
>
> **Đồng chí chủ trì:**
>
> Tiếp tục chương trình, Hội nghị tiến hành kiểm điểm trách nhiệm các đồng chí Ủy viên Ban Chấp hành Đảng ủy theo thứ tự đã thống nhất.
>
> Trước hết, xin mời đồng chí [họ tên, chức vụ] trình bày nội dung kiểm điểm trách nhiệm trong thực hiện nhiệm vụ được phân công năm 2026.
>
> Xin mời đồng chí!
>
> *Đồng chí được mời trình bày.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí trong Ban Chấp hành tham gia nhận xét, góp ý, làm rõ những kết quả đã đạt được, những hạn chế cần khắc phục và trách nhiệm trong việc thực hiện nhiệm vụ được phân công.
>
> Xin mời các đồng chí!
>
> *Hội nghị góp ý.*
>
> Xin cảm ơn các đồng chí!
>
> Xin mời đồng chí [họ tên] tiếp thu, giải trình các ý kiến góp ý.
>
> *Sau khi cá nhân tiếp thu, giải trình:*
>
> Đề nghị đồng chí tiếp tục phát huy những ưu điểm, nghiêm túc tiếp thu các ý kiến đóng góp và cụ thể hóa biện pháp khắc phục trong thời gian tới.
>
> *Tiếp tục thực hiện tương tự đối với các đồng chí Ủy viên Ban Chấp hành còn lại.*
>
> **Kết thúc nội dung:**
>
> Kính thưa các đồng chí!
>
> Như vậy, Hội nghị đã hoàn thành phần kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy.
>
> Đề nghị từng đồng chí căn cứ các ý kiến đóng góp để bổ sung, hoàn thiện nội dung kiểm điểm cá nhân, xác định những việc cần tập trung khắc phục, gắn với nhiệm vụ được phân công trong thời gian tới.
>
> Việc đánh giá, đề xuất xếp loại chất lượng đối với từng cá nhân được thực hiện theo đúng đối tượng, quy trình và thẩm quyền quy định.
>
> Chúng ta chuyển sang nội dung tiếp theo.
>
> ---
>
> ## IV. XEM XÉT HỒ SƠ ĐÁNH GIÁ, XẾP LOẠI CHẤT LƯỢNG CỦA 03 CHI BỘ TRỰC THUỘC
>
> **Đồng chí chủ trì:**
>
> Kính thưa Hội nghị!
>
> Tiếp theo chương trình, Ban Chấp hành Đảng ủy tiến hành xem xét hồ sơ kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 của 03 chi bộ trực thuộc Đảng bộ Trường Mầm non An Bình.
>
> Nội dung này nhằm xem xét kết quả kiểm điểm, đánh giá của từng chi bộ; đối chiếu giữa mức tự nhận, đề xuất xếp loại với kết quả thực hiện nhiệm vụ và những tiêu chí, điều kiện theo quy định.
>
> Đề nghị các đồng chí tập trung nghiên cứu kết quả thực hiện nhiệm vụ chính trị, công tác xây dựng Đảng, chất lượng sinh hoạt chi bộ, trách nhiệm của tập thể chi ủy, kết quả đánh giá đảng viên và những vấn đề còn hạn chế.
>
> ### 1. Báo cáo kết quả của từng chi bộ
>
> Trước hết, xin mời đại diện Chi bộ [tên chi bộ thứ nhất] báo cáo tóm tắt kết quả kiểm điểm, đánh giá, xếp loại chất lượng tập thể chi ủy, chi bộ và đảng viên năm 2026.
>
> Xin mời đồng chí!
>
> *Đại diện chi bộ báo cáo.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí trong Ban Chấp hành Đảng ủy cho ý kiến về kết quả đánh giá của chi bộ, nhất là mức tự nhận xếp loại, các căn cứ minh chứng và những nội dung cần bổ sung, làm rõ.
>
> *Hội nghị thảo luận, chủ trì kết luận nội dung cần ghi nhận và tiếp tục hoàn thiện đối với chi bộ.*
>
> Tiếp theo, xin mời đại diện Chi bộ [tên chi bộ thứ hai] trình bày báo cáo.
>
> *Thực hiện tương tự.*
>
> Sau đây, xin mời đại diện Chi bộ [tên chi bộ thứ ba] trình bày báo cáo.
>
> *Thực hiện tương tự.*
>
> ### 2. Thảo luận, nhận xét và thống nhất kết quả xem xét
>
> Kính thưa các đồng chí!
>
> Hội nghị đã nghe báo cáo kết quả kiểm điểm, đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc.
>
> Qua các báo cáo và hồ sơ được trình, đề nghị các đồng chí tiếp tục cho ý kiến đối với những trường hợp còn có nội dung cần làm rõ; nhất là sự thống nhất giữa kết quả thực hiện nhiệm vụ, những hạn chế đã được chỉ ra và mức xếp loại được đề xuất.
>
> Đề nghị các đồng chí trao đổi trên tinh thần khách quan, công tâm, bảo đảm đánh giá đúng thực chất hoạt động của từng chi bộ và đảng viên.
>
> *Hội nghị tiếp tục thảo luận những trường hợp cần thiết.*
>
> Trên cơ sở kết quả xem xét, đề nghị đồng chí thư ký tổng hợp đầy đủ các ý kiến của Ban Chấp hành đối với từng chi bộ, ghi rõ những nội dung đã thống nhất, những nội dung còn phải bổ sung minh chứng và kết quả lấy ý kiến hoặc biểu quyết theo quy trình áp dụng.
>
> Đối với những trường hợp hồ sơ chưa đầy đủ, yêu cầu chi bộ liên quan bổ sung, làm rõ trước khi hoàn thiện kết quả đánh giá, xếp loại hoặc trình cấp có thẩm quyền.
>
> ---
>
> ## V. XEM XÉT CÁC TẬP THỂ, CÁ NHÂN ĐƯỢC ĐỀ XUẤT MỨC “HOÀN THÀNH XUẤT SẮC NHIỆM VỤ”
>
> **Đồng chí chủ trì:**
>
> Kính thưa các đồng chí!
>
> Tiếp theo chương trình, Hội nghị tiến hành xem xét riêng các tập thể chi ủy, chi bộ và đảng viên được đề xuất mức xếp loại “Hoàn thành xuất sắc nhiệm vụ” năm 2026.
>
> Đây là nội dung cần được xem xét thận trọng, bảo đảm việc đề xuất mức xếp loại cao nhất phải thực sự dựa trên kết quả, thành tích nổi bật và mức độ hoàn thành nhiệm vụ của từng tập thể, cá nhân.
>
> Việc xem xét không chỉ căn cứ vào số điểm tự chấm hoặc mức đề xuất của chi bộ mà cần đối chiếu đầy đủ điều kiện, tiêu chí, minh chứng, những hạn chế nếu có và tỷ lệ theo quy định.
>
> Sau đây, xin mời đồng chí [người được phân công] trình bày danh sách các tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”, kèm theo kết quả đánh giá và căn cứ đề xuất.
>
> Xin mời đồng chí!
>
> *Người được phân công trình bày danh sách.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí tập trung xem xét từng trường hợp, nhất là kết quả thực hiện nhiệm vụ nổi bật, những đóng góp cụ thể, chất lượng sản phẩm công tác và việc đáp ứng đầy đủ điều kiện xếp loại.
>
> Đối với trường hợp còn có ý kiến khác nhau, đề nghị các đồng chí trao đổi làm rõ, bảo đảm việc đề xuất khách quan, công bằng, đúng tiêu chuẩn.
>
> Sau đây, xin mời các đồng chí tham gia ý kiến.
>
> *Hội nghị xem xét từng trường hợp.*
>
> Trên cơ sở thảo luận, Hội nghị tiến hành lấy ý kiến hoặc biểu quyết đối với các trường hợp thuộc phạm vi xem xét của Ban Chấp hành, theo đúng quy trình và thẩm quyền.
>
> *Chủ trì tổ chức lấy ý kiến hoặc biểu quyết theo hướng dẫn áp dụng; thư ký tổng hợp và ghi đầy đủ kết quả đối với từng trường hợp.*
>
> Đề nghị đồng chí thư ký ghi rõ kết quả xem xét, mức đề xuất, những trường hợp đủ điều kiện và những trường hợp cần tiếp tục rà soát hồ sơ, minh chứng.
>
> Như vậy, Hội nghị đã hoàn thành nội dung xem xét các đề xuất mức “Hoàn thành xuất sắc nhiệm vụ” năm 2026.
>
> ---
>
> ## VI. THỐNG NHẤT HỒ SƠ VÀ NHIỆM VỤ SAU HỘI NGHỊ
>
> **Đồng chí chủ trì:**
>
> Kính thưa các đồng chí!
>
> Sau khi hoàn thành các nội dung kiểm điểm, thảo luận và xem xét kết quả đánh giá, xếp loại chất lượng, Hội nghị chuyển sang phần thống nhất việc hoàn thiện hồ sơ và những nhiệm vụ cần thực hiện sau Hội nghị.
>
> Trước hết, xin mời đồng chí **Phan Thị Mỹ Hạnh – Thư ký Hội nghị** báo cáo tóm tắt kết quả tổng hợp các nội dung đã được thảo luận, thống nhất; những vấn đề còn cần bổ sung, hoàn thiện.
>
> Xin mời đồng chí!
>
> *Thư ký báo cáo tóm tắt kết quả Hội nghị.*
>
> Xin cảm ơn đồng chí!
>
> Trên cơ sở kết quả làm việc, tôi đề nghị tập trung thực hiện một số nhiệm vụ sau:
>
> **Thứ nhất,** hoàn thiện Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026, tiếp thu đầy đủ những ý kiến đã được thống nhất tại Hội nghị.
>
> **Thứ hai,** rà soát kết quả tự chấm điểm, mức tự nhận và đề xuất xếp loại chất lượng tập thể Ban Chấp hành, bảo đảm thống nhất giữa báo cáo kiểm điểm, bảng chấm điểm và các tài liệu minh chứng.
>
> **Thứ ba,** hoàn thiện hồ sơ đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc; yêu cầu bổ sung, làm rõ những trường hợp còn thiếu căn cứ hoặc có nội dung cần điều chỉnh.
>
> **Thứ tư,** tổng hợp kết quả xem xét các tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”, bảo đảm đúng tiêu chí, điều kiện và thẩm quyền.
>
> **Thứ năm,** hoàn thiện biên bản, các bảng tổng hợp, danh sách, tờ trình và hồ sơ liên quan; thực hiện việc gửi cấp có thẩm quyền theo thời hạn được hướng dẫn.
>
> **Thứ sáu,** phân công theo dõi, tham mưu xây dựng và thực hiện các biện pháp khắc phục hạn chế, khuyết điểm đã được chỉ ra qua kiểm điểm.
>
> Đối với từng nội dung, đề nghị xác định rõ đồng chí hoặc bộ phận chịu trách nhiệm chính, thời gian hoàn thành và kết quả cần báo cáo để bảo đảm việc thực hiện sau Hội nghị được nghiêm túc, đầy đủ.
>
> *Chủ trì phân công cụ thể công việc, người thực hiện và thời hạn hoàn thành.*
>
> ---
>
> # C. PHẦN KẾT THÚC HỘI NGHỊ
>
> ## 1. Phát biểu kết luận Hội nghị
>
> **Đồng chí Bí thư Đảng ủy:**
>
> Kính thưa các đồng chí!
>
> Sau thời gian làm việc với tinh thần nghiêm túc, dân chủ, trách nhiệm và xây dựng, Hội nghị Ban Chấp hành Đảng ủy Trường Mầm non An Bình về kiểm điểm, đánh giá, đề xuất xếp loại chất lượng năm 2026 đã thực hiện các nội dung theo chương trình đề ra.
>
> Hội nghị đã tập trung kiểm điểm tập thể Ban Chấp hành Đảng ủy; thảo luận, làm rõ những kết quả đạt được trong công tác lãnh đạo, chỉ đạo, những hạn chế, khuyết điểm, nguyên nhân và trách nhiệm của tập thể, cá nhân có liên quan.
>
> Các đồng chí Ủy viên Ban Chấp hành đã thể hiện tinh thần trách nhiệm trong tự phê bình và phê bình, nghiêm túc nhìn nhận kết quả thực hiện chức trách, nhiệm vụ được giao.
>
> Hội nghị cũng đã xem xét kết quả kiểm điểm, đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc và các trường hợp được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”, trên cơ sở hồ sơ và những căn cứ được báo cáo, thảo luận tại Hội nghị.
>
> Thay mặt Ban Chấp hành Đảng ủy, tôi ghi nhận tinh thần trách nhiệm và những ý kiến đóng góp của các đồng chí.
>
> Để kết quả Hội nghị thực sự phát huy hiệu quả, tôi đề nghị các đồng chí tập trung thực hiện tốt một số nội dung:
>
> Một là, tiếp tục rà soát, hoàn thiện đầy đủ hồ sơ kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 theo những nội dung đã thống nhất.
>
> Hai là, nghiêm túc tiếp thu các ý kiến góp ý, không dừng lại ở việc hoàn thiện báo cáo mà phải chuyển thành những biện pháp khắc phục cụ thể, phù hợp với trách nhiệm và nhiệm vụ được giao.
>
> Ba là, tiếp tục phát huy vai trò lãnh đạo của Ban Chấp hành Đảng ủy, nâng cao chất lượng hoạt động của các chi bộ và trách nhiệm nêu gương của từng cán bộ, đảng viên.
>
> Bốn là, tập trung chuẩn bị tốt chương trình, nhiệm vụ công tác năm 2027; quan tâm giải quyết những hạn chế đã được chỉ ra, tạo chuyển biến rõ nét trong công tác xây dựng Đảng và thực hiện nhiệm vụ chính trị của nhà trường.
>
> Đề nghị các đồng chí được phân công nghiêm túc triển khai thực hiện, bảo đảm tiến độ, chất lượng và đầy đủ hồ sơ theo yêu cầu.
>
> Một lần nữa, xin cảm ơn tinh thần trách nhiệm của toàn thể các đồng chí trong Hội nghị.
>
> ## 2. Thông qua biên bản Hội nghị
>
> **Người điều hành:**
>
> Kính thưa Hội nghị!
>
> Trước khi kết thúc chương trình, để bảo đảm nội dung biên bản phản ánh đầy đủ, chính xác diễn biến và kết quả làm việc, xin kính mời đồng chí **Phan Thị Mỹ Hạnh – Thư ký Hội nghị** thông qua biên bản Hội nghị.
>
> Xin mời đồng chí!
>
> *Thư ký thông qua biên bản.*
>
> Xin cảm ơn đồng chí thư ký!
>
> Xin ý kiến các đồng chí đối với nội dung biên bản vừa được thông qua. Có đồng chí nào đề nghị bổ sung, điều chỉnh hoặc làm rõ nội dung nào không?
>
> *Dừng để Hội nghị góp ý; thư ký tiếp thu, chỉnh sửa nếu có.*
>
> Nếu không còn ý kiến khác, xin Hội nghị thống nhất thông qua nội dung biên bản sau khi đã tiếp thu các ý kiến bổ sung, điều chỉnh.
>
> *Chủ trì xác nhận sự thống nhất của Hội nghị và yêu cầu hoàn thiện, ký biên bản theo quy định.*
>
> ## 3. Bế mạc Hội nghị
>
> **Đồng chí chủ trì:**
>
> Kính thưa các đồng chí!
>
> Đến đây, Hội nghị kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026 của Đảng ủy Trường Mầm non An Bình đã hoàn thành chương trình đề ra.
>
> Thay mặt Đảng ủy, tôi trân trọng cảm ơn các đồng chí đã tham dự và đóng góp ý kiến với tinh thần nghiêm túc, trách nhiệm, xây dựng.
>
> Đề nghị các đồng chí tiếp tục thực hiện tốt những nội dung đã được Hội nghị thống nhất và các nhiệm vụ được phân công.
>
> Tôi xin tuyên bố kết thúc Hội nghị.
>
> Kính chúc các đồng chí sức khỏe và hoàn thành tốt nhiệm vụ được giao.
>
> **Xin trân trọng cảm ơn!**

## Một số điều chỉnh tôi đề xuất trước khi sử dụng

Bản kịch bản trên đã bổ sung lời dẫn, lời chuyển ý và các đoạn điều hành còn thiếu trong chương trình gốc. Có ba điểm cần đặc biệt lưu ý:

1\. **Phân vai điều hành:** Nên để một đồng chí được phân công dẫn phần mở đầu, sau đó đồng chí Huỳnh Hồng Loan trực tiếp điều hành phần kiểm điểm, thảo luận và kết luận. Riêng phần kiểm điểm trách nhiệm của đồng chí Bí thư nên bố trí người điều hành phù hợp để thuận tiện cho việc góp ý khách quan.

2\. **Không kết luận xếp loại trước khi thảo luận:** Những mức xếp loại, số điểm và kết quả biểu quyết phải được bổ sung theo diễn biến thực tế. Đặc biệt, cần phân biệt việc xem xét, đề xuất với việc quyết định xếp loại thuộc thẩm quyền theo phân cấp.

3\. **Rà soát hồ sơ trước Hội nghị:** Cần bổ sung tên đầy đủ của ba chi bộ, tổng số Ủy viên Ban Chấp hành, danh sách người trình bày báo cáo, phương thức lấy ý kiến hoặc biểu quyết và các biểu mẫu theo hướng dẫn cấp ủy cấp trên. Đồng thời kiểm tra trường hợp chuyển tiếp theo Quy định 208-QĐ/TW nếu Đảng bộ thuộc diện tổ chức lại trong năm 2026.

**Về cách dẫn, tôi đề xuất sử dụng bản này theo hướng “ít nghi thức, rõ nội dung, chú trọng điều hành”.** Đây là Hội nghị kiểm điểm của Ban Chấp hành Đảng ủy, nên trọng tâm không phải những lời giới thiệu dài mà là tạo không khí dân chủ, gợi mở thảo luận, làm rõ trách nhiệm, thống nhất kết quả và giao nhiệm vụ cụ thể sau Hội nghị.

---

USER

dựa vào chương trình bổ sung này.  bạn hòa thành lại giúp minh nhé

---

ASSISTANT

Tôi sẽ hoàn thiện lại kịch bản theo chương trình bổ sung, giữ đúng các thông tin mới: ba đại biểu cấp phường, 7/7 đồng chí dự họp, đồng chí Phan Thị Mỹ Hạnh làm thư ký và đồng chí Nguyễn Thị Ngọc Phượng trình bày báo cáo kiểm điểm tập thể. Tôi cũng sẽ viết đầy đủ lời mời, lời chuyển ý, gợi mở thảo luận và kết luận để có thể sử dụng trực tiếp tại hội nghị.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đã đối chiếu chương trình bổ sung mới nhất với hai tài liệu trước đó và biên tập lại thành **kịch bản dẫn và điều hành Hội nghị Đảng ủy Trường Mầm non An Bình năm 2026 hoàn chỉnh**, có thể sử dụng trực tiếp tại hội nghị.

Bản này giữ đúng thông tin về ba đại biểu cấp phường, 07/07 đồng chí Ủy viên Ban Chấp hành tham dự, đồng chí Huỳnh Hồng Loan chủ trì, đồng chí Nguyễn Thị Ngọc Phượng trình bày báo cáo kiểm điểm tập thể và đồng chí Phan Thị Mỹ Hạnh làm thư ký.

Tôi cũng bổ sung lời mời, lời cảm ơn, chuyển tiếp giữa sáu nội dung, gợi ý thảo luận, xử lý biểu quyết và phần kết luận. Các nội dung chưa có kết quả thực tế sẽ được để trống, không tự ấn định mức xếp loại.

> **writing · document**
>
> # KỊCH BẢN DẪN VÀ ĐIỀU HÀNH HỘI NGHỊ
>
> **KIỂM ĐIỂM, TỰ ĐÁNH GIÁ, ĐỀ XUẤT XẾP LOẠI CHẤT LƯỢNG BAN CHẤP HÀNH ĐẢNG ỦY VÀ XEM XÉT KẾT QUẢ ĐÁNH GIÁ TẬP THỂ CHI ỦY, CHI BỘ, ĐẢNG VIÊN NĂM 2026**
>
> **ĐẢNG ỦY TRƯỜNG MẦM NON AN BÌNH**
>
> **Thời gian:** 15 giờ 00 phút, ngày 10 tháng 11 năm 2026.
>
> **Địa điểm:** Phòng họp Trường Mầm non An Bình.
>
> **Chủ trì:** Đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy.
>
> **Thư ký:** Đồng chí Phan Thị Mỹ Hạnh.
>
> *Ghi chú: Các dòng in nghiêng dùng để hướng dẫn điều hành, không đọc tại Hội nghị. Những nội dung trong dấu [ ] được bổ sung theo diễn biến và kết quả thực tế.*
>
> ---
>
> # I. PHẦN MỞ ĐẦU
>
> ## 1. Tuyên bố lý do, giới thiệu đại biểu
>
> **Người dẫn chương trình:**
>
> Kính thưa các đồng chí đại biểu!
>
> Kính thưa toàn thể Hội nghị!
>
> Thực hiện chương trình công tác và kế hoạch kiểm điểm, đánh giá, xếp loại chất lượng tổ chức đảng, đảng viên năm 2026, hôm nay, Đảng ủy Trường Mầm non An Bình tổ chức Hội nghị kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026.
>
> Hội nghị nhằm đánh giá toàn diện, khách quan kết quả lãnh đạo, chỉ đạo và tổ chức thực hiện nhiệm vụ của Ban Chấp hành Đảng ủy trong năm; làm rõ những ưu điểm, kết quả đạt được, đồng thời nghiêm túc nhìn nhận những hạn chế, khuyết điểm, xác định nguyên nhân, trách nhiệm và biện pháp khắc phục trong thời gian tới.
>
> Đồng thời, Hội nghị xem xét kết quả kiểm điểm, đánh giá, xếp loại chất lượng của các chi bộ trực thuộc, bảo đảm việc đánh giá đúng thực chất, công tâm, khách quan, làm cơ sở thực hiện các bước tiếp theo theo đúng quy định và thẩm quyền.
>
> Đó là lý do của Hội nghị hôm nay.
>
> **Kính thưa Hội nghị!**
>
> Về tham dự Hội nghị hôm nay, tôi xin trân trọng giới thiệu:
>
> - Đồng chí **Trần Thụy Ngọc Diễm** – Ủy viên Ban Thường vụ Đảng ủy, Chủ tịch Ủy ban Mặt trận Tổ quốc Việt Nam phường.
> - Đồng chí **Trần Thị Mai** – Đảng ủy viên, Phó Trưởng ban Xây dựng Đảng Đảng ủy phường An Bình.
> - Đồng chí **Nguyễn Quốc Đại** – Ủy ban Kiểm tra Đảng ủy phường An Bình.
>
> Xin trân trọng giới thiệu:
>
> - Đồng chí **Huỳnh Hồng Loan** – Bí thư Đảng ủy Trường Mầm non An Bình, chủ trì Hội nghị.
> - Cùng toàn thể các đồng chí Ủy viên Ban Chấp hành Đảng ủy Trường Mầm non An Bình có mặt tại Hội nghị hôm nay.
>
> Xin trân trọng chào mừng các đồng chí đại biểu cùng toàn thể các đồng chí tham dự Hội nghị!
>
> ## 2. Báo cáo số lượng dự họp, giới thiệu thư ký
>
> Kính thưa Hội nghị!
>
> Trước khi tiến hành các nội dung làm việc, tôi xin báo cáo số lượng Ủy viên Ban Chấp hành Đảng ủy tham dự Hội nghị như sau:
>
> Tổng số Ủy viên Ban Chấp hành Đảng ủy là **07 đồng chí**; có mặt **07/07 đồng chí**, đạt 100%; vắng mặt **0 đồng chí**.
>
> Thư ký Hội nghị là đồng chí **Phan Thị Mỹ Hạnh**.
>
> Đề nghị đồng chí thư ký theo dõi, ghi chép đầy đủ, trung thực diễn biến Hội nghị; các ý kiến thảo luận, góp ý, nội dung tiếp thu, giải trình, kết luận của chủ trì và kết quả lấy ý kiến, biểu quyết để hoàn thiện biên bản, hồ sơ Hội nghị theo quy định.
>
> ## 3. Thông qua chương trình làm việc
>
> Kính thưa các đồng chí!
>
> Theo chương trình đã được chuẩn bị, Hội nghị hôm nay tập trung thực hiện 06 nội dung trọng tâm:
>
> **Nội dung thứ nhất:** Kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> **Nội dung thứ hai:** Tự chấm điểm, tự nhận và đề xuất xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy.
>
> **Nội dung thứ ba:** Kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy trong thực hiện chức trách, nhiệm vụ được phân công.
>
> **Nội dung thứ tư:** Xem xét hồ sơ đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc.
>
> **Nội dung thứ năm:** Xem xét các tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”.
>
> **Nội dung thứ sáu:** Thống nhất việc hoàn thiện hồ sơ và phân công nhiệm vụ sau Hội nghị.
>
> Cuối cùng là phần kết luận và thông qua biên bản Hội nghị.
>
> Trên đây là toàn bộ chương trình làm việc.
>
> Xin ý kiến các đồng chí về nội dung chương trình vừa thông qua.
>
> *Dừng để Hội nghị cho ý kiến.*
>
> Nếu không có ý kiến khác, xin Hội nghị thống nhất thực hiện theo chương trình đã đề ra.
>
> Xin trân trọng cảm ơn các đồng chí!
>
> ## 4. Mời đồng chí Bí thư Đảng ủy quán triệt mục đích, yêu cầu
>
> Kính thưa Hội nghị!
>
> Để công tác kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 được thực hiện nghiêm túc, dân chủ, khách quan, đúng nguyên tắc, quy trình và thẩm quyền, tiếp theo chương trình, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy Trường Mầm non An Bình**, chủ trì Hội nghị, phát biểu quán triệt mục đích, yêu cầu và những nội dung cần lưu ý trong quá trình kiểm điểm, đánh giá, xếp loại chất lượng năm 2026.
>
> Xin trân trọng kính mời đồng chí!
>
> ### Gợi ý phát biểu quán triệt của đồng chí Bí thư Đảng ủy
>
> Kính thưa các đồng chí đại biểu!
>
> Kính thưa toàn thể Hội nghị!
>
> Hội nghị kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 có ý nghĩa quan trọng đối với công tác xây dựng Đảng của Đảng bộ Trường Mầm non An Bình. Đây không chỉ là việc đánh giá kết quả thực hiện nhiệm vụ trong năm mà còn là dịp để tập thể Ban Chấp hành và từng đồng chí cấp ủy viên nghiêm túc tự nhìn nhận trách nhiệm, phát huy ưu điểm, khắc phục hạn chế và xác định nhiệm vụ trong thời gian tới.
>
> Để Hội nghị đạt yêu cầu đề ra, tôi đề nghị các đồng chí tập trung thực hiện tốt một số nội dung sau:
>
> **Thứ nhất,** phát huy tinh thần tự phê bình và phê bình, bảo đảm dân chủ, thẳng thắn, khách quan, trung thực và xây dựng. Việc đánh giá phải phản ánh đúng thực chất, không né tránh hạn chế, khuyết điểm, đồng thời giữ gìn sự đoàn kết, thống nhất trong Ban Chấp hành Đảng ủy.
>
> **Thứ hai,** nội dung kiểm điểm phải bám sát chức năng, nhiệm vụ, quy chế làm việc, chương trình công tác và những nhiệm vụ được giao trong năm. Đề nghị các đồng chí tập trung làm rõ kết quả thực hiện, những vấn đề còn hạn chế, nguyên nhân và trách nhiệm có liên quan.
>
> **Thứ ba,** đối với việc kiểm điểm trách nhiệm cá nhân, từng đồng chí Ủy viên Ban Chấp hành cần gắn nội dung kiểm điểm với nhiệm vụ được phân công, thể hiện rõ tinh thần trách nhiệm, vai trò nêu gương và những việc đã làm được, chưa làm được.
>
> **Thứ tư,** đối với kết quả đánh giá, xếp loại của các chi bộ và đảng viên, đề nghị các đồng chí xem xét thận trọng, đối chiếu tiêu chí, điều kiện, minh chứng và phân cấp thẩm quyền; không đánh giá theo cảm tính, không chạy theo thành tích.
>
> **Thứ năm,** sau kiểm điểm, từng tập thể, cá nhân phải xác định rõ những hạn chế cần khắc phục, biện pháp thực hiện và trách nhiệm theo dõi. Kết quả kiểm điểm phải góp phần tạo chuyển biến tích cực trong công tác xây dựng Đảng và thực hiện nhiệm vụ chính trị của nhà trường.
>
> Với tinh thần đó, đề nghị các đồng chí tập trung nghiên cứu tài liệu, phát huy trách nhiệm, tham gia ý kiến có trọng tâm để Hội nghị hoàn thành tốt các nội dung đề ra.
>
> Xin trân trọng cảm ơn các đồng chí!
>
> ### Người dẫn chương trình tiếp lời
>
> Xin trân trọng cảm ơn đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy đã quán triệt mục đích, yêu cầu và định hướng những nội dung trọng tâm của Hội nghị.
>
> Đề nghị các đồng chí phát huy tinh thần trách nhiệm, tập trung nghiên cứu, thảo luận để các nội dung kiểm điểm, đánh giá được thực hiện nghiêm túc, hiệu quả.
>
> Sau đây, Hội nghị chuyển sang phần nội dung làm việc.
>
> ---
>
> # II. PHẦN NỘI DUNG LÀM VIỆC
>
> ## 1. KIỂM ĐIỂM TẬP THỂ BAN CHẤP HÀNH ĐẢNG ỦY
>
> ### 1.1. Trình bày dự thảo Báo cáo kiểm điểm tập thể
>
> **Người dẫn chương trình:**
>
> Kính thưa các đồng chí đại biểu!
>
> Kính thưa Hội nghị!
>
> Mở đầu phần nội dung, Hội nghị tiến hành kiểm điểm tập thể Ban Chấp hành Đảng ủy Trường Mầm non An Bình năm 2026.
>
> Nội dung kiểm điểm tập trung đánh giá kết quả lãnh đạo, chỉ đạo thực hiện nhiệm vụ chính trị, công tác xây dựng Đảng, việc thực hiện nguyên tắc tập trung dân chủ, quy chế làm việc, công tác kiểm tra, giám sát và trách nhiệm của tập thể Ban Chấp hành trong năm.
>
> Sau đây, xin trân trọng kính mời đồng chí **Nguyễn Thị Ngọc Phượng – Phó Bí thư Đảng ủy Trường Mầm non An Bình**, thay mặt Ban Chấp hành Đảng ủy, trình bày dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> Xin trân trọng kính mời đồng chí!
>
> *Đồng chí Nguyễn Thị Ngọc Phượng trình bày báo cáo.*
>
> ### 1.2. Gợi ý thảo luận
>
> **Người dẫn chương trình:**
>
> Xin trân trọng cảm ơn đồng chí Nguyễn Thị Ngọc Phượng!
>
> Kính thưa Hội nghị!
>
> Hội nghị vừa nghe dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> Để việc kiểm điểm bảo đảm khách quan, toàn diện và đi vào thực chất, đề nghị các đồng chí tập trung nghiên cứu, tham gia góp ý đối với những kết quả đạt được, những hạn chế, khuyết điểm, nguyên nhân và trách nhiệm của tập thể trong công tác lãnh đạo, chỉ đạo.
>
> Sau đây, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy**, chủ trì điều hành phần thảo luận, đóng góp ý kiến đối với dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy.
>
> Xin trân trọng kính mời đồng chí!
>
> **Đồng chí Bí thư Đảng ủy điều hành:**
>
> Kính thưa các đồng chí!
>
> Trên cơ sở dự thảo Báo cáo kiểm điểm vừa được trình bày, tôi đề nghị các đồng chí tập trung tham gia ý kiến vào một số vấn đề trọng tâm:
>
> Một là, kết quả lãnh đạo, chỉ đạo thực hiện nghị quyết, chương trình công tác và các nhiệm vụ chính trị của Đảng bộ trong năm 2026.
>
> Hai là, việc thực hiện nguyên tắc tập trung dân chủ, quy chế làm việc, chế độ sinh hoạt cấp ủy, sự phối hợp trong lãnh đạo, chỉ đạo và giữ gìn đoàn kết nội bộ.
>
> Ba là, kết quả lãnh đạo công tác xây dựng Đảng; công tác chính trị, tư tưởng; quản lý, giáo dục đảng viên; kiểm tra, giám sát và nâng cao chất lượng hoạt động của các chi bộ trực thuộc.
>
> Bốn là, trách nhiệm của Ban Chấp hành trong lãnh đạo thực hiện nhiệm vụ của nhà trường, đặc biệt là công tác chăm sóc, nuôi dưỡng, giáo dục trẻ; xây dựng đội ngũ, duy trì nền nếp, kỷ cương và bảo đảm an toàn trường học.
>
> Năm là, những hạn chế, khuyết điểm trong công tác lãnh đạo, chỉ đạo; nguyên nhân chủ quan, khách quan; trách nhiệm của tập thể Ban Chấp hành và các giải pháp cần tập trung thực hiện trong thời gian tới.
>
> Đề nghị các đồng chí tham gia ý kiến thẳng thắn, khách quan, tập trung làm rõ những nội dung cần bổ sung, điều chỉnh; đồng thời đề xuất những giải pháp cụ thể, khả thi.
>
> Sau đây, xin mời các đồng chí tham gia thảo luận.
>
> *Chủ trì lần lượt mời các đồng chí Ủy viên Ban Chấp hành phát biểu.*
>
> *Trường hợp đại biểu Đảng ủy phường có ý kiến nhận xét, góp ý hoặc chỉ đạo, chủ trì bố trí mời phát biểu trước khi kết luận phần kiểm điểm tập thể.*
>
> ### 1.3. Tiếp thu, giải trình và kết luận
>
> **Đồng chí Bí thư Đảng ủy:**
>
> Xin trân trọng cảm ơn các ý kiến tham gia đóng góp của các đồng chí.
>
> Các ý kiến tại Hội nghị thể hiện tinh thần trách nhiệm, thẳng thắn và xây dựng, giúp Ban Chấp hành nhìn nhận đầy đủ hơn kết quả lãnh đạo, chỉ đạo và những vấn đề cần tiếp tục quan tâm khắc phục.
>
> Thay mặt Ban Chấp hành Đảng ủy, tôi xin tiếp thu những ý kiến đóng góp của các đồng chí. Đối với một số nội dung cần làm rõ, tôi xin trao đổi, giải trình thêm như sau:
>
> *[Đồng chí Bí thư giải trình các nội dung phát sinh từ ý kiến thảo luận.]*
>
> Trên cơ sở dự thảo Báo cáo kiểm điểm và ý kiến đóng góp tại Hội nghị, tôi đề nghị thống nhất một số nội dung:
>
> **Về ưu điểm:** [Khái quát những kết quả nổi bật được Hội nghị thống nhất.]
>
> **Về hạn chế, khuyết điểm:** [Nêu những nội dung cần làm rõ, bổ sung hoặc điều chỉnh.]
>
> **Về nguyên nhân và trách nhiệm:** [Xác định những vấn đề thuộc trách nhiệm lãnh đạo của tập thể và trách nhiệm liên quan.]
>
> **Về nhiệm vụ, giải pháp khắc phục:** [Nêu những biện pháp trọng tâm cần thực hiện trong năm 2027.]
>
> Đề nghị đồng chí Phó Bí thư Đảng ủy phối hợp với các đồng chí có liên quan tiếp thu đầy đủ ý kiến, hoàn thiện Báo cáo kiểm điểm tập thể Ban Chấp hành, bảo đảm nội dung phản ánh đúng thực tế và kết quả thảo luận tại Hội nghị.
>
> Như vậy, Hội nghị đã hoàn thành phần kiểm điểm tập thể Ban Chấp hành Đảng ủy.
>
> Xin cảm ơn các đồng chí!
>
> ---
>
> ## 2. TỰ CHẤM ĐIỂM, TỰ NHẬN VÀ ĐỀ XUẤT XẾP LOẠI CHẤT LƯỢNG TẬP THỂ BAN CHẤP HÀNH ĐẢNG ỦY
>
> **Người dẫn chương trình:**
>
> Kính thưa Hội nghị!
>
> Tiếp theo chương trình, Hội nghị tiến hành nội dung tự chấm điểm, tự nhận và đề xuất mức xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> Đây là nội dung cần được xem xét trên cơ sở kết quả kiểm điểm vừa được Hội nghị thảo luận, đối chiếu với tiêu chí đánh giá, kết quả thực hiện nhiệm vụ và những điều kiện xếp loại theo quy định.
>
> Sau đây, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy**, chủ trì điều hành nội dung tự chấm điểm, thảo luận và thống nhất mức đề xuất xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> Xin trân trọng kính mời đồng chí!
>
> ### Đồng chí Bí thư Đảng ủy điều hành
>
> Kính thưa các đồng chí!
>
> Trên cơ sở dự thảo Báo cáo kiểm điểm tập thể và kết quả thảo luận vừa qua, Ban Chấp hành Đảng ủy tiến hành xem xét bảng tự chấm điểm, xác định mức độ đáp ứng các tiêu chí đánh giá và mức tự nhận xếp loại chất lượng năm 2026.
>
> Trước hết, xin mời đồng chí [người được phân công] trình bày kết quả tự chấm điểm, các căn cứ minh chứng và mức xếp loại được đề xuất.
>
> Xin mời đồng chí!
>
> *Người được phân công trình bày bảng tự chấm điểm.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí nghiên cứu, đối chiếu từng nhóm tiêu chí, kết quả thực hiện nhiệm vụ và những hạn chế đã được chỉ ra trong báo cáo kiểm điểm.
>
> Đặc biệt, cần xem xét sự phù hợp giữa số điểm tự chấm với những kết quả thực tế, bảo đảm việc tự đánh giá khách quan, không chạy theo thành tích.
>
> Sau đây, xin mời các đồng chí tham gia ý kiến về điểm tự chấm và mức đề xuất xếp loại chất lượng của tập thể Ban Chấp hành.
>
> *Hội nghị thảo luận, điều chỉnh điểm tự chấm hoặc mức đề xuất nếu có căn cứ.*
>
> Xin cảm ơn các đồng chí!
>
> Trên cơ sở kết quả thảo luận, Ban Chấp hành Đảng ủy thống nhất xem xét:
>
> - Tổng điểm tự chấm: [....] điểm.
> - Mức tự nhận, đề xuất xếp loại chất lượng: [....].
>
> Xin ý kiến các đồng chí về nội dung vừa nêu.
>
> *Chủ trì tổ chức lấy ý kiến hoặc biểu quyết theo hình thức và quy trình được hướng dẫn áp dụng tại Hội nghị.*
>
> Đề nghị đồng chí thư ký ghi nhận chính xác kết quả, số lượng ý kiến thống nhất, không thống nhất và những nội dung cần bổ sung nếu có.
>
> Kết quả lấy ý kiến, biểu quyết: [....].
>
> Đề nghị bộ phận được phân công hoàn thiện hồ sơ, bảo đảm thống nhất giữa báo cáo kiểm điểm, bảng chấm điểm, biên bản và mức tự nhận, đề xuất xếp loại của tập thể Ban Chấp hành Đảng ủy.
>
> Lưu ý, mức xếp loại được Hội nghị thống nhất là mức tự nhận, đề xuất để báo cáo cấp có thẩm quyền xem xét, quyết định.
>
> Như vậy, Hội nghị đã hoàn thành nội dung tự chấm điểm và đề xuất xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy năm 2026.
>
> ---
>
> ## 3. KIỂM ĐIỂM TRÁCH NHIỆM CỦA CÁC ỦY VIÊN BAN CHẤP HÀNH ĐẢNG ỦY
>
> **Người dẫn chương trình:**
>
> Kính thưa các đồng chí!
>
> Tiếp theo chương trình, Hội nghị tiến hành kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy trong việc thực hiện chức trách, nhiệm vụ được phân công năm 2026.
>
> Nội dung kiểm điểm nhằm làm rõ tinh thần trách nhiệm, kết quả thực hiện nhiệm vụ của từng đồng chí; đồng thời phát huy tinh thần tự phê bình và phê bình, giúp mỗi đồng chí nhận diện đầy đủ những ưu điểm, hạn chế và xác định biện pháp khắc phục trong thời gian tới.
>
> Đề nghị các đồng chí khi trình bày tập trung vào nội dung thuộc trách nhiệm cá nhân; các ý kiến góp ý cần khách quan, thẳng thắn, có căn cứ và mang tính xây dựng.
>
> Xin trân trọng kính mời đồng chí chủ trì điều hành nội dung này.
>
> ### 3.1. Kiểm điểm trách nhiệm đồng chí Bí thư Đảng ủy
>
> *Đề xuất điều hành: Khi kiểm điểm đồng chí Huỳnh Hồng Loan, Hội nghị có thể thống nhất phân công đồng chí Nguyễn Thị Ngọc Phượng – Phó Bí thư Đảng ủy điều hành phần kiểm điểm này.*
>
> **Đồng chí Nguyễn Thị Ngọc Phượng điều hành (nếu được phân công):**
>
> Kính thưa Hội nghị!
>
> Trước hết, chúng ta tiến hành kiểm điểm trách nhiệm của đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy trong thực hiện chức trách, nhiệm vụ được giao năm 2026.
>
> Xin trân trọng kính mời đồng chí Huỳnh Hồng Loan trình bày nội dung kiểm điểm trách nhiệm cá nhân.
>
> Xin kính mời đồng chí!
>
> *Đồng chí Bí thư trình bày nội dung kiểm điểm.*
>
> Xin trân trọng cảm ơn đồng chí!
>
> Sau đây, đề nghị các đồng chí trong Ban Chấp hành tham gia góp ý, tập trung vào vai trò, trách nhiệm của người đứng đầu; kết quả lãnh đạo, chỉ đạo, điều hành và việc thực hiện chức trách, nhiệm vụ được giao.
>
> Xin mời các đồng chí tham gia ý kiến.
>
> *Hội nghị thảo luận, góp ý.*
>
> Xin cảm ơn các đồng chí!
>
> Tiếp theo, xin mời đồng chí Huỳnh Hồng Loan tiếp thu, giải trình những nội dung được góp ý và trao đổi thêm về biện pháp khắc phục những hạn chế, khuyết điểm nếu có.
>
> *Đồng chí Bí thư tiếp thu, giải trình.*
>
> Trên cơ sở nội dung tự kiểm điểm và những ý kiến đóng góp, đề nghị đồng chí nghiêm túc tiếp thu, hoàn thiện nội dung kiểm điểm, phát huy những ưu điểm và xác định rõ những nhiệm vụ cần tập trung thực hiện trong thời gian tới.
>
> Xin cảm ơn đồng chí!
>
> ### 3.2. Kiểm điểm trách nhiệm các đồng chí Ủy viên Ban Chấp hành
>
> **Đồng chí chủ trì:**
>
> Kính thưa Hội nghị!
>
> Tiếp tục chương trình, chúng ta tiến hành kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy theo thứ tự đã thống nhất.
>
> Trước hết, xin mời đồng chí [họ tên, chức vụ] trình bày nội dung kiểm điểm trách nhiệm cá nhân trong thực hiện chức trách, nhiệm vụ được phân công năm 2026.
>
> Xin mời đồng chí!
>
> *Đồng chí được mời trình bày.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí trong Ban Chấp hành tham gia nhận xét, góp ý, tập trung làm rõ kết quả thực hiện nhiệm vụ, tinh thần trách nhiệm, sự phối hợp trong công tác và những hạn chế cần khắc phục.
>
> Xin mời các đồng chí tham gia ý kiến.
>
> *Hội nghị góp ý.*
>
> Xin cảm ơn các đồng chí!
>
> Sau đây, xin mời đồng chí [họ tên] tiếp thu, giải trình những nội dung được góp ý.
>
> *Cá nhân tiếp thu, giải trình.*
>
> Đề nghị đồng chí nghiêm túc tiếp thu các ý kiến đóng góp, bổ sung, hoàn thiện nội dung kiểm điểm và xác định những giải pháp khắc phục cụ thể trong thời gian tới.
>
> Xin cảm ơn đồng chí!
>
> *Tiếp tục thực hiện trình tự tương tự đối với các đồng chí Ủy viên Ban Chấp hành còn lại.*
>
> ### 3.3. Kết thúc phần kiểm điểm trách nhiệm cá nhân
>
> **Đồng chí chủ trì:**
>
> Kính thưa các đồng chí!
>
> Như vậy, Hội nghị đã hoàn thành phần kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy năm 2026.
>
> Qua kiểm điểm, đề nghị mỗi đồng chí tiếp tục phát huy những ưu điểm, nghiêm túc tiếp thu ý kiến góp ý, nhận diện rõ những hạn chế thuộc trách nhiệm cá nhân và có biện pháp khắc phục phù hợp.
>
> Việc tự đánh giá, đề xuất xếp loại chất lượng từng cá nhân tiếp tục được thực hiện theo đúng đối tượng, quy trình và thẩm quyền quy định.
>
> Xin cảm ơn các đồng chí!
>
> ---
>
> ## 4. XEM XÉT HỒ SƠ ĐÁNH GIÁ, XẾP LOẠI CHẤT LƯỢNG CỦA 03 CHI BỘ TRỰC THUỘC
>
> **Người dẫn chương trình:**
>
> Kính thưa các đồng chí đại biểu!
>
> Kính thưa toàn thể Hội nghị!
>
> Tiếp theo chương trình, Ban Chấp hành Đảng ủy tiến hành xem xét hồ sơ đánh giá, xếp loại chất lượng năm 2026 của 03 chi bộ trực thuộc Đảng bộ Trường Mầm non An Bình.
>
> Nội dung này nhằm xem xét kết quả kiểm điểm, đánh giá của từng chi bộ; đối chiếu giữa mức tự nhận, đề xuất xếp loại với kết quả thực hiện nhiệm vụ, các tiêu chí, điều kiện và minh chứng theo quy định.
>
> Sau đây, xin trân trọng kính mời đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy, chủ trì điều hành việc xem xét hồ sơ của các chi bộ.
>
> Xin kính mời đồng chí!
>
> ### 4.1. Báo cáo kết quả của chi bộ thứ nhất
>
> **Đồng chí chủ trì:**
>
> Trước hết, xin mời đại diện Chi bộ [tên chi bộ thứ nhất] báo cáo tóm tắt kết quả kiểm điểm, đánh giá, xếp loại chất lượng tập thể chi ủy, chi bộ và đảng viên năm 2026; đồng thời trình bày bảng tổng hợp tự chấm điểm và các nội dung đề xuất.
>
> Xin mời đồng chí!
>
> *Đại diện chi bộ báo cáo.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí Ủy viên Ban Chấp hành Đảng ủy cho ý kiến đối với hồ sơ và kết quả đánh giá của chi bộ, tập trung vào mức tự nhận xếp loại, những kết quả nổi bật, các hạn chế và sự đầy đủ của tài liệu minh chứng.
>
> Xin mời các đồng chí tham gia ý kiến.
>
> *Hội nghị thảo luận.*
>
> Xin cảm ơn các đồng chí!
>
> Qua ý kiến thảo luận, đề nghị ghi nhận những nội dung đã thống nhất và yêu cầu Chi bộ [tên chi bộ] tiếp tục bổ sung, hoàn thiện những nội dung cần thiết theo kết quả xem xét của Ban Chấp hành.
>
> ### 4.2. Báo cáo kết quả của chi bộ thứ hai
>
> Tiếp theo, xin mời đại diện Chi bộ [tên chi bộ thứ hai] trình bày tóm tắt kết quả kiểm điểm, đánh giá, xếp loại chất lượng tập thể chi ủy, chi bộ và đảng viên năm 2026.
>
> Xin mời đồng chí!
>
> *Đại diện chi bộ báo cáo.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí trong Ban Chấp hành tiếp tục xem xét, đối chiếu hồ sơ, tiêu chí đánh giá và kết quả thực hiện nhiệm vụ của chi bộ; cho ý kiến đối với mức xếp loại được đề xuất.
>
> Xin mời các đồng chí tham gia ý kiến.
>
> *Hội nghị thảo luận.*
>
> Xin cảm ơn các đồng chí!
>
> Đề nghị thư ký ghi nhận đầy đủ các ý kiến và những nội dung Chi bộ [tên chi bộ] cần tiếp tục bổ sung, hoàn thiện.
>
> ### 4.3. Báo cáo kết quả của chi bộ thứ ba
>
> Tiếp tục chương trình, xin mời đại diện Chi bộ [tên chi bộ thứ ba] trình bày tóm tắt kết quả kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 của tập thể chi ủy, chi bộ và đảng viên.
>
> Xin mời đồng chí!
>
> *Đại diện chi bộ báo cáo.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí Ủy viên Ban Chấp hành tham gia góp ý, tập trung xem xét tính khách quan, phù hợp của mức tự nhận xếp loại và những căn cứ, minh chứng kèm theo.
>
> Xin mời các đồng chí!
>
> *Hội nghị thảo luận.*
>
> Xin cảm ơn các đồng chí!
>
> Đề nghị thư ký tổng hợp những nội dung đã được thống nhất và những vấn đề cần bổ sung, điều chỉnh đối với hồ sơ của chi bộ.
>
> ### 4.4. Kết luận chung phần xem xét hồ sơ của 03 chi bộ
>
> **Đồng chí chủ trì:**
>
> Kính thưa các đồng chí!
>
> Hội nghị đã nghe báo cáo và xem xét hồ sơ kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 của 03 chi bộ trực thuộc.
>
> Qua các nội dung đã được báo cáo, thảo luận, đề nghị các chi bộ tiếp tục rà soát, hoàn thiện hồ sơ, bảo đảm sự thống nhất giữa kết quả kiểm điểm, bảng tự chấm điểm, mức xếp loại đề xuất và các tài liệu minh chứng.
>
> Đối với những nội dung còn có ý kiến khác nhau hoặc chưa đầy đủ căn cứ, yêu cầu chi bộ liên quan bổ sung, giải trình trước khi hoàn thiện kết quả đánh giá hoặc trình cấp có thẩm quyền.
>
> Đề nghị đồng chí thư ký ghi nhận đầy đủ kết quả xem xét của Ban Chấp hành đối với từng chi bộ, những nội dung đã thống nhất và những vấn đề cần tiếp tục xử lý.
>
> Như vậy, Hội nghị đã hoàn thành nội dung xem xét hồ sơ đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc.
>
> ---
>
> ## 5. XEM XÉT CÁC ĐỀ XUẤT MỨC “HOÀN THÀNH XUẤT SẮC NHIỆM VỤ”
>
> **Người dẫn chương trình:**
>
> Kính thưa Hội nghị!
>
> Tiếp theo chương trình, Hội nghị tiến hành xem xét riêng các trường hợp tập thể chi ủy, chi bộ và đảng viên được đề xuất mức xếp loại “Hoàn thành xuất sắc nhiệm vụ” năm 2026, nếu có trong hồ sơ trình Hội nghị.
>
> Đây là nội dung cần được xem xét thận trọng, bảo đảm việc đề xuất mức xếp loại phù hợp với thành tích nổi bật, kết quả thực hiện nhiệm vụ, các tiêu chí và điều kiện theo quy định.
>
> Xin trân trọng kính mời đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy, chủ trì điều hành nội dung này.
>
> Xin kính mời đồng chí!
>
> ### Đồng chí Bí thư Đảng ủy điều hành
>
> Kính thưa các đồng chí!
>
> Đối với những tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”, tôi đề nghị Ban Chấp hành xem xét kỹ từng trường hợp trên cơ sở kết quả thực hiện nhiệm vụ, những thành tích nổi bật, mức độ hoàn thành các chỉ tiêu, nhiệm vụ được giao và những điều kiện, tiêu chí theo quy định.
>
> Việc xem xét cần bảo đảm khách quan, công bằng, đúng thực chất, đúng tỷ lệ và thẩm quyền; không chỉ căn cứ vào mức tự nhận hoặc đề xuất của chi bộ.
>
> Sau đây, xin mời đồng chí [người được phân công] trình bày danh sách các tập thể, cá nhân được đề nghị mức “Hoàn thành xuất sắc nhiệm vụ”, cùng những căn cứ và kết quả đánh giá có liên quan.
>
> Xin mời đồng chí!
>
> *Người được phân công trình bày.*
>
> Xin cảm ơn đồng chí!
>
> Đề nghị các đồng chí tập trung nghiên cứu, thảo luận và cho ý kiến đối với từng trường hợp, đặc biệt lưu ý những kết quả, thành tích nổi bật, tính đầy đủ của minh chứng và việc đáp ứng các điều kiện xếp loại.
>
> Đối với những trường hợp còn có ý kiến khác nhau, đề nghị trao đổi làm rõ để bảo đảm việc đề xuất được thực hiện thận trọng, có căn cứ.
>
> Sau đây, xin mời các đồng chí tham gia ý kiến.
>
> *Hội nghị thảo luận từng trường hợp.*
>
> Xin cảm ơn các đồng chí!
>
> Trên cơ sở ý kiến thảo luận, Hội nghị tiến hành thống nhất kết quả xem xét và thực hiện việc lấy ý kiến, biểu quyết đối với những trường hợp thuộc phạm vi, thẩm quyền và quy trình áp dụng.
>
> *Chủ trì tổ chức lấy ý kiến hoặc biểu quyết khi đủ điều kiện; thư ký ghi rõ kết quả từng trường hợp.*
>
> Đề nghị đồng chí thư ký tổng hợp đầy đủ kết quả xem xét, những trường hợp được thống nhất đề xuất và những nội dung cần tiếp tục rà soát, bổ sung minh chứng.
>
> Kết quả của Hội nghị phải được thể hiện đầy đủ trong biên bản, bảo đảm không kết luận vượt quá thẩm quyền.
>
> *Trường hợp không có tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”, chủ trì nêu rõ không phát sinh trường hợp để xem xét và chuyển sang nội dung tiếp theo.*
>
> Như vậy, Hội nghị đã hoàn thành nội dung xem xét các đề xuất mức “Hoàn thành xuất sắc nhiệm vụ” năm 2026.
>
> Xin cảm ơn các đồng chí!
>
> ---
>
> ## 6. THỐNG NHẤT HỒ SƠ VÀ NHIỆM VỤ SAU HỘI NGHỊ
>
> **Người dẫn chương trình:**
>
> Kính thưa các đồng chí!
>
> Sau khi hoàn thành các nội dung kiểm điểm, thảo luận và xem xét kết quả đánh giá, xếp loại chất lượng, Hội nghị chuyển sang nội dung cuối cùng của phần làm việc, đó là thống nhất việc hoàn thiện hồ sơ và phân công nhiệm vụ sau Hội nghị.
>
> Trước hết, xin trân trọng kính mời đồng chí **Phan Thị Mỹ Hạnh – Thư ký Hội nghị** báo cáo tóm tắt kết quả tổng hợp các nội dung đã được thảo luận, thống nhất và những vấn đề cần tiếp tục hoàn thiện.
>
> Xin mời đồng chí!
>
> ### Gợi ý nội dung báo cáo của thư ký
>
> Kính thưa các đồng chí đại biểu!
>
> Kính thưa Hội nghị!
>
> Qua quá trình làm việc, Hội nghị đã tiến hành kiểm điểm tập thể Ban Chấp hành Đảng ủy; tự chấm điểm, đề xuất mức xếp loại chất lượng tập thể; kiểm điểm trách nhiệm các đồng chí Ủy viên Ban Chấp hành; xem xét hồ sơ đánh giá, xếp loại của 03 chi bộ trực thuộc và các trường hợp được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”.
>
> Trên cơ sở kết quả thảo luận và các nội dung được thống nhất tại Hội nghị, thư ký xin báo cáo tóm tắt một số kết quả như sau:
>
> **Thứ nhất,** về kiểm điểm tập thể Ban Chấp hành Đảng ủy: [Tóm tắt những nội dung được thống nhất, ý kiến cần bổ sung.]
>
> **Thứ hai,** về kết quả tự chấm điểm và đề xuất xếp loại chất lượng tập thể Ban Chấp hành: [Ghi số điểm, mức đề xuất, kết quả lấy ý kiến hoặc biểu quyết.]
>
> **Thứ ba,** về kiểm điểm trách nhiệm các Ủy viên Ban Chấp hành: [Tổng hợp những vấn đề cần tiếp thu, bổ sung và hoàn thiện.]
>
> **Thứ tư,** về kết quả xem xét hồ sơ của 03 chi bộ trực thuộc: [Tóm tắt các mức đề xuất, nội dung thống nhất và những vấn đề còn cần hoàn thiện.]
>
> **Thứ năm,** về các trường hợp được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”: [Nêu kết quả xem xét theo thực tế.]
>
> **Thứ sáu,** về những tài liệu, hồ sơ cần tiếp tục hoàn thiện và báo cáo cấp có thẩm quyền: [Nêu các nội dung cần thực hiện.]
>
> Trên đây là những nội dung thư ký đã tổng hợp. Kính đề nghị Hội nghị cho ý kiến bổ sung, điều chỉnh để bảo đảm nội dung ghi nhận đầy đủ, chính xác.
>
> Xin trân trọng cảm ơn các đồng chí!
>
> ### Mời đồng chí Bí thư chỉ đạo, thống nhất phân công
>
> **Người dẫn chương trình:**
>
> Xin trân trọng cảm ơn đồng chí Phan Thị Mỹ Hạnh – Thư ký Hội nghị!
>
> Kính thưa Hội nghị!
>
> Để bảo đảm các nội dung sau kiểm điểm được triển khai kịp thời, đầy đủ, đúng yêu cầu, tiếp theo xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy**, cho ý kiến chỉ đạo và thống nhất việc phân công hoàn thiện hồ sơ, thực hiện các nhiệm vụ sau Hội nghị.
>
> Xin trân trọng kính mời đồng chí!
>
> **Đồng chí Bí thư Đảng ủy:**
>
> Kính thưa các đồng chí!
>
> Trên cơ sở những nội dung đã được Hội nghị thảo luận, thống nhất, tôi đề nghị tập trung thực hiện một số nhiệm vụ sau:
>
> **Một là,** tiếp thu, hoàn thiện Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026, bảo đảm phản ánh đầy đủ những kết quả đạt được, hạn chế, nguyên nhân và trách nhiệm đã được Hội nghị làm rõ.
>
> **Hai là,** rà soát, hoàn thiện bảng tự chấm điểm, mức tự nhận và đề xuất xếp loại chất lượng tập thể Ban Chấp hành; bảo đảm các tài liệu thống nhất với kết quả thảo luận, lấy ý kiến hoặc biểu quyết tại Hội nghị.
>
> **Ba là,** tiếp tục rà soát hồ sơ đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc, yêu cầu bổ sung những nội dung còn thiếu hoặc chưa đầy đủ căn cứ; tổng hợp kết quả xem xét để thực hiện các bước tiếp theo theo phân cấp thẩm quyền.
>
> **Bốn là,** hoàn thiện hồ sơ liên quan đến các trường hợp được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”; bảo đảm có đầy đủ căn cứ, minh chứng và kết quả xem xét.
>
> **Năm là,** hoàn thiện biên bản, bảng tổng hợp, danh sách, tờ trình và các tài liệu liên quan để báo cáo, gửi cấp có thẩm quyền theo thời gian quy định.
>
> **Sáu là,** đối với những hạn chế, khuyết điểm được chỉ ra qua kiểm điểm, đề nghị từng đồng chí có liên quan xác định rõ biện pháp khắc phục; tập thể Ban Chấp hành tiếp tục theo dõi, kiểm tra kết quả thực hiện, gắn với chương trình công tác năm 2027.
>
> Về phân công cụ thể, đề nghị:
>
> - Đồng chí [....] chịu trách nhiệm chính trong việc hoàn thiện Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy.
> - Đồng chí Phan Thị Mỹ Hạnh phối hợp tổng hợp, hoàn thiện biên bản và các tài liệu liên quan đến kết quả Hội nghị.
> - Các đồng chí được phân công phụ trách, theo dõi chi bộ phối hợp đôn đốc hoàn thiện hồ sơ của các chi bộ trực thuộc.
> - Đồng chí [....] chịu trách nhiệm tổng hợp hồ sơ, tham mưu hoàn thiện thủ tục trình cấp có thẩm quyền.
> - Thời hạn hoàn thành các nội dung: [....].
>
> *Chủ trì điều chỉnh và thống nhất nhiệm vụ, người phụ trách, thời hạn theo ý kiến Hội nghị.*
>
> Đề nghị các đồng chí được phân công nghiêm túc triển khai thực hiện, bảo đảm đúng tiến độ và chất lượng.
>
> Xin cảm ơn các đồng chí!
>
> ---
>
> # III. PHẦN KẾT THÚC HỘI NGHỊ
>
> ## 1. Mời đồng chí Bí thư Đảng ủy phát biểu kết luận
>
> **Người dẫn chương trình:**
>
> Kính thưa các đồng chí đại biểu!
>
> Kính thưa toàn thể Hội nghị!
>
> Sau thời gian làm việc với tinh thần nghiêm túc, dân chủ, trách nhiệm và xây dựng, Hội nghị đã thực hiện các nội dung theo chương trình đề ra.
>
> Để đánh giá khái quát kết quả Hội nghị và định hướng những nhiệm vụ cần tập trung thực hiện trong thời gian tới, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy Trường Mầm non An Bình**, chủ trì Hội nghị, phát biểu kết luận.
>
> Xin trân trọng kính mời đồng chí!
>
> ### Dự thảo phát biểu kết luận của đồng chí Bí thư Đảng ủy
>
> Kính thưa các đồng chí đại biểu!
>
> Kính thưa toàn thể Hội nghị!
>
> Sau thời gian làm việc nghiêm túc, dân chủ, thẳng thắn và trách nhiệm, Hội nghị kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026 của Đảng ủy Trường Mầm non An Bình đã hoàn thành các nội dung theo chương trình đề ra.
>
> Tại Hội nghị, Ban Chấp hành đã tập trung kiểm điểm, đánh giá kết quả lãnh đạo, chỉ đạo và tổ chức thực hiện nhiệm vụ trong năm 2026; làm rõ những kết quả đạt được, những hạn chế, khuyết điểm, nguyên nhân và trách nhiệm trong quá trình thực hiện nhiệm vụ.
>
> Các đồng chí Ủy viên Ban Chấp hành đã phát huy tinh thần tự phê bình và phê bình, nghiêm túc nhìn nhận trách nhiệm trong thực hiện chức trách, nhiệm vụ được phân công; tham gia góp ý với tinh thần thẳng thắn, khách quan và xây dựng.
>
> Hội nghị cũng đã xem xét kết quả kiểm điểm, đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc; đối chiếu hồ sơ, tiêu chí, điều kiện và những đề xuất của các chi bộ, làm cơ sở hoàn thiện các bước đánh giá, xếp loại theo quy định.
>
> Thay mặt Đảng ủy, tôi trân trọng cảm ơn các đồng chí đại biểu đã quan tâm tham dự, theo dõi và đóng góp ý kiến đối với công tác kiểm điểm, đánh giá, xếp loại chất lượng của Đảng bộ nhà trường.
>
> Tôi cũng ghi nhận tinh thần trách nhiệm của các đồng chí trong Ban Chấp hành Đảng ủy đã nghiêm túc nghiên cứu hồ sơ, tham gia thảo luận và góp ý đối với các nội dung của Hội nghị.
>
> **Kính thưa các đồng chí!**
>
> Điều quan trọng sau Hội nghị không chỉ là hoàn thành việc kiểm điểm, đánh giá, xếp loại chất lượng mà còn phải xác định rõ những việc cần tiếp tục thực hiện để phát huy ưu điểm, khắc phục hạn chế và nâng cao hiệu quả lãnh đạo, chỉ đạo của Đảng ủy trong thời gian tới.
>
> Vì vậy, tôi đề nghị các đồng chí tập trung thực hiện tốt một số nhiệm vụ trọng tâm:
>
> **Thứ nhất,** tiếp thu đầy đủ các ý kiến góp ý, hoàn thiện hồ sơ kiểm điểm, đánh giá, xếp loại chất lượng năm 2026, bảo đảm chính xác, đầy đủ, đúng quy định và thời hạn.
>
> **Thứ hai,** đối với những hạn chế, khuyết điểm đã được chỉ ra, phải xác định rõ trách nhiệm, biện pháp và thời gian khắc phục; tránh tình trạng kiểm điểm xong nhưng chậm chuyển biến trong thực hiện.
>
> **Thứ ba,** từng đồng chí Ủy viên Ban Chấp hành tiếp tục phát huy tinh thần trách nhiệm, vai trò nêu gương, chủ động trong lĩnh vực được phân công, phối hợp chặt chẽ trong lãnh đạo thực hiện nhiệm vụ chung.
>
> **Thứ tư,** tiếp tục quan tâm lãnh đạo nâng cao chất lượng hoạt động của các chi bộ trực thuộc, chất lượng sinh hoạt Đảng, công tác quản lý đảng viên, kiểm tra, giám sát và việc thực hiện nguyên tắc tập trung dân chủ.
>
> **Thứ năm,** tập trung chuẩn bị tốt chương trình công tác năm 2027, xác định nhiệm vụ trọng tâm, giải pháp cụ thể, gắn công tác xây dựng Đảng với việc thực hiện nhiệm vụ chăm sóc, nuôi dưỡng, giáo dục trẻ và xây dựng nhà trường phát triển ổn định, chất lượng.
>
> Tôi đề nghị các đồng chí tiếp tục phát huy tinh thần đoàn kết, thống nhất, trách nhiệm và quyết tâm thực hiện tốt các nhiệm vụ đã được Hội nghị thống nhất.
>
> Một lần nữa, xin trân trọng cảm ơn các đồng chí đại biểu và toàn thể các đồng chí đã tham dự, đóng góp ý kiến để Hội nghị hoàn thành chương trình đề ra.
>
> Xin trân trọng cảm ơn!
>
> ## 2. Thông qua biên bản Hội nghị
>
> **Người dẫn chương trình:**
>
> Xin trân trọng cảm ơn đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy đã phát biểu kết luận và chỉ đạo những nhiệm vụ trọng tâm cần thực hiện sau Hội nghị.
>
> Kính thưa Hội nghị!
>
> Để bảo đảm kết quả làm việc được ghi nhận đầy đủ, chính xác, tiếp theo xin trân trọng kính mời đồng chí **Phan Thị Mỹ Hạnh – Thư ký Hội nghị** thông qua biên bản Hội nghị.
>
> Xin kính mời đồng chí!
>
> *Đồng chí thư ký đọc biên bản Hội nghị.*
>
> Xin cảm ơn đồng chí thư ký!
>
> Kính thưa các đồng chí!
>
> Hội nghị vừa nghe thông qua biên bản ghi nhận diễn biến, các ý kiến thảo luận, kết quả xem xét và những nội dung đã được thống nhất.
>
> Xin ý kiến các đồng chí đối với nội dung biên bản vừa được thông qua.
>
> Có đồng chí nào đề nghị bổ sung, điều chỉnh hoặc làm rõ nội dung nào không?
>
> *Dừng để các đồng chí tham gia ý kiến.*
>
> Nếu không có ý kiến khác, xin Hội nghị thống nhất thông qua biên bản; đồng thời giao đồng chí thư ký hoàn thiện những nội dung bổ sung, điều chỉnh nếu có, để thực hiện việc ký và lưu hồ sơ theo quy định.
>
> Xin trân trọng cảm ơn các đồng chí!
>
> ## 3. Bế mạc Hội nghị
>
> **Người dẫn chương trình:**
>
> Kính thưa các đồng chí đại biểu!
>
> Kính thưa toàn thể Hội nghị!
>
> Đến đây, Hội nghị kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026 của Đảng ủy Trường Mầm non An Bình đã hoàn thành toàn bộ nội dung chương trình đề ra.
>
> Thay mặt Ban Tổ chức, xin trân trọng cảm ơn sự quan tâm tham dự của các đồng chí đại biểu; cảm ơn tinh thần trách nhiệm, sự tập trung và những ý kiến đóng góp của các đồng chí trong Ban Chấp hành Đảng ủy.
>
> Kính chúc các đồng chí đại biểu cùng toàn thể các đồng chí sức khỏe, hạnh phúc và hoàn thành tốt nhiệm vụ được giao.
>
> **Xin trân trọng tuyên bố kết thúc Hội nghị!**
>
> **Xin trân trọng cảm ơn!**

### Lưu ý rà soát trước khi sử dụng chính thức

Bản trên đã bám sát chương trình bổ sung. Cần kiểm tra lại **chức danh đầy đủ của đồng chí Nguyễn Quốc Đại**, tên của cả 03 chi bộ và người được phân công dẫn chương trình. Phương án đồng chí Nguyễn Thị Ngọc Phượng điều hành phần kiểm điểm đồng chí Bí thư là đề xuất tổ chức, cần được Hội nghị thống nhất, không phải thông tin đã có trong chương trình.

Về căn cứ nghiệp vụ, việc kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 tiếp tục áp dụng Quy định số 366-QĐ/TW ngày 30/8/2025 và hướng dẫn liên quan theo điều khoản chuyển tiếp của Quy định số 227-QĐ/TW; trường hợp tổ chức đảng có điều chỉnh theo Quy định số 208-QĐ/TW thì thực hiện theo hướng dẫn riêng của Ban Tổ chức Trung ương. Cần đối chiếu thêm hướng dẫn cụ thể của Đảng ủy phường An Bình trước khi thực hiện việc biểu quyết và xác định thẩm quyền xếp loại. [Quy định về kiểm điểm và đánh giá, xếp loại chất lượng đối với tập thể, cá nhân](<https://baochinhphu.vn/quy-dinh-ve-kiem-diem-va-danh-gia-xep-loai-chat-luong-doi-voi-tap-the-ca-nhan-102261022093100487.htm>); [Quy định số 366\-QĐ/TW ngày 30/8/2025 của Bộ Chính trị về việc kiểm điểm và đánh giá, xếp loại chất \.\.\.](<https://tulieuvankien.dangcongsan.vn/he-thong-van-ban/van-ban-cua-dang/quy-dinh-so-366-qdtw-ngay-3082025-cua-bo-chinh-tri-ve-viec-kiem-diem-va-danh-gia-xep-loai-chat-luong-doi-voi-tap-the-11785>)

---

ASSISTANT

<WritingBlock id="68431" variant="document"># KỊCH BẢN DẪN VÀ ĐIỀU HÀNH HỘI NGHỊ

**KIỂM ĐIỂM, TỰ ĐÁNH GIÁ, ĐỀ XUẤT XẾP LOẠI CHẤT LƯỢNG BAN CHẤP HÀNH ĐẢNG ỦY VÀ XEM XÉT KẾT QUẢ ĐÁNH GIÁ TẬP THỂ CHI ỦY, CHI BỘ, ĐẢNG VIÊN NĂM 2026**

**ĐẢNG ỦY TRƯỜNG MẦM NON AN BÌNH**

**Thời gian:** 15 giờ 00 phút, ngày 10 tháng 11 năm 2026.

**Địa điểm:** Phòng họp Trường Mầm non An Bình.

**Chủ trì:** Đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy.

**Thư ký:** Đồng chí Phan Thị Mỹ Hạnh.

*Ghi chú: Các dòng in nghiêng dùng để hướng dẫn điều hành, không đọc tại Hội nghị. Những nội dung trong dấu [ ] được bổ sung theo diễn biến và kết quả thực tế.*

---

# I. PHẦN MỞ ĐẦU

## 1. Tuyên bố lý do, giới thiệu đại biểu

**Người dẫn chương trình:**

Kính thưa các đồng chí đại biểu!

Kính thưa toàn thể Hội nghị!

Thực hiện chương trình công tác và kế hoạch kiểm điểm, đánh giá, xếp loại chất lượng tổ chức đảng, đảng viên năm 2026, hôm nay, Đảng ủy Trường Mầm non An Bình tổ chức Hội nghị kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026.

Hội nghị nhằm đánh giá toàn diện, khách quan kết quả lãnh đạo, chỉ đạo và tổ chức thực hiện nhiệm vụ của Ban Chấp hành Đảng ủy trong năm; làm rõ những ưu điểm, kết quả đạt được, đồng thời nghiêm túc nhìn nhận những hạn chế, khuyết điểm, xác định nguyên nhân, trách nhiệm và biện pháp khắc phục trong thời gian tới.

Đồng thời, Hội nghị xem xét kết quả kiểm điểm, đánh giá, xếp loại chất lượng của các chi bộ trực thuộc, bảo đảm việc đánh giá đúng thực chất, công tâm, khách quan, làm cơ sở thực hiện các bước tiếp theo theo đúng quy định và thẩm quyền.

Đó là lý do của Hội nghị hôm nay.

**Kính thưa Hội nghị!**

Về tham dự Hội nghị hôm nay, tôi xin trân trọng giới thiệu:

- Đồng chí **Trần Thụy Ngọc Diễm** – Ủy viên Ban Thường vụ Đảng ủy, Chủ tịch Ủy ban Mặt trận Tổ quốc Việt Nam phường.
- Đồng chí **Trần Thị Mai** – Đảng ủy viên, Phó Trưởng ban Xây dựng Đảng Đảng ủy phường An Bình.
- Đồng chí **Nguyễn Quốc Đại** – Ủy ban Kiểm tra Đảng ủy phường An Bình.

Xin trân trọng giới thiệu:

- Đồng chí **Huỳnh Hồng Loan** – Bí thư Đảng ủy Trường Mầm non An Bình, chủ trì Hội nghị.
- Cùng toàn thể các đồng chí Ủy viên Ban Chấp hành Đảng ủy Trường Mầm non An Bình có mặt tại Hội nghị hôm nay.

Xin trân trọng chào mừng các đồng chí đại biểu cùng toàn thể các đồng chí tham dự Hội nghị!

## 2. Báo cáo số lượng dự họp, giới thiệu thư ký

Kính thưa Hội nghị!

Trước khi tiến hành các nội dung làm việc, tôi xin báo cáo số lượng Ủy viên Ban Chấp hành Đảng ủy tham dự Hội nghị như sau:

Tổng số Ủy viên Ban Chấp hành Đảng ủy là **07 đồng chí**; có mặt **07/07 đồng chí**, đạt 100%; vắng mặt **0 đồng chí**.

Thư ký Hội nghị là đồng chí **Phan Thị Mỹ Hạnh**.

Đề nghị đồng chí thư ký theo dõi, ghi chép đầy đủ, trung thực diễn biến Hội nghị; các ý kiến thảo luận, góp ý, nội dung tiếp thu, giải trình, kết luận của chủ trì và kết quả lấy ý kiến, biểu quyết để hoàn thiện biên bản, hồ sơ Hội nghị theo quy định.

## 3. Thông qua chương trình làm việc

Kính thưa các đồng chí!

Theo chương trình đã được chuẩn bị, Hội nghị hôm nay tập trung thực hiện 06 nội dung trọng tâm:

**Nội dung thứ nhất:** Kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.

**Nội dung thứ hai:** Tự chấm điểm, tự nhận và đề xuất xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy.

**Nội dung thứ ba:** Kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy trong thực hiện chức trách, nhiệm vụ được phân công.

**Nội dung thứ tư:** Xem xét hồ sơ đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc.

**Nội dung thứ năm:** Xem xét các tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”.

**Nội dung thứ sáu:** Thống nhất việc hoàn thiện hồ sơ và phân công nhiệm vụ sau Hội nghị.

Cuối cùng là phần kết luận và thông qua biên bản Hội nghị.

Trên đây là toàn bộ chương trình làm việc.

Xin ý kiến các đồng chí về nội dung chương trình vừa thông qua.

*Dừng để Hội nghị cho ý kiến.*

Nếu không có ý kiến khác, xin Hội nghị thống nhất thực hiện theo chương trình đã đề ra.

Xin trân trọng cảm ơn các đồng chí!

## 4. Mời đồng chí Bí thư Đảng ủy quán triệt mục đích, yêu cầu

Kính thưa Hội nghị!

Để công tác kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 được thực hiện nghiêm túc, dân chủ, khách quan, đúng nguyên tắc, quy trình và thẩm quyền, tiếp theo chương trình, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy Trường Mầm non An Bình**, chủ trì Hội nghị, phát biểu quán triệt mục đích, yêu cầu và những nội dung cần lưu ý trong quá trình kiểm điểm, đánh giá, xếp loại chất lượng năm 2026.

Xin trân trọng kính mời đồng chí!

### Gợi ý phát biểu quán triệt của đồng chí Bí thư Đảng ủy

Kính thưa các đồng chí đại biểu!

Kính thưa toàn thể Hội nghị!

Hội nghị kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 có ý nghĩa quan trọng đối với công tác xây dựng Đảng của Đảng bộ Trường Mầm non An Bình. Đây không chỉ là việc đánh giá kết quả thực hiện nhiệm vụ trong năm mà còn là dịp để tập thể Ban Chấp hành và từng đồng chí cấp ủy viên nghiêm túc tự nhìn nhận trách nhiệm, phát huy ưu điểm, khắc phục hạn chế và xác định nhiệm vụ trong thời gian tới.

Để Hội nghị đạt yêu cầu đề ra, tôi đề nghị các đồng chí tập trung thực hiện tốt một số nội dung sau:

**Thứ nhất,** phát huy tinh thần tự phê bình và phê bình, bảo đảm dân chủ, thẳng thắn, khách quan, trung thực và xây dựng. Việc đánh giá phải phản ánh đúng thực chất, không né tránh hạn chế, khuyết điểm, đồng thời giữ gìn sự đoàn kết, thống nhất trong Ban Chấp hành Đảng ủy.

**Thứ hai,** nội dung kiểm điểm phải bám sát chức năng, nhiệm vụ, quy chế làm việc, chương trình công tác và những nhiệm vụ được giao trong năm. Đề nghị các đồng chí tập trung làm rõ kết quả thực hiện, những vấn đề còn hạn chế, nguyên nhân và trách nhiệm có liên quan.

**Thứ ba,** đối với việc kiểm điểm trách nhiệm cá nhân, từng đồng chí Ủy viên Ban Chấp hành cần gắn nội dung kiểm điểm với nhiệm vụ được phân công, thể hiện rõ tinh thần trách nhiệm, vai trò nêu gương và những việc đã làm được, chưa làm được.

**Thứ tư,** đối với kết quả đánh giá, xếp loại của các chi bộ và đảng viên, đề nghị các đồng chí xem xét thận trọng, đối chiếu tiêu chí, điều kiện, minh chứng và phân cấp thẩm quyền; không đánh giá theo cảm tính, không chạy theo thành tích.

**Thứ năm,** sau kiểm điểm, từng tập thể, cá nhân phải xác định rõ những hạn chế cần khắc phục, biện pháp thực hiện và trách nhiệm theo dõi. Kết quả kiểm điểm phải góp phần tạo chuyển biến tích cực trong công tác xây dựng Đảng và thực hiện nhiệm vụ chính trị của nhà trường.

Với tinh thần đó, đề nghị các đồng chí tập trung nghiên cứu tài liệu, phát huy trách nhiệm, tham gia ý kiến có trọng tâm để Hội nghị hoàn thành tốt các nội dung đề ra.

Xin trân trọng cảm ơn các đồng chí!

### Người dẫn chương trình tiếp lời

Xin trân trọng cảm ơn đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy đã quán triệt mục đích, yêu cầu và định hướng những nội dung trọng tâm của Hội nghị.

Đề nghị các đồng chí phát huy tinh thần trách nhiệm, tập trung nghiên cứu, thảo luận để các nội dung kiểm điểm, đánh giá được thực hiện nghiêm túc, hiệu quả.

Sau đây, Hội nghị chuyển sang phần nội dung làm việc.

---

# II. PHẦN NỘI DUNG LÀM VIỆC

## 1. KIỂM ĐIỂM TẬP THỂ BAN CHẤP HÀNH ĐẢNG ỦY

### 1.1. Trình bày dự thảo Báo cáo kiểm điểm tập thể

**Người dẫn chương trình:**

Kính thưa các đồng chí đại biểu!

Kính thưa Hội nghị!

Mở đầu phần nội dung, Hội nghị tiến hành kiểm điểm tập thể Ban Chấp hành Đảng ủy Trường Mầm non An Bình năm 2026.

Nội dung kiểm điểm tập trung đánh giá kết quả lãnh đạo, chỉ đạo thực hiện nhiệm vụ chính trị, công tác xây dựng Đảng, việc thực hiện nguyên tắc tập trung dân chủ, quy chế làm việc, công tác kiểm tra, giám sát và trách nhiệm của tập thể Ban Chấp hành trong năm.

Sau đây, xin trân trọng kính mời đồng chí **Nguyễn Thị Ngọc Phượng – Phó Bí thư Đảng ủy Trường Mầm non An Bình**, thay mặt Ban Chấp hành Đảng ủy, trình bày dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.

Xin trân trọng kính mời đồng chí!

*Đồng chí Nguyễn Thị Ngọc Phượng trình bày báo cáo.*

### 1.2. Gợi ý thảo luận

**Người dẫn chương trình:**

Xin trân trọng cảm ơn đồng chí Nguyễn Thị Ngọc Phượng!

Kính thưa Hội nghị!

Hội nghị vừa nghe dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026.

Để việc kiểm điểm bảo đảm khách quan, toàn diện và đi vào thực chất, đề nghị các đồng chí tập trung nghiên cứu, tham gia góp ý đối với những kết quả đạt được, những hạn chế, khuyết điểm, nguyên nhân và trách nhiệm của tập thể trong công tác lãnh đạo, chỉ đạo.

Sau đây, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy**, chủ trì điều hành phần thảo luận, đóng góp ý kiến đối với dự thảo Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy.

Xin trân trọng kính mời đồng chí!

**Đồng chí Bí thư Đảng ủy điều hành:**

Kính thưa các đồng chí!

Trên cơ sở dự thảo Báo cáo kiểm điểm vừa được trình bày, tôi đề nghị các đồng chí tập trung tham gia ý kiến vào một số vấn đề trọng tâm:

Một là, kết quả lãnh đạo, chỉ đạo thực hiện nghị quyết, chương trình công tác và các nhiệm vụ chính trị của Đảng bộ trong năm 2026.

Hai là, việc thực hiện nguyên tắc tập trung dân chủ, quy chế làm việc, chế độ sinh hoạt cấp ủy, sự phối hợp trong lãnh đạo, chỉ đạo và giữ gìn đoàn kết nội bộ.

Ba là, kết quả lãnh đạo công tác xây dựng Đảng; công tác chính trị, tư tưởng; quản lý, giáo dục đảng viên; kiểm tra, giám sát và nâng cao chất lượng hoạt động của các chi bộ trực thuộc.

Bốn là, trách nhiệm của Ban Chấp hành trong lãnh đạo thực hiện nhiệm vụ của nhà trường, đặc biệt là công tác chăm sóc, nuôi dưỡng, giáo dục trẻ; xây dựng đội ngũ, duy trì nền nếp, kỷ cương và bảo đảm an toàn trường học.

Năm là, những hạn chế, khuyết điểm trong công tác lãnh đạo, chỉ đạo; nguyên nhân chủ quan, khách quan; trách nhiệm của tập thể Ban Chấp hành và các giải pháp cần tập trung thực hiện trong thời gian tới.

Đề nghị các đồng chí tham gia ý kiến thẳng thắn, khách quan, tập trung làm rõ những nội dung cần bổ sung, điều chỉnh; đồng thời đề xuất những giải pháp cụ thể, khả thi.

Sau đây, xin mời các đồng chí tham gia thảo luận.

*Chủ trì lần lượt mời các đồng chí Ủy viên Ban Chấp hành phát biểu.*

*Trường hợp đại biểu Đảng ủy phường có ý kiến nhận xét, góp ý hoặc chỉ đạo, chủ trì bố trí mời phát biểu trước khi kết luận phần kiểm điểm tập thể.*

### 1.3. Tiếp thu, giải trình và kết luận

**Đồng chí Bí thư Đảng ủy:**

Xin trân trọng cảm ơn các ý kiến tham gia đóng góp của các đồng chí.

Các ý kiến tại Hội nghị thể hiện tinh thần trách nhiệm, thẳng thắn và xây dựng, giúp Ban Chấp hành nhìn nhận đầy đủ hơn kết quả lãnh đạo, chỉ đạo và những vấn đề cần tiếp tục quan tâm khắc phục.

Thay mặt Ban Chấp hành Đảng ủy, tôi xin tiếp thu những ý kiến đóng góp của các đồng chí. Đối với một số nội dung cần làm rõ, tôi xin trao đổi, giải trình thêm như sau:

*[Đồng chí Bí thư giải trình các nội dung phát sinh từ ý kiến thảo luận.]*

Trên cơ sở dự thảo Báo cáo kiểm điểm và ý kiến đóng góp tại Hội nghị, tôi đề nghị thống nhất một số nội dung:

**Về ưu điểm:** [Khái quát những kết quả nổi bật được Hội nghị thống nhất.]

**Về hạn chế, khuyết điểm:** [Nêu những nội dung cần làm rõ, bổ sung hoặc điều chỉnh.]

**Về nguyên nhân và trách nhiệm:** [Xác định những vấn đề thuộc trách nhiệm lãnh đạo của tập thể và trách nhiệm liên quan.]

**Về nhiệm vụ, giải pháp khắc phục:** [Nêu những biện pháp trọng tâm cần thực hiện trong năm 2027.]

Đề nghị đồng chí Phó Bí thư Đảng ủy phối hợp với các đồng chí có liên quan tiếp thu đầy đủ ý kiến, hoàn thiện Báo cáo kiểm điểm tập thể Ban Chấp hành, bảo đảm nội dung phản ánh đúng thực tế và kết quả thảo luận tại Hội nghị.

Như vậy, Hội nghị đã hoàn thành phần kiểm điểm tập thể Ban Chấp hành Đảng ủy.

Xin cảm ơn các đồng chí!

---

## 2. TỰ CHẤM ĐIỂM, TỰ NHẬN VÀ ĐỀ XUẤT XẾP LOẠI CHẤT LƯỢNG TẬP THỂ BAN CHẤP HÀNH ĐẢNG ỦY

**Người dẫn chương trình:**

Kính thưa Hội nghị!

Tiếp theo chương trình, Hội nghị tiến hành nội dung tự chấm điểm, tự nhận và đề xuất mức xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy năm 2026.

Đây là nội dung cần được xem xét trên cơ sở kết quả kiểm điểm vừa được Hội nghị thảo luận, đối chiếu với tiêu chí đánh giá, kết quả thực hiện nhiệm vụ và những điều kiện xếp loại theo quy định.

Sau đây, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy**, chủ trì điều hành nội dung tự chấm điểm, thảo luận và thống nhất mức đề xuất xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy năm 2026.

Xin trân trọng kính mời đồng chí!

### Đồng chí Bí thư Đảng ủy điều hành

Kính thưa các đồng chí!

Trên cơ sở dự thảo Báo cáo kiểm điểm tập thể và kết quả thảo luận vừa qua, Ban Chấp hành Đảng ủy tiến hành xem xét bảng tự chấm điểm, xác định mức độ đáp ứng các tiêu chí đánh giá và mức tự nhận xếp loại chất lượng năm 2026.

Trước hết, xin mời đồng chí [người được phân công] trình bày kết quả tự chấm điểm, các căn cứ minh chứng và mức xếp loại được đề xuất.

Xin mời đồng chí!

*Người được phân công trình bày bảng tự chấm điểm.*

Xin cảm ơn đồng chí!

Đề nghị các đồng chí nghiên cứu, đối chiếu từng nhóm tiêu chí, kết quả thực hiện nhiệm vụ và những hạn chế đã được chỉ ra trong báo cáo kiểm điểm.

Đặc biệt, cần xem xét sự phù hợp giữa số điểm tự chấm với những kết quả thực tế, bảo đảm việc tự đánh giá khách quan, không chạy theo thành tích.

Sau đây, xin mời các đồng chí tham gia ý kiến về điểm tự chấm và mức đề xuất xếp loại chất lượng của tập thể Ban Chấp hành.

*Hội nghị thảo luận, điều chỉnh điểm tự chấm hoặc mức đề xuất nếu có căn cứ.*

Xin cảm ơn các đồng chí!

Trên cơ sở kết quả thảo luận, Ban Chấp hành Đảng ủy thống nhất xem xét:

- Tổng điểm tự chấm: [....] điểm.
- Mức tự nhận, đề xuất xếp loại chất lượng: [....].

Xin ý kiến các đồng chí về nội dung vừa nêu.

*Chủ trì tổ chức lấy ý kiến hoặc biểu quyết theo hình thức và quy trình được hướng dẫn áp dụng tại Hội nghị.*

Đề nghị đồng chí thư ký ghi nhận chính xác kết quả, số lượng ý kiến thống nhất, không thống nhất và những nội dung cần bổ sung nếu có.

Kết quả lấy ý kiến, biểu quyết: [....].

Đề nghị bộ phận được phân công hoàn thiện hồ sơ, bảo đảm thống nhất giữa báo cáo kiểm điểm, bảng chấm điểm, biên bản và mức tự nhận, đề xuất xếp loại của tập thể Ban Chấp hành Đảng ủy.

Lưu ý, mức xếp loại được Hội nghị thống nhất là mức tự nhận, đề xuất để báo cáo cấp có thẩm quyền xem xét, quyết định.

Như vậy, Hội nghị đã hoàn thành nội dung tự chấm điểm và đề xuất xếp loại chất lượng tập thể Ban Chấp hành Đảng ủy năm 2026.

---

## 3. KIỂM ĐIỂM TRÁCH NHIỆM CỦA CÁC ỦY VIÊN BAN CHẤP HÀNH ĐẢNG ỦY

**Người dẫn chương trình:**

Kính thưa các đồng chí!

Tiếp theo chương trình, Hội nghị tiến hành kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy trong việc thực hiện chức trách, nhiệm vụ được phân công năm 2026.

Nội dung kiểm điểm nhằm làm rõ tinh thần trách nhiệm, kết quả thực hiện nhiệm vụ của từng đồng chí; đồng thời phát huy tinh thần tự phê bình và phê bình, giúp mỗi đồng chí nhận diện đầy đủ những ưu điểm, hạn chế và xác định biện pháp khắc phục trong thời gian tới.

Đề nghị các đồng chí khi trình bày tập trung vào nội dung thuộc trách nhiệm cá nhân; các ý kiến góp ý cần khách quan, thẳng thắn, có căn cứ và mang tính xây dựng.

Xin trân trọng kính mời đồng chí chủ trì điều hành nội dung này.

### 3.1. Kiểm điểm trách nhiệm đồng chí Bí thư Đảng ủy

*Đề xuất điều hành: Khi kiểm điểm đồng chí Huỳnh Hồng Loan, Hội nghị có thể thống nhất phân công đồng chí Nguyễn Thị Ngọc Phượng – Phó Bí thư Đảng ủy điều hành phần kiểm điểm này.*

**Đồng chí Nguyễn Thị Ngọc Phượng điều hành (nếu được phân công):**

Kính thưa Hội nghị!

Trước hết, chúng ta tiến hành kiểm điểm trách nhiệm của đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy trong thực hiện chức trách, nhiệm vụ được giao năm 2026.

Xin trân trọng kính mời đồng chí Huỳnh Hồng Loan trình bày nội dung kiểm điểm trách nhiệm cá nhân.

Xin kính mời đồng chí!

*Đồng chí Bí thư trình bày nội dung kiểm điểm.*

Xin trân trọng cảm ơn đồng chí!

Sau đây, đề nghị các đồng chí trong Ban Chấp hành tham gia góp ý, tập trung vào vai trò, trách nhiệm của người đứng đầu; kết quả lãnh đạo, chỉ đạo, điều hành và việc thực hiện chức trách, nhiệm vụ được giao.

Xin mời các đồng chí tham gia ý kiến.

*Hội nghị thảo luận, góp ý.*

Xin cảm ơn các đồng chí!

Tiếp theo, xin mời đồng chí Huỳnh Hồng Loan tiếp thu, giải trình những nội dung được góp ý và trao đổi thêm về biện pháp khắc phục những hạn chế, khuyết điểm nếu có.

*Đồng chí Bí thư tiếp thu, giải trình.*

Trên cơ sở nội dung tự kiểm điểm và những ý kiến đóng góp, đề nghị đồng chí nghiêm túc tiếp thu, hoàn thiện nội dung kiểm điểm, phát huy những ưu điểm và xác định rõ những nhiệm vụ cần tập trung thực hiện trong thời gian tới.

Xin cảm ơn đồng chí!

### 3.2. Kiểm điểm trách nhiệm các đồng chí Ủy viên Ban Chấp hành

**Đồng chí chủ trì:**

Kính thưa Hội nghị!

Tiếp tục chương trình, chúng ta tiến hành kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy theo thứ tự đã thống nhất.

Trước hết, xin mời đồng chí [họ tên, chức vụ] trình bày nội dung kiểm điểm trách nhiệm cá nhân trong thực hiện chức trách, nhiệm vụ được phân công năm 2026.

Xin mời đồng chí!

*Đồng chí được mời trình bày.*

Xin cảm ơn đồng chí!

Đề nghị các đồng chí trong Ban Chấp hành tham gia nhận xét, góp ý, tập trung làm rõ kết quả thực hiện nhiệm vụ, tinh thần trách nhiệm, sự phối hợp trong công tác và những hạn chế cần khắc phục.

Xin mời các đồng chí tham gia ý kiến.

*Hội nghị góp ý.*

Xin cảm ơn các đồng chí!

Sau đây, xin mời đồng chí [họ tên] tiếp thu, giải trình những nội dung được góp ý.

*Cá nhân tiếp thu, giải trình.*

Đề nghị đồng chí nghiêm túc tiếp thu các ý kiến đóng góp, bổ sung, hoàn thiện nội dung kiểm điểm và xác định những giải pháp khắc phục cụ thể trong thời gian tới.

Xin cảm ơn đồng chí!

*Tiếp tục thực hiện trình tự tương tự đối với các đồng chí Ủy viên Ban Chấp hành còn lại.*

### 3.3. Kết thúc phần kiểm điểm trách nhiệm cá nhân

**Đồng chí chủ trì:**

Kính thưa các đồng chí!

Như vậy, Hội nghị đã hoàn thành phần kiểm điểm trách nhiệm của các đồng chí Ủy viên Ban Chấp hành Đảng ủy năm 2026.

Qua kiểm điểm, đề nghị mỗi đồng chí tiếp tục phát huy những ưu điểm, nghiêm túc tiếp thu ý kiến góp ý, nhận diện rõ những hạn chế thuộc trách nhiệm cá nhân và có biện pháp khắc phục phù hợp.

Việc tự đánh giá, đề xuất xếp loại chất lượng từng cá nhân tiếp tục được thực hiện theo đúng đối tượng, quy trình và thẩm quyền quy định.

Xin cảm ơn các đồng chí!

---

## 4. XEM XÉT HỒ SƠ ĐÁNH GIÁ, XẾP LOẠI CHẤT LƯỢNG CỦA 03 CHI BỘ TRỰC THUỘC

**Người dẫn chương trình:**

Kính thưa các đồng chí đại biểu!

Kính thưa toàn thể Hội nghị!

Tiếp theo chương trình, Ban Chấp hành Đảng ủy tiến hành xem xét hồ sơ đánh giá, xếp loại chất lượng năm 2026 của 03 chi bộ trực thuộc Đảng bộ Trường Mầm non An Bình.

Nội dung này nhằm xem xét kết quả kiểm điểm, đánh giá của từng chi bộ; đối chiếu giữa mức tự nhận, đề xuất xếp loại với kết quả thực hiện nhiệm vụ, các tiêu chí, điều kiện và minh chứng theo quy định.

Sau đây, xin trân trọng kính mời đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy, chủ trì điều hành việc xem xét hồ sơ của các chi bộ.

Xin kính mời đồng chí!

### 4.1. Báo cáo kết quả của chi bộ thứ nhất

**Đồng chí chủ trì:**

Trước hết, xin mời đại diện Chi bộ [tên chi bộ thứ nhất] báo cáo tóm tắt kết quả kiểm điểm, đánh giá, xếp loại chất lượng tập thể chi ủy, chi bộ và đảng viên năm 2026; đồng thời trình bày bảng tổng hợp tự chấm điểm và các nội dung đề xuất.

Xin mời đồng chí!

*Đại diện chi bộ báo cáo.*

Xin cảm ơn đồng chí!

Đề nghị các đồng chí Ủy viên Ban Chấp hành Đảng ủy cho ý kiến đối với hồ sơ và kết quả đánh giá của chi bộ, tập trung vào mức tự nhận xếp loại, những kết quả nổi bật, các hạn chế và sự đầy đủ của tài liệu minh chứng.

Xin mời các đồng chí tham gia ý kiến.

*Hội nghị thảo luận.*

Xin cảm ơn các đồng chí!

Qua ý kiến thảo luận, đề nghị ghi nhận những nội dung đã thống nhất và yêu cầu Chi bộ [tên chi bộ] tiếp tục bổ sung, hoàn thiện những nội dung cần thiết theo kết quả xem xét của Ban Chấp hành.

### 4.2. Báo cáo kết quả của chi bộ thứ hai

Tiếp theo, xin mời đại diện Chi bộ [tên chi bộ thứ hai] trình bày tóm tắt kết quả kiểm điểm, đánh giá, xếp loại chất lượng tập thể chi ủy, chi bộ và đảng viên năm 2026.

Xin mời đồng chí!

*Đại diện chi bộ báo cáo.*

Xin cảm ơn đồng chí!

Đề nghị các đồng chí trong Ban Chấp hành tiếp tục xem xét, đối chiếu hồ sơ, tiêu chí đánh giá và kết quả thực hiện nhiệm vụ của chi bộ; cho ý kiến đối với mức xếp loại được đề xuất.

Xin mời các đồng chí tham gia ý kiến.

*Hội nghị thảo luận.*

Xin cảm ơn các đồng chí!

Đề nghị thư ký ghi nhận đầy đủ các ý kiến và những nội dung Chi bộ [tên chi bộ] cần tiếp tục bổ sung, hoàn thiện.

### 4.3. Báo cáo kết quả của chi bộ thứ ba

Tiếp tục chương trình, xin mời đại diện Chi bộ [tên chi bộ thứ ba] trình bày tóm tắt kết quả kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 của tập thể chi ủy, chi bộ và đảng viên.

Xin mời đồng chí!

*Đại diện chi bộ báo cáo.*

Xin cảm ơn đồng chí!

Đề nghị các đồng chí Ủy viên Ban Chấp hành tham gia góp ý, tập trung xem xét tính khách quan, phù hợp của mức tự nhận xếp loại và những căn cứ, minh chứng kèm theo.

Xin mời các đồng chí!

*Hội nghị thảo luận.*

Xin cảm ơn các đồng chí!

Đề nghị thư ký tổng hợp những nội dung đã được thống nhất và những vấn đề cần bổ sung, điều chỉnh đối với hồ sơ của chi bộ.

### 4.4. Kết luận chung phần xem xét hồ sơ của 03 chi bộ

**Đồng chí chủ trì:**

Kính thưa các đồng chí!

Hội nghị đã nghe báo cáo và xem xét hồ sơ kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 của 03 chi bộ trực thuộc.

Qua các nội dung đã được báo cáo, thảo luận, đề nghị các chi bộ tiếp tục rà soát, hoàn thiện hồ sơ, bảo đảm sự thống nhất giữa kết quả kiểm điểm, bảng tự chấm điểm, mức xếp loại đề xuất và các tài liệu minh chứng.

Đối với những nội dung còn có ý kiến khác nhau hoặc chưa đầy đủ căn cứ, yêu cầu chi bộ liên quan bổ sung, giải trình trước khi hoàn thiện kết quả đánh giá hoặc trình cấp có thẩm quyền.

Đề nghị đồng chí thư ký ghi nhận đầy đủ kết quả xem xét của Ban Chấp hành đối với từng chi bộ, những nội dung đã thống nhất và những vấn đề cần tiếp tục xử lý.

Như vậy, Hội nghị đã hoàn thành nội dung xem xét hồ sơ đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc.

---

## 5. XEM XÉT CÁC ĐỀ XUẤT MỨC “HOÀN THÀNH XUẤT SẮC NHIỆM VỤ”

**Người dẫn chương trình:**

Kính thưa Hội nghị!

Tiếp theo chương trình, Hội nghị tiến hành xem xét riêng các trường hợp tập thể chi ủy, chi bộ và đảng viên được đề xuất mức xếp loại “Hoàn thành xuất sắc nhiệm vụ” năm 2026, nếu có trong hồ sơ trình Hội nghị.

Đây là nội dung cần được xem xét thận trọng, bảo đảm việc đề xuất mức xếp loại phù hợp với thành tích nổi bật, kết quả thực hiện nhiệm vụ, các tiêu chí và điều kiện theo quy định.

Xin trân trọng kính mời đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy, chủ trì điều hành nội dung này.

Xin kính mời đồng chí!

### Đồng chí Bí thư Đảng ủy điều hành

Kính thưa các đồng chí!

Đối với những tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”, tôi đề nghị Ban Chấp hành xem xét kỹ từng trường hợp trên cơ sở kết quả thực hiện nhiệm vụ, những thành tích nổi bật, mức độ hoàn thành các chỉ tiêu, nhiệm vụ được giao và những điều kiện, tiêu chí theo quy định.

Việc xem xét cần bảo đảm khách quan, công bằng, đúng thực chất, đúng tỷ lệ và thẩm quyền; không chỉ căn cứ vào mức tự nhận hoặc đề xuất của chi bộ.

Sau đây, xin mời đồng chí [người được phân công] trình bày danh sách các tập thể, cá nhân được đề nghị mức “Hoàn thành xuất sắc nhiệm vụ”, cùng những căn cứ và kết quả đánh giá có liên quan.

Xin mời đồng chí!

*Người được phân công trình bày.*

Xin cảm ơn đồng chí!

Đề nghị các đồng chí tập trung nghiên cứu, thảo luận và cho ý kiến đối với từng trường hợp, đặc biệt lưu ý những kết quả, thành tích nổi bật, tính đầy đủ của minh chứng và việc đáp ứng các điều kiện xếp loại.

Đối với những trường hợp còn có ý kiến khác nhau, đề nghị trao đổi làm rõ để bảo đảm việc đề xuất được thực hiện thận trọng, có căn cứ.

Sau đây, xin mời các đồng chí tham gia ý kiến.

*Hội nghị thảo luận từng trường hợp.*

Xin cảm ơn các đồng chí!

Trên cơ sở ý kiến thảo luận, Hội nghị tiến hành thống nhất kết quả xem xét và thực hiện việc lấy ý kiến, biểu quyết đối với những trường hợp thuộc phạm vi, thẩm quyền và quy trình áp dụng.

*Chủ trì tổ chức lấy ý kiến hoặc biểu quyết khi đủ điều kiện; thư ký ghi rõ kết quả từng trường hợp.*

Đề nghị đồng chí thư ký tổng hợp đầy đủ kết quả xem xét, những trường hợp được thống nhất đề xuất và những nội dung cần tiếp tục rà soát, bổ sung minh chứng.

Kết quả của Hội nghị phải được thể hiện đầy đủ trong biên bản, bảo đảm không kết luận vượt quá thẩm quyền.

*Trường hợp không có tập thể, cá nhân được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”, chủ trì nêu rõ không phát sinh trường hợp để xem xét và chuyển sang nội dung tiếp theo.*

Như vậy, Hội nghị đã hoàn thành nội dung xem xét các đề xuất mức “Hoàn thành xuất sắc nhiệm vụ” năm 2026.

Xin cảm ơn các đồng chí!

---

## 6. THỐNG NHẤT HỒ SƠ VÀ NHIỆM VỤ SAU HỘI NGHỊ

**Người dẫn chương trình:**

Kính thưa các đồng chí!

Sau khi hoàn thành các nội dung kiểm điểm, thảo luận và xem xét kết quả đánh giá, xếp loại chất lượng, Hội nghị chuyển sang nội dung cuối cùng của phần làm việc, đó là thống nhất việc hoàn thiện hồ sơ và phân công nhiệm vụ sau Hội nghị.

Trước hết, xin trân trọng kính mời đồng chí **Phan Thị Mỹ Hạnh – Thư ký Hội nghị** báo cáo tóm tắt kết quả tổng hợp các nội dung đã được thảo luận, thống nhất và những vấn đề cần tiếp tục hoàn thiện.

Xin mời đồng chí!

### Gợi ý nội dung báo cáo của thư ký

Kính thưa các đồng chí đại biểu!

Kính thưa Hội nghị!

Qua quá trình làm việc, Hội nghị đã tiến hành kiểm điểm tập thể Ban Chấp hành Đảng ủy; tự chấm điểm, đề xuất mức xếp loại chất lượng tập thể; kiểm điểm trách nhiệm các đồng chí Ủy viên Ban Chấp hành; xem xét hồ sơ đánh giá, xếp loại của 03 chi bộ trực thuộc và các trường hợp được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”.

Trên cơ sở kết quả thảo luận và các nội dung được thống nhất tại Hội nghị, thư ký xin báo cáo tóm tắt một số kết quả như sau:

**Thứ nhất,** về kiểm điểm tập thể Ban Chấp hành Đảng ủy: [Tóm tắt những nội dung được thống nhất, ý kiến cần bổ sung.]

**Thứ hai,** về kết quả tự chấm điểm và đề xuất xếp loại chất lượng tập thể Ban Chấp hành: [Ghi số điểm, mức đề xuất, kết quả lấy ý kiến hoặc biểu quyết.]

**Thứ ba,** về kiểm điểm trách nhiệm các Ủy viên Ban Chấp hành: [Tổng hợp những vấn đề cần tiếp thu, bổ sung và hoàn thiện.]

**Thứ tư,** về kết quả xem xét hồ sơ của 03 chi bộ trực thuộc: [Tóm tắt các mức đề xuất, nội dung thống nhất và những vấn đề còn cần hoàn thiện.]

**Thứ năm,** về các trường hợp được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”: [Nêu kết quả xem xét theo thực tế.]

**Thứ sáu,** về những tài liệu, hồ sơ cần tiếp tục hoàn thiện và báo cáo cấp có thẩm quyền: [Nêu các nội dung cần thực hiện.]

Trên đây là những nội dung thư ký đã tổng hợp. Kính đề nghị Hội nghị cho ý kiến bổ sung, điều chỉnh để bảo đảm nội dung ghi nhận đầy đủ, chính xác.

Xin trân trọng cảm ơn các đồng chí!

### Mời đồng chí Bí thư chỉ đạo, thống nhất phân công

**Người dẫn chương trình:**

Xin trân trọng cảm ơn đồng chí Phan Thị Mỹ Hạnh – Thư ký Hội nghị!

Kính thưa Hội nghị!

Để bảo đảm các nội dung sau kiểm điểm được triển khai kịp thời, đầy đủ, đúng yêu cầu, tiếp theo xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy**, cho ý kiến chỉ đạo và thống nhất việc phân công hoàn thiện hồ sơ, thực hiện các nhiệm vụ sau Hội nghị.

Xin trân trọng kính mời đồng chí!

**Đồng chí Bí thư Đảng ủy:**

Kính thưa các đồng chí!

Trên cơ sở những nội dung đã được Hội nghị thảo luận, thống nhất, tôi đề nghị tập trung thực hiện một số nhiệm vụ sau:

**Một là,** tiếp thu, hoàn thiện Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy năm 2026, bảo đảm phản ánh đầy đủ những kết quả đạt được, hạn chế, nguyên nhân và trách nhiệm đã được Hội nghị làm rõ.

**Hai là,** rà soát, hoàn thiện bảng tự chấm điểm, mức tự nhận và đề xuất xếp loại chất lượng tập thể Ban Chấp hành; bảo đảm các tài liệu thống nhất với kết quả thảo luận, lấy ý kiến hoặc biểu quyết tại Hội nghị.

**Ba là,** tiếp tục rà soát hồ sơ đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc, yêu cầu bổ sung những nội dung còn thiếu hoặc chưa đầy đủ căn cứ; tổng hợp kết quả xem xét để thực hiện các bước tiếp theo theo phân cấp thẩm quyền.

**Bốn là,** hoàn thiện hồ sơ liên quan đến các trường hợp được đề xuất mức “Hoàn thành xuất sắc nhiệm vụ”; bảo đảm có đầy đủ căn cứ, minh chứng và kết quả xem xét.

**Năm là,** hoàn thiện biên bản, bảng tổng hợp, danh sách, tờ trình và các tài liệu liên quan để báo cáo, gửi cấp có thẩm quyền theo thời gian quy định.

**Sáu là,** đối với những hạn chế, khuyết điểm được chỉ ra qua kiểm điểm, đề nghị từng đồng chí có liên quan xác định rõ biện pháp khắc phục; tập thể Ban Chấp hành tiếp tục theo dõi, kiểm tra kết quả thực hiện, gắn với chương trình công tác năm 2027.

Về phân công cụ thể, đề nghị:

- Đồng chí [....] chịu trách nhiệm chính trong việc hoàn thiện Báo cáo kiểm điểm tập thể Ban Chấp hành Đảng ủy.
- Đồng chí Phan Thị Mỹ Hạnh phối hợp tổng hợp, hoàn thiện biên bản và các tài liệu liên quan đến kết quả Hội nghị.
- Các đồng chí được phân công phụ trách, theo dõi chi bộ phối hợp đôn đốc hoàn thiện hồ sơ của các chi bộ trực thuộc.
- Đồng chí [....] chịu trách nhiệm tổng hợp hồ sơ, tham mưu hoàn thiện thủ tục trình cấp có thẩm quyền.
- Thời hạn hoàn thành các nội dung: [....].

*Chủ trì điều chỉnh và thống nhất nhiệm vụ, người phụ trách, thời hạn theo ý kiến Hội nghị.*

Đề nghị các đồng chí được phân công nghiêm túc triển khai thực hiện, bảo đảm đúng tiến độ và chất lượng.

Xin cảm ơn các đồng chí!

---

# III. PHẦN KẾT THÚC HỘI NGHỊ

## 1. Mời đồng chí Bí thư Đảng ủy phát biểu kết luận

**Người dẫn chương trình:**

Kính thưa các đồng chí đại biểu!

Kính thưa toàn thể Hội nghị!

Sau thời gian làm việc với tinh thần nghiêm túc, dân chủ, trách nhiệm và xây dựng, Hội nghị đã thực hiện các nội dung theo chương trình đề ra.

Để đánh giá khái quát kết quả Hội nghị và định hướng những nhiệm vụ cần tập trung thực hiện trong thời gian tới, xin trân trọng kính mời đồng chí **Huỳnh Hồng Loan – Bí thư Đảng ủy Trường Mầm non An Bình**, chủ trì Hội nghị, phát biểu kết luận.

Xin trân trọng kính mời đồng chí!

### Dự thảo phát biểu kết luận của đồng chí Bí thư Đảng ủy

Kính thưa các đồng chí đại biểu!

Kính thưa toàn thể Hội nghị!

Sau thời gian làm việc nghiêm túc, dân chủ, thẳng thắn và trách nhiệm, Hội nghị kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026 của Đảng ủy Trường Mầm non An Bình đã hoàn thành các nội dung theo chương trình đề ra.

Tại Hội nghị, Ban Chấp hành đã tập trung kiểm điểm, đánh giá kết quả lãnh đạo, chỉ đạo và tổ chức thực hiện nhiệm vụ trong năm 2026; làm rõ những kết quả đạt được, những hạn chế, khuyết điểm, nguyên nhân và trách nhiệm trong quá trình thực hiện nhiệm vụ.

Các đồng chí Ủy viên Ban Chấp hành đã phát huy tinh thần tự phê bình và phê bình, nghiêm túc nhìn nhận trách nhiệm trong thực hiện chức trách, nhiệm vụ được phân công; tham gia góp ý với tinh thần thẳng thắn, khách quan và xây dựng.

Hội nghị cũng đã xem xét kết quả kiểm điểm, đánh giá, xếp loại chất lượng của 03 chi bộ trực thuộc; đối chiếu hồ sơ, tiêu chí, điều kiện và những đề xuất của các chi bộ, làm cơ sở hoàn thiện các bước đánh giá, xếp loại theo quy định.

Thay mặt Đảng ủy, tôi trân trọng cảm ơn các đồng chí đại biểu đã quan tâm tham dự, theo dõi và đóng góp ý kiến đối với công tác kiểm điểm, đánh giá, xếp loại chất lượng của Đảng bộ nhà trường.

Tôi cũng ghi nhận tinh thần trách nhiệm của các đồng chí trong Ban Chấp hành Đảng ủy đã nghiêm túc nghiên cứu hồ sơ, tham gia thảo luận và góp ý đối với các nội dung của Hội nghị.

**Kính thưa các đồng chí!**

Điều quan trọng sau Hội nghị không chỉ là hoàn thành việc kiểm điểm, đánh giá, xếp loại chất lượng mà còn phải xác định rõ những việc cần tiếp tục thực hiện để phát huy ưu điểm, khắc phục hạn chế và nâng cao hiệu quả lãnh đạo, chỉ đạo của Đảng ủy trong thời gian tới.

Vì vậy, tôi đề nghị các đồng chí tập trung thực hiện tốt một số nhiệm vụ trọng tâm:

**Thứ nhất,** tiếp thu đầy đủ các ý kiến góp ý, hoàn thiện hồ sơ kiểm điểm, đánh giá, xếp loại chất lượng năm 2026, bảo đảm chính xác, đầy đủ, đúng quy định và thời hạn.

**Thứ hai,** đối với những hạn chế, khuyết điểm đã được chỉ ra, phải xác định rõ trách nhiệm, biện pháp và thời gian khắc phục; tránh tình trạng kiểm điểm xong nhưng chậm chuyển biến trong thực hiện.

**Thứ ba,** từng đồng chí Ủy viên Ban Chấp hành tiếp tục phát huy tinh thần trách nhiệm, vai trò nêu gương, chủ động trong lĩnh vực được phân công, phối hợp chặt chẽ trong lãnh đạo thực hiện nhiệm vụ chung.

**Thứ tư,** tiếp tục quan tâm lãnh đạo nâng cao chất lượng hoạt động của các chi bộ trực thuộc, chất lượng sinh hoạt Đảng, công tác quản lý đảng viên, kiểm tra, giám sát và việc thực hiện nguyên tắc tập trung dân chủ.

**Thứ năm,** tập trung chuẩn bị tốt chương trình công tác năm 2027, xác định nhiệm vụ trọng tâm, giải pháp cụ thể, gắn công tác xây dựng Đảng với việc thực hiện nhiệm vụ chăm sóc, nuôi dưỡng, giáo dục trẻ và xây dựng nhà trường phát triển ổn định, chất lượng.

Tôi đề nghị các đồng chí tiếp tục phát huy tinh thần đoàn kết, thống nhất, trách nhiệm và quyết tâm thực hiện tốt các nhiệm vụ đã được Hội nghị thống nhất.

Một lần nữa, xin trân trọng cảm ơn các đồng chí đại biểu và toàn thể các đồng chí đã tham dự, đóng góp ý kiến để Hội nghị hoàn thành chương trình đề ra.

Xin trân trọng cảm ơn!

## 2. Thông qua biên bản Hội nghị

**Người dẫn chương trình:**

Xin trân trọng cảm ơn đồng chí Huỳnh Hồng Loan – Bí thư Đảng ủy đã phát biểu kết luận và chỉ đạo những nhiệm vụ trọng tâm cần thực hiện sau Hội nghị.

Kính thưa Hội nghị!

Để bảo đảm kết quả làm việc được ghi nhận đầy đủ, chính xác, tiếp theo xin trân trọng kính mời đồng chí **Phan Thị Mỹ Hạnh – Thư ký Hội nghị** thông qua biên bản Hội nghị.

Xin kính mời đồng chí!

*Đồng chí thư ký đọc biên bản Hội nghị.*

Xin cảm ơn đồng chí thư ký!

Kính thưa các đồng chí!

Hội nghị vừa nghe thông qua biên bản ghi nhận diễn biến, các ý kiến thảo luận, kết quả xem xét và những nội dung đã được thống nhất.

Xin ý kiến các đồng chí đối với nội dung biên bản vừa được thông qua.

Có đồng chí nào đề nghị bổ sung, điều chỉnh hoặc làm rõ nội dung nào không?

*Dừng để các đồng chí tham gia ý kiến.*

Nếu không có ý kiến khác, xin Hội nghị thống nhất thông qua biên bản; đồng thời giao đồng chí thư ký hoàn thiện những nội dung bổ sung, điều chỉnh nếu có, để thực hiện việc ký và lưu hồ sơ theo quy định.

Xin trân trọng cảm ơn các đồng chí!

## 3. Bế mạc Hội nghị

**Người dẫn chương trình:**

Kính thưa các đồng chí đại biểu!

Kính thưa toàn thể Hội nghị!

Đến đây, Hội nghị kiểm điểm, tự đánh giá, đề xuất xếp loại chất lượng Ban Chấp hành Đảng ủy và xem xét kết quả đánh giá tập thể chi ủy, chi bộ, đảng viên năm 2026 của Đảng ủy Trường Mầm non An Bình đã hoàn thành toàn bộ nội dung chương trình đề ra.

Thay mặt Ban Tổ chức, xin trân trọng cảm ơn sự quan tâm tham dự của các đồng chí đại biểu; cảm ơn tinh thần trách nhiệm, sự tập trung và những ý kiến đóng góp của các đồng chí trong Ban Chấp hành Đảng ủy.

Kính chúc các đồng chí đại biểu cùng toàn thể các đồng chí sức khỏe, hạnh phúc và hoàn thành tốt nhiệm vụ được giao.

**Xin trân trọng tuyên bố kết thúc Hội nghị!**

**Xin trân trọng cảm ơn!**</WritingBlock>

### Lưu ý rà soát trước khi sử dụng chính thức

Bản trên đã bám sát chương trình bổ sung. Cần kiểm tra lại **chức danh đầy đủ của đồng chí Nguyễn Quốc Đại**, tên của cả 03 chi bộ và người được phân công dẫn chương trình. Phương án đồng chí Nguyễn Thị Ngọc Phượng điều hành phần kiểm điểm đồng chí Bí thư là đề xuất tổ chức, cần được Hội nghị thống nhất, không phải thông tin đã có trong chương trình.

Về căn cứ nghiệp vụ, việc kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 tiếp tục áp dụng Quy định số 366-QĐ/TW ngày 30/8/2025 và hướng dẫn liên quan theo điều khoản chuyển tiếp của Quy định số 227-QĐ/TW; trường hợp tổ chức đảng có điều chỉnh theo Quy định số 208-QĐ/TW thì thực hiện theo hướng dẫn riêng của Ban Tổ chức Trung ương. Cần đối chiếu thêm hướng dẫn cụ thể của Đảng ủy phường An Bình trước khi thực hiện việc biểu quyết và xác định thẩm quyền xếp loại. [Source unavailable: turn993144view2]; [Source unavailable: turn784197search5]

---

