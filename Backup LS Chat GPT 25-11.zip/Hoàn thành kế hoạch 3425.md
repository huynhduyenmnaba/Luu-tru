USER

với vai trò hiệu trưởng và các văn bản đính kèm. bạn hya4 giúp tôi hoàn thành nội dung văn bàn 3425 của phường yêu cầu. Lưu ý bám sát nội dung chỉ đạo và thực hiện phù hợp thực tiễn cơ sở giáo dục mầm non An Bình. Lặp luận logic, chặt chẽ thuyết phục dễ hiểu.

---

ASSISTANT

Tôi sẽ đối chiếu Kế hoạch số 3425/KH-UBND với các văn bản đính kèm, sau đó xây dựng **Kế hoạch triển khai tại Trường Mầm non An Bình giai đoạn 2026–2030**. Nội dung sẽ cụ thể hóa quy trình 6 bước, nhiệm vụ của từng bộ phận, lộ trình thực hiện và cách phối hợp xử lý tình huống phù hợp với trẻ mầm non; đồng thời tránh phát sinh hồ sơ, thủ tục không cần thiết.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Kế hoạch 3425 yêu cầu nhà trường thực hiện 6 nhóm nhiệm vụ, trọng tâm là **quy trình xử lý 6 bước, phòng ngừa qua hoạt động giáo dục, tư vấn ban đầu, kết nối cơ quan hỗ trợ và bảo mật thông tin trẻ**. Tôi sẽ cụ thể hóa thêm các thời điểm dễ phát sinh nguy cơ ở trường mầm non như đón – trả trẻ, ăn, ngủ, vệ sinh và vui chơi. Các tệp hiện có chưa gồm toàn văn Kế hoạch 1328 của Sở, nên bản dự thảo sẽ lấy Kế hoạch 3425 làm căn cứ chỉ đạo trực tiếp.

---

ASSISTANT

---

ASSISTANT

# 📌 KẾ HOẠCH TRIỂN KHAI THỰC HIỆN KẾ HOẠCH SỐ 3425/KH-UBND TẠI TRƯỜNG MẦM NON AN BÌNH

Qua nghiên cứu các văn bản đính kèm, tôi xây dựng dự thảo **Kế hoạch phòng ngừa, phát hiện và xử lý bạo lực trong trường học giai đoạn 2026–2030 tại Trường Mầm non An Bình**.

Bản dự thảo bám sát 6 nhiệm vụ trọng tâm, 3 mục tiêu đến năm 2030 và lộ trình triển khai của UBND phường. Đồng thời, nội dung được cụ thể hóa theo đặc thù giáo dục mầm non: trẻ còn hạn chế khả năng tự bảo vệ và trình bày sự việc; việc bảo đảm an toàn phụ thuộc nhiều vào trách nhiệm của cán bộ quản lý, giáo viên, nhân viên và sự phối hợp với gia đình.

> **writing · document**
>
> | **UBND PHƯỜNG AN BÌNH** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |:---:|:---:|
> | **TRƯỜNG MẦM NON AN BÌNH** | **Độc lập - Tự do - Hạnh phúc** |
> | Số: …/KH-MNAB | *An Bình, ngày … tháng … năm 2026* |
>
> # KẾ HOẠCH
> **Triển khai thực hiện phòng ngừa, phát hiện và xử lý bạo lực trong trường học giai đoạn 2026–2030 tại Trường Mầm non An Bình**
>
> Căn cứ Luật Trẻ em năm 2016 và các văn bản hướng dẫn thi hành;
>
> Căn cứ Nghị định số 80/2017/NĐ-CP ngày 17 tháng 7 năm 2017 của Chính phủ quy định về môi trường giáo dục an toàn, lành mạnh, thân thiện, phòng, chống bạo lực học đường;
>
> Căn cứ Thông tư số 06/2019/TT-BGDĐT ngày 12 tháng 4 năm 2019 của Bộ Giáo dục và Đào tạo quy định Quy tắc ứng xử trong cơ sở giáo dục mầm non, cơ sở giáo dục phổ thông, cơ sở giáo dục thường xuyên;
>
> Căn cứ Thông tư số 45/2021/TT-BGDĐT ngày 31 tháng 12 năm 2021 của Bộ Giáo dục và Đào tạo quy định về việc xây dựng trường học an toàn, phòng, chống tai nạn thương tích trong cơ sở giáo dục mầm non;
>
> Thực hiện Kế hoạch số 3425/KH-UBND ngày 26 tháng 10 năm 2026 của Ủy ban nhân dân phường An Bình về triển khai thực hiện phòng ngừa, phát hiện và xử lý bạo lực trong trường học giai đoạn 2026–2030; trên cơ sở Kế hoạch số 1328/KH-SGDĐT ngày 23 tháng 10 năm 2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp được dẫn chiếu tại Kế hoạch số 3425/KH-UBND;
>
> Căn cứ chức năng, nhiệm vụ và tình hình thực tế của nhà trường, Trường Mầm non An Bình xây dựng Kế hoạch triển khai thực hiện phòng ngừa, phát hiện và xử lý bạo lực trong trường học giai đoạn 2026–2030, cụ thể như sau:
>
> ## I. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> Tăng cường trách nhiệm của cán bộ quản lý, giáo viên, nhân viên trong công tác phòng ngừa, phát hiện và xử lý bạo lực trong trường học; xây dựng môi trường giáo dục an toàn, lành mạnh, thân thiện, bình đẳng, tôn trọng sự khác biệt, bảo đảm mọi trẻ em được chăm sóc, nuôi dưỡng và giáo dục trong môi trường không có bạo lực, xâm hại và phân biệt đối xử.
>
> Chủ động nhận diện, phòng ngừa và phát hiện sớm những nguy cơ ảnh hưởng đến sự an toàn về thể chất, tinh thần của trẻ; kịp thời tiếp nhận thông tin, thực hiện các biện pháp bảo vệ, hỗ trợ ban đầu và phối hợp xử lý vụ việc theo đúng thẩm quyền. Chú trọng phòng ngừa các hành vi bạo hành, xâm hại trẻ em, bạo lực trên cơ sở giới, các hành vi ứng xử thiếu chuẩn mực trong quá trình chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> Nâng cao chất lượng thực hiện quy tắc ứng xử trong nhà trường; xây dựng đội ngũ cán bộ, giáo viên, nhân viên có ý thức trách nhiệm, thái độ ứng xử chuẩn mực, tôn trọng nhân phẩm và quyền trẻ em; thực hiện phương pháp giáo dục tích cực, phù hợp đặc điểm tâm sinh lý lứa tuổi mầm non.
>
> Tăng cường sự phối hợp giữa nhà trường, gia đình và các cơ quan chức năng tại địa phương; xác định rõ trách nhiệm của từng bộ phận, cá nhân trong công tác phòng ngừa, phát hiện, hỗ trợ và xử lý vụ việc, góp phần duy trì môi trường giáo dục an toàn, tạo sự tin tưởng của cha mẹ trẻ và cộng đồng đối với nhà trường.
>
> ### 2. Yêu cầu
>
> Việc triển khai thực hiện phải bám sát mục tiêu, nhiệm vụ và giải pháp theo Kế hoạch số 3425/KH-UBND của UBND phường An Bình; bảo đảm phù hợp với chức năng, nhiệm vụ, điều kiện thực tế và đặc thù hoạt động của cơ sở giáo dục mầm non.
>
> Lấy sự an toàn, quyền và lợi ích tốt nhất của trẻ làm nguyên tắc xuyên suốt. Mọi biểu hiện nghi ngờ trẻ bị bạo lực, xâm hại hoặc có nguy cơ bị tổn thương phải được quan tâm, tiếp nhận và xem xét kịp thời; không chủ quan, che giấu, bỏ sót thông tin hoặc xử lý hình thức.
>
> Phân công trách nhiệm cụ thể, phát huy vai trò chủ động của giáo viên trực tiếp chăm sóc, nuôi dưỡng, giáo dục trẻ; đồng thời đề cao trách nhiệm kiểm tra, giám sát của Ban Giám hiệu trong toàn bộ quá trình tổ chức thực hiện.
>
> Lồng ghép các nội dung phòng ngừa bạo lực, giáo dục bình đẳng giới, kỹ năng tự bảo vệ và xây dựng môi trường giáo dục an toàn vào kế hoạch giáo dục, sinh hoạt chuyên môn, công tác kiểm tra nội bộ và hoạt động phối hợp với cha mẹ trẻ. Hạn chế phát sinh hồ sơ, biểu mẫu, hội nghị hoặc hoạt động riêng không cần thiết.
>
> Bảo đảm tính bảo mật, khách quan, thận trọng trong tiếp nhận và xử lý thông tin. Không công khai danh tính, hình ảnh hoặc các thông tin có khả năng nhận diện trẻ liên quan đến vụ việc; không thực hiện hoạt động tư vấn, trị liệu, xác minh hoặc xử lý vượt quá chức năng, thẩm quyền của nhà trường.
>
> ## II. MỤC TIÊU ĐẾN NĂM 2030
>
> ### 1. Mục tiêu chung
>
> Xây dựng Trường Mầm non An Bình trở thành môi trường giáo dục an toàn, thân thiện, bình đẳng, không bạo lực; chủ động phòng ngừa nguy cơ, phát hiện sớm và phối hợp xử lý kịp thời các tình huống có ảnh hưởng đến sự an toàn của trẻ. Hình thành cơ chế phối hợp thường xuyên, hiệu quả giữa nhà trường, gia đình và các cơ quan chức năng trong công tác bảo vệ trẻ em.
>
> ### 2. Mục tiêu cụ thể
>
> - 100% cán bộ quản lý, giáo viên, nhân viên được phổ biến, quán triệt các quy định về phòng, chống bạo lực học đường, phòng ngừa bạo lực trên cơ sở giới, bảo vệ trẻ em và Quy trình khung 6 bước theo Kế hoạch số 3425/KH-UBND.
>
> - 100% nhóm, lớp triển khai lồng ghép nội dung giáo dục bình đẳng giới, tôn trọng sự khác biệt, kỹ năng tự bảo vệ, nhận biết nguy cơ mất an toàn, phòng ngừa bạo lực và xâm hại trẻ em vào hoạt động chăm sóc, nuôi dưỡng, giáo dục phù hợp độ tuổi.
>
> - 100% phản ánh, thông tin về nguy cơ bạo lực, xâm hại hoặc mất an toàn đối với trẻ được tiếp nhận, xem xét, đánh giá nguy cơ và có biện pháp xử lý, hỗ trợ phù hợp; các vụ việc vượt thẩm quyền được chuyển đến cơ quan chức năng kịp thời.
>
> - Duy trì kênh tiếp nhận thông tin an toàn, thuận tiện giữa nhà trường và cha mẹ trẻ; phân công người phụ trách tiếp nhận, hỗ trợ ban đầu và kết nối chuyển gửi khi phát sinh vụ việc.
>
> - Thiết lập và duy trì cơ chế phối hợp với Công an phường, Trạm Y tế phường, Phòng Văn hóa - Xã hội và các bộ phận có chức năng bảo vệ trẻ em, hỗ trợ pháp lý tại địa phương theo hướng dẫn của UBND phường.
>
> - Duy trì công tác kiểm tra, giám sát, đánh giá việc thực hiện phòng ngừa bạo lực trong hoạt động quản lý, chăm sóc, nuôi dưỡng và giáo dục trẻ; kịp thời phát hiện, chấn chỉnh các hạn chế và phòng ngừa nguy cơ tái diễn.
>
> ## III. NHIỆM VỤ VÀ GIẢI PHÁP TRỌNG TÂM
>
> ### 1. Tổ chức thực hiện nghiêm túc Quy trình khung 6 bước về phòng ngừa, phát hiện và xử lý bạo lực
>
> Nhà trường tổ chức quán triệt và áp dụng thống nhất Quy trình khung 6 bước theo Kế hoạch số 3425/KH-UBND. Việc thực hiện phải phù hợp với đặc điểm trẻ mầm non, trong đó ưu tiên bảo vệ an toàn cho trẻ ngay từ khi phát hiện nguy cơ, không chờ đến khi có đầy đủ thông tin mới thực hiện biện pháp bảo vệ cần thiết.
>
> **Bước 1. Tiếp nhận thông tin**
>
> Tiếp nhận thông tin từ giáo viên, nhân viên, cha mẹ trẻ, người chăm sóc trẻ và các nguồn phản ánh hợp pháp khác thông qua các kênh liên lạc hiện có của nhà trường.
>
> Giáo viên chủ động quan sát, nhận biết những thay đổi bất thường trong hành vi, cảm xúc, sức khỏe của trẻ như lo sợ, né tránh, thu mình, thay đổi đột ngột trong ăn, ngủ, vui chơi hoặc có dấu hiệu tổn thương chưa rõ nguyên nhân. Những biểu hiện này cần được xem xét thận trọng, không tự kết luận là bằng chứng bạo lực hay xâm hại.
>
> Khi tiếp nhận thông tin, người được giao nhiệm vụ phải lắng nghe, ghi nhận khách quan, báo cáo Ban Giám hiệu theo tính chất vụ việc; không tự ý chia sẻ thông tin, chất vấn trẻ nhiều lần hoặc làm ảnh hưởng đến tâm lý của trẻ.
>
> **Bước 2. Đánh giá nguy cơ**
>
> Ban Giám hiệu phối hợp với giáo viên phụ trách trẻ và nhân viên y tế hoặc người được phân công nhiệm vụ y tế trường học để xem xét dấu hiệu tổn thương, mức độ ảnh hưởng và nguy cơ tiếp tục xảy ra bạo lực, xâm hại.
>
> Tập trung nhận diện các nguy cơ liên quan đến hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ; hành vi ứng xử của người lớn với trẻ; các mối quan hệ giữa trẻ với trẻ; nguy cơ mất an toàn trong môi trường lớp học và tại gia đình.
>
> Trường hợp có dấu hiệu nguy hiểm, tổn thương nghiêm trọng hoặc nghi ngờ xâm hại, nhà trường ưu tiên bảo vệ trẻ và phối hợp ngay với cơ quan có thẩm quyền, không tự tiến hành xác minh chuyên sâu.
>
> **Bước 3. Bảo đảm an toàn cho trẻ**
>
> Thực hiện ngay các biện pháp cần thiết nhằm bảo vệ tính mạng, sức khỏe và tinh thần của trẻ.
>
> Tùy tính chất vụ việc, bố trí trẻ ở môi trường an toàn, có người chăm sóc phù hợp; ngăn ngừa nguy cơ trẻ tiếp tục tiếp xúc với người có hành vi đe dọa hoặc nghi gây tổn hại; tổ chức hỗ trợ y tế kịp thời khi cần thiết.
>
> Trường hợp phản ánh liên quan đến cán bộ, giáo viên, nhân viên nhà trường, Hiệu trưởng chủ động bố trí biện pháp bảo vệ phù hợp trong thời gian phối hợp xem xét, xử lý; bảo đảm an toàn của trẻ và quyền, lợi ích hợp pháp của các bên liên quan.
>
> **Bước 4. Hỗ trợ ban đầu**
>
> Giáo viên và nhân viên được phân công thực hiện các biện pháp trấn an, chăm sóc và hỗ trợ ban đầu phù hợp với độ tuổi, trạng thái tâm lý và tình trạng sức khỏe của trẻ.
>
> Đối với trẻ có dấu hiệu tổn thương về thể chất, tổ chức sơ cứu trong phạm vi năng lực, liên hệ cơ sở y tế khi cần. Đối với trẻ bị hoảng sợ, lo lắng hoặc có biểu hiện bất ổn tâm lý, tạo môi trường an toàn, lắng nghe, động viên, giúp trẻ ổn định cảm xúc; không ép trẻ kể lại sự việc hoặc tham gia đối chất.
>
> Nhà trường không thực hiện các hoạt động chẩn đoán, trị liệu tâm lý hoặc xử lý chuyên môn vượt quá năng lực được giao.
>
> **Bước 5. Thông báo và phối hợp xử lý**
>
> Cá nhân tiếp nhận thông tin có trách nhiệm báo cáo Hiệu trưởng hoặc người được phân công phụ trách ngay khi phát hiện vụ việc có nguy cơ ảnh hưởng đến an toàn của trẻ.
>
> Hiệu trưởng căn cứ tính chất, mức độ vụ việc để chỉ đạo biện pháp xử lý thuộc thẩm quyền; phối hợp với gia đình và thông báo, chuyển thông tin đến Công an phường, Trạm Y tế, Phòng Văn hóa - Xã hội, UBND phường hoặc cơ quan chức năng có liên quan theo quy định.
>
> Việc thông báo cho gia đình cần bảo đảm không làm gia tăng nguy cơ tổn hại đối với trẻ. Trường hợp nghi ngờ người thân hoặc người chăm sóc là người gây bạo lực, xâm hại, nhà trường phối hợp cơ quan bảo vệ trẻ em để xác định phương thức thông báo và bảo vệ phù hợp.
>
> Không tự hòa giải đối với vụ việc có dấu hiệu xâm hại, vi phạm pháp luật; không che giấu, trì hoãn việc chuyển thông tin hoặc tự kết luận thay cơ quan có thẩm quyền.
>
> **Bước 6. Kết nối hỗ trợ và theo dõi**
>
> Sau khi thực hiện các biện pháp hỗ trợ ban đầu, nhà trường tiếp tục phối hợp với gia đình và cơ quan chức năng để theo dõi tình trạng sức khỏe, tâm lý, mức độ an toàn và khả năng tham gia các hoạt động sinh hoạt, học tập của trẻ.
>
> Đối với trường hợp cần hỗ trợ chuyên sâu, chủ động kết nối, chuyển gửi đến cơ sở y tế hoặc dịch vụ bảo vệ trẻ em phù hợp. Giáo viên được phân công quan tâm, hỗ trợ trẻ ổn định tâm lý, hòa nhập với môi trường lớp học; không kỳ thị, phân biệt đối xử hoặc nhắc lại vụ việc gây tổn thương cho trẻ.
>
> Thông tin về vụ việc được quản lý, lưu giữ theo quy định hiện hành, bảo đảm bảo mật và chỉ sử dụng phục vụ công tác bảo vệ, hỗ trợ, xử lý theo thẩm quyền.
>
> ### 2. Tăng cường các giải pháp phòng ngừa bạo lực, xây dựng môi trường giáo dục an toàn, thân thiện
>
> **2.1. Nâng cao trách nhiệm và chuẩn mực ứng xử của đội ngũ**
>
> Tổ chức quán triệt cán bộ quản lý, giáo viên, nhân viên thực hiện nghiêm quy tắc ứng xử, đạo đức nghề nghiệp và các quy định về bảo vệ trẻ em; nâng cao ý thức tự kiểm soát cảm xúc, hành vi, lời nói trong quá trình thực hiện nhiệm vụ.
>
> Nghiêm cấm mọi hành vi đánh đập, đe dọa, xúc phạm, miệt thị, cô lập, gây áp lực tâm lý đối với trẻ; không sử dụng các hình thức trừng phạt thân thể, ép ăn, ép ngủ, dọa nạt hoặc biện pháp giáo dục gây tổn hại đến thể chất, tinh thần và nhân phẩm của trẻ.
>
> Khuyến khích giáo viên vận dụng phương pháp giáo dục tích cực, sử dụng ngôn ngữ nhẹ nhàng, tôn trọng cảm xúc, nhu cầu và sự khác biệt của mỗi trẻ; giải quyết các tình huống sư phạm bằng biện pháp phù hợp với độ tuổi, tuyệt đối không lấy bạo lực làm công cụ giáo dục.
>
> **2.2. Chủ động phòng ngừa nguy cơ trong hoạt động chăm sóc, nuôi dưỡng và giáo dục**
>
> Tăng cường kiểm tra, giám sát việc bảo đảm an toàn cho trẻ trong các hoạt động hằng ngày, đặc biệt tại những thời điểm và khu vực cần quan tâm như đón, trả trẻ; ăn, ngủ; vệ sinh cá nhân; vui chơi ngoài trời; hành lang; cổng trường và các vị trí khuất tầm quan sát.
>
> Giáo viên thực hiện nghiêm trách nhiệm quản lý trẻ theo phân công; quan sát, bao quát, hỗ trợ trẻ trong suốt quá trình tổ chức hoạt động; không để trẻ ở trong tình huống thiếu sự giám sát phù hợp hoặc tiếp xúc riêng với người không có nhiệm vụ chăm sóc, giáo dục trẻ.
>
> Thường xuyên rà soát môi trường lớp học, khu vực sinh hoạt và các điều kiện bảo đảm an toàn; kịp thời khắc phục những yếu tố có thể tạo nguy cơ bạo lực, xâm hại hoặc mất an toàn cho trẻ.
>
> Trong các tình huống trẻ tranh giành đồ chơi, xô đẩy, cắn hoặc có hành vi chưa phù hợp, giáo viên cần xem xét đặc điểm phát triển lứa tuổi, hướng dẫn trẻ nhận biết cảm xúc, điều chỉnh hành vi, biết chia sẻ và giải quyết mâu thuẫn; không vội vàng quy kết, gắn nhãn trẻ có hành vi bạo lực.
>
> **2.3. Tăng cường phối hợp giữa nhà trường và gia đình**
>
> Duy trì việc trao đổi thường xuyên, hai chiều giữa giáo viên và cha mẹ trẻ về tình hình sức khỏe, tâm lý, hành vi và sự phát triển của trẻ.
>
> Chủ động hướng dẫn cha mẹ trẻ thực hiện phương pháp chăm sóc, giáo dục tích cực; không sử dụng bạo lực trong giáo dục con; quan tâm đến những biểu hiện bất thường của trẻ và kịp thời thông tin cho nhà trường khi phát hiện nguy cơ.
>
> Lồng ghép tuyên truyền thông qua họp cha mẹ trẻ, trao đổi trực tiếp, bảng tin, các nhóm thông tin chính thức và những hình thức phù hợp với điều kiện của nhà trường. Nội dung tuyên truyền bảo đảm ngắn gọn, dễ hiểu, thiết thực, tránh hình thức và không làm phát sinh thêm các hoạt động riêng không cần thiết.
>
> ### 3. Lồng ghép giáo dục bình đẳng giới, kỹ năng tự bảo vệ, phòng ngừa xâm hại và an toàn số
>
> Chỉ đạo các tổ chuyên môn, giáo viên lồng ghép nội dung giáo dục bình đẳng giới, tôn trọng sự khác biệt, nhận biết cảm xúc, kỹ năng tự bảo vệ và phòng ngừa xâm hại vào các hoạt động giáo dục theo Chương trình Giáo dục mầm non.
>
> Việc lựa chọn nội dung, hình thức tổ chức phải phù hợp khả năng nhận thức, đặc điểm tâm sinh lý và trải nghiệm thực tế của trẻ; không áp dụng máy móc các nội dung giáo dục dành cho học sinh phổ thông.
>
> Đối với trẻ nhà trẻ, nếu nhà trường có tổ chức nhóm tuổi này, tập trung hình thành cảm giác an toàn, sự tin tưởng đối với người chăm sóc; giúp trẻ biết thể hiện nhu cầu, cảm xúc bằng lời nói, cử chỉ và biết tìm đến người lớn khi khó chịu hoặc cần được hỗ trợ.
>
> Đối với trẻ mẫu giáo, thông qua trò chuyện, kể chuyện, trò chơi đóng vai, tranh ảnh và tình huống gần gũi để hướng dẫn trẻ:
>
> - Nhận biết một số tình huống an toàn và không an toàn trong sinh hoạt hằng ngày.
> - Biết cơ thể mình cần được tôn trọng; bước đầu nhận biết ranh giới cá nhân và quyền từ chối những hành vi khiến bản thân không thoải mái.
> - Biết nói “không”, tìm cách tránh xa tình huống nguy hiểm và báo cho người lớn đáng tin cậy khi cần giúp đỡ.
> - Biết tôn trọng bạn bè, không trêu chọc, chế giễu, phân biệt đối xử với bạn vì giới tính, đặc điểm cơ thể, hoàn cảnh hoặc khả năng khác nhau.
> - Biết bày tỏ cảm xúc, hợp tác, chia sẻ và giải quyết mâu thuẫn bằng lời nói, hành động phù hợp.
>
> Đối với nội dung an toàn số và phòng ngừa bạo lực trên không gian mạng, nhà trường tập trung nâng cao trách nhiệm của cán bộ, giáo viên, nhân viên và cha mẹ trẻ trong việc sử dụng thiết bị, nền tảng số; bảo vệ thông tin cá nhân, hình ảnh, dữ liệu của trẻ; hướng dẫn trẻ sử dụng các phương tiện số có sự giám sát của người lớn, phù hợp lứa tuổi.
>
> Không tự ý đăng tải, chia sẻ hình ảnh, video, thông tin nhạy cảm hoặc nội dung liên quan đến trẻ bị bạo lực, xâm hại trên mạng xã hội và các nhóm trao đổi không có thẩm quyền.
>
> Khai thác học liệu, tài liệu hướng dẫn của ngành Giáo dục; ưu tiên sinh hoạt chuyên môn, trao đổi tình huống sư phạm tại trường để nâng cao năng lực giáo viên, bảo đảm thiết thực, tiết kiệm và hiệu quả.
>
> ### 4. Củng cố hoạt động hỗ trợ ban đầu, tư vấn và bảo mật thông tin trẻ em
>
> Hiệu trưởng phân công cán bộ quản lý hoặc giáo viên có năng lực phù hợp kiêm nhiệm nhiệm vụ tiếp nhận thông tin, hỗ trợ tâm lý ban đầu và phối hợp thực hiện công tác bảo vệ trẻ em tại nhà trường.
>
> Người được phân công có trách nhiệm phối hợp với giáo viên chủ nhiệm, nhân viên y tế hoặc người được giao nhiệm vụ y tế trường học để nhận diện nguy cơ, hỗ trợ ban đầu, tham mưu biện pháp bảo vệ và kết nối dịch vụ hỗ trợ khi cần thiết.
>
> Hoạt động hỗ trợ tập trung vào việc lắng nghe, trấn an, ổn định tâm lý, hỗ trợ trẻ trong sinh hoạt và phối hợp với gia đình; không thực hiện các hoạt động trị liệu tâm lý chuyên sâu ngoài phạm vi chuyên môn.
>
> Thực hiện nghiêm quy định về bảo vệ thông tin cá nhân của trẻ em. Thông tin phản ánh, hồ sơ liên quan đến vụ việc chỉ được tiếp cận, sử dụng và cung cấp cho cá nhân, cơ quan có trách nhiệm theo quy định.
>
> Không công khai danh tính trẻ, cha mẹ trẻ, người cung cấp thông tin và người có liên quan; không bình luận, phát tán nội dung vụ việc khi chưa được phép. Việc trao đổi thông tin trong nội bộ nhà trường phải bảo đảm đúng phạm vi trách nhiệm, tránh gây ảnh hưởng đến quyền riêng tư và tâm lý của trẻ.
>
> ### 5. Thiết lập và duy trì cơ chế phối hợp với các cơ quan, đơn vị hỗ trợ tại địa phương
>
> Nhà trường chủ động tiếp nhận và cập nhật danh mục đầu mối liên hệ chính thức do UBND phường, Phòng Văn hóa - Xã hội cung cấp, gồm Công an phường, Trạm Y tế phường, bộ phận thực hiện nhiệm vụ bảo vệ trẻ em, hỗ trợ pháp lý và các đơn vị liên quan.
>
> Phân công đầu mối liên hệ, lưu giữ thông tin liên lạc tại Ban Giám hiệu và những bộ phận cần thiết để bảo đảm kịp thời sử dụng khi phát sinh tình huống. Thông tin liên hệ được cập nhật khi cơ quan có thẩm quyền điều chỉnh.
>
> Khi xảy ra vụ việc vượt quá thẩm quyền hoặc khả năng hỗ trợ của nhà trường, Hiệu trưởng chủ động thông tin, phối hợp và chuyển gửi đến cơ quan chức năng phù hợp với tính chất, mức độ vụ việc.
>
> Đối với tình huống cần bảo vệ khẩn cấp, ưu tiên thực hiện ngay biện pháp bảo đảm an toàn, hỗ trợ y tế và liên hệ cơ quan chức năng; có thể sử dụng Tổng đài quốc gia bảo vệ trẻ em 111 để được hướng dẫn, hỗ trợ theo quy định.
>
> Tăng cường phối hợp với cha mẹ trẻ và các tổ chức, đoàn thể tại địa phương trong tuyên truyền, vận động xây dựng môi trường sống, học tập an toàn, không bạo lực; bảo đảm sự phối hợp có trách nhiệm, đúng chức năng và không làm ảnh hưởng đến quyền lợi của trẻ.
>
> ### 6. Tăng cường kiểm tra, giám sát, đánh giá việc thực hiện
>
> Lồng ghép nội dung phòng ngừa bạo lực, bảo vệ trẻ em, thực hiện quy tắc ứng xử và bảo đảm an toàn về thể chất, tinh thần cho trẻ vào kế hoạch kiểm tra nội bộ, kiểm tra chuyên môn, dự giờ, thăm lớp và các hoạt động quản lý thường xuyên.
>
> Nội dung kiểm tra tập trung vào trách nhiệm của cán bộ, giáo viên, nhân viên trong thực hiện nhiệm vụ; thái độ, hành vi ứng xử với trẻ; việc tổ chức các hoạt động chăm sóc, nuôi dưỡng, giáo dục; công tác phối hợp với cha mẹ trẻ và khả năng phát hiện, xử lý tình huống có nguy cơ mất an toàn.
>
> Đối với những hạn chế được phát hiện, Ban Giám hiệu kịp thời trao đổi, hướng dẫn, yêu cầu khắc phục và theo dõi kết quả. Những hành vi vi phạm phải được xem xét, xử lý hoặc chuyển cơ quan có thẩm quyền theo quy định, không nể nang, bao che.
>
> Gắn kết quả thực hiện với việc đánh giá trách nhiệm, chất lượng thực hiện nhiệm vụ của tập thể, cá nhân và công tác xây dựng trường học an toàn. Chú trọng đánh giá hiệu quả phòng ngừa, khả năng phát hiện sớm và xử lý đúng quy định; không chạy theo thành tích hoặc sử dụng chỉ tiêu không có vụ việc để che giấu, bỏ sót phản ánh.
>
> Sử dụng các hồ sơ chuyên môn, sổ giao ban, biên bản kiểm tra và hệ thống báo cáo hiện có; không đặt ra các loại hồ sơ, sổ sách hoặc báo cáo độc lập khi không có yêu cầu của cơ quan có thẩm quyền.
>
> ## IV. LỘ TRÌNH THỰC HIỆN GIAI ĐOẠN 2026–2030
>
> ### 1. Năm 2026: Triển khai, rà soát và xác định nhiệm vụ trọng tâm
>
> Ban hành Kế hoạch triển khai thực hiện tại Trường Mầm non An Bình; tổ chức phổ biến, quán triệt đến toàn thể cán bộ quản lý, giáo viên, nhân viên thông qua các cuộc họp và sinh hoạt chuyên môn hiện có.
>
> Rà soát việc thực hiện quy tắc ứng xử, công tác bảo đảm an toàn cho trẻ, các kênh tiếp nhận thông tin, trách nhiệm của từng bộ phận và những nguy cơ có thể phát sinh trong hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Phân công người phụ trách tiếp nhận thông tin, hỗ trợ ban đầu và phối hợp xử lý vụ việc; thống nhất việc vận dụng Quy trình khung 6 bước trong phạm vi nhà trường.
>
> Tập trung hoàn thành việc quán triệt, rà soát và phân công trách nhiệm trong thời gian còn lại của năm 2026.
>
> ### 2. Năm 2027: Chuẩn hóa việc thực hiện và tăng cường năng lực phòng ngừa
>
> Tổ chức thực hiện thống nhất Quy trình khung 6 bước trong toàn trường; hướng dẫn cán bộ, giáo viên, nhân viên nhận diện nguy cơ, tiếp nhận thông tin và xử lý tình huống theo chức trách được giao.
>
> Lồng ghép nội dung phòng ngừa bạo lực, bình đẳng giới, kỹ năng tự bảo vệ vào các hoạt động giáo dục thường xuyên.
>
> Cập nhật, sử dụng hiệu quả danh mục đầu mối mạng lưới hỗ trợ của địa phương; tăng cường trao đổi, phối hợp với gia đình trong việc phát hiện nguy cơ và bảo vệ trẻ em.
>
> Tổ chức trao đổi, thực hành xử lý tình huống thông qua sinh hoạt chuyên môn, không tổ chức tập huấn riêng dàn trải.
>
> ### 3. Năm 2028: Sơ kết, đánh giá và điều chỉnh
>
> Tổ chức sơ kết kết quả thực hiện giai đoạn 2026–2028; đánh giá mức độ hoàn thành các mục tiêu, hiệu quả của công tác phòng ngừa, phát hiện và xử lý bạo lực trong nhà trường.
>
> Rà soát những khó khăn, hạn chế trong việc phối hợp giữa nhà trường, gia đình và cơ quan chức năng; xác định nguyên nhân, trách nhiệm và giải pháp khắc phục.
>
> Điều chỉnh các biện pháp tổ chức thực hiện phù hợp với điều kiện thực tế, đặc điểm đội ngũ và yêu cầu bảo đảm an toàn cho trẻ.
>
> ### 4. Năm 2029: Duy trì, củng cố và nâng cao hiệu quả
>
> Tiếp tục duy trì các nội dung đã triển khai hiệu quả; tăng cường hướng dẫn, hỗ trợ giáo viên trong công tác phòng ngừa, nhận diện nguy cơ và hỗ trợ trẻ.
>
> Rà soát việc thực hiện quy tắc ứng xử, trách nhiệm của các bộ phận, hiệu quả hoạt động của kênh tiếp nhận thông tin và cơ chế phối hợp chuyển gửi.
>
> Kịp thời bổ sung giải pháp đối với những nguy cơ mới phát sinh, đặc biệt là nguy cơ liên quan đến sử dụng thiết bị số, chia sẻ thông tin cá nhân và hình ảnh của trẻ.
>
> ### 5. Năm 2030: Tổng kết giai đoạn
>
> Tổ chức tổng kết, đánh giá kết quả thực hiện Kế hoạch giai đoạn 2026–2030; đối chiếu kết quả thực hiện với các mục tiêu, nhiệm vụ đã đề ra.
>
> Phân tích những kết quả đạt được, hạn chế, nguyên nhân và bài học kinh nghiệm; đề xuất giải pháp duy trì, nâng cao chất lượng công tác phòng ngừa bạo lực và bảo vệ trẻ em trong giai đoạn tiếp theo.
>
> Đề xuất biểu dương, khen thưởng tập thể, cá nhân có thành tích tiêu biểu trong xây dựng môi trường giáo dục an toàn, thân thiện, không bạo lực theo quy định.
>
> ## V. KINH PHÍ THỰC HIỆN
>
> Kinh phí thực hiện Kế hoạch được cân đối trong dự toán chi thường xuyên hằng năm của nhà trường theo phân cấp và các nguồn kinh phí hợp pháp khác theo quy định.
>
> Ưu tiên lồng ghép các hoạt động tuyên truyền, sinh hoạt chuyên môn, giáo dục kỹ năng, kiểm tra và giám sát vào những hoạt động thường xuyên của nhà trường; tận dụng cơ sở vật chất, trang thiết bị, học liệu và hệ thống thông tin hiện có.
>
> Việc sử dụng kinh phí bảo đảm tiết kiệm, thiết thực, đúng mục đích, đúng quy định; không đặt ra các khoản thu hoặc danh mục đầu tư riêng không cần thiết để thực hiện Kế hoạch.
>
> ## VI. TỔ CHỨC THỰC HIỆN
>
> ### 1. Hiệu trưởng
>
> Chịu trách nhiệm trước UBND phường An Bình về việc tổ chức triển khai thực hiện Kế hoạch và công tác phòng ngừa, phát hiện, xử lý bạo lực trong phạm vi quản lý của nhà trường.
>
> Chỉ đạo phổ biến, quán triệt các nội dung của Kế hoạch đến toàn thể cán bộ quản lý, giáo viên, nhân viên; phân công trách nhiệm cụ thể cho từng bộ phận và cá nhân có liên quan.
>
> Chỉ đạo triển khai thống nhất Quy trình khung 6 bước; duy trì kênh tiếp nhận thông tin an toàn, bảo đảm mọi phản ánh liên quan đến nguy cơ bạo lực, xâm hại trẻ em được quan tâm và xử lý kịp thời.
>
> Chủ động phối hợp với Công an phường, Trạm Y tế, Phòng Văn hóa - Xã hội, UBND phường và các cơ quan chức năng khi xảy ra vụ việc vượt thẩm quyền; thực hiện chế độ thông tin, báo cáo theo quy định.
>
> Tăng cường kiểm tra, giám sát, kịp thời chấn chỉnh hạn chế và xử lý trách nhiệm khi phát hiện vi phạm.
>
> ### 2. Phó Hiệu trưởng và các tổ chuyên môn
>
> Căn cứ nhiệm vụ được phân công, tham mưu Hiệu trưởng tổ chức triển khai, hướng dẫn giáo viên thực hiện các nội dung của Kế hoạch gắn với công tác chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> Hướng dẫn giáo viên xây dựng môi trường giáo dục an toàn, thực hiện ứng xử sư phạm tích cực; lồng ghép giáo dục bình đẳng giới, kỹ năng tự bảo vệ, phòng ngừa bạo lực và xâm hại trẻ em vào kế hoạch giáo dục hiện có.
>
> Đưa nội dung phòng ngừa bạo lực và xử lý tình huống sư phạm vào sinh hoạt chuyên môn; tổ chức trao đổi, rút kinh nghiệm từ các tình huống thực tiễn, nâng cao năng lực nhận diện và ứng phó của giáo viên.
>
> Thường xuyên theo dõi, kiểm tra việc thực hiện tại các nhóm, lớp; tổng hợp khó khăn, vướng mắc và đề xuất biện pháp giải quyết với Hiệu trưởng.
>
> ### 3. Giáo viên các nhóm, lớp
>
> Thực hiện nghiêm quy tắc ứng xử, đạo đức nghề nghiệp và trách nhiệm bảo vệ trẻ em; bảo đảm an toàn về thể chất, tinh thần cho trẻ trong mọi hoạt động thuộc phạm vi được phân công.
>
> Chủ động quan sát, nhận biết những biểu hiện bất thường của trẻ; kịp thời báo cáo khi phát hiện nguy cơ hoặc dấu hiệu trẻ bị bạo lực, xâm hại; không che giấu hoặc tự giải quyết vụ việc vượt quá thẩm quyền.
>
> Tổ chức lồng ghép giáo dục kỹ năng tự bảo vệ, nhận biết cảm xúc, tôn trọng sự khác biệt và giải quyết mâu thuẫn phù hợp với độ tuổi.
>
> Phối hợp chặt chẽ với cha mẹ trẻ trong công tác chăm sóc, giáo dục, phát hiện và phòng ngừa nguy cơ; bảo mật thông tin cá nhân, hình ảnh của trẻ theo quy định.
>
> ### 4. Nhân viên y tế, nuôi dưỡng, bảo vệ và các bộ phận liên quan
>
> Nhân viên y tế hoặc người được giao nhiệm vụ y tế trường học có trách nhiệm phối hợp nhận diện dấu hiệu tổn thương, thực hiện sơ cứu ban đầu trong phạm vi chuyên môn, tham mưu kết nối cơ sở y tế khi cần thiết.
>
> Nhân viên nuôi dưỡng thực hiện nghiêm quy định về an toàn, vệ sinh, chăm sóc trẻ; có thái độ ứng xử phù hợp, không thực hiện hành vi ép buộc, đe dọa, gây tổn hại cho trẻ.
>
> Nhân viên bảo vệ phối hợp kiểm soát người ra vào trường, bảo đảm an ninh, trật tự khu vực cổng trường, hỗ trợ phát hiện và thông tin kịp thời các tình huống bất thường.
>
> Các bộ phận có trách nhiệm phối hợp với Ban Giám hiệu và giáo viên theo chức trách được giao; không tự ý cung cấp thông tin vụ việc, hình ảnh hoặc dữ liệu cá nhân của trẻ cho người không có thẩm quyền.
>
> ### 5. Cán bộ, giáo viên được phân công kiêm nhiệm công tác hỗ trợ trẻ em
>
> Thực hiện nhiệm vụ tiếp nhận và tham mưu xử lý thông tin liên quan đến nguy cơ bạo lực, xâm hại trẻ em theo sự phân công của Hiệu trưởng.
>
> Phối hợp hỗ trợ tâm lý ban đầu, hướng dẫn giáo viên quan tâm, ổn định tinh thần cho trẻ; chủ động đề xuất kết nối dịch vụ y tế, bảo vệ trẻ em hoặc hỗ trợ chuyên sâu khi cần thiết.
>
> Thực hiện nghiêm quy định bảo mật và quản lý thông tin; không tự tiến hành hoạt động trị liệu, điều tra hoặc xử lý vượt quá phạm vi trách nhiệm.
>
> ### 6. Phối hợp với cha mẹ trẻ
>
> Nhà trường thông tin, tuyên truyền để cha mẹ trẻ hiểu rõ trách nhiệm phối hợp trong phòng ngừa bạo lực, bảo vệ trẻ em và xây dựng môi trường giáo dục an toàn.
>
> Khuyến khích cha mẹ trẻ chủ động trao đổi với giáo viên, Ban Giám hiệu khi có những thay đổi bất thường về sức khỏe, tâm lý, hành vi của trẻ hoặc phát hiện nguy cơ mất an toàn.
>
> Phối hợp thống nhất các biện pháp chăm sóc, giáo dục tích cực giữa gia đình và nhà trường; không sử dụng bạo lực, xúc phạm hoặc gây áp lực tâm lý đối với trẻ.
>
> ### 7. Công tác theo dõi, đánh giá và báo cáo
>
> Ban Giám hiệu thường xuyên theo dõi tình hình thực hiện Kế hoạch; định kỳ lồng ghép đánh giá kết quả vào các cuộc họp chuyên môn, sơ kết học kỳ, tổng kết năm học và công tác kiểm tra nội bộ.
>
> Khi phát sinh vụ việc có dấu hiệu bạo lực, xâm hại hoặc nguy cơ nghiêm trọng đối với trẻ, nhà trường thực hiện thông tin, báo cáo kịp thời đến cơ quan có thẩm quyền theo quy định; đồng thời phối hợp triển khai các biện pháp bảo vệ, hỗ trợ trẻ.
>
> Thực hiện báo cáo sơ kết, tổng kết theo yêu cầu của UBND phường, cơ quan quản lý và hướng dẫn của ngành Giáo dục; không phát sinh hệ thống báo cáo, hồ sơ độc lập ngoài yêu cầu.
>
> Trên đây là Kế hoạch triển khai thực hiện phòng ngừa, phát hiện và xử lý bạo lực trong trường học giai đoạn 2026–2030 tại Trường Mầm non An Bình. Yêu cầu toàn thể cán bộ quản lý, giáo viên, nhân viên nghiêm túc triển khai thực hiện. Trong quá trình thực hiện, nếu phát sinh khó khăn, vướng mắc, các bộ phận kịp thời báo cáo Hiệu trưởng để xem xét, giải quyết hoặc tham mưu cơ quan có thẩm quyền theo quy định./.
>
> | **Nơi nhận:** | **HIỆU TRƯỞNG** |
> |:---|:---:|
> | - UBND phường An Bình (báo cáo); | |
> | - Phòng Văn hóa - Xã hội (phối hợp); | |
> | - Ban Giám hiệu; | |
> | - Các tổ chuyên môn, bộ phận (thực hiện); | |
> | - Lưu: VT. | **(Ký, ghi rõ họ tên và đóng dấu)** |

## ⚠️ Những nội dung cần hoàn thiện trước khi ban hành

Bản dự thảo không tự đưa vào số lượng trẻ, nhóm lớp, cán bộ, giáo viên, nhân viên hoặc tên người phụ trách vì các dữ liệu thực tế của Trường Mầm non An Bình chưa được cung cấp.

Trước khi ký ban hành, nhà trường cần điền số, ngày văn bản; xác định người được phân công tiếp nhận thông tin, hỗ trợ trẻ; cập nhật danh bạ đầu mối chính thức do phường cung cấp. Các căn cứ chuyên ngành bổ sung đã được đối chiếu với nguồn văn bản chính thức và tài liệu của Bộ Giáo dục và Đào tạo. [Source unavailable: turn659672search1]; [Source unavailable: turn659672search0]; [Source unavailable: turn354615search1]

**Một lưu ý quan trọng:** Các tệp đính kèm có Kế hoạch số 3425/KH-UBND nhưng chưa có toàn văn Kế hoạch số 1328/KH-SGDĐT. Vì vậy, bản dự thảo đã bám sát đầy đủ những nhiệm vụ được UBND phường thể hiện trong Kế hoạch 3425; khi có toàn văn Kế hoạch 1328, cần đối chiếu thêm để bảo đảm không bỏ sót nhiệm vụ đặc thù cấp trường.

✅ **Về định hướng quản lý:** Tôi đề xuất nhà trường lấy ba yếu tố làm trọng tâm đánh giá kết quả: *phòng ngừa thực chất – phát hiện kịp thời – xử lý đúng quy định*. Đây là cách triển khai vừa đáp ứng chỉ đạo của UBND phường, vừa tạo sự chuyển biến bền vững trong chất lượng chăm sóc, nuôi dưỡng và bảo vệ trẻ tại Trường Mầm non An Bình.

---

USER

nội dung tổ chức thực hiện bạn viết gọn lại gồm BGH, tổ chuyên môn, giáo viên , nhân viên,  cán bộ, giáo viên phân công kiêm nhiệm công tác hỗ trợ trẻ em, cha mẹ trẻ.  Công tác theo dõi báo cáo là mục lớn

---

ASSISTANT

Tôi đã điều chỉnh **Mục VI. Tổ chức thực hiện** theo hướng ngắn gọn, rõ trách nhiệm của 6 nhóm đối tượng; đồng thời tách **Công tác theo dõi, báo cáo** thành Mục VII riêng, bảo đảm logic, tránh trùng lặp và bám sát Kế hoạch số 3425/KH-UBND của phường An Bình.

> **writing · document**
>
> ## VI. TỔ CHỨC THỰC HIỆN
>
> ### 1. Ban Giám hiệu
>
> Chịu trách nhiệm chỉ đạo, tổ chức triển khai thực hiện Kế hoạch trong toàn trường; phân công nhiệm vụ cụ thể cho các bộ phận, cá nhân; tổ chức thực hiện thống nhất Quy trình khung 6 bước về phòng ngừa, phát hiện và xử lý bạo lực.
>
> Tăng cường kiểm tra, giám sát việc thực hiện; kịp thời chỉ đạo xử lý các tình huống phát sinh, chủ động phối hợp với gia đình và cơ quan chức năng khi vụ việc vượt thẩm quyền, bảo đảm an toàn và quyền lợi của trẻ.
>
> ### 2. Các tổ chuyên môn
>
> Lồng ghép nội dung phòng ngừa bạo lực, giáo dục bình đẳng giới, kỹ năng tự bảo vệ và xây dựng môi trường giáo dục an toàn vào các hoạt động chuyên môn phù hợp với độ tuổi.
>
> Tăng cường sinh hoạt chuyên môn, trao đổi kinh nghiệm xử lý tình huống sư phạm; theo dõi, hướng dẫn, hỗ trợ giáo viên thực hiện và kịp thời đề xuất giải pháp khắc phục những hạn chế phát sinh.
>
> ### 3. Giáo viên
>
> Thực hiện nghiêm quy tắc ứng xử, đạo đức nghề nghiệp; bảo đảm an toàn về thể chất, tinh thần cho trẻ trong các hoạt động chăm sóc, nuôi dưỡng và giáo dục.
>
> Chủ động quan sát, phát hiện sớm các dấu hiệu bất thường, nguy cơ bạo lực, xâm hại; kịp thời báo cáo Ban Giám hiệu, phối hợp hỗ trợ trẻ và bảo mật thông tin theo quy định. Tăng cường giáo dục kỹ năng tự bảo vệ, ứng xử tích cực và phối hợp chặt chẽ với cha mẹ trẻ.
>
> ### 4. Nhân viên
>
> Thực hiện nghiêm trách nhiệm bảo đảm an toàn cho trẻ theo vị trí việc làm; tuân thủ quy tắc ứng xử, không có hành vi gây tổn hại đến thể chất, tinh thần của trẻ.
>
> Chủ động phát hiện, thông tin kịp thời các nguy cơ mất an toàn; phối hợp với giáo viên, Ban Giám hiệu trong việc bảo vệ, chăm sóc và hỗ trợ trẻ khi có tình huống phát sinh.
>
> ### 5. Cán bộ, giáo viên được phân công kiêm nhiệm công tác hỗ trợ trẻ em
>
> Tham mưu Ban Giám hiệu tiếp nhận thông tin, nhận diện nguy cơ, hỗ trợ tâm lý ban đầu và phối hợp thực hiện các biện pháp bảo vệ trẻ theo Quy trình khung 6 bước.
>
> Phối hợp với giáo viên, cha mẹ trẻ và các cơ quan chức năng trong việc kết nối dịch vụ hỗ trợ khi cần thiết; theo dõi tình trạng của trẻ, bảo mật thông tin và không thực hiện hoạt động chuyên môn vượt quá năng lực, thẩm quyền.
>
> ### 6. Cha mẹ trẻ
>
> Phối hợp với nhà trường trong công tác chăm sóc, giáo dục, bảo vệ trẻ; thực hiện phương pháp giáo dục tích cực, không sử dụng bạo lực hoặc các hình thức gây tổn thương cho trẻ.
>
> Thường xuyên trao đổi thông tin với giáo viên; kịp thời phản ánh những biểu hiện bất thường, nguy cơ bạo lực, xâm hại và phối hợp thực hiện các biện pháp bảo vệ, hỗ trợ trẻ khi cần thiết.
>
> ## VII. CÔNG TÁC THEO DÕI, BÁO CÁO
>
> Ban Giám hiệu thường xuyên theo dõi, kiểm tra, đánh giá kết quả thực hiện Kế hoạch; lồng ghép nội dung đánh giá vào các cuộc họp chuyên môn, công tác kiểm tra nội bộ, sơ kết học kỳ và tổng kết năm học. Kịp thời phát hiện những khó khăn, hạn chế để chỉ đạo điều chỉnh, bổ sung giải pháp phù hợp với tình hình thực tế.
>
> Các tổ chuyên môn, giáo viên, nhân viên có trách nhiệm phản ánh kịp thời những nguy cơ, vụ việc liên quan đến bạo lực, xâm hại hoặc mất an toàn đối với trẻ. Khi phát sinh vụ việc, Ban Giám hiệu chỉ đạo thực hiện ngay các biện pháp bảo vệ, hỗ trợ trẻ; đồng thời thông tin, báo cáo và phối hợp với cơ quan có thẩm quyền theo quy định.
>
> Nhà trường thực hiện chế độ báo cáo định kỳ, đột xuất, sơ kết và tổng kết theo yêu cầu của UBND phường An Bình và cơ quan quản lý giáo dục. Nội dung báo cáo bảo đảm khách quan, chính xác, kịp thời, bảo mật thông tin trẻ em; sử dụng hệ thống hồ sơ, báo cáo hiện có, không phát sinh thủ tục hành chính không cần thiết.

**Điểm điều chỉnh:** Mục VI tập trung vào trách nhiệm thực hiện của từng đối tượng; Mục VII tập trung vào cơ chế theo dõi, kiểm tra, thông tin và báo cáo. Cách phân định này giúp văn bản rõ trách nhiệm, dễ triển khai, đồng thời phù hợp yêu cầu của UBND phường về giảm hồ sơ hành chính và nâng cao hiệu quả quản lý tại Trường Mầm non An Bình.

---

USER

với nội dung kế hoạch này mình thấy cần có bảng phân công sẽ rõ nội dung hơn

---

ASSISTANT

Tôi đồng ý. Với Kế hoạch triển khai giai đoạn 2026–2030, **bổ sung bảng phân công nhiệm vụ sẽ giúp xác định rõ ai phụ trách, thực hiện nội dung gì, thời gian nào và kết quả cần đạt**. Đây cũng là căn cứ để Ban Giám hiệu theo dõi, đôn đốc và đánh giá việc thực hiện.

Tôi đề xuất **giữ nguyên Mục VI. Tổ chức thực hiện và Mục VII. Công tác theo dõi, báo cáo** đã tinh gọn; bổ sung bảng phân công dưới dạng phụ lục kèm theo Kế hoạch. Cách này vừa bảo đảm tính chặt chẽ của văn bản hành chính, vừa thuận lợi cho việc triển khai tại Trường Mầm non An Bình.

> **writing · document**
>
> **PHỤ LỤC**
>
> # BẢNG PHÂN CÔNG NHIỆM VỤ
> **Triển khai thực hiện phòng ngừa, phát hiện và xử lý bạo lực trong trường học giai đoạn 2026–2030 tại Trường Mầm non An Bình**
>
> *(Kèm theo Kế hoạch số …/KH-MNAB ngày … tháng … năm 2026 của Trường Mầm non An Bình)*
>
> | TT | Nội dung nhiệm vụ | Phụ trách chính | Bộ phận phối hợp | Thời gian thực hiện | Kết quả cần đạt |
> |---|---|---|---|---|---|
> | 1 | Tổ chức triển khai, quán triệt Kế hoạch số 3425/KH-UBND; phân công trách nhiệm và hướng dẫn thực hiện trong toàn trường. | Ban Giám hiệu | Tổ chuyên môn, giáo viên, nhân viên | Quý IV/2026; cập nhật khi có chỉ đạo mới | 100% CBQL, GV, NV được quán triệt nội dung Kế hoạch và trách nhiệm thực hiện. |
> | 2 | Rà soát nguy cơ bạo lực, xâm hại, mất an toàn trong các hoạt động đón, trả trẻ; ăn, ngủ; vệ sinh; vui chơi và các khu vực sinh hoạt của trẻ. | Ban Giám hiệu | Tổ chuyên môn, giáo viên, nhân viên | Năm 2026; duy trì thường xuyên | Phát hiện nguy cơ, kịp thời thực hiện biện pháp phòng ngừa, khắc phục. |
> | 3 | Tổ chức thực hiện Quy trình khung 6 bước: tiếp nhận thông tin, đánh giá nguy cơ, bảo đảm an toàn, hỗ trợ ban đầu, thông báo và xử lý, kết nối và theo dõi. | Ban Giám hiệu | Cán bộ, giáo viên kiêm nhiệm hỗ trợ trẻ em; giáo viên, nhân viên | Triển khai từ năm 2026, chuẩn hóa năm 2027; thực hiện khi phát sinh vụ việc | 100% thông tin phản ánh được tiếp nhận, xem xét và xử lý hoặc chuyển cơ quan có thẩm quyền phù hợp. |
> | 4 | Lồng ghép giáo dục bình đẳng giới, tôn trọng sự khác biệt, kỹ năng tự bảo vệ, phòng ngừa bạo lực, xâm hại và an toàn số phù hợp độ tuổi. | Tổ chuyên môn | Giáo viên, cha mẹ trẻ | Thường xuyên theo kế hoạch giáo dục | 100% nhóm, lớp lồng ghép nội dung phù hợp; trẻ được hình thành kỹ năng tự bảo vệ theo khả năng và độ tuổi. |
> | 5 | Thực hiện quy tắc ứng xử, phương pháp giáo dục tích cực; tăng cường quan sát, quản lý và bảo đảm an toàn thể chất, tinh thần cho trẻ. | Giáo viên | Tổ chuyên môn, nhân viên | Hằng ngày | Duy trì môi trường giáo dục an toàn, thân thiện; kịp thời phát hiện, ngăn ngừa hành vi không phù hợp. |
> | 6 | Tiếp nhận thông tin, nhận diện nguy cơ, tham mưu hỗ trợ tâm lý ban đầu; phối hợp theo dõi, hỗ trợ trẻ và bảo mật thông tin. | Cán bộ, giáo viên được phân công kiêm nhiệm công tác hỗ trợ trẻ em | Ban Giám hiệu, giáo viên, nhân viên | Thường xuyên; ngay khi phát sinh vụ việc | Trẻ có nguy cơ hoặc bị tổn thương được hỗ trợ kịp thời, đúng phạm vi trách nhiệm. |
> | 7 | Cập nhật đầu mối liên hệ, phối hợp với Công an phường, Trạm Y tế, Phòng Văn hóa - Xã hội và các cơ quan chức năng khi có vụ việc vượt thẩm quyền. | Ban Giám hiệu | Cán bộ, giáo viên kiêm nhiệm hỗ trợ trẻ em; các bộ phận liên quan | Theo danh mục phường cung cấp; cập nhật khi thay đổi, phối hợp ngay khi cần | Duy trì cơ chế phối hợp, kết nối hỗ trợ và chuyển gửi kịp thời. |
> | 8 | Tuyên truyền, trao đổi với cha mẹ trẻ về phòng ngừa bạo lực, phương pháp giáo dục tích cực, bảo vệ thông tin, hình ảnh và an toàn của trẻ. | Giáo viên | Ban Giám hiệu, tổ chuyên môn, cha mẹ trẻ | Thông qua họp cha mẹ trẻ, trao đổi thường xuyên và các kênh liên lạc hiện có | Nâng cao nhận thức và trách nhiệm phối hợp giữa gia đình và nhà trường. |
> | 9 | Kiểm tra, giám sát việc thực hiện quy tắc ứng xử, bảo đảm an toàn và phòng ngừa bạo lực trong hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ. | Ban Giám hiệu | Tổ chuyên môn, giáo viên, nhân viên | Lồng ghép kiểm tra nội bộ hằng năm và kiểm tra thường xuyên | Kịp thời phát hiện, chấn chỉnh hạn chế; nâng cao trách nhiệm của đội ngũ. |
> | 10 | Theo dõi, tổng hợp kết quả; thực hiện báo cáo định kỳ, đột xuất; tổ chức sơ kết và tổng kết giai đoạn. | Ban Giám hiệu | Tổ chuyên môn, giáo viên, nhân viên, cán bộ kiêm nhiệm hỗ trợ trẻ em | Theo yêu cầu báo cáo; sơ kết năm 2028, tổng kết năm 2030 | Báo cáo đầy đủ, chính xác, đúng yêu cầu; đánh giá kết quả và đề xuất giải pháp phù hợp. |
>
> **Ghi chú:**
>
> - Các bộ phận, cá nhân căn cứ nhiệm vụ được phân công chủ động triển khai thực hiện; kịp thời báo cáo Ban Giám hiệu khi phát sinh khó khăn, vướng mắc.
> - Cha mẹ trẻ tham gia phối hợp trong phạm vi trách nhiệm gia đình, không thay thế trách nhiệm chuyên môn của nhà trường.
> - Việc theo dõi, đánh giá kết quả thực hiện được lồng ghép vào hồ sơ chuyên môn, kiểm tra nội bộ và chế độ báo cáo hiện có; không phát sinh hồ sơ, sổ sách riêng không cần thiết.

## 💡 Đề xuất để kế hoạch chặt chẽ hơn

Ở cuối **Mục VI. Tổ chức thực hiện**, trước Mục VII, nên bổ sung câu sau:

> Việc phân công nhiệm vụ cụ thể cho từng bộ phận, cá nhân được thực hiện theo Bảng phân công nhiệm vụ kèm theo Kế hoạch này. Các bộ phận căn cứ nội dung được giao chủ động triển khai, phối hợp thực hiện, bảo đảm đúng tiến độ và hiệu quả.

Đồng thời, vẫn giữ **Mục VII. Công tác theo dõi, báo cáo** là một mục lớn độc lập để quy định trách nhiệm kiểm tra, đánh giá và báo cáo của nhà trường.

**Ưu điểm của cách trình bày này:** Phần nội dung Kế hoạch không bị dài hoặc lặp lại trách nhiệm; bảng phân công thể hiện rõ 10 nhóm công việc cụ thể, có thời gian và kết quả cần đạt. Đặc biệt, các nhiệm vụ được gắn trực tiếp với 6 nội dung chỉ đạo trọng tâm của Kế hoạch số 3425/KH-UBND, phù hợp với điều kiện tổ chức hoạt động tại Trường Mầm non An Bình.

---

