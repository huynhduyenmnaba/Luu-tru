USER

với vai trò bí thư bạn giúp tôi phân công nhiệm vụ thực hiện hồ sơ chi bộ 4 tốt. Bí thư, Pbi thư, chi ủy viên kim thư ký. Đảm bảo sát nội dung, dễ hiểu không tự ý thêm nội dung ngoài hướng dẫn

---

ASSISTANT

Tôi đã đối chiếu 4 tài liệu đồng chí cung cấp, đặc biệt là **Hướng dẫn số 01-HD/ĐU về thực hiện mô hình “Chi bộ bốn tốt”**, bảng đánh giá 4 tiêu chí, trích biên bản hội nghị và tờ trình đề nghị công nhận.

Với vai trò Bí thư Chi bộ Trường Mầm non An Bình A, tôi đề xuất phân công theo nguyên tắc: **mỗi đồng chí có nhiệm vụ cụ thể, cả 4 tiêu chí đều có người phụ trách; 3 thành phần hồ sơ theo hướng dẫn đều có người chịu trách nhiệm.** Không bổ sung biểu mẫu hoặc thủ tục ngoài hướng dẫn.

## PHÂN CÔNG NHIỆM VỤ THỰC HIỆN HỒ SƠ “CHI BỘ BỐN TỐT”

**1. Đồng chí Huỳnh Hồng Loan – Bí thư Chi bộ**

Phụ trách chung và Tiêu chí 1: Hoàn thành tốt nhiệm vụ chính trị (mục 1.1 đến 1.9)

- Rà soát kết quả thực hiện nhiệm vụ chính trị, công tác xây dựng Đảng, phát triển đảng viên, đánh giá xếp loại đảng viên, kiểm tra, giám sát và các nội dung thuộc Tiêu chí 1.
- Chỉ đạo Chi ủy rà soát, thống nhất kết quả tự đánh giá cả 4 tiêu chí trước khi trình Chi bộ.
- Chủ trì hội nghị Chi bộ, tổ chức thảo luận, biểu quyết kết quả đánh giá.
- Kiểm tra, ký Tờ trình đề nghị công nhận “Chi bộ bốn tốt” và trình Đảng ủy cơ sở xem xét.

**Sản phẩm phụ trách:** Kết quả đánh giá Tiêu chí 1 và Tờ trình đề nghị công nhận.

---

**2. Đồng chí Nguyễn Thị Huỳnh Duyên – Phó Bí thư Chi bộ**

Phụ trách Tiêu chí 2: Chất lượng sinh hoạt tốt (2.1–2.4) và Tiêu chí 4: Cán bộ, đảng viên tốt (4.1–4.4)

- Rà soát việc thực hiện nền nếp, chất lượng sinh hoạt chi bộ thường kỳ, sinh hoạt chuyên đề; kết quả đánh giá chất lượng sinh hoạt hằng tháng.
- Rà soát kết quả thực hiện trách nhiệm nêu gương, chấp hành kỷ luật, thực hiện chức trách nhiệm vụ của cán bộ, đảng viên và công tác phát triển đảng viên.
- Chủ trì tổng hợp nội dung tự đánh giá của 4 tiêu chí vào Bảng đánh giá theo mẫu hướng dẫn, trên cơ sở kết quả Chi ủy thống nhất.
- Thông qua Bảng đánh giá tại hội nghị Chi bộ theo phân công của Bí thư.

**Sản phẩm phụ trách:** Kết quả đánh giá Tiêu chí 2, Tiêu chí 4 và Bảng đánh giá kết quả thực hiện các tiêu chí “Chi bộ bốn tốt”.

---

**3. Đồng chí Cao Thị Ngọc Nga – Chi ủy viên kiêm Thư ký**

Phụ trách Tiêu chí 3: Đoàn kết, kỷ luật tốt (3.1–3.4) và tổng hợp hồ sơ

- Rà soát việc thực hiện quy chế làm việc, nguyên tắc tập trung dân chủ, tự phê bình và phê bình, đoàn kết nội bộ, chấp hành kỷ luật của đảng viên.
- Đối chiếu tình hình đơn thư khiếu nại, tố cáo đã được cấp có thẩm quyền kết luận và việc xử lý kỷ luật đảng viên (nếu có).
- Ghi biên bản hội nghị Chi bộ, ghi đầy đủ ý kiến thảo luận, kết quả biểu quyết và kết luận của chủ trì.
- Hoàn thiện Trích biên bản hội nghị; tập hợp Tờ trình và Bảng đánh giá thành bộ hồ sơ đề nghị công nhận, trình Bí thư kiểm tra.

**Sản phẩm phụ trách:** Kết quả đánh giá Tiêu chí 3, Trích biên bản hội nghị và bộ hồ sơ tổng hợp.

## Bảng kiểm hồ sơ và người chịu trách nhiệm

Theo Mục IV.5 của Hướng dẫn, hồ sơ đề nghị xét công nhận gồm các thành phần sau:

**Kiểm tra hoàn thiện hồ sơ** /3

## Trình tự thực hiện theo Hướng dẫn

1. **Chi ủy tự đánh giá:** Từng đồng chí rà soát các tiêu chí được phân công; Chi ủy thống nhất kết quả đánh giá trước khi báo cáo Chi bộ.
2. **Chi bộ họp xét:** Thảo luận, biểu quyết kết quả đánh giá. Việc đề nghị công nhận phải được trên 50% số đảng viên chính thức có mặt tán thành.
3. **Hoàn thiện, trình hồ sơ:** Thư ký tổng hợp 3 thành phần hồ sơ; Bí thư kiểm tra, ký Tờ trình và gửi Đảng ủy cơ sở UBND phường xem xét, quyết định.

## Lưu ý quan trọng

- **Không tự đánh giá “Tốt” khi chưa đủ điều kiện.** Theo Hướng dẫn, nếu không bảo đảm một trong các tiêu chí thì Chi bộ không thực hiện đánh giá, đề nghị công nhận.
- Chi bộ chỉ **đánh giá và đề nghị công nhận**; Đảng ủy cơ sở có thẩm quyền xét, quyết định.
- Trong Tờ trình đồng chí đã gửi, phần “Kính gửi: Đảng bộ cơ sở UBND phường An Bình” cần rà soát, chỉnh thành **“Kính gửi: Đảng ủy cơ sở UBND phường An Bình”** cho đúng chủ thể có thẩm quyền theo Hướng dẫn.

**Đề xuất chốt phân công:** Bí thư phụ trách Tiêu chí 1 và Tờ trình; Phó Bí thư phụ trách Tiêu chí 2, 4 và Bảng đánh giá; Chi ủy viên kiêm Thư ký phụ trách Tiêu chí 3, Trích biên bản và tổng hợp hồ sơ. Đây là cách phân công công việc trong Chi ủy, không phải một thủ tục bổ sung ngoài Hướng dẫn.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

