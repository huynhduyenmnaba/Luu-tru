USER

[@Chuyên gia Giáo dục mầm non](plugin://gpt-10d60647f7dfc69465055636721f7c6c@openai-curated-remote) với vai trò hiệu trưởng bạn giúp tôi xử lý tình huống giáo viên tự ý thu tiền ăn bán trú của trẻ bằng hình thức chuyển khoản vào tài khoản cá nhân giáo viên. (nguyên tắc phải chuyển cho tài khoản trường)

---

ASSISTANT

Tôi sẽ sử dụng hướng dẫn của plugin Chuyên gia Giáo dục mầm non để đề xuất cách xử lý trên cương vị hiệu trưởng, làm rõ dòng tiền, bảo đảm quyền lợi của trẻ và trách nhiệm của giáo viên.

---

ASSISTANT

**Với quy trình chị nêu, giáo viên tự ý nhận tiền ăn bán trú vào tài khoản cá nhân là thực hiện sai quy trình thu của nhà trường, cần chấm dứt và làm rõ ngay.** Tuy nhiên, việc nhận tiền sai tài khoản chưa đủ để kết luận giáo viên chiếm dụng tiền. Hiệu trưởng cần xác minh số tiền, thời gian giữ tiền, việc bàn giao và mục đích sử dụng trước khi quyết định xử lý.

Mục tiêu là thu hồi đầy đủ tiền ăn, bảo đảm bữa ăn của trẻ, xác định đúng trách nhiệm và ngăn việc tái diễn.

**1. Yêu cầu dừng ngay việc nhận tiền vào tài khoản cá nhân**

Hiệu trưởng làm việc trực tiếp với giáo viên, có kế toán và người ghi biên bản; yêu cầu:

- Dừng cung cấp số tài khoản cá nhân để thu tiền ăn.
- Giữ nguyên các tin nhắn hướng dẫn phụ huynh chuyển tiền và chứng từ giao dịch liên quan.
- Lập danh sách đầy đủ phụ huynh đã chuyển tiền, số tiền, ngày nhận, khoản đã bàn giao và khoản còn giữ.
- Viết bản tường trình: thực hiện từ khi nào, vì sao, có ai chỉ đạo hoặc biết việc này, tiền đã được sử dụng hay chưa.

**Không chỉ trao đổi miệng hoặc yêu cầu chuyển tiền xong là kết thúc vụ việc.** Biên bản cần ghi rõ yêu cầu khắc phục, người phụ trách và thời hạn hoàn thành.

**2. Giao kế toán đối chiếu, xác định chính xác dòng tiền**

Đối chiếu ba nguồn: chứng từ phụ huynh chuyển tiền, giao dịch liên quan do giáo viên cung cấp và sổ thu của trường.

| Nội dung cần xác minh | Mục đích |
|---|---|
| Từng trẻ, từng khoản tiền đã chuyển | Xác định đủ người nộp và số tiền |
| Tổng tiền giáo viên nhận | Xác định số thực thu |
| Tiền đã bàn giao cho trường, kèm chứng từ | Tránh tính thiếu hoặc tính trùng |
| Tiền còn giữ, đã hoàn trả hoặc đã sử dụng | Xác định khoản phải khắc phục |
| Chênh lệch và nguyên nhân | Làm rõ trách nhiệm |

Chỉ yêu cầu cung cấp giao dịch liên quan đến tiền ăn; không công khai những giao dịch cá nhân không liên quan.

Sau đối chiếu, yêu cầu giáo viên chuyển đầy đủ khoản còn giữ vào tài khoản trường, kèm bảng kê để kế toán xác nhận theo từng trẻ. Nếu có khoản giáo viên tự chi, phải kiểm tra chứng từ và thẩm quyền chi, **không tự động chấp nhận bù trừ**.

Thời hạn khắc phục nên ngắn, ghi bằng ngày, giờ cụ thể và phù hợp khối lượng giao dịch; đây là thời hạn quản lý do hiệu trưởng đặt ra.

**3. Thông tin rõ cho phụ huynh, không để phụ huynh phải nộp hai lần**

Nhà trường gửi thông báo chính thức về tài khoản nhận tiền, tên chủ tài khoản, nội dung chuyển khoản và đầu mối kế toán hỗ trợ.

Đối với phụ huynh đã chuyển vào tài khoản giáo viên, đề nghị cung cấp chứng từ để đối chiếu; **không yêu cầu nộp lại khoản đang được xác minh, không ngừng suất ăn của trẻ vì sai sót trong tổ chức thu**. Nhà trường chủ động xử lý dòng tiền để duy trì bữa ăn.

Khi trao đổi, cần nhận trách nhiệm kiểm tra và khắc phục của nhà trường; tránh đưa tên giáo viên lên nhóm phụ huynh để phê bình hoặc công bố nhận định chưa được xác minh.

**4. Xử lý giáo viên theo kết quả xác minh**

| Kết quả xác minh | Hướng xử lý |
|---|---|
| Thu sai quy trình, đã bàn giao đầy đủ, hợp tác xác minh | Ghi nhận vi phạm, yêu cầu khắc phục và xem xét trách nhiệm theo quy định; không bỏ qua chỉ vì “không mất tiền” |
| Giữ tiền kéo dài, không bàn giao đúng hạn hoặc tái diễn sau nhắc nhở | Làm rõ mức độ lỗi, hậu quả; xem xét xử lý theo thẩm quyền và đúng thủ tục |
| Sử dụng tiền cho cá nhân, che giấu, cung cấp thông tin sai hoặc không hoàn trả | Bảo toàn hồ sơ, yêu cầu khắc phục; báo cáo cơ quan quản lý và chuyển cơ quan có thẩm quyền khi có dấu hiệu vi phạm pháp luật |

Không nên ấn định ngay “khiển trách” hay “cảnh cáo” khi chưa có hồ sơ xác minh. Nếu giáo viên là viên chức trường công lập, cần đối chiếu quy định xử lý kỷ luật viên chức và các văn bản sửa đổi còn hiệu lực tại thời điểm quyết định; nếu là người lao động theo hợp đồng, áp dụng quy định lao động tương ứng. Nghị định 112/2020/NĐ-CP và Nghị định 71/2023/NĐ-CP là các văn bản cần đối chiếu đối với viên chức. https://congbao.chinhphu.vn/van-ban/nghi-dinh-so-71-2023-nd-cp-40132.htm
https://congbao.chinhphu.vn/van-ban/nghi-dinh-so-71-2023-nd-cp-40132.htm?utm_source=chatgpt.com
https://vanban.chinhphu.vn/?docid=201042&pageid=27160
https://vanban.chinhphu.vn/?docid=201042&pageid=27160&utm_source=chatgpt.com

**Việc nộp lại đủ tiền là khắc phục hậu quả, không tự động xóa trách nhiệm.** Ngược lại, hiệu trưởng cũng không phạt tiền hoặc tự ý trừ lương để thay cho việc xử lý đúng quy định.

**5. Rà soát trách nhiệm quản lý và khóa lại quy trình thu**

Hiệu trưởng cần kiểm tra: tài khoản trường đã được thông báo rõ chưa, giáo viên đã được phổ biến quy trình chưa, kế toán có đối chiếu định kỳ không, có tồn tại cách thu tương tự ở lớp khác không.

Sau đó thống nhất:

- Nhà trường phát hành thông báo thu và mã QR chính thức.
- Kế toán theo dõi, xác nhận khoản nộp và xử lý chênh lệch.
- Giáo viên phối hợp nhắc phụ huynh, không nhận tiền vào tài khoản cá nhân.
- Trường hợp phụ huynh gặp khó khăn khi chuyển khoản phải liên hệ bộ phận được trường giao nhiệm vụ thu, thực hiện theo quy trình có chứng từ.

Chị có thể nói rõ trong buổi làm việc:

> “Nhà trường yêu cầu cô dừng ngay việc nhận tiền ăn của trẻ vào tài khoản cá nhân. Cô có trách nhiệm cung cấp đầy đủ danh sách, chứng từ và phối hợp với kế toán đối chiếu, bàn giao toàn bộ khoản còn giữ theo thời hạn ghi trong biên bản. Nhà trường sẽ xem xét trách nhiệm trên cơ sở kết quả xác minh, mức độ vi phạm và việc khắc phục. Quyền lợi ăn bán trú của trẻ phải được bảo đảm trong suốt quá trình xử lý.”

Cách xử lý này vừa thể hiện sự nghiêm túc trong quản lý tài chính, vừa công bằng với giáo viên và bảo vệ được niềm tin của phụ huynh.

---

USER

tôi đã bảo cô ấy viết bảng tường trình sự việc tuy nhiên tôi lại nhận phản ánh gv đó lại tiếp tục nhận khoản tiền khác. bạn hướng tôi cách giải quyết trước khi trình bày  với hiệu trưởng

---

ASSISTANT

**Chị nên báo cáo sớm với Hiệu trưởng, đồng thời xác minh khoản tiền mới và đề nghị giáo viên dừng nhận các khoản thu của trường qua tài khoản cá nhân.** Không cần đợi giáo viên hoàn thành bản tường trình mới báo cáo, vì đã xuất hiện thông tin về một giao dịch khác.

Điểm cần làm rõ là: **khoản tiền mới có thuộc khoản thu của trường không, giao dịch phát sinh khi nào và trước đó giáo viên đã được yêu cầu dừng nhận tiền hay mới chỉ được yêu cầu viết tường trình.** Những chi tiết này quyết định cách nhận định trách nhiệm.

**1. Kiểm tra nhanh thông tin phản ánh**

Chị trao đổi riêng với người phản ánh, đề nghị cung cấp chứng từ hoặc tin nhắn liên quan để xác định:

- Khoản tiền gì, bao nhiêu, của phụ huynh nào?
- Tiền chuyển vào tài khoản nào, thời điểm nào?
- Giáo viên chủ động hướng dẫn chuyển tiền hay phụ huynh tự chuyển theo thông tin cũ?
- Tiền đã được chuyển về trường chưa?

Chỉ ghi nhận những gì có căn cứ. Nếu chưa có chứng từ, ghi rõ **“thông tin phản ánh đang được xác minh”**, chưa kết luận giáo viên tiếp tục vi phạm.

**2. Làm việc riêng với giáo viên, ghi nhận bằng biên bản**

Trong phạm vi nhiệm vụ được giao, chị mời giáo viên làm việc, có kế toán hoặc người phụ trách thu cùng tham gia. Nội dung cần ngắn gọn:

> “Trước đó, tôi đã yêu cầu cô tường trình việc nhận tiền ăn vào tài khoản cá nhân. Hiện tôi tiếp nhận thêm phản ánh về một khoản tiền khác chuyển vào tài khoản của cô. Đề nghị cô làm rõ khoản tiền, thời điểm nhận, lý do nhận và tình trạng bàn giao. Đồng thời, cô cần kê khai đầy đủ các khoản thu của trường đã nhận qua tài khoản cá nhân để nhà trường đối chiếu.”

Yêu cầu giáo viên bổ sung nội dung này vào tường trình, nộp kèm bảng kê và chứng từ liên quan, có thời hạn cụ thể. Không yêu cầu viết theo nhận định có sẵn của người quản lý.

**Nếu lần trước chị chỉ yêu cầu tường trình mà chưa yêu cầu dừng thu, không nên ghi “cố tình không chấp hành chỉ đạo”.** Khi đó, cần ghi đúng diễn biến: sau khi được yêu cầu giải trình sự việc trước, tiếp tục phát sinh giao dịch khác cần làm rõ.

**3. Ngăn phát sinh thêm và phối hợp đối chiếu tiền**

Chị truyền đạt rõ quy trình đã được trường quy định: các khoản phải nộp vào tài khoản trường thì giáo viên không được hướng dẫn phụ huynh chuyển vào tài khoản cá nhân.

Nếu phụ huynh vẫn tự chuyển theo thông tin cũ, giáo viên phải báo ngay cho kế toán để xử lý có chứng từ, không tự giữ hoặc tự sử dụng. Chị phối hợp kế toán đối chiếu từng khoản; tránh chỉ nhận một khoản chuyển gộp mà không biết tiền của trẻ nào, thu cho nội dung gì.

Nếu việc ra chỉ đạo này ngoài thẩm quyền của chị, **đề nghị Hiệu trưởng chỉ đạo ngay**, không tự quyết định hình thức xử lý giáo viên.

**4. Báo cáo Hiệu trưởng bằng diễn biến và chứng cứ**

Chị chuẩn bị một bản báo cáo ngắn, kèm tài liệu hiện có, trình bày theo bốn ý:

| Nội dung | Cách trình bày |
|---|---|
| Sự việc ban đầu | Phát hiện ngày nào, khoản thu gì, đã xác minh đến đâu |
| Việc chị đã thực hiện | Yêu cầu tường trình ngày nào; đã yêu cầu dừng nhận tiền hay chưa |
| Thông tin phát sinh | Khoản tiền mới, thời điểm, chứng cứ; nội dung còn chưa rõ |
| Đề xuất | Chỉ đạo dừng nhận tiền sai tài khoản, giao kế toán đối chiếu toàn bộ, yêu cầu bàn giao và xem xét trách nhiệm sau xác minh |

Chị có thể trình bày trực tiếp:

> “Báo cáo Hiệu trưởng, sau khi tôi yêu cầu cô … viết tường trình về việc nhận tiền ăn của trẻ vào tài khoản cá nhân, tôi tiếp nhận thêm phản ánh về một khoản tiền khác. Qua kiểm tra bước đầu, đã xác định …; còn nội dung … đang xác minh. Tôi đã thực hiện … trong phạm vi nhiệm vụ được giao. Tôi xin báo cáo ngay và đề nghị Hiệu trưởng chỉ đạo đối chiếu toàn bộ khoản đã nhận, chấm dứt việc nhận tiền sai tài khoản, yêu cầu bàn giao đầy đủ và xem xét trách nhiệm trên cơ sở hồ sơ xác minh.”

**Điều quan trọng lúc này là báo cáo kịp thời, ghi đúng việc đã làm và kiểm soát đầy đủ dòng tiền.** Chị không nên tự giải quyết bằng một lần nhắc nhở tiếp theo rồi chờ xem giáo viên có thực hiện hay không.

---

