USER

với vai trò bí thư bạn soạn giúp mình chương tri2nhkie63m điểm, đánh giá xếp loại 2026 đúng nội dung, phù hợp không tự ý thêm bớt

---

ASSISTANT

Tôi sẽ bám sát Kế hoạch số 122-KH/ĐU ngày 16/10/2026 của Đảng ủy phường An Bình để soạn chương trình hội nghị dành cho chi bộ, phân biệt nội dung kiểm điểm với đánh giá, xếp loại và không tự đặt thêm thủ tục ngoài căn cứ được cung cấp.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Căn cứ **Kế hoạch số 122-KH/ĐU ngày 16/10/2026 của Ban Thường vụ Đảng ủy phường An Bình** mà bạn cung cấp, tôi soạn chương trình hội nghị kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 dành cho chi bộ.

Tôi lưu ý ba nội dung để tránh sai sót: **chi ủy là đối tượng kiểm điểm tập thể (đối với chi bộ có chi ủy); đảng viên kiểm điểm tại chi bộ; chi bộ là đối tượng đánh giá, xếp loại chất lượng**. Việc kiểm điểm tập thể thực hiện trước kiểm điểm cá nhân, còn đánh giá, xếp loại chi bộ phải căn cứ kết quả đánh giá các đối tượng liên quan theo quy định. [Quy định 366\-QĐ/TW 2025 đánh giá xếp loại chất lượng tập thể hệ thống chính trị](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Quy-dinh-366-QD-TW-2025-danh-gia-xep-loai-chat-luong-tap-the-he-thong-chinh-tri-673375.aspx>); [Quy định 366\-QĐ/TW 2025 đánh giá xếp loại chất lượng tập thể hệ thống chính trị](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Quy-dinh-366-QD-TW-2025-danh-gia-xep-loai-chat-luong-tap-the-he-thong-chinh-tri-673375.aspx>); [Hướng dẫn 43\-HD/BTCTW về kiểm điểm và đánh giá, xếp loại chất lượng tập thể, cá nhân trong hệ thống \.\.\.](<https://laichau.gov.vn/tin-tuc-su-kien/chuyen-de/tin-trong-nuoc/huong-dan-43-hd-btctw-ve-kiem-diem-va-danh-gia-xep-loai-chat-luong-tap-the-ca-nhan-trong-he-thong-chinh-tri.html>)

Dưới đây là chương trình theo trình tự tổ chức hội nghị, không tự đặt thêm tiêu chí, mức xếp loại hoặc thủ tục bỏ phiếu chưa được hướng dẫn.

> **writing · document**
>
> **ĐẢNG ỦY [CẤP TRÊN TRỰC TIẾP]**  
> **CHI BỘ [TÊN CHI BỘ]**  
> *  
> **ĐẢNG CỘNG SẢN VIỆT NAM**
>
> *[Địa danh], ngày ... tháng 11 năm 2026*
>
> # CHƯƠNG TRÌNH
> **Hội nghị kiểm điểm, đánh giá, xếp loại chất lượng tập thể, cá nhân năm 2026**
>
> ---
>
> **Thời gian:** ... giờ ... phút, ngày ... tháng 11 năm 2026.
>
> **Địa điểm:** ......................................
>
> **Thành phần:** Đảng viên thuộc diện kiểm điểm, đánh giá, xếp loại của chi bộ; đại diện cấp ủy cấp trên được phân công dự, chỉ đạo (nếu có).
>
> **Chủ trì:** Đồng chí ......................................, Bí thư Chi bộ.
>
> **Thư ký:** Đồng chí ......................................
>
> ## I. KIỂM ĐIỂM, TỰ ĐÁNH GIÁ, XẾP LOẠI TẬP THỂ CHI ỦY (ĐỐI VỚI CHI BỘ CÓ CHI ỦY)
>
> **1.** Đồng chí Bí thư Chi bộ thông qua mục đích, yêu cầu, nội dung kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 theo Kế hoạch số 122-KH/ĐU, ngày 16/10/2026 của Ban Thường vụ Đảng ủy phường An Bình và các văn bản hướng dẫn có liên quan.
>
> **2.** Đồng chí Bí thư Chi bộ trình bày báo cáo kiểm điểm tập thể chi ủy năm 2026; báo cáo kết quả tự đánh giá theo các tiêu chí quy định.
>
> **3.** Các đồng chí chi ủy viên tham gia góp ý đối với báo cáo kiểm điểm tập thể chi ủy; tập trung làm rõ ưu điểm, hạn chế, khuyết điểm, nguyên nhân, trách nhiệm và biện pháp khắc phục.
>
> **4.** Đồng chí Bí thư Chi bộ tiếp thu, giải trình các ý kiến góp ý; kết luận nội dung kiểm điểm tập thể chi ủy.
>
> **5.** Chi ủy thực hiện tự đánh giá, đề xuất mức xếp loại chất lượng tập thể chi ủy năm 2026 theo quy trình, tiêu chí và thẩm quyền quy định.
>
> ## II. HỘI NGHỊ CHI BỘ KIỂM ĐIỂM, ĐÁNH GIÁ, XẾP LOẠI CHẤT LƯỢNG ĐẢNG VIÊN VÀ CHI BỘ NĂM 2026
>
> **1. Ổn định tổ chức, khai mạc hội nghị**
>
> - Tuyên bố lý do, giới thiệu đại biểu (nếu có).
> - Báo cáo số lượng đảng viên tham dự hội nghị.
> - Thông qua chương trình hội nghị.
>
> **2. Quán triệt mục đích, yêu cầu kiểm điểm, đánh giá, xếp loại**
>
> Đồng chí Bí thư Chi bộ quán triệt các nội dung, yêu cầu về kiểm điểm tự phê bình và phê bình; đánh giá, xếp loại chất lượng tập thể, cá nhân năm 2026 theo Kế hoạch số 122-KH/ĐU và hướng dẫn của cấp trên.
>
> **3. Tiến hành kiểm điểm cá nhân đảng viên năm 2026**
>
> Thực hiện kiểm điểm lần lượt:
>
> - Đồng chí Bí thư Chi bộ.
> - Đồng chí Phó Bí thư Chi bộ (nếu có).
> - Các đồng chí chi ủy viên (nếu có).
> - Các đồng chí đảng viên còn lại thuộc diện kiểm điểm.
>
> Đối với từng cá nhân:
>
> - Cá nhân trình bày bản tự kiểm điểm năm 2026.
> - Các đảng viên tham gia nhận xét, góp ý.
> - Cá nhân tiếp thu, giải trình ý kiến góp ý.
> - Đồng chí chủ trì kết luận nội dung kiểm điểm của cá nhân.
>
> **4. Đánh giá, đề xuất xếp loại chất lượng đảng viên năm 2026**
>
> - Từng đảng viên báo cáo kết quả tự đánh giá, đề xuất mức xếp loại chất lượng năm 2026.
> - Chi bộ thảo luận, nhận xét, đánh giá trên cơ sở kết quả kiểm điểm, thực hiện nhiệm vụ và các tiêu chí quy định.
> - Thực hiện việc đánh giá, đề xuất xếp loại chất lượng đảng viên theo quy trình và hướng dẫn của cấp có thẩm quyền.
> - Tổng hợp kết quả đề xuất xếp loại chất lượng đảng viên năm 2026.
>
> **5. Đánh giá, đề xuất xếp loại chất lượng chi bộ năm 2026**
>
> - Chi ủy báo cáo kết quả tự đánh giá, đề xuất mức xếp loại chất lượng chi bộ năm 2026. Đối với chi bộ không có chi ủy, thực hiện việc tự đánh giá theo quy định.
> - Hội nghị thảo luận, góp ý kết quả tự đánh giá chất lượng chi bộ.
> - Hoàn thiện kết quả tự đánh giá, đề xuất mức xếp loại chất lượng chi bộ năm 2026 để báo cáo cấp có thẩm quyền xem xét, quyết định.
>
> **6. Phát biểu của đại diện cấp ủy cấp trên**
>
> Đại diện cấp ủy cấp trên được phân công dự, chỉ đạo hội nghị phát biểu ý kiến (nếu có).
>
> **7. Thông qua kết quả hội nghị**
>
> - Thư ký báo cáo biên bản hội nghị kiểm điểm.
> - Báo cáo kết quả kiểm phiếu theo quy trình được hướng dẫn (nếu có).
> - Hội nghị thống nhất nội dung biên bản và các kết quả đề xuất báo cáo cấp trên.
>
> **8. Kết luận, bế mạc hội nghị**
>
> Đồng chí Bí thư Chi bộ:
>
> - Nhận xét, đánh giá chung về kết quả hội nghị kiểm điểm, đánh giá, xếp loại chất lượng năm 2026.
> - Yêu cầu tập thể, cá nhân tiếp thu ý kiến góp ý, bổ sung, hoàn thiện bản kiểm điểm; xác định biện pháp khắc phục hạn chế, khuyết điểm.
> - Phân công hoàn thiện hồ sơ kiểm điểm, đánh giá, xếp loại và gửi cấp trên theo quy định.
> - Tuyên bố bế mạc hội nghị.
>
> **CHI BỘ [TÊN CHI BỘ]**

## Những điểm cần lưu ý trước khi tổ chức

Theo Kế hoạch số 122-KH/ĐU, có ba mốc cần thực hiện đúng:

| Nội dung | Thời hạn |
|--------|--------|
| Báo cáo thời gian tổ chức kiểm điểm về Ban Thường vụ Đảng ủy qua Ban Xây dựng Đảng | Chậm nhất ngày **09/11/2026** |
| Hoàn thành kiểm điểm, đánh giá, xếp loại đối với chi ủy, chi bộ thuộc đối tượng quy định | Chậm nhất ngày **13/11/2026** |
| Gửi hồ sơ thuộc diện quy định tại Mục IV.3 về Ban Xây dựng Đảng | Trong **03 ngày làm việc** sau khi hoàn thành |

**Lưu ý nghiệp vụ:** Kế hoạch số 122-KH/ĐU dẫn chiếu Quy định số 04-QĐ/ĐU ngày 14/11/2025, Hướng dẫn số 01-HD/BTCTU ngày 13/11/2025 và giao Ban Xây dựng Đảng cụ thể hóa chương trình, quy trình đánh giá, xếp loại. Do chưa có đầy đủ những tài liệu này, tôi không tự quy định cách bỏ phiếu, tỷ lệ phiếu hoặc biểu mẫu riêng cho chi bộ.

Bản trên là **dự thảo chương trình điều hành**, đã bám sát đối tượng, trình tự và nội dung trong kế hoạch được cung cấp. Trước khi sử dụng chính thức, cần đối chiếu chương trình mẫu và hướng dẫn cụ thể do Ban Xây dựng Đảng phường ban hành, nếu có.

---

USER

chương trính t63ng không pahi3 chi tiết

---

ASSISTANT

> **writing · document**
>
> **ĐẢNG ỦY PHƯỜNG AN BÌNH**  
> **CHI BỘ ................................**  
> *  
> **ĐẢNG CỘNG SẢN VIỆT NAM**
>
> # CHƯƠNG TRÌNH
> **Hội nghị kiểm điểm, đánh giá, xếp loại chất lượng tập thể, cá nhân năm 2026**
>
> **Thời gian:** ..............................................
>
> **Địa điểm:** ...............................................
>
> **Chủ trì:** Đồng chí Bí thư Chi bộ.
>
> **NỘI DUNG CHƯƠNG TRÌNH**
>
> 1. Tuyên bố lý do, giới thiệu đại biểu; thông qua chương trình hội nghị.
>
> 2. Kiểm điểm tập thể chi ủy năm 2026 (đối với chi bộ có chi ủy).
>
> 3. Kiểm điểm cá nhân đảng viên năm 2026.
>
> 4. Đánh giá, đề xuất xếp loại chất lượng đảng viên năm 2026.
>
> 5. Đánh giá, đề xuất xếp loại chất lượng chi bộ năm 2026.
>
> 6. Phát biểu chỉ đạo của đại diện cấp ủy cấp trên (nếu có).
>
> 7. Kết luận và bế mạc hội nghị.

Đây là **chương trình tổng quát**, chỉ nêu các nội dung chính để thông qua tại hội nghị, không đi vào trình tự điều hành từng nội dung.

Chương trình được xây dựng trên cơ sở Kế hoạch số 122-KH/ĐU ngày 16/10/2026. Trình tự cụ thể cần đối chiếu hướng dẫn của Ban Xây dựng Đảng phường trước khi sử dụng chính thức.

---

