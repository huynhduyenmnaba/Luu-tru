USER

DỰA VÀO NỘI DUNG NÀY với vai trò bí thư chi bộ bạn giúp tôi liệt kê các đầu việc để phân công thực hiện tổ chức Hội nghị kiểm điểm theo đúng uy định

---

ASSISTANT

Tôi sẽ chuyển hướng dẫn đính kèm thành bảng phân công công việc theo ba giai đoạn: trước, trong và sau hội nghị; xác định người phụ trách, thời hạn và hồ sơ đầu ra. Tôi cũng sẽ lưu ý các mốc thời gian và khâu dễ sai về trình tự, biểu quyết.

---

ASSISTANT

---

ASSISTANT

# BẢNG DANH MỤC CÔNG VIỆC VÀ PHÂN CÔNG NHIỆM VỤ TỔ CHỨC HỘI NGHỊ KIỂM ĐIỂM, ĐÁNH GIÁ, XẾP LOẠI CHẤT LƯỢNG NĂM 2026

Căn cứ nội dung **Hướng dẫn trình tự kiểm điểm, đánh giá chi ủy, chi bộ, đảng viên** mà đồng chí cung cấp, dưới góc độ Bí thư Chi bộ, tôi đề xuất xây dựng bảng phân công theo nguyên tắc: **Rõ việc – Rõ người – Rõ thời hạn – Rõ sản phẩm – Rõ trách nhiệm kiểm tra.**

Toàn bộ công việc được chia thành 3 giai đoạn:

1. **Trước hội nghị:** Chuẩn bị nội dung, hồ sơ, nhân sự, biểu mẫu và điều kiện tổ chức.
2. **Trong hội nghị:** Điều hành kiểm điểm, thảo luận, bỏ phiếu, tổng hợp kết quả và kết luận.
3. **Sau hội nghị:** Hoàn chỉnh hồ sơ, báo cáo cấp trên, lưu trữ và theo dõi khắc phục hạn chế.

## I. Các mốc thời gian phải bảo đảm

Theo tài liệu hướng dẫn đã cung cấp:

| Nội dung | Thời hạn |
|--------|--------|
| Báo cáo lịch tổ chức hội nghị về Đảng ủy trường | Chậm nhất **09/11/2026** |
| Lấy ý kiến đối với dự thảo báo cáo tập thể Mẫu 01A | Trước hội nghị ít nhất **05 ngày** |
| Gửi dự thảo cho người dự họp | Trước hội nghị ít nhất **03 ngày làm việc** |
| Hoàn thành kiểm điểm, đánh giá, đề nghị xếp loại | Chậm nhất **13/11/2026** |
| Nộp hồ sơ thuộc diện Ban Thường vụ Đảng ủy phường quản lý | Trong **03 ngày làm việc** sau khi hoàn thành, theo Kế hoạch 122 |

**Đề xuất điều hành:** Nếu tổ chức hội nghị ngày **13/11/2026**, nên triển khai lấy ý kiến dự thảo từ ngày **06/11/2026**, gửi tài liệu cho người dự họp chậm nhất ngày **09/11/2026**. Cách bố trí này tạo khoảng thời gian dự phòng để bảo đảm yêu cầu của hướng dẫn.

## II. Bảng phân công nhiệm vụ cụ thể

Các thời hạn dưới đây là **mốc đề xuất** trên cơ sở dự kiến tổ chức hội nghị ngày 13/11/2026. Người phụ trách được xác định theo chức trách, đồng chí có thể thay bằng họ tên cụ thể khi giao nhiệm vụ.

### A. Giai đoạn 1 – Công việc chuẩn bị trước hội nghị

| STT | Nội dung công việc cần thực hiện | Người chủ trì/phụ trách đề xuất | Hạn hoàn thành |
|--------|--------|--------|--------|
| 1 | Họp chi ủy thống nhất kế hoạch tổ chức hội nghị, nội dung, tiến độ và phân công từng đồng chí phụ trách | Bí thư Chi bộ | 05–06/11 |
| 2 | Xây dựng chương trình hội nghị; xác định thời gian, địa điểm, thành phần tham dự | Phó Bí thư | 06/11 |
| 3 | Báo cáo thời gian tổ chức hội nghị với Đảng ủy trường; liên hệ mời cấp ủy viên cấp trên phụ trách giám sát | Bí thư Chi bộ | Chậm nhất 09/11 |
| 4 | Rà soát danh sách đảng viên thuộc diện kiểm điểm, đánh giá, xếp loại; xác định thành phần được biểu quyết và các trường hợp đặc thù | Chi ủy viên phụ trách tổ chức | 06–09/11 |
| 5 | Xây dựng báo cáo kiểm điểm tập thể Mẫu 01A và biểu tự chấm điểm của tập thể theo đối tượng áp dụng | Bí thư chủ trì, chi ủy phối hợp | 06/11 |
| 6 | Tổ chức lấy ý kiến góp ý đối với dự thảo báo cáo kiểm điểm tập thể, bảo đảm trước hội nghị ít nhất 05 ngày | Phó Bí thư | Từ 06/11 |
| 7 | Tổng hợp ý kiến góp ý, tiếp thu và gửi dự thảo cho người dự họp trước ít nhất 03 ngày làm việc | Phó Bí thư, người phụ trách hồ sơ | Chậm nhất 09/11 |
| 8 | Hướng dẫn đảng viên viết bản kiểm điểm Mẫu 02A hoặc 02B, tự chấm điểm theo biểu mẫu tương ứng | Phó Bí thư | 06/11 |
| 9 | Đôn đốc thu nhận bản kiểm điểm cá nhân, nhận xét nơi cư trú, minh chứng, ý kiến góp ý hoặc gợi ý kiểm điểm (nếu có) | Chi ủy viên phụ trách tổ chức | 10/11 |
| 10 | Rà soát nội dung, thành phần và tính đầy đủ của hồ sơ kiểm điểm cá nhân; thông báo cá nhân bổ sung hồ sơ còn thiếu | Chi ủy viên phụ trách tổ chức | 11/11 |
| 11 | Tổng hợp kết quả tự chấm điểm của đảng viên, ý kiến nơi cư trú và các tài liệu liên quan để phục vụ thảo luận, đề nghị xếp loại | Phó Bí thư | 12/11 |
| 12 | Chuẩn bị Mẫu 03 tóm tắt ưu điểm, khuyết điểm theo hướng dẫn | Người phụ trách hồ sơ | 12/11 |
| 13 | In phiếu kín Mẫu 08C để đề nghị xếp loại đảng viên và Mẫu 08A-P1 để đề nghị xếp loại chi bộ, chi ủy (nếu có) | Người phụ trách hồ sơ | 12/11 |
| 14 | Chuẩn bị danh sách tham dự, danh sách phát phiếu, mẫu biên bản hội nghị, biên bản kiểm phiếu và bảng tổng hợp kết quả bỏ phiếu | Người phụ trách hồ sơ | 12/11 |
| 15 | Dự kiến nhân sự thư ký hội nghị và tổ kiểm phiếu để trình hội nghị xem xét, thống nhất | Bí thư Chi bộ | 12/11 |
| 16 | Xây dựng kịch bản điều hành chi tiết; phân công Phó Bí thư điều hành phần kiểm điểm cá nhân Bí thư | Bí thư, Phó Bí thư | 12/11 |
| 17 | Chuẩn bị phòng họp, tài liệu, thiết bị, hòm phiếu, điều kiện bảo đảm cho hội nghị | Đảng viên được phân công hậu cần | 12/11 |
| 18 | Kiểm tra lần cuối toàn bộ tài liệu, biểu mẫu, danh sách, hồ sơ và các điều kiện trước hội nghị | Bí thư Chi bộ | 12/11 |

**Sản phẩm cần có trước hội nghị:** Chương trình, danh sách tham dự và biểu quyết, Mẫu 01A, bản kiểm điểm cá nhân Mẫu 02A/02B, biểu tự chấm điểm, Mẫu 03, phiếu 08A-P1 và 08C, tài liệu minh chứng và các biểu mẫu biên bản cần thiết.

### B. Giai đoạn 2 – Công việc thực hiện trong hội nghị

| STT | Nội dung công việc | Người thực hiện | Sản phẩm/kết quả |
|--------|--------|--------|--------|
| 19 | Khai mạc, giới thiệu đại biểu, thông qua chương trình, số đảng viên có mặt/vắng mặt, thành phần biểu quyết và cử thư ký | Bí thư Chi bộ | Chương trình và thành phần được xác nhận |
| 20 | Trình bày báo cáo kiểm điểm tập thể chi ủy (nếu có), tổ chức góp ý, giải trình, kết luận và giao hoàn thiện | Bí thư điều hành, chi ủy tham gia | Ý kiến kiểm điểm và kết luận đối với tập thể |
| 21 | Tổ chức kiểm điểm cá nhân theo thứ tự: Bí thư, Phó Bí thư, chi ủy viên, đảng viên còn lại; từng người trình bày, tập thể góp ý, cá nhân giải trình và chủ trì kết luận | Bí thư, Phó Bí thư điều hành theo phân công | Nội dung kiểm điểm, góp ý và kết luận từng cá nhân |
| 22 | Tổng hợp, trình bày mức tự chấm điểm và đề xuất xếp loại từng đảng viên; tổ chức thảo luận và bỏ phiếu kín Mẫu 08C | Người chủ trì, tổ kiểm phiếu | Phiếu đề nghị xếp loại đảng viên |
| 23 | Kiểm phiếu, lập biên bản, công bố số phiếu và mức đề nghị xếp loại từng đảng viên | Tổ kiểm phiếu | Biên bản và bảng tổng hợp kiểm phiếu |
| 24 | Thảo luận tiêu chí, điểm số, tổng điểm và mức tự nhận của tổ chức đảng; bỏ phiếu kín Mẫu 08A-P1, đề nghị xếp loại chi bộ trước, chi ủy sau (nếu có) | Bí thư chủ trì, tổ kiểm phiếu thực hiện | Kết quả đề nghị xếp loại tổ chức đảng và biên bản kiểm phiếu |
| 25 | Tiếp thu ý kiến đại biểu cấp trên (nếu có), kết luận chung, phân công hoàn thiện hồ sơ, thông qua biên bản và bế mạc | Bí thư, thư ký hội nghị | Kết luận hội nghị, biên bản được hoàn thiện |

**Yêu cầu Bí thư cần kiểm soát:** Hội nghị phải có thời gian thực chất cho tự phê bình và phê bình; mỗi cá nhân được trình bày, giải trình và tiếp thu đầy đủ; việc bỏ phiếu phải đúng đối tượng, đúng mẫu và có biên bản kiểm phiếu.

### C. Giai đoạn 3 – Công việc sau hội nghị

| STT | Nội dung công việc | Người thực hiện | Thời gian đề xuất |
|--------|--------|--------|--------|
| 26 | Tiếp thu ý kiến góp ý, chỉnh sửa, hoàn thiện và ký bản kiểm điểm cá nhân, biểu chấm điểm cùng hồ sơ liên quan | Từng đảng viên | Ngay sau hội nghị |
| 27 | Hoàn thiện biên bản hội nghị, biên bản kiểm phiếu, danh sách kết quả bỏ phiếu | Thư ký, tổ kiểm phiếu | Ngay sau hội nghị |
| 28 | Hoàn thiện báo cáo tập thể, Mẫu 03 và tổng hợp hồ sơ, biểu chấm điểm, tài liệu của tập thể và cá nhân | Phó Bí thư, người phụ trách hồ sơ | Sau hội nghị, trước hạn nộp |
| 29 | Kiểm tra, ký và gửi hồ sơ đề nghị xếp loại đến đúng cơ quan có thẩm quyền theo phân cấp | Bí thư Chi bộ | Theo hạn cấp trên quy định |
| 30 | Lưu trữ hồ sơ; lập danh mục các hạn chế, khuyết điểm, phân công trách nhiệm khắc phục và theo dõi kết quả thực hiện | Bí thư chủ trì, chi ủy phối hợp | Sau hội nghị |

Đối với công việc số 30, đây là **đề xuất quản lý sau kiểm điểm** nhằm bảo đảm kết quả kiểm điểm được chuyển thành nhiệm vụ khắc phục cụ thể, không chỉ dừng lại ở hồ sơ hành chính.

## III. Phân công theo từng vị trí để Bí thư dễ giao nhiệm vụ

| Vị trí | Nhóm nhiệm vụ trọng tâm |
|--------|--------|
| **Bí thư Chi bộ** | Chỉ đạo chung; xây dựng báo cáo tập thể; thông báo cấp trên; chủ trì hội nghị; kết luận kiểm điểm; kiểm tra, ký hồ sơ |
| **Phó Bí thư** | Tham mưu chương trình, lịch họp; tổ chức lấy ý kiến; hướng dẫn đảng viên; tổng hợp chấm điểm; điều hành kiểm điểm Bí thư; phối hợp hoàn chỉnh hồ sơ |
| **Chi ủy viên phụ trách tổ chức (nếu có)** | Rà soát danh sách, đối tượng kiểm điểm; đôn đốc, thu nhận hồ sơ; chuẩn bị mẫu biểu và danh sách phát phiếu |
| **Thư ký hội nghị** | Ghi biên bản đầy đủ, chính xác; tổng hợp ý kiến; hoàn thiện biên bản và tài liệu hội nghị |
| **Tổ kiểm phiếu** | Phát, thu, kiểm phiếu; lập biên bản kiểm phiếu; báo cáo kết quả |
| **Từng đảng viên** | Chuẩn bị bản kiểm điểm, tự chấm điểm, minh chứng; tham gia góp ý, kiểm điểm; hoàn thiện và ký hồ sơ cá nhân |
| **Đảng viên phụ trách hậu cần** | Bố trí địa điểm, tài liệu, thiết bị, hòm phiếu và điều kiện phục vụ hội nghị |

Các vị trí thư ký, tổ kiểm phiếu cần được xác lập tại hội nghị theo trình tự của hướng dẫn. Việc phân công chuẩn bị trước là để chủ động tổ chức, không thay thế thủ tục tại hội nghị.

## IV. Những nội dung Bí thư phải kiểm tra để tránh sai sót

**1. Đúng đối tượng, thành phần biểu quyết**

Hướng dẫn xác định thành phần biểu quyết đề nghị xếp loại đảng viên không gồm đảng viên dự bị. Các trường hợp miễn sinh hoạt, đình chỉ, mới kết nạp chưa đủ 06 tháng phải đối chiếu Kế hoạch 122.

---

**2. Đúng thứ tự kiểm điểm**

Kiểm điểm tập thể chi ủy (nếu có), sau đó kiểm điểm cá nhân; thực hiện các nội dung đánh giá, đề nghị xếp loại theo trình tự trong hướng dẫn. Phó Bí thư được phân công điều hành khi kiểm điểm Bí thư.

---

**3. Đúng mẫu phiếu và cách biểu quyết**

Sử dụng Mẫu 08C và 08A-P1, không tự thiết kế mẫu khác. Đối với đề nghị xếp loại tổ chức đảng, hướng dẫn nêu yêu cầu trên 50% thành viên dự hội nghị đồng ý.

---

**4. Đúng thẩm quyền xếp loại**

Mức biểu quyết tại hội nghị là mức đề nghị, không được công bố là kết quả xếp loại chính thức khi cấp có thẩm quyền chưa quyết định.

---

**5. Đúng yêu cầu riêng của năm 2026**

Theo tài liệu đã gửi, không tổ chức đánh giá, đề xuất xếp loại quý IV riêng; kết quả thực hiện nhiệm vụ quý IV được sử dụng làm căn cứ đánh giá cuối năm.

**Lưu ý về căn cứ:** Bảng phân công trên được xây dựng trực tiếp từ hướng dẫn đính kèm. Tôi chưa có bản đầy đủ Kế hoạch 122-KH/ĐU ngày 16/10/2026 và các Phụ lục 01, 04, 06, nên các trường hợp đặc thù, thành phần hồ sơ nộp và biểu mẫu chính thức cần đối chiếu với tài liệu gốc của cấp ủy trước khi triển khai.

## V. Đề xuất cách tổ chức phân công hiệu quả nhất

Với vai trò Bí thư Chi bộ, tôi đề xuất **không giao việc chung chung cho cả chi ủy**, mà xác định một đồng chí chịu trách nhiệm chính đối với mỗi đầu việc và một đồng chí theo dõi tiến độ, kiểm tra kết quả.

Bí thư trực tiếp nắm 5 khâu quan trọng: báo cáo tập thể; đối tượng được kiểm điểm, biểu quyết; trình tự điều hành; kết quả kiểm phiếu; chất lượng và thời hạn hồ sơ gửi cấp trên.

Phó Bí thư làm đầu mối điều phối chuẩn bị và tổng hợp hồ sơ. Chi ủy viên hoặc đảng viên được giao phụ trách hồ sơ theo dõi việc nộp biểu mẫu, phát hiện tài liệu còn thiếu và báo cáo ngay cho Bí thư để xử lý.

**Tóm lại:** Danh mục trên gồm **30 đầu việc**, bao quát toàn bộ quá trình từ chuẩn bị đến hoàn tất hội nghị. Đồng chí có thể sử dụng làm bảng giao nhiệm vụ trong cuộc họp chi ủy; khi triển khai thực tế, chỉ cần bổ sung **họ tên người phụ trách, người phối hợp và tình trạng hoàn thành** cho từng công việc.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

còn hoạt động chụp ảnh, ghi hình

---

ASSISTANT

Đúng vậy, cần bổ sung **công tác chụp ảnh, ghi hình và lưu trữ tư liệu hội nghị** vào bảng phân công nhiệm vụ. Đây là công việc phục vụ công tác thông tin, tuyên truyền, lưu trữ hình ảnh và minh chứng hoạt động của chi bộ.

Tuy nhiên, tài liệu hướng dẫn đồng chí cung cấp chưa quy định đây là nhiệm vụ bắt buộc. Vì vậy, tôi đề xuất bổ sung các đầu việc sau:

## Bổ sung nhóm nhiệm vụ: Chụp ảnh, ghi hình hội nghị

| STT | Nội dung công việc | Người phụ trách đề xuất | Thời gian | Sản phẩm |
|--------|--------|--------|--------|--------|
| 31 | Phân công đảng viên phụ trách chụp ảnh, ghi hình; thống nhất nội dung, phạm vi và thời điểm được ghi hình | Phó Bí thư tham mưu, Bí thư quyết định | Trước hội nghị | Phân công cụ thể |
| 32 | Chuẩn bị máy ảnh, điện thoại, thiết bị ghi hình; kiểm tra pin, dung lượng lưu trữ và vị trí tác nghiệp | Đảng viên phụ trách hình ảnh | Trước hội nghị | Thiết bị sẵn sàng |
| 33 | Chụp ảnh toàn cảnh hội nghị; đại biểu tham dự; phát biểu khai mạc; trình bày báo cáo; một số hoạt động chung phù hợp; phát biểu kết luận và ảnh tập thể nếu tổ chức | Đảng viên phụ trách hình ảnh | Trong hội nghị | Bộ ảnh tư liệu |
| 34 | Ghi hình các nội dung được Bí thư cho phép, phục vụ lưu trữ hoặc xây dựng tin bài nội bộ | Đảng viên phụ trách hình ảnh | Trong hội nghị | Video tư liệu (nếu có) |
| 35 | Lựa chọn, phân loại, đặt tên, lưu trữ hình ảnh, video; dự thảo tin bài nếu được giao và trình duyệt trước khi sử dụng | Đảng viên phụ trách hình ảnh, Phó Bí thư kiểm tra | Sau hội nghị | Thư mục ảnh, video và tin bài (nếu có) |

## Những lưu ý đặc biệt đối với hội nghị kiểm điểm

Với vai trò Bí thư Chi bộ, tôi đề xuất quản lý công tác chụp ảnh, ghi hình chặt chẽ hơn hội nghị thông thường vì có nội dung tự phê bình, phê bình và đánh giá cá nhân.

- **Nên chụp ảnh:** Quang cảnh hội nghị, đại biểu tham dự, khai mạc, báo cáo chung, phát biểu kết luận và ảnh tập thể.
- **Hạn chế ghi hình:** Nội dung kiểm điểm cá nhân, ý kiến phê bình, giải trình và những vấn đề nội bộ nhạy cảm.
- **Không chụp ảnh làm lộ nội dung bỏ phiếu kín**, phiếu đã đánh dấu, thông tin cá nhân hoặc tài liệu thuộc diện bảo mật.
- **Không tự ý phát trực tiếp, đăng tải hoặc cung cấp hình ảnh, video ra bên ngoài** khi chưa được người có thẩm quyền cho phép.
- Việc chụp ảnh, ghi hình không được gây ảnh hưởng đến tính nghiêm túc, dân chủ và chất lượng kiểm điểm.

## Đề xuất phân công phù hợp

Tôi đề xuất giao **01 đảng viên phụ trách công tác thông tin, tuyên truyền hoặc có khả năng chụp ảnh, ghi hình** thực hiện. Phó Bí thư theo dõi, kiểm tra sản phẩm; Bí thư thống nhất phạm vi ghi hình và duyệt nội dung trước khi công bố.

Có thể ghi trong bảng phân công chính thức:

> **Phụ trách công tác hình ảnh, tư liệu hội nghị:** Chuẩn bị thiết bị, chụp ảnh và ghi hình những nội dung được cho phép; lựa chọn, tổng hợp, lưu trữ hình ảnh phục vụ công tác báo cáo, tuyên truyền và lưu hồ sơ hoạt động của chi bộ; bảo đảm không làm lộ thông tin thuộc nội dung kiểm điểm nội bộ.

**Như vậy, bảng phân công được bổ sung thành 35 đầu việc.** Tôi cũng đề xuất bổ sung một cột **“Người phối hợp”** và một cột **“Tình trạng thực hiện”** để Bí thư thuận tiện giao việc, đôn đốc và kiểm tra tiến độ chuẩn bị hội nghị.

---

USER

không thấy nội dung Đảng viên

---

ASSISTANT

Đồng chí nhận xét đúng. Trong bảng phân công trước, tôi mới tập trung vào nhiệm vụ của Bí thư, Phó Bí thư, chi ủy viên và bộ phận phục vụ hội nghị, **chưa xây dựng thành một nhóm nhiệm vụ riêng, đầy đủ cho từng đảng viên trong chi bộ**.

Với vai trò Bí thư Chi bộ, tôi đề xuất bổ sung **Mục D – Nhiệm vụ của đảng viên trong tổ chức Hội nghị kiểm điểm, đánh giá, xếp loại chất lượng năm 2026** như sau:

## D. PHÂN CÔNG NHIỆM VỤ ĐỐI VỚI ĐẢNG VIÊN

| STT | Nội dung công việc | Người thực hiện | Thời gian đề xuất | Sản phẩm/kết quả |
|--------|--------|--------|--------|--------|
| 1 | Nghiên cứu hướng dẫn kiểm điểm, đánh giá, xếp loại chất lượng năm 2026; nắm rõ nội dung, tiêu chí và quy trình thực hiện | Tất cả đảng viên | Trước 07/11 | Nắm vững yêu cầu kiểm điểm |
| 2 | Xây dựng bản kiểm điểm cá nhân theo Mẫu 02A (lãnh đạo, quản lý) hoặc Mẫu 02B (không giữ chức vụ lãnh đạo, quản lý) | Từng đảng viên | Trước 10/11 | Bản kiểm điểm cá nhân |
| 3 | Tự đánh giá, chấm điểm các tiêu chí và xác định mức tự nhận xếp loại theo biểu mẫu tương ứng | Từng đảng viên | Trước 10/11 | Bảng tự chấm điểm |
| 4 | Chuẩn bị minh chứng về kết quả thực hiện nhiệm vụ, trách nhiệm được giao, việc khắc phục hạn chế, khuyết điểm (nếu có) | Từng đảng viên | Trước 10/11 | Tài liệu minh chứng |
| 5 | Chuẩn bị và nộp văn bản nhận xét của cấp ủy nơi cư trú theo yêu cầu; bổ sung ý kiến góp ý, gợi ý kiểm điểm (nếu có) | Từng đảng viên thuộc đối tượng áp dụng | Trước 10/11 | Hồ sơ nhận xét, góp ý |
| 6 | Nghiên cứu dự thảo báo cáo kiểm điểm tập thể chi ủy; tham gia góp ý về kết quả, hạn chế, nguyên nhân và giải pháp khắc phục | Các đảng viên được lấy ý kiến | Theo lịch lấy ý kiến | Ý kiến góp ý tập thể |
| 7 | Tham dự hội nghị đầy đủ, đúng giờ; thực hiện nghiêm túc chương trình, nội quy và các yêu cầu của hội nghị | Tất cả đảng viên thuộc thành phần dự họp | Ngày hội nghị | Tham dự đúng thành phần |
| 8 | Trình bày bản kiểm điểm cá nhân; tiếp thu, giải trình các ý kiến góp ý; làm rõ trách nhiệm và biện pháp khắc phục hạn chế | Từng đảng viên | Trong hội nghị | Nội dung kiểm điểm cá nhân |
| 9 | Tham gia góp ý kiểm điểm đối với các đồng chí trong chi bộ trên tinh thần thẳng thắn, khách quan, xây dựng, đúng nguyên tắc | Đảng viên tham dự | Trong hội nghị | Ý kiến góp ý cụ thể |
| 10 | Tham gia thảo luận, đề nghị xếp loại đảng viên và bỏ phiếu kín Mẫu 08C theo đúng đối tượng được biểu quyết | Đảng viên đủ điều kiện biểu quyết | Trong hội nghị | Phiếu đề nghị xếp loại |
| 11 | Tham gia thảo luận tiêu chí, điểm số, mức tự nhận xếp loại chi bộ, chi ủy (nếu có); thực hiện bỏ phiếu Mẫu 08A-P1 theo đúng thành phần | Đảng viên thuộc thành phần biểu quyết | Trong hội nghị | Phiếu đề nghị xếp loại tổ chức đảng |
| 12 | Tiếp thu ý kiến góp ý, chỉnh sửa, hoàn thiện và ký bản kiểm điểm cá nhân, bảng chấm điểm và hồ sơ liên quan | Từng đảng viên | Sau hội nghị | Hồ sơ cá nhân hoàn chỉnh |
| 13 | Xác định nội dung, biện pháp và thời gian khắc phục những hạn chế, khuyết điểm đã được kết luận hoặc tiếp thu qua kiểm điểm | Từng đảng viên | Sau hội nghị | Nội dung cam kết, kế hoạch khắc phục phù hợp |
| 14 | Thực hiện nhiệm vụ phục vụ hội nghị theo phân công cụ thể của Bí thư hoặc chi ủy | Đảng viên được giao nhiệm vụ | Trước, trong và sau hội nghị | Hoàn thành nhiệm vụ được giao |

## E. Nhiệm vụ riêng của đảng viên được phân công phục vụ hội nghị

Ngoài trách nhiệm kiểm điểm của bản thân, có thể phân công các đảng viên phụ trách những công việc cụ thể sau:

| STT | Nhiệm vụ được giao | Người thực hiện | Kết quả cần đạt |
|--------|--------|--------|--------|
| 1 | Chuẩn bị, bố trí phòng họp, bàn ghế, âm thanh và các điều kiện phục vụ | Đảng viên được phân công | Phòng họp sẵn sàng |
| 2 | In ấn, sắp xếp, phát tài liệu và biểu mẫu theo danh sách | Đảng viên được phân công | Tài liệu đầy đủ, đúng mẫu |
| 3 | Kiểm tra danh sách, điểm danh đảng viên, tổng hợp số lượng có mặt và vắng mặt | Đảng viên được phân công | Danh sách tham dự chính xác |
| 4 | Chụp ảnh toàn cảnh, các hoạt động chung; ghi hình những nội dung được phép; lưu trữ hình ảnh hội nghị | Đảng viên phụ trách hình ảnh | Bộ ảnh, video tư liệu phù hợp |
| 5 | Thực hiện công tác thư ký, ghi chép và hoàn thiện biên bản hội nghị | Đảng viên được cử làm thư ký | Biên bản hội nghị |
| 6 | Phát, thu, kiểm phiếu và lập biên bản kiểm phiếu | Thành viên tổ kiểm phiếu | Biên bản kiểm phiếu |
| 7 | Tập hợp, sắp xếp hồ sơ kiểm điểm của các đảng viên; rà soát hồ sơ còn thiếu | Đảng viên phụ trách hồ sơ | Hồ sơ cá nhân đầy đủ |
| 8 | Hỗ trợ tổng hợp kết quả hội nghị, sắp xếp và bàn giao tài liệu lưu trữ | Đảng viên được phân công | Hồ sơ bàn giao, lưu trữ |

**Lưu ý:** Thư ký, tổ kiểm phiếu thực hiện nhiệm vụ trên cơ sở được hội nghị cử hoặc thông qua theo trình tự. Việc ghi hình phải được kiểm soát để bảo đảm tính bảo mật của nội dung kiểm điểm và bỏ phiếu kín.

## F. Đề xuất của Bí thư Chi bộ

Để phân công khoa học, tránh bỏ sót nhiệm vụ, tôi đề xuất chia trách nhiệm thành **hai nhóm**:

**Nhóm 1 – Trách nhiệm bắt buộc theo đối tượng:** Mỗi đảng viên phải chủ động chuẩn bị nội dung kiểm điểm, tự chấm điểm, tham gia hội nghị, thực hiện tự phê bình và phê bình, tham gia đánh giá, biểu quyết khi đủ điều kiện và hoàn thiện hồ sơ cá nhân.

**Nhóm 2 – Nhiệm vụ được Bí thư hoặc chi ủy giao thêm:** Bao gồm công tác tổ chức, tài liệu, điểm danh, hậu cần, chụp ảnh, ghi hình, thư ký, kiểm phiếu, tổng hợp và lưu trữ hồ sơ.

Cần đặc biệt phân biệt **trách nhiệm tham gia kiểm điểm** với **quyền tham gia biểu quyết**. Theo hướng dẫn đã cung cấp, đảng viên dự bị không thuộc thành phần biểu quyết đề nghị xếp loại đảng viên; các trường hợp đặc thù khác cần đối chiếu Kế hoạch 122.

**Như vậy, khi hoàn thiện bảng phân công chính thức, tôi đề xuất có đủ 5 nhóm công việc:**

1. Nhiệm vụ của Bí thư Chi bộ.
2. Nhiệm vụ của Phó Bí thư và chi ủy viên.
3. Nhiệm vụ của từng đảng viên.
4. Nhiệm vụ của đảng viên được phân công phục vụ hội nghị.
5. Nhiệm vụ hoàn thiện hồ sơ, báo cáo, lưu trữ sau hội nghị.

Để Bí thư thuận lợi giao việc và giám sát tiến độ, bảng cuối cùng nên thể hiện thành một danh mục thống nhất, có các cột: **STT – Nội dung công việc – Người chịu trách nhiệm chính – Người phối hợp – Thời hạn – Sản phẩm – Tình trạng hoàn thành**.

---

