USER

với vai trò là hiệu trưởng trường mầm non có hơn 20 năm kinh nghiệm trong quản lý và các văn bản đình kèm. Bạn hãy giúp tôi lập kế hoạch triển khai nội dung theo văn bản yêu cầu. Văn phong trang trọng, lịch sự bám sát nội dung văn bản, dễ hiểu phù hợp thực tiễn cơ sở giáo dục. Không hàn lâm sáo rổng

---

ASSISTANT

Tôi sẽ đối chiếu nội dung kế hoạch của Sở, phụ lục nhiệm vụ và văn bản chỉ đạo của địa phương, sau đó xây dựng kế hoạch ở cấp trường mầm non. Tôi sẽ chú trọng các việc nhà trường thực sự phải làm, phân công trách nhiệm, thời gian thực hiện và chế độ báo cáo; tránh đưa những yêu cầu chỉ áp dụng cho bậc phổ thông vào kế hoạch.

---

ASSISTANT

Tôi xây dựng dự thảo kế hoạch dành cho **trường mầm non thuộc UBND phường An Bình, tỉnh Đồng Tháp**, trên cơ sở các văn bản đính kèm, trọng tâm là:

- Quyết định số 2758/QĐ-BGDĐT ngày 18/9/2026 của Bộ Giáo dục và Đào tạo.
- Kế hoạch số 1201/KH-SGDĐT ngày 29/9/2026 của Sở Giáo dục và Đào tạo Đồng Tháp và phụ lục nhiệm vụ kèm theo.
- Văn bản số 5856/VP-VX ngày 03/10/2026 của Văn phòng HĐND và UBND phường An Bình.

Kế hoạch được cụ thể hóa phù hợp với giáo dục mầm non, đặc biệt chú trọng **chăm sóc, nuôi dưỡng, tổ chức hoạt động giáo dục, đánh giá sự phát triển của trẻ, công khai minh bạch và giảm áp lực hồ sơ cho giáo viên**. Những nội dung về thi cử, điểm số của bậc phổ thông được điều chỉnh phù hợp, không áp dụng máy móc.

Dưới đây là dự thảo có thể sử dụng làm cơ sở ban hành tại nhà trường.

> **writing · document**
>
> | UBND PHƯỜNG AN BÌNH | CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM |
> |:---:|:---:|
> | **TRƯỜNG MẦM NON …………** | **Độc lập - Tự do - Hạnh phúc** |
> | Số: …/KH-… | *An Bình, ngày … tháng 10 năm 2026* |
>
> # KẾ HOẠCH
>
> **Triển khai thực hiện Chương trình hành động của Bộ Giáo dục và Đào tạo về tăng cường kỷ cương; xây dựng văn hóa trung thực, liêm chính và thực chất trong các hoạt động giáo dục**
>
> Thực hiện Quyết định số 2758/QĐ-BGDĐT ngày 18 tháng 9 năm 2026 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Chương trình hành động của Bộ Giáo dục và Đào tạo về tăng cường kỷ cương; xây dựng văn hóa trung thực, liêm chính và thực chất trong các hoạt động giáo dục;
>
> Thực hiện Kế hoạch số 1201/KH-SGDĐT ngày 29 tháng 9 năm 2026 của Sở Giáo dục và Đào tạo Đồng Tháp về triển khai thực hiện Chương trình hành động của Bộ Giáo dục và Đào tạo;
>
> Căn cứ Văn bản số 5856/VP-VX ngày 03 tháng 10 năm 2026 của Văn phòng HĐND và UBND phường An Bình về việc triển khai thực hiện Chương trình hành động của Bộ Giáo dục và Đào tạo;
>
> Căn cứ tình hình thực tế và nhiệm vụ năm học 2026 - 2027, Trường Mầm non ………… xây dựng kế hoạch triển khai thực hiện với những nội dung cụ thể như sau:
>
> ## I. MỤC TIÊU
>
> ### 1. Mục tiêu chung
>
> Tăng cường kỷ luật, kỷ cương, nâng cao tinh thần trách nhiệm, ý thức chấp hành pháp luật và đạo đức nghề nghiệp của đội ngũ cán bộ quản lý, giáo viên, nhân viên; xây dựng môi trường giáo dục an toàn, lành mạnh, dân chủ, trung thực, liêm chính và tôn trọng trẻ.
>
> Nâng cao chất lượng thực chất trong công tác chăm sóc, nuôi dưỡng và giáo dục trẻ; bảo đảm các hoạt động của nhà trường được tổ chức đúng quy định, phù hợp với điều kiện thực tế, lấy sự an toàn và phát triển của trẻ làm trọng tâm.
>
> Đề cao trách nhiệm nêu gương của cán bộ quản lý, giáo viên, nhân viên; thực hiện công khai, minh bạch trong quản lý, điều hành và đánh giá kết quả thực hiện nhiệm vụ. Từng bước khắc phục bệnh thành tích, hình thức; giảm các công việc hành chính không cần thiết, tạo điều kiện để giáo viên tập trung thực hiện tốt nhiệm vụ chuyên môn.
>
> ### 2. Mục tiêu cụ thể
>
> Trong năm học 2026 - 2027, nhà trường tập trung thực hiện các mục tiêu sau:
>
> - 100% cán bộ quản lý, giáo viên, nhân viên được quán triệt, phổ biến nội dung Chương trình hành động của Bộ Giáo dục và Đào tạo, kế hoạch triển khai của Sở Giáo dục và Đào tạo và các quy định liên quan đến kỷ cương, đạo đức nghề nghiệp, văn hóa ứng xử, trung thực và trách nhiệm trong thực hiện nhiệm vụ.
>
> - 100% nhóm, lớp thực hiện nghiêm túc Chương trình giáo dục mầm non; tổ chức các hoạt động chăm sóc, nuôi dưỡng, giáo dục phù hợp với độ tuổi, khả năng và nhu cầu của trẻ; không chạy theo thành tích, không tổ chức các hoạt động mang tính hình thức.
>
> - 100% giáo viên thực hiện theo dõi, quan sát, đánh giá sự phát triển của trẻ theo đúng quy định; kết quả đánh giá phản ánh trung thực khả năng, mức độ tiến bộ của từng trẻ, làm cơ sở điều chỉnh hoạt động giáo dục.
>
> - 100% bộ phận, tổ chuyên môn thực hiện rà soát hồ sơ, sổ sách, kế hoạch, hội thi và các hoạt động phong trào; không tự đặt thêm hồ sơ ngoài quy định hoặc tổ chức các hoạt động không mang lại hiệu quả thiết thực.
>
> - Thực hiện công khai, minh bạch các nội dung về tài chính, các khoản thu - chi, công tác tuyển sinh, chế độ chính sách, công tác nuôi dưỡng, thi đua và đánh giá đội ngũ theo quy định.
>
> - Tăng cường ứng dụng công nghệ thông tin trong quản lý, điều hành và thực hiện nhiệm vụ chuyên môn; bảo đảm thông tin, số liệu, hồ sơ được cập nhật chính xác, thống nhất, có thể kiểm tra và đối chiếu khi cần thiết.
>
> - Phấn đấu không để xảy ra các hành vi vi phạm đạo đức nhà giáo, thiếu trung thực trong đánh giá trẻ, sai lệch số liệu, tiêu cực trong quản lý tài chính, chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> ## II. NHIỆM VỤ VÀ GIẢI PHÁP
>
> ### 1. Nâng cao ý thức chấp hành pháp luật, tăng cường kỷ cương và trách nhiệm trong thực hiện nhiệm vụ
>
> Tổ chức quán triệt, triển khai đầy đủ nội dung Chương trình hành động của Bộ Giáo dục và Đào tạo, Kế hoạch số 1201/KH-SGDĐT và các văn bản chỉ đạo liên quan đến toàn thể cán bộ quản lý, giáo viên, nhân viên thông qua họp hội đồng sư phạm, sinh hoạt tổ chuyên môn và các hoạt động phù hợp.
>
> Rà soát, bổ sung nội dung về trách nhiệm, tính trung thực, liêm chính và văn hóa ứng xử vào quy chế làm việc, quy tắc ứng xử và các quy định nội bộ của nhà trường, bảo đảm phù hợp với quy định hiện hành.
>
> Thực hiện nghiêm kỷ luật, kỷ cương hành chính, quy chế chuyên môn, thời gian làm việc và nhiệm vụ được phân công. Mỗi cán bộ quản lý, giáo viên, nhân viên có trách nhiệm giữ gìn phẩm chất đạo đức, tác phong sư phạm, giao tiếp chuẩn mực, tôn trọng và đối xử công bằng với trẻ.
>
> Phát huy vai trò nêu gương của người đứng đầu và cán bộ quản lý trong thực hiện nhiệm vụ, quản lý tài chính, phân công công việc, đánh giá đội ngũ và giải quyết các vấn đề phát sinh. Thực hiện đánh giá, xếp loại viên chức, người lao động khách quan, đúng quy định, gắn với kết quả thực hiện nhiệm vụ và tinh thần trách nhiệm của từng cá nhân.
>
> Tăng cường kiểm tra, nhắc nhở, kịp thời chấn chỉnh các biểu hiện thiếu trách nhiệm, vi phạm quy định, thiếu trung thực hoặc gây ảnh hưởng đến chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> ### 2. Nâng cao chất lượng thực chất trong công tác chăm sóc, nuôi dưỡng và giáo dục trẻ
>
> **a) Đối với hoạt động giáo dục**
>
> Tổ chức thực hiện Chương trình giáo dục mầm non theo đúng quy định; xây dựng kế hoạch giáo dục phù hợp với điều kiện thực tế của nhà trường, đặc điểm của từng nhóm, lớp và khả năng phát triển của trẻ.
>
> Giáo viên tổ chức các hoạt động giáo dục trên cơ sở nhu cầu, hứng thú và khả năng của trẻ; tạo điều kiện để trẻ được vui chơi, trải nghiệm, khám phá và phát triển theo nhịp độ riêng. Không áp đặt kết quả, không yêu cầu mọi trẻ phải đạt mức độ như nhau hoặc tạo áp lực thành tích đối với trẻ.
>
> Thực hiện nghiêm túc việc quan sát, theo dõi và đánh giá sự phát triển của trẻ. Kết quả đánh giá phải dựa trên biểu hiện thực tế của từng trẻ trong quá trình tham gia các hoạt động hằng ngày; không sao chép, ghi nhận kết quả theo cảm tính hoặc điều chỉnh kết quả nhằm làm đẹp hồ sơ, báo cáo.
>
> Khắc phục tình trạng tổ chức hoạt động giáo dục mang tính trình diễn; không tập luyện trước cho trẻ để tạo kết quả hình thức trong các hoạt động dự giờ, thao giảng, kiểm tra hoặc tổ chức chuyên đề.
>
> Đối với trẻ mẫu giáo 5 tuổi, thực hiện tốt công tác chuẩn bị tâm thế cho trẻ vào lớp Một theo quy định; không dạy trước chương trình lớp Một hoặc tổ chức các hoạt động gây áp lực học tập không phù hợp với lứa tuổi.
>
> **b) Đối với hoạt động chăm sóc, nuôi dưỡng**
>
> Thực hiện nghiêm các quy định về an toàn trường học, vệ sinh, phòng chống tai nạn thương tích, phòng chống bạo lực học đường và bảo đảm an toàn cho trẻ trong thời gian ở trường.
>
> Tổ chức thực hiện công tác nuôi dưỡng đúng quy trình; bảo đảm chất lượng bữa ăn, định lượng khẩu phần, vệ sinh an toàn thực phẩm và công khai các nội dung liên quan theo quy định.
>
> Thực hiện trung thực việc giao nhận thực phẩm, kiểm tra chất lượng thực phẩm, xây dựng thực đơn, tính khẩu phần, quản lý số suất ăn và quyết toán tiền ăn của trẻ. Không để xảy ra tình trạng cắt giảm khẩu phần, sử dụng kinh phí sai mục đích hoặc ghi chép số liệu không đúng thực tế.
>
> Tổ chức theo dõi sức khỏe, cân đo, đánh giá tình trạng dinh dưỡng và sự phát triển thể chất của trẻ đúng quy trình; cập nhật kết quả chính xác, không điều chỉnh số liệu để đạt chỉ tiêu hoặc làm đẹp báo cáo.
>
> Tăng cường sự phối hợp giữa giáo viên, nhân viên nuôi dưỡng, nhân viên y tế và cha mẹ trẻ trong chăm sóc sức khỏe, dinh dưỡng và bảo đảm an toàn cho trẻ.
>
> ### 3. Xây dựng văn hóa trung thực, trách nhiệm và môi trường giáo dục lành mạnh
>
> Lồng ghép giáo dục các giá trị trung thực, trách nhiệm, tôn trọng và chia sẻ vào hoạt động giáo dục hằng ngày; lựa chọn hình thức phù hợp với độ tuổi, không tổ chức thành nội dung giáo dục nặng về lý thuyết.
>
> Thông qua các hoạt động vui chơi, kể chuyện, trò chuyện, sinh hoạt và xử lý tình huống gần gũi, giáo viên hướng dẫn trẻ biết nói thật, nhận lỗi khi làm sai, giữ lời hứa, biết xin lỗi, cảm ơn, tôn trọng bạn và giữ gìn đồ dùng chung.
>
> Giáo viên thực hiện nêu gương bằng lời nói, hành vi và cách ứng xử; khuyến khích trẻ mạnh dạn bày tỏ suy nghĩ, biết nhận trách nhiệm phù hợp với khả năng, không tạo tâm lý sợ sai hoặc áp lực khi trẻ chưa thực hiện được yêu cầu.
>
> Xây dựng mối quan hệ đoàn kết, tôn trọng, hợp tác giữa cán bộ quản lý, giáo viên, nhân viên; kịp thời trao đổi, tháo gỡ khó khăn trong công việc, hạn chế tình trạng né tránh trách nhiệm, thiếu phối hợp hoặc thiếu công bằng trong thực hiện nhiệm vụ.
>
> Phối hợp với cha mẹ trẻ trong việc giáo dục những hành vi, thói quen tốt cho trẻ; thống nhất phương pháp giáo dục giữa gia đình và nhà trường, không chạy theo kết quả hoặc thành tích hình thức.
>
> ### 4. Khắc phục bệnh thành tích, hình thức; giảm hồ sơ, sổ sách và công việc ngoài chuyên môn
>
> Rà soát các loại hồ sơ, sổ sách, kế hoạch, báo cáo và biểu mẫu đang sử dụng tại nhà trường; thực hiện đúng thành phần, nội dung theo quy định, không yêu cầu giáo viên lập thêm hồ sơ, minh chứng không cần thiết.
>
> Đối với những nội dung đã được cập nhật đầy đủ trên hệ thống quản lý hoặc hồ sơ hiện có, hạn chế yêu cầu thực hiện trùng lặp bằng nhiều hình thức.
>
> Rà soát các cuộc thi, hội thi, phong trào, hoạt động chuyên đề do nhà trường tổ chức; chỉ duy trì những hoạt động phù hợp với mục tiêu giáo dục, có tác dụng nâng cao chất lượng chuyên môn hoặc tạo cơ hội phát triển cho trẻ.
>
> Không tổ chức hội thi, hoạt động phong trào chỉ nhằm mục đích lấy thành tích, hình ảnh hoặc tạo áp lực đối với giáo viên, trẻ và cha mẹ trẻ. Không sử dụng đơn thuần kết quả hội thi, giải thưởng hoặc các chỉ tiêu số lượng để đánh giá chất lượng giáo viên, nhóm lớp.
>
> Đổi mới sinh hoạt chuyên môn theo hướng tập trung giải quyết những khó khăn thực tế trong tổ chức hoạt động giáo dục, chăm sóc và nuôi dưỡng trẻ; chú trọng trao đổi kinh nghiệm, hỗ trợ giáo viên thay vì chỉ kiểm tra hồ sơ hoặc đánh giá hình thức.
>
> Sắp xếp lịch họp, kiểm tra, sinh hoạt chuyên môn hợp lý; hạn chế các cuộc họp trùng lặp, không cần thiết. Phân công nhiệm vụ đúng vị trí việc làm, bảo đảm thời gian để giáo viên tập trung chăm sóc và tổ chức hoạt động giáo dục cho trẻ.
>
> ### 5. Thực hiện công khai, minh bạch trong quản lý và các hoạt động của nhà trường
>
> Thực hiện công khai đầy đủ, đúng thời điểm và đúng hình thức các nội dung thuộc trách nhiệm công khai của cơ sở giáo dục theo quy định, tập trung vào công tác tuyển sinh, các khoản thu - chi, chế độ chính sách, tài chính, chất lượng chăm sóc, nuôi dưỡng, giáo dục và điều kiện bảo đảm chất lượng.
>
> Quản lý, sử dụng các nguồn kinh phí đúng mục đích, đúng chế độ; thực hiện thu, chi và quyết toán đầy đủ chứng từ, không vận động hoặc tổ chức thu các khoản trái quy định.
>
> Thực hiện công khai, minh bạch trong phân công nhiệm vụ, đánh giá, xếp loại viên chức, thi đua, khen thưởng và giải quyết chế độ chính sách; bảo đảm khách quan, công bằng, có căn cứ và phù hợp với kết quả thực hiện nhiệm vụ.
>
> Duy trì các kênh tiếp nhận ý kiến, phản ánh của cán bộ quản lý, giáo viên, nhân viên và cha mẹ trẻ thông qua trao đổi trực tiếp, hộp thư góp ý, số điện thoại hoặc các kênh thông tin hiện có của nhà trường.
>
> Kịp thời tiếp nhận, xem xét, giải quyết các ý kiến phản ánh thuộc thẩm quyền; chuyển cơ quan có thẩm quyền đối với những nội dung vượt thẩm quyền. Bảo đảm giữ bí mật thông tin và bảo vệ người phản ánh theo quy định của pháp luật.
>
> ### 6. Tăng cường ứng dụng công nghệ thông tin, bảo đảm tính chính xác trong quản lý hồ sơ và dữ liệu
>
> Đẩy mạnh ứng dụng công nghệ thông tin, sử dụng hiệu quả các phần mềm và cơ sở dữ liệu hiện có trong quản lý trẻ, đội ngũ, tài chính, hồ sơ chuyên môn và các hoạt động của nhà trường.
>
> Phân công trách nhiệm cập nhật, kiểm tra và quản lý dữ liệu; bảo đảm các thông tin về trẻ, đội ngũ, chuyên cần, sức khỏe, kết quả đánh giá và các số liệu báo cáo được ghi nhận đầy đủ, chính xác, thống nhất.
>
> Không tự ý điều chỉnh, hợp thức hóa số liệu, sao chép thông tin thiếu kiểm chứng hoặc sử dụng dữ liệu không đúng thực tế để phục vụ đánh giá, kiểm tra, báo cáo thành tích.
>
> Khai thác các công cụ công nghệ số và trí tuệ nhân tạo để hỗ trợ công tác quản lý, xây dựng tài liệu và hoạt động chuyên môn một cách phù hợp; kiểm tra nội dung trước khi sử dụng, không để công nghệ thay thế trách nhiệm quan sát, nhận xét và đánh giá trực tiếp của giáo viên đối với trẻ.
>
> Thực hiện các biện pháp bảo vệ thông tin cá nhân, dữ liệu và hình ảnh của trẻ; sử dụng thông tin đúng mục đích, phù hợp với quy định về bảo vệ dữ liệu và quyền riêng tư.
>
> ### 7. Tăng cường công tác kiểm tra, giám sát và trách nhiệm giải trình
>
> Lồng ghép các nội dung về chấp hành kỷ cương, đạo đức nghề nghiệp, tính trung thực và hiệu quả thực hiện nhiệm vụ vào kế hoạch kiểm tra nội bộ của nhà trường.
>
> Tập trung kiểm tra những nội dung có liên quan trực tiếp đến quyền lợi, sự an toàn và phát triển của trẻ, gồm: thực hiện quy chế chuyên môn; tổ chức hoạt động giáo dục; đánh giá trẻ; an toàn trường học; chăm sóc, nuôi dưỡng; quản lý tài chính và thực hiện công khai.
>
> Kết hợp kiểm tra theo kế hoạch với kiểm tra đột xuất khi cần thiết; đánh giá dựa trên kết quả thực hiện nhiệm vụ, điều kiện thực tế và các thông tin có thể kiểm chứng, không chỉ căn cứ vào hồ sơ, báo cáo.
>
> Sau kiểm tra, xác định rõ những nội dung cần điều chỉnh, trách nhiệm của cá nhân, bộ phận liên quan và biện pháp khắc phục. Ưu tiên hướng dẫn, hỗ trợ để nâng cao chất lượng; xử lý nghiêm các hành vi cố ý vi phạm theo đúng thẩm quyền, trình tự và quy định.
>
> Người đứng đầu nhà trường chịu trách nhiệm về công tác chỉ đạo, quản lý, kiểm tra và việc giải quyết, báo cáo các vấn đề phát sinh thuộc phạm vi quản lý.
>
> ## III. TIẾN ĐỘ VÀ PHÂN CÔNG THỰC HIỆN
>
> | Thời gian | Nội dung trọng tâm | Bộ phận thực hiện |
> |---|---|---|
> | Tháng 10/2026 | Ban hành kế hoạch; quán triệt các văn bản chỉ đạo; triển khai nội dung đến toàn thể cán bộ quản lý, giáo viên, nhân viên. | Hiệu trưởng; các Phó Hiệu trưởng |
> | Tháng 10 - 11/2026 | Rà soát quy chế, quy định nội bộ; hồ sơ, sổ sách; các cuộc thi, hội thi, phong trào. Rà soát quy định đánh giá, xếp loại viên chức thuộc thẩm quyền. | Ban Giám hiệu; các tổ chuyên môn; bộ phận liên quan |
> | Từ tháng 11/2026 | Lồng ghép giáo dục trung thực, trách nhiệm trong hoạt động giáo dục; tăng cường quản lý, đánh giá thực chất; chấn chỉnh các nội dung còn hạn chế sau rà soát. | Phó Hiệu trưởng phụ trách chuyên môn; tổ trưởng; giáo viên |
> | Thường xuyên trong năm học | Thực hiện công khai, minh bạch; bảo đảm an toàn, chất lượng chăm sóc, nuôi dưỡng; cập nhật chính xác dữ liệu và hồ sơ; tiếp nhận ý kiến phản ánh. | Ban Giám hiệu; giáo viên; nhân viên theo nhiệm vụ |
> | Học kỳ I và học kỳ II | Kiểm tra, giám sát việc thực hiện; đánh giá kết quả, rút kinh nghiệm và triển khai biện pháp khắc phục các hạn chế. | Hiệu trưởng; Ban kiểm tra nội bộ; các bộ phận liên quan |
> | Tháng 5/2027 | Đánh giá kết quả thực hiện năm học 2026 - 2027; tổng hợp báo cáo theo yêu cầu của cơ quan quản lý. | Hiệu trưởng; các Phó Hiệu trưởng; bộ phận được phân công |
> | Những năm tiếp theo | Tiếp tục duy trì, cập nhật các nội dung phù hợp với chỉ đạo của cấp trên; gắn việc thực hiện với kế hoạch năm học và công tác quản trị nhà trường. | Toàn thể cán bộ quản lý, giáo viên, nhân viên |
>
> Việc triển khai các nhiệm vụ được lồng ghép vào kế hoạch năm học, kế hoạch chuyên môn và hoạt động kiểm tra nội bộ hiện có; không phát sinh thêm hồ sơ, báo cáo riêng khi không cần thiết hoặc không có yêu cầu của cơ quan có thẩm quyền.
>
> ## IV. TỔ CHỨC THỰC HIỆN
>
> ### 1. Hiệu trưởng
>
> Chịu trách nhiệm chung về công tác lãnh đạo, chỉ đạo và tổ chức triển khai thực hiện kế hoạch trong toàn trường.
>
> Tổ chức quán triệt các văn bản chỉ đạo; rà soát, điều chỉnh các quy chế, quy định nội bộ thuộc thẩm quyền; phân công nhiệm vụ rõ ràng, phù hợp với chức năng, vị trí việc làm của từng bộ phận và cá nhân.
>
> Chỉ đạo thực hiện công khai, minh bạch trong quản lý, sử dụng tài chính, đánh giá đội ngũ và tổ chức các hoạt động giáo dục; tăng cường kiểm tra, giám sát, kịp thời chấn chỉnh những hạn chế, thiếu sót.
>
> Chịu trách nhiệm về tính chính xác, trung thực của các thông tin, số liệu và báo cáo thuộc trách nhiệm của nhà trường.
>
> ### 2. Các Phó Hiệu trưởng
>
> Căn cứ lĩnh vực được phân công, chủ động triển khai các nhiệm vụ của kế hoạch vào hoạt động chuyên môn, chăm sóc, nuôi dưỡng, giáo dục và quản lý các điều kiện bảo đảm an toàn cho trẻ.
>
> Hướng dẫn giáo viên, nhân viên thực hiện đúng quy chế chuyên môn; theo dõi, kiểm tra việc tổ chức hoạt động giáo dục, đánh giá trẻ, thực hiện hồ sơ và công tác chăm sóc, nuôi dưỡng.
>
> Rà soát, đề xuất điều chỉnh những hoạt động chưa phù hợp, còn mang tính hình thức; tổng hợp khó khăn, vướng mắc và tham mưu Hiệu trưởng giải pháp xử lý kịp thời.
>
> ### 3. Các tổ chuyên môn, tổ văn phòng
>
> Tổ chức triển khai nội dung kế hoạch trong sinh hoạt tổ; hướng dẫn các thành viên thực hiện đúng yêu cầu, gắn với nhiệm vụ chuyên môn và công việc được giao.
>
> Chú trọng đổi mới nội dung sinh hoạt chuyên môn, chia sẻ kinh nghiệm tổ chức hoạt động giáo dục và đánh giá trẻ thực chất.
>
> Theo dõi việc thực hiện của các thành viên; kịp thời phản ánh những khó khăn, bất cập hoặc biểu hiện thiếu trung thực trong thực hiện nhiệm vụ để Ban Giám hiệu xem xét, giải quyết.
>
> ### 4. Giáo viên
>
> Thực hiện nghiêm quy chế chuyên môn, đạo đức nghề nghiệp và quy tắc ứng xử; chịu trách nhiệm về chất lượng tổ chức hoạt động chăm sóc, nuôi dưỡng, giáo dục và đánh giá trẻ tại nhóm, lớp được phân công.
>
> Chủ động xây dựng môi trường giáo dục an toàn, thân thiện; tổ chức hoạt động phù hợp với trẻ, không chạy theo thành tích hoặc thực hiện đối phó khi kiểm tra.
>
> Theo dõi, đánh giá sự phát triển của trẻ khách quan, trung thực; phối hợp chặt chẽ với cha mẹ trẻ để hỗ trợ trẻ phát triển.
>
> Thực hiện hồ sơ, sổ sách đúng quy định; sử dụng hiệu quả công nghệ thông tin, bảo đảm tính chính xác của dữ liệu và các nội dung báo cáo.
>
> ### 5. Nhân viên
>
> Nhân viên kế toán, y tế, nuôi dưỡng và các vị trí khác thực hiện nghiêm chức trách, nhiệm vụ được giao; bảo đảm tính trung thực, chính xác trong quản lý tài chính, chế độ chính sách, hồ sơ sức khỏe, công tác nuôi dưỡng và các hoạt động liên quan.
>
> Chấp hành quy trình làm việc, quy định về an toàn, vệ sinh và bảo mật thông tin; chủ động phối hợp với giáo viên, các bộ phận để thực hiện tốt nhiệm vụ chăm sóc, nuôi dưỡng và bảo đảm an toàn cho trẻ.
>
> Kịp thời báo cáo người phụ trách khi phát hiện các vấn đề bất thường, sai sót hoặc nguy cơ ảnh hưởng đến quyền lợi, sức khỏe và sự an toàn của trẻ.
>
> ### 6. Công tác phối hợp với cha mẹ trẻ
>
> Thông tin, tuyên truyền những nội dung phù hợp của kế hoạch đến cha mẹ trẻ thông qua họp cha mẹ trẻ, bảng thông tin và các kênh liên lạc hiện có của nhà trường.
>
> Phát huy vai trò phối hợp, giám sát của cha mẹ trẻ đối với các hoạt động chăm sóc, nuôi dưỡng, giáo dục và việc thực hiện công khai theo quy định.
>
> Tiếp nhận ý kiến góp ý trên tinh thần cầu thị, hợp tác; kịp thời giải quyết những vấn đề thuộc trách nhiệm của nhà trường.
>
> ### 7. Điều kiện thực hiện
>
> Sử dụng hiệu quả nguồn nhân lực, cơ sở vật chất và kinh phí đã được bố trí cho hoạt động thường xuyên của nhà trường; lồng ghép các nội dung triển khai vào những hoạt động có liên quan.
>
> Không tổ chức các hoạt động phát sinh kinh phí không cần thiết; không huy động nguồn đóng góp trái quy định để thực hiện kế hoạch.
>
> ## V. CHẾ ĐỘ THÔNG TIN, BÁO CÁO
>
> Các tổ chuyên môn, tổ văn phòng và bộ phận có liên quan thực hiện theo dõi, đánh giá kết quả triển khai trong phạm vi nhiệm vụ được phân công; kịp thời báo cáo Ban Giám hiệu những khó khăn, vướng mắc và các vấn đề phát sinh.
>
> Nhà trường tổ chức đánh giá kết quả thực hiện gắn với sơ kết học kỳ I và tổng kết năm học; tập trung vào những chuyển biến cụ thể trong chấp hành kỷ cương, chất lượng chăm sóc, nuôi dưỡng, giáo dục, tính trung thực trong đánh giá và hiệu quả giảm các hoạt động mang tính hình thức.
>
> Thực hiện chế độ báo cáo định kỳ hoặc đột xuất theo yêu cầu của UBND phường An Bình và cơ quan quản lý có thẩm quyền; bảo đảm nội dung báo cáo trung thực, chính xác, đúng thời hạn.
>
> Trên đây là Kế hoạch triển khai thực hiện Chương trình hành động của Bộ Giáo dục và Đào tạo về tăng cường kỷ cương; xây dựng văn hóa trung thực, liêm chính và thực chất trong các hoạt động giáo dục của Trường Mầm non …………. Yêu cầu các bộ phận, cán bộ quản lý, giáo viên, nhân viên nghiêm túc triển khai thực hiện. Trong quá trình thực hiện, nếu có khó khăn, vướng mắc, kịp thời báo cáo Hiệu trưởng để xem xét, giải quyết./.
>
> | **Nơi nhận:** | **HIỆU TRƯỞNG** |
> |---|:---:|
> | - UBND phường An Bình (để báo cáo); | |
> | - Phòng Văn hóa - Xã hội (để phối hợp); | |
> | - Ban Giám hiệu (để chỉ đạo); | |
> | - Các tổ chuyên môn, tổ văn phòng (để thực hiện); | |
> | - Lưu: VT. | **……………………** |

## Một số lưu ý trước khi ban hành

Từ góc độ quản lý trường mầm non, tôi đề xuất lưu ý ba vấn đề để kế hoạch vừa đúng yêu cầu chỉ đạo, vừa triển khai được trong thực tế.

**Thứ nhất, về đánh giá thực chất:** Ở cấp học mầm non, nội dung quan trọng nhất không phải điểm số hay thi cử mà là chất lượng chăm sóc, nuôi dưỡng, tổ chức hoạt động giáo dục và đánh giá đúng sự phát triển của từng trẻ. Vì vậy, dự thảo tập trung vào những nội dung này, đồng thời giữ đúng tinh thần chống bệnh thành tích của văn bản cấp trên.

**Thứ hai, về hồ sơ và phân công:** Phụ lục kèm Kế hoạch số 1201 có những nhiệm vụ do Bộ hoặc Sở chủ trì. Nhà trường chỉ cụ thể hóa các nhiệm vụ thuộc phạm vi trách nhiệm của cơ sở giáo dục, không tự nhận những sản phẩm thuộc trách nhiệm của cơ quan cấp trên. Các hoạt động triển khai nên sử dụng hồ sơ, cuộc họp và kế hoạch hiện có, tránh tạo thêm gánh nặng cho giáo viên.

**Thứ ba, về chế độ báo cáo:** Kế hoạch số 1201 quy định thời hạn báo cáo trước ngày 31/5 hằng năm đối với các cơ sở giáo dục trực thuộc Sở; đối với cơ sở thuộc phạm vi quản lý của UBND cấp xã, UBND xã, phường tổng hợp báo cáo chung. Vì vậy, trường mầm non thuộc UBND phường An Bình cần thực hiện theo lịch và hướng dẫn của địa phương, không mặc nhiên áp dụng tuyến báo cáo dành cho cơ sở trực thuộc Sở.

**Đề xuất:** Dự thảo này phù hợp làm kế hoạch triển khai trong năm học 2026 - 2027, đồng thời tiếp tục thực hiện trong các năm tiếp theo. Khi hoàn thiện bản chính thức, nên bổ sung chính xác tên trường, số văn bản, thời điểm ban hành và chức danh phụ trách từng lĩnh vực theo cơ cấu thực tế của nhà trường.

---

USER

bạn có thể kèm phụ lục dựa theo các nội dung cảu văn bản]

---

ASSISTANT

Có. Tôi đề xuất bổ sung **Phụ lục danh mục nhiệm vụ triển khai thực hiện** kèm theo Kế hoạch của nhà trường, được xây dựng trên cơ sở đối chiếu Kế hoạch số 1201/KH-SGDĐT, phụ lục 10 nhiệm vụ của Sở Giáo dục và Đào tạo và Văn bản số 5856/VP-VX của địa phương.

Phụ lục này cụ thể hóa thành **13 nhiệm vụ phù hợp với trường mầm non**, xác định rõ nội dung, sản phẩm, thời gian và bộ phận chịu trách nhiệm. Đặc biệt, sản phẩm thực hiện chủ yếu sử dụng hồ sơ, minh chứng sẵn có, không yêu cầu giáo viên lập thêm sổ sách không cần thiết.

> **writing · document**
>
> # PHỤ LỤC
>
> **DANH MỤC NHIỆM VỤ TRIỂN KHAI THỰC HIỆN CHƯƠNG TRÌNH HÀNH ĐỘNG VỀ TĂNG CƯỜNG KỶ CƯƠNG; XÂY DỰNG VĂN HÓA TRUNG THỰC, LIÊM CHÍNH VÀ THỰC CHẤT TRONG CÁC HOẠT ĐỘNG GIÁO DỤC**
>
> *(Kèm theo Kế hoạch số …/KH-… ngày … tháng 10 năm 2026 của Trường Mầm non ……………)*
>
> | TT | Nội dung, nhiệm vụ thực hiện | Sản phẩm, kết quả cần đạt | Thời gian thực hiện | Bộ phận chủ trì, phối hợp |
> |---|---|---|---|---|
> | 1 | **Triển khai, quán triệt Chương trình hành động.** Phổ biến nội dung Quyết định số 2758/QĐ-BGDĐT, Kế hoạch số 1201/KH-SGDĐT và các văn bản chỉ đạo liên quan đến toàn thể cán bộ quản lý, giáo viên, nhân viên. | Kế hoạch triển khai của nhà trường; nội dung triển khai được ghi nhận trong hồ sơ họp hội đồng sư phạm hoặc hình thức phù hợp. 100% cán bộ quản lý, giáo viên, nhân viên được quán triệt. | Tháng 10/2026 | Hiệu trưởng chủ trì; các Phó Hiệu trưởng, tổ trưởng phối hợp. |
> | 2 | **Rà soát, điều chỉnh các quy chế, quy định nội bộ.** Rà soát quy chế làm việc, quy tắc ứng xử, quy định về trách nhiệm thực hiện nhiệm vụ; quy chế đánh giá, xếp loại viên chức và các bộ phận thuộc thẩm quyền quản lý. | Các quy chế, quy định được rà soát, sửa đổi hoặc bổ sung khi cần thiết; bảo đảm nội dung về kỷ cương, trung thực, trách nhiệm và đánh giá thực chất. | Tháng 10 - 11/2026 | Hiệu trưởng chủ trì; các Phó Hiệu trưởng, tổ chuyên môn, tổ văn phòng phối hợp. |
> | 3 | **Xây dựng văn hóa trung thực, trách nhiệm trong nhà trường.** Lồng ghép giáo dục trẻ biết nói thật, nhận lỗi, giữ lời hứa, tôn trọng và chia sẻ với bạn; xây dựng văn hóa ứng xử chuẩn mực trong đội ngũ. | Nội dung được tích hợp trong kế hoạch giáo dục của nhóm, lớp và các hoạt động hằng ngày; trẻ được hình thành hành vi, thói quen phù hợp với độ tuổi. | Thường xuyên từ tháng 10/2026 | Phó Hiệu trưởng phụ trách chuyên môn; tổ trưởng, giáo viên thực hiện. |
> | 4 | **Thực hiện chương trình giáo dục và đánh giá sự phát triển của trẻ thực chất.** Tổ chức hoạt động phù hợp với độ tuổi, khả năng của trẻ; đánh giá thông qua quan sát và quá trình hoạt động thực tế; không làm sai lệch kết quả đánh giá hoặc tổ chức hoạt động mang tính đối phó. | Kế hoạch giáo dục được thực hiện phù hợp; hồ sơ theo dõi, đánh giá trẻ đúng quy định, phản ánh trung thực sự tiến bộ của từng trẻ; kết quả đánh giá được sử dụng để điều chỉnh hoạt động giáo dục. | Thường xuyên trong năm học | Phó Hiệu trưởng phụ trách chuyên môn; tổ trưởng, giáo viên thực hiện. |
> | 5 | **Bảo đảm chất lượng chăm sóc, nuôi dưỡng và an toàn cho trẻ.** Thực hiện đúng quy trình giao nhận thực phẩm, chế biến, chia ăn, quản lý khẩu phần, theo dõi sức khỏe, phòng chống tai nạn thương tích; bảo đảm số liệu trung thực, chính xác. | Hồ sơ nuôi dưỡng, giao nhận thực phẩm, theo dõi sức khỏe và kết quả kiểm tra theo quy định; các hoạt động được thực hiện đúng quy trình, bảo đảm an toàn và quyền lợi của trẻ. | Thường xuyên trong năm học | Phó Hiệu trưởng phụ trách nuôi dưỡng; nhân viên y tế, kế toán, cấp dưỡng và giáo viên phối hợp. |
> | 6 | **Thực hiện công khai, minh bạch trong hoạt động của nhà trường.** Công khai các nội dung về tuyển sinh, thu - chi tài chính, chế độ chính sách, công tác nuôi dưỡng, các điều kiện bảo đảm chất lượng và hoạt động thi đua theo quy định. | Nội dung công khai đúng quy định, đúng thời điểm; có hồ sơ, chứng từ và thông tin phục vụ việc kiểm tra, giám sát. | Theo thời điểm quy định và thường xuyên trong năm học | Hiệu trưởng chủ trì; kế toán và các bộ phận liên quan thực hiện. |
> | 7 | **Rà soát, tinh gọn hồ sơ, sổ sách, kế hoạch và báo cáo.** Không yêu cầu giáo viên thực hiện hồ sơ ngoài quy định; hạn chế biểu mẫu, báo cáo trùng lặp; tăng cường sử dụng dữ liệu đã có. | Danh mục hồ sơ được rà soát; điều chỉnh hoặc loại bỏ những yêu cầu không cần thiết; giáo viên thực hiện hồ sơ đúng quy định. | Tháng 10 - 11/2026; duy trì thường xuyên | Ban Giám hiệu; tổ chuyên môn, tổ văn phòng phối hợp. |
> | 8 | **Rà soát các hội thi, phong trào và hoạt động chuyên đề.** Chỉ tổ chức các hoạt động thiết thực, phù hợp với mục tiêu giáo dục và điều kiện thực tế; không tạo áp lực thành tích đối với giáo viên và trẻ. | Danh mục hoạt động được rà soát; các hoạt động không thiết thực được đề xuất cắt giảm, điều chỉnh hoặc lồng ghép; không sử dụng đơn thuần kết quả hội thi để đánh giá chất lượng giáo viên, nhóm lớp. | Tháng 10 - 11/2026; rà soát trước khi tổ chức hoạt động | Hiệu trưởng; các Phó Hiệu trưởng và tổ chuyên môn. |
> | 9 | **Đổi mới quản trị và phân công nhiệm vụ.** Phân công công việc đúng chức năng, nhiệm vụ; sắp xếp lịch họp, kiểm tra hợp lý; bảo đảm thời gian để giáo viên tập trung thực hiện hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ. | Phân công nhiệm vụ và lịch công tác phù hợp; giảm các công việc trùng lặp, hình thức; nâng cao hiệu quả sinh hoạt chuyên môn. | Thường xuyên trong năm học | Hiệu trưởng; các Phó Hiệu trưởng, tổ trưởng phối hợp. |
> | 10 | **Ứng dụng công nghệ thông tin trong quản lý, điều hành và thực hiện nhiệm vụ.** Quản lý, cập nhật thông tin trẻ, đội ngũ, hồ sơ chuyên môn và dữ liệu báo cáo chính xác; sử dụng công cụ số phù hợp, bảo đảm an toàn thông tin. | Hồ sơ, dữ liệu được cập nhật đầy đủ, chính xác trên các hệ thống hiện có; hạn chế nhập liệu trùng lặp; thông tin có thể kiểm tra, đối chiếu. | Thường xuyên trong năm học | Ban Giám hiệu; nhân sự phụ trách công nghệ thông tin, các tổ và giáo viên. |
> | 11 | **Tăng cường công tác tuyên truyền, phối hợp và tiếp nhận phản ánh.** Tuyên truyền về kỷ cương, văn hóa trung thực, trách nhiệm; phối hợp với cha mẹ trẻ; duy trì các kênh tiếp nhận và xử lý ý kiến phản ánh. | Nội dung tuyên truyền qua họp cha mẹ trẻ, bảng thông tin hoặc kênh truyền thông hiện có; ý kiến phản ánh được tiếp nhận, xem xét và xử lý theo thẩm quyền. | Thường xuyên, hằng năm | Hiệu trưởng; các Phó Hiệu trưởng, giáo viên và bộ phận liên quan. |
> | 12 | **Kiểm tra, giám sát việc thực hiện kế hoạch.** Lồng ghép nội dung kiểm tra kỷ cương, quy chế chuyên môn, đạo đức nghề nghiệp, đánh giá trẻ, công tác nuôi dưỡng, tài chính và thực hiện công khai vào kiểm tra nội bộ. | Hồ sơ kiểm tra theo kế hoạch; kết quả đánh giá, kiến nghị và biện pháp chấn chỉnh, khắc phục các hạn chế. | Theo kế hoạch kiểm tra nội bộ và khi cần thiết | Hiệu trưởng; Ban kiểm tra nội bộ hoặc bộ phận được phân công. |
> | 13 | **Đánh giá kết quả thực hiện và báo cáo.** Rà soát mức độ hoàn thành các nhiệm vụ, những chuyển biến thực chất, khó khăn, hạn chế và giải pháp khắc phục; thực hiện báo cáo theo yêu cầu của cơ quan quản lý. | Nội dung đánh giá được lồng ghép trong sơ kết, tổng kết năm học; báo cáo định kỳ hoặc đột xuất gửi cơ quan quản lý đúng thời hạn yêu cầu. | Sơ kết học kỳ I; tổng kết tháng 5 hằng năm; báo cáo theo yêu cầu | Hiệu trưởng chủ trì; các Phó Hiệu trưởng và bộ phận liên quan phối hợp. |
>
> ## GHI CHÚ THỰC HIỆN
>
> **1. Về căn cứ xây dựng nhiệm vụ**
>
> Các nội dung trong phụ lục được cụ thể hóa từ ba nhóm nhiệm vụ, giải pháp tại Mục II Kế hoạch số 1201/KH-SGDĐT, gồm:
>
> - Nâng cao ý thức tuân thủ pháp luật, tăng cường kỷ cương; xây dựng văn hóa trung thực, liêm chính và thực chất.
> - Thực hiện “dạy thật, học thật, thi thật, đánh giá thật”, được vận dụng phù hợp với đặc thù giáo dục mầm non, trọng tâm là tổ chức hoạt động giáo dục và đánh giá đúng sự phát triển của trẻ.
> - Khắc phục bệnh thành tích, hình thức; giảm hồ sơ, sổ sách, hội thi và các công việc ngoài chuyên môn.
>
> Đồng thời, phụ lục có đối chiếu các nhiệm vụ liên quan đến cơ sở giáo dục trong phụ lục kèm Kế hoạch số 1201/KH-SGDĐT, nhất là nội dung rà soát quy chế đánh giá, truyền thông, tinh gọn hội thi, hoạt động phong trào và thực hiện chế độ báo cáo.
>
> **2. Về thời gian và sản phẩm thực hiện**
>
> Các mốc thời gian trong phụ lục là tiến độ triển khai dự kiến của nhà trường trong năm học 2026 - 2027, phù hợp với thời điểm ban hành kế hoạch và yêu cầu thực tế.
>
> Các sản phẩm, minh chứng được sử dụng từ hồ sơ quản lý, hồ sơ chuyên môn, hồ sơ kiểm tra và dữ liệu hiện có. Không lập thêm hồ sơ riêng nếu nội dung đã được thể hiện đầy đủ trong hồ sơ theo quy định.
>
> **3. Về trách nhiệm và chế độ báo cáo**
>
> Các bộ phận được phân công chủ động thực hiện nhiệm vụ, báo cáo khó khăn, vướng mắc để Ban Giám hiệu xem xét, giải quyết.
>
> Hiệu trưởng chịu trách nhiệm chỉ đạo, kiểm tra và tổng hợp kết quả thực hiện; báo cáo UBND phường An Bình và cơ quan quản lý có thẩm quyền theo hướng dẫn, thời hạn được giao.
>
> **4. Về tổ chức thực hiện lâu dài**
>
> Sau năm học 2026 - 2027, nhà trường tiếp tục duy trì các nhiệm vụ phù hợp, cập nhật theo chỉ đạo của cấp trên, gắn với việc thực hiện nhiệm vụ năm học và nâng cao chất lượng quản trị nhà trường; góp phần thực hiện mục tiêu đến năm 2030, định hướng đến năm 2035 của Chương trình hành động.
>
> *Phụ lục này là bộ phận kèm theo Kế hoạch triển khai thực hiện Chương trình hành động về tăng cường kỷ cương; xây dựng văn hóa trung thực, liêm chính và thực chất trong các hoạt động giáo dục của Trường Mầm non ……………*.

## 📌 Đề xuất khi đưa vào kế hoạch chính thức

Tôi đề xuất sử dụng phụ lục này làm **bảng phân công và theo dõi thực hiện thống nhất của nhà trường**, thay vì xây dựng thêm nhiều biểu mẫu riêng.

Có hai điểm cần giữ đúng với văn bản của Sở:

**Một là**, các nhiệm vụ do Bộ hoặc Sở chủ trì như rà soát văn bản quy phạm pháp luật, xây dựng bộ tiêu chí trường học an toàn, quy chế đánh giá cơ sở giáo dục trực thuộc Sở không được chuyển thành nhiệm vụ bắt buộc nhà trường tự ban hành sản phẩm. Trường chỉ thực hiện nội dung thuộc thẩm quyền và phối hợp khi được yêu cầu.

**Hai là**, báo cáo kết quả thực hiện của trường mầm non thuộc UBND phường cần gửi theo hướng dẫn của địa phương. Không tự áp dụng thời hạn, tuyến báo cáo trực tiếp về Sở dành cho những cơ sở giáo dục trực thuộc Sở.

Với cách xây dựng này, **kế hoạch chính nêu mục tiêu, nhiệm vụ và giải pháp; phụ lục cụ thể hóa ai làm, làm khi nào, kết quả cần đạt là gì**. Hai phần thống nhất, đủ cơ sở để Hiệu trưởng chỉ đạo, theo dõi, kiểm tra và đánh giá kết quả thực hiện, đồng thời không tạo thêm áp lực hành chính cho giáo viên.

---

