USER

với vai trò hiệu trưởng dựa vào tiêu chí thi đua, bạn hãy giúp tôi thiết kế bảng KPI cho giáo viên theo nội dug đính kèm (file excel) đảm bảo các trục

---

ASSISTANT

# 📊 THIẾT KẾ BẢNG KPI ĐÁNH GIÁ GIÁO VIÊN MẦM NON THEO 06 TRỤC

🎯 **Mục tiêu:** Xây dựng bảng KPI dành cho giáo viên Trường Mầm non An Bình A, kết hợp tiêu chí thi đua của nhà trường với yêu cầu đánh giá, xếp loại kết quả thực hiện nhiệm vụ theo quý.

Bảng KPI cần bảo đảm 4 yêu cầu:

1. **Đúng 06 trục đánh giá** theo tài liệu hướng dẫn đính kèm.
2. **Bám sát tiêu chí thi đua của nhà trường**, cụ thể hóa thành các chỉ số có thể đo lường.
3. **Đánh giá được kết quả thực chất của giáo viên**, đặc biệt về chăm sóc, nuôi dưỡng, giáo dục trẻ, hồ sơ chuyên môn và trách nhiệm nghề nghiệp.
4. **Dễ sử dụng trên Excel**, có công thức tính điểm, tổng hợp kết quả, đối chiếu điểm tự đánh giá với điểm của người quản lý và hỗ trợ đề xuất xếp loại.

Tôi sẽ thiết kế theo hướng vừa phục vụ quản trị chất lượng giáo viên, vừa có thể sử dụng làm minh chứng đánh giá định kỳ. Các chỉ số KPI bổ sung sẽ được phân biệt với tiêu chí chính thức để tránh tự ý thay đổi quy định thi đua.

## 🔍 Cấu trúc bảng KPI đề xuất

Tôi đề xuất một bảng KPI thang điểm 100, với 06 nhóm đánh giá. Đây là **phương án dự thảo**, chưa phải tên và trọng số chính thức của 06 trục trong Phụ lục 3.

| Nhóm KPI dự kiến | Nội dung đánh giá | Điểm |
|--------|--------|--------|
| 1. Phẩm chất, đạo đức nghề nghiệp | Tư tưởng, đạo đức, tác phong, chấp hành quy định | 15 |
| 2. Thực hiện nhiệm vụ chuyên môn | Kế hoạch giáo dục, tổ chức hoạt động, hồ sơ chuyên môn | 30 |
| 3. Chất lượng chăm sóc, giáo dục trẻ | An toàn, sức khỏe, sự phát triển của trẻ | 25 |
| 4. Kỷ luật, trách nhiệm công vụ | Ngày giờ công, tiến độ, trách nhiệm thực hiện nhiệm vụ | 10 |
| 5. Đổi mới, sáng tạo | Ứng dụng CNTT, chuyển đổi số, cải tiến phương pháp | 10 |
| 6. Phối hợp và đóng góp tập thể | Phối hợp phụ huynh, đồng nghiệp, phong trào thi đua | 10 |
| **Tổng cộng** |  | **100** |

## 📋 Cấu trúc file Excel

Tôi đề xuất bố trí 5 sheet:

- **Sheet 1 – Danh mục KPI:** Mã chỉ số, nội dung tiêu chí, điểm tối đa, cách tính, minh chứng và người đánh giá.
- **Sheet 2 – Đánh giá cá nhân:** Giáo viên tự chấm điểm theo từng chỉ số, ghi kết quả thực hiện và minh chứng.
- **Sheet 3 – Đánh giá của quản lý:** Tổ trưởng chuyên môn hoặc ban giám hiệu chấm điểm, nhận xét và xác nhận.
- **Sheet 4 – Tổng hợp theo quý:** Tự động tổng hợp điểm 06 trục, đối chiếu kết quả và đề xuất mức xếp loại.
- **Sheet 5 – Dashboard:** Theo dõi kết quả giáo viên theo quý, từng trục và toàn trường.

## ⚠️ Nội dung cần xác nhận trước khi hoàn thiện

Tôi đã nhận được Quyết định số 56/QĐ-MNABA ngày 03/10/2025 và các mẫu biểu đính kèm. Quyết định xác nhận việc ban hành tiêu chí thi đua nhưng trang tài liệu hiện có chưa thể hiện bảng tiêu chí chi tiết.

Mẫu 11 có yêu cầu cụ thể hóa kết quả đánh giá theo **06 trục của bảng chấm điểm**. Vì vậy, cần lấy đúng tên trục, tiêu chí và trọng số từ file Excel *2. Kèm HD Phụ lục 3(2).xlsx*, thay vì mặc định sử dụng 06 nhóm tôi đề xuất ở trên.

**Tôi cần xác nhận một nội dung:** Bạn muốn bảng KPI dành cho giáo viên **giữ nguyên hoàn toàn 06 trục và thang điểm trong Phụ lục 3**, sau đó lồng ghép tiêu chí thi đua của Trường Mầm non An Bình A vào từng trục, đúng không?

Đây là phương án tôi ưu tiên vì giúp nhà trường thống nhất giữa đánh giá theo quý, đánh giá kết quả công việc và công tác thi đua, đồng thời hạn chế việc giáo viên phải thực hiện nhiều bảng đánh giá khác nhau.

---

USER

tôi muốn bảng KPI dành cho giáo viên giữ nguyên hoàn toàn 06 trục và thang điểm trong Phụ lục 3, sau đó lồng ghép tiêu chí thi đua của Trường Mầm non An Bình A vào từng trục,

---

ASSISTANT

Tôi thống nhất với phương án này. **Bảng KPI dành cho giáo viên Trường Mầm non An Bình A sẽ giữ nguyên hoàn toàn 06 trục, tên tiêu chí và thang điểm theo Phụ lục 3**, đồng thời lồng ghép các tiêu chí thi đua của nhà trường vào từng trục tương ứng.

## 📊 Nguyên tắc thiết kế bảng KPI

Tôi sẽ thực hiện theo 3 nguyên tắc:

1. **Giữ nguyên quy định gốc:** Không tự ý thay đổi tên trục, điểm tối đa, trọng số và nguyên tắc xếp loại trong Phụ lục 3.
2. **Cụ thể hóa cho giáo viên mầm non:** Lồng ghép những yêu cầu về phẩm chất đạo đức, chăm sóc và bảo đảm an toàn cho trẻ, tổ chức hoạt động giáo dục, hồ sơ chuyên môn, phối hợp phụ huynh, đổi mới sáng tạo và thực hiện phong trào thi đua vào đúng trục phù hợp.
3. **Đánh giá có minh chứng:** Mỗi chỉ số có nội dung công việc, kết quả cần đạt, phương pháp chấm điểm, minh chứng, điểm giáo viên tự đánh giá và điểm quản lý đánh giá.

## 📋 Cấu trúc bảng Excel dự kiến

| Thành phần | Nội dung |
|--------|--------|
| 06 trục đánh giá | Giữ nguyên Phụ lục 3 |
| Tiêu chí thành phần | Theo quy định gốc |
| KPI cụ thể | Lồng ghép tiêu chí thi đua nhà trường |
| Chỉ tiêu cần đạt | Có thể đo lường, kiểm chứng |
| Điểm tối đa | Theo thang điểm gốc |
| Điểm tự đánh giá | Giáo viên nhập |
| Điểm quản lý đánh giá | Tổ trưởng/BGH nhập |
| Minh chứng | Hồ sơ, sản phẩm, kết quả thực hiện |
| Tổng điểm và xếp loại | Excel tự động tính theo quy định |

Tôi cũng sẽ bố trí phần tổng hợp theo quý, theo năm và bảng theo dõi kết quả của toàn bộ giáo viên.

## ⚠️ Một nội dung cần bổ sung

Hiện tôi đã xác định được yêu cầu đánh giá theo 06 trục từ Mẫu 11, nhưng chưa đọc được đầy đủ nội dung các bảng trong hai tệp Excel đính kèm. Quyết định số 56/QĐ-MNABA cũng chưa có phần tiêu chí thi đua chi tiết trong trang PDF được cung cấp.

Để bảo đảm **đúng tuyệt đối Phụ lục 3, không tự đặt tên trục hoặc phân bổ lại điểm**, bạn vui lòng gửi ảnh chụp hoặc bản PDF của:

- Bảng 06 trục và thang điểm trong file *2. Kèm HD Phụ lục 3(2).xlsx*.
- Bảng tiêu chí thi đua chi tiết kèm Quyết định số 56/QĐ-MNABA (nếu có).

Khi có đủ hai nội dung này, tôi sẽ xây dựng bảng KPI Excel hoàn chỉnh, có công thức tự động, phù hợp để Hiệu trưởng triển khai đánh giá giáo viên trong toàn trường.

---

USER

gửi bạn tiêu chí thi đua

---

ASSISTANT

Tôi đã nhận được **bộ tiêu chí chấm điểm thi đua năm học 2025–2026 của Trường Mầm non An Bình A**, ban hành kèm Quyết định số 38/QĐ-MNABA ngày 01/12/2025.

Qua nghiên cứu 8 hình ảnh bạn gửi (trang 3–10), tôi xác định được những nội dung quan trọng để xây dựng bảng KPI giáo viên.

## 📌 1. Cơ sở xây dựng bảng KPI

Bộ tiêu chí thi đua của nhà trường có **37 nội dung, thuộc 11 nhóm tiêu chí**, bao gồm:

| Nhóm | Nội dung |
|--------|--------|
| I | Trẻ em và giáo viên |
| II | Chất lượng giáo dục |
| III | Các hội thi bắt buộc theo kế hoạch thời gian năm học |
| IV | Thiết bị, đồ dùng, đồ chơi |
| V | Thực hiện an sinh xã hội trong giáo dục |
| VI | Công tác tài chính |
| VII | Công tác Đảng, đoàn thể |
| VIII | Chấp hành pháp luật, quy định; bảo vệ an ninh, trật tự; bảo vệ bí mật nhà nước |
| IX | Kiểm định chất lượng giáo dục, phổ cập giáo dục |
| X | Ứng dụng công nghệ thông tin, chuyển đổi số |
| XI | Công tác báo cáo |

Theo mục III, phần *Tổ chức thực hiện*, mỗi giáo viên được giao 370 điểm thi đua ban đầu, tương ứng 37 nội dung, mỗi nội dung 10 điểm. Điểm thưởng và điểm trừ được áp dụng theo quy định của nhà trường.

## 🎯 2. Phương án tích hợp vào KPI 06 trục

Tôi đề xuất xây dựng bảng đối chiếu giữa 37 nội dung thi đua và 06 trục của Phụ lục 3. Mỗi nội dung sẽ được gắn với trục phù hợp, nhưng **không cộng trực tiếp 370 điểm thi đua vào thang điểm KPI**, tránh làm sai trọng số của Phụ lục 3.

Đặc biệt, bảng KPI sẽ có những chỉ số đo lường cụ thể như:

- Tỷ lệ chuyên cần: lớp 5 tuổi 95%, lớp 4 tuổi 85%, lớp 3 tuổi và nhóm trẻ 80%.
- Tỷ lệ trẻ suy dinh dưỡng nhẹ cân, thấp còi không quá 1,25%; tỷ lệ béo phì không quá 2%.
- Tham gia đầy đủ các hội thi bắt buộc.
- Ứng dụng CNTT trong giảng dạy ít nhất 1 bài/chủ đề.
- Cung cấp ít nhất 2 nội dung/năm cho kho học liệu của đơn vị.
- Gửi ít nhất 1 tin bài/tháng trên website trường.
- Thực hiện đầy đủ, đúng hạn các báo cáo.

Các tiêu chí về an toàn trẻ, đạo đức nghề nghiệp, chấp hành pháp luật và quy chế sẽ được theo dõi riêng để áp dụng đúng quy định khống chế xếp loại của nhà trường.

## 📊 3. Cấu trúc Excel hoàn chỉnh

Tôi dự kiến thiết kế 6 sheet:

| Sheet | Chức năng |
|--------|--------|
| 01. Hướng dẫn | Quy định chấm điểm, cách nhập dữ liệu |
| 02. Danh mục 06 trục KPI | Giữ nguyên nội dung và điểm của Phụ lục 3 |
| 03. Đối chiếu tiêu chí thi đua | Liên kết 37 nội dung với các trục KPI |
| 04. Chấm điểm giáo viên | Tự đánh giá, quản lý đánh giá, minh chứng |
| 05. Tổng hợp theo quý | Tự động tính điểm và đề xuất xếp loại |
| 06. Dashboard | Thống kê kết quả đánh giá giáo viên toàn trường |

## ⚠️ 4. Nội dung còn cần đối chiếu

Tôi đã có đủ thông tin về **tiêu chí thi đua của nhà trường**. Tuy nhiên, để thực hiện đúng yêu cầu giữ nguyên hoàn toàn 06 trục và thang điểm, tôi vẫn cần xác định chính xác nội dung bảng chấm điểm trong Phụ lục 3.

Bạn vui lòng gửi thêm **ảnh chụp sheet có bảng 06 trục trong file “2. Kèm HD Phụ lục 3(2).xlsx”**.

Khi có bảng này, tôi sẽ sử dụng trực tiếp 37 tiêu chí thi đua vừa nhận để xây dựng file Excel KPI cho giáo viên, có công thức tự động và hệ thống minh chứng, bảo đảm không thay đổi tên trục, trọng số hoặc thang điểm quy định.

---

USER

mình gửi lại bảng mẫu KPI của mình. bạn hãy lấy mẫu này để làm mẫu KPI cho giáo viên dựa theo bộ tiêu chí mình gửi ở trên nhe

---

ASSISTANT

Tôi đã nhận được 3 tệp mẫu bạn vừa gửi, gồm:

- **Duyen-KPI.Mau 1, Mau 2, PL3.1-QUY III.2026.xlsx** – mẫu KPI và bảng đánh giá theo quý.
- **NTH.Duyen-Danh mục KPI.Mau 1-QUY III.2026.xlsx** – mẫu danh mục KPI.
- **Duyen-Mẫu 11 (Bản tự đánh giá, xếp loại cá nhân) Quý II.doc** – mẫu trình bày kết quả tự đánh giá.

Tôi hiểu yêu cầu của bạn là **xây dựng bộ KPI mới dành riêng cho giáo viên Trường Mầm non An Bình A, lấy các bảng KPI của Phó Hiệu trưởng làm mẫu về cấu trúc, giữ nguyên 06 trục và thang điểm, đồng thời thay nội dung công việc bằng các chỉ tiêu phù hợp với giáo viên mầm non**.

Tôi sẽ bám sát 37 nội dung thi đua năm học 2025–2026 mà bạn đã cung cấp, đặc biệt là các tiêu chí về chất lượng chăm sóc, giáo dục trẻ, chuyên cần, an toàn trường học, hồ sơ chuyên môn, hội thi, chuyển đổi số và công tác báo cáo.

Tuy nhiên, hiện tôi đọc được nội dung bản tự đánh giá Mẫu 11 nhưng **chưa trích xuất được các ô dữ liệu trong hai bảng Excel mẫu**. Vì vậy, tôi chưa thể xác nhận chính xác tên 06 trục, điểm tối đa và cách bố trí các cột để sao chép đúng mẫu của bạn.

Bạn vui lòng **xuất file “Duyen-KPI.Mau 1, Mau 2, PL3.1-QUY III.2026.xlsx” sang PDF rồi gửi lại**. Tôi sẽ dựa trực tiếp vào đó để hoàn thiện bộ bảng KPI giáo viên, thay vì tự xây dựng một mẫu khác.

Tôi sẽ ưu tiên thiết kế bảng có thể sử dụng ngay trong đánh giá quý III/2026, đồng thời thuận tiện điều chỉnh cho các quý tiếp theo.

---

USER

bạn hoàn thành giúp mình

---

ASSISTANT

Mình sẽ hoàn thiện bộ Excel KPI giáo viên từ các mẫu bạn đã gửi, giữ nguyên cấu trúc 06 trục và thang điểm của mẫu gốc, rồi đối chiếu từng chỉ tiêu với bộ tiêu chí thi đua năm học 2025–2026. Mình cũng sẽ kiểm tra công thức tính điểm và phần tổng hợp trước khi gửi file.

---

ASSISTANT

---

ASSISTANT

Mình đã rà soát các tài liệu và tìm được **bảng KPI dành cho giáo viên mầm non An Bình năm học 2026–2027** đã có trong thư viện tài liệu của bạn.

- File Excel KPI giáo viên gồm hướng dẫn chấm điểm, phiếu đánh giá cá nhân, 9 tiêu chí chung và 22 chỉ số công việc về chăm sóc, giáo dục trẻ, an toàn, chuyên cần, chuyển đổi số và báo cáo; có cột tự chấm, xác nhận và minh chứng. 

### 📊 Nội dung bảng hiện có

Bảng đã cụ thể hóa các tiêu chí thi đua của nhà trường, gồm hai phần:

| Phần đánh giá | Điểm tối đa |
|--------|--------|
| A. Phẩm chất, đạo đức, kỷ luật, trách nhiệm và đổi mới | 30 |
| B. Kết quả thực hiện nhiệm vụ chuyên môn của giáo viên | 70 |
| **Tổng cộng** | **100** |

### ⚠️ Điểm cần lưu ý

Mình cần nói rõ: **đây là bảng KPI đã có, chưa phải phiên bản được chỉnh sửa theo đúng 06 trục và thang điểm trong file mẫu của bạn**.

Hiện mình chưa truy xuất được nội dung từng ô của hai file Excel mẫu Duyên để đối chiếu chính xác và cũng chưa tạo được một file Excel chỉnh sửa mới trong phiên này. Vì vậy, mình không muốn xác nhận sai rằng bảng đã đáp ứng hoàn toàn yêu cầu.

Bạn có thể mở bảng Excel trên để tham khảo ngay. Phần còn phải hoàn thiện là chuyển các chỉ số giáo viên vào **đúng 06 trục, đúng điểm tối đa và đúng bố cục Mẫu 1, Mẫu 2, Phụ lục 3.1** mà bạn yêu cầu, thay vì sử dụng thang 30–70 của bản hiện có.

---

USER

hoàn chỉnh KPI 6 trục neh1

---

ASSISTANT

Mình sẽ hoàn thiện bảng KPI 6 trục theo đúng mẫu của bạn, không dùng lại thang điểm 30–70 trước đó. Mình sẽ đối chiếu tên trục, điểm tối đa với bảng KPI mẫu, rồi lồng ghép 37 tiêu chí thi đua và phần minh chứng dành cho giáo viên.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# BẢNG KPI 06 TRỤC DÀNH CHO GIÁO VIÊN MẦM NON AN BÌNH A

Tôi đã đối chiếu bộ **37 tiêu chí thi đua năm học 2025–2026** của nhà trường với khung đánh giá KPI 06 trục.

Khung 06 trục được nêu tại Phụ lục 3 kèm Hướng dẫn 02-HD/BTCTW ngày 22/5/2026, có tổng điểm 100, gồm 30 điểm tiêu chí chung và 70 điểm kết quả thực hiện nhiệm vụ. [Hướng dẫn 02\-HD/BTCTW 2026 đánh giá định kỳ hằng quý đối với cán bộ lãnh đạo quản lý các cấp](<https://thuvienphapluat.vn/van-ban/bo-may-hanh-chinh/Huong-dan-02-HD-BTCTW-2026-danh-gia-dinh-ky-hang-quy-doi-voi-can-bo-lanh-dao-quan-ly-cac-cap-706652.aspx>); [https://sha\.quangngai\.gov\.vn/upload/2007040/20260608/Ph%E1%BB%A5%20l%E1%BB%A5c%203%20\-%20ph\.pdf](<https://sha.quangngai.gov.vn/upload/2007040/20260608/Ph%E1%BB%A5%20l%E1%BB%A5c%203%20-%20ph.pdf>)

Dưới đây là bảng KPI giáo viên đã được cụ thể hóa theo nhiệm vụ của trường mầm non, thay cho các nội dung quản lý cấp địa phương không thuộc chức trách giáo viên.

## 1. Cơ cấu 06 trục đánh giá

| Trục | Lĩnh vực đánh giá | Điểm tối đa |
|--------|--------|--------|
| 1 | Thực hiện mục tiêu, nhiệm vụ chính trị được giao; chất lượng chăm sóc, giáo dục trẻ | 15 |
| 2 | Thực hiện quy định, quy trình chuyên môn; kiểm tra, giám sát và hồ sơ | 10 |
| 3 | Phát triển khoa học, công nghệ, đổi mới sáng tạo và chuyển đổi số | 10 |
| 4 | Xây dựng Đảng, đoàn kết nội bộ, thực hiện kỷ luật và trách nhiệm nghề nghiệp | 15 |
| 5 | Phát triển con người, bảo đảm an sinh xã hội và phối hợp gia đình | 10 |
| 6 | Bảo đảm an ninh, an toàn, trật tự và phòng ngừa vi phạm | 10 |
|  | **Tổng điểm 06 trục** | **70** |
|  | Tiêu chí chung theo mẫu đánh giá | 30 |
|  | **Tổng điểm đánh giá** | **100** |

Lưu ý đối chiếu: Đây là mức điểm từ khung Phụ lục 3 công khai và nội dung cụ thể hóa cho giáo viên. Chưa thể xác nhận từng ô điểm trùng hoàn toàn với file Excel mẫu Duyên do nội dung bảng tính đó chưa trích xuất được. Điểm thi đua 370 của nhà trường được theo dõi riêng, không cộng trực tiếp vào thang KPI 100 điểm.

## 2. Danh mục KPI chi tiết cho giáo viên

Bảng dưới đây đã phân bổ các nhiệm vụ theo 06 trục, có chỉ tiêu, điểm tối đa, mã đối chiếu tiêu chí thi đua và minh chứng.

Bạn có thể dùng nút **Sao chép bảng KPI vào Excel** để đưa toàn bộ danh mục và công thức tính điểm vào bảng tính.

29 chỉ số KPI cụ thể hóa theo 06 trục [Sao chép bảng KPI vào Excel]

| Trục | Nội dung KPI và yêu cầu cần đạt | Điểm | Mã thi đua |
|--------|--------|--------|--------|

## 3. Phương pháp chấm điểm

Tôi đề xuất sử dụng quy trình sau để giáo viên và nhà trường dễ thao tác:

- Giáo viên cung cấp kết quả thực hiện và minh chứng của từng KPI.
- Với tiêu chí hai mức *Đạt/Không đạt*, ghi 100% hoặc 0%. Với tiêu chí có thể đánh giá từng phần, tỷ lệ hoàn thành do người đánh giá xác nhận dựa trên kết quả và minh chứng.
- Điểm mỗi KPI bằng điểm tối đa nhân với tỷ lệ hoàn thành, không vượt điểm tối đa.
- Cộng điểm 29 KPI để xác định điểm 06 trục trên thang 70.
- Cộng 30 điểm tiêu chí chung theo mẫu của cấp có thẩm quyền để xác định tổng điểm trên thang 100.

Ví dụ, chỉ số 1.4 có 3 điểm tối đa. Nếu được xác nhận đạt 90% thì điểm quy đổi là \(3\times90\%=2,7\) điểm.

**Trong Excel:** Sau khi sao chép bảng, dán vào ô A1 của một sheet mới. Nhập tỷ lệ tự chấm ở cột G và tỷ lệ quản lý đánh giá ở cột I. Công thức có sẵn sẽ tính điểm tại cột H và J.

## 4. Các điều kiện cần kiểm soát riêng

Không nên chỉ dựa trên điểm số để kết luận xếp loại. Tôi đề nghị nhà trường thực hiện thêm bước kiểm tra điều kiện trước khi trình Hội đồng đánh giá.

**Vi phạm nhóm VIII – Chấp hành pháp luật, an ninh, bảo mật**

Đây là nhóm điều kiện có quy định khống chế thi đua trong tài liệu nhà trường. Cần ghi nhận và xử lý theo quy định riêng, không để điểm từ các nhóm khác tự động bù trừ.

---

**Chỉ tiêu phụ thuộc điều kiện khách quan**

Sĩ số, dinh dưỡng, hoàn cảnh gia đình và thành tích hội thi phải được đánh giá trong phạm vi trách nhiệm giáo viên được giao, không quy hoàn toàn kết quả tập thể thành lỗi cá nhân.

---

**Tiêu chí không áp dụng cho mọi giáo viên**

Nội dung liên quan đến đảng viên, đoàn viên, nhiệm vụ hội thi hoặc công việc đặc thù cần có nguyên tắc điều chỉnh điểm do cấp có thẩm quyền thống nhất.

## 5. Kết luận và tình trạng hoàn thiện

Bảng trên đã có **06 trục, 29 chỉ số KPI, phân bổ đủ 70 điểm, chỉ tiêu cần đạt, minh chứng, mã đối chiếu thi đua và công thức chấm điểm để sao chép sang Excel**.

Có hai điểm tôi cần ghi rõ để tránh sai lệch hồ sơ chính thức:

Thứ nhất, trong hình ảnh tiêu chí thi đua bạn gửi, số thứ tự chuyển từ **2 sang 4**, nên chưa xác định được nội dung tiêu chí số 3. Tôi không tự đặt thêm nội dung này.

Thứ hai, việc giữ nguyên tuyệt đối cách trình bày, tên trục và các ô điểm trong **file Excel Duyên** vẫn cần đối chiếu trực tiếp bảng gốc. Bảng hiện tại là bản nội dung KPI được hoàn thiện theo khung 06 trục tham khảo, chưa phải file `.xlsx` đã chỉnh sửa và kiểm chứng từ mẫu gốc.

Về sử dụng thực tế, tôi đề nghị nhà trường thống nhất bảng KPI này qua tổ chuyên môn và ban giám hiệu, sau đó mới áp dụng làm căn cứ đánh giá chính thức theo quý.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

USER

nếu vậy bạn quy các tiêu chí thi đua ứng với 6 trục để có được 100 điểm sẽ thuận tiện hơn

---

ASSISTANT

Mình sẽ quy đổi các tiêu chí thi đua của trường vào 06 trục, tổng đúng 100 điểm để giáo viên có thể chấm trực tiếp trên một bảng. Mình sẽ giữ riêng các điều kiện khống chế xếp loại và quy định điểm thưởng, điểm trừ, tránh để việc quy đổi làm thay đổi tinh thần của bộ tiêu chí gốc.

---

ASSISTANT

# 📊 BẢNG QUY ĐỔI 37 TIÊU CHÍ THI ĐUA VÀO 06 TRỤC KPI – THANG ĐIỂM 100

Tôi đồng ý với phương án này. Đối với giáo viên Trường Mầm non An Bình A, **quy đổi trực tiếp các tiêu chí thi đua vào 06 trục, tổng 100 điểm** sẽ thuận tiện hơn khi tự đánh giá, chấm điểm theo quý và tổng hợp kết quả toàn trường.

Tôi đề xuất giữ 06 lĩnh vực đánh giá đã thống nhất ở bản dự thảo trước, nhưng phân bổ lại trọng số để cả 06 trục đạt 100 điểm, không phải cộng thêm phần 30 điểm riêng.

## 🎯 1. Phân bổ 100 điểm cho 06 trục

TỔNG ĐIỂM KPI

# 100 điểm

(06 trục đánh giá)

| Trục | Nội dung đánh giá | Điểm |
|--------|--------|--------|
| **Tổng cộng** | **100** |  |

Cách phân bổ này ưu tiên 45 điểm cho hai trục liên quan trực tiếp đến kết quả chăm sóc, giáo dục và an toàn trẻ. Đây là **phương án quy đổi đề xuất của nhà trường**, không phải thang điểm gốc đã được xác nhận trong Phụ lục 3.

## 📋 2. Bảng quy đổi chi tiết các tiêu chí thi đua

Tôi giữ nguyên số thứ tự tiêu chí trong tài liệu của nhà trường để thuận lợi khi đối chiếu, kể cả các tiêu chí 4.1, 4.2, 4.3.

Đầy đủ các chỉ số có nội dung xác định trong tài liệu [Sao chép bảng vào Excel]

Xem chi tiết theo từng trục Lựa chọn hiện tại không khả dụng.

Kiểm tra tổng điểm bảng quy đổi: /100. Tiêu chí số 3 không xuất hiện trong các trang đã cung cấp nên chưa được phân điểm; mục 4 được tách thành 4.1, 4.2 và 4.3.

## 📋 3. Cách chấm điểm trên Excel

Bảng sao chép đã có sẵn các cột: Trục, mã tiêu chí, nội dung, chỉ tiêu, điểm tối đa, minh chứng, đối tượng áp dụng, giáo viên tự chấm và BGH chấm.

Tôi đề nghị Hội đồng thi đua thống nhất mức chấm trước khi triển khai:

| Kết quả thực hiện | Tỷ lệ điểm đề xuất |
|--------|--------|
| Đạt đầy đủ yêu cầu, có minh chứng | 100% |
| Cơ bản đạt, có hạn chế nhỏ đã khắc phục | 75% |
| Thực hiện một phần, chưa bảo đảm đầy đủ | 50% |
| Không thực hiện hoặc không đạt điều kiện bắt buộc | 0% |

Đối với tiêu chí quy định rõ **Đạt/Không đạt** hoặc **Không vi phạm**, cần ưu tiên chấm theo điều kiện bắt buộc, không tùy tiện áp dụng mức 75% hay 50%.

Ví dụ, giáo viên được chấm trục 1 như sau:

| Tiêu chí | Tối đa | Thực đạt |
|--------|--------|--------|
| 4.1 | 5 | 5 |
| 4.2 | 4 | 4 |
| 4.3 | 4 | 4 |
| 5 | 7 | 5,25 |
| 6 | 3 | 3 |
| 7 | 2 | 2 |
| **Tổng trục 1** | **25** | **23,25** |

Nếu đủ điều kiện áp dụng tất cả chỉ số, tổng điểm giáo viên là tổng điểm thực đạt của 06 trục, tối đa 100 điểm.

## ⚠️ 4. Quy định cần lưu ý khi áp dụng

Có ba nội dung quan trọng để bảo đảm công bằng:

- **Tiêu chí không áp dụng:** Những nội dung về Đảng, Đoàn, hội thi chưa tổ chức hoặc nhiệm vụ chưa đến kỳ cần ghi *KAD*. Có thể tính lại điểm trục theo tỷ lệ giữa điểm đạt và điểm tối đa của những tiêu chí thực sự áp dụng, nhưng phải có xác nhận và thống nhất cách xử lý từ đầu kỳ.
- **Điều kiện khống chế:** Vi phạm ở nhóm VIII phải tiếp tục được xem xét theo quy định thi đua gốc, không được dùng điểm cao ở các trục khác để bù trừ. Cần căn cứ vào kết quả xác minh, kết luận có thẩm quyền.
- **Điểm thưởng, điểm trừ:** Các quy định thưởng thành tích, vượt sĩ số, bồi dưỡng, vi phạm quy chế của trường cần được theo dõi riêng. Không cộng điểm thưởng vượt mức tối đa 100 và không trừ lặp lại một hành vi.

Đặc biệt, không nên trừ điểm giáo viên chỉ vì không phải đảng viên, không thuộc tổ chức Đoàn, không có trẻ thuộc diện chính sách hoặc không có điều kiện vận động xã hội hóa. Các chỉ tiêu về sĩ số, dinh dưỡng cũng cần xét đúng phạm vi trách nhiệm và điều kiện thực tế của giáo viên.

## ✅ 5. Kết luận

Tôi đề xuất nhà trường sử dụng bảng **06 trục – 100 điểm** vừa xây dựng làm dự thảo đánh giá KPI giáo viên.

Phương án này có ba ưu điểm: mỗi tiêu chí thi đua được đối chiếu vào một trục cụ thể, giáo viên chỉ cần chấm trên một bảng duy nhất, và ban giám hiệu dễ tổng hợp, so sánh kết quả theo quý.

Trước khi ban hành chính thức, nhà trường cần xác nhận nội dung còn thiếu ở tiêu chí số 3, thống nhất trọng số và quy tắc xử lý tiêu chí không áp dụng, đồng thời kiểm tra sự phù hợp với mẫu đánh giá cấp trên.

**Lưu ý:** Đây là bảng quy đổi quản trị nội bộ theo yêu cầu của bạn, chưa thay thế đương nhiên thang điểm bắt buộc của Phụ lục 3 nếu cấp có thẩm quyền quy định khác.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

hoàn thành giúp mình

---

ASSISTANT

# 📊 Hoàn thiện bảng KPI giáo viên – 06 trục, 100 điểm

Tôi chốt phương án **quy đổi tiêu chí thi đua năm học 2025–2026 của Trường Mầm non An Bình A thành bảng KPI 06 trục, thang điểm 100**, để giáo viên tự chấm và ban giám hiệu đánh giá theo quý.

| Trục | Nội dung đánh giá | Điểm |
|--------|--------|--------|
| 1 | Kết quả thực hiện nhiệm vụ chăm sóc, giáo dục trẻ | 25 |
| 2 | Quy trình chuyên môn, hồ sơ, thiết bị và kiểm định chất lượng | 15 |
| 3 | Ứng dụng CNTT, đổi mới sáng tạo và chuyển đổi số | 10 |
| 4 | Kỷ luật, trách nhiệm, đạo đức, công tác Đảng và đoàn thể | 15 |
| 5 | Phát triển trẻ, an sinh xã hội và phối hợp hỗ trợ trẻ | 15 |
| 6 | An ninh, an toàn trường học và phòng ngừa vi phạm | 20 |
| **Tổng** |  | **100** |

Bảng hoàn chỉnh sẽ có mã tiêu chí thi đua gốc, yêu cầu cần đạt, điểm tối đa, minh chứng, cột tự chấm, cột ban giám hiệu chấm và phần tổng hợp tự động.

**Lưu ý về tính pháp lý:** Đây là phương án phân bổ 100 điểm phục vụ quản lý nội bộ theo yêu cầu của bạn; chưa được xác nhận là thang điểm nguyên bản của Phụ lục 3. Điều kiện khống chế xếp loại và quy định thưởng, trừ điểm của trường vẫn được theo dõi riêng.

## 📁 Bộ bảng KPI hoàn chỉnh để sử dụng trong Excel

Tôi đã chuẩn bị nội dung bảng tính gồm: danh mục KPI, phiếu chấm điểm cá nhân, bảng tổng hợp 06 trục, bảng theo dõi điểm thưởng – trừ và danh sách tổng hợp giáo viên.

Trong phiên này, tôi chưa thể đính kèm trực tiếp tệp `.xlsx`. Vì vậy, tôi bố trí bản Excel dạng XML có thể mở bằng Microsoft Excel, cùng lựa chọn sao chép trực tiếp bảng chấm điểm.

BẢN KPI HOÀN CHỈNH

# 06 trục ·  chỉ số · /100 điểm

---

Sổ Excel gồm 6 trang tính

[Sao chép toàn bộ sổ Excel (XML)]

[Sao chép riêng bảng chấm KPI vào Excel]

Hai nút sao chép nội dung vào bộ nhớ tạm. Bản XML có các trang tính và công thức tổng hợp; bản bảng chấm có thể dán trực tiếp vào ô A1 của Excel.

## Cách mở sổ Excel đầy đủ

1. Nhấn **Sao chép toàn bộ sổ Excel (XML)** ở trên.
2. Mở Notepad trên máy tính, dán nội dung và lưu với tên `KPI_Giao_vien_An_Binh_A.xml`, chọn mã hóa UTF-8.
3. Mở tệp `.xml` bằng Microsoft Excel, sau đó chọn **Save As → Excel Workbook (.xlsx)**.
4. Vào sheet **CHAM\_DIEM\_QUY**, nhập thông tin giáo viên, trạng thái áp dụng và điểm đánh giá. Xem kết quả tại **TONG\_HOP\_6\_TRUC**.

## Kiểm tra phân bổ điểm

---

**Tổng điểm quy đổi**

## /100

## Xem lại danh mục KPI theo trục

Lựa chọn hiện tại không khả dụng.

| Mã thi đua | Nội dung KPI | Điểm |
|--------|--------|--------|

## ✅ Những nội dung cần thống nhất trước khi ban hành

Bảng đã phân bổ đủ 100 điểm, nhưng có một số chi tiết cần Hội đồng thi đua xác nhận trước khi dùng để xếp loại chính thức: cách xử lý tiêu chí không áp dụng, các chỉ tiêu chưa đến hạn theo quý, ngưỡng xếp loại và các điều kiện khống chế ở nhóm VIII.

Đặc biệt, tài liệu ảnh bạn gửi không có nội dung tiêu chí số 3; tôi không tự bổ sung. Tiêu chí số 4 được phân thành ba chỉ số 4.1, 4.2, 4.3 để chấm cụ thể.

**Kết quả:** Bạn đã có bộ nội dung KPI 06 trục, 100 điểm, kèm mẫu tính và tổng hợp dùng cho giáo viên. Sau khi nhà trường thông qua trọng số và nguyên tắc đánh giá, có thể sử dụng thống nhất cho các quý tiếp theo.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

bạn hoàn thành dùm mình

---

ASSISTANT

Mình sẽ hoàn thiện thành bảng KPI dùng được ngay, ưu tiên giữ nguyên mẫu bạn gửi và quy đổi tiêu chí thi đua vào 06 trục, tổng 100 điểm. Mình sẽ kiểm tra điểm từng trục, cách chấm các tiêu chí không áp dụng và công thức tổng hợp để tránh sai khi nhà trường sử dụng.

---

ASSISTANT

Mình đã hoàn thiện phương án **KPI giáo viên Trường Mầm non An Bình A theo 06 trục, tổng 100 điểm**, dựa trên bộ tiêu chí thi đua năm học 2025–2026 bạn gửi. Bảng có đủ mã tiêu chí gốc, điểm quy đổi, yêu cầu cần đạt, minh chứng, cột tự đánh giá và cột Ban giám hiệu chấm.

Hiện mình chưa thể xuất tệp `.xlsx` đính kèm trực tiếp trong phiên này. Để bạn sử dụng ngay, mình đã chuẩn bị **bảng dữ liệu có công thức Excel**, có thể sao chép và dán vào Excel.

KPI GIÁO VIÊN – BẢN QUY ĐỔI

# 100 điểm

06 trục · 38 dòng tiêu chí chấm

[Sao chép danh mục KPI để dán vào Excel]

[Sao chép bảng tổng hợp 06 trục]

Bảng danh mục chứa 38 dòng chỉ số, công thức tính điểm hợp lệ; bảng tổng hợp tự tính điểm quy đổi theo từng trục. Các công thức sử dụng dấu chấm phẩy của Excel thiết lập tiếng Việt.

## Bảng kiểm tra phân bổ điểm

| Trục | Số chỉ số | Điểm tối đa |
|--------|--------|--------|

Lựa chọn hiện tại không khả dụng.

| **Mã** | **Tiêu chí** | **Điểm** |
|--------|--------|--------|

## Hướng dẫn hoàn tất trong Excel

1. Tạo sheet tên **KPI**, nhấn nút sao chép danh mục ở trên và dán vào ô A1.
2. Tạo sheet **TONG\_HOP**, sao chép bảng tổng hợp 06 trục vào ô A1.
3. Giáo viên nhập điểm ở cột H, Ban giám hiệu nhập điểm ở cột I; với chỉ số không thuộc đối tượng áp dụng, ghi `KAD` tại cột G. Bảng sẽ tính điểm tại cột J.
4. Kiểm tra đủ minh chứng và điểm chấm của các chỉ số áp dụng trước khi sử dụng tổng điểm quy đổi. Lưu bảng thành tệp `.xlsx`.

**Lưu ý quan trọng:** Bảng chấm điểm gốc có 37 nội dung được nêu, nhưng ảnh bạn cung cấp không thể hiện tiêu chí số 3; đồng thời mục 4 được tách thành 4.1–4.3. Do đó bản này gồm 38 dòng chấm điểm xác định từ các trang đã gửi. Các chỉ số về Đảng, Đoàn, hội thi và nhiệm vụ chưa phát sinh phải được xử lý theo nguyên tắc áp dụng công bằng; không chấm 0 một cách máy móc.

Đây là **bản dự thảo hoàn chỉnh về nội dung và phân bổ 100 điểm**. Trước khi chính thức sử dụng để xếp loại viên chức, nhà trường cần thống nhất cách quy đổi tiêu chí không áp dụng, điều kiện khống chế tại nhóm VIII và thẩm quyền phê duyệt thang KPI mới.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

hoàn thành sản phẩm đi chứ

---

ASSISTANT

Bạn nói đúng, bạn cần **file Excel hoàn chỉnh**, không phải thêm một bản hướng dẫn sao chép. Mình sẽ làm sản phẩm KPI 06 trục – 100 điểm từ các tài liệu đã gửi, có phiếu chấm, công thức tổng hợp và phần minh chứng; đồng thời kiểm tra những tiêu chí chưa đủ dữ liệu trước khi bàn giao.

---

ASSISTANT

Mình đã kiểm tra lại phép phân bổ: **38 dòng chỉ số đang có dữ liệu, cộng đúng 100 điểm** theo 06 trục (25–15–10–15–15–20). Mình đang ghép phần nhập điểm và công thức kiểm tra tiêu chí “không áp dụng” để bảng không tự báo đủ điểm khi giáo viên chưa được chấm hết.

---

ASSISTANT

Mình đã hoàn tất phần thiết kế sổ chấm điểm: giáo viên nhập điểm, BGH xác nhận, bảng tự cộng từng trục và báo **“CHƯA ĐỦ”** nếu còn chỉ số chưa chấm. Mình cũng tách bảng thưởng–trừ theo quy định thi đua gốc để không cộng trùng vào thang 100 điểm.

---

ASSISTANT

Mình hoàn thiện bảng **KPI giáo viên Trường Mầm non An Bình A – 06 trục, 100 điểm**, sử dụng bộ tiêu chí thi đua năm học 2025–2026 mà bạn đã gửi.

Bản này gồm danh mục KPI, phiếu giáo viên tự chấm, cột Ban giám hiệu đánh giá, minh chứng, công thức tổng hợp 06 trục, bảng điểm thưởng – trừ và bảng tổng hợp giáo viên toàn trường.

Bạn có thể sử dụng công cụ dưới đây để tạo tệp Excel `.xlsx` trực tiếp.

## Tạo bảng KPI giáo viên – Excel 06 trục, 100 điểm

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="kpi-ab-tool" class="w-full space-y-4 text-base">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="flex items-center justify-between gap-3">
      <div>
        <div class="font-semibold text-lg">KPI giáo viên Mầm non An Bình A</div>
        <div class="text-sm opacity-65">06 trục · 38 chỉ số · 100 điểm</div>
      </div>
      <div class="text-2xl font-semibold tabular-nums">100</div>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <label class="text-sm space-y-1"><span class="opacity-70">Quý đánh giá</span><select id="ab-quarter" class="w-full rounded-lg border bg-transparent p-2"><option value="I">Quý I</option><option value="II">Quý II</option><option value="III" selected>Quý III</option><option value="IV">Quý IV</option></select></label>
      <label class="text-sm space-y-1"><span class="opacity-70">Năm đánh giá</span><input id="ab-year" type="number" value="2026" min="2025" max="2100" class="w-full rounded-lg border bg-transparent p-2"/></label>
    </div>
    <label class="block text-sm space-y-1"><span class="opacity-70">Họ và tên giáo viên (có thể bổ sung sau trong Excel)</span><input id="ab-name" type="text" placeholder="Nhập tên giáo viên" class="w-full rounded-lg border bg-transparent p-2"/></label>
    <label class="block text-sm space-y-1"><span class="opacity-70">Nhóm/lớp</span><input id="ab-class" type="text" placeholder="Ví dụ: Mẫu giáo 5 tuổi" class="w-full rounded-lg border bg-transparent p-2"/></label>
    <button id="ab-download" class="w-full rounded-xl py-3 px-4 font-semibold text-white bg-slate-800 hover:bg-slate-700 cursor-pointer">↓ Tạo và tải file KPI Excel (.xlsx)</button>
    <div id="ab-status" aria-live="polite" class="text-sm opacity-75">Tệp sẽ có 6 trang tính, bố cục và công thức tính điểm.</div>
  </div>
  <div class="rounded-xl border overflow-hidden">
    <div class="p-3 font-medium text-sm">Phân bổ KPI</div>
    <div id="ab-preview" class="divide-y text-sm"></div>
  </div>
  <p class="text-xs opacity-65">Bản quy đổi nội bộ theo tiêu chí thi đua 2025–2026. Chỉ số chưa áp dụng có ký hiệu KAD và được tính lại trọng số trong trục. Trước khi xếp loại chính thức, cần xác nhận điều kiện khống chế và ngưỡng xếp loại của nhà trường.</p>
</div>
<script>
(function(){
const root=document.getElementById("kpi-ab-tool");
if(!root||root.dataset.ready)return;root.dataset.ready="1";
const axes=[
["Kết quả chăm sóc, giáo dục trẻ",25],
["Quy trình chuyên môn, hồ sơ và kiểm định",15],
["CNTT, đổi mới sáng tạo và chuyển đổi số",10],
["Kỷ luật, đạo đức, Đảng và đoàn thể",15],
["Phát triển trẻ và an sinh xã hội",15],
["An ninh, an toàn và phòng ngừa vi phạm",20]
];
const d=[
[1,"4.1","Trẻ suy dinh dưỡng nhẹ cân","Tỷ lệ ≤1,25%",5,"Bảng tổng hợp dinh dưỡng","Có","Đánh giá theo số liệu được xác nhận"],
[1,"4.2","Trẻ suy dinh dưỡng thấp còi","Tỷ lệ <1,25%",4,"Bảng tổng hợp dinh dưỡng","Có",""],
[1,"4.3","Trẻ béo phì","Tỷ lệ ≤2%",4,"Bảng tổng hợp dinh dưỡng","Có",""],
[1,"5","Duy trì tỷ lệ chuyên cần","5 tuổi ≥95%; 4 tuổi ≥85%; 3 tuổi và nhà trẻ ≥80%",7,"Sổ điểm danh; thống kê chuyên cần","Có","Chọn mức theo nhóm tuổi"],
[1,"6","Tham gia các hội thi bắt buộc","Tham gia 100% hội thi được phân công theo kế hoạch",3,"Kế hoạch; danh sách tham gia","Có","Xem xét tiến độ và kỳ tổ chức"],
[1,"7","Thành tích hội thi cấp cơ sở","Đạt giải Nhất theo tiêu chí thi đua khi được phân công",2,"Quyết định công nhận thành tích","KAD","Áp dụng khi có hội thi và nhiệm vụ phù hợp"],
[2,"8","Hồ sơ theo dõi tài sản lớp","Theo dõi tài sản đầy đủ, đúng quy định",2,"Sổ tài sản; biên bản kiểm tra","Có",""],
[2,"9","Tăng đồ dùng, đồ chơi","Có tăng từ nguồn xã hội hóa hợp pháp so với đầu năm, không tính đồ được cấp",2,"Danh mục; đối chiếu đầu năm","Có","Không được vận động khoản thu trái quy định"],
[2,"10","Bảo quản thiết bị, đồ dùng, đồ chơi","Bảo quản tốt, vệ sinh và bảo đảm an toàn",2,"Biên bản kiểm tra thực tế","Có",""],
[2,"12","Lớp xanh, sạch, đẹp","Đạt tiêu chuẩn xanh, sạch, đẹp của nhà trường",2,"Phiếu kiểm tra; hình ảnh lớp","Có",""],
[2,"29","Kiểm định chất lượng giáo dục","Hoàn thành nhiệm vụ kiểm định được phân công",2,"Hồ sơ minh chứng; xác nhận BGH","Có",""],
[2,"30","Phổ cập giáo dục trẻ 5 tuổi","Hoàn thành nhiệm vụ phổ cập được phân công",2,"Hồ sơ phổ cập; xác nhận BGH","Có",""],
[2,"35","Công tác báo cáo","Đầy đủ, chính xác, kịp thời; đối chiếu quy định báo cáo trễ",2,"Nhật ký nộp báo cáo","Có","Báo cáo quá 2 ngày được xem là không báo cáo theo tài liệu gốc"],
[2,"37","Thể thức văn bản, báo cáo","Đúng thể thức Nghị định 30 đối với văn bản thuộc phạm vi áp dụng",1,"Văn bản, báo cáo kiểm tra","Có",""],
[3,"31","Ứng dụng CNTT trong giảng dạy","Ít nhất 01 bài/chủ đề",3,"Giáo án; file bài giảng","Có",""],
[3,"32","Đóng góp kho học liệu số","Ít nhất 02 nội dung/năm, theo tiến độ được giao",3,"Đường dẫn kho học liệu","Có",""],
[3,"33","Tin, bài website trường","Ít nhất 01 tin, bài/tháng",2,"Tin bài; xác nhận tiếp nhận","Có",""],
[3,"34","Công tác chuyển đổi số","Số hóa hồ sơ, cập nhật phần mềm và dữ liệu kịp thời",2,"Hồ sơ số; ghi nhận BGH","Có",""],
[4,"2","Điều kiện viên chức là đảng viên","Đáp ứng nội dung gốc khi thuộc đối tượng áp dụng",1,"Hồ sơ tổ chức Đảng","KAD","Không đánh giá bất lợi người không phải đảng viên"],
[4,"15","Không tự ý thu tiền phụ huynh","Không thu khi chưa được phân công",2,"Kiểm tra; phản ánh đã xác minh","Có",""],
[4,"16","Không làm thu ngoài quy định","Không thực hiện khoản thu trái quy định",2,"Chứng từ; kết quả kiểm tra","Có",""],
[4,"17","Không vận động thu sai qua Ban đại diện","Không phát động khoản thu trái quy định trong nhóm/lớp",2,"Biên bản; kết quả xác minh","Có",""],
[4,"18","Nhiệm vụ đảng viên","Hoàn thành tốt nhiệm vụ trở lên nếu là đảng viên",1,"Kết quả đánh giá Đảng","KAD","Không áp dụng ngoài đối tượng"],
[4,"19","Nhiệm vụ đoàn viên","Hoàn thành tốt nhiệm vụ nếu là đoàn viên",1,"Kết quả đánh giá Đoàn","KAD","Không áp dụng ngoài đối tượng"],
[4,"22","Đoàn kết và ứng xử","Không nhũng nhiễu, gây mất đoàn kết theo kết quả xác minh",2,"Biên bản; kết luận có thẩm quyền","Có","Không coi khiếu nại, tố cáo hợp pháp là vi phạm"],
[4,"28","Chấp hành nội quy, quy chế","Không vi phạm nội quy, quy chế làm việc và chuyên môn",4,"Nhật ký; biên bản kiểm tra","Có",""],
[5,"1","Thực hiện chỉ tiêu sĩ số","Nhà trẻ 8; MG 3 tuổi 10; MG 4 tuổi 12; MG 5 tuổi 14 trẻ/GV",5,"Danh sách trẻ; phân công giáo viên","Có","Căn cứ điều kiện, phân công và kết quả thực tế"],
[5,"13","Thực hiện chính sách hỗ trợ trẻ","Cung cấp kịp thời 100% thông tin trẻ thuộc diện hỗ trợ",5,"Danh sách và hồ sơ chính sách","Có","Có thể KAD nếu không có trường hợp phát sinh"],
[5,"14","Hỗ trợ trẻ hoàn cảnh đặc biệt","Phối hợp hỗ trợ theo nhiệm vụ được giao, đúng quy định",5,"Hồ sơ hỗ trợ; biên bản phối hợp","Có","Không ép buộc đóng góp"],
[6,"11","Bảo đảm trường, lớp an toàn","Đạt yêu cầu an toàn trường học theo quy định",4,"Biên bản kiểm tra an toàn","Có",""],
[6,"20","Chấp hành pháp luật","Không vi phạm pháp luật thuộc phạm vi tiêu chí gốc",2,"Kết quả xác minh có thẩm quyền","Có",""],
[6,"21","Đón, trả trẻ đúng quy định","Không tổ chức giữ trẻ trễ trái quy định",2,"Sổ đón, trả trẻ","Có",""],
[6,"23","Bảo vệ thông tin, bí mật nhà nước","Không làm lộ, lọt bí mật hoặc phát tán thông tin sai sự thật",2,"Bản cam kết; kết quả xác minh","Có",""],
[6,"24","Chấp hành pháp luật liên quan đến tổ chức tôn giáo","Không có hành vi vi phạm pháp luật được xác minh",1,"Kết luận có thẩm quyền","Có","Không đánh giá dựa trên niềm tin cá nhân"],
[6,"25","Ứng xử trên mạng xã hội","Không vi phạm quy định ứng xử, chia sẻ thông tin",2,"Kết quả kiểm tra, xác minh","Có",""],
[6,"26","Chấp hành quy định địa phương","Không vi phạm đã được xác minh",2,"Văn bản; kết quả xác minh","Có",""],
[6,"27","Phòng chống bạo lực học đường","Không bạo lực thể chất, tinh thần đối với trẻ hoặc đồng nghiệp",4,"Kết quả kiểm tra, xác minh","Có","Điều kiện nghiêm trọng cần xử lý riêng"],
[6,"36","Báo cáo sự việc bất thường","Báo cáo kịp thời các sự việc tại nhóm/lớp, tổ",1,"Nhật ký sự việc; báo cáo","Có",""]
];
const bonus=[
["Trừ điểm vi phạm quy chế làm việc","Lần","Trừ tối thiểu 01 điểm/nội dung/lần","Theo quy định gốc"],
["Trừ điểm vi phạm quy tắc ứng xử","Lần","Trừ 01 điểm/nội dung/lần; lần 2 không đạt tiêu chuẩn","Theo quy định gốc"],
["Xung phong dạy lớp nhà trẻ","Tháng","Cộng 0,5 điểm/tháng","Có phân công"],
["Đạt giải tập thể cấp cơ sở","Hội thi","Nhất 7; Nhì 5; Ba 3; Khuyến khích 1,5","Có quyết định"],
["Đạt giải cá nhân cấp cơ sở","Hội thi","Nhất 5; Nhì 3,5; Ba 2; Khuyến khích 1","Có quyết định"],
["Giải hội thi cấp trên","Hội thi","Thành phố gấp 2 cấp cơ sở; tỉnh gấp 2 thành phố","Theo quy định gốc"],
["Tham gia sự kiện, hội thi ngoài chuyên môn","Sự kiện","Cộng 0,5 điểm/người/sự kiện","Theo kế hoạch"],
["Vượt sĩ số nhà trẻ","Trẻ/tháng","Cộng 1 điểm/trẻ vượt/tháng; tối đa 5 điểm","Danh sách, xác nhận"],
["Vượt sĩ số mẫu giáo","Trẻ/tháng","Cộng 2 điểm/trẻ vượt/tháng; giảm sĩ số trừ tương ứng","Danh sách, xác nhận"],
["Đồ chơi, thiết bị từ XHH tăng tối thiểu 10%","Học kỳ","Cộng 2 điểm/học kỳ","Nguồn hợp lệ"],
["Trình độ đào tạo vượt chuẩn","Năm","Cộng 1 điểm/mức vượt chuẩn","Bằng cấp"],
["Học tập bồi dưỡng chuyên môn nghiệp vụ","Giấy","Cộng 1 điểm/giấy chứng nhận hoặc chứng chỉ","Theo tiêu chí"],
["Tổ trưởng, Bí thư chi đoàn","Năm","Tối đa 5 điểm/năm theo các điều kiện","Theo phân công"]
];
root.querySelector("#ab-preview").innerHTML=axes.map((a,i)=>'<div class="flex items-center justify-between gap-3 px-3 py-2"><span>Trục '+(i+1)+'. '+a[0]+'</span><span class="font-semibold whitespace-nowrap">'+a[1]+' điểm</span></div>').join('');
const E=s=>String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
function col(n){let a="";while(n){n--;a=String.fromCharCode(65+n%26)+a;n=Math.floor(n/26);}return a;}
function C(c,r,v,s=5,f=null){const ref=col(c)+r;let a='<c r="'+ref+'" s="'+s+'"';if(f!==null)return a+'><f>'+E(f)+'</f></c>';if(v===null||v===undefined||v==="")return a+'/>';if(typeof v==="number")return a+'><v>'+v+'</v></c>';return a+' t="inlineStr"><is><t xml:space="preserve">'+E(v)+'</t></is></c>';}
function R(n,items,h){return '<row r="'+n+'"'+(h?' ht="'+h+'" customHeight="1"':'')+'>'+items.map(x=>C(x[0],n,x[1],x[2]===undefined?5:x[2],x[3]===undefined?null:x[3])).join('')+'</row>';}
const A=(...v)=>v.map((x,i)=>[i+1,x,5]);
const Head=(n,values)=>R(n,values.map((v,i)=>[i+1,v,3]),44);
const Txt=(a,b)=>R(a,[[1,b,1]],38);
function sheet(rows,widths,opts={}){
let cols=widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join('');
let pane=opts.freeze?'<sheetViews><sheetView workbookViewId="0"><pane ySplit="'+opts.freeze+'" topLeftCell="A'+(opts.freeze+1)+'" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>':'<sheetViews><sheetView workbookViewId="0"/></sheetViews>';
let merges=opts.merge?'<mergeCells count="1"><mergeCell ref="A1:'+col(widths.length)+'1"/></mergeCells>':'';
let filters=opts.filter?'<autoFilter ref="'+opts.filter+'"/>':'';
let validation=opts.validations||"";
return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'+pane+'<sheetFormatPr defaultRowHeight="21"/><cols>'+cols+'</cols><sheetData>'+rows.join('')+'</sheetData>'+merges+filters+validation+'<pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.2" footer="0.2"/><pageSetup orientation="landscape" paperSize="9"/></worksheet>';
}
const styles='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="4"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="17"/><color rgb="FF17365A"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FF17365A"/><name val="Calibri"/></font></fonts><fills count="7"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDCEBF7"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FF174F78"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF0C3"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE5F3E8"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFE4DB"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD9E1EB"/></left><right style="thin"><color rgb="FFD9E1EB"/></right><top style="thin"><color rgb="FFD9E1EB"/></top><bottom style="thin"><color rgb="FFD9E1EB"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="11"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="center" horizontal="center"/></xf><xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf numFmtId="2" fontId="3" fillId="5" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="2" fontId="3" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf numFmtId="10" fontId="3" fillId="5" borderId="1" xfId="0"/><xf numFmtId="0" fontId="3" fillId="6" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1"/></xf><xf numFmtId="0" fontId="3" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
function buildSheets(name,klass,quarter,year){
const notes=[
["Nguồn dữ liệu","Tiêu chí chấm điểm thi đua viên chức Trường Mầm non An Bình A năm học 2025–2026, kèm Quyết định 38/QĐ-MNABA ngày 01/12/2025."],
["Phạm vi","Bảng KPI giáo viên theo 06 trục, tổng 100 điểm; là phương án quy đổi nội bộ chờ thống nhất phê duyệt."],
["Đối chiếu","38 dòng KPI từ tài liệu hiện có; số thứ tự 3 không xuất hiện ở các trang được cung cấp; nội dung 4 gồm 4.1, 4.2, 4.3."],
["Cách nhập","CHAM_DIEM: điền tên giáo viên, lớp; cột G Có/KAD; H giáo viên tự chấm; I BGH chấm; K minh chứng thực tế."],
["Thang điểm","Nhập điểm từ 0 đến điểm tối đa của từng tiêu chí ở cột E. Các ô điểm vượt ngưỡng sẽ hiển thị LỖI."],
["Tiêu chí KAD","Không áp dụng phải có lý do và xác nhận; điểm trục = điểm đã chấm x tổng điểm trục / tổng điểm chuẩn các KPI áp dụng."],
["Kiểm soát chưa chấm","TONG_HOP hiển thị CHƯA ĐỦ nếu có bất kỳ chỉ số Có nào chưa nhập điểm quản lý hợp lệ."],
["Kiểm soát toàn trục KAD","Nếu toàn bộ một trục KAD, hệ thống hiện CẦN PHÂN BỔ; không được tự ý chuyển điểm qua trục khác."],
["Điểm thưởng/trừ","Bảng THUONG_TRU lưu nội dung điểm thưởng, điểm trừ theo quy định gốc; không cộng trực tiếp vào tổng KPI 100."],
["Khống chế xếp loại","Vi phạm nhóm VIII và các điều kiện khống chế khác phải được xử lý riêng, không tự động bù bằng điểm trục khác."],
["Đánh giá theo quý","Chỉ chấm các nhiệm vụ đã đến hạn hoặc phát sinh trong quý. Các chỉ tiêu năm cần xét tiến độ và nhiệm vụ được giao."],
["Đối tượng","Tiêu chí dành cho đảng viên, đoàn viên hay hội thi chưa có nhiệm vụ có thể chọn KAD, không máy móc chấm 0."],
["Tính công bằng","Chỉ tiêu liên quan sĩ số, dinh dưỡng, hoàn cảnh trẻ cần xét theo điều kiện thực tế và trách nhiệm được phân công."],
["Bảo vệ trẻ","Các sự việc an toàn, bạo lực đối với trẻ phải được xử lý theo quy định chuyên ngành, không chỉ bằng điểm KPI."],
["Xếp loại","Điểm 100 không tự suy ra Hoàn thành xuất sắc/tốt/chưa hoàn thành nếu chưa có ngưỡng xếp loại được phê duyệt."],
["Hiệu lực tiêu chí","Tiêu chí nguồn thuộc năm học 2025–2026; nếu áp dụng quý của năm học khác, cần cập nhật văn bản thi đua mới."],
["Nguồn nội dung","Tham chiếu các ảnh trang 3–10 do nhà trường cung cấp. Không tự bổ sung tiêu chí gốc số 3 đang thiếu."]
];
let h=[Txt(1,"HƯỚNG DẪN SỬ DỤNG BỘ KPI GIÁO VIÊN"),R(3,[[1,"TRƯỜNG",10],[2,"MẦM NON AN BÌNH A",5]]),R(4,[[1,"KỲ ĐÁNH GIÁ",10],[2,"Quý "+quarter+" / "+year,5]]),Head(6,["Nội dung","Hướng dẫn / quy định"]),...notes.map((n,i)=>R(7+i,[[1,n[0],10],[2,n[1],5]],i===0?48:50))];
let catalog=[Txt(1,"DANH MỤC KPI GIÁO VIÊN – 06 TRỤC / 100 ĐIỂM"),R(3,[[1,"Nguồn: Tiêu chí thi đua năm học 2025–2026; điểm là phương án quy đổi nội bộ",2]]),Head(7,["Trục","Mã tiêu chí","Nội dung KPI","Chỉ tiêu cần đạt","Điểm tối đa","Minh chứng theo quy định","Mặc định","Lưu ý / điều kiện"])];
for(let i=0;i<d.length;i++){let z=d[i];catalog.push(R(8+i,[[1,z[0]],[2,z[1]],[3,z[2]],[4,z[3]],[5,z[4],6],[6,z[5]],[7,z[6]],[8,z[7]]],44));}
catalog.push(R(46,[[1,"TỔNG",7],[5,100,7]]));
let scoring=[Txt(1,"PHIẾU CHẤM KPI GIÁO VIÊN – QUÝ "+quarter+" / "+year),R(2,[[1,"Điền cột G, H, I, K, L; cột J tự tính điểm hợp lệ. Chưa chấm sẽ báo CHƯA ĐỦ.",2]]),R(3,[[1,"Họ và tên",10],[2,name,4],[3,"Nhóm/lớp",10],[4,klass,4],[5,"Quý",10],[6,quarter,4],[7,"Năm",10],[8,year,4]],29),R(5,[[1,"Chấm theo minh chứng; KAD cần có lý do. Điểm thưởng–trừ và điều kiện khống chế theo dõi riêng.",2]]),Head(7,["Trục","Mã gốc","Nội dung KPI","Chỉ tiêu cần đạt","Điểm tối đa","Minh chứng yêu cầu","Có/KAD","GV tự chấm","BGH chấm","Điểm hợp lệ","Minh chứng thực tế","Ghi chú / lý do KAD"])];
for(let i=0;i<d.length;i++){const z=d[i],r=8+i;const f='IF(G'+r+'="KAD","",IF(I'+r+'="","",IF(AND(ISNUMBER(I'+r+'),I'+r+'>=0,I'+r+'<=E'+r+'),I'+r+',"LỖI ĐIỂM")))';scoring.push(R(r,[[1,z[0]],[2,z[1]],[3,z[2]],[4,z[3]],[5,z[4],7],[6,z[5]],[7,z[6],4],[8,"",4],[9,"",4],[10,null,6,f],[11,"",4],[12,z[7],4]],46));}
scoring.push(R(46,[[1,"TỔNG ĐIỂM CHUẨN",7],[5,null,7,"SUM(E8:E45)"],[10,null,6,"SUM(J8:J45)"]]));
scoring.push(R(48,[[1,"Lưu ý",10],[2,"Không sử dụng tổng điểm gốc này để xếp loại; điểm KPI 100 phải xem tại sheet TONG_HOP.",9]]));
const scoreA="CHAM_DIEM!$A$8:$A$45",scoreE="CHAM_DIEM!$E$8:$E$45",scoreG="CHAM_DIEM!$G$8:$G$45",scoreI="CHAM_DIEM!$I$8:$I$45",scoreJ="CHAM_DIEM!$J$8:$J$45";
let summary=[Txt(1,"TỔNG HỢP KPI 06 TRỤC – THANG 100 ĐIỂM"),R(3,[[1,"Giáo viên",10],[2,null,5,"CHAM_DIEM!B3"],[3,"Nhóm/lớp",10],[4,null,5,"CHAM_DIEM!D3"],[5,"Quý",10],[6,null,5,"CHAM_DIEM!F3"],[7,"Năm",10],[8,null,5,"CHAM_DIEM!H3"]]),R(5,[[1,"Chỉ xếp loại khi đủ điểm, xác minh KAD, điều kiện khống chế và có phê duyệt.",2]]),Head(7,["Trục","Tên trục đánh giá","Điểm tối đa","Điểm chuẩn có áp dụng","BGH đã chấm","Số KPI áp dụng","Số KPI hợp lệ","Điểm quy đổi","Tỷ lệ đạt","Nhận xét"])];
for(let j=0;j<axes.length;j++){let r=8+j,a=axes[j];let fD=`SUMIFS(${scoreE},${scoreA},A${r},${scoreG},"Có")`,fE=`SUMIFS(${scoreJ},${scoreA},A${r},${scoreG},"Có")`,fF=`COUNTIFS(${scoreA},A${r},${scoreG},"Có")`,fG=`SUMPRODUCT((${scoreA}=A${r})*(${scoreG}="Có")*(ISNUMBER(${scoreI}))*(${scoreI}>=0)*(${scoreI}<=${scoreE}))`,fH=`IF(F${r}=0,"KAD",IF(G${r}<F${r},"CHƯA ĐỦ",IF(D${r}=0,"CHƯA ĐỦ",ROUND(E${r}*C${r}/D${r},2))))`;summary.push(R(r,[[1,j+1],[2,a[0]],[3,a[1],7],[4,null,6,fD],[5,null,6,fE],[6,null,6,fF],[7,null,6,fG],[8,null,6,fH],[9,null,8,`IF(ISNUMBER(H${r}),H${r}/C${r},"")`],[10,"",4]],42));}
summary.push(R(14,[[1,"TỔNG",7],[2,"KPI 06 trục",7],[3,null,7,"SUM(C8:C13)"],[8,null,7,'IF(COUNTIF(H8:H13,"KAD")>0,"CẦN PHÂN BỔ",IF(COUNT(H8:H13)<6,"CHƯA ĐỦ",ROUND(SUM(H8:H13),2)))']]));
summary.push(R(17,[[1,"Điều kiện nhóm VIII",10],[2,"Chưa xác minh",4]]));
summary.push(R(18,[[1,"Đề xuất xếp loại",10],[2,"Chờ hội đồng đánh giá",4]]));
summary.push(R(19,[[1,"Ghi chú",10],[2,"KPI này là bản quy đổi phục vụ quản trị, không thay thế cơ chế đánh giá bắt buộc của cấp có thẩm quyền.",5]],48));
let awards=[Txt(1,"THEO DÕI ĐIỂM THƯỞNG – TRỪ THEO TIÊU CHÍ GỐC"),R(3,[[1,"Không cộng tự động bảng này vào KPI 100 điểm; tránh cộng hoặc trừ lặp một hành vi.",9]]),Head(7,["Nội dung","Chu kỳ","Quy định điểm gốc","Điều kiện","Số lượng","Điểm thực tế","Minh chứng"])];
bonus.forEach((z,i)=>awards.push(R(8+i,[[1,z[0]],[2,z[1]],[3,z[2]],[4,z[3]],[5,"",4],[6,"",4],[7,"",4]],50)));
let staff=[Txt(1,"TỔNG HỢP KPI GIÁO VIÊN TOÀN TRƯỜNG"),R(3,[[1,"Dòng đầu tự liên kết từ phiếu CHAM_DIEM; các dòng sau nhập kết quả từng giáo viên.",2]]),Head(7,["STT","Họ và tên","Nhóm/lớp","Quý","Năm","Trục 1","Trục 2","Trục 3","Trục 4","Trục 5","Trục 6","Tổng KPI","Đề xuất xếp loại","Điều kiện / ghi chú"])];
for(let i=0;i<40;i++){let r=8+i;if(i===0){staff.push(R(r,[[1,1],[2,null,5,"CHAM_DIEM!B3"],[3,null,5,"CHAM_DIEM!D3"],[4,null,5,"CHAM_DIEM!F3"],[5,null,5,"CHAM_DIEM!H3"],...[0,1,2,3,4,5].map((_,k)=>[6+k,null,6,"TONG_HOP!H"+(8+k)]),[12,null,6,"TONG_HOP!H14"],[13,"",4],[14,"",4]]));}else{staff.push(R(r,[[1,i+1],...[2,3,4,5,6,7,8,9,10,11].map(k=>[k,"",4]),[12,null,6,`IF(COUNT(F${r}:K${r})=6,ROUND(SUM(F${r}:K${r}),2),"")`],[13,"",4],[14,"",4]]));}}
const validation='<dataValidations count="2"><dataValidation type="list" allowBlank="0" showErrorMessage="1" error="Chọn Có hoặc KAD." sqref="G8:G45"><formula1>"Có,KAD"</formula1></dataValidation><dataValidation type="custom" allowBlank="1" showErrorMessage="1" error="Điểm phải nằm trong khoảng từ 0 đến điểm tối đa." sqref="H8:I45"><formula1>AND(OR(H8="",ISNUMBER(H8)),OR(H8="",AND(H8&gt;=0,H8&lt;=$E8)))</formula1></dataValidation></dataValidations>';
return [
sheet(h,[34,114],{merge:true}),
sheet(catalog,[9,12,43,56,12,40,13,42],{merge:true,freeze:7,filter:"A7:H45"}),
sheet(scoring,[9,12,43,56,13,43,13,14,14,15,37,43],{merge:true,freeze:7,filter:"A7:L45",validations:validation}),
sheet(summary,[14,43,16,21,19,16,16,19,15,35],{merge:true,freeze:7}),
sheet(awards,[43,15,53,44,18,19,38],{merge:true,freeze:7}),
sheet(staff,[9,30,23,13,13,13,13,13,13,13,13,17,26,38],{merge:true,freeze:7})
];
}
function bytes(str){return new TextEncoder().encode(str);}
function crc32(b){let c=-1;for(let i=0;i<b.length;i++){c^=b[i];for(let k=0;k<8;k++)c=(c>>>1)^(0xEDB88320&-(c&1));}return(c^(-1))>>>0;}
const w16=x=>[x&255,(x>>>8)&255],w32=x=>[x&255,(x>>>8)&255,(x>>>16)&255,(x>>>24)&255];
function makeZip(items){
let locals=[],centrals=[],offset=0;
for(const [filename,contents] of items){
const fn=bytes(filename),data=bytes(contents),crc=crc32(data);
const lh=Uint8Array.from([...w32(0x04034b50),...w16(20),...w16(0x0800),...w16(0),...w16(0),...w16(0),...w32(crc),...w32(data.length),...w32(data.length),...w16(fn.length),...w16(0)]);
locals.push(lh,fn,data);
const ch=Uint8Array.from([...w32(0x02014b50),...w16(20),...w16(20),...w16(0x0800),...w16(0),...w16(0),...w16(0),...w32(crc),...w32(data.length),...w32(data.length),...w16(fn.length),...w16(0),...w16(0),...w16(0),...w16(0),...w32(0),...w32(offset)]);
centrals.push(ch,fn);offset+=lh.length+fn.length+data.length;
}
const cdlen=centrals.reduce((n,v)=>n+v.length,0),end=Uint8Array.from([...w32(0x06054b50),...w16(0),...w16(0),...w16(items.length),...w16(items.length),...w32(cdlen),...w32(offset),...w16(0)]);
return new Blob([...locals,...centrals,end],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
}
function generate(){
const quarter=root.querySelector("#ab-quarter").value,year=Number(root.querySelector("#ab-year").value)||2026,name=root.querySelector("#ab-name").value.trim(),klass=root.querySelector("#ab-class").value.trim();
const sheets=buildSheets(name,klass,quarter,year);
const nms=["HUONG_DAN","DANH_MUC","CHAM_DIEM","TONG_HOP","THUONG_TRU","TONG_HOP_TRUONG"];
const main="http://schemas.openxmlformats.org/spreadsheetml/2006/main",rel="http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const wb='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="'+main+'" xmlns:r="'+rel+'"><bookViews><workbookView activeTab="2"/></bookViews><sheets>'+nms.map((n,i)=>'<sheet name="'+n+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join('')+'</sheets><calcPr calcId="191029" calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>';
const rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+nms.map((n,i)=>'<Relationship Id="rId'+(i+1)+'" Type="'+rel+'/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join('')+'<Relationship Id="rId7" Type="'+rel+'/styles" Target="styles.xml"/></Relationships>';
const types='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+sheets.map((_,i)=>'<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('')+'</Types>';
const parts=[
["[Content_Types].xml",types],
["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'+rel+'/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
["xl/workbook.xml",wb],
["xl/_rels/workbook.xml.rels",rels],
["xl/styles.xml",styles],
...sheets.map((s,i)=>["xl/worksheets/sheet"+(i+1)+".xml",s])
];
return {blob:makeZip(parts),name:"KPI_Giao_vien_An_Binh_A_6_truc_100_diem_Quy_"+quarter+"_"+year+".xlsx"};
}
root.querySelector("#ab-download").addEventListener("click",function(){
const status=root.querySelector("#ab-status");
try{
this.disabled=true;status.textContent="Đang tạo sổ Excel với công thức và 6 trang tính…";
const result=generate(),url=URL.createObjectURL(result.blob);
const a=document.createElement("a");a.href=url;a.download=result.name;a.style.display="none";document.body.appendChild(a);a.click();a.remove();
status.textContent="Đã gửi yêu cầu tải file: "+result.name+". Bạn có thể mở bằng Microsoft Excel để chấm điểm.";
setTimeout(()=>URL.revokeObjectURL(url),30000);
}catch(e){status.textContent="Không thể xuất tệp trong môi trường hiện tại: "+String(e.message||e);}
finally{this.disabled=false;}
});
})();
</script>

```

**Lưu ý khi đưa vào sử dụng chính thức:** Đây là phương án quy đổi 100 điểm đã thiết kế theo các tiêu chí thi đua được cung cấp. Nhà trường cần thống nhất trọng số, phương pháp xử lý tiêu chí không áp dụng và điều kiện khống chế trước khi phê duyệt áp dụng cho đánh giá, xếp loại giáo viên.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

xuất file execl

---

ASSISTANT

Mình sẽ xuất file Excel KPI giáo viên 06 trục – 100 điểm, có các sheet danh mục tiêu chí, chấm điểm, tổng hợp tự động và theo dõi điểm thưởng–trừ. Mình sẽ kiểm tra lại công thức và tổng điểm trước khi gửi bạn.

---

ASSISTANT

Mình đã chuẩn bị **bảng KPI giáo viên Trường Mầm non An Bình A – 06 trục, 100 điểm**, quy đổi từ bộ tiêu chí thi đua năm học 2025–2026.

Bảng Excel gồm 6 sheet: Hướng dẫn, Danh mục KPI, Chấm điểm giáo viên, Tổng hợp 06 trục, Điểm thưởng–trừ và Tổng hợp toàn trường.

## Xuất Excel KPI giáo viên – 06 trục, 100 điểm

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="export-kpi-mnab" class="w-full space-y-3">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="flex items-center gap-3">
      <div class="rounded-lg bg-emerald-100 text-emerald-700 p-3">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 7h8M8 11h8M8 15h3M15 15l-4 5M11 15l4 5"/></svg>
      </div>
      <div class="min-w-0">
        <div class="font-semibold">KPI_Giao_vien_An_Binh_A.xlsx</div>
        <div class="text-sm opacity-65">06 sheet · 38 chỉ số · 100 điểm · Công thức tự động</div>
      </div>
    </div>
    <button id="kpi-get-xlsx" type="button" class="w-full p-3 rounded-xl font-semibold text-white bg-emerald-700 hover:bg-emerald-800 cursor-pointer">Tải file Excel (.xlsx)</button>
    <div id="kpi-export-status" class="text-sm opacity-70" role="status">Nhấn nút để tạo và lưu file Excel về thiết bị.</div>
  </div>
</div>
<script>
(function(){
const node=document.getElementById('export-kpi-mnab');
if(!node||node.dataset.init)return;
node.dataset.init='yes';
const AX=[
["Kết quả chăm sóc, giáo dục trẻ",25],
["Quy trình chuyên môn, hồ sơ, thiết bị và kiểm định",15],
["Ứng dụng CNTT, đổi mới sáng tạo và chuyển đổi số",10],
["Kỷ luật, trách nhiệm, đạo đức, Đảng và đoàn thể",15],
["Phát triển trẻ, an sinh xã hội và phối hợp hỗ trợ trẻ",15],
["An ninh, an toàn trường học và phòng ngừa vi phạm",20]
];
const D=[
[1,"4.1","Trẻ suy dinh dưỡng nhẹ cân","Tỷ lệ ≤1,25%",5,"Bảng tổng hợp dinh dưỡng","Có"],
[1,"4.2","Trẻ suy dinh dưỡng thấp còi","Tỷ lệ <1,25%",4,"Bảng tổng hợp dinh dưỡng","Có"],
[1,"4.3","Trẻ béo phì","Tỷ lệ ≤2%",4,"Bảng tổng hợp dinh dưỡng","Có"],
[1,"5","Tỷ lệ chuyên cần","5 tuổi 95%; 4 tuổi 85%; 3 tuổi và nhà trẻ 80%",7,"Sổ điểm danh, bảng chuyên cần","Có"],
[1,"6","Hội thi bắt buộc","Tham gia đầy đủ theo kế hoạch, phân công",3,"Kế hoạch, danh sách hội thi","Có"],
[1,"7","Thành tích hội thi cấp cơ sở","Giải Nhất theo tiêu chí gốc khi được phân công",2,"Quyết định khen thưởng","KAD"],
[2,"8","Theo dõi tài sản lớp","Có hồ sơ theo dõi tài sản đúng quy định",2,"Sổ tài sản","Có"],
[2,"9","Bổ sung đồ dùng đồ chơi","Có tăng từ nguồn xã hội hóa hợp pháp, tự nguyện",2,"Danh mục, biên bản đối chiếu","Có"],
[2,"10","Bảo quản đồ dùng đồ chơi","Bảo quản tốt, vệ sinh và an toàn",2,"Biên bản kiểm tra thực tế","Có"],
[2,"12","Lớp xanh sạch đẹp","Đạt tiêu chuẩn nhà trường",2,"Phiếu kiểm tra, hình ảnh","Có"],
[2,"29","Kiểm định chất lượng","Hoàn thành nhiệm vụ được phân công",2,"Hồ sơ kiểm định","Có"],
[2,"30","Phổ cập giáo dục trẻ 5 tuổi","Hoàn thành nhiệm vụ được phân công",2,"Hồ sơ phổ cập","Có"],
[2,"35","Báo cáo đầy đủ chính xác kịp thời","Thực hiện theo thời hạn, điều kiện của tiêu chí thi đua",2,"Nhật ký nộp báo cáo","Có"],
[2,"37","Thể thức văn bản","Đúng Nghị định 30 khi thuộc phạm vi áp dụng",1,"Văn bản, báo cáo","Có"],
[3,"31","Ứng dụng CNTT trong giảng dạy","Ít nhất 01 bài/chủ đề",3,"Giáo án, file trình chiếu","Có"],
[3,"32","Kho học liệu số","Ít nhất 02 nội dung/năm theo tiến độ",3,"Đường dẫn học liệu","Có"],
[3,"33","Tin bài website","Ít nhất 01 tin bài/tháng",2,"Tin bài, xác nhận tiếp nhận","Có"],
[3,"34","Chuyển đổi số","Số hóa hồ sơ, cập nhật dữ liệu kịp thời",2,"Hồ sơ số, phần mềm","Có"],
[4,"2","Điều kiện viên chức là đảng viên","Đáp ứng điều kiện của tiêu chí gốc khi thuộc đối tượng",1,"Hồ sơ Đảng","KAD"],
[4,"15","Không tự ý thu tiền","Không thu khi chưa được phân công",2,"Kết quả kiểm tra","Có"],
[4,"16","Không thu ngoài quy định","Không phát sinh khoản thu trái quy định",2,"Chứng từ, kiểm tra","Có"],
[4,"17","Không phát động thu sai","Không thu trái quy định thông qua ban đại diện cha mẹ trẻ",2,"Biên bản xác minh","Có"],
[4,"18","Nhiệm vụ đảng viên","Hoàn thành tốt trở lên nếu là đảng viên",1,"Kết quả đánh giá Đảng","KAD"],
[4,"19","Nhiệm vụ đoàn viên","Hoàn thành tốt nếu thuộc Đoàn",1,"Kết quả đánh giá Đoàn","KAD"],
[4,"22","Ứng xử và đoàn kết nội bộ","Không nhũng nhiễu, gây mất đoàn kết được xác minh",2,"Kết quả xác minh","Có"],
[4,"28","Chấp hành nội quy quy chế","Không vi phạm nội quy, quy chế chuyên môn, làm việc",4,"Biên bản kiểm tra","Có"],
[5,"1","Sĩ số theo giáo viên","Nhà trẻ 8; MG 3 tuổi 10; MG 4 tuổi 12; MG 5 tuổi 14 trẻ/GV",5,"Danh sách trẻ, phân công","Có"],
[5,"13","Chính sách hỗ trợ trẻ","Cung cấp 100% hồ sơ, thông tin kịp thời",5,"Hồ sơ chính sách","Có"],
[5,"14","Hỗ trợ trẻ hoàn cảnh đặc biệt","Tham gia hỗ trợ theo nhiệm vụ và điều kiện thực tế",5,"Hồ sơ hỗ trợ","Có"],
[6,"11","An toàn trường lớp","Đáp ứng tiêu chuẩn an toàn theo quy định",4,"Biên bản kiểm tra an toàn","Có"],
[6,"20","Chấp hành pháp luật","Không có vi phạm đã được xác minh",2,"Kết luận có thẩm quyền","Có"],
[6,"21","Đón trả trẻ đúng quy định","Không giữ trẻ trễ trái quy định",2,"Sổ đón trả trẻ","Có"],
[6,"23","Bảo mật thông tin","Không làm lộ bí mật hoặc phát tán thông tin sai sự thật",2,"Kết quả xác minh","Có"],
[6,"24","Tuân thủ pháp luật về hoạt động tôn giáo","Chỉ xem xét vi phạm pháp luật được xác minh, không đánh giá niềm tin",1,"Kết luận có thẩm quyền","Có"],
[6,"25","Ứng xử trên mạng xã hội","Không vi phạm quy định liên quan",2,"Kết quả xác minh","Có"],
[6,"26","Chấp hành quy định địa phương","Không có vi phạm được xác minh",2,"Văn bản, kết quả xác minh","Có"],
[6,"27","Không bạo lực học đường","Không bạo lực thể chất, tinh thần đối với trẻ, đồng nghiệp",4,"Kết quả kiểm tra","Có"],
[6,"36","Báo cáo việc bất thường","Báo cáo kịp thời sự việc tại nhóm, lớp, tổ",1,"Nhật ký sự việc","Có"]
];
const BT=[
["Vi phạm quy chế làm việc","Trừ tối thiểu 01 điểm/nội dung/lần"],
["Vi phạm quy tắc ứng xử","Trừ 01 điểm/nội dung/lần; lần 2 không đạt tiêu chuẩn"],
["Xung phong dạy lớp nhà trẻ","Cộng 0,5 điểm/tháng"],
["Giải tập thể cấp cơ sở","Nhất 7; Nhì 5; Ba 3; Khuyến khích 1,5"],
["Giải cá nhân cấp cơ sở","Nhất 5; Nhì 3,5; Ba 2; Khuyến khích 1"],
["Hội thi cấp trên","Thành phố nhân 2 cấp cơ sở; tỉnh nhân 2 thành phố"],
["Sự kiện ngoài chuyên môn","Tham gia cộng 0,5 điểm/người/sự kiện"],
["Vượt sĩ số nhà trẻ","Cộng 1 điểm/trẻ/tháng, tối đa 5"],
["Vượt sĩ số mẫu giáo","Cộng 2 điểm/trẻ/tháng; giảm sĩ số trừ tương ứng"],
["Đồ dùng đồ chơi do XHH tăng tối thiểu 10%","Cộng 2 điểm/học kỳ"],
["Trình độ đào tạo vượt chuẩn","Cộng 1 điểm/mức vượt chuẩn"],
["Bồi dưỡng chuyên môn nghiệp vụ","Cộng 1 điểm/giấy chứng nhận hoặc chứng chỉ"],
["Tổ trưởng, Bí thư chi đoàn","Tối đa cộng 5 điểm/năm theo điều kiện"]
];
const x=s=>String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const col=n=>{let s="";while(n){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26)}return s};
function cell(c,r,v,style=0,formula){
let a='<c r="'+col(c)+r+'" s="'+style+'"';
if(formula!==undefined)return a+'><f>'+x(formula)+'</f></c>';
if(v===null||v===undefined||v==="")return a+'/>';
return typeof v==="number"?a+'><v>'+v+'</v></c>':a+' t="inlineStr"><is><t>'+x(v)+'</t></is></c>';
}
function row(r,vals,h){return '<row r="'+r+'"'+(h?' ht="'+h+'" customHeight="1"':'')+'>'+vals.map(v=>cell(v[0],r,v[1],v[2]||0,v[3])).join("")+'</row>'}
const vals=(r,a,style=0)=>row(r,a.map((v,i)=>[i+1,v,style]),r===6?39:31);
function sheet(rows,widths,freeze=0,filter=""){
let view=freeze?'<sheetViews><sheetView workbookViewId="0"><pane ySplit="'+freeze+'" topLeftCell="A'+(freeze+1)+'" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>':'<sheetViews><sheetView workbookViewId="0"/></sheetViews>';
return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'+view+'<sheetFormatPr defaultRowHeight="22"/><cols>'+widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join("")+'</cols><sheetData>'+rows.join("")+'</sheetData>'+(filter?'<autoFilter ref="'+filter+'"/>':'')+'<pageMargins left="0.3" right="0.3" top="0.4" bottom="0.4" header="0.2" footer="0.2"/></worksheet>';
}
const hdr=(r,arr)=>vals(r,arr,2);
const rEnd=7+D.length-1;
const H=[
vals(1,["HƯỚNG DẪN BỘ KPI GIÁO VIÊN MẦM NON AN BÌNH A – 06 TRỤC, 100 ĐIỂM"],1),
hdr(3,["Nội dung","Hướng dẫn"]),
...[
["Nguồn","Bộ tiêu chí thi đua viên chức 2025–2026, kèm Quyết định 38/QĐ-MNABA ngày 01/12/2025."],
["Tính chất","Phương án quy đổi KPI nội bộ trên thang 100 điểm; chưa thay thế thang điểm chính thức của cấp có thẩm quyền."],
["Cơ cấu","Trục 1: 25; Trục 2: 15; Trục 3: 10; Trục 4: 15; Trục 5: 15; Trục 6: 20."],
["Danh mục","38 dòng chỉ số có dữ liệu. Tiêu chí gốc số 3 không xuất hiện trong các trang đã cung cấp; nội dung 4 được tách thành 4.1–4.3."],
["Chấm điểm","Trong CHAM_DIEM, nhập Có hoặc KAD tại cột G; giáo viên tự chấm cột H; BGH chấm cột I, từ 0 đến điểm tối đa cột E."],
["Minh chứng","Nhập đường dẫn hoặc mô tả minh chứng tại cột K; ghi nhận xét và giải trình KAD ở cột L."],
["Chưa hoàn tất","TONG_HOP sẽ hiển thị CHƯA ĐỦ khi một chỉ số đang áp dụng chưa có điểm BGH hợp lệ."],
["KAD","Điểm của các KPI Có được quy đổi trong phạm vi từng trục; KAD cần được xác nhận và không được dùng để che giấu nhiệm vụ chưa hoàn thành."],
["Trục toàn KAD","Bảng hiển thị CẦN XEM XÉT nếu một trục không có nội dung nào áp dụng."],
["Điểm thưởng/trừ","THUONG_TRU theo dõi độc lập, không tự cộng điểm vượt 100 hay trừ lặp từ KPI."],
["Điều kiện khống chế","Áp dụng riêng các điều kiện nhóm VIII của bộ thi đua và quy định về đánh giá viên chức; không tự động xếp loại chỉ theo tổng điểm."],
["Nguyên tắc công bằng","Người không là đảng viên, đoàn viên hoặc không được phân công hội thi không bị chấm 0 vì không thuộc đối tượng."],
["Thời điểm","Các chỉ tiêu năm học chỉ đánh giá theo tiến độ đến kỳ, nhiệm vụ đã phân công; điều chỉnh nếu dùng cho năm học tiếp theo."],
["Cách sử dụng","Nhân bản sheet CHAM_DIEM và TONG_HOP để lưu phiếu từng giáo viên hoặc lưu mỗi giáo viên một file; ghi kết quả vào TONG_HOP_TRUONG."],
["Lưu ý","Cần được Hội đồng/Hiệu trưởng thống nhất, phê duyệt trọng số quy đổi, điều kiện áp dụng, tiêu chí khống chế trước khi sử dụng xếp loại chính thức."]
].map((z,i)=>row(i+4,[[1,z[0],3],[2,z[1],4]],48))
];
const DM=[vals(1,["DANH MỤC KPI GIÁO VIÊN – 06 TRỤC, 100 ĐIỂM"],1),vals(3,["Theo bộ tiêu chí thi đua năm học 2025–2026 – Bản quy đổi quản lý nội bộ"],4),hdr(6,["Trục","Mã tiêu chí","Nội dung KPI","Chỉ tiêu cần đạt","Điểm","Minh chứng","Áp dụng mặc định"])];
const CD=[vals(1,["PHIẾU CHẤM ĐIỂM KPI GIÁO VIÊN – 06 TRỤC, 100 ĐIỂM"],1),row(3,[[1,"Họ tên giáo viên",3],[2,"",5],[3,"Nhóm/lớp",3],[4,"",5],[5,"Quý",3],[6,"",5],[7,"Năm",3],[8,2026,5]]),vals(4,["Nhập điểm cột H và I, minh chứng cột K. Trạng thái KAD cần có lý do xác nhận."],4),hdr(6,["Trục","Mã gốc","Nội dung KPI","Chỉ tiêu cần đạt","Điểm tối đa","Minh chứng yêu cầu","Có/KAD","GV tự chấm","BGH chấm","Điểm hợp lệ","Minh chứng thực tế","Nhận xét / lý do KAD"])];
D.forEach((z,i)=>{
let r=7+i;
DM.push(row(r,[[1,z[0]],[2,z[1]],[3,z[2],4],[4,z[3],4],[5,z[4],3],[6,z[5],4],[7,z[6],5]],40));
CD.push(row(r,[[1,z[0]],[2,z[1]],[3,z[2],4],[4,z[3],4],[5,z[4],3],[6,z[5],4],[7,z[6],5],[8,"",5],[9,"",5],[10,null,6,`IF(G${r}="KAD","",IF(I${r}="","",IF(AND(ISNUMBER(I${r}),I${r}>=0,I${r}<=E${r}),I${r},"SAI ĐIỂM")))`],[11,"",5],[12,"",5]],44));
});
DM.push(row(46,[[1,"TỔNG",3],[5,null,3,`SUM(E7:E${rEnd})`]]));
CD.push(row(46,[[1,"TỔNG ĐIỂM GỐC",3],[5,null,3,`SUM(E7:E${rEnd})`],[10,null,6,`SUM(J7:J${rEnd})`]]));
const ra=`CHAM_DIEM!$A$7:$A${rEnd}`,re=`CHAM_DIEM!$E$7:$E${rEnd}`,rg=`CHAM_DIEM!$G$7:$G${rEnd}`,rj=`CHAM_DIEM!$J$7:$J${rEnd}`;
const TH=[vals(1,["TỔNG HỢP ĐIỂM KPI GIÁO VIÊN – 06 TRỤC"],1),row(3,[[1,"Giáo viên",3],[2,null,4,"CHAM_DIEM!B3"],[3,"Lớp",3],[4,null,4,"CHAM_DIEM!D3"],[5,"Quý",3],[6,null,4,"CHAM_DIEM!F3"]]),hdr(6,["Trục","Nội dung trục","Điểm tối đa","Điểm chuẩn áp dụng","Điểm BGH chấm","Số KPI áp dụng","Số KPI hợp lệ","Điểm quy đổi","Tỷ lệ đạt","Nhận xét"])];
AX.forEach((a,i)=>{
let r=7+i;
TH.push(row(r,[[1,i+1],[2,a[0],4],[3,a[1],3],[4,null,6,`SUMIFS(${re},${ra},A${r},${rg},"Có")`],[5,null,6,`SUMIFS(${rj},${ra},A${r},${rg},"Có")`],[6,null,6,`COUNTIFS(${ra},A${r},${rg},"Có")`],[7,null,6,`SUMPRODUCT((${ra}=A${r})*(${rg}="Có")*ISNUMBER(${rj}))`],[8,null,6,`IF(F${r}=0,"KAD",IF(G${r}<F${r},"CHƯA ĐỦ",IF(D${r}=0,"CHƯA ĐỦ",ROUND(E${r}*C${r}/D${r},2))))`],[9,null,7,`IF(ISNUMBER(H${r}),H${r}/C${r},"")`],[10,"",5]],40));
});
TH.push(row(13,[[1,"TỔNG",3],[2,"06 trục KPI",3],[3,100,3],[8,null,6,`IF(COUNTIF(H7:H12,"KAD")>0,"CẦN XEM XÉT",IF(COUNT(H7:H12)<6,"CHƯA ĐỦ",ROUND(SUM(H7:H12),2)))`]]));
TH.push(row(16,[[1,"Điều kiện nhóm VIII",3],[2,"Chưa xác minh",5]]));
TH.push(row(17,[[1,"Đề xuất xếp loại",3],[2,"Chờ đánh giá, xác nhận",5]]));
const TT=[vals(1,["THEO DÕI ĐIỂM THƯỞNG – TRỪ THEO BỘ THI ĐUA GỐC"],1),vals(3,["Theo dõi độc lập, không cộng trực tiếp vào KPI 100 điểm"],4),hdr(6,["Nội dung","Quy định gốc","Số lượng","Điểm thực tế","Minh chứng"])];
BT.forEach((b,i)=>TT.push(row(i+7,[[1,b[0],4],[2,b[1],4],[3,"",5],[4,"",5],[5,"",5]],40)));
const TR=[vals(1,["TỔNG HỢP ĐÁNH GIÁ KPI GIÁO VIÊN TOÀN TRƯỜNG"],1),hdr(6,["STT","Họ tên","Nhóm/lớp","Quý","Năm","Trục 1","Trục 2","Trục 3","Trục 4","Trục 5","Trục 6","Tổng KPI","Xếp loại đề xuất","Ghi chú"])];
for(let i=0;i<40;i++){let r=7+i;TR.push(row(r,[[1,i+1],[2,i===0?null:"",i===0?4:5,i===0?"CHAM_DIEM!B3":undefined],[3,i===0?null:"",5,i===0?"CHAM_DIEM!D3":undefined],[4,i===0?null:"",5,i===0?"CHAM_DIEM!F3":undefined],[5,i===0?null:"",5,i===0?"CHAM_DIEM!H3":undefined],...[6,7,8,9,10,11].map((c,j)=>[c,i===0?null:"",i===0?6:5,i===0?`TONG_HOP!H${j+7}`:undefined]),[12,null,6,i===0?"TONG_HOP!H13":`IF(COUNT(F${r}:K${r})=6,SUM(F${r}:K${r}),"")`],[13,"",5],[14,"",5]],27));}
const ST='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="15"/><color rgb="FF16476F"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="6"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7F0F8"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FF205781"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFDF1C9"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE1F2E7"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"/><right style="thin"/><top style="thin"/><bottom style="thin"/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="8"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0"/><xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0"/><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf numFmtId="2" fontId="1" fillId="5" borderId="1" xfId="0"/><xf numFmtId="10" fontId="1" fillId="5" borderId="1" xfId="0"/></cellXfs></styleSheet>';
function enc(s){return new TextEncoder().encode(s)}
function crc(b){let c=-1;for(const n of b){c^=n;for(let i=0;i<8;i++)c=(c>>>1)^(0xEDB88320&-(c&1))}return(c^-1)>>>0}
const u16=n=>[n&255,(n>>>8)&255],u32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];
function zip(files){
let locals=[],central=[],off=0;
for(let [name,content] of files){
let fn=enc(name),b=enc(content),check=crc(b);
let lh=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0),...u32(check),...u32(b.length),...u32(b.length),...u16(fn.length),...u16(0)]);
locals.push(lh,fn,b);
let ch=new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0),...u32(check),...u32(b.length),...u32(b.length),...u16(fn.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(off)]);
central.push(ch,fn);off+=lh.length+fn.length+b.length;
}
let centralLen=central.reduce((a,b)=>a+b.length,0);
let end=new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(centralLen),...u32(off),...u16(0)]);
return new Blob([...locals,...central,end],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
}
function exportFile(){
let sheets=[
sheet(H,[34,115]),
sheet(DM,[12,14,49,65,13,45,19],6,"A6:G44"),
sheet(CD,[11,13,45,62,14,42,13,16,16,17,42,40],6,"A6:L44"),
sheet(TH,[17,54,17,22,22,19,20,19,16,36],6),
sheet(TT,[47,76,16,19,42],6),
sheet(TR,[9,28,22,13,13,13,13,13,13,13,13,17,26,39],6)
];
let names=["HUONG_DAN","DANH_MUC","CHAM_DIEM","TONG_HOP","THUONG_TRU","TONG_HOP_TRUONG"];
let base="http://schemas.openxmlformats.org/officeDocument/2006/relationships";
let wb='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="'+base+'"><sheets>'+names.map((n,i)=>'<sheet name="'+n+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join("")+'</sheets><calcPr calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>';
let rel='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+names.map((n,i)=>'<Relationship Id="rId'+(i+1)+'" Type="'+base+'/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join("")+'<Relationship Id="rId7" Type="'+base+'/styles" Target="styles.xml"/></Relationships>';
let types='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+names.map((n,i)=>'<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join("")+'</Types>';
let files=[
["[Content_Types].xml",types],
["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'+base+'/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
["xl/workbook.xml",wb],["xl/_rels/workbook.xml.rels",rel],["xl/styles.xml",ST],
...sheets.map((z,i)=>["xl/worksheets/sheet"+(i+1)+".xml",z])
];
return zip(files);
}
node.querySelector("#kpi-get-xlsx").addEventListener("click",function(){
let st=node.querySelector("#kpi-export-status");
try{
st.textContent="Đang tạo file Excel...";
let file=exportFile(),url=URL.createObjectURL(file),a=document.createElement("a");
a.href=url;a.download="KPI_Giao_vien_An_Binh_A_6_truc_100_diem.xlsx";
document.body.appendChild(a);a.click();a.remove();
st.textContent="Đã gửi yêu cầu tải Excel. Kiểm tra thư mục Tải xuống của thiết bị.";
setTimeout(()=>URL.revokeObjectURL(url),30000);
}catch(err){st.textContent="Không thể xuất trong thiết bị này: "+(err.message||err);}
});
})();
</script>

```

**Sau khi tải**, bạn mở file Excel, vào sheet `CHAM_DIEM` để nhập điểm giáo viên và Ban giám hiệu. Sheet `TONG_HOP` sẽ tự tính kết quả theo 06 trục.

*Lưu ý: Đây là bản quy đổi KPI 100 điểm đề xuất để nhà trường xem xét phê duyệt, chưa phải thang điểm chính thức được xác nhận theo Phụ lục 3.*

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

bạn có thể giúp tôi hoàn thành file excel để có thể in ấn dễ dàng hôn

---

ASSISTANT

Được nhé. Mình sẽ hoàn thiện thành **file Excel có thể in và ký xác nhận ngay**, không chỉ là bảng dữ liệu: bố cục A4, tiêu đề trường, thông tin giáo viên, 06 trục KPI, cột tự chấm – BGH chấm, minh chứng và phần tổng hợp. Mình sẽ giữ riêng phần điểm thưởng–trừ, đồng thời kiểm tra ngắt trang và công thức trước khi bàn giao.

---

ASSISTANT

Được nhé. Mình sẽ hoàn thiện bản **Excel KPI giáo viên Trường Mầm non An Bình A – 06 trục, 100 điểm** theo hướng có thể in, trình ký và lưu hồ sơ.

Bản in được bố trí như sau:

- **Phiếu chấm KPI:** Khổ A4 ngang, chia theo 06 trục, có điểm tự chấm, điểm Ban giám hiệu và minh chứng.
- **Bảng tổng hợp kết quả:** Khổ A4 dọc, gói gọn trong một trang, có phần nhận xét và chữ ký xác nhận.
- **Danh mục tiêu chí:** Có mã đối chiếu tiêu chí thi đua, trình bày rõ nội dung và điểm tối đa.
- **Bảng tổng hợp toàn trường:** A4 ngang, lặp lại tiêu đề cột khi in nhiều trang.

Mình sẽ giữ nguyên phương án phân bổ **25 – 15 – 10 – 15 – 15 – 20 = 100 điểm** đã xây dựng. Đây là thang quy đổi đề xuất để nhà trường phê duyệt, không tự nhận là trọng số nguyên bản của Phụ lục 3.

## Excel KPI giáo viên – Bản in A4

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="mnab-print-excel" class="w-full space-y-4">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="flex items-center gap-3">
      <div class="rounded-xl bg-emerald-100 text-emerald-800 p-3">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 7h8M8 11h8M8 15h8M8 19h5"/></svg>
      </div>
      <div class="min-w-0">
        <div class="font-semibold text-base">KPI_Giao_vien_An_Binh_A_IN_A4.xlsx</div>
        <div class="text-xs opacity-65">07 sheet · 06 trục · 100 điểm · Thiết lập in A4</div>
      </div>
    </div>
    <div class="grid grid-cols-2 gap-3 text-sm">
      <label class="space-y-1"><span class="opacity-70">Quý đánh giá</span><select id="mnab-q" class="w-full p-2 rounded-lg border bg-transparent"><option>I</option><option>II</option><option>III</option><option selected>IV</option></select></label>
      <label class="space-y-1"><span class="opacity-70">Năm</span><input id="mnab-y" type="number" min="2025" max="2100" value="2026" class="w-full p-2 rounded-lg border bg-transparent"/></label>
      <label class="space-y-1"><span class="opacity-70">Họ và tên giáo viên</span><input id="mnab-name" type="text" placeholder="Có thể để trống" class="w-full p-2 rounded-lg border bg-transparent"/></label>
      <label class="space-y-1"><span class="opacity-70">Nhóm/lớp</span><input id="mnab-class" type="text" placeholder="Có thể để trống" class="w-full p-2 rounded-lg border bg-transparent"/></label>
    </div>
    <button type="button" id="mnab-export" class="w-full rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold p-3 cursor-pointer flex justify-center items-center gap-2">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4"/></svg>
      Tải file Excel KPI – Bản in A4
    </button>
    <div id="mnab-status" class="text-xs opacity-70" role="status">Nhập thông tin nếu cần rồi nhấn tải. Thông tin có thể bổ sung sau trong Excel.</div>
  </div>
  <div class="rounded-xl border overflow-hidden">
    <div class="font-semibold text-sm p-3">Bố cục in đã thiết lập</div>
    <div class="divide-y text-sm">
      <div class="flex justify-between gap-3 p-3"><span>Phiếu chấm KPI, có nhóm trục và chữ ký</span><span class="whitespace-nowrap opacity-65">A4 ngang</span></div>
      <div class="flex justify-between gap-3 p-3"><span>Tổng hợp điểm cá nhân, xác nhận</span><span class="whitespace-nowrap opacity-65">A4 dọc · 1 trang</span></div>
      <div class="flex justify-between gap-3 p-3"><span>Nhập điểm và danh mục minh chứng</span><span class="whitespace-nowrap opacity-65">A4 ngang</span></div>
      <div class="flex justify-between gap-3 p-3"><span>Điểm thưởng–trừ và tổng hợp toàn trường</span><span class="whitespace-nowrap opacity-65">A4 ngang</span></div>
      <div class="flex justify-between gap-3 p-3"><span>Hướng dẫn sử dụng</span><span class="whitespace-nowrap opacity-65">A4 dọc · 1 trang</span></div>
    </div>
  </div>
</div>
<script>
(()=>{
const root=document.getElementById("mnab-print-excel");
if(!root||root.dataset.ready)return;
root.dataset.ready="1";
const axes=[
["Kết quả thực hiện nhiệm vụ chăm sóc, giáo dục trẻ",25],
["Quy trình chuyên môn, hồ sơ, thiết bị và kiểm định",15],
["Ứng dụng CNTT, đổi mới sáng tạo và chuyển đổi số",10],
["Kỷ luật, trách nhiệm, đạo đức, Đảng và đoàn thể",15],
["Phát triển trẻ, an sinh xã hội và phối hợp hỗ trợ trẻ",15],
["An ninh, an toàn trường học và phòng ngừa vi phạm",20]
];
const raw=`1|4.1|Tỷ lệ trẻ suy dinh dưỡng nhẹ cân|Không quá 1,25%|5|Bảng tổng hợp dinh dưỡng|Có|Đánh giá theo số liệu được xác nhận
1|4.2|Tỷ lệ trẻ suy dinh dưỡng thấp còi|Dưới 1,25%|4|Bảng tổng hợp dinh dưỡng|Có|
1|4.3|Tỷ lệ trẻ béo phì|Không quá 2%|4|Bảng tổng hợp dinh dưỡng|Có|
1|5|Tỷ lệ trẻ chuyên cần 2 buổi/ngày|Lớp 5 tuổi: 95%; 4 tuổi: 85%; 3 tuổi và nhà trẻ: 80%|7|Sổ điểm danh, bảng chuyên cần|Có|Đối chiếu độ tuổi nhóm lớp
1|6|Tham gia hội thi bắt buộc|Tham gia 100% theo kế hoạch và phân công|3|Danh sách, kế hoạch hội thi|Có|Chỉ đánh giá nhiệm vụ đến hạn
1|7|Thành tích hội thi cấp cơ sở|Đạt giải Nhất khi được phân công và có hội thi|2|Quyết định khen thưởng|KAD|Xác định điều kiện áp dụng theo phân công
2|8|Theo dõi tài sản lớp|Có sổ theo dõi tài sản đúng quy định|2|Sổ tài sản, biên bản kiểm tra|Có|
2|9|Tăng đồ dùng, đồ chơi|Có tăng so với đầu năm từ nguồn xã hội hóa hợp pháp, tự nguyện|2|Danh mục, biên bản đối chiếu|Có|Không vận động thu trái quy định
2|10|Bảo quản đồ dùng, đồ chơi|Bảo quản tốt, vệ sinh, an toàn|2|Biên bản kiểm tra thực tế|Có|
2|12|Lớp xanh, sạch, đẹp|Đạt yêu cầu của nhà trường|2|Phiếu kiểm tra, hình ảnh lớp|Có|
2|29|Kiểm định chất lượng giáo dục|Hoàn thành nhiệm vụ được phân công|2|Hồ sơ kiểm định, xác nhận BGH|Có|
2|30|Phổ cập giáo dục trẻ 5 tuổi|Hoàn thành nhiệm vụ được phân công|2|Hồ sơ phổ cập, xác nhận BGH|Có|
2|35|Công tác báo cáo|Đầy đủ, chính xác, đúng hạn theo tiêu chí gốc|2|Báo cáo, nhật ký nộp|Có|Báo cáo quá 2 ngày được xem như không báo cáo theo bộ tiêu chí gốc
2|37|Thể thức văn bản|Đúng quy định tại Nghị định 30 khi thuộc phạm vi áp dụng|1|Văn bản và báo cáo|Có|
3|31|Ứng dụng CNTT trong giảng dạy|Ít nhất 01 bài/chủ đề|3|Giáo án, file bài giảng|Có|
3|32|Xây dựng kho học liệu số|Ít nhất 02 nội dung/năm theo tiến độ|3|Đường dẫn, sản phẩm học liệu|Có|
3|33|Tin, bài trên website trường|Ít nhất 01 tin, bài/tháng|2|Tin bài và xác nhận tiếp nhận|Có|
3|34|Công tác chuyển đổi số|Số hóa hồ sơ, cập nhật dữ liệu và phần mềm đúng hạn|2|Hồ sơ số, xác nhận BGH|Có|
4|2|Điều kiện đảng viên của viên chức|Đáp ứng nội dung gốc khi thuộc đối tượng|1|Hồ sơ tổ chức Đảng|KAD|Không trừ người không thuộc đối tượng
4|15|Không tự ý thu tiền phụ huynh|Không thu khi chưa được phân công|2|Kết quả kiểm tra và xác minh|Có|
4|16|Không thu ngoài quy định|Không phát sinh khoản thu sai quy định|2|Chứng từ, biên bản kiểm tra|Có|
4|17|Không phát động khoản thu sai|Không phát động thu trái quy định thông qua ban đại diện cha mẹ trẻ|2|Biên bản và kết quả xác minh|Có|
4|18|Nhiệm vụ đảng viên|Hoàn thành tốt nhiệm vụ trở lên nếu là đảng viên|1|Kết quả đánh giá Đảng|KAD|Không áp dụng ngoài đối tượng
4|19|Nhiệm vụ đoàn viên|Hoàn thành tốt nhiệm vụ nếu thuộc tổ chức Đoàn|1|Kết quả đánh giá Đoàn|KAD|Không áp dụng ngoài đối tượng
4|22|Đoàn kết và ứng xử|Không nhũng nhiễu, gây mất đoàn kết được xác minh|2|Kết quả xác minh|Có|Không đánh giá bất lợi hành vi khiếu nại hợp pháp
4|28|Chấp hành nội quy, quy chế|Không vi phạm nội quy, quy chế làm việc và chuyên môn|4|Biên bản kiểm tra|Có|
5|1|Sĩ số chuẩn theo giáo viên|Nhà trẻ 8; MG 3 tuổi 10; MG 4 tuổi 12; MG 5 tuổi 14 trẻ/GV|5|Danh sách trẻ, phân công|Có|Căn cứ nhiệm vụ, điều kiện lớp thực tế
5|13|Chính sách hỗ trợ trẻ|Cung cấp kịp thời 100% thông tin trẻ thuộc diện chính sách|5|Hồ sơ chính sách|Có|Xem xét KAD khi không phát sinh
5|14|Hỗ trợ trẻ hoàn cảnh đặc biệt|Tham gia hỗ trợ trẻ theo nhiệm vụ và điều kiện thực tế|5|Hồ sơ hỗ trợ, phối hợp|Có|Không ép buộc đóng góp
6|11|An toàn trường lớp|Đạt yêu cầu trường học an toàn theo quy định|4|Biên bản kiểm tra an toàn|Có|
6|20|Chấp hành pháp luật|Không vi phạm theo tiêu chí gốc đã được xác minh|2|Kết luận có thẩm quyền|Có|
6|21|Đón, trả trẻ đúng quy định|Không tổ chức giữ trẻ trễ trái quy định|2|Sổ đón, trả trẻ|Có|
6|23|Bảo vệ thông tin, bí mật nhà nước|Không làm lộ lọt bí mật hoặc phát tán thông tin sai sự thật|2|Kết quả xác minh|Có|
6|24|Chấp hành pháp luật liên quan đến hoạt động tôn giáo|Không có hành vi vi phạm pháp luật đã được xác minh|1|Kết luận có thẩm quyền|Có|Không đánh giá niềm tin cá nhân
6|25|Ứng xử trên mạng xã hội|Không vi phạm quy định liên quan|2|Kết quả kiểm tra|Có|
6|26|Chấp hành quy định của địa phương|Không có vi phạm đã được xác minh|2|Văn bản, kết quả xác minh|Có|
6|27|Phòng chống bạo lực học đường|Không bạo lực thể chất, tinh thần đối với trẻ và đồng nghiệp|4|Kết quả kiểm tra, xác minh|Có|Xử lý điều kiện khống chế riêng
6|36|Báo cáo sự việc bất thường|Báo cáo kịp thời các sự việc xảy ra tại nhóm lớp, tổ|1|Nhật ký sự việc, báo cáo|Có|`;
const data=raw.trim().split("\n").map((line,i)=>{
const a=line.split("|");
return {axis:Number(a[0]),code:a[1],title:a[2],target:a[3],max:Number(a[4]),evidence:a[5],status:a[6],notes:a[7]||"",row:i+7};
});
const bonus=[
["Vi phạm quy chế làm việc","Trừ tối thiểu 01 điểm/nội dung/lần"],
["Vi phạm quy tắc ứng xử","Trừ 01 điểm/nội dung/lần; lần 2 không đạt tiêu chuẩn"],
["Xung phong dạy lớp nhà trẻ","Cộng 0,5 điểm/tháng"],
["Giải tập thể cấp cơ sở","Nhất 7; Nhì 5; Ba 3; Khuyến khích 1,5"],
["Giải cá nhân cấp cơ sở","Nhất 5; Nhì 3,5; Ba 2; Khuyến khích 1"],
["Giải hội thi cấp trên","Thành phố nhân 2 cấp cơ sở; tỉnh nhân 2 cấp thành phố"],
["Hội thi, sự kiện ngoài chuyên môn","Tham gia cộng 0,5 điểm/người/sự kiện"],
["Vượt sĩ số nhà trẻ","Cộng 1 điểm/trẻ vượt/tháng, tối đa 5"],
["Vượt sĩ số mẫu giáo","Cộng 2 điểm/trẻ vượt/tháng; giảm sĩ số trừ tương ứng"],
["Đồ chơi, thiết bị xã hội hóa tăng tối thiểu 10%","Cộng 2 điểm/học kỳ"],
["Trình độ đào tạo vượt chuẩn","Cộng 1 điểm/mức vượt chuẩn"],
["Bồi dưỡng chuyên môn nghiệp vụ","Cộng 1 điểm/chứng chỉ hoặc chứng nhận"],
["Nhiệm vụ tổ trưởng, Bí thư chi đoàn","Tối đa 5 điểm/năm khi đủ điều kiện"]
];
const escapeXML=v=>String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const xlcol=n=>{let s="";while(n){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26);}return s;};
const cc=(n,v,s=5,f)=>({n,v,s,f});
function makeCell(row,o){
let s='<c r="'+xlcol(o.n)+row+'" s="'+(o.s||0)+'"';
if(o.f!==undefined)return s+'><f>'+escapeXML(o.f)+'</f></c>';
if(o.v===undefined||o.v===null||o.v==="")return s+'/>';
if(typeof o.v==="number")return s+'><v>'+o.v+'</v></c>';
return s+' t="inlineStr"><is><t xml:space="preserve">'+escapeXML(o.v)+'</t></is></c>';
}
function rr(row,cells,height=23){
return '<row r="'+row+'" ht="'+height+'" customHeight="1">'+cells.map(o=>makeCell(row,o)).join("")+'</row>';
}
const hh=(row,items)=>rr(row,items.map((v,i)=>cc(i+1,v,3)),35);
const merge=(r1,c1,r2,c2)=>`${xlcol(c1)}${r1}:${xlcol(c2)}${r2}`;
const sourceA="NHAP_DIEM!$A$7:$A$44";
const sourceE="NHAP_DIEM!$E$7:$E$44";
const sourceG="NHAP_DIEM!$G$7:$G$44";
const sourceH="NHAP_DIEM!$H$7:$H$44";
const sourceJ="NHAP_DIEM!$J$7:$J$44";
const sumIFS=(range,r)=>`SUMIFS(${range},${sourceA},A${r},${sourceG},"Có")`;
const countApplied=r=>`COUNTIFS(${sourceA},A${r},${sourceG},"Có")`;
const validCount=(range,r)=>`SUMPRODUCT((${sourceA}=A${r})*(${sourceG}="Có")*ISNUMBER(${range}))`;
function scoreFormula(range,r){
let total=sumIFS(range,r),weights=sumIFS(sourceE,r),count=countApplied(r),valid=validCount(range,r);
let status=`COUNTIFS(${sourceA},A${r},${sourceG},"Có")+COUNTIFS(${sourceA},A${r},${sourceG},"KAD")`;
return `IF(${status}<COUNTIF(${sourceA},A${r}),"CHƯA RÕ",IF(${count}=0,"KAD",IF(${valid}<${count},"CHƯA ĐỦ",IF(${weights}=0,"CHƯA ĐỦ",ROUND(${total}*C${r}/${weights},2)))))`;
}
function sheetsFor(name,klass,q,year){
const sheets=[];
const info=[
["Đơn vị","Trường Mầm non An Bình A."],
["Nguồn","Bộ tiêu chí chấm điểm thi đua năm học 2025–2026, ban hành kèm Quyết định 38/QĐ-MNABA ngày 01/12/2025."],
["Loại bảng","Bảng KPI quy đổi nội bộ 06 trục – 100 điểm, cần được nhà trường thống nhất trước khi áp dụng chính thức."],
["Dữ liệu","38 chỉ số có điểm; phần tài liệu đã gửi chưa có nội dung mã 3; mục 4 được tách thành 4.1, 4.2, 4.3."],
["Nhập liệu","Chỉ nhập thông tin và kết quả tại NHAP_DIEM: cột G Có/KAD; H giáo viên tự chấm; I BGH chấm; K minh chứng; L ghi chú."],
["Điểm nhập","Điểm tự chấm và điểm BGH từ 0 đến điểm chuẩn từng tiêu chí. Cột J tự kiểm tra và tính điểm hợp lệ."],
["KAD","Chỉ áp dụng khi tiêu chí không thuộc đối tượng hoặc chưa đến kỳ; cần có giải trình, xác nhận."],
["Quy đổi","Điểm trục = điểm của các tiêu chí Có / điểm chuẩn của các tiêu chí Có × điểm tối đa của trục."],
["Chưa chấm","Nếu còn tiêu chí Có chưa có điểm hợp lệ, tổng hợp hiện CHƯA ĐỦ; nếu tất cả KPI của một trục KAD, hiện CẦN XEM XÉT."],
["Điểm thưởng – trừ","Theo dõi ở THUONG_TRU theo quy định gốc; không cộng cơ học vào KPI 100 và không trừ lặp."],
["An toàn trẻ","Điều kiện về bảo vệ trẻ, nhóm VIII và vi phạm nghiêm trọng phải xử lý riêng theo quy định."],
["Xếp loại","Bảng không tự động kết luận mức xếp loại khi chưa có tiêu chuẩn và quyết định phê duyệt của cấp có thẩm quyền."],
["Cách in","Mở PHIEU_IN → File → Print → Print Active Sheets. Các trang đã đặt A4, hướng giấy, lề và tiêu đề lặp."],
["Hồ sơ","In thêm TONG_HOP trên 01 trang A4 dọc để lấy ý kiến, chữ ký giáo viên, tổ trưởng và đại diện Ban giám hiệu."],
["Theo quý","Với chỉ tiêu năm học, xác định tiến độ đến thời điểm đánh giá; không chấm chưa đạt chỉ vì chưa hết năm học."],
["Cập nhật","Nếu áp dụng sang năm học khác, đối chiếu tiêu chí thi đua mới trước khi sử dụng."]
];
let help=[
rr(1,[cc(1,"HƯỚNG DẪN SỬ DỤNG BỘ KPI GIÁO VIÊN",1)],34),
rr(2,[cc(1,"TRƯỜNG MẦM NON AN BÌNH A – 06 TRỤC, 100 ĐIỂM",2)],25),
hh(4,["MỤC","NỘI DUNG / HƯỚNG DẪN"])
];
info.forEach((v,i)=>help.push(rr(i+5,[cc(1,v[0],4),cc(2,v[1],5)],35)));
sheets.push({name:"HUONG_DAN",rows:help,widths:[25,91],orientation:"portrait",fitHeight:1,printEnd:20,maxCol:2,merges:[merge(1,1,1,2),merge(2,1,2,2)]});
let catalog=[
rr(1,[cc(1,"DANH MỤC KPI GIÁO VIÊN – 06 TRỤC / 100 ĐIỂM",1)],34),
rr(2,[cc(1,"Quy đổi theo bộ tiêu chí thi đua năm học 2025–2026",2)],25),
rr(4,[cc(1,"Các tiêu chí giữ mã gốc để đối chiếu; trọng số là mức đề xuất dùng nội bộ.",10)],29),
hh(6,["Trục","Mã gốc","Nội dung KPI","Yêu cầu cần đạt","Điểm","Minh chứng","Áp dụng"])
];
data.forEach(z=>catalog.push(rr(z.row,[cc(1,z.axis,7),cc(2,z.code,7),cc(3,z.title,5),cc(4,z.target,5),cc(5,z.max,7),cc(6,z.evidence,5),cc(7,z.status,6)],31)));
catalog.push(rr(46,[cc(1,"TỔNG CỘNG",9),cc(5,100,9)],29));
sheets.push({name:"DANH_MUC",rows:catalog,widths:[8,10,37,51,10,38,13],orientation:"landscape",fitHeight:0,freeze:6,printEnd:46,maxCol:7,titleRows:[1,6],merges:[merge(1,1,1,7),merge(2,1,2,7),merge(4,1,4,7)],filter:"A6:G44"});
let input=[
rr(1,[cc(1,"PHIẾU NHẬP ĐIỂM KPI GIÁO VIÊN",1)],34),
rr(2,[cc(1,"Nhập dữ liệu tại các ô màu vàng; xem PHIEU_IN và TONG_HOP để in.",2)],26),
rr(3,[cc(1,"Giáo viên",4),cc(2,name,6),cc(3,"Nhóm/lớp",4),cc(4,klass,6),cc(5,"Quý",4),cc(6,q,6),cc(7,"Năm",4),cc(8,year,6)],28),
rr(5,[cc(1,"KAD: không áp dụng (phải giải trình); điểm BGH ngoài khoảng 0 đến điểm chuẩn sẽ báo LỖI ĐIỂM.",10)],30),
hh(6,["Trục","Mã gốc","Nội dung KPI","Chỉ tiêu cần đạt","Điểm chuẩn","Minh chứng yêu cầu","Có/KAD","GV tự chấm","BGH chấm","Điểm hợp lệ","Minh chứng thực tế","Nhận xét / lý do KAD"])
];
data.forEach(z=>{
const r=z.row;
const formula=`IF(G${r}="KAD","",IF(I${r}="","",IF(AND(ISNUMBER(I${r}),I${r}>=0,I${r}<=E${r}),I${r},"LỖI ĐIỂM")))`;
input.push(rr(r,[cc(1,z.axis,7),cc(2,z.code,7),cc(3,z.title,5),cc(4,z.target,5),cc(5,z.max,7),cc(6,z.evidence,5),cc(7,z.status,6),cc(8,"",6),cc(9,"",6),cc(10,null,8,formula),cc(11,"",6),cc(12,z.notes,6)],36));
});
input.push(rr(46,[cc(1,"TỔNG ĐIỂM GỐC",9),cc(5,null,9,"SUM(E7:E44)"),cc(10,null,8,"SUM(J7:J44)")],28));
input.push(rr(48,[cc(1,"Tổng trên chưa quy đổi KAD. Kết quả chính thức xem tại TONG_HOP.",10)],32));
const validations='<dataValidations count="2"><dataValidation type="list" allowBlank="0" showErrorMessage="1" errorStyle="stop" error="Chọn Có hoặc KAD" sqref="G7:G44"><formula1>"Có,KAD"</formula1></dataValidation><dataValidation type="custom" allowBlank="1" showErrorMessage="1" errorStyle="stop" error="Điểm phải từ 0 đến điểm chuẩn." sqref="H7:I44"><formula1>OR(H7="",AND(ISNUMBER(H7),H7&gt;=0,H7&lt;=$E7))</formula1></dataValidation></dataValidations>';
sheets.push({name:"NHAP_DIEM",rows:input,widths:[8,10,36,47,12,31,12,13,13,14,30,35],orientation:"landscape",fitHeight:0,freeze:6,printEnd:48,maxCol:12,titleRows:[1,6],merges:[merge(1,1,1,12),merge(2,1,2,12),merge(5,1,5,12),merge(48,1,48,12)],filter:"A6:L44",validations});
let summary=[
rr(1,[cc(1,"TRƯỜNG MẦM NON AN BÌNH A – TỔNG HỢP KPI GIÁO VIÊN",1)],35),
rr(2,[cc(1,"BẢNG ĐÁNH GIÁ KẾT QUẢ THEO QUÝ – 06 TRỤC, 100 ĐIỂM",2)],27),
rr(3,[cc(1,"Họ và tên",4),cc(2,null,5,'IF(NHAP_DIEM!B3="","",NHAP_DIEM!B3)'),cc(4,"Nhóm/lớp",4),cc(5,null,5,'IF(NHAP_DIEM!D3="","",NHAP_DIEM!D3)')],27),
rr(4,[cc(1,"Quý",4),cc(2,null,5,"NHAP_DIEM!F3"),cc(3,"Năm",4),cc(4,null,5,"NHAP_DIEM!H3")],25),
rr(5,[cc(1,"Chấm theo minh chứng; KAD chỉ khi được xác nhận. Điều kiện khống chế xếp loại xét riêng.",10)],32),
hh(6,["Trục","Nội dung đánh giá","Điểm tối đa","GV tự chấm","BGH đánh giá","Tỷ lệ đạt"])
];
axes.forEach((a,i)=>{
const r=7+i;
summary.push(rr(r,[cc(1,i+1,7),cc(2,a[0],5),cc(3,a[1],7),cc(4,null,8,scoreFormula(sourceH,r)),cc(5,null,8,scoreFormula(sourceJ,r)),cc(6,null,18,`IF(ISNUMBER(E${r}),E${r}/C${r},"")`)],42));
});
summary.push(rr(13,[cc(1,"TỔNG",9),cc(2,"Kết quả KPI 06 trục",9),cc(3,100,9),cc(4,null,8,'IF(COUNT(D7:D12)=6,ROUND(SUM(D7:D12),2),"CHƯA ĐỦ")'),cc(5,null,8,'IF(COUNTIF(E7:E12,"KAD")>0,"CẦN XEM XÉT",IF(COUNT(E7:E12)<6,"CHƯA ĐỦ",ROUND(SUM(E7:E12),2)))'),cc(6,null,18,'IF(ISNUMBER(E13),E13/100,"")')],34));
summary.push(rr(15,[cc(1,"Điều kiện nhóm VIII",4),cc(2,"Chưa xác minh",6)],28));
summary.push(rr(16,[cc(1,"Điểm thưởng – trừ",4),cc(2,"Theo dõi riêng theo tiêu chí thi đua",5)],28));
summary.push(rr(17,[cc(1,"Đề xuất xếp loại",4),cc(2,"Chờ Hội đồng và Ban giám hiệu xác nhận",6)],28));
summary.push(rr(19,[cc(1,"NHẬN XÉT CỦA TỔ CHUYÊN MÔN / BAN GIÁM HIỆU",4)],25));
summary.push(rr(20,[cc(1,".........................................................................................................",5)],24));
summary.push(rr(21,[cc(1,".........................................................................................................",5)],24));
summary.push(rr(23,[cc(1,"An Bình, ngày ...... tháng ...... năm ........",12)],24));
summary.push(rr(25,[cc(1,"GIÁO VIÊN TỰ ĐÁNH GIÁ",11),cc(3,"TỔ TRƯỞNG CHUYÊN MÔN",11),cc(5,"ĐẠI DIỆN BAN GIÁM HIỆU",11)],26));
summary.push(rr(26,[cc(1,"(Ký, ghi rõ họ tên)",12),cc(3,"(Ký, ghi rõ họ tên)",12),cc(5,"(Ký, ghi rõ họ tên)",12)],22));
summary.push(rr(29,[cc(1,"",12),cc(3,"",12),cc(5,"",12)],22));
let m=[merge(1,1,1,6),merge(2,1,2,6),merge(3,2,3,3),merge(3,5,3,6),merge(5,1,5,6),merge(19,1,19,6),merge(20,1,20,6),merge(21,1,21,6),merge(23,1,23,6)];
for(const r of [25,26,27,28,29])m.push(merge(r,1,r,2),merge(r,3,r,4),merge(r,5,r,6));
sheets.push({name:"TONG_HOP",rows:summary,widths:[13,47,17,20,21,18],orientation:"portrait",fitHeight:1,printEnd:29,maxCol:6,merges:m});
let paper=[
rr(1,[cc(1,"TRƯỜNG MẦM NON AN BÌNH A – PHIẾU CHẤM KPI GIÁO VIÊN",1)],35),
rr(2,[cc(1,"ĐÁNH GIÁ THEO 06 TRỤC – TỔNG 100 ĐIỂM",2)],28),
rr(3,[cc(1,"Giáo viên",4),cc(2,null,5,'IF(NHAP_DIEM!B3="","................................",NHAP_DIEM!B3)'),cc(4,"Nhóm/lớp",4),cc(5,null,5,'IF(NHAP_DIEM!D3="","................",NHAP_DIEM!D3)'),cc(7,"Quý/năm",4),cc(8,null,5,'NHAP_DIEM!F3&"/"&NHAP_DIEM!H3')],26),
rr(4,[cc(1,"Giáo viên tự đánh giá, tổ chuyên môn và BGH xác nhận theo minh chứng, chỉ tiêu được giao.",2)],22),
rr(5,[cc(1,"KAD: không áp dụng (có giải trình). Điểm quy đổi mỗi trục thể hiện ở dòng cộng trục.",10)],24),
hh(6,["TT","Mã","Nội dung KPI","Chỉ tiêu cần đạt","Điểm chuẩn","GV tự chấm","BGH chấm","Minh chứng"])
];
const paperM=[merge(1,1,1,8),merge(2,1,2,8),merge(3,2,3,3),merge(3,5,3,6),merge(4,1,4,8),merge(5,1,5,8)];
const pageBreaks=[];
let pr=7,serial=0;
axes.forEach((a,ix)=>{
if(ix===2||ix===4)pageBreaks.push(pr-1);
paper.push(rr(pr,[cc(1,`TRỤC ${ix+1}. ${a[0].toUpperCase()} – ${a[1]} ĐIỂM`,15)],27));
paperM.push(merge(pr,1,pr,8));pr++;
data.filter(z=>z.axis===ix+1).forEach(z=>{
serial++;
const src=z.row;
const self=`IF(NHAP_DIEM!G${src}="KAD","KAD",IF(NHAP_DIEM!H${src}="","",NHAP_DIEM!H${src}))`;
const boss=`IF(NHAP_DIEM!G${src}="KAD","KAD",IF(NHAP_DIEM!J${src}="","",NHAP_DIEM!J${src}))`;
const proof=`IF(NHAP_DIEM!K${src}<>"",NHAP_DIEM!K${src},NHAP_DIEM!F${src})`;
paper.push(rr(pr,[cc(1,serial,13),cc(2,z.code,13),cc(3,z.title,12),cc(4,z.target,12),cc(5,z.max,13),cc(6,null,14,self),cc(7,null,14,boss),cc(8,null,12,proof)],29));
pr++;
});
paper.push(rr(pr,[cc(1,`CỘNG TRỤC ${ix+1}`,9),cc(5,a[1],9),cc(6,null,8,`TONG_HOP!D${ix+7}`),cc(7,null,8,`TONG_HOP!E${ix+7}`)],28));
paperM.push(merge(pr,1,pr,4));pr++;
});
pr++;
const totalPrintRow=pr;
paper.push(rr(pr,[cc(1,"TỔNG CỘNG 06 TRỤC KPI",9),cc(5,100,9),cc(6,null,8,"TONG_HOP!D13"),cc(7,null,8,"TONG_HOP!E13")],32));
paperM.push(merge(pr,1,pr,4));pr++;
paper.push(rr(pr,[cc(1,"Đề xuất xếp loại: ...................................    Nhận xét: ..........................................................",5)],27));
paperM.push(merge(pr,1,pr,8));pr+=2;
paper.push(rr(pr,[cc(1,"An Bình, ngày ...... tháng ...... năm ........",12)],24));
paperM.push(merge(pr,1,pr,8));pr++;
paper.push(rr(pr,[cc(1,"GIÁO VIÊN TỰ ĐÁNH GIÁ",11),cc(3,"TỔ TRƯỞNG CHUYÊN MÔN",11),cc(6,"ĐẠI DIỆN BAN GIÁM HIỆU",11)],27));
paperM.push(merge(pr,1,pr,2),merge(pr,3,pr,5),merge(pr,6,pr,8));pr++;
paper.push(rr(pr,[cc(1,"(Ký, ghi rõ họ tên)",12),cc(3,"(Ký, ghi rõ họ tên)",12),cc(6,"(Ký, ghi rõ họ tên)",12)],23));
paperM.push(merge(pr,1,pr,2),merge(pr,3,pr,5),merge(pr,6,pr,8));pr+=3;
paper.push(rr(pr,[cc(1,"",12)],22));
sheets.push({name:"PHIEU_IN",rows:paper,widths:[7,9,35,43,12,13,13,29],orientation:"landscape",fitHeight:0,printEnd:pr,maxCol:8,merges:paperM,titleRows:[1,6],breaks:pageBreaks});
let award=[
rr(1,[cc(1,"THEO DÕI ĐIỂM THƯỞNG – TRỪ THEO TIÊU CHÍ THI ĐUA",1)],35),
rr(2,[cc(1,"Theo dõi độc lập với KPI 100 điểm; các mức dưới đây căn cứ bộ tiêu chí thi đua nhà trường.",2)],30),
hh(5,["Nội dung","Quy định thi đua gốc","Số lượng","Điểm thực tế","Minh chứng"])
];
bonus.forEach((z,i)=>award.push(rr(6+i,[cc(1,z[0],5),cc(2,z[1],5),cc(3,"",6),cc(4,"",6),cc(5,"",6)],33)));
award.push(rr(21,[cc(1,"Ghi chú: Điểm thưởng và điểm trừ phải được xác minh, phê duyệt và không tính trùng.",10)],29));
sheets.push({name:"THUONG_TRU",rows:award,widths:[40,63,16,18,37],orientation:"landscape",fitHeight:1,printEnd:21,maxCol:5,merges:[merge(1,1,1,5),merge(2,1,2,5),merge(21,1,21,5)]});
let staff=[
rr(1,[cc(1,"BẢNG TỔNG HỢP KPI GIÁO VIÊN TOÀN TRƯỜNG",1)],34),
rr(2,[cc(1,"Trường Mầm non An Bình A – 06 trục KPI, tổng 100 điểm",2)],24),
rr(4,[cc(1,"Dòng đầu liên kết phiếu hiện tại; các dòng còn lại nhập kết quả từng giáo viên sau khi duyệt.",10)],27),
hh(5,["TT","Họ và tên","Nhóm/lớp","Quý/năm","Trục 1","Trục 2","Trục 3","Trục 4","Trục 5","Trục 6","Tổng","Xếp loại","Ghi chú"])
];
for(let i=0;i<40;i++){
let r=6+i;
if(i===0){
staff.push(rr(r,[cc(1,1,7),cc(2,null,5,'IF(NHAP_DIEM!B3="","",NHAP_DIEM!B3)'),cc(3,null,5,'IF(NHAP_DIEM!D3="","",NHAP_DIEM!D3)'),cc(4,null,5,'NHAP_DIEM!F3&"/"&NHAP_DIEM!H3'),...Array.from({length:6},(_,j)=>cc(5+j,null,8,`TONG_HOP!E${7+j}`)),cc(11,null,8,"TONG_HOP!E13"),cc(12,"",6),cc(13,"",6)],27));
}else{
staff.push(rr(r,[cc(1,i+1,7),cc(2,"",6),cc(3,"",6),cc(4,"",6),...Array.from({length:6},(_,j)=>cc(5+j,"",6)),cc(11,null,8,`IF(COUNT(E${r}:J${r})=6,ROUND(SUM(E${r}:J${r}),2),"")`),cc(12,"",6),cc(13,"",6)],27));
}
}
sheets.push({name:"TONG_HOP_TRUONG",rows:staff,widths:[7,29,18,13,11,11,11,11,11,11,13,19,29],orientation:"landscape",fitHeight:2,printEnd:45,maxCol:13,merges:[merge(1,1,1,13),merge(2,1,2,13),merge(4,1,4,13)],titleRows:[1,5]});
return sheets;
}
const styles=(()=>{
const fonts=[
'<font><sz val="11"/><name val="Arial"/></font>',
'<font><b/><sz val="15"/><color rgb="FF163B60"/><name val="Arial"/></font>',
'<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>',
'<font><b/><sz val="10"/><color rgb="FF173C5B"/><name val="Arial"/></font>',
'<font><sz val="9"/><name val="Arial"/></font>',
'<font><b/><sz val="10"/><color rgb="FF173C5B"/><name val="Arial"/></font>',
'<font><sz val="9"/><color rgb="FF566577"/><name val="Arial"/></font>'
];
const fillColor=["DCEBF7","205781","FFF1C9","E3F4E8","ECF2F7","16617B","FFF0E6"];
let fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>',...fillColor.map(c=>`<fill><patternFill patternType="solid"><fgColor rgb="FF${c}"/><bgColor indexed="64"/></patternFill></fill>`)];
const borders=[
'<border><left/><right/><top/><bottom/><diagonal/></border>',
'<border><left style="thin"><color rgb="FFCED8E2"/></left><right style="thin"><color rgb="FFCED8E2"/></right><top style="thin"><color rgb="FFCED8E2"/></top><bottom style="thin"><color rgb="FFCED8E2"/></bottom><diagonal/></border>'
];
const defs=[
[0,0,0,0,"left",false,0],
[1,2,0,0,"left",false,0],
[6,2,0,0,"left",true,0],
[2,3,1,0,"center",true,0],
[3,6,1,0,"left",true,0],
[0,0,1,0,"left",true,0],
[0,4,1,0,"center",true,0],
[5,6,1,0,"center",true,0],
[5,5,1,2,"center",true,0],
[5,2,1,0,"left",true,0],
[3,8,1,0,"left",true,0],
[5,0,0,0,"center",true,0],
[4,0,1,0,"left",true,0],
[4,0,1,0,"center",true,0],
[4,5,1,2,"center",true,0],
[2,7,1,0,"left",true,0],
[3,2,0,0,"left",true,0],
[5,0,0,0,"left",true,0],
[5,5,1,10,"center",true,0]
];
const xfs=defs.map(a=>`<xf numFmtId="${a[3]}" fontId="${a[0]}" fillId="${a[1]}" borderId="${a[2]}" xfId="0" applyAlignment="1" applyNumberFormat="${a[3]?"1":"0"}"><alignment horizontal="${a[4]}" vertical="center"${a[5]?' wrapText="1"':''}/></xf>`);
return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="'+fonts.length+'">'+fonts.join("")+'</fonts><fills count="'+fills.length+'">'+fills.join("")+'</fills><borders count="'+borders.length+'">'+borders.join("")+'</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="'+xfs.length+'">'+xfs.join("")+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
})();
function sheetXML(s){
const freeze=s.freeze?`<pane ySplit="${s.freeze}" topLeftCell="A${s.freeze+1}" activePane="bottomLeft" state="frozen"/>`:"";
const widths=s.widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join("");
const mergeXML=s.merges&&s.merges.length?`<mergeCells count="${s.merges.length}">${s.merges.map(ref=>`<mergeCell ref="${ref}"/>`).join("")}</mergeCells>`:"";
const filter=s.filter?`<autoFilter ref="${s.filter}"/>`:"";
const pages=s.breaks&&s.breaks.length?`<rowBreaks count="${s.breaks.length}" manualBreakCount="${s.breaks.length}">${s.breaks.map(r=>`<brk id="${r}" max="16383" man="1"/>`).join("")}</rowBreaks>`:"";
const footer='<headerFooter><oddFooter>&amp;LTrường Mầm non An Bình A&amp;RTrang &amp;P / &amp;N</oddFooter></headerFooter>';
return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" showGridLines="0">'+freeze+'</sheetView></sheetViews><sheetFormatPr defaultRowHeight="22"/><cols>'+widths+'</cols><sheetData>'+s.rows.join("")+'</sheetData>'+mergeXML+filter+(s.validations||"")+'<printOptions horizontalCentered="1" gridLines="0"/><pageMargins left="0.25" right="0.25" top="0.38" bottom="0.4" header="0.18" footer="0.2"/><pageSetup paperSize="9" orientation="'+s.orientation+'" fitToWidth="1" fitToHeight="'+s.fitHeight+'"/>'+footer+pages+'</worksheet>';
}
const u16=n=>[n&255,(n>>>8)&255],u32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];
const encode=s=>new TextEncoder().encode(s);
function crc32(bytes){let v=-1;for(const b of bytes){v^=b;for(let j=0;j<8;j++)v=(v>>>1)^(0xEDB88320&-(v&1));}return(v^-1)>>>0;}
function makeZip(files){
let local=[],central=[],offset=0;
for(const [path,content] of files){
const file=encode(path),payload=encode(content),crc=crc32(payload);
const localHeader=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(payload.length),...u32(payload.length),...u16(file.length),...u16(0)]);
local.push(localHeader,file,payload);
const centralHeader=new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(payload.length),...u32(payload.length),...u16(file.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset)]);
central.push(centralHeader,file);
offset+=localHeader.length+file.length+payload.length;
}
const centralLen=central.reduce((a,b)=>a+b.length,0);
const ending=new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(centralLen),...u32(offset),...u16(0)]);
return new Blob([...local,...central,ending],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
}
function createWorkbook(){
let q=root.querySelector("#mnab-q").value,year=Number(root.querySelector("#mnab-y").value)||2026,name=root.querySelector("#mnab-name").value.trim(),klass=root.querySelector("#mnab-class").value.trim();
if(data.length!==38||data.reduce((s,z)=>s+z.max,0)!==100)throw Error("Kiểm tra tổng điểm không đạt.");
for(let i=0;i<6;i++)if(data.filter(z=>z.axis===i+1).reduce((s,z)=>s+z.max,0)!==axes[i][1])throw Error("Phân bổ điểm trục "+(i+1)+" không đúng.");
const constructed=sheetsFor(name,klass,q,year);
const order=["PHIEU_IN","TONG_HOP","NHAP_DIEM","DANH_MUC","THUONG_TRU","TONG_HOP_TRUONG","HUONG_DAN"];
const sheets=order.map(n=>constructed.find(s=>s.name===n));
const rel="http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const names=order.map((n,i)=>`<sheet name="${n}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join("");
let defined="";
sheets.forEach((s,i)=>{
defined+=`<definedName name="_xlnm.Print_Area" localSheetId="${i}">'${s.name}'!$A$1:${xlcol(s.maxCol)}${s.printEnd}</definedName>`;
if(s.titleRows)defined+=`<definedName name="_xlnm.Print_Titles" localSheetId="${i}">'${s.name}'!${s.titleRows[0]}:${s.titleRows[1]}</definedName>`;
});
const wb=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="${rel}"><bookViews><workbookView activeTab="0"/></bookViews><sheets>${names}</sheets><definedNames>${defined}</definedNames><calcPr calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>`;
const relationships=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((s,i)=>`<Relationship Id="rId${i+1}" Type="${rel}/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join("")}<Relationship Id="rId8" Type="${rel}/styles" Target="styles.xml"/></Relationships>`;
const types=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((s,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`;
const parts=[
["[Content_Types].xml",types],
["_rels/.rels",`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${rel}/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
["xl/workbook.xml",wb],
["xl/_rels/workbook.xml.rels",relationships],
["xl/styles.xml",styles],
...sheets.map((s,i)=>[`xl/worksheets/sheet${i+1}.xml`,sheetXML(s)])
];
return {blob:makeZip(parts),filename:`KPI_Giao_vien_An_Binh_A_6_truc_100_diem_Quy_${q}_${year}_IN_A4.xlsx`};
}
root.querySelector("#mnab-export").addEventListener("click",()=>{
const status=root.querySelector("#mnab-status"),button=root.querySelector("#mnab-export");
button.disabled=true;
try{
status.textContent="Đang tạo sổ Excel, công thức tính điểm và thiết lập trang in...";
const {blob,filename}=createWorkbook();
const url=URL.createObjectURL(blob),link=document.createElement("a");
link.href=url;link.download=filename;link.style.display="none";document.body.appendChild(link);link.click();link.remove();
status.textContent="Đã gửi yêu cầu tải file "+filename+". Bạn hãy kiểm tra thư mục Tải xuống và mở bằng Microsoft Excel.";
setTimeout(()=>URL.revokeObjectURL(url),30000);
}catch(error){status.textContent="Không thể tạo file trong thiết bị hiện tại: "+String(error.message||error);}
finally{button.disabled=false;}
});
})();
</script>

```

### Hướng dẫn in sau khi mở Excel

Bạn vào sheet **PHIEU\_IN**, chọn **File → Print**. Khổ A4 ngang và căn lề đã được thiết lập; Excel sẽ lặp lại hàng tiêu đề ở các trang. Khi cần bản tổng hợp để trình ký, chọn sheet **TONG\_HOP** và in một trang A4 dọc.

Bản Excel này có công thức liên kết giữa các sheet, nên bạn chỉ cần nhập điểm một lần tại **NHAP\_DIEM**. Phiếu in và tổng hợp sẽ cập nhật khi Excel tính toán lại.

Trước khi in chính thức, bạn nên mở **Print Preview** để kiểm tra ngắt trang trên máy in của trường và xác nhận các tiêu chí KAD đã được xử lý đúng.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

dựa vào tiêu chí KPI. bạn hướng giúp tôi hướng dẫn giáo viên  cách viết nội dung tự đánh giá sao cho phù hợp neh1

---

ASSISTANT

# 📌 HƯỚNG DẪN GIÁO VIÊN VIẾT BẢN TỰ ĐÁNH GIÁ, XẾP LOẠI CÁ NHÂN THEO KPI 06 TRỤC

Dựa trên mẫu **Bản tự đánh giá, xếp loại của cá nhân** bạn vừa gửi và bộ KPI 06 trục, 100 điểm của Trường Mầm non An Bình A mà chúng ta đã xây dựng, tôi đề xuất hướng dẫn giáo viên viết theo hướng **ngắn gọn, đúng nhiệm vụ, có kết quả cụ thể và có minh chứng**, tránh nhận xét chung chung.

Đặc biệt, giáo viên không cần sao chép toàn bộ 38 chỉ số KPI vào bản tự đánh giá, mà cần tổng hợp những kết quả tiêu biểu theo 06 trục.

## 🎯 1. Hướng dẫn nội dung cần viết theo 06 trục

| Trục KPI | Giáo viên cần tự đánh giá nội dung gì? |
|--------|--------|
| **Trục 1 – Chăm sóc, giáo dục trẻ** \(25 điểm) | Kết quả chăm sóc, giáo dục; chuyên cần; dinh dưỡng; hội thi; thực hiện chương trình giáo dục. |
| **Trục 2 – Công tác chuyên môn, hồ sơ** \(15 điểm) | Hồ sơ chuyên môn, quản lý tài sản, đồ dùng đồ chơi, môi trường lớp, kiểm định, phổ cập và báo cáo. |
| **Trục 3 – CNTT và chuyển đổi số** \(10 điểm) | Ứng dụng CNTT trong giảng dạy, đóng góp học liệu số, gửi tin bài, cập nhật hồ sơ điện tử. |
| **Trục 4 – Kỷ luật và trách nhiệm** \(15 điểm) | Chấp hành quy chế, đạo đức nghề nghiệp, đoàn kết nội bộ, thực hiện công tác Đảng, đoàn thể nếu thuộc đối tượng. |
| **Trục 5 – Phát triển trẻ và an sinh** \(15 điểm) | Duy trì sĩ số, thực hiện chính sách hỗ trợ trẻ, phối hợp phụ huynh và giúp đỡ trẻ có hoàn cảnh khó khăn. |
| **Trục 6 – An ninh, an toàn** \(20 điểm) | Bảo đảm an toàn cho trẻ, đón trả trẻ, phòng chống bạo lực, bảo mật thông tin và báo cáo sự việc bất thường. |

## 📖 2. Mẫu nội dung tự đánh giá dành cho giáo viên

Mẫu dưới đây có thể đưa trực tiếp vào **Mục I – Tự đánh giá kết quả thực hiện nhiệm vụ** trong văn bản bạn gửi.

> **writing · document**
>
> ## I- TỰ ĐÁNH GIÁ KẾT QUẢ THỰC HIỆN NHIỆM VỤ
>
> Trên cơ sở chức trách, nhiệm vụ được phân công và kết quả thực hiện các chỉ tiêu KPI, bản thân tự đánh giá kết quả thực hiện nhiệm vụ trong tháng/quý như sau:
>
> **1. Kết quả thực hiện nhiệm vụ chăm sóc, giáo dục trẻ**
>
> Thực hiện đầy đủ chương trình, kế hoạch chăm sóc, nuôi dưỡng và giáo dục trẻ theo độ tuổi; tổ chức các hoạt động giáo dục phù hợp, chú trọng phát triển toàn diện và lấy trẻ làm trung tâm. Duy trì sĩ số, tỷ lệ chuyên cần của lớp đạt ...%; theo dõi sức khỏe, tình trạng dinh dưỡng của trẻ theo quy định. Tích cực tham gia các hội thi, hoạt động chuyên môn theo kế hoạch và nhiệm vụ được phân công.
>
> **2. Thực hiện quy trình chuyên môn, hồ sơ và các nhiệm vụ được giao**
>
> Xây dựng và thực hiện kế hoạch giáo dục đúng tiến độ; cập nhật hồ sơ, sổ sách đầy đủ, bảo đảm chất lượng. Quản lý, sử dụng và bảo quản tốt tài sản, thiết bị, đồ dùng, đồ chơi; xây dựng môi trường lớp học xanh, sạch, đẹp, an toàn. Thực hiện đầy đủ các báo cáo và nhiệm vụ kiểm định chất lượng, phổ cập giáo dục theo phân công.
>
> **3. Ứng dụng công nghệ thông tin, đổi mới sáng tạo và chuyển đổi số**
>
> Chủ động ứng dụng công nghệ thông tin trong tổ chức hoạt động giáo dục; thực hiện ... bài giảng có ứng dụng CNTT; đóng góp ... nội dung cho kho học liệu số và gửi ... tin, bài phục vụ công tác truyền thông của nhà trường. Thực hiện cập nhật, lưu trữ hồ sơ và dữ liệu trên các phần mềm được phân công.
>
> **4. Chấp hành kỷ luật, trách nhiệm và đạo đức nghề nghiệp**
>
> Chấp hành nghiêm chủ trương, chính sách, pháp luật của Nhà nước; nội quy, quy chế làm việc và quy định chuyên môn của nhà trường. Có tinh thần trách nhiệm, đoàn kết, phối hợp tốt với đồng nghiệp; giữ gìn phẩm chất, đạo đức và tác phong nhà giáo. Thực hiện đúng quy định về các khoản thu; tích cực tham gia hoạt động tập thể và hoàn thành nhiệm vụ được phân công.
>
> **5. Thực hiện nhiệm vụ phát triển trẻ, an sinh xã hội và phối hợp phụ huynh**
>
> Phối hợp với gia đình trong công tác chăm sóc, giáo dục trẻ; tích cực vận động trẻ ra lớp, duy trì sĩ số theo chỉ tiêu được giao. Kịp thời rà soát, cung cấp thông tin trẻ thuộc diện chính sách; quan tâm, hỗ trợ trẻ có hoàn cảnh khó khăn và trẻ cần sự hỗ trợ đặc biệt theo điều kiện thực tế.
>
> **6. Bảo đảm an ninh, an toàn và phòng ngừa vi phạm**
>
> Thực hiện nghiêm các quy định về bảo đảm an toàn cho trẻ; kiểm tra điều kiện an toàn trong lớp, thực hiện đúng quy trình đón, trả trẻ và phòng chống bạo lực học đường. Giữ gìn chuẩn mực ứng xử, bảo mật thông tin của trẻ và nhà trường; thực hiện báo cáo kịp thời các sự việc phát sinh thuộc trách nhiệm được giao.
>
> ## II- TỰ ĐỀ XUẤT XẾP LOẠI MỨC CHẤT LƯỢNG
>
> Căn cứ kết quả thực hiện nhiệm vụ, bảng KPI và các điều kiện đánh giá theo quy định, bản thân tự đề xuất mức xếp loại: **........................................**
>
> *Cá nhân tự đánh giá, ký và ghi rõ họ tên.*

Đây là mẫu tham khảo. Giáo viên chỉ giữ những nội dung đã thực hiện, bổ sung số liệu thực tế và minh chứng; không mặc định các nội dung trên đều đã đạt.

## 📋 3. Hướng dẫn giáo viên viết sao cho có chất lượng

Tôi đề nghị giáo viên thực hiện theo nguyên tắc: **Nhiệm vụ được giao → Kết quả thực hiện → Số liệu hoặc minh chứng.**

Ví dụ về cách chuyển từ nhận xét chung sang nhận xét theo KPI:

Cách viết chưa phù hợp

"Bản thân luôn cố gắng chăm sóc, giáo dục trẻ tốt, thực hiện đầy đủ công tác chuyên môn và tích cực ứng dụng công nghệ thông tin."

---

Cách viết nên áp dụng

"Thực hiện đầy đủ kế hoạch giáo dục theo độ tuổi; tỷ lệ chuyên cần của lớp đạt 96%, vượt 1 điểm phần trăm so với chỉ tiêu 95%; tổ chức 04 hoạt động có ứng dụng CNTT; hoàn thành các hồ sơ, báo cáo đúng thời hạn."

Số liệu 96%, 95% và 04 hoạt động chỉ là ví dụ minh họa, không phải kết quả thực tế của giáo viên.

## 💡 4. Những lưu ý khi triển khai tại trường

- Giáo viên cần căn cứ vào bảng KPI đã chấm để tự đánh giá, không đưa thành tích chưa có minh chứng.
- Nhiệm vụ chưa đến thời điểm thực hiện hoặc không thuộc đối tượng được giao thì không viết là đã hoàn thành.
- Nếu có chỉ số KPI chưa đạt, giáo viên cần nêu ngắn gọn nguyên nhân, biện pháp khắc phục; không chỉ liệt kê ưu điểm.
- Mức tự đề xuất xếp loại phải phù hợp với kết quả thực hiện nhiệm vụ và các điều kiện quy định, không chỉ căn cứ vào điểm số.
- Mẫu ảnh ghi **đánh giá theo tháng**, nhưng đoạn hướng dẫn bên trong lại ghi **theo quý**. Nhà trường cần thống nhất một kỳ đánh giá trong toàn văn bản trước khi phát cho giáo viên.

## ✅ 5. Đề xuất dành cho Hiệu trưởng

Để giáo viên dễ viết và hồ sơ thống nhất, tôi khuyến nghị nhà trường ban hành **một mẫu hướng dẫn tự đánh giá chung**, yêu cầu mỗi giáo viên trình bày 06 nội dung theo KPI, mỗi nội dung khoảng 2–4 câu, có thể rút gọn khi nhiệm vụ không phát sinh. Toàn bộ bản tự đánh giá nên gói gọn trong 1–2 trang A4.

Điều quan trọng nhất là giáo viên **viết những gì mình thực sự làm được, kết quả đạt đến đâu và có minh chứng gì**, giúp tổ chuyên môn và Ban giám hiệu có cơ sở đánh giá khách quan, công bằng.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

bạn trình bày cụ thể các chỉ số cụ thể trong các trục giúp mình nhe

---

ASSISTANT

# 📊 DANH MỤC CHI TIẾT 06 TRỤC KPI ĐÁNH GIÁ GIÁO VIÊN MẦM NON

**Trường Mầm non An Bình A – Năm học 2025–2026**

Căn cứ bộ tiêu chí thi đua của Trường Mầm non An Bình A và phương án quy đổi KPI đã xây dựng, tôi cụ thể hóa **38 chỉ số thuộc 06 trục, tổng 100 điểm**, làm cơ sở để giáo viên tự đánh giá kết quả thực hiện nhiệm vụ theo tháng, quý.

Mỗi chỉ số được trình bày gồm: mã tiêu chí thi đua gốc, nội dung KPI, yêu cầu cần đạt, điểm tối đa và minh chứng đánh giá.

## Trục 1. Kết quả thực hiện nhiệm vụ chăm sóc, giáo dục trẻ

06 chỉ số KPI

## 25 điểm

| STT | Nội dung chỉ số KPI | Điểm |
|--------|--------|--------|
| 1.1 | **Tỷ lệ trẻ suy dinh dưỡng nhẹ cân:** Không quá 1,25% theo kết quả theo dõi sức khỏe trẻ. | 5 |
| 1.2 | **Tỷ lệ trẻ suy dinh dưỡng thấp còi:** Dưới 1,25% theo bảng tổng hợp dinh dưỡng. | 4 |
| 1.3 | **Tỷ lệ trẻ béo phì:** Không quá 2% theo kết quả đánh giá dinh dưỡng. | 4 |
| 1.4 | **Tỷ lệ chuyên cần 2 buổi/ngày:** Lớp 5 tuổi đạt 95%; lớp 4 tuổi đạt 85%; lớp 3 tuổi và nhóm trẻ đạt 80%. | 7 |
| 1.5 | **Tham gia các hội thi bắt buộc:** Thực hiện đầy đủ 100% hội thi theo kế hoạch và phân công của nhà trường. | 3 |
| 1.6 | **Thành tích hội thi cấp cơ sở:** Đạt giải Nhất theo tiêu chí thi đua khi được phân công tham gia hội thi phù hợp. | 2 |
|  | **Tổng điểm trục 1** | **25** |

Mã tiêu chí gốc: 4.1, 4.2, 4.3, 5, 6, 7. Minh chứng: Bảng tổng hợp dinh dưỡng, sổ chuyên cần, danh sách tham gia hội thi, quyết định công nhận thành tích.

**Gợi ý giáo viên tự đánh giá:** Nêu kết quả chuyên cần thực tế của lớp, tình trạng dinh dưỡng của trẻ, những biện pháp chăm sóc đã thực hiện và kết quả tham gia hội thi. Chỉ nêu thành tích đã có minh chứng.

## Trục 2. Quy trình chuyên môn, hồ sơ, thiết bị và kiểm định

08 chỉ số KPI

## 15 điểm

| STT | Nội dung chỉ số KPI | Điểm |
|--------|--------|--------|
| 2.1 | **Quản lý tài sản:** Có sổ theo dõi tài sản, cập nhật và quản lý tài sản lớp đúng quy định. | 2 |
| 2.2 | **Bổ sung đồ dùng, đồ chơi:** Có tăng đồ dùng, đồ chơi từ nguồn xã hội hóa hợp pháp, tự nguyện so với đầu năm học, không tính thiết bị được cấp. | 2 |
| 2.3 | **Bảo quản thiết bị, đồ dùng, đồ chơi:** Thực hiện vệ sinh, bảo quản, sử dụng đồ dùng, đồ chơi an toàn và hiệu quả. | 2 |
| 2.4 | **Môi trường giáo dục:** Xây dựng lớp học đạt tiêu chuẩn xanh, sạch, đẹp. | 2 |
| 2.5 | **Kiểm định chất lượng giáo dục:** Hoàn thành các nhiệm vụ, hồ sơ và minh chứng kiểm định được phân công. | 2 |
| 2.6 | **Phổ cập giáo dục trẻ 5 tuổi:** Hoàn thành nhiệm vụ điều tra, cập nhật và cung cấp số liệu theo phân công. | 2 |
| 2.7 | **Công tác báo cáo:** Thực hiện đầy đủ, chính xác, đúng thời gian quy định; đối chiếu số lần và thời gian báo cáo trễ theo tiêu chí gốc. | 2 |
| 2.8 | **Thể thức văn bản:** Thực hiện văn bản, báo cáo đúng thể thức theo Nghị định 30/2020/NĐ-CP khi thuộc phạm vi áp dụng. | 1 |
|  | **Tổng điểm trục 2** | **15** |

Mã tiêu chí gốc: 8, 9, 10, 12, 29, 30, 35, 37. Minh chứng: Sổ tài sản, phiếu kiểm tra lớp, hồ sơ kiểm định, hồ sơ phổ cập và các báo cáo đã thực hiện.

**Gợi ý giáo viên tự đánh giá:** Nêu những nhiệm vụ quản lý hồ sơ, thiết bị, xây dựng môi trường giáo dục và các báo cáo đã hoàn thành; ghi rõ việc thực hiện đúng hoặc chưa đúng thời hạn.

## Trục 3. Ứng dụng công nghệ thông tin, đổi mới sáng tạo và chuyển đổi số

04 chỉ số KPI

## 10 điểm

| STT | Nội dung chỉ số KPI | Điểm |
|--------|--------|--------|
| 3.1 | **Ứng dụng CNTT trong giảng dạy:** Thực hiện ít nhất 01 bài giảng có ứng dụng CNTT/chủ đề. | 3 |
| 3.2 | **Xây dựng kho học liệu số:** Cung cấp ít nhất 02 nội dung/năm cho kho học liệu của đơn vị, đánh giá theo tiến độ được giao. | 3 |
| 3.3 | **Công tác truyền thông:** Gửi ít nhất 01 tin, bài/tháng cho website nhà trường. | 2 |
| 3.4 | **Thực hiện chuyển đổi số:** Số hóa hồ sơ, cập nhật và cung cấp thông tin trên phần mềm kịp thời, đúng quy định. | 2 |
|  | **Tổng điểm trục 3** | **10** |

Mã tiêu chí gốc: 31, 32, 33, 34. Minh chứng: Giáo án điện tử, file bài giảng, sản phẩm học liệu số, đường dẫn tin bài và hồ sơ cập nhật phần mềm.

**Gợi ý giáo viên tự đánh giá:** Nêu số bài giảng ứng dụng CNTT đã thực hiện, sản phẩm học liệu số đã đóng góp, số tin bài đã gửi và kết quả cập nhật hồ sơ điện tử.

## Trục 4. Kỷ luật, trách nhiệm, đạo đức, công tác Đảng và đoàn thể

08 chỉ số KPI

## 15 điểm

| STT | Nội dung chỉ số KPI | Điểm |
|--------|--------|--------|
| 4.1 | **Điều kiện về đảng viên:** Thực hiện nội dung tiêu chí thi đua gốc đối với viên chức thuộc đối tượng áp dụng. | 1 |
| 4.2 | **Chấp hành quy định thu tiền:** Không tự ý thu tiền phụ huynh khi chưa được phân công. | 2 |
| 4.3 | **Thực hiện các khoản thu:** Không thực hiện khoản thu ngoài quy định. | 2 |
| 4.4 | **Phối hợp Ban đại diện cha mẹ trẻ:** Không phát động các khoản thu trái quy định thông qua Ban đại diện. | 2 |
| 4.5 | **Thực hiện nhiệm vụ đảng viên:** Hoàn thành tốt nhiệm vụ trở lên đối với giáo viên là đảng viên. | 1 |
| 4.6 | **Thực hiện nhiệm vụ đoàn viên:** Hoàn thành tốt nhiệm vụ đối với giáo viên thuộc tổ chức Đoàn. | 1 |
| 4.7 | **Đạo đức, ứng xử và đoàn kết:** Không có hành vi nhũng nhiễu, gây mất đoàn kết được xác minh; thực hiện chuẩn mực đạo đức nghề nghiệp. | 2 |
| 4.8 | **Chấp hành nội quy, quy chế:** Không vi phạm nội quy nhà trường, quy chế làm việc và quy chế chuyên môn. | 4 |
|  | **Tổng điểm trục 4** | **15** |

Mã tiêu chí gốc: 2, 15, 16, 17, 18, 19, 22, 28. Minh chứng: Kết quả đánh giá Đảng, Đoàn khi thuộc đối tượng; hồ sơ kiểm tra, nhận xét của tổ chuyên môn và kết quả xác minh.

**Gợi ý giáo viên tự đánh giá:** Nêu kết quả chấp hành nội quy, quy chế, đạo đức nghề nghiệp, tinh thần phối hợp, trách nhiệm công việc. Giáo viên là đảng viên hoặc đoàn viên bổ sung kết quả thực hiện nhiệm vụ tương ứng.

## Trục 5. Phát triển trẻ, an sinh xã hội và hỗ trợ trẻ

03 chỉ số KPI

## 15 điểm

| STT | Nội dung chỉ số KPI | Điểm |
|--------|--------|--------|
| 5.1 | **Thực hiện chỉ tiêu sĩ số:** Đáp ứng chỉ tiêu theo độ tuổi và phân công: nhà trẻ 8 trẻ/GV; MG 3 tuổi 10 trẻ/GV; MG 4 tuổi 12 trẻ/GV; MG 5 tuổi 14 trẻ/GV. | 5 |
| 5.2 | **Thực hiện chính sách hỗ trợ trẻ:** Cung cấp kịp thời, đầy đủ 100% thông tin trẻ thuộc diện miễn, giảm học phí và hỗ trợ chi phí học tập theo quy định. | 5 |
| 5.3 | **Hỗ trợ trẻ có hoàn cảnh đặc biệt:** Phối hợp vận động, hỗ trợ trẻ khó khăn theo nhiệm vụ được giao, bảo đảm đúng quy định và tự nguyện. | 5 |
|  | **Tổng điểm trục 5** | **15** |

Mã tiêu chí gốc: 1, 13, 14. Minh chứng: Danh sách sĩ số, hồ sơ chính sách, danh sách trẻ được hỗ trợ, biên bản phối hợp và xác nhận của nhà trường.

**Gợi ý giáo viên tự đánh giá:** Nêu số trẻ thực tế của lớp, kết quả huy động và duy trì sĩ số, số trường hợp trẻ được hỗ trợ chính sách hoặc được giúp đỡ. Nếu không có trẻ thuộc diện chính sách hoặc hoàn cảnh đặc biệt, ghi rõ tình hình thực tế.

## Trục 6. An ninh, an toàn và phòng ngừa vi phạm

09 chỉ số KPI

## 20 điểm

| STT | Nội dung chỉ số KPI | Điểm |
|--------|--------|--------|
| 6.1 | **Bảo đảm an toàn trường lớp:** Lớp học đạt yêu cầu về trường học an toàn theo quy định. | 4 |
| 6.2 | **Chấp hành pháp luật:** Không có hành vi vi phạm pháp luật thuộc phạm vi tiêu chí thi đua gốc đã được xác minh. | 2 |
| 6.3 | **Thực hiện đón, trả trẻ:** Không tổ chức giữ trẻ trễ trái quy định; thực hiện đúng quy trình bàn giao trẻ. | 2 |
| 6.4 | **Bảo vệ thông tin, bí mật nhà nước:** Không làm lộ, lọt bí mật hoặc phát tán thông tin sai sự thật. | 2 |
| 6.5 | **Tuân thủ pháp luật liên quan đến hoạt động tôn giáo:** Không có hành vi vi phạm pháp luật được xác minh; không đánh giá dựa trên niềm tin cá nhân. | 1 |
| 6.6 | **Ứng xử trên mạng xã hội:** Không vi phạm quy định về ứng xử, chia sẻ thông tin trên mạng xã hội. | 2 |
| 6.7 | **Chấp hành quy định địa phương:** Không có vi phạm được xác minh theo nội dung tiêu chí gốc. | 2 |
| 6.8 | **Phòng chống bạo lực học đường:** Không có hành vi bạo lực thể chất hoặc tinh thần đối với trẻ và đồng nghiệp. | 4 |
| 6.9 | **Báo cáo sự việc bất thường:** Báo cáo kịp thời các sự việc bất thường phát sinh tại nhóm, lớp, tổ. | 1 |
|  | **Tổng điểm trục 6** | **20** |

Mã tiêu chí gốc: 11, 20, 21, 23, 24, 25, 26, 27, 36. Minh chứng: Biên bản kiểm tra an toàn, sổ đón trả trẻ, hồ sơ báo cáo sự việc và kết quả xác minh có thẩm quyền.

**Gợi ý giáo viên tự đánh giá:** Nêu kết quả thực hiện các biện pháp phòng ngừa tai nạn thương tích, bảo đảm an toàn cho trẻ, thực hiện quy trình đón trả trẻ, phòng chống bạo lực và xử lý các sự việc phát sinh.

---

## 📋 Bảng tổng hợp điểm KPI 06 trục

| Trục đánh giá | Số chỉ số | Điểm |
|--------|--------|--------|
| Trục 1 – Chăm sóc, giáo dục trẻ | 6 | 25 |
| Trục 2 – Chuyên môn, hồ sơ và kiểm định | 8 | 15 |
| Trục 3 – CNTT và chuyển đổi số | 4 | 10 |
| Trục 4 – Kỷ luật, đạo đức và trách nhiệm | 8 | 15 |
| Trục 5 – Phát triển trẻ và an sinh | 3 | 15 |
| Trục 6 – An ninh, an toàn | 9 | 20 |
| **Tổng cộng** | **38** | **100** |

Phân bổ trọng số KPI

06 trục 100/100 điểm

## ⚠️ Những lưu ý quan trọng đối với Hiệu trưởng

Thứ nhất, đây là **phương án quy đổi điểm KPI nội bộ** từ tiêu chí thi đua nhà trường, không phải trọng số chính thức đã được xác nhận trong Phụ lục 3. Trước khi dùng để xếp loại, nhà trường cần thống nhất và phê duyệt phương án.

Thứ hai, bộ tiêu chí thi đua gốc có 37 nội dung được nêu nhưng hình ảnh chưa thể hiện tiêu chí số 3; mục số 4 lại chia thành 4.1, 4.2, 4.3. Vì vậy danh mục hiện có 38 dòng chỉ số được quy đổi, chưa được xem là đã bao phủ nội dung số 3 chưa có dữ liệu.

Thứ ba, khi đánh giá theo tháng hoặc quý, cần phân biệt những nhiệm vụ đã đến hạn, chưa đến hạn và không thuộc đối tượng áp dụng. Không nên trừ điểm giáo viên vì không phải đảng viên, đoàn viên, không được tham gia hội thi hoặc không có trẻ thuộc diện hỗ trợ. Các tiêu chí về an toàn, đạo đức và vi phạm nghiêm trọng phải được xem xét theo điều kiện khống chế riêng.

## ✅ Đề xuất cách triển khai

Tôi khuyến nghị sử dụng **cùng một danh mục 38 chỉ số** cho ba hoạt động: giáo viên tự chấm KPI, tổ trưởng và Ban giám hiệu xác nhận kết quả, giáo viên viết bản tự đánh giá theo 06 trục.

Như vậy, mỗi nội dung giáo viên trình bày trong bản tự đánh giá đều có thể đối chiếu trực tiếp với mã KPI, điểm số và minh chứng tương ứng. Điều này giúp việc đánh giá thống nhất, rõ ràng, hạn chế nhận xét cảm tính và giảm khối lượng hồ sơ cho giáo viên.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

Này là nội dung diễn giải của lãnh đạo quản lý.  Bạn giúp tôi diễn giải đối với giáo viên cho từng nội dung trục (6 trục)

---

ASSISTANT

# 📌 NỘI DUNG DIỄN GIẢI 06 TRỤC KPI DÀNH CHO GIÁO VIÊN MẦM NON

**Trường Mầm non An Bình A – Áp dụng trong đánh giá kết quả thực hiện nhiệm vụ theo tháng, quý**

Dựa trên nội dung diễn giải dành cho cán bộ lãnh đạo, quản lý mà bạn gửi, tôi chuyển thành **nội dung diễn giải dành riêng cho giáo viên mầm non**, bám sát 06 trục KPI, 38 chỉ số và thang điểm 100 đã xây dựng.

Tôi sử dụng văn phong hành chính ngắn gọn, tập trung vào nhiệm vụ và kết quả cần đạt, phù hợp để **đưa trực tiếp vào cột “Nội dung diễn giải” của bảng danh mục KPI giáo viên**.

> **writing · document**
>
> ### TRỤC 1. KẾT QUẢ THỰC HIỆN NHIỆM VỤ CHĂM SÓC, GIÁO DỤC TRẺ (25 điểm)
>
> - Thực hiện đầy đủ, đúng tiến độ và có chất lượng chương trình, kế hoạch chăm sóc, nuôi dưỡng, giáo dục trẻ theo độ tuổi và nhiệm vụ được phân công.
> - Thực hiện tốt công tác theo dõi sức khỏe, đánh giá tình trạng dinh dưỡng của trẻ; phối hợp thực hiện các biện pháp phòng, chống suy dinh dưỡng, thừa cân, béo phì, bảo đảm các chỉ tiêu theo quy định của nhà trường.
> - Thực hiện các biện pháp duy trì và nâng cao tỷ lệ chuyên cần của trẻ; phối hợp với cha mẹ trẻ trong việc đưa trẻ đến trường đều đặn, bảo đảm chỉ tiêu chuyên cần theo từng độ tuổi.
> - Tích cực tham gia các hội thi, hoạt động giáo dục và phong trào chuyên môn theo kế hoạch; thực hiện đầy đủ nhiệm vụ được giao, phấn đấu đạt kết quả tốt.
> - Hoàn thành các chỉ tiêu, nhiệm vụ chăm sóc, giáo dục trẻ theo kế hoạch và sự phân công của nhà trường.
>
> ### TRỤC 2. THỰC HIỆN QUY TRÌNH CHUYÊN MÔN, HỒ SƠ, THIẾT BỊ VÀ KIỂM ĐỊNH CHẤT LƯỢNG (15 điểm)
>
> - Thực hiện nghiêm túc quy chế chuyên môn, kế hoạch giáo dục và các quy trình chăm sóc, nuôi dưỡng, giáo dục trẻ; bảo đảm đúng nội dung, tiến độ và yêu cầu chất lượng.
> - Quản lý, sử dụng, bảo quản tài sản, thiết bị, đồ dùng, đồ chơi đúng quy định; tích cực làm và bổ sung đồ dùng, đồ chơi, xây dựng môi trường lớp học xanh, sạch, đẹp, an toàn, phù hợp với độ tuổi.
> - Thực hiện đầy đủ, chính xác, cập nhật kịp thời các loại hồ sơ, sổ sách, biểu mẫu và báo cáo thuộc nhiệm vụ được phân công; bảo đảm đúng thời hạn và thể thức quy định.
> - Tích cực tham gia công tác kiểm định chất lượng giáo dục, phổ cập giáo dục mầm non cho trẻ 5 tuổi; thu thập, cập nhật số liệu và cung cấp minh chứng đầy đủ, chính xác theo phân công.
> - Chủ động khắc phục những hạn chế được phát hiện qua kiểm tra chuyên môn; hoàn thành các nhiệm vụ khác do tổ chuyên môn và Ban giám hiệu phân công.
>
> ### TRỤC 3. ỨNG DỤNG CÔNG NGHỆ THÔNG TIN, ĐỔI MỚI SÁNG TẠO VÀ CHUYỂN ĐỔI SỐ (10 điểm)
>
> - Chủ động nghiên cứu, đổi mới phương pháp tổ chức các hoạt động chăm sóc, giáo dục trẻ; ứng dụng công nghệ thông tin phù hợp, hiệu quả trong tổ chức hoạt động giáo dục theo chủ đề.
> - Tích cực xây dựng, khai thác và chia sẻ bài giảng điện tử, video, hình ảnh, tài liệu và các sản phẩm học liệu số; đóng góp nội dung cho kho học liệu chung của nhà trường theo chỉ tiêu được giao.
> - Thực hiện tốt công tác truyền thông giáo dục; chủ động viết và cung cấp tin, bài, hình ảnh hoạt động của nhóm, lớp phục vụ website và các kênh truyền thông chính thức của nhà trường.
> - Thực hiện cập nhật, quản lý, lưu trữ hồ sơ, dữ liệu trên các phần mềm và nền tảng số được triển khai; bảo đảm thông tin đầy đủ, chính xác, kịp thời và an toàn.
> - Tích cực tự học, nâng cao kỹ năng số; phát huy tinh thần đổi mới, sáng tạo trong thực hiện nhiệm vụ chuyên môn.
>
> ### TRỤC 4. CHẤP HÀNH KỶ LUẬT, TRÁCH NHIỆM, ĐẠO ĐỨC NGHỀ NGHIỆP VÀ CÔNG TÁC ĐẢNG, ĐOÀN THỂ (15 điểm)
>
> - Chấp hành nghiêm chủ trương của Đảng, chính sách, pháp luật của Nhà nước; nội quy, quy chế làm việc, quy chế chuyên môn và các quy định của ngành, của nhà trường.
> - Thực hiện tốt phẩm chất, đạo đức, tác phong nhà giáo; có tinh thần trách nhiệm, tận tụy với công việc, yêu thương, tôn trọng trẻ; giữ gìn uy tín, hình ảnh của giáo viên và nhà trường.
> - Thực hiện đúng quy định về công tác tài chính; không tự ý thu tiền phụ huynh, không thực hiện hoặc vận động các khoản thu ngoài quy định.
> - Có tinh thần đoàn kết, hợp tác, hỗ trợ đồng nghiệp; giao tiếp, ứng xử văn minh, chuẩn mực với trẻ, cha mẹ trẻ và các thành viên trong nhà trường.
> - Tích cực tham gia sinh hoạt, hoạt động của tổ chuyên môn, đoàn thể và các phong trào do nhà trường phát động; thực hiện tốt nhiệm vụ của đảng viên, đoàn viên đối với cá nhân thuộc đối tượng.
> - Chủ động thực hiện nhiệm vụ được giao; không vi phạm kỷ luật, nội quy, quy chế và đạo đức nghề nghiệp.
>
> ### TRỤC 5. PHÁT TRIỂN TRẺ, THỰC HIỆN AN SINH XÃ HỘI VÀ PHỐI HỢP HỖ TRỢ TRẺ (15 điểm)
>
> - Thực hiện tốt công tác huy động, duy trì sĩ số trẻ đến lớp; phối hợp với gia đình và nhà trường thực hiện các chỉ tiêu phát triển số lượng trẻ theo độ tuổi và nhiệm vụ được phân công.
> - Thường xuyên quan tâm, theo dõi tình hình học tập, sức khỏe, hoàn cảnh gia đình và nhu cầu của trẻ; kịp thời phát hiện những trường hợp cần được quan tâm, hỗ trợ.
> - Phối hợp rà soát, cung cấp đầy đủ, chính xác và kịp thời thông tin, hồ sơ trẻ thuộc diện được hưởng chính sách miễn, giảm học phí và các chế độ hỗ trợ theo quy định.
> - Tích cực phối hợp với cha mẹ trẻ, nhà trường và các tổ chức liên quan trong việc quan tâm, hỗ trợ trẻ có hoàn cảnh khó khăn, trẻ thuộc diện chính sách và trẻ cần sự hỗ trợ đặc biệt.
> - Thực hiện tốt công tác phối hợp giữa gia đình và nhà trường; tạo điều kiện để trẻ được chăm sóc, giáo dục, tham gia các hoạt động và phát triển phù hợp với khả năng, nhu cầu của từng trẻ.
>
> ### TRỤC 6. BẢO ĐẢM AN NINH, AN TOÀN TRƯỜNG HỌC VÀ PHÒNG NGỪA VI PHẠM (20 điểm)
>
> - Chấp hành nghiêm các quy định của pháp luật, của ngành và nhà trường về bảo đảm an ninh, trật tự, an toàn trường học và phòng ngừa các hành vi vi phạm.
> - Thực hiện đầy đủ các biện pháp bảo đảm an toàn về thể chất, tinh thần cho trẻ; thường xuyên kiểm tra, phát hiện và xử lý kịp thời nguy cơ mất an toàn trong môi trường nhóm, lớp.
> - Thực hiện nghiêm quy trình đón, trả trẻ, quản lý trẻ trong các hoạt động chăm sóc, giáo dục; không tự ý tổ chức giữ trẻ ngoài thời gian quy định.
> - Thực hiện tốt công tác phòng, chống bạo lực học đường; không có hành vi xâm phạm thân thể, xúc phạm danh dự, nhân phẩm hoặc gây tổn thương tinh thần đối với trẻ và đồng nghiệp.
> - Chấp hành quy định về bảo vệ bí mật nhà nước, bảo mật thông tin của trẻ, phụ huynh và nhà trường; sử dụng mạng xã hội đúng chuẩn mực, không đăng tải, chia sẻ thông tin trái quy định.
> - Chủ động phòng ngừa, phát hiện và báo cáo kịp thời các sự việc bất thường, nguy cơ mất an toàn hoặc tình huống phát sinh tại nhóm, lớp; phối hợp xử lý theo đúng thẩm quyền và quy trình.
> - Thực hiện nghiêm các quy định về an ninh, trật tự tại địa phương; góp phần xây dựng môi trường giáo dục an toàn, lành mạnh, thân thiện.

## 📋 Hướng dẫn sử dụng trong bảng KPI

| Trục | Số chỉ số | Điểm tối đa |
|--------|--------|--------|
| Trục 1 – Chăm sóc, giáo dục trẻ | 6 | 25 |
| Trục 2 – Chuyên môn, hồ sơ, kiểm định | 8 | 15 |
| Trục 3 – CNTT, đổi mới, chuyển đổi số | 4 | 10 |
| Trục 4 – Kỷ luật, đạo đức, trách nhiệm | 8 | 15 |
| Trục 5 – Phát triển trẻ và an sinh | 3 | 15 |
| Trục 6 – An toàn và phòng ngừa vi phạm | 9 | 20 |
| **Tổng cộng** | **38** | **100** |

**Đối với cột “Nội dung diễn giải” trong Excel:** Bạn có thể sử dụng nguyên văn từng phần tương ứng với trục. Các câu được diễn đạt dưới dạng yêu cầu thực hiện nhiệm vụ, không phải lời khẳng định giáo viên đã hoàn thành, nên phù hợp với danh mục KPI dùng chung.

**Đối với bản tự đánh giá của giáo viên:** Giáo viên căn cứ các nội dung này để trình bày kết quả thực tế; bổ sung số liệu, minh chứng và nêu rõ chỉ tiêu chưa đạt (nếu có).

### 💡 Đề xuất của tôi

Để bảng KPI có chất lượng quản lý và tránh trùng lặp, nên phân biệt rõ:

- **Nội dung diễn giải:** Xác định giáo viên phải thực hiện những nhiệm vụ gì trong từng trục.
- **Chỉ số KPI:** Xác định kết quả cụ thể cần đạt.
- **Minh chứng:** Xác định tài liệu hoặc kết quả dùng để kiểm tra.
- **Điểm đánh giá:** Phản ánh mức độ hoàn thành được xác nhận.

Sáu phần diễn giải trên có thể dùng chung cho giáo viên nhà trẻ, mẫu giáo 3 tuổi, 4 tuổi và 5 tuổi; khi chấm điểm cần áp dụng đúng chỉ tiêu theo từng độ tuổi và nhiệm vụ được phân công.

**Lưu ý:** Đây là nội dung diễn giải theo phương án KPI 06 trục đã quy đổi cho nhà trường, không phải nguyên văn mô tả trục của Phụ lục 3. Trước khi ban hành chính thức, cần đối chiếu lại khung bắt buộc của cấp có thẩm quyền.

---

USER

giúp tôi trình bày sang file word giúp tôi

---

ASSISTANT

Mình sẽ chuyển nội dung 06 trục KPI thành file Word có định dạng hành chính, gồm phần diễn giải dành cho giáo viên, bảng chỉ số – điểm của từng trục và hướng dẫn tự đánh giá. Mình sẽ căn chỉnh khổ A4, bảng biểu và ngắt trang để bạn dễ in hoặc chỉnh sửa.

---

ASSISTANT

Mình đã bố trí nội dung thành **tài liệu Word hướng dẫn 06 trục KPI dành cho giáo viên Trường Mầm non An Bình A**, kết hợp phần diễn giải nhiệm vụ với bảng 38 chỉ số, tổng 100 điểm.

Tài liệu được thiết kế khổ A4, phông Times New Roman, có tiêu đề từng trục, bảng điểm, minh chứng và gợi ý giáo viên tự đánh giá; phù hợp để chỉnh sửa, in ấn và triển khai trong tổ chuyên môn.

## Tài liệu Word – Hướng dẫn KPI giáo viên

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="mnab-word6" class="w-full space-y-3">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="flex gap-3 items-center">
      <div class="rounded-lg bg-blue-100 text-blue-800 p-3">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h9l5 5v14a1 1 0 0 1-1 1H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z"/><path d="M15 2v6h5M8 13h8M8 17h8"/></svg>
      </div>
      <div class="min-w-0">
        <div class="font-semibold">Huong_dan_6_truc_KPI_Giao_vien_An_Binh_A.docx</div>
        <div class="text-sm opacity-65">06 trục · 38 chỉ số · 100 điểm</div>
      </div>
    </div>
    <button type="button" id="mnab-word-button" class="w-full rounded-lg py-3 px-4 bg-blue-700 hover:bg-blue-800 text-white font-semibold cursor-pointer">Tải tài liệu Word (.docx)</button>
    <p class="text-xs opacity-70" id="mnab-word-status" role="status">Nhấn nút để tạo và lưu tài liệu Word về thiết bị.</p>
  </div>
  <div class="rounded-lg border p-3 text-sm space-y-2">
    <div class="font-medium">Nội dung tài liệu</div>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 opacity-85">
      <div>✓ Diễn giải nhiệm vụ theo 06 trục</div>
      <div>✓ Bảng chi tiết 38 chỉ số KPI</div>
      <div>✓ Điểm tối đa từng tiêu chí</div>
      <div>✓ Minh chứng và hướng dẫn tự đánh giá</div>
      <div>✓ Bảng tổng hợp 100 điểm</div>
      <div>✓ Định dạng trang in A4</div>
    </div>
  </div>
</div>
<script>
(function(){
const root=document.getElementById("mnab-word6");
if(!root||root.dataset.ready)return;root.dataset.ready="1";
const sections=[
{
title:"KẾT QUẢ THỰC HIỆN NHIỆM VỤ CHĂM SÓC, GIÁO DỤC TRẺ",points:25,
bullets:[
"Thực hiện đầy đủ, đúng tiến độ và có chất lượng chương trình, kế hoạch chăm sóc, nuôi dưỡng, giáo dục trẻ theo độ tuổi và nhiệm vụ được phân công.",
"Theo dõi sức khỏe, đánh giá tình trạng dinh dưỡng của trẻ; phối hợp thực hiện các biện pháp phòng, chống suy dinh dưỡng, thừa cân, béo phì, bảo đảm các chỉ tiêu theo quy định của nhà trường.",
"Thực hiện các biện pháp duy trì và nâng cao tỷ lệ chuyên cần; phối hợp với cha mẹ trẻ đưa trẻ đến trường đều đặn, phấn đấu đạt chỉ tiêu theo từng độ tuổi.",
"Tích cực tham gia hội thi, hoạt động giáo dục và phong trào chuyên môn theo kế hoạch; thực hiện đầy đủ nhiệm vụ được giao, phấn đấu đạt kết quả tốt.",
"Hoàn thành các chỉ tiêu, nhiệm vụ chăm sóc và giáo dục trẻ theo kế hoạch, sự phân công của nhà trường."
],
items:[
["1.1","Tỷ lệ trẻ suy dinh dưỡng nhẹ cân: Không quá 1,25% theo kết quả theo dõi sức khỏe trẻ.",5],
["1.2","Tỷ lệ trẻ suy dinh dưỡng thấp còi: Dưới 1,25% theo bảng tổng hợp dinh dưỡng.",4],
["1.3","Tỷ lệ trẻ béo phì: Không quá 2% theo kết quả đánh giá dinh dưỡng.",4],
["1.4","Tỷ lệ chuyên cần 2 buổi/ngày: Lớp 5 tuổi 95%; lớp 4 tuổi 85%; lớp 3 tuổi và nhóm trẻ 80%.",7],
["1.5","Tham gia hội thi bắt buộc: Đầy đủ 100% theo kế hoạch và phân công.",3],
["1.6","Thành tích hội thi cấp cơ sở: Đạt giải Nhất theo tiêu chí thi đua khi được phân công tham gia hội thi phù hợp.",2]
],
codes:"4.1, 4.2, 4.3, 5, 6, 7",
proof:"Bảng tổng hợp dinh dưỡng, sổ chuyên cần, danh sách tham gia hội thi, quyết định công nhận thành tích.",
guide:"Nêu tỷ lệ chuyên cần thực tế, tình trạng dinh dưỡng của trẻ, các biện pháp chăm sóc đã thực hiện và kết quả tham gia hội thi; chỉ nêu thành tích có minh chứng."
},
{
title:"QUY TRÌNH CHUYÊN MÔN, HỒ SƠ, THIẾT BỊ VÀ KIỂM ĐỊNH",points:15,
bullets:[
"Thực hiện nghiêm túc quy chế chuyên môn, kế hoạch giáo dục và quy trình chăm sóc, nuôi dưỡng, giáo dục trẻ, bảo đảm nội dung, tiến độ và yêu cầu chất lượng.",
"Quản lý, sử dụng, bảo quản tài sản, thiết bị, đồ dùng, đồ chơi đúng quy định; tích cực làm và bổ sung đồ dùng, đồ chơi; xây dựng môi trường lớp xanh, sạch, đẹp, an toàn, phù hợp độ tuổi.",
"Thực hiện đầy đủ, chính xác, cập nhật kịp thời hồ sơ, sổ sách, biểu mẫu và báo cáo thuộc nhiệm vụ được phân công; bảo đảm thời hạn và thể thức.",
"Tham gia công tác kiểm định chất lượng giáo dục, phổ cập giáo dục mầm non cho trẻ 5 tuổi; cập nhật số liệu và cung cấp minh chứng theo phân công.",
"Chủ động khắc phục hạn chế được phát hiện qua kiểm tra chuyên môn; hoàn thành nhiệm vụ khác do tổ chuyên môn và Ban giám hiệu phân công."
],
items:[
["2.1","Quản lý tài sản: Có sổ theo dõi, cập nhật và quản lý tài sản lớp đúng quy định.",2],
["2.2","Bổ sung đồ dùng, đồ chơi: Có tăng từ nguồn xã hội hóa hợp pháp, tự nguyện so với đầu năm, không tính thiết bị được cấp.",2],
["2.3","Bảo quản thiết bị, đồ dùng, đồ chơi: Thực hiện vệ sinh, bảo quản, sử dụng an toàn và hiệu quả.",2],
["2.4","Môi trường giáo dục: Xây dựng lớp học đạt tiêu chuẩn xanh, sạch, đẹp.",2],
["2.5","Kiểm định chất lượng giáo dục: Hoàn thành nhiệm vụ, hồ sơ và minh chứng được phân công.",2],
["2.6","Phổ cập giáo dục trẻ 5 tuổi: Hoàn thành điều tra, cập nhật và cung cấp số liệu theo phân công.",2],
["2.7","Công tác báo cáo: Thực hiện đầy đủ, chính xác, đúng hạn theo tiêu chí thi đua.",2],
["2.8","Thể thức văn bản: Đúng Nghị định 30/2020/NĐ-CP khi thuộc phạm vi áp dụng.",1]
],
codes:"8, 9, 10, 12, 29, 30, 35, 37",
proof:"Sổ tài sản, phiếu kiểm tra lớp, hồ sơ kiểm định, hồ sơ phổ cập, văn bản và báo cáo đã thực hiện.",
guide:"Nêu những hồ sơ, nhiệm vụ quản lý thiết bị, xây dựng môi trường giáo dục, hoạt động kiểm định, phổ cập và báo cáo đã hoàn thành; xác định đúng hạn hoặc chưa đúng hạn."
},
{
title:"ỨNG DỤNG CÔNG NGHỆ THÔNG TIN, ĐỔI MỚI SÁNG TẠO VÀ CHUYỂN ĐỔI SỐ",points:10,
bullets:[
"Chủ động nghiên cứu, đổi mới phương pháp tổ chức hoạt động chăm sóc, giáo dục trẻ; ứng dụng công nghệ thông tin phù hợp, hiệu quả theo chủ đề.",
"Xây dựng, khai thác và chia sẻ bài giảng điện tử, video, hình ảnh, tài liệu và sản phẩm học liệu số; đóng góp cho kho học liệu chung theo chỉ tiêu.",
"Thực hiện công tác truyền thông giáo dục; viết và cung cấp tin, bài, hình ảnh hoạt động của nhóm, lớp phục vụ các kênh truyền thông chính thức của nhà trường.",
"Cập nhật, quản lý, lưu trữ hồ sơ, dữ liệu trên phần mềm và nền tảng số được triển khai; bảo đảm đầy đủ, chính xác, kịp thời và an toàn.",
"Tích cực tự học, nâng cao kỹ năng số và phát huy tinh thần đổi mới, sáng tạo trong thực hiện nhiệm vụ chuyên môn."
],
items:[
["3.1","Ứng dụng CNTT trong giảng dạy: Ít nhất 01 bài giảng có ứng dụng CNTT/chủ đề.",3],
["3.2","Xây dựng kho học liệu số: Ít nhất 02 nội dung/năm, đánh giá theo tiến độ được giao.",3],
["3.3","Công tác truyền thông: Gửi ít nhất 01 tin, bài/tháng cho website nhà trường.",2],
["3.4","Thực hiện chuyển đổi số: Số hóa hồ sơ, cập nhật dữ liệu và phần mềm kịp thời.",2]
],
codes:"31, 32, 33, 34",
proof:"Giáo án điện tử, bài giảng, sản phẩm học liệu số, đường dẫn tin bài, hồ sơ trên phần mềm.",
guide:"Nêu số bài giảng ứng dụng CNTT đã thực hiện, số sản phẩm học liệu đã đóng góp, số tin bài đã gửi và kết quả cập nhật hồ sơ điện tử."
},
{
title:"KỶ LUẬT, TRÁCH NHIỆM, ĐẠO ĐỨC NGHỀ NGHIỆP, CÔNG TÁC ĐẢNG VÀ ĐOÀN THỂ",points:15,
bullets:[
"Chấp hành nghiêm chủ trương của Đảng, chính sách, pháp luật của Nhà nước; nội quy, quy chế làm việc, quy chế chuyên môn và các quy định của ngành, của nhà trường.",
"Thực hiện tốt phẩm chất, đạo đức, tác phong nhà giáo; có tinh thần trách nhiệm, tận tụy với công việc, yêu thương và tôn trọng trẻ, giữ gìn uy tín nhà giáo.",
"Thực hiện đúng quy định về tài chính; không tự ý thu tiền phụ huynh, không thực hiện hoặc vận động khoản thu ngoài quy định.",
"Có tinh thần đoàn kết, hợp tác, hỗ trợ đồng nghiệp; giao tiếp, ứng xử văn minh, chuẩn mực với trẻ, cha mẹ trẻ và các thành viên trong nhà trường.",
"Tham gia sinh hoạt tổ chuyên môn, đoàn thể, phong trào; thực hiện nhiệm vụ đảng viên, đoàn viên đối với cá nhân thuộc đối tượng.",
"Chủ động thực hiện nhiệm vụ được giao; không vi phạm kỷ luật, nội quy, quy chế và đạo đức nghề nghiệp."
],
items:[
["4.1","Điều kiện về đảng viên: Thực hiện tiêu chí thi đua gốc đối với viên chức thuộc đối tượng áp dụng.",1],
["4.2","Chấp hành quy định thu tiền: Không tự ý thu tiền phụ huynh khi chưa được phân công.",2],
["4.3","Thực hiện các khoản thu: Không thực hiện khoản thu ngoài quy định.",2],
["4.4","Phối hợp Ban đại diện cha mẹ trẻ: Không phát động khoản thu trái quy định.",2],
["4.5","Nhiệm vụ đảng viên: Hoàn thành tốt nhiệm vụ trở lên đối với giáo viên là đảng viên.",1],
["4.6","Nhiệm vụ đoàn viên: Hoàn thành tốt nhiệm vụ đối với giáo viên thuộc tổ chức Đoàn.",1],
["4.7","Đạo đức, ứng xử và đoàn kết: Không có hành vi nhũng nhiễu, gây mất đoàn kết được xác minh; giữ chuẩn mực nghề nghiệp.",2],
["4.8","Chấp hành nội quy, quy chế: Không vi phạm nội quy trường, quy chế làm việc và chuyên môn.",4]
],
codes:"2, 15, 16, 17, 18, 19, 22, 28",
proof:"Kết quả đánh giá Đảng, Đoàn (nếu áp dụng), hồ sơ kiểm tra, nhận xét tổ chuyên môn và kết quả xác minh.",
guide:"Nêu kết quả chấp hành nội quy, quy chế, đạo đức nghề nghiệp, tinh thần phối hợp và trách nhiệm công việc; bổ sung nhiệm vụ đảng viên hoặc đoàn viên nếu thuộc đối tượng."
},
{
title:"PHÁT TRIỂN TRẺ, AN SINH XÃ HỘI VÀ HỖ TRỢ TRẺ",points:15,
bullets:[
"Thực hiện tốt việc huy động, duy trì sĩ số trẻ; phối hợp với gia đình và nhà trường thực hiện chỉ tiêu phát triển số lượng trẻ theo độ tuổi và nhiệm vụ được phân công.",
"Quan tâm, theo dõi tình hình học tập, sức khỏe, hoàn cảnh gia đình và nhu cầu của trẻ; phát hiện kịp thời những trường hợp cần hỗ trợ.",
"Phối hợp rà soát, cung cấp đầy đủ, chính xác, kịp thời thông tin và hồ sơ trẻ thuộc diện hưởng chế độ, chính sách theo quy định.",
"Tích cực phối hợp với cha mẹ trẻ, nhà trường và các tổ chức liên quan trong việc hỗ trợ trẻ có hoàn cảnh khó khăn, trẻ thuộc diện chính sách và trẻ có nhu cầu đặc biệt.",
"Phối hợp tốt giữa gia đình và nhà trường, tạo điều kiện để trẻ được chăm sóc, giáo dục và tham gia hoạt động phù hợp với khả năng, nhu cầu của trẻ."
],
items:[
["5.1","Thực hiện chỉ tiêu sĩ số: Nhà trẻ 8 trẻ/GV; mẫu giáo 3 tuổi 10; mẫu giáo 4 tuổi 12; mẫu giáo 5 tuổi 14 trẻ/GV.",5],
["5.2","Chính sách hỗ trợ trẻ: Cung cấp đầy đủ, kịp thời 100% thông tin trẻ thuộc diện miễn, giảm học phí và hỗ trợ theo quy định.",5],
["5.3","Hỗ trợ trẻ hoàn cảnh đặc biệt: Phối hợp vận động, hỗ trợ trẻ khó khăn theo nhiệm vụ, đúng quy định và tự nguyện.",5]
],
codes:"1, 13, 14",
proof:"Danh sách sĩ số, hồ sơ chính sách, danh sách trẻ được hỗ trợ, biên bản phối hợp và xác nhận của nhà trường.",
guide:"Nêu sĩ số lớp, kết quả huy động, duy trì sĩ số, số trường hợp được hỗ trợ; nếu không phát sinh trẻ thuộc diện hỗ trợ, ghi rõ tình hình thực tế."
},
{
title:"BẢO ĐẢM AN NINH, AN TOÀN TRƯỜNG HỌC VÀ PHÒNG NGỪA VI PHẠM",points:20,
bullets:[
"Chấp hành nghiêm pháp luật và các quy định của ngành, nhà trường về an ninh, trật tự, an toàn trường học và phòng ngừa vi phạm.",
"Thực hiện đầy đủ biện pháp bảo đảm an toàn thể chất, tinh thần cho trẻ; kiểm tra, phát hiện và xử lý kịp thời nguy cơ mất an toàn tại nhóm, lớp.",
"Thực hiện nghiêm quy trình đón, trả trẻ, quản lý trẻ trong các hoạt động; không tự ý tổ chức giữ trẻ ngoài thời gian quy định.",
"Thực hiện tốt công tác phòng, chống bạo lực học đường; không xâm phạm thân thể, xúc phạm danh dự, nhân phẩm hoặc gây tổn thương tinh thần với trẻ, đồng nghiệp.",
"Chấp hành quy định về bảo vệ bí mật nhà nước và thông tin của trẻ, phụ huynh, nhà trường; sử dụng mạng xã hội đúng chuẩn mực.",
"Phòng ngừa, phát hiện và báo cáo kịp thời sự việc bất thường, nguy cơ mất an toàn tại nhóm, lớp; phối hợp xử lý theo đúng thẩm quyền, quy trình.",
"Chấp hành quy định an ninh, trật tự tại địa phương, góp phần xây dựng môi trường giáo dục an toàn, lành mạnh, thân thiện."
],
items:[
["6.1","Bảo đảm an toàn trường lớp: Đạt yêu cầu về trường học an toàn theo quy định.",4],
["6.2","Chấp hành pháp luật: Không có vi phạm pháp luật thuộc tiêu chí thi đua gốc đã được xác minh.",2],
["6.3","Đón, trả trẻ đúng quy định: Không tổ chức giữ trẻ trễ trái quy định, thực hiện đúng bàn giao trẻ.",2],
["6.4","Bảo mật thông tin: Không làm lộ, lọt bí mật hoặc phát tán thông tin sai sự thật.",2],
["6.5","Tuân thủ pháp luật liên quan hoạt động tôn giáo: Không có vi phạm pháp luật được xác minh; không đánh giá theo niềm tin cá nhân.",1],
["6.6","Ứng xử trên mạng xã hội: Không vi phạm quy định về ứng xử, chia sẻ thông tin.",2],
["6.7","Chấp hành quy định địa phương: Không có vi phạm được xác minh theo tiêu chí gốc.",2],
["6.8","Phòng chống bạo lực học đường: Không bạo lực thể chất hoặc tinh thần đối với trẻ và đồng nghiệp.",4],
["6.9","Báo cáo sự việc bất thường: Báo cáo kịp thời sự việc phát sinh tại nhóm, lớp, tổ.",1]
],
codes:"11, 20, 21, 23, 24, 25, 26, 27, 36",
proof:"Biên bản kiểm tra an toàn, sổ đón trả trẻ, hồ sơ báo cáo sự việc và kết quả xác minh có thẩm quyền.",
guide:"Nêu các biện pháp phòng ngừa tai nạn, bảo đảm an toàn trẻ, quy trình đón trả trẻ, phòng chống bạo lực và xử lý sự việc phát sinh."
}
];
const esc=s=>String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
function textRun(t,opts={}){
let pr='<w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'+(opts.bold?'<w:b/>':'')+(opts.italic?'<w:i/>':'')+(opts.color?`<w:color w:val="${opts.color}"/>`:'')+`<w:sz w:val="${opts.size||26}"/><w:szCs w:val="${opts.size||26}"/></w:rPr>`;
return `<w:r>${pr}<w:t xml:space="preserve">${esc(t)}</w:t></w:r>`;
}
function para(text,opts={}){
let ppr=`<w:pPr>${opts.keep?'<w:keepNext/>':''}${opts.page?'<w:pageBreakBefore/>':''}<w:spacing w:before="${opts.before??0}" w:after="${opts.after??110}" w:line="${opts.line||335}" w:lineRule="auto"/>${opts.align?`<w:jc w:val="${opts.align}"/>`:''}${opts.left?`<w:ind w:left="${opts.left}" w:firstLine="${opts.first||0}"/>`:''}</w:pPr>`;
return `<w:p>${ppr}${textRun(text,opts)}</w:p>`;
}
function richParagraph(label,value){
return `<w:p><w:pPr><w:spacing w:after="95" w:line="330" w:lineRule="auto"/></w:pPr>${textRun(label,{bold:true,size:25})}${textRun(value,{size:25})}</w:p>`;
}
const grid=[870,7170,1030],totalGrid=grid.reduce((a,b)=>a+b,0);
function tc(text,w,opt={}){
const shade=opt.shade?`<w:shd w:fill="${opt.shade}"/>`:"";
const bold=!!opt.bold;
const align=opt.center?"center":"left";
return `<w:tc><w:tcPr><w:tcW w:w="${w}" w:type="dxa"/>${shade}<w:vAlign w:val="center"/></w:tcPr><w:p><w:pPr><w:spacing w:before="25" w:after="25"/><w:jc w:val="${align}"/></w:pPr>${textRun(text,{bold,size:opt.size||23})}</w:p></w:tc>`;
}
function tr(cells,header=false){
return `<w:tr>${header?'<w:trPr><w:tblHeader w:val="true"/><w:cantSplit/></w:trPr>':'<w:trPr><w:cantSplit/></w:trPr>'}${cells.join("")}</w:tr>`;
}
function table(rows,widths=grid){
const borders='<w:tblBorders>'+["top","left","bottom","right","insideH","insideV"].map(k=>`<w:${k} w:val="single" w:sz="4" w:color="AAB6C2"/>`).join("")+'</w:tblBorders>';
const margins='<w:tblCellMar><w:top w:w="80" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/><w:left w:w="110" w:type="dxa"/><w:right w:w="110" w:type="dxa"/></w:tblCellMar>';
return `<w:tbl><w:tblPr><w:tblW w:w="${widths.reduce((a,b)=>a+b,0)}" w:type="dxa"/><w:tblLayout w:type="fixed"/>${borders}${margins}</w:tblPr><w:tblGrid>${widths.map(w=>`<w:gridCol w:w="${w}"/>`).join("")}</w:tblGrid>${rows.join("")}</w:tbl>`;
}
function kpiTable(s,idx){
const rows=[tr([tc("STT",grid[0],{bold:true,center:true,shade:"E4EBF2"}),tc("Nội dung chỉ số KPI",grid[1],{bold:true,center:true,shade:"E4EBF2"}),tc("Điểm",grid[2],{bold:true,center:true,shade:"E4EBF2"})],true)];
s.items.forEach(z=>rows.push(tr([tc(z[0],grid[0],{center:true}),tc(z[1],grid[1]),tc(String(z[2]),grid[2],{center:true})])));
rows.push(tr([tc("",grid[0],{shade:"EDF3F8"}),tc("Tổng điểm trục "+idx,grid[1],{bold:true,shade:"EDF3F8"}),tc(String(s.points),grid[2],{bold:true,center:true,shade:"EDF3F8"})]));
return table(rows);
}
function buildDocument(){
let body="";
body+=para("TRƯỜNG MẦM NON AN BÌNH A",{bold:true,size:26,align:"center",after:100});
body+=para("TÀI LIỆU HƯỚNG DẪN 06 TRỤC KPI",{bold:true,size:32,align:"center",after:35});
body+=para("ĐÁNH GIÁ GIÁO VIÊN MẦM NON",{bold:true,size:30,align:"center",after:75});
body+=para("Năm học 2025–2026 | 38 chỉ số | 100 điểm",{italic:true,size:25,align:"center",after:280});
body+=para("I. MỤC ĐÍCH VÀ NGUYÊN TẮC SỬ DỤNG",{bold:true,size:28,before:90,after:135,keep:true});
body+=para("Tài liệu cụ thể hóa nhiệm vụ và chỉ số đánh giá giáo viên theo 06 trục KPI, dựa trên bộ tiêu chí chấm điểm thi đua của Trường Mầm non An Bình A. Nội dung phục vụ hướng dẫn giáo viên tự đánh giá theo tháng, quý và cung cấp minh chứng kết quả thực hiện nhiệm vụ.",{after:135});
body+=para("Mỗi trục gồm phần diễn giải nhiệm vụ, bảng chỉ số và điểm tối đa, mã tiêu chí thi đua gốc, minh chứng và gợi ý tự đánh giá. Thang điểm 100 là phương án quy đổi phục vụ quản lý nội bộ, cần được nhà trường thống nhất trước khi áp dụng chính thức.",{after:220});
body+=para("II. NỘI DUNG CỤ THỂ THEO 06 TRỤC KPI",{bold:true,size:28,after:160,keep:true});
sections.forEach((s,i)=>{
body+=para(`TRỤC ${i+1}. ${s.title} (${s.points} ĐIỂM)`,{bold:true,size:27,color:"1C4568",before:200,after:110,keep:true});
body+=para("1. Nội dung diễn giải nhiệm vụ",{bold:true,size:26,after:90,keep:true});
s.bullets.forEach(b=>body+=para("– "+b,{left:310,first:-230,after:72,size:25,line:315}));
body+=para(`2. Danh mục ${s.items.length.toString().padStart(2,"0")} chỉ số KPI`,{bold:true,size:26,before:110,after:95,keep:true});
body+=kpiTable(s,i+1);
body+=para("",{after:50,size:8});
body+=richParagraph("Mã tiêu chí thi đua gốc: ",s.codes+".");
body+=richParagraph("Minh chứng: ",s.proof);
body+=richParagraph("Gợi ý giáo viên tự đánh giá: ",s.guide);
});
body+=para("III. BẢNG TỔNG HỢP 06 TRỤC KPI",{bold:true,size:28,before:250,after:140,keep:true});
const sw=[6590,1210,1270];
const sumrows=[tr([tc("Trục đánh giá",sw[0],{center:true,bold:true,shade:"E4EBF2"}),tc("Số chỉ số",sw[1],{center:true,bold:true,shade:"E4EBF2"}),tc("Điểm",sw[2],{center:true,bold:true,shade:"E4EBF2"})],true)];
sections.forEach((s,i)=>sumrows.push(tr([tc(`Trục ${i+1} – ${s.title.toLowerCase()}`,sw[0]),tc(String(s.items.length),sw[1],{center:true}),tc(String(s.points),sw[2],{center:true})])));
sumrows.push(tr([tc("TỔNG CỘNG",sw[0],{bold:true,shade:"EDF3F8"}),tc("38",sw[1],{bold:true,center:true,shade:"EDF3F8"}),tc("100",sw[2],{bold:true,center:true,shade:"EDF3F8"})]));
body+=table(sumrows,sw);
body+=para("IV. LƯU Ý KHI THỰC HIỆN",{bold:true,size:28,before:240,after:125,keep:true});
[
"Giáo viên căn cứ nhiệm vụ được phân công và kết quả thực tế để tự đánh giá; số liệu và thành tích đưa vào báo cáo phải có minh chứng.",
"Chỉ tiêu chưa đến hạn hoặc không thuộc đối tượng áp dụng cần được ghi rõ và xem xét theo quy trình thống nhất; không tự động chấm 0.",
"Các tiêu chí về an toàn trẻ, đạo đức, bảo mật và vi phạm nghiêm trọng phải được xem xét theo quy định riêng, không chỉ căn cứ vào tổng điểm.",
"Bộ tiêu chí thi đua được cung cấp chưa thể hiện nội dung số 3; mục số 4 được cụ thể hóa thành 4.1, 4.2, 4.3. Do đó tài liệu hiện trình bày 38 dòng chỉ số có thông tin xác định.",
"Việc phê duyệt trọng số, cách quy đổi điểm và điều kiện xếp loại thuộc thẩm quyền của nhà trường và cấp quản lý theo quy định."
].forEach(x=>body+=para("– "+x,{left:310,first:-230,after:85,size:25}));
body+=para("TÀI LIỆU DỰ THẢO – PHỤC VỤ HƯỚNG DẪN VÀ THỐNG NHẤT CHUYÊN MÔN",{italic:true,size:22,align:"center",before:220});
const sect=`<w:sectPr><w:footerReference w:type="default" r:id="rId2"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1134" w:bottom="1134" w:left="1701" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>`;
return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>'+body+sect+'</w:body></w:document>';
}
const styles='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="26"/><w:lang w:val="vi-VN"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="110" w:line="330" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>';
const footer='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:pPr><w:jc w:val="center"/></w:pPr>'+textRun("Trường Mầm non An Bình A  –  Trang ",{size:20,italic:true})+'<w:fldSimple w:instr="PAGE"/></w:p></w:ftr>';
const u16=n=>[n&255,(n>>>8)&255],u32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255],enc=s=>new TextEncoder().encode(s);
function crc32(arr){let c=-1;for(let b of arr){c^=b;for(let i=0;i<8;i++)c=(c>>>1)^(0xEDB88320&-(c&1));}return(c^-1)>>>0;}
function zip(files){
let local=[],central=[],offset=0;
for(const [name,content] of files){
const filename=enc(name),body=enc(content),crc=crc32(body);
const lh=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(body.length),...u32(body.length),...u16(filename.length),...u16(0)]);
local.push(lh,filename,body);
const ch=new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(body.length),...u32(body.length),...u16(filename.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset)]);
central.push(ch,filename);
offset+=lh.length+filename.length+body.length;
}
const centralSize=central.reduce((s,x)=>s+x.length,0);
const end=new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(centralSize),...u32(offset),...u16(0)]);
return new Blob([...local,...central,end],{type:"application/vnd.openxmlformats-officedocument.wordprocessingml.document"});
}
function create(){
const contentTypes='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>';
const pkgRel='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>';
const docRel='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>';
return zip([
["[Content_Types].xml",contentTypes],
["_rels/.rels",pkgRel],
["word/document.xml",buildDocument()],
["word/_rels/document.xml.rels",docRel],
["word/styles.xml",styles],
["word/footer1.xml",footer]
]);
}
root.querySelector("#mnab-word-button").addEventListener("click",()=>{
const button=root.querySelector("#mnab-word-button"),status=root.querySelector("#mnab-word-status");
try{
button.disabled=true;status.textContent="Đang tạo tài liệu Word...";
const count=sections.reduce((n,s)=>n+s.items.length,0),score=sections.reduce((n,s)=>n+s.points,0);
if(count!==38||score!==100)throw Error("Dữ liệu KPI chưa khớp tổng 38 chỉ số, 100 điểm.");
for(const s of sections)if(s.items.reduce((n,v)=>n+v[2],0)!==s.points)throw Error("Điểm một trục không khớp.");
const blob=create(),url=URL.createObjectURL(blob),a=document.createElement("a");
a.href=url;a.download="Huong_dan_6_truc_KPI_Giao_vien_An_Binh_A.docx";
document.body.appendChild(a);a.click();a.remove();
status.textContent="Đã gửi yêu cầu tải file Word. Bạn kiểm tra thư mục Tải xuống trên thiết bị.";
setTimeout(()=>URL.revokeObjectURL(url),30000);
}catch(e){status.textContent="Chưa thể xuất Word trên thiết bị này: "+String(e.message||e);}
finally{button.disabled=false;}
});
})();
</script>

```

Sau khi mở file Word, bạn có thể chỉnh sửa câu chữ hoặc bổ sung số liệu của nhà trường. **Phần diễn giải được đặt trước bảng chỉ số của từng trục** để giáo viên dễ hiểu nhiệm vụ cần thực hiện và liên hệ với KPI khi viết bản tự đánh giá.

Lưu ý: Đây là tài liệu hướng dẫn dự thảo theo phương án quy đổi 100 điểm đã thống nhất trong cuộc trao đổi; nhà trường cần phê duyệt trước khi sử dụng như căn cứ xếp loại chính thức.

---

USER

bạn có thể thiết kế KPI cho chức vụ THủ quỹ, văn thư, kế toán, bảo vệ, y tế học đường, nhân viên nấu ăn, nhân viên thư viện và phục vụ của trường?

---

ASSISTANT

Mình sẽ thiết kế bộ KPI riêng cho cả 8 vị trí, tiếp tục dùng **06 trục và thang 100 điểm** để nhà trường dễ tổng hợp chung. Các chỉ số sẽ được điều chỉnh theo đúng nhiệm vụ của từng vị trí, có kết quả cần đạt và minh chứng, đồng thời phân biệt rõ trách nhiệm của kế toán với thủ quỹ, nhân viên y tế với nhân viên nấu ăn.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📊 THIẾT KẾ BỘ KPI 06 TRỤC – 100 ĐIỂM CHO 08 VỊ TRÍ NHÂN VIÊN TRƯỜNG MẦM NON AN BÌNH A

Tôi đề xuất xây dựng **08 bảng KPI riêng theo vị trí việc làm**, nhưng thống nhất một khung 06 trục và thang điểm 100 để Hiệu trưởng thuận tiện đánh giá theo tháng, quý, tổng hợp kết quả và xét thi đua.

Các vị trí gồm: **Thủ quỹ, Văn thư, Kế toán, Bảo vệ, Y tế học đường, Nhân viên nấu ăn, Nhân viên thư viện và Nhân viên phục vụ.**

## 🎯 1. Cơ cấu 06 trục áp dụng chung

| Trục | Nội dung đánh giá | Điểm |
|--------|--------|--------|
| 1 | Kết quả thực hiện nhiệm vụ chuyên môn theo vị trí việc làm | 25 |
| 2 | Thực hiện quy trình nghiệp vụ, hồ sơ, quản lý tài sản và thiết bị | 15 |
| 3 | Ứng dụng CNTT, đổi mới sáng tạo và chuyển đổi số | 10 |
| 4 | Kỷ luật, trách nhiệm, đạo đức nghề nghiệp và quy chế làm việc | 15 |
| 5 | Phối hợp công tác, phục vụ hoạt động giáo dục và hỗ trợ trẻ | 15 |
| 6 | Bảo đảm an toàn, an ninh, bảo mật và phòng ngừa vi phạm | 20 |
| **Tổng** |  | **100** |

Cơ cấu này kế thừa phương án đã xây dựng cho giáo viên, đồng thời điều chỉnh tên và nội dung trục cho phù hợp với nhân viên. Mỗi vị trí có **12 chỉ số KPI cụ thể, hai chỉ số trong mỗi trục**, gắn với kết quả, thời hạn và minh chứng.

Về căn cứ chuyên môn, Thông tư 19/2023/TT-BGDĐT có hướng dẫn các vị trí việc làm trong trường mầm non công lập; nhiệm vụ thực tế cần được cụ thể hóa theo bản mô tả vị trí việc làm và phân công được phê duyệt của nhà trường. [Thông tư hướng dẫn định mức người làm việc trong cơ sở giáo dục mầm non công lập](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-huong-dan-dinh-muc-so-luong-nguoi-lam-viec-trong-co-so-giao-duc-mam-non-cong-lap-119231115151943505.htm>); [466](<https://moet.gov.vn/content/vanban/Lists/VBDH/Attachments/3625/466qdbgddtsigned.pdf>)

**Lưu ý:** Đây là phương án KPI nội bộ đề xuất, không phải bảng trọng số bắt buộc của Phụ lục 3. Nhà trường cần thống nhất trước khi ban hành chính thức.

## 📋 2. Danh mục KPI chi tiết cho từng vị trí

Tôi đã cụ thể hóa thành **96 chỉ số KPI cho 08 vị trí**, mỗi chỉ số đều có yêu cầu cần đạt, thang điểm và minh chứng. Bạn chọn từng vị trí bên dưới để xem bảng đánh giá.

Chọn vị trí nhân viên

Mỗi vị trí gồm 12 KPI – tổng 100 điểm

Lựa chọn hiện tại không khả dụng.

[Sao chép KPI vị trí này] [Sao chép toàn bộ 08 vị trí]

Tổng điểm KPI –

# /100

Nút sao chép tạo bảng phân tách cột để dán vào Excel, gồm vị trí, trục, mã KPI, nội dung, yêu cầu, điểm, minh chứng, cột tự chấm và cột quản lý chấm.

## 📖 3. Căn cứ và yêu cầu chuyên môn đặc thù

Đối với **y tế học đường**, tôi đã lồng ghép yêu cầu quản lý sức khỏe trẻ, chăm sóc sức khỏe ban đầu, phòng chống dịch, vệ sinh trường học theo định hướng của Thông tư liên tịch 13/2016/TTLT-BYT-BGDĐT. [Trung ương](<https://vbpl.vn/TW/Pages/vbpq-toanvan.aspx?ItemID=132249>)

Đối với **nhân viên nấu ăn**, các nhiệm vụ về kiểm thực ba bước và lưu mẫu thức ăn được xây dựng có tham chiếu Quyết định 1246/QĐ-BYT ngày 31/3/2017. Việc phân công phải phù hợp phạm vi áp dụng và quy trình bếp ăn của trường. [Quyết định 1246/QĐ\-BYT năm 2017 hướng dẫn thực hiện chế độ kiểm thực ba bước và lưu mẫu thức ăn đối với cơ sở kinh doanh dịch vụ ăn uống do Bộ trưởng Bộ Y tế ban hành](<https://dulieuphapluat.vn/van-ban/y-te-van-ban/quyet-dinh-1246qd-byt-nam-2017-huong-dan-thuc-hien-che-do-kiem-thuc-ba-buoc-va-luu-mau-thuc-an-doi-voi-co-so-kinh-doanh-dich-vu-an-uong-do-bo-truong-bo-y-te-ban-hanh-107006.html>)

Đối với **kế toán và thủ quỹ**, cần phân biệt rõ trách nhiệm: kế toán thực hiện nghiệp vụ kế toán, kiểm tra chứng từ, tham mưu tài chính; thủ quỹ thực hiện quản lý quỹ và thu, chi theo chứng từ hợp lệ, trong phạm vi được giao. Không thiết kế KPI khiến thủ quỹ phải tự phê duyệt giao dịch của mình.

## 📋 4. Hướng dẫn thống nhất cách chấm điểm

Để 08 bảng KPI có thể sử dụng chung, tôi đề xuất phương pháp đánh giá sau:

| Mức độ hoàn thành | Điểm đề xuất |
|--------|--------|
| Hoàn thành đầy đủ chỉ tiêu, đúng hạn, có minh chứng | 100% điểm chỉ số |
| Hoàn thành phần lớn, còn hạn chế nhỏ có căn cứ | 75% điểm chỉ số |
| Hoàn thành một phần, chưa bảo đảm đầy đủ yêu cầu | 50% điểm chỉ số |
| Không thực hiện hoặc không đạt điều kiện bắt buộc | 0 điểm |
| Không thuộc nhiệm vụ hoặc chưa đến kỳ thực hiện | KAD – xác nhận riêng |

Các mức 75% và 50% chỉ áp dụng khi có thể xác định mức độ hoàn thành từng phần. Với nhiệm vụ bắt buộc như bảo mật, an toàn thực phẩm, phòng chống bạo lực và chấp hành pháp luật, phải căn cứ điều kiện quy định, không chỉ lấy tỷ lệ điểm để đánh giá.

Ngoài ra, tôi đề nghị nhà trường theo dõi riêng các vi phạm nghiêm trọng, có kết luận hoặc căn cứ xác minh phù hợp. **Không để nhân viên đạt điểm KPI cao nhưng bỏ qua hành vi có thể gây mất an toàn cho trẻ hoặc thất thoát tài sản.**

## ✅ 5. Đề xuất triển khai tại Trường Mầm non An Bình A

Tôi khuyến nghị sử dụng bộ KPI này dưới hình thức **một danh mục chung và tám phiếu đánh giá cá nhân theo vị trí**. Phiếu của mỗi nhân viên nên có phần thông tin cá nhân, 12 chỉ số theo 06 trục, điểm tự đánh giá, điểm quản lý đánh giá, minh chứng, nhận xét và chữ ký xác nhận.

Với nhân viên kiêm nhiệm nhiều công việc, Hiệu trưởng cần xác định rõ nhiệm vụ chính, nhiệm vụ kiêm nhiệm và phạm vi trách nhiệm trước khi chấm. Những chỉ số không có thiết bị, phần mềm hoặc không phát sinh nhiệm vụ cũng cần có cách xử lý thống nhất, tránh bất lợi cho người lao động.

**Kết quả thiết kế:** 08 vị trí × 12 chỉ số = **96 chỉ số KPI**, mỗi vị trí 100 điểm. Đây là bộ dự thảo để nhà trường thảo luận, điều chỉnh theo bản mô tả vị trí việc làm thực tế và phê duyệt trước khi áp dụng đánh giá chính thức.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

bạn tiếp tục làm danh mục KPI chi tiết cho các vị trí còn lại nhé

---

ASSISTANT

# 📊 DANH MỤC KPI CHI TIẾT CHO 08 VỊ TRÍ NHÂN VIÊN TRƯỜNG MẦM NON AN BÌNH A

Tôi tiếp tục cụ thể hóa bộ KPI dành cho **Thủ quỹ, Văn thư, Kế toán, Bảo vệ, Y tế học đường, Nhân viên nấu ăn, Thư viện và Nhân viên phục vụ**, thống nhất theo 06 trục – 100 điểm.

Bộ danh mục được thiết kế để sử dụng trong đánh giá theo tháng, quý, với mỗi chỉ số xác định rõ: **nhiệm vụ, chỉ tiêu cần đạt, điểm tối đa và minh chứng**.

## 1. Khung điểm thống nhất

| Trục | Nội dung đánh giá | Điểm |
|--------|--------|--------|
| 1 | Kết quả thực hiện nhiệm vụ chuyên môn theo vị trí | 25 |
| 2 | Quy trình nghiệp vụ, hồ sơ, tài sản và thiết bị | 15 |
| 3 | Ứng dụng CNTT, đổi mới sáng tạo và chuyển đổi số | 10 |
| 4 | Kỷ luật, trách nhiệm và đạo đức nghề nghiệp | 15 |
| 5 | Phối hợp thực hiện nhiệm vụ và phục vụ hoạt động giáo dục | 15 |
| 6 | An ninh, an toàn và phòng ngừa vi phạm | 20 |
| **Tổng cộng** | **12 chỉ số/vị trí** | **100** |

## 2. Danh mục KPI chi tiết theo từng vị trí

Bạn chọn chức danh để xem bảng 12 chỉ số. Các chỉ tiêu được diễn đạt theo kết quả có thể kiểm tra, không chỉ là mô tả công việc chung.

Lựa chọn vị trí việc làm

Lựa chọn hiện tại không khả dụng.

## KPI –

12 chỉ số • 06 trục

## 100 điểm

[Sao chép KPI vị trí này] [Sao chép cả 08 vị trí]

## 3. Hướng dẫn đánh giá dành cho Ban giám hiệu

Đối với mỗi vị trí, giáo viên hoặc nhân viên tự đánh giá kết quả thực hiện từng chỉ số, sau đó người quản lý căn cứ hồ sơ minh chứng để xác nhận. Tôi đề nghị áp dụng nguyên tắc sau:

| Mức đánh giá | Cách chấm đề xuất |
|--------|--------|
| Hoàn thành đầy đủ, đúng hạn, đủ minh chứng | 100% điểm chỉ số |
| Hoàn thành phần lớn, còn hạn chế nhỏ | 75% điểm chỉ số |
| Hoàn thành một phần nhiệm vụ | 50% điểm chỉ số |
| Không thực hiện hoặc không đạt yêu cầu bắt buộc | 0 điểm |
| Chưa phát sinh hoặc không thuộc nhiệm vụ | KAD – xem xét riêng |

Việc chấm 75% hoặc 50% chỉ phù hợp với nhiệm vụ có thể đánh giá mức độ hoàn thành từng phần. Những yêu cầu bắt buộc về an toàn thực phẩm, an toàn trẻ, bảo mật, phòng cháy chữa cháy, tài chính và đạo đức nghề nghiệp phải được kiểm tra theo quy định riêng.

**Đối với nhân viên kiêm nhiệm**, chẳng hạn văn thư kiêm thủ quỹ hoặc nhân viên thư viện kiêm thiết bị, Hiệu trưởng cần xác định rõ tỷ trọng nhiệm vụ chính và kiêm nhiệm để tránh chấm trùng hoặc giao chỉ tiêu vượt quá phạm vi công việc.

## ✅ 4. Đề xuất sử dụng trong toàn trường

Bộ danh mục hiện đã có **96 chỉ số cụ thể cho 08 vị trí**, thống nhất 06 trục và 100 điểm/vị trí, có thể đưa vào Excel để xây dựng phiếu tự chấm, phiếu đánh giá của Ban giám hiệu và bảng tổng hợp theo quý.

Để triển khai chính thức, nhà trường cần đối chiếu với bản mô tả vị trí việc làm, hợp đồng và quyết định phân công thực tế; thống nhất cách xử lý nhiệm vụ chưa phát sinh, ngưỡng xếp loại, điều kiện khống chế và thẩm quyền phê duyệt. Đây là **bộ KPI quản trị nội bộ đề xuất**, không mặc nhiên thay thế biểu mẫu hoặc thang điểm bắt buộc của cấp trên.

Bước triển khai phù hợp tiếp theo là chuẩn hóa cả 08 danh mục vào cùng một bộ biểu mẫu, để nhân viên có thể tự chấm và Ban giám hiệu sử dụng thống nhất khi đánh giá hằng quý.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

các vị trí văn thư, Kế toán, Bảo vệ, Y tế học đường, Nhân viên nấu ăn, Thư viện và Nhân viên phục vụ, thống nhất theo 06 trục – 100 điểm.

---

ASSISTANT

Mình sẽ chuẩn hóa KPI cho đúng **7 vị trí bạn vừa chọn** \(không gồm thủ quỹ), mỗi vị trí có 06 trục, tổng 100 điểm. Mình sẽ giữ cùng cấu trúc để Ban giám hiệu dễ chấm và tổng hợp, nhưng điều chỉnh chỉ số, minh chứng theo từng công việc; đồng thời chuẩn bị bảng có thể đưa vào Excel để in.

---

ASSISTANT

# 📊 DANH MỤC KPI CHO 07 VỊ TRÍ NHÂN VIÊN TRƯỜNG MẦM NON AN BÌNH A

Tôi thống nhất thiết kế cho **07 vị trí: Văn thư, Kế toán, Bảo vệ, Y tế học đường, Nhân viên nấu ăn, Thư viện và Nhân viên phục vụ**, không bao gồm Thủ quỹ.

Mỗi vị trí có 12 chỉ số KPI, phân bổ theo 06 trục, tổng 100 điểm. Các chỉ số được thiết kế dựa trên nhiệm vụ đặc thù, kết quả cần đạt và minh chứng để giáo viên, nhân viên có thể tự đánh giá, Ban giám hiệu có cơ sở kiểm tra, xác nhận.

## 1. Khung điểm áp dụng thống nhất

| Trục | Lĩnh vực đánh giá | Số chỉ số | Điểm tối đa |
|--------|--------|--------|--------|
| 1 | Kết quả thực hiện nhiệm vụ chuyên môn | 2 | 25 |
| 2 | Quy trình nghiệp vụ, hồ sơ, tài sản và thiết bị | 2 | 15 |
| 3 | Ứng dụng CNTT, đổi mới và chuyển đổi số | 2 | 10 |
| 4 | Kỷ luật, trách nhiệm và đạo đức nghề nghiệp | 2 | 15 |
| 5 | Phối hợp công tác, phục vụ hoạt động giáo dục | 2 | 15 |
| 6 | An ninh, an toàn và phòng ngừa vi phạm | 2 | 20 |
| **Tổng** |  | **12** | **100** |

Mỗi chức danh sử dụng cùng mã chỉ số từ 1.1 đến 6.2 và trọng số tương ứng: **15 – 10 – 8 – 7 – 6 – 4 – 8 – 7 – 8 – 7 – 12 – 8 điểm**.

Tổng cộng bộ danh mục có **84 chỉ số KPI**, thống nhất cách trình bày nhưng không đánh đồng nhiệm vụ giữa các vị trí.

## 2. Danh mục chi tiết theo từng vị trí

Bạn chọn từng vị trí để xem đầy đủ 12 chỉ số, kết quả cần đạt, minh chứng và điểm tối đa. Có thể sao chép riêng bảng của một vị trí hoặc cả 07 vị trí vào Excel.

Chọn vị trí việc làm Lựa chọn hiện tại không khả dụng.

## 100 điểm

[Sao chép KPI vị trí này] [Sao chép cả 07 vị trí]

**Tổng điểm tối đa –**

## /100

## 3. Hướng dẫn áp dụng chung

Để tránh phát sinh chênh lệch giữa các bộ phận, tôi đề xuất nhà trường sử dụng thống nhất cách chấm dưới đây.

| Mức hoàn thành | Tỷ lệ điểm đề xuất |
|--------|--------|
| Hoàn thành đầy đủ, đúng hạn, có minh chứng | 100% |
| Hoàn thành phần lớn, có hạn chế nhỏ | 75% |
| Hoàn thành một phần nhiệm vụ | 50% |
| Không thực hiện hoặc không đạt yêu cầu bắt buộc | 0% |
| Chưa phát sinh hoặc không thuộc nhiệm vụ được giao | KAD – xem xét riêng |

Các mức phần trăm này chỉ phù hợp với công việc có thể đánh giá mức độ hoàn thành từng phần. Nhiệm vụ liên quan đến an toàn thực phẩm, an toàn trẻ, tài chính, bảo mật và phòng chống bạo lực cần được đánh giá theo điều kiện bắt buộc, quy trình xác minh và quy định có liên quan.

Riêng trục 3, khi nhân viên chưa được trang bị phần mềm hoặc thiết bị số, nhà trường cần xác định cách đánh giá thay thế phù hợp ngay từ đầu kỳ, không để thiếu điều kiện làm việc trở thành lý do trừ điểm máy móc.

## ✅ 4. Đề xuất dành cho Hiệu trưởng

Bộ KPI này đã cụ thể hóa **84 chỉ số cho 07 vị trí**, với cùng cấu trúc, trọng số và phương pháp tổng hợp. Tôi đề xuất dùng làm dự thảo danh mục KPI theo vị trí việc làm, sau đó đối chiếu với bản mô tả công việc, quyết định phân công thực tế, điều kiện cơ sở vật chất và tiêu chí thi đua của nhà trường.

Đối với nhân viên kiêm nhiệm, cần xác định rõ nhiệm vụ chính và kiêm nhiệm để không chấm trùng. Đối với tiêu chí không phát sinh trong quý, cần có nguyên tắc xác nhận và quy đổi điểm được thống nhất trước kỳ đánh giá.

**Bản này là phương án KPI quản trị nội bộ 06 trục – 100 điểm**, chưa mặc nhiên thay thế quy định đánh giá, xếp loại viên chức hoặc người lao động của cấp có thẩm quyền.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

Kế toán, Bảo vệ, Y tế học đường, Nhân viên nấu ăn, Thư viện và Nhân viên phục vụ

---

ASSISTANT

Mình sẽ chốt bộ KPI cho đúng **6 vị trí bạn vừa chọn**, không gồm Văn thư và Thủ quỹ. Mỗi vị trí sẽ có 12 chỉ số theo 06 trục, tổng 100 điểm, kèm yêu cầu cần đạt và minh chứng để Ban giám hiệu sử dụng thống nhất.

---

ASSISTANT

# 📊 BỘ KPI 06 TRỤC – 100 ĐIỂM CHO 06 VỊ TRÍ NHÂN VIÊN

TRƯỜNG MẦM NON AN BÌNH A

Tôi thống nhất xây dựng bộ KPI cho đúng **06 vị trí: Kế toán, Bảo vệ, Y tế học đường, Nhân viên nấu ăn, Nhân viên thư viện và Nhân viên phục vụ**.

Mỗi vị trí được thiết kế 12 chỉ số KPI, với yêu cầu cần đạt và minh chứng cụ thể, phù hợp để tự đánh giá và Ban giám hiệu chấm điểm theo tháng, quý.

## 1. Cơ cấu điểm chung

| Trục | Nội dung | Điểm |
|--------|--------|--------|
| 1 | Kết quả thực hiện nhiệm vụ chuyên môn | 25 |
| 2 | Quy trình nghiệp vụ, hồ sơ, tài sản và thiết bị | 15 |
| 3 | CNTT, đổi mới sáng tạo và chuyển đổi số | 10 |
| 4 | Kỷ luật, trách nhiệm và đạo đức nghề nghiệp | 15 |
| 5 | Phối hợp thực hiện nhiệm vụ, phục vụ nhà trường | 15 |
| 6 | An ninh, an toàn và phòng ngừa vi phạm | 20 |
| **Tổng cộng** |  | **100** |

## 2. Danh mục KPI chi tiết của từng vị trí

Chọn vị trí nhân viên Lựa chọn hiện tại không khả dụng.

## 100 điểm

[Sao chép KPI vị trí này] [Sao chép cả 06 vị trí]

**Tổng điểm KPI –**

## /100

## 3. Hướng dẫn áp dụng trong nhà trường

Mỗi vị trí được đánh giá theo hai bước: nhân viên tự chấm và cung cấp minh chứng; sau đó tổ trưởng hoặc người phụ trách trực tiếp kiểm tra, Ban giám hiệu xem xét, xác nhận kết quả.

Khi triển khai, cần lưu ý ba nguyên tắc quan trọng:

- **Đúng vị trí việc làm:** Chỉ chấm những nhiệm vụ thực sự được giao, có điều kiện thực hiện và thuộc trách nhiệm của nhân viên.
- **Có căn cứ đánh giá:** Mỗi chỉ số cần dựa trên khối lượng, chất lượng, thời hạn và minh chứng công việc; không chỉ đánh giá theo cảm nhận.
- **Bảo đảm công bằng:** Tiêu chí chưa phát sinh hoặc không thuộc trách nhiệm phải có cách xử lý được thống nhất trước kỳ đánh giá. Những hành vi vi phạm nghiêm trọng về an toàn, tài chính, an toàn thực phẩm, bảo mật phải được xem xét riêng.

## ✅ 4. Kết quả hoàn thiện

# 06

Vị trí nhân viên

# 72

Chỉ số KPI

# 100

Điểm/vị trí

Đây là bộ danh mục KPI dành riêng cho **06 vị trí bạn đã xác định**, thống nhất với cấu trúc KPI giáo viên về số trục và tổng điểm. Trước khi dùng chính thức, nhà trường cần đối chiếu các chỉ số với bản mô tả vị trí việc làm, phân công thực tế và quy định đánh giá hiện hành.

Bộ danh mục có thể chuyển sang mẫu Excel gồm phiếu tự đánh giá, phiếu Ban giám hiệu chấm điểm, bảng tổng hợp theo quý và bản in ký xác nhận cho từng nhân viên.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

trong quy chế này còn thiếu nội dung huy động trẻ ở các độ tuổi: Nhà trẻ, 3-5 tuổi  đạt, chưa đạt và vượt chỉ tiêu trong KPI. bạn giúp tôi bổ sung nhưng không làm ảnh hưởng đến các số điểm đã chốt ở các mục.

---

ASSISTANT

Tôi đã đối chiếu Quy chế và Phụ lục I bạn gửi. Phương án phù hợp nhất là **bổ sung nội dung huy động trẻ vào tiêu chí B1.4 hiện có (3 điểm)**, kèm bảng theo dõi riêng cho nhà trẻ và từng độ tuổi 3, 4, 5; như vậy không phải tăng tổng điểm hay sửa thang chấm đã ban hành. Tôi sẽ làm rõ cách phân biệt *chưa đạt – đạt – vượt chỉ tiêu* và trách nhiệm của giáo viên để tránh chấm trùng.

---

ASSISTANT

---

ASSISTANT

# 📌 Đề xuất bổ sung chỉ tiêu huy động trẻ vào Quy chế KPI năm học 2026–2027

Tôi đã rà soát **Quy chế đánh giá, xếp loại chất lượng viên chức Trường Mầm non An Bình**, ban hành kèm Quyết định số **89/QĐ-MNAB ngày 02/11/2026**.

**Phương án phù hợp nhất là bổ sung nội dung huy động trẻ vào tiêu chí B1.4 của Phụ lục I**, đồng thời bổ sung một bảng theo dõi kết quả huy động trẻ theo độ tuổi. Cách này không làm thay đổi bất kỳ mức điểm nào đã chốt trong Quy chế.

Cụ thể, giữ nguyên:

- **Tiêu chí chung A:** 30 điểm.
- **Kết quả thực hiện nhiệm vụ B:** 70 điểm.
- **Tiêu chí B1.4 – Nhiệm vụ khác theo phân công:** Tối đa 3 điểm, với các mức **3 – 2 – 1 – 0 điểm** như hiện hành.
- **Tiêu chí B4.3 – Phối hợp với cha mẹ trẻ:** Tối đa 3 điểm, giữ nguyên mức chấm hiện hành.
- **Tổng KPI giáo viên:** 100 điểm.

Nội dung mới sẽ phân biệt rõ **chưa đạt, đạt và vượt chỉ tiêu** đối với nhóm nhà trẻ và các độ tuổi 3, 4, 5 tuổi. Kết quả vượt chỉ tiêu được ghi nhận riêng về thành tích, **không tự động cộng điểm vượt mức tối đa**.

Cách bổ sung này cũng phù hợp với nguyên tắc đánh giá theo nhiệm vụ và sản phẩm cụ thể của Nghị định 233/2026/NĐ-CP, có hiệu lực từ ngày 01/7/2026. [Nghị định số 233/2026/NĐ\-CP của Chính phủ: Quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức](<https://vanban.chinhphu.vn/?classid=1&docid=218616&pageid=27160>)

## 1. Nội dung bổ sung có thể đưa trực tiếp vào Quy chế

> **writing · document**
>
> # NỘI DUNG ĐỀ XUẤT BỔ SUNG
> **Về theo dõi, đánh giá kết quả huy động trẻ ra lớp theo độ tuổi**
>
> *Áp dụng trong Quy chế đánh giá, xếp loại chất lượng viên chức Trường Mầm non An Bình năm học 2026–2027.*
>
> ### I. Bổ sung khoản 6 vào Điều 10 – Giao nhiệm vụ và minh chứng đánh giá
>
> **6. Giao và theo dõi nhiệm vụ huy động trẻ ra lớp**
>
> Hằng năm, căn cứ kế hoạch phát triển giáo dục, kế hoạch tuyển sinh, chỉ tiêu huy động trẻ được cấp có thẩm quyền phê duyệt và điều kiện thực tế của nhà trường, Hiệu trưởng tổ chức giao nhiệm vụ huy động trẻ ra lớp theo từng độ tuổi, bao gồm: trẻ nhà trẻ, trẻ mẫu giáo 3 tuổi, 4 tuổi và 5 tuổi.
>
> Việc giao nhiệm vụ phải xác định rõ đối tượng, địa bàn, số lượng hoặc tỷ lệ cần đạt, thời điểm hoàn thành, trách nhiệm của tổ chuyên môn và cá nhân được phân công. Đối với nhiệm vụ giao cho tập thể, cần xác định cụ thể phần việc của từng cá nhân để làm căn cứ đánh giá khách quan.
>
> Kết quả huy động trẻ ra lớp được theo dõi theo ba mức: **Chưa đạt chỉ tiêu, Đạt chỉ tiêu và Vượt chỉ tiêu**, trên cơ sở số liệu thực tế được kiểm tra, đối chiếu và xác nhận.
>
> Kết quả huy động là một trong các minh chứng đánh giá mức độ hoàn thành nhiệm vụ được giao theo tiêu chí KPI hiện có; không hình thành tiêu chí chấm điểm độc lập, không cộng thêm điểm ngoài thang điểm đã ban hành và không làm thay đổi cơ cấu 30 điểm tiêu chí chung, 70 điểm kết quả thực hiện nhiệm vụ.
>
> Trường hợp không được giao nhiệm vụ, chưa đến thời điểm thực hiện hoặc chỉ tiêu được điều chỉnh hợp lệ, việc đánh giá phải căn cứ nhiệm vụ thực tế thuộc trách nhiệm của viên chức; không mặc nhiên xác định không hoàn thành nhiệm vụ.
>
> ### II. Bổ sung nội dung vào tiêu chí B1.4, Phụ lục I – KPI giáo viên
>
> **Nội dung bổ sung tại cột “Tiêu chí” của mã B1.4:**
>
> Thực hiện nhiệm vụ khác theo phân công, bao gồm: trực lớp, đón trả trẻ, bảo quản đồ dùng, chuẩn bị môi trường giáo dục, thực hiện nhiệm vụ chung; phối hợp điều tra, rà soát số trẻ trong độ tuổi, tuyên truyền, vận động và huy động trẻ nhà trẻ, trẻ mẫu giáo 3 tuổi, 4 tuổi, 5 tuổi ra lớp theo chỉ tiêu và nhiệm vụ được giao.
>
> **Điểm tối đa: Giữ nguyên 3 điểm.**
>
> **Mức chấm: Giữ nguyên quy định hiện hành của tiêu chí B1.4:**
>
> - 3 điểm: Hoàn thành 100% nhiệm vụ được giao.
> - 2 điểm: Hoàn thành từ 90% đến dưới 100%.
> - 1 điểm: Hoàn thành từ 70% đến dưới 90%.
> - 0 điểm: Hoàn thành dưới 70%.
>
> **Minh chứng bổ sung:** Kế hoạch huy động trẻ; chỉ tiêu được giao; danh sách trẻ theo độ tuổi; kết quả điều tra, rà soát; hồ sơ vận động trẻ ra lớp; bảng tổng hợp kết quả huy động đã được xác nhận.
>
> ### III. Quy định cụ thể về xác định kết quả huy động trẻ
>
> **1. Phạm vi theo dõi**
>
> Kết quả huy động được xác định riêng đối với từng nhóm tuổi:
>
> - Trẻ nhà trẻ.
> - Trẻ mẫu giáo 3 tuổi.
> - Trẻ mẫu giáo 4 tuổi.
> - Trẻ mẫu giáo 5 tuổi.
>
> Kết quả trẻ mẫu giáo từ 3 đến 5 tuổi được tổng hợp trên cơ sở số lượng trẻ của ba độ tuổi; không cộng trực tiếp các tỷ lệ phần trăm.
>
> **2. Cách xác định mức hoàn thành chỉ tiêu**
>
> Đối với chỉ tiêu giao bằng số lượng trẻ:
>
> **Tỷ lệ thực hiện chỉ tiêu (%) = (Số trẻ huy động thực tế được xác nhận / Số trẻ theo chỉ tiêu được giao) × 100%.**
>
> Trường hợp chỉ tiêu giao theo tỷ lệ huy động, sử dụng tỷ lệ thực tế và tỷ lệ mục tiêu theo cùng một phạm vi, đối tượng, thời điểm thống kê để đối chiếu.
>
> | Mức kết quả | Điều kiện xác định |
> |---|---|
> | **Chưa đạt chỉ tiêu** | Kết quả huy động thực tế thấp hơn chỉ tiêu được giao. |
> | **Đạt chỉ tiêu** | Kết quả huy động thực tế bằng chỉ tiêu được giao. |
> | **Vượt chỉ tiêu** | Kết quả huy động thực tế cao hơn chỉ tiêu được giao và bảo đảm các điều kiện tuyển sinh, cơ sở vật chất, an toàn theo quy định. |
> | **Chưa đến kỳ/Không được giao** | Chưa đủ điều kiện để xác định mức đạt, không mặc nhiên tính là chưa đạt. |
>
> **3. Nguyên tắc sử dụng kết quả trong KPI**
>
> Kết quả huy động trẻ được ghi nhận làm minh chứng đối với nhiệm vụ thuộc tiêu chí B1.4.
>
> Trường hợp nhiệm vụ huy động là một trong nhiều nhiệm vụ thuộc B1.4, việc chấm điểm căn cứ vào tỷ lệ hoàn thành tổng số nhiệm vụ được giao hợp lệ, không lấy riêng tỷ lệ huy động để thay thế toàn bộ kết quả của tiêu chí.
>
> Trường hợp huy động trẻ là nhiệm vụ duy nhất được giao để đánh giá tại B1.4 trong kỳ, áp dụng trực tiếp các mức 3 – 2 – 1 – 0 điểm theo tỷ lệ hoàn thành đã quy định. Kết quả vượt chỉ tiêu vẫn được chấm tối đa 3 điểm và ghi nhận là hoàn thành vượt chỉ tiêu trong phần nhận xét.
>
> Đối với công tác huy động mang tính tập thể hoặc chịu tác động của các yếu tố khách quan, việc đánh giá cá nhân phải xem xét kết quả thực hiện phần việc cụ thể như điều tra, rà soát, tuyên truyền, liên hệ cha mẹ trẻ, cập nhật hồ sơ và phối hợp vận động; không quy toàn bộ kết quả tuyển sinh của nhà trường thành trách nhiệm riêng của một giáo viên.
>
> **4. Minh chứng đánh giá**
>
> Sử dụng số liệu và hồ sơ hiện có của nhà trường, bao gồm kế hoạch, chỉ tiêu được giao, danh sách trẻ, kết quả điều tra, kết quả tuyển sinh, biên bản đối chiếu số liệu, xác nhận của tổ chuyên môn và Ban giám hiệu. Không yêu cầu tạo thêm hồ sơ mang tính hình thức.
>
> ### IV. Bảng theo dõi kết quả huy động trẻ theo độ tuổi
>
> | Độ tuổi | Chỉ tiêu được giao | Kết quả thực tế | Tỷ lệ thực hiện | Mức đánh giá |
> |---|---|---|---|---|
> | Nhà trẻ | … | … | …% | … |
> | Mẫu giáo 3 tuổi | … | … | …% | … |
> | Mẫu giáo 4 tuổi | … | … | …% | … |
> | Mẫu giáo 5 tuổi | … | … | …% | … |
> | **Tổng mẫu giáo 3–5 tuổi** | **…** | **…** | **…%** | **…** |
>
> **Nhận xét kết quả huy động:** ......................................................................
>
> **Nguyên nhân chưa đạt (nếu có):** ...............................................................
>
> **Giải pháp tiếp tục thực hiện:** ....................................................................
>
> **Kết quả nổi bật, vượt chỉ tiêu (nếu có):** ......................................................
>
> ### V. Nguyên tắc không thay đổi thang điểm
>
> Việc bổ sung nội dung huy động trẻ ra lớp chỉ nhằm cụ thể hóa nhiệm vụ được giao và bổ sung căn cứ đánh giá kết quả thực hiện nhiệm vụ tại tiêu chí B1.4, Phụ lục I.
>
> Toàn bộ mã tiêu chí, điểm tối đa, các mức chấm điểm và tổng điểm KPI theo Quy chế hiện hành được giữ nguyên. Kết quả huy động trẻ không được tính trùng ở nhiều tiêu chí hoặc sử dụng để cộng thêm điểm vượt quá mức điểm đã quy định.

## 2. Ví dụ minh họa ba mức huy động trẻ

Số liệu giả định để hướng dẫn, không phải chỉ tiêu tuyển sinh thực tế của Trường Mầm non An Bình.

| Độ tuổi | Chỉ tiêu | Thực hiện | Tỷ lệ | Kết quả |
|--------|--------|--------|--------|--------|
| Nhà trẻ | 20 | 18 | 90% | Chưa đạt |
| 3 tuổi | 25 | 25 | 100% | Đạt |
| 4 tuổi | 25 | 27 | 108% | Vượt |
| 5 tuổi | 30 | 30 | 100% | Đạt |
| **Tổng 3–5 tuổi** | **80** | **82** | **102,5%** | **Vượt** |

Ở ví dụ này, chỉ tiêu 4 tuổi và tổng nhóm 3–5 tuổi được xác nhận là **vượt** để ghi nhận thành tích, nhưng không làm phát sinh điểm cộng ngoài tiêu chí B1.4.

## 3. Vị trí chèn nội dung vào văn bản hiện có

| Vị trí trong Quy chế | Thao tác đề xuất |
|--------|--------|
| **Điều 10 – trang 6–7** | Bổ sung khoản 6 về giao và theo dõi chỉ tiêu huy động trẻ. |
| **Phụ lục I, tiêu chí B1.4 – trang 16** | Bổ sung công tác huy động trẻ vào nội dung nhiệm vụ khác; giữ nguyên 3 điểm và toàn bộ mức chấm. |
| **Ngay sau phần B1 hoặc cuối Phụ lục I** | Bổ sung hướng dẫn phân loại chưa đạt, đạt, vượt và bảng theo dõi theo độ tuổi. |
| **Tiêu chí B4.3 – trang 20** | Giữ nguyên nội dung và 3 điểm; chỉ sử dụng minh chứng về phối hợp cha mẹ trẻ, không chấm trùng kết quả huy động. |

## 💡 Khuyến nghị để Quy chế chặt chẽ hơn

Với chỉ tiêu huy động trẻ có tính mùa vụ, nhà trường nên giao **mốc thực hiện theo từng tháng hoặc từng đợt tuyển sinh**, thay vì yêu cầu giáo viên hoàn thành ngay toàn bộ chỉ tiêu năm học trong mọi tháng.

Đồng thời, cần phân biệt **chỉ tiêu huy động trẻ trong địa bàn ra lớp** và **chỉ tiêu tuyển sinh của trường**. Hai chỉ tiêu này có thể khác nhau về đối tượng thống kê, nên phải được xác định trước khi chấm.

## ✅ Kết luận

Phương án bổ sung này bảo đảm ba yêu cầu bạn đặt ra: **có chỉ số huy động trẻ nhà trẻ và mẫu giáo 3–5 tuổi; phân biệt rõ chưa đạt – đạt – vượt chỉ tiêu; giữ nguyên toàn bộ thang điểm đã chốt**.

Tôi đề nghị nhà trường thực hiện bổ sung theo Điều 23 của Quy chế về sửa đổi, bổ sung, lấy ý kiến các bộ phận liên quan và ban hành theo thẩm quyền, thay vì tự chỉnh sửa bản Quy chế đã ký mà không có văn bản điều chỉnh tương ứng.

---

USER

Hằng năm, căn cứ kế hoạch phát triển giáo dục, kế hoạch tuyển sinh, chỉ tiêu huy động trẻ được cấp có thẩm quyền phê duyệt và điều kiện thực tế của nhà trường, Hiệu trưởng tổ chức giao nhiệm vụ huy động trẻ ra lớp theo từng độ tuổi, bao gồm: trẻ nhà trẻ, trẻ mẫu giáo 3 tuổi, 4 tuổi và 5 tuổi.
Việc giao nhiệm vụ phải xác định rõ đối tượng, địa bàn, số lượng hoặc tỷ lệ cần đạt, thời điểm hoàn thành, trách nhiệm của tổ chuyên môn và cá nhân được phân công. Đối với nhiệm vụ giao cho tập thể, cần xác định cụ thể phần việc của từng cá nhân để làm căn cứ đánh giá khách quan.
Kết quả huy động trẻ ra lớp được theo dõi theo ba mức: **Chưa đạt chỉ tiêu, Đạt chỉ tiêu và Vượt chỉ tiêu**, trên cơ sở số liệu thực tế được kiểm tra, đối chiếu và xác nhận.
Kết quả huy động là một trong các minh chứng đánh giá mức độ hoàn thành nhiệm vụ được giao theo tiêu chí KPI hiện có; không hình thành tiêu chí chấm điểm độc lập, không cộng thêm điểm ngoài thang điểm đã ban hành và không làm thay đổi cơ cấu 30 điểm tiêu chí chung, 70 điểm kết quả thực hiện nhiệm vụ.
Trường hợp không được giao nhiệm vụ, chưa đến thời điểm thực hiện hoặc chỉ tiêu được điều chỉnh hợp lệ, việc đánh giá phải căn cứ nhiệm vụ thực tế thuộc trách nhiệm của viên chức; không mặc nhiên xác định không hoàn thành nhiệm vụ. bạn có thể viết lại nội dung này để mình điền vào quy chế một cách logic, lặp luận chặt chẽ giúp người đọc dễ hiểu

---

ASSISTANT

Tôi đề xuất viết lại nội dung này theo văn phong quy chế hành chính, bảo đảm **rõ căn cứ giao nhiệm vụ, trách nhiệm thực hiện, cách xác định kết quả và nguyên tắc chấm KPI**. Đặc biệt, nội dung bổ sung không làm thay đổi các mức điểm đã quy định trong Quy chế.

Bạn có thể sử dụng nguyên văn nội dung dưới đây để bổ sung thành **khoản 6 Điều 10 – Giao nhiệm vụ và minh chứng đánh giá**.

> **writing · document**
>
> **6. Giao nhiệm vụ và đánh giá kết quả huy động trẻ ra lớp**
>
> Hằng năm, căn cứ kế hoạch phát triển giáo dục, kế hoạch tuyển sinh, chỉ tiêu huy động trẻ được giao và điều kiện thực tế của nhà trường, Hiệu trưởng tổ chức phân công nhiệm vụ huy động trẻ ra lớp theo từng độ tuổi, gồm: trẻ nhà trẻ, trẻ mẫu giáo 3 tuổi, 4 tuổi và 5 tuổi.
>
> Việc giao nhiệm vụ phải bảo đảm cụ thể, phù hợp với chức trách, vị trí việc làm và điều kiện thực hiện của từng cá nhân, bộ phận; trong đó xác định rõ đối tượng, địa bàn phụ trách, chỉ tiêu về số lượng hoặc tỷ lệ huy động, thời gian hoàn thành và trách nhiệm thực hiện. Đối với nhiệm vụ giao cho tập thể, phải xác định rõ phần việc và trách nhiệm của từng cá nhân làm cơ sở theo dõi, đánh giá.
>
> Kết quả huy động trẻ ra lớp được xác định trên cơ sở đối chiếu số trẻ huy động thực tế với chỉ tiêu được giao theo từng độ tuổi và thời điểm đánh giá, đồng thời phân loại thành ba mức:
>
> - **Chưa đạt chỉ tiêu:** Kết quả huy động thực tế thấp hơn chỉ tiêu được giao.
> - **Đạt chỉ tiêu:** Kết quả huy động thực tế bằng chỉ tiêu được giao.
> - **Vượt chỉ tiêu:** Kết quả huy động thực tế cao hơn chỉ tiêu được giao.
>
> Việc đánh giá kết quả thực hiện nhiệm vụ huy động trẻ phải căn cứ vào chỉ tiêu được giao, kết quả thực tế, mức độ hoàn thành phần việc của cá nhân và các minh chứng được kiểm tra, xác nhận. Đối với nhiệm vụ có sự phối hợp của nhiều cá nhân, bộ phận hoặc chịu tác động của yếu tố khách quan, việc đánh giá phải xem xét đầy đủ trách nhiệm và kết quả thực hiện của từng cá nhân, không đồng nhất kết quả chung của nhà trường với mức độ hoàn thành nhiệm vụ của một cá nhân.
>
> Kết quả huy động trẻ được sử dụng làm minh chứng đánh giá mức độ hoàn thành nhiệm vụ theo các tiêu chí KPI đã quy định tại Quy chế và phụ lục kèm theo; không xác lập tiêu chí chấm điểm độc lập, không cộng thêm điểm ngoài thang điểm hiện hành và không làm thay đổi cơ cấu 30 điểm tiêu chí chung, 70 điểm kết quả thực hiện nhiệm vụ. Trường hợp huy động vượt chỉ tiêu được ghi nhận trong phần nhận xét, đánh giá kết quả thực hiện nhiệm vụ nhưng không làm tăng điểm tối đa của tiêu chí tương ứng.
>
> Đối với trường hợp cá nhân không được phân công nhiệm vụ huy động trẻ, nhiệm vụ chưa đến thời hạn hoàn thành hoặc chỉ tiêu được điều chỉnh hợp lệ, việc đánh giá căn cứ vào nhiệm vụ thực tế thuộc trách nhiệm của cá nhân trong kỳ; không mặc nhiên xác định là chưa hoàn thành nhiệm vụ hoặc trừ điểm KPI.

## 💡 Một số điểm được hoàn thiện trong cách diễn đạt

So với nội dung ban đầu, bản viết lại đã làm rõ bốn vấn đề:

1\. **Giao nhiệm vụ phải cụ thể:** Không chỉ giao chỉ tiêu huy động chung mà phải xác định phần việc của từng giáo viên, tổ chuyên môn hoặc bộ phận.

2\. **Phân biệt kết quả và trách nhiệm:** Lớp hoặc toàn trường chưa đạt chỉ tiêu không đồng nghĩa mọi giáo viên tham gia đều không hoàn thành nhiệm vụ. Cần xem xét kết quả công việc thực tế được giao.

3\. **Ghi nhận vượt chỉ tiêu nhưng không tăng điểm:** Giáo viên có kết quả huy động vượt chỉ tiêu vẫn được ghi nhận thành tích; tuy nhiên không cộng thêm điểm ngoài mức điểm tối đa đã chốt.

4\. **Bảo đảm công bằng khi đánh giá:** Nhiệm vụ chưa đến hạn, không được giao hoặc đã điều chỉnh hợp lệ không bị xem là chưa hoàn thành.

## ✅ Khuyến nghị vị trí bổ sung

Nội dung trên phù hợp nhất khi đặt tại **khoản 6 Điều 10**, vì đây là điều quy định về giao nhiệm vụ và minh chứng đánh giá.

Đồng thời, tại **tiêu chí B1.4 của Phụ lục I**, tôi đề nghị chỉ bổ sung một cụm ngắn vào phần nội dung tiêu chí:

> “Thực hiện nhiệm vụ khác theo phân công, bao gồm nhiệm vụ huy động trẻ ra lớp theo từng độ tuổi và chỉ tiêu được giao.”

**Giữ nguyên mức tối đa 3 điểm và các mức chấm 3 – 2 – 1 – 0 điểm của B1.4.**

Như vậy, Điều 10 quy định nguyên tắc giao nhiệm vụ và đánh giá; Phụ lục I cụ thể hóa nội dung được chấm. Hai phần có sự liên kết chặt chẽ, không trùng lặp và **không làm thay đổi thang điểm 100 của Quy chế đã ban hành**.

---

USER

trường hợp này sẽ xét theo tháng. Bạn trình bày rối quá, mình xem chẳng hiểu nói chi đến giáo viên

---

ASSISTANT

Tôi hiểu ý bạn rồi. Vì nhà trường **đánh giá KPI hằng tháng**, nội dung phải thật ngắn gọn để giáo viên đọc là hiểu ngay: **Tháng này được giao huy động bao nhiêu trẻ, thực hiện được bao nhiêu trẻ, kết quả đạt hay chưa đạt.**

Tôi đề xuất bổ sung trực tiếp vào **tiêu chí B1.4 – Phụ lục I**, không cần viết thêm một điều dài trong Quy chế.

### 📌 Nội dung bổ sung vào Quy chế

> **writing · document**
>
> **Huy động trẻ ra lớp theo chỉ tiêu được giao**
>
> Hằng tháng, căn cứ chỉ tiêu và nhiệm vụ nhà trường phân công, giáo viên thực hiện công tác tuyên truyền, vận động trẻ ra lớp đối với các độ tuổi: nhà trẻ, mẫu giáo 3 tuổi, 4 tuổi và 5 tuổi.
>
> Cuối tháng, kết quả huy động được đối chiếu với chỉ tiêu của tháng để xác định:
>
> - **Chưa đạt:** Số trẻ huy động thấp hơn chỉ tiêu được giao.
> - **Đạt:** Số trẻ huy động bằng chỉ tiêu được giao.
> - **Vượt:** Số trẻ huy động cao hơn chỉ tiêu được giao.
>
> Kết quả huy động trẻ là căn cứ đánh giá mức độ hoàn thành nhiệm vụ tại tiêu chí **B1.4 (tối đa 3 điểm)**, được xem xét cùng các nhiệm vụ khác đã quy định trong tiêu chí này. **Giữ nguyên các mức chấm 3 – 2 – 1 – 0 điểm; không cộng thêm điểm khi vượt chỉ tiêu.**
>
> Giáo viên không được giao nhiệm vụ huy động trẻ trong tháng thì không bị trừ điểm đối với nội dung này.

### 📋 Ví dụ để giáo viên dễ hiểu

| Độ tuổi | Chỉ tiêu tháng | Thực hiện | Kết quả |
|--------|--------|--------|--------|
| Nhà trẻ | 5 trẻ | 4 trẻ | Chưa đạt |
| Mẫu giáo 3 tuổi | 5 trẻ | 5 trẻ | Đạt |
| Mẫu giáo 4 tuổi | 5 trẻ | 6 trẻ | Vượt |
| Mẫu giáo 5 tuổi | 3 trẻ | 3 trẻ | Đạt |

Số liệu minh họa, không phải chỉ tiêu thực tế của nhà trường.

### ✅ Lưu ý khi chấm điểm

**B1.4 có tổng cộng 3 điểm**, bao gồm nhiều nhiệm vụ khác nhau, không chỉ riêng huy động trẻ. Vì vậy, giáo viên được đánh giá dựa trên toàn bộ nhiệm vụ được giao trong tháng theo các mức điểm B1.4 đã chốt, tránh chấm riêng 3 điểm huy động rồi cộng vào tổng.

Đây là cách tôi khuyến nghị đưa vào Quy chế: **ngắn gọn, dễ hiểu, có kết quả cụ thể theo tháng và giữ nguyên tổng điểm KPI 100 điểm của nhà trường.**

---

USER

mình vẫn chưa hiểu

---

ASSISTANT

Tôi giải thích bằng một ví dụ thật đơn giản nhé. Mục đích của bạn là **đưa việc huy động trẻ vào KPI hằng tháng, phân biệt được chưa đạt – đạt – vượt, nhưng không tăng thêm điểm trong Quy chế.**

## 1. Ví dụ giáo viên được giao huy động trẻ

Tháng 11, nhà trường giao cho giáo viên A huy động **5 trẻ nhà trẻ** ra lớp.

| Kết quả cuối tháng | Đánh giá |
|--------|--------|
| Huy động được 4/5 trẻ | Chưa đạt |
| Huy động được 5/5 trẻ | Đạt |
| Huy động được 6/5 trẻ | Vượt |

Đối với mẫu giáo 3 tuổi, 4 tuổi và 5 tuổi cũng đánh giá tương tự, căn cứ chỉ tiêu được giao cho từng độ tuổi.

## 2. Vậy tính điểm KPI như thế nào?

Trong Quy chế của trường, **B1.4 đã có tối đa 3 điểm**, dùng để đánh giá các nhiệm vụ khác theo phân công.

Tôi đề xuất:

- Huy động trẻ được bổ sung thành **một nhiệm vụ thuộc B1.4**.
- Giáo viên huy động đạt hoặc vượt thì được ghi nhận kết quả tương ứng. Vượt chỉ tiêu không được cộng thêm điểm.
- Khi chấm B1.4, nhà trường vẫn xem xét **toàn bộ nhiệm vụ được giao trong tháng** và áp dụng các mức 3 – 2 – 1 – 0 điểm đã chốt.

Như vậy, **không phải cứ huy động được 4/5 trẻ là tự động chấm B1.4 được 1 điểm**, vì giáo viên còn các nhiệm vụ khác trong mục này.

## 3. Đây là đoạn tôi đề nghị đưa vào Quy chế

> **writing · document**
>
> **Bổ sung nội dung huy động trẻ ra lớp vào tiêu chí B1.4**
>
> Hằng tháng, giáo viên thực hiện nhiệm vụ tuyên truyền, vận động và huy động trẻ nhà trẻ, mẫu giáo 3 tuổi, 4 tuổi, 5 tuổi ra lớp theo chỉ tiêu và sự phân công của nhà trường.
>
> Kết quả huy động được đánh giá theo ba mức: **Chưa đạt** khi số trẻ huy động thấp hơn chỉ tiêu; **Đạt** khi bằng chỉ tiêu; **Vượt** khi cao hơn chỉ tiêu được giao.
>
> Kết quả huy động trẻ là một trong những căn cứ đánh giá mức độ hoàn thành nhiệm vụ tại tiêu chí B1.4. Việc chấm điểm thực hiện theo các mức điểm đã quy định, tối đa 3 điểm; không cộng thêm điểm khi huy động vượt chỉ tiêu. Giáo viên không được giao nhiệm vụ huy động trẻ trong tháng thì không bị trừ điểm đối với nội dung này.

**Điểm quan trọng:** Huy động trẻ là một nội dung công việc được bổ sung, **không phải một tiêu chí cộng điểm mới**. Tổng KPI của giáo viên vẫn là 100 điểm.

Tuy nhiên, tôi muốn xác định đúng một ý của bạn để tránh thiết kế sai: **Bạn muốn việc huy động trẻ được chấm điểm riêng theo 3 mức chưa đạt – đạt – vượt, hay chỉ muốn ghi nhận 3 mức này để làm căn cứ chấm trong 3 điểm B1.4 hiện có?**

---

USER

ghi nhận 3 mức này để làm căn cứ chấm trong 3 điểm B1.4 hiện có

---

ASSISTANT

Vậy tôi đã hiểu đúng yêu cầu của bạn. **Nhà trường chỉ ghi nhận kết quả huy động trẻ theo 3 mức: Chưa đạt – Đạt – Vượt, sau đó dùng kết quả này làm căn cứ chấm tiêu chí B1.4 đã có 3 điểm.** Không tách điểm riêng, không cộng điểm thưởng.

Tôi đề xuất đưa nguyên văn nội dung sau vào Quy chế:

> **writing · document**
>
> ### Bổ sung nội dung huy động trẻ vào tiêu chí B1.4 (3 điểm)
>
> Hằng tháng, giáo viên thực hiện công tác tuyên truyền, vận động và huy động trẻ nhà trẻ, mẫu giáo 3 tuổi, 4 tuổi và 5 tuổi ra lớp theo chỉ tiêu, nhiệm vụ được nhà trường phân công.
>
> Cuối tháng, căn cứ chỉ tiêu được giao và số trẻ huy động thực tế của từng độ tuổi, kết quả được ghi nhận theo 03 mức:
>
> - **Chưa đạt:** Số trẻ huy động thấp hơn chỉ tiêu được giao.
> - **Đạt:** Số trẻ huy động bằng chỉ tiêu được giao.
> - **Vượt:** Số trẻ huy động cao hơn chỉ tiêu được giao.
>
> Kết quả huy động trẻ là một trong những căn cứ để đánh giá mức độ hoàn thành các nhiệm vụ thuộc tiêu chí **B1.4**; không chấm điểm riêng cho từng mức huy động.
>
> Việc chấm điểm B1.4 căn cứ vào kết quả thực hiện toàn bộ nhiệm vụ được giao trong tháng, áp dụng các mức điểm **3 – 2 – 1 – 0 điểm** đã quy định. Kết quả huy động vượt chỉ tiêu được ghi nhận trong phần nhận xét nhưng không cộng thêm điểm.
>
> Giáo viên không được giao nhiệm vụ huy động trẻ trong tháng thì không bị trừ điểm đối với nội dung này.

## 📋 Ví dụ giáo viên dễ hiểu

Giả sử giáo viên được giao huy động 5 trẻ nhà trẻ trong tháng:

| Số trẻ huy động | Ghi nhận |
|--------|--------|
| 4 trẻ | Chưa đạt |
| 5 trẻ | Đạt |
| 6 trẻ | Vượt |

**Khi chấm KPI:** Ban giám hiệu xem kết quả huy động này cùng với các công việc khác của B1.4 như trực lớp, đón trả trẻ, bảo quản đồ dùng và chuẩn bị môi trường giáo dục.

Chẳng hạn, giáo viên huy động 4/5 trẻ nhưng các nhiệm vụ khác đều hoàn thành thì **không tự động chấm B1.4 là 0 điểm**. Nhà trường vẫn xác định tỷ lệ hoàn thành chung và áp dụng thang điểm B1.4 hiện hành.

## ✅ Kết luận

Bạn chỉ cần bổ sung đoạn trên vào **Phụ lục I, tiêu chí B1.4** của Quy chế. Giữ nguyên:

- Điểm tối đa B1.4: **3 điểm**.
- Các mức chấm: **3 – 2 – 1 – 0 điểm**.
- Tổng điểm KPI giáo viên: **100 điểm**.

Cách này vừa ghi nhận được giáo viên huy động trẻ **chưa đạt, đạt hoặc vượt chỉ tiêu hằng tháng**, vừa không làm xáo trộn các điểm số mà nhà trường đã thống nhất.

---

USER

vậy mục B1.4 sẽ được trình bày như thế nào

---

ASSISTANT

Bạn giữ nguyên **mã B1.4, điểm tối đa 3 điểm và các mức chấm đã có**. Chỉ bổ sung nhiệm vụ huy động trẻ vào phần nội dung và minh chứng.

Dưới đây là cách trình bày hoàn chỉnh để bạn thay thế dòng **B1.4 trong Phụ lục I của Quy chế**.

> **writing · document**
>
> ### B1.4. Thực hiện các nhiệm vụ khác theo phân công
>
> | Nội dung | Quy định |
> |---|---|
> | **Mã số** | B1.4 |
> | **Tiêu chí** | Thực hiện các nhiệm vụ khác theo phân công: trực lớp, đón trả trẻ, bảo quản đồ dùng, chuẩn bị môi trường giáo dục, thực hiện nhiệm vụ chung; tuyên truyền, vận động và huy động trẻ nhà trẻ, mẫu giáo 3 tuổi, 4 tuổi, 5 tuổi ra lớp theo chỉ tiêu được giao trong tháng (nếu có). |
> | **Điểm tối đa** | **3 điểm** |
> | **Quy định mức điểm** | **3 điểm:** Hoàn thành 100% nhiệm vụ được giao. |
> | | **2 điểm:** Hoàn thành từ 90% đến dưới 100%. |
> | | **1 điểm:** Hoàn thành từ 70% đến dưới 90%. |
> | | **0 điểm:** Hoàn thành dưới 70%. |
> | **Minh chứng/biểu hiện** | Bảng phân công nhiệm vụ; lịch trực; kết quả kiểm tra; chỉ tiêu huy động trẻ trong tháng; danh sách và số trẻ huy động thực tế được xác nhận. |
>
> **Ghi chú về kết quả huy động trẻ:**
>
> Cuối tháng, căn cứ chỉ tiêu được giao và số trẻ huy động thực tế, kết quả được ghi nhận như sau:
>
> - **Chưa đạt:** Số trẻ huy động thấp hơn chỉ tiêu.
> - **Đạt:** Số trẻ huy động bằng chỉ tiêu.
> - **Vượt:** Số trẻ huy động cao hơn chỉ tiêu.
>
> Kết quả huy động trẻ là một trong các căn cứ để đánh giá mức độ hoàn thành nhiệm vụ tại B1.4; không chấm điểm riêng. Việc chấm điểm căn cứ vào toàn bộ nhiệm vụ được giao trong tháng, theo các mức điểm đã quy định.
>
> Trường hợp huy động vượt chỉ tiêu được ghi nhận trong phần nhận xét nhưng không cộng thêm điểm. Giáo viên không được giao nhiệm vụ huy động trẻ trong tháng thì không bị trừ điểm đối với nội dung này.

## 📋 Ví dụ cách thực hiện

Tháng 11, giáo viên A được giao huy động 5 trẻ nhà trẻ, thực tế huy động được 6 trẻ.

Kết quả ghi nhận: **Vượt chỉ tiêu huy động trẻ.**

Tuy nhiên, điểm B1.4 vẫn căn cứ vào cả việc trực lớp, đón trả trẻ, bảo quản đồ dùng, chuẩn bị môi trường giáo dục và các nhiệm vụ khác được giao. Nếu giáo viên hoàn thành đầy đủ các nhiệm vụ đó thì chấm **3/3 điểm**.

Ngược lại, nếu huy động chưa đạt chỉ tiêu thì cũng **không tự động trừ điểm**, mà phải xem xét mức độ hoàn thành tổng thể các nhiệm vụ của B1.4.

**Như vậy, nhà trường chỉ cần thay nội dung dòng B1.4 và thêm phần ghi chú ngay dưới bảng B1.** Tổng điểm B1 vẫn là 20 điểm, tổng KPI giáo viên vẫn là 100 điểm, không ảnh hưởng đến các mục đã chốt.

---

USER

Trong năm học sẽ phát sinh các phong trào trong và ngoài ngành ngoài kế hoạch thực hiện thời gian năm học. Với nội dung này nhà trường định hướng sẽ thực hiện vào mục vượt tỷ lệ 30% để tạo điều kiện khen thường xuất sắc cho giáo viên (tùy nhiên tùy vào độ khó mức độ phức tạp của hội thi mà số tỷ lệ sẽ khác nhau. Bạn hãy giúp tôi trình bày nội dung này trong quy chế

---

ASSISTANT

Tôi sẽ đối chiếu quy định về “30% nhiệm vụ hoàn thành vượt mức” với Quy chế của trường, rồi soạn một điều khoản ngắn gọn để ghi nhận các hội thi, phong trào phát sinh ngoài kế hoạch. Phần này cần phân biệt rõ **thành tích xét khen thưởng giáo viên** với **điều kiện xếp loại xuất sắc của nhà trường**, để tránh áp dụng nhầm.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Có thể bổ sung nội dung này vào Quy chế để **khuyến khích giáo viên tham gia các hội thi, phong trào phát sinh ngoài kế hoạch và ghi nhận thành tích nổi trội khi xét khen thưởng, xếp loại xuất sắc**.

Tuy nhiên, có một điểm pháp lý quan trọng: quy định **ít nhất 30% nhiệm vụ hoàn thành vượt mức yêu cầu** tại khoản 1 Điều 7 Nghị định 233/2026/NĐ-CP là điều kiện đánh giá **đơn vị sự nghiệp công lập**, không phải điều kiện bắt buộc của từng giáo viên. Viên chức được xét hoàn thành xuất sắc từ 90 điểm trở lên và phải đáp ứng các quy định, tỷ lệ xếp loại có liên quan. [Điều 7 Nghị định 233/2026/NĐ\-CP quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức](<https://hethongphapluat.com/nghi-dinh-233-2026-nd-cp-quy-dinh-ve-danh-gia-xep-loai-chat-luong-doi-voi-don-vi-su-nghiep-cong-lap-va-vien-chuc/dieu-7>); [Các mức xếp loại chất lượng viên chức](<https://xaydungchinhsach.chinhphu.vn/cac-muc-xep-loai-chat-luong-vien-chuc-119260701155446369.htm>)

Vì vậy, tôi đề nghị nhà trường quy định **mức ghi nhận thành tích vượt kế hoạch theo độ khó của từng hoạt động**, sử dụng làm căn cứ xét thành tích nổi trội của giáo viên, đồng thời tổng hợp minh chứng phục vụ đánh giá nhiệm vụ của nhà trường. Các mức quy đổi dưới đây là đề xuất nội bộ, không phải tỷ lệ do Nghị định quy định.

## 📖 Nội dung đề xuất bổ sung vào Điều 10 của Quy chế

> **writing · document**
>
> ### Ghi nhận nhiệm vụ phát sinh ngoài kế hoạch và thành tích vượt mức
>
> Trong năm học, ngoài các nhiệm vụ theo kế hoạch, nhà trường khuyến khích giáo viên tích cực tham gia các hội thi, phong trào, hoạt động chuyên môn và nhiệm vụ phát sinh do ngành giáo dục, địa phương hoặc các cơ quan, tổ chức có thẩm quyền phát động.
>
> Đối với từng hoạt động, Ban giám hiệu xác định nội dung, yêu cầu, thời gian thực hiện, người được phân công và mức độ khó, phức tạp của nhiệm vụ. Kết quả thực hiện được ghi nhận hằng tháng và tổng hợp cuối năm học.
>
> **1. Mức ghi nhận thành tích vượt kế hoạch**
>
> Căn cứ khối lượng công việc, yêu cầu chuyên môn, thời gian chuẩn bị, mức độ phức tạp và kết quả thực hiện, nhà trường đề xuất quy đổi mức đóng góp vượt kế hoạch như sau:
>
> | Mức độ | Đặc điểm nhiệm vụ | Tỷ lệ ghi nhận đề xuất |
> |---|---|---:|
> | **Mức 1 – Đơn giản** | Hoạt động có khối lượng công việc ít, yêu cầu chuẩn bị và phối hợp không phức tạp. | 5% |
> | **Mức 2 – Trung bình** | Hoạt động cần xây dựng sản phẩm, chuẩn bị nội dung, có yêu cầu chuyên môn và thời gian thực hiện nhất định. | 10% |
> | **Mức 3 – Khó** | Hoạt động có yêu cầu chuyên môn cao, nhiều công đoạn, thời gian chuẩn bị dài hoặc cần phối hợp nhiều bộ phận. | 15% |
> | **Mức 4 – Đặc biệt khó** | Hoạt động có quy mô lớn, nhiều vòng thực hiện, yêu cầu chuyên môn sâu, sản phẩm phức tạp hoặc trách nhiệm cao. | 20% |
>
> Các tỷ lệ trên là **mức quy đổi thành tích phục vụ công tác theo dõi, xét thi đua, khen thưởng nội bộ**, không phải tỷ lệ nhiệm vụ hoàn thành vượt mức theo quy định của pháp luật.
>
> **2. Nguyên tắc ghi nhận**
>
> Giáo viên được ghi nhận thành tích khi hoàn thành nhiệm vụ phát sinh ngoài kế hoạch, có sản phẩm hoặc kết quả cụ thể được xác nhận. Mức ghi nhận căn cứ vào tính chất hoạt động, trách nhiệm thực tế của cá nhân và kết quả đạt được; không chỉ dựa vào cấp tổ chức hoặc việc tham gia hội thi.
>
> Đối với hoạt động có nhiều giáo viên cùng tham gia, việc ghi nhận phải phù hợp với nhiệm vụ, mức độ đóng góp của từng cá nhân. Một kết quả không được tính trùng nhiều lần.
>
> **3. Sử dụng kết quả xét thành tích nổi trội**
>
> Cuối năm học, nhà trường tổng hợp các mức ghi nhận của từng giáo viên. Cá nhân có tổng mức ghi nhận từ **30% trở lên** được ưu tiên xem xét về thành tích vượt kế hoạch khi đề nghị khen thưởng, trên cơ sở kết quả KPI, chất lượng công việc thường xuyên và các điều kiện theo quy định.
>
> Mức 30% nêu trên là mốc tham khảo do nhà trường đề xuất áp dụng trong xét thành tích nội bộ, không phải điều kiện bắt buộc đối với viên chức theo Nghị định số 233/2026/NĐ-CP.
>
> Việc ghi nhận thành tích vượt kế hoạch không làm tăng tổng điểm KPI tối đa 100 điểm; không tự động quyết định mức xếp loại “Hoàn thành xuất sắc nhiệm vụ” hoặc kết quả khen thưởng. Việc xếp loại và khen thưởng thực hiện theo quy định của pháp luật và Quy chế của nhà trường.
>
> Giáo viên không được phân công hoặc không có cơ hội tham gia hoạt động phát sinh không bị trừ điểm KPI; những sáng kiến, giải pháp hoặc nhiệm vụ vượt kế hoạch khác có giá trị tương đương được xem xét ghi nhận công bằng.

## 📋 Ví dụ để giáo viên dễ hiểu

Giả sử trong năm học, giáo viên A hoàn thành tốt nhiệm vụ thường xuyên và được ghi nhận ba hoạt động phát sinh:

| Hoạt động | Độ khó | Mức ghi nhận |
|--------|--------|--------|
| Tham gia hoạt động phong trào phát sinh của địa phương | Đơn giản | 5% |
| Xây dựng sản phẩm tham gia hội thi ngoài kế hoạch | Trung bình | 10% |
| Thực hiện hội thi có nhiều vòng, yêu cầu chuyên môn cao | Khó | 15% |
| **Tổng mức ghi nhận** |  | **30%** |

Như vậy, giáo viên A có **30% mức đóng góp vượt kế hoạch theo quy ước nội bộ** để nhà trường tham khảo khi xét thành tích nổi trội. Đây không phải 30% nhiệm vụ hoàn thành vượt mức theo Điều 7 Nghị định 233/2026/NĐ-CP.

## ✅ Vị trí và cách áp dụng

Tôi khuyến nghị bổ sung nội dung này thành **một khoản mới tại Điều 10 – Giao nhiệm vụ và minh chứng đánh giá**, đánh số phù hợp khi hoàn thiện Quy chế. Nhà trường không cần sửa điểm trong Phụ lục I; hằng tháng chỉ ghi nhận các hoạt động phát sinh vào bảng theo dõi, cuối năm tổng hợp để xét thành tích.

**Điều cần thống nhất trước khi ban hành:** Mức 5% – 10% – 15% – 20% và mốc tham khảo 30% là phương án quản trị do tôi đề xuất, cần được tập thể nhà trường thảo luận, phê duyệt. Để tránh khiếu nại, mức độ khó của từng hoạt động nên được xác định khi giao nhiệm vụ, không tùy ý điều chỉnh sau khi có kết quả hội thi.

Đặc biệt, **hồ sơ 30% nhiệm vụ hoàn thành vượt mức của nhà trường phải được tổng hợp, xác định riêng**; không lấy phép cộng các tỷ lệ ghi nhận thành tích của giáo viên để thay thế điều kiện đó.

---

USER

trong quy chế này khá đầy đủ các nội dung và khá sát thực tiễn. Dựa vào các nội dung KPI bạn hãy giúp tôi thiết kế đầu việc KPI cho từng tháng để giáo viên, nhân viên dễ thực hiện

---

USER

file excel canh chỉnh hợp lý để tiện in ấn

---

ASSISTANT

Tôi sẽ thiết kế **file Excel giao việc KPI theo từng tháng cho năm học 2026–2027**, căn cứ trực tiếp vào Quy chế số 89/QĐ-MNAB của Trường Mầm non An Bình mà bạn đã gửi.

File sẽ gồm phiếu giao việc cho **giáo viên và 07 vị trí nhân viên**: cấp dưỡng, y tế, kế toán, văn thư, thủ quỹ, bảo vệ và phục vụ. Mỗi phiếu có mã KPI, đầu việc cần thực hiện, kết quả cần đạt, minh chứng và ô ghi kết quả thực tế.

Để đúng với Quy chế hiện tại, tôi sẽ giữ nguyên **30 điểm tiêu chí chung + 70 điểm kết quả thực hiện nhiệm vụ**, không dùng khung 06 trục của phương án trước. Các phiếu được căn chỉnh **A4 ngang, một tháng/một vị trí/một trang**, có chỗ ký xác nhận và không tự chấm điểm khi chưa có kết quả thực tế.

## 📥 File Excel đầu việc KPI theo tháng – sẵn để in A4

Bạn có thể chọn tháng, vị trí rồi tải phiếu riêng, hoặc tải **toàn bộ kế hoạch 12 tháng cho cả trường**. Trong file, mỗi vị trí được bố trí thành một trang tính riêng, mỗi tháng có ngắt trang để in độc lập.

## Xuất Excel giao việc KPI – Trường Mầm non An Bình

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="mnab-kpi-export" class="w-full space-y-4">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="font-semibold text-base">PHIẾU GIAO VIỆC KPI HẰNG THÁNG</div>
    <div class="text-sm opacity-70">Năm học 2026–2027 · A: 30 điểm · B: 70 điểm · Khổ A4 ngang</div>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <label class="text-sm space-y-1"><span class="font-medium">Vị trí</span><select data-role class="w-full rounded-lg border p-2 bg-transparent"></select></label>
      <label class="text-sm space-y-1"><span class="font-medium">Tháng</span><select data-month class="w-full rounded-lg border p-2 bg-transparent"></select></label>
    </div>
    <div class="rounded-lg p-3 bg-black/5 dark:bg-white/5 space-y-2">
      <div class="font-medium text-sm">Đầu việc tháng đã chọn</div>
      <div data-preview class="space-y-1 text-sm"></div>
    </div>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
      <button data-single class="rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-semibold p-3 cursor-pointer">Tải phiếu 01 tháng (.xlsx)</button>
      <button data-year class="rounded-lg border p-3 font-semibold cursor-pointer">Tải 12 tháng của vị trí</button>
    </div>
    <button data-all class="w-full rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold p-3 cursor-pointer">Tải Excel toàn trường – 08 vị trí, 12 tháng</button>
    <p data-status class="text-xs opacity-70" role="status">Các ô “Kết quả thực tế” và “Trạng thái” được để trống để người thực hiện cập nhật.</p>
  </div>
  <div class="text-xs opacity-65">Bản kế hoạch là gợi ý giao việc theo tháng, không tự thay đổi mức điểm trong Quy chế. Các nhiệm vụ theo đợt, nhiệm vụ hè và hội thi chỉ áp dụng khi được nhà trường phân công.</div>
</div>
<script>
(function(){
const root=document.getElementById("mnab-kpi-export");
if(!root||root.dataset.ready)return;root.dataset.ready="1";
const months=[
["09/2026","Ổn định đầu năm, hoàn thiện phân công và môi trường giáo dục"],
["10/2026","Củng cố nề nếp, kiểm tra quy trình chuyên môn"],
["11/2026","Hoạt động chuyên môn và phong trào theo kế hoạch, phân công"],
["12/2026","Rà soát kết quả học kỳ I, hồ sơ và công việc cuối năm dương lịch"],
["01/2027","Sơ kết học kỳ I, chuẩn bị an toàn trước kỳ nghỉ Tết"],
["02/2027","Ổn định sau kỳ nghỉ, chăm sóc và phòng bệnh"],
["03/2027","Tăng cường chất lượng, hoạt động chuyên đề và phối hợp"],
["04/2027","Rà soát chất lượng cuối năm, phòng ngừa rủi ro mùa nóng"],
["05/2027","Tổng kết năm học, hoàn thiện hồ sơ, bàn giao"],
["06/2027","Nhiệm vụ hè theo phân công; bảo trì và hỗ trợ tuyển sinh"],
["07/2027","Tuyển sinh, rà soát điều kiện chuẩn bị năm học mới"],
["08/2027","Chuẩn bị khai giảng và tổ chức hoạt động đầu năm học mới"]
];
const roles=[
{id:"GV",name:"Giáo viên",sheet:"GIAO_VIEN",base:[
"B1.1/B3.1|Xây dựng kế hoạch giáo dục|Hoàn thành kế hoạch tháng, tuần và nhiệm vụ được giao đúng hạn.|Kế hoạch, hồ sơ chuyên môn",
"B1.2/B2.3|Tổ chức hoạt động giáo dục|Thực hiện đủ hoạt động theo kế hoạch; bảo đảm phù hợp độ tuổi, lấy trẻ làm trung tâm.|Kế hoạch, phiếu quan sát",
"B2.1|Bảo đảm an toàn cho trẻ|Thực hiện đúng điểm danh, giám sát, đón trả; phát hiện và xử lý nguy cơ mất an toàn.|Sổ đón trả, bảng kiểm an toàn",
"B2.2|Thực hiện chăm sóc, nuôi dưỡng|Tổ chức ăn, ngủ, vệ sinh và theo dõi sức khỏe theo quy trình được giao.|Sổ lớp, kết quả kiểm tra",
"B1.3/B2.4|Hoàn thiện hồ sơ, đánh giá trẻ|Cập nhật đúng hạn hồ sơ lớp và nội dung quan sát, đánh giá phát triển của trẻ.|Hồ sơ lớp, phiếu theo dõi",
"B4.2/B4.3|Phối hợp giáo viên và cha mẹ trẻ|Bàn giao thông tin, phối hợp thực hiện nhiệm vụ và hỗ trợ trẻ theo nhu cầu.|Sổ bàn giao, ghi nhận trao đổi"
],focus:[
["B1.4|Huy động trẻ ra lớp đầu năm|Ghi rõ chỉ tiêu được giao, số huy động; nhận xét chưa đạt, đạt hoặc vượt nếu được giao.|Chỉ tiêu, danh sách trẻ","B4.1/A4.2|Ổn định nề nếp và môi trường lớp|Hoàn thiện môi trường, sinh hoạt chuyên môn đầu năm và một nội dung vận dụng.|Biên bản, hình ảnh"],
["B1.4|Theo dõi sĩ số, huy động bổ sung|Đối chiếu số trẻ theo độ tuổi và phần việc huy động được giao trong tháng.|Danh sách, xác nhận","B4.1|Dự giờ, chia sẻ biện pháp giáo dục|Tham gia đầy đủ hoạt động chuyên môn theo lịch; có ý kiến hoặc sản phẩm vận dụng.|Biên bản, sản phẩm"],
["B3.3|Thực hiện hoạt động phong trào phát sinh|Hoàn thành nhiệm vụ hội thi, phong trào khi có phân công hợp lệ.|Phân công, sản phẩm","A4.2/B2.3|Cải tiến một hoạt động giáo dục|Vận dụng một giải pháp tổ chức hoạt động phù hợp; ghi nhận hiệu quả thực tế.|Giáo án, hình ảnh"],
["B2.4|Rà soát kết quả phát triển của trẻ|Cập nhật nhận xét trẻ theo tiến độ đánh giá học kỳ I và kế hoạch lớp.|Hồ sơ theo dõi trẻ","B3.1/B3.2|Hoàn thiện hồ sơ sơ kết|Nộp đủ hồ sơ, báo cáo và minh chứng được giao đúng thời hạn.|Báo cáo, phiếu nhận"],
["B2.4|Đánh giá, hỗ trợ trẻ cuối học kỳ I|Tổng hợp kết quả theo dõi, xác định nhu cầu và giải pháp hỗ trợ trẻ.|Bảng đánh giá, kế hoạch hỗ trợ","B2.1/B4.3|Tuyên truyền an toàn dịp nghỉ Tết|Trao đổi với cha mẹ trẻ nội dung an toàn, sức khỏe theo hướng dẫn nhà trường.|Tin nhắn, tài liệu"],
["B1.4|Vận động trẻ trở lại lớp sau kỳ nghỉ|Theo dõi chuyên cần; thực hiện huy động theo chỉ tiêu nếu nhà trường giao.|Sổ chuyên cần, danh sách","B2.2|Tăng cường chăm sóc, phòng bệnh|Kiểm tra vệ sinh, phối hợp theo dõi sức khỏe trong giai đoạn sau nghỉ.|Sổ lớp, bảng kiểm"],
["B4.1|Tham gia chuyên đề, hội thi được giao|Hoàn thành nội dung chuyên môn và nhiệm vụ phong trào nếu phát sinh.|Kế hoạch, minh chứng","B2.3|Tổ chức hoạt động trải nghiệm|Tổ chức hoạt động theo chủ đề với điều kiện an toàn và sự tham gia chủ động của trẻ.|Giáo án, phiếu quan sát"],
["B2.4|Rà soát đánh giá trẻ cuối năm|Hoàn thành quan sát, đánh giá trẻ theo tiến độ được duyệt.|Hồ sơ đánh giá trẻ","B2.1|Tăng cường an toàn mùa nóng|Kiểm tra nguy cơ tại lớp, hoạt động ngoài trời; phối hợp phòng tai nạn.|Bảng kiểm, sổ lớp"],
["B1.3/B3.1|Hoàn thành hồ sơ cuối năm học|Hoàn thiện đầy đủ hồ sơ lớp và báo cáo tổng kết theo phân công.|Hồ sơ, báo cáo","B1.4|Bàn giao, phối hợp chỉ tiêu năm mới|Thực hiện bàn giao và nhiệm vụ huy động trẻ nếu có phân công.|Biên bản, danh sách"],
["B1.4|Hỗ trợ tuyển sinh hè nếu được giao|Hoàn thành phần việc điều tra, tuyên truyền hoặc cập nhật danh sách theo chỉ tiêu.|Phân công, danh sách","B1.2|Thực hiện hoạt động hè nếu được phân công|Đảm bảo nhiệm vụ chăm sóc, giáo dục hè theo kế hoạch thực tế.|Lịch hè, sổ theo dõi"],
["B1.4|Rà soát trẻ trong độ tuổi theo phân công|Đối chiếu danh sách nhà trẻ và mẫu giáo 3, 4, 5 tuổi nếu được giao nhiệm vụ.|Danh sách, biên bản","B4.1/A4.1|Bồi dưỡng chuyên môn theo kế hoạch hè|Thực hiện nhiệm vụ học tập, chuẩn bị học liệu nếu có phân công hợp lệ.|Sản phẩm, ghi nhận"],
["B1.1|Chuẩn bị kế hoạch năm học mới|Xây dựng kế hoạch và hồ sơ đầu năm theo lớp, độ tuổi được phân công.|Kế hoạch, hồ sơ","B1.4|Phối hợp huy động và ổn định lớp|Cập nhật trẻ nhập học, kết quả huy động và môi trường lớp theo phân công.|Danh sách, bảng kiểm"]
]},
{id:"CD",name:"Nhân viên cấp dưỡng",sheet:"CAP_DUONG",base:[
"B1.1|Thực hiện ca chế biến, các bữa ăn|Hoàn thành ca, công đoạn và số bữa theo thực đơn, số trẻ ăn thực tế được giao.|Lịch bếp, nhật ký chế biến",
"B1.2|Tiếp nhận và sơ chế thực phẩm|Thực hiện đủ việc giao nhận, sơ chế, chia suất, thu dọn theo phân công.|Phiếu giao nhận, nhật ký",
"B2.1|Vệ sinh an toàn thực phẩm|Thực hiện đúng bảo hộ, vệ sinh cá nhân, tách sống – chín, tránh nhiễm chéo.|Bảng kiểm, biên bản",
"B2.2|Thực đơn, định lượng, kiểm thực, lưu mẫu|Chế biến đúng thực đơn, định lượng và thực hiện kiểm thực, lưu mẫu theo trách nhiệm.|Thực đơn, sổ kiểm thực",
"B2.3|Vệ sinh, bảo quản khu vực bếp|Khử khuẩn dụng cụ, bảo quản thực phẩm, thu gom rác đúng quy trình.|Sổ vệ sinh, kiểm tra bếp",
"B3.1/B3.2|Bàn giao thức ăn và ghi sổ đúng hạn|Đủ suất, đúng giờ ăn; hoàn tất sổ bếp và giao nhận kịp thời.|Sổ giao nhận, lịch ăn"
],focus:[
["B4.1|Ổn định phối hợp bếp ăn đầu năm|Thống nhất khâu tiếp nhận, chia suất và giao nhận với các lớp.|Biên bản phân công","B4.2|Kiểm tra dụng cụ, thiết bị bếp|Rà soát thiết bị, đề xuất khắc phục hư hỏng trước khi phục vụ.|Bảng kiểm, đề xuất"],
["B2.1|Rà soát nguy cơ nhiễm chéo|Kiểm tra khu sơ chế, khu chế biến và bảo quản theo quy trình.|Bảng kiểm bếp","B4.2|Thực hành tiết kiệm nguyên liệu|Thực hiện một biện pháp giảm hao hụt được tổ bếp thống nhất.|Ghi nhận, bảng nguyên liệu"],
["B4.1|Phối hợp phục vụ hoạt động được giao|Bố trí công đoạn, thời gian bếp khi có hoạt động đặc biệt.|Phiếu giao việc","B2.3|Kiểm tra vệ sinh, bảo quản dụng cụ|Tổng vệ sinh định kỳ và kiểm tra dụng cụ, khu vực lưu trữ.|Bảng kiểm, hình ảnh"],
["B2.2|Rà soát định lượng và thực đơn|Đối chiếu số suất, lượng thực phẩm theo thực đơn đã duyệt.|Bảng định lượng","B4.2|Tổng hợp hao hụt, bảo quản|Ghi nhận việc tiết kiệm, bảo quản tài sản phục vụ sơ kết.|Phiếu theo dõi"],
["B3.1|Bảo đảm lịch phục vụ trước nghỉ Tết|Hoàn thành bữa ăn theo lịch, không tự ý đổi thực đơn.|Lịch ăn, sổ giao nhận","B2.1|Kiểm tra an toàn bếp trước nghỉ|Vệ sinh bếp, khóa điện, gas, nước theo quy trình bàn giao.|Bảng kiểm"],
["B2.1|Kiểm tra an toàn thực phẩm sau nghỉ|Rà soát thực phẩm, hạn dùng, thiết bị trước khi phục vụ trở lại.|Phiếu kiểm tra","B4.1|Phối hợp điều chỉnh số suất|Đối chiếu số trẻ ăn thực tế với các lớp.|Bảng báo ăn, phiếu giao"],
["B4.2|Rà soát phương án tiết kiệm thực phẩm|Đề xuất cải tiến công đoạn, giảm hao hụt được duyệt.|Đề xuất, bảng theo dõi","B2.3|Kiểm tra khử khuẩn khu vực chế biến|Thực hiện đủ nội dung kiểm tra vệ sinh theo lịch.|Sổ vệ sinh"],
["B2.1|Kiểm soát an toàn thực phẩm mùa nóng|Tăng cường kiểm tra bảo quản nguyên liệu và nhiệt độ theo quy trình.|Bảng kiểm, sổ kho","B2.2|Rà soát kiểm thực, lưu mẫu|Đối chiếu ghi chép với thực tế; khắc phục thiếu sót nếu có.|Sổ kiểm thực, lưu mẫu"],
["B4.2|Tổng hợp công tác tiết kiệm cuối năm|Hoàn thiện ghi nhận giảm hao hụt, bảo quản vật tư theo kế hoạch.|Báo cáo, sổ theo dõi","B2.3|Bàn giao, vệ sinh bếp cuối năm|Vệ sinh, kiểm kê và bàn giao dụng cụ theo phân công.|Biên bản bàn giao"],
["B1.1|Thực hiện ca bếp hè nếu được giao|Phục vụ suất ăn hè theo lịch được phê duyệt.|Lịch bếp hè","B2.3|Vệ sinh, bảo quản thiết bị không sử dụng|Thực hiện bảo quản, kiểm tra hư hỏng theo phân công.|Bảng kiểm"],
["B4.2|Rà soát hư hỏng và nhu cầu vật tư bếp|Lập danh sách đề xuất bảo dưỡng, thay thế hợp lệ.|Danh mục, phiếu đề xuất","B2.1|Kiểm tra an toàn bếp hè|Bảo đảm vệ sinh, hóa chất, nguồn nước theo nhiệm vụ được giao.|Biên bản, bảng kiểm"],
["B1.2|Chuẩn bị quy trình giao nhận thực phẩm|Thống nhất biểu mẫu, công đoạn chuẩn bị đầu năm mới.|Biểu mẫu, phân công","B4.1|Phối hợp các lớp xây dựng lịch giao suất|Rà soát lịch ăn và phương thức giao nhận khi được duyệt.|Lịch ăn, biên bản"]
]},
{id:"YT",name:"Nhân viên y tế",sheet:"Y_TE",base:[
"B1.1|Theo dõi sức khỏe trẻ theo kế hoạch|Thực hiện cân đo, theo dõi, cập nhật thông tin đến kỳ theo phân công.|Hồ sơ sức khỏe",
"B2.1|Sơ cứu, chăm sóc sức khỏe ban đầu|Tiếp nhận, xử lý đúng phạm vi chuyên môn; chuyển tuyến khi cần.|Sổ y tế, hồ sơ xử lý",
"B2.2|Giám sát nguy cơ dịch bệnh|Theo dõi, phát hiện dấu hiệu bất thường và phối hợp phòng ngừa.|Nhật ký, bảng kiểm",
"B2.3|Quản lý thuốc, vật tư và hồ sơ|Kiểm tra hạn dùng, bảo quản, theo dõi sử dụng thuốc và vật tư.|Sổ thuốc, sổ vật tư",
"B3.1/B3.2|Báo cáo, xử lý sự việc đúng hạn|Thông tin khẩn cấp kịp thời; hoàn thành báo cáo định kỳ đúng lịch.|Báo cáo, nhật ký",
"B4.1/B4.2|Phối hợp, truyền thông sức khỏe|Hướng dẫn giáo viên, cha mẹ trẻ và bộ phận bếp theo nhiệm vụ.|Tài liệu, biên bản"
],focus:[
["B1.1|Rà soát hồ sơ sức khỏe đầu năm|Kiểm tra dữ liệu trẻ mới, kế hoạch theo dõi sức khỏe theo lớp.|Danh sách, hồ sơ","B1.2|Truyền thông vệ sinh đầu năm|Hướng dẫn giáo viên và phụ huynh nội dung vệ sinh, phòng bệnh.|Tài liệu, kế hoạch"],
["B1.1|Tổ chức cân đo theo lịch được duyệt|Hoàn thành số lượt thuộc đợt cân đo, cập nhật số liệu chính xác.|Bảng cân đo","B2.2|Theo dõi nguy cơ bệnh truyền nhiễm|Tăng cường giám sát, thông báo kịp thời ca nghi ngờ theo quy trình.|Nhật ký, báo cáo"],
["B1.2|Truyền thông phòng bệnh theo mùa|Thực hiện nội dung truyền thông theo kế hoạch y tế tháng.|Tin bài, tài liệu","B4.1|Phối hợp kiểm tra vệ sinh bếp, lớp|Thực hiện các cuộc kiểm tra được phân công.|Bảng kiểm, biên bản"],
["B2.3|Kiểm kê thuốc, vật tư cuối năm dương lịch|Đối chiếu hạn dùng và tồn kho theo thời điểm được giao.|Biên bản kiểm kê","B1.1|Tổng hợp sức khỏe học kỳ I|Hoàn thành báo cáo tổng hợp theo kế hoạch sơ kết.|Bảng tổng hợp"],
["B2.2|Tăng cường phòng bệnh trước kỳ nghỉ|Hướng dẫn vệ sinh, phòng bệnh, an toàn sinh hoạt theo kế hoạch.|Tài liệu, ghi nhận","B2.3|Bảo quản tủ thuốc trước nghỉ|Rà soát thuốc, thiết bị, điều kiện bảo quản.|Sổ thuốc, bảng kiểm"],
["B2.2|Theo dõi sức khỏe trẻ khi trở lại trường|Ghi nhận, báo cáo kịp thời dấu hiệu bệnh và hỗ trợ giáo viên.|Nhật ký, hồ sơ","B1.2|Truyền thông phòng dịch sau nghỉ|Thực hiện thông tin phòng bệnh phù hợp tình hình thực tế.|Tin bài, biên bản"],
["B4.2|Hướng dẫn vệ sinh, chăm sóc sức khỏe|Thực hiện nội dung tư vấn được phân công và ghi nhận kết quả.|Tài liệu, phản hồi","B2.2|Kiểm tra môi trường phòng bệnh|Phối hợp kiểm tra lớp, bếp và khu vệ sinh theo lịch.|Bảng kiểm"],
["B1.1|Rà soát đợt theo dõi sức khỏe cuối năm|Cập nhật đầy đủ các đợt khám, cân đo đến hạn.|Hồ sơ sức khỏe","B2.2|Phòng ngừa rủi ro mùa nóng|Truyền thông nước uống, hoạt động ngoài trời và an toàn trẻ.|Tài liệu, biên bản"],
["B1.1|Tổng hợp tình hình sức khỏe cuối năm học|Hoàn thành báo cáo kết quả chăm sóc sức khỏe theo kế hoạch.|Báo cáo, bảng thống kê","B2.3|Kiểm kê, bàn giao hồ sơ và vật tư|Hoàn thành nhiệm vụ kiểm kê, bàn giao theo phân công.|Biên bản"],
["B2.2|Theo dõi dịch bệnh hè nếu được giao|Thực hiện giám sát, báo cáo theo lịch phân công thực tế.|Nhật ký hè","B4.1|Phối hợp chăm sóc trẻ tham gia hoạt động hè|Hỗ trợ các tình huống sức khỏe trong phạm vi nhiệm vụ.|Sổ y tế, phân công"],
["B2.3|Rà soát bổ sung thuốc, vật tư|Tham mưu nhu cầu vật tư và kiểm tra hạn dùng.|Danh mục, đề xuất","B1.2|Chuẩn bị nội dung truyền thông năm mới|Xây dựng chủ đề truyền thông đầu năm theo phân công.|Dự thảo, kế hoạch"],
["B1.1|Chuẩn bị hồ sơ sức khỏe đầu năm mới|Cập nhật danh sách và biểu mẫu theo kế hoạch tuyển sinh.|Biểu mẫu, danh sách","B4.1|Thống nhất phối hợp y tế đầu năm|Hướng dẫn quy trình báo sức khỏe, sơ cứu, chuyển tuyến.|Biên bản, hướng dẫn"]
]},
{id:"KT",name:"Nhân viên kế toán",sheet:"KE_TOAN",base:[
"B1.1|Tiếp nhận, xử lý nghiệp vụ kế toán|Kiểm tra, ghi nhận đầy đủ chứng từ phát sinh hợp lệ thuộc trách nhiệm.|Chứng từ, sổ kế toán",
"B2.1|Kiểm tra tính chính xác, hợp lệ|Hạch toán đúng quy trình; phát hiện, sửa sai trước khi hoàn tất nghiệp vụ.|Sổ kế toán, kết quả kiểm tra",
"B2.2|Đối chiếu số liệu và công nợ|Đối chiếu với thủ quỹ, ngân hàng, các bộ phận theo lịch.|Biên bản đối chiếu",
"B2.3|Lưu trữ, công khai, bảo mật tài chính|Sắp xếp hồ sơ, bảo vệ thông tin và giải trình đúng thẩm quyền.|Hồ sơ lưu, báo cáo",
"B3.1/B3.2|Thực hiện công việc tài chính đúng hạn|Hoàn thành mốc báo cáo, phản hồi đề nghị thanh toán hợp lệ đúng thời hạn.|Lịch công việc, phiếu tiếp nhận",
"B4.1|Hướng dẫn bộ phận hoàn thiện hồ sơ|Phối hợp xử lý hồ sơ tài chính thuộc phạm vi được giao.|Danh sách, sổ giao việc"
],focus:[
["B1.2|Rà soát hồ sơ tài chính đầu năm|Tổng hợp công việc thu chi, dự toán đến kỳ, chế độ của trẻ.|Báo cáo, danh sách","B4.2|Chuẩn hóa biểu mẫu theo dõi|Áp dụng biểu mẫu thống nhất và lưu dữ liệu số theo phân công.|File, biểu mẫu"],
["B2.2|Đối chiếu công nợ và các khoản thu hợp lệ|Hoàn thành đối chiếu các mốc công việc được giao.|Biên bản đối chiếu","B1.2|Báo cáo thu chi tháng|Cung cấp số liệu tổng hợp chính xác, đúng hạn.|Báo cáo, bảng tổng hợp"],
["B4.1|Phối hợp thanh toán hoạt động được duyệt|Hướng dẫn chứng từ hợp lệ cho hoạt động, hội thi phát sinh nếu có.|Chứng từ, phiếu hướng dẫn","B2.3|Kiểm tra hồ sơ tài chính lưu trữ|Rà soát sắp xếp và bảo mật chứng từ đến kỳ.|Hồ sơ kiểm tra"],
["B1.2|Tổng hợp công việc cuối năm tài chính|Hoàn thành báo cáo, thống kê đến hạn theo quy định áp dụng.|Báo cáo, số liệu","B2.2|Đối chiếu các khoản tồn, tạm ứng|Rà soát và xử lý chênh lệch đúng thẩm quyền.|Biên bản"],
["B1.2|Chuẩn bị báo cáo, quyết toán đến kỳ|Xử lý các đầu việc tài chính theo lịch thực tế của đơn vị.|Hồ sơ báo cáo","B3.1|Rà soát thời hạn bắt buộc|Theo dõi, hoàn thành đầy đủ mốc nộp hồ sơ theo quy định.|Lịch, phiếu nộp"],
["B3.2|Tiếp nhận hồ sơ sau kỳ nghỉ|Giải quyết hoặc phản hồi đề nghị thanh toán hợp lệ đúng hạn.|Sổ tiếp nhận","B2.2|Kiểm tra đối chiếu sau nghỉ|Đối chiếu quỹ, ngân hàng và chứng từ theo thời điểm thực tế.|Biên bản"],
["B1.2|Tổng hợp báo cáo đến kỳ trong quý|Hoàn thành số liệu, dự toán, báo cáo theo lịch được giao.|Báo cáo","B4.2|Cải tiến bảng theo dõi chi phí|Thực hiện nội dung số hóa hoặc kiểm soát chi phí có sản phẩm.|Bảng tổng hợp, file"],
["B2.3|Rà soát hồ sơ công khai tài chính|Chuẩn bị hồ sơ, tài liệu đến kỳ thuộc trách nhiệm kế toán.|Báo cáo công khai","B4.1|Phối hợp hồ sơ phục vụ kiểm tra|Cung cấp chứng từ, giải trình đúng phạm vi được giao.|Danh mục hồ sơ"],
["B1.2|Tổng hợp tài chính cuối năm học|Chuẩn bị số liệu phục vụ báo cáo tổng kết, bàn giao.|Báo cáo, biên bản","B2.2|Kiểm tra tài sản, công nợ cuối năm học|Phối hợp kiểm kê, đối chiếu theo kế hoạch trường.|Biên bản"],
["B1.2|Theo dõi tài chính hoạt động hè nếu có|Cập nhật đầy đủ phát sinh hợp lệ theo phân công.|Sổ kế toán","B4.2|Rà soát dữ liệu và lưu trữ|Thực hiện sao lưu, chuẩn hóa bộ dữ liệu theo nhiệm vụ.|Hồ sơ số"],
["B1.2|Tham mưu dự toán năm học mới|Chuẩn bị bảng dự kiến nhu cầu kinh phí theo yêu cầu của đơn vị.|Bảng dự toán","B2.1|Kiểm soát hồ sơ mua sắm hợp lệ|Kiểm tra chứng từ thuộc trách nhiệm, không vượt thẩm quyền.|Hồ sơ kiểm tra"],
["B1.2|Chuẩn bị kế hoạch tài chính đầu năm|Tổng hợp các khoản thu chi được cấp có thẩm quyền cho phép.|Báo cáo, văn bản","B4.1|Hướng dẫn hồ sơ chính sách đầu năm|Phối hợp bộ phận rà soát hồ sơ chế độ trẻ, viên chức.|Danh sách, hồ sơ"]
]},
{id:"VT",name:"Nhân viên văn thư",sheet:"VAN_THU",base:[
"B1.1|Đăng ký, quản lý văn bản đến và đi|Tiếp nhận, phân phối và theo dõi đủ văn bản thuộc nhiệm vụ.|Sổ văn bản, phần mềm",
"B1.2|Phát hành, lập hồ sơ và số hóa|Hoàn thành nhiệm vụ phát hành, lưu trữ, số hóa được giao.|Danh mục hồ sơ",
"B2.1|Kiểm tra thể thức văn bản|Rà soát số hiệu, nơi nhận, thể thức và thông tin theo trách nhiệm.|Văn bản, phiếu kiểm tra",
"B2.2|Quản lý con dấu, chữ ký số|Sử dụng và bảo quản đúng quy trình, đúng phân quyền.|Sổ theo dõi, nhật ký",
"B2.3|Sắp xếp, tra cứu hồ sơ lưu|Phân loại, lưu giữ đủ tài liệu, bảo đảm tra cứu hợp lệ.|Hồ sơ lưu",
"B3.1/B3.2|Chuyển, phát hành, bàn giao đúng hạn|Ưu tiên văn bản khẩn; không để chậm việc do nguyên nhân chủ quan.|Nhật ký, sổ phát hành"
],focus:[
["B4.1|Phục vụ hồ sơ đầu năm học|Cung cấp văn bản, biểu mẫu cho các tổ theo phân công.|Phiếu giao nhận","B4.2|Chuẩn hóa danh mục hồ sơ năm học|Lập danh mục theo hướng dẫn nội bộ được giao.|Danh mục hồ sơ"],
["B2.3|Rà soát sắp xếp hồ sơ đang xử lý|Phân loại, bổ sung, phục vụ tra cứu đúng quy trình.|Hồ sơ kiểm tra","B4.1|Hỗ trợ văn bản triển khai chuyên đề|Phát hành, chuyển giao đầy đủ tài liệu hợp lệ.|Sổ phát hành"],
["B1.2|Chuẩn bị, phát hành văn bản sự kiện|Xử lý văn bản theo các hoạt động đã được duyệt, phân công.|Hồ sơ sự kiện","B4.2|Rà soát lưu trữ điện tử|Chuẩn hóa dữ liệu, đường dẫn tài liệu theo yêu cầu.|Danh mục số"],
["B2.3|Sắp xếp hồ sơ cuối năm dương lịch|Rà soát tài liệu đến hạn nộp lưu theo danh mục.|Biên bản, hồ sơ","B3.2|Bàn giao, nộp lưu đúng lịch|Hoàn thành bàn giao hồ sơ trong phạm vi trách nhiệm.|Phiếu giao nhận"],
["B2.2|Kiểm tra con dấu, chữ ký số trước nghỉ|Bảo đảm bảo quản, phân quyền và quy trình sử dụng.|Sổ, biên bản","B4.1|Phối hợp văn bản sơ kết học kỳ I|Cung cấp, phát hành hồ sơ đúng hạn.|Hồ sơ sơ kết"],
["B3.1|Xử lý văn bản đến sau kỳ nghỉ|Đăng ký và chuyển văn bản đúng thời hạn.|Sổ văn bản","B1.2|Hoàn thiện hồ sơ phát hành còn tồn hợp lệ|Rà soát, hoàn tất hồ sơ theo phân công.|Danh mục, sổ bàn giao"],
["B4.1|Phục vụ hoạt động chuyên môn tháng|Cung cấp kịp thời biểu mẫu, văn bản được yêu cầu.|Sổ yêu cầu","B4.2|Cải tiến tra cứu dữ liệu văn bản|Tạo hoặc áp dụng phương pháp tra cứu được chấp thuận.|Danh mục, kết quả"],
["B2.3|Rà soát hồ sơ chuẩn bị cuối năm học|Đối chiếu danh mục và tiến độ thu nhận hồ sơ.|Bảng theo dõi","B1.2|Số hóa các hồ sơ được phân công|Hoàn thành sản phẩm số hóa và lưu đúng nơi.|File, danh mục"],
["B1.2|Hoàn thiện văn bản tổng kết|Phát hành, lưu tài liệu tổng kết đúng thẩm quyền.|Hồ sơ phát hành","B3.2|Nộp lưu, bàn giao hồ sơ cuối năm|Giao đủ hồ sơ được phân công theo lịch.|Biên bản giao nhận"],
["B1.1|Theo dõi văn bản trong thời gian hè|Tiếp nhận, chuyển văn bản theo lịch trực và phân công.|Sổ văn bản","B2.3|Bảo quản kho hồ sơ mùa hè|Rà soát điều kiện lưu trữ, báo nguy cơ mất an toàn.|Bảng kiểm"],
["B4.1|Hỗ trợ hồ sơ tuyển sinh nếu được giao|Thực hiện tiếp nhận, chuyển giao giấy tờ đúng quy trình.|Sổ giao nhận","B4.2|Tối ưu biểu mẫu tiếp nhận hồ sơ|Sử dụng biểu mẫu thống nhất, bảo đảm dễ tra cứu.|Biểu mẫu, báo cáo"],
["B1.2|Phát hành văn bản đầu năm học mới|Hoàn thành các văn bản đã duyệt, đúng hạn.|Sổ phát hành","B2.3|Chuẩn bị danh mục hồ sơ năm học mới|Hoàn thiện danh mục, phân loại và bố trí hồ sơ.|Danh mục, bảng kiểm"]
]},
{id:"TQ",name:"Nhân viên thủ quỹ",sheet:"THU_QUY",base:[
"B1.1|Thực hiện thu, chi tiền mặt hợp lệ|Thực hiện đủ giao dịch theo chứng từ được phê duyệt, đúng thẩm quyền.|Phiếu thu, chi",
"B1.2|Cập nhật sổ quỹ, kiểm đếm, bàn giao|Ghi đầy đủ nghiệp vụ phát sinh, kiểm đếm theo quy trình.|Sổ quỹ, biên bản",
"B2.1|Bảo đảm khớp quỹ và an toàn tiền|Đối chiếu tiền thực tế, chứng từ, sổ quỹ; báo chênh lệch.|Biên bản kiểm kê",
"B2.2|Kiểm tra điều kiện chứng từ giao dịch|Thực hiện đủ ký nhận, giao nhận theo quy trình.|Chứng từ hợp lệ",
"B2.3|Bảo mật, lưu chứng từ và đối chiếu|Sắp xếp, bảo quản hồ sơ; đối chiếu với kế toán theo lịch.|Hồ sơ quỹ, bảng đối chiếu",
"B3.1/B3.2|Giao dịch, báo cáo, bàn giao đúng hạn|Hoàn tất giao dịch hợp lệ, sổ quỹ, báo cáo trong thời hạn được giao.|Sổ giao việc, biên bản"
],focus:[
["B4.1|Phối hợp thu, chi đầu năm học|Đối chiếu chứng từ với kế toán trước khi thực hiện giao dịch.|Phiếu, biên bản","B4.2|Chuẩn hóa mẫu kiểm đếm tiền mặt|Áp dụng biện pháp kiểm soát được phê duyệt.|Biểu mẫu, ghi nhận"],
["B2.3|Kiểm tra lưu trữ chứng từ phát sinh|Sắp xếp chứng từ và đối chiếu tồn quỹ theo lịch.|Sổ quỹ, tập chứng từ","B4.1|Phối hợp kế toán kiểm tra khoản thu hợp lệ|Thực hiện giao nhận chứng từ và số liệu kịp thời.|Biên bản"],
["B1.1|Thực hiện giao dịch hoạt động được duyệt|Chỉ thu, chi theo hồ sơ hợp lệ và phân công thực tế.|Chứng từ","B2.1|Đối chiếu tiền thực tế trong kỳ|Kiểm đếm, xác nhận tồn quỹ theo yêu cầu.|Biên bản"],
["B2.1|Kiểm kê quỹ cuối năm dương lịch|Đối chiếu quỹ và sổ sách tại thời điểm được giao.|Biên bản kiểm kê","B3.2|Hoàn tất bàn giao, đối chiếu cuối kỳ|Thực hiện đủ các mốc hoàn tất sổ quỹ.|Sổ quỹ, biên bản"],
["B2.3|Bảo quản quỹ trước kỳ nghỉ|Kiểm tra phương tiện bảo quản, chìa khóa và phân quyền.|Bảng kiểm","B3.1|Đảm bảo tiến độ giao dịch hợp lệ|Hoàn thành giao dịch đến hạn trước kỳ nghỉ theo phân công.|Phiếu giao dịch"],
["B2.1|Xác nhận tồn quỹ sau kỳ nghỉ|Kiểm đếm và đối chiếu với sổ quỹ đúng quy trình.|Biên bản","B4.1|Phối hợp xử lý giao dịch phát sinh|Bàn giao chứng từ với kế toán đúng thời hạn.|Sổ giao nhận"],
["B4.2|Rà soát nguy cơ sai sót sổ quỹ|Đề xuất cải tiến đối chiếu, phát hiện chênh lệch kịp thời.|Phiếu đề xuất","B2.3|Kiểm tra bảo mật chứng từ|Rà soát lưu trữ, phân quyền thông tin quỹ.|Hồ sơ kiểm tra"],
["B2.1|Đối chiếu quỹ trong quý|Hoàn thành kiểm đếm và xử lý số liệu theo quy trình.|Biên bản","B3.2|Hoàn thành sổ, báo cáo đúng hạn|Không để tồn đọng nhiệm vụ bàn giao, đối chiếu.|Sổ quỹ, báo cáo"],
["B1.2|Rà soát sổ quỹ cuối năm học|Cập nhật và đối chiếu đủ các giao dịch phát sinh.|Sổ quỹ","B4.1|Bàn giao hồ sơ theo phân công|Hoàn thành giao nhận đúng thẩm quyền.|Biên bản bàn giao"],
["B1.1|Thực hiện giao dịch hè nếu được giao|Chỉ thực hiện các khoản thu chi hợp lệ phát sinh.|Phiếu thu chi","B2.3|Bảo quản tiền và chứng từ mùa hè|Thực hiện kiểm tra quỹ, hồ sơ theo lịch trực.|Bảng kiểm"],
["B2.1|Kiểm tra quỹ và phương tiện bảo quản|Rà soát nguy cơ mất an toàn, báo kịp thời.|Bảng kiểm","B4.2|Cải tiến kiểm đếm, đối chiếu|Áp dụng một giải pháp được phê duyệt nếu có.|Ghi nhận, báo cáo"],
["B4.1|Phối hợp kế toán chuẩn bị đầu năm|Thống nhất lịch, biểu mẫu giao nhận chứng từ hợp lệ.|Lịch, biên bản","B1.1|Thu, chi hợp lệ đầu năm mới nếu được giao|Chỉ thực hiện khi có chứng từ và phê duyệt đúng quy định.|Chứng từ, sổ quỹ"]
]},
{id:"BV",name:"Nhân viên bảo vệ",sheet:"BAO_VE",base:[
"B1.1|Thực hiện ca trực theo phân công|Có mặt đầy đủ ca trực hợp lệ; bàn giao đúng quy trình.|Sổ trực, bảng phân công",
"B1.2|Kiểm tra cổng, tuần tra, tài sản|Thực hiện đầy đủ lượt kiểm tra, kiểm soát người ra vào.|Sổ trực, nhật ký tuần tra",
"B2.1|Kiểm soát cổng, phối hợp đón trả trẻ|Không để người lạ vào trường trái quy định; bảo đảm trật tự cổng.|Sổ khách, biên bản",
"B2.2|Kiểm tra PCCC và lối thoát hiểm|Kiểm tra đúng lịch, báo ngay nguy cơ liên quan khu vực phụ trách.|Bảng kiểm PCCC",
"B2.3|Kiểm tra khóa, điện, nước, khuôn viên|Kiểm tra đầy đủ điều kiện an toàn thuộc nhiệm vụ.|Phiếu kiểm tra",
"B3.1/B3.2|Báo cáo sự việc, bàn giao ca đúng hạn|Phản hồi tình huống đúng thời điểm; ghi sổ và bàn giao đúng hạn.|Nhật ký, biên bản"
],focus:[
["B4.1|Phân luồng đón, trả trẻ đầu năm|Phối hợp giáo viên bảo đảm trật tự, an toàn cổng.|Lịch trực, biên bản","B4.2|Đề xuất khắc phục điểm nguy cơ|Rà soát khu vực cổng, hàng rào và đề xuất sửa chữa.|Phiếu kiểm tra"],
["B2.2|Kiểm tra PCCC theo kế hoạch|Rà soát lối thoát hiểm, thiết bị và thông tin nguy cơ.|Bảng kiểm","B4.2|Kiểm tra hoạt động camera, khóa cửa|Ghi nhận hư hỏng và báo bộ phận phụ trách.|Nhật ký, phiếu báo"],
["B4.1|Bảo đảm an ninh sự kiện được giao|Phối hợp tổ chức trật tự theo lịch sự kiện thực tế.|Phiếu phân công","B2.1|Kiểm soát khách tăng cường|Thực hiện đúng quy trình ra vào trong ngày có hoạt động.|Sổ khách"],
["B2.3|Rà soát an toàn điện, nước, cửa|Kiểm tra trước nghỉ dài ngày, báo nguy cơ kịp thời.|Bảng kiểm","B4.2|Củng cố phương án bảo vệ tài sản|Thực hiện việc phòng ngừa mất mát theo phân công.|Nhật ký, biên bản"],
["B3.2|Bàn giao lịch trực trước kỳ nghỉ|Thực hiện đầy đủ bàn giao chìa khóa, tài sản, ca trực.|Sổ giao nhận","B2.2|Rà soát phòng cháy tại khu vực trọng yếu|Kiểm tra theo lịch, báo các điểm chưa bảo đảm.|Phiếu kiểm tra"],
["B1.1|Thực hiện lịch trực kỳ nghỉ nếu được giao|Đảm bảo trực, báo cáo và bàn giao theo phân công.|Bảng phân công","B2.1|Ổn định an ninh khi trẻ trở lại|Tăng cường kiểm soát cổng, khách và người lạ.|Sổ trực"],
["B4.1|Bảo đảm trật tự hoạt động tập thể|Phối hợp theo kế hoạch các hoạt động được duyệt.|Phân công, nhật ký","B2.3|Rà soát an toàn khuôn viên|Kiểm tra hư hỏng, vật sắc nhọn, khu vực nguy hiểm.|Bảng kiểm"],
["B2.3|Kiểm tra nguy cơ cây xanh, mưa giông|Báo cáo, khoanh vùng nguy hiểm trong phạm vi trách nhiệm.|Phiếu kiểm tra","B4.2|Đề xuất khắc phục khu vực mất an toàn|Ghi nhận nguy cơ và theo dõi kết quả sửa chữa.|Đề xuất, biên bản"],
["B2.3|Bàn giao, kiểm tra cơ sở vật chất cuối năm|Đối chiếu khóa, cửa, tài sản theo phân công.|Biên bản","B4.1|Phối hợp bảo đảm an ninh tổng kết|Hoàn thành nhiệm vụ trực, phân luồng khi có sự kiện.|Lịch sự kiện"],
["B1.1|Thực hiện ca trực hè được giao|Trực, bàn giao, kiểm tra tài sản đúng lịch.|Sổ trực hè","B2.3|Kiểm tra trường khi giảm hoạt động|Rà soát khóa, cửa, điện nước, tài sản theo kế hoạch.|Bảng kiểm"],
["B4.2|Theo dõi sửa chữa, bảo trì an ninh|Phối hợp kiểm tra hàng rào, cửa, khóa bị hư.|Phiếu báo hỏng","B2.2|Kiểm tra PCCC trong hè|Rà soát thiết bị, lối thoát hiểm theo lịch.|Bảng kiểm"],
["B2.1|Tăng cường kiểm soát cổng tuyển sinh|Hướng dẫn phụ huynh, khách đúng quy trình.|Sổ khách","B4.1|Phối hợp bảo đảm an ninh khai giảng|Chuẩn bị phương án cổng và phân luồng theo phân công.|Lịch phân công"]
]},
{id:"PV",name:"Nhân viên phục vụ, vệ sinh",sheet:"PHUC_VU",base:[
"B1.1|Vệ sinh khu vực, ca được phân công|Hoàn thành đủ khu vực và hạng mục vệ sinh theo lịch.|Bảng phân công, kiểm tra",
"B1.2|Thu gom rác, bổ sung vật tư|Hoàn thành nhiệm vụ thu gom, bổ sung vật tư, thu dọn đúng quy trình.|Danh mục công việc",
"B2.1|Bảo đảm chất lượng vệ sinh|Không để rác, nước đọng hoặc mất vệ sinh do bỏ sót nhiệm vụ.|Bảng kiểm thực tế",
"B2.2|Sử dụng hóa chất và dụng cụ an toàn|Dùng đúng hướng dẫn, bảo quản hóa chất ngoài tầm với trẻ.|Bảng kiểm an toàn",
"B2.3|Phân loại rác, phòng ngừa trơn trượt|Thực hiện đúng thu gom rác, cảnh báo sàn ướt và vệ sinh khu vực chung.|Biên bản kiểm tra",
"B3.1/B3.2|Vệ sinh đúng giờ, phản hồi nhiệm vụ phát sinh|Hoàn thành khu vực trước thời điểm sử dụng; phản hồi việc phát sinh đúng hạn.|Nhật ký, phiếu giao việc"
],focus:[
["B4.1|Tổng vệ sinh trước khi đón trẻ|Hoàn thành khu vực chung, lối đi, nhà vệ sinh theo lịch.|Bảng kiểm","B4.2|Rà soát và sắp xếp dụng cụ|Bố trí đúng nơi, đề xuất vật tư còn thiếu.|Danh mục, hình ảnh"],
["B2.3|Kiểm tra điểm dễ trơn trượt|Phòng ngừa nước đọng, lối đi trơn, điểm mất vệ sinh.|Bảng kiểm","B4.2|Thực hiện tiết kiệm vật tư|Áp dụng biện pháp tiết kiệm được giao.|Sổ vật tư"],
["B4.1|Phục vụ vệ sinh hoạt động sự kiện|Bảo đảm khu vực trước, trong, sau hoạt động theo phân công.|Phiếu giao việc","B2.1|Tăng cường vệ sinh khu vực công cộng|Thực hiện đủ lịch vệ sinh khi có đông người.|Bảng kiểm"],
["B1.2|Kiểm kê dụng cụ, vật tư cuối năm|Tổng hợp tình trạng dụng cụ theo phân công.|Biên bản","B4.2|Rà soát cải tiến thu gom rác|Đề xuất biện pháp bảo đảm sạch, gọn, an toàn.|Đề xuất, ghi nhận"],
["B2.2|Kiểm tra hóa chất, dụng cụ trước nghỉ|Khóa, cất giữ hóa chất và vật tư an toàn.|Bảng kiểm","B4.1|Phối hợp vệ sinh trước kỳ nghỉ|Hoàn thành tổng vệ sinh được phân công đúng thời điểm.|Phiếu giao việc"],
["B2.1|Tổng vệ sinh sau kỳ nghỉ|Vệ sinh các khu vực trước khi trẻ quay lại trường.|Bảng kiểm","B2.3|Phòng ngừa nước đọng, lây nhiễm|Kiểm tra nhà vệ sinh, hành lang, điểm rửa tay.|Nhật ký"],
["B4.1|Phục vụ hoạt động tập thể theo lịch|Chuẩn bị, thu dọn khu vực được phân công.|Phiếu giao việc","B4.2|Cải tiến bố trí dụng cụ vệ sinh|Áp dụng phương án bảo quản, sử dụng tiết kiệm.|Hình ảnh, báo cáo"],
["B2.3|Tăng cường vệ sinh, phòng muỗi|Kiểm tra khu vực nước đọng, thu gom rác theo quy trình.|Bảng kiểm","B2.2|Kiểm soát an toàn hóa chất|Rà soát bao bì, nơi cất, hướng dẫn sử dụng.|Phiếu kiểm tra"],
["B4.1|Vệ sinh, phục vụ tổng kết năm học|Hoàn thành các khu vực, hoạt động được giao.|Bảng kiểm, phân công","B1.2|Bàn giao, kiểm kê dụng cụ cuối năm|Ghi nhận tình trạng, đề xuất sửa hoặc thay.|Biên bản"],
["B1.1|Vệ sinh hè theo phân công|Hoàn thành các ca, khu vực được giao thực tế.|Lịch vệ sinh hè","B4.2|Bảo quản dụng cụ khi ít sử dụng|Kiểm tra, sắp xếp dụng cụ và vật tư an toàn.|Bảng kiểm"],
["B2.1|Tổng vệ sinh khu vực chờ bảo trì|Thực hiện vệ sinh theo phân công, không vào khu vực nguy hiểm.|Phiếu giao việc","B2.2|Rà soát hóa chất, vật tư phục vụ|Lập danh mục vật tư đến hạn thay thế.|Danh mục"],
["B4.1|Chuẩn bị môi trường đón trẻ năm mới|Vệ sinh, sắp xếp khu vực chung đúng lịch.|Bảng kiểm","B2.3|Kiểm tra lần cuối nguy cơ trơn trượt|Báo cáo và xử lý các vị trí có nguy cơ cho trẻ.|Biên bản, hình ảnh"]
]}
];
const parse=s=>{const a=s.split("|");return{code:a[0],task:a[1],target:a[2],proof:a[3]}};
function getTasks(role,index){return [...role.base,...role.focus[index]].map(parse);}
function e(s){return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");}
const letters="ABCDEFG";
const $role=root.querySelector("[data-role]");
const $month=root.querySelector("[data-month]");
roles.forEach(x=>{let el=document.createElement("option");el.value=x.id;el.textContent=x.name;$role.appendChild(el);});
months.forEach((x,i)=>{let el=document.createElement("option");el.value=String(i);el.textContent="Tháng "+x[0];$month.appendChild(el);});
$month.value="2";
function preview(){const role=roles.find(r=>r.id===$role.value)||roles[0],m=+$month.value;root.querySelector("[data-preview]").innerHTML='<div class="font-medium">'+e(role.name)+" – "+e(months[m][0])+'</div><div class="opacity-70">'+e(months[m][1])+'</div><div class="mt-2 space-y-1">'+getTasks(role,m).map((x,i)=>'<div><span class="opacity-60">'+(i+1)+'. ['+e(x.code)+']</span> '+e(x.task)+'</div>').join("")+'</div>';}
$role.addEventListener("change",preview);$month.addEventListener("change",preview);preview();
const u16=n=>[n&255,(n>>>8)&255],u32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255],enc=s=>new TextEncoder().encode(s);
function crc32(arr){let c=-1;for(const b of arr){c^=b;for(let i=0;i<8;i++)c=(c>>>1)^(0xEDB88320&-(c&1));}return(c^-1)>>>0;}
function zip(files){let local=[],central=[],offset=0;for(const [name,content] of files){const filename=enc(name),body=enc(content),crc=crc32(body);const lh=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(body.length),...u32(body.length),...u16(filename.length),...u16(0)]);local.push(lh,filename,body);const ch=new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(body.length),...u32(body.length),...u16(filename.length),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset)]);central.push(ch,filename);offset+=lh.length+filename.length+body.length;}const cs=central.reduce((n,x)=>n+x.length,0);const tail=new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(cs),...u32(offset),...u16(0)]);return new Blob([...local,...central,tail],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});}
function styles(){
const fonts=[
[10,false,"FF222222",false],[10,true,"FF173A59",false],[14,true,"FF173A59",false],
[9,true,"FFFFFFFF",false],[9,false,"FF536372",false],[9,true,"FF173A59",false],
[9,false,"FF455567",true],[9,false,"FF222222",false]
].map(f=>'<font><sz val="'+f[0]+'"/><name val="Times New Roman"/>'+(f[1]?'<b/>':'')+(f[3]?'<i/>':'')+'<color rgb="'+f[2]+'"/></font>').join("");
const fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>',...["FF173A59","FFE9F1F6","FFFFF7E8","FFF3F6F8"].map(c=>'<fill><patternFill patternType="solid"><fgColor rgb="'+c+'"/><bgColor indexed="64"/></patternFill></fill>')].join("");
const borders='<border><left/><right/><top/><bottom/><diagonal/></border>'+'<border><left style="thin"><color rgb="FFACBCC9"/></left><right style="thin"><color rgb="FFACBCC9"/></right><top style="thin"><color rgb="FFACBCC9"/></top><bottom style="thin"><color rgb="FFACBCC9"/></bottom><diagonal/></border>';
const specs=[
[0,0,0,"left"],[1,0,0,"left"],[2,0,0,"center"],[1,3,0,"left"],[6,0,0,"left"],
[3,2,0,"left"],[3,2,1,"center"],[7,0,1,"center"],[5,0,1,"center"],
[7,0,1,"left"],[7,0,1,"left"],[4,0,1,"left"],[7,4,1,"left"],[7,4,1,"center"],
[7,3,0,"left"],[6,0,0,"left"],[1,0,0,"center"],[7,0,0,"center"],
[1,5,0,"left"],[5,3,0,"left"]
];
const xfs=specs.map(s=>'<xf numFmtId="0" fontId="'+s[0]+'" fillId="'+s[1]+'" borderId="'+s[2]+'" xfId="0" applyAlignment="1"><alignment horizontal="'+s[3]+'" vertical="center" wrapText="1"/></xf>').join("");
return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="8">'+fonts+'</fonts><fills count="6">'+fills+'</fills><borders count="2">'+borders+'</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="'+specs.length+'">'+xfs+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
}
function cell(col,row,text,style){
const ref=letters[col]+row;
if(text===undefined||text===null||text==="")return '<c r="'+ref+'" s="'+style+'"/>';
return '<c r="'+ref+'" s="'+style+'" t="inlineStr"><is><t xml:space="preserve">'+e(text)+'</t></is></c>';
}
function rowSeg(number,height,seg,merge,ncols=7){
const cells=Array.from({length:ncols},()=>({v:"",s:0}));
for(const a of seg){for(let j=a.start;j<=a.end;j++)cells[j]={v:j===a.start?a.text:"",s:a.style};if(a.end>a.start)merge.push(letters[a.start]+number+":"+letters[a.end]+number);}
return '<row r="'+number+'" ht="'+height+'" customHeight="1">'+cells.map((x,i)=>cell(i,number,x.v,x.s)).join("")+'</row>';
}
function seg(start,end,text,style){return{start,end,text,style};}
function sheetXML(rows,merges,widths,opts={}){
const last=opts.last||rows.length,ncols=widths.length;
const cols=widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join("");
const mrg=merges.length?'<mergeCells count="'+merges.length+'">'+merges.map(x=>'<mergeCell ref="'+x+'"/>').join("")+'</mergeCells>':"";
const validation=opts.statusRanges&&opts.statusRanges.length?'<dataValidations count="1"><dataValidation type="list" allowBlank="1" showErrorMessage="1" errorTitle="Chọn trạng thái" error="Vui lòng chọn trạng thái trong danh sách." sqref="'+e(opts.statusRanges.join(" "))+'"><formula1>"Hoàn thành,Đang làm,Chưa thực hiện,Không phát sinh"</formula1></dataValidation></dataValidations>':"";
const br=opts.breaks&&opts.breaks.length?'<rowBreaks count="'+opts.breaks.length+'" manualBreakCount="'+opts.breaks.length+'">'+opts.breaks.map(id=>'<brk id="'+id+'" min="0" max="16383" man="1"/>').join("")+'</rowBreaks>':"";
const ori=opts.orientation||"landscape",height=opts.fitHeight===undefined?1:opts.fitHeight;
return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1" autoPageBreaks="0"/></sheetPr><dimension ref="A1:'+letters[ncols-1]+last+'"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>'+cols+'</cols><sheetData>'+rows.join("")+'</sheetData>'+mrg+validation+'<printOptions gridLines="0" headings="0" horizontalCentered="1"/><pageMargins left="0.24" right="0.24" top="0.28" bottom="0.30" header="0.12" footer="0.15"/><pageSetup paperSize="9" orientation="'+ori+'" fitToWidth="1" fitToHeight="'+height+'"/><headerFooter><oddFooter>&amp;CTrường Mầm non An Bình - Trang &amp;P / &amp;N</oddFooter></headerFooter>'+br+'</worksheet>';
}
function makeRoleSheet(role,monthIndexes){
let rr=[],merge=[],ranges=[],breaks=[];
for(let ii=0;ii<monthIndexes.length;ii++){
const mi=monthIndexes[ii],month=months[mi],ofs=ii*20,R=i=>ofs+i;
const note=mi>=9?"Tháng hè: chỉ thực hiện công việc được giao; nghỉ hợp lệ không bị trừ KPI.":"Đầu việc đề xuất: BGH giao số lượng, thời hạn cụ thể và xác nhận minh chứng đầu tháng.";
rr.push(rowSeg(R(1),18,[seg(0,6,"TRƯỜNG MẦM NON AN BÌNH  |  NĂM HỌC 2026–2027",1)],merge));
rr.push(rowSeg(R(2),27,[seg(0,6,"PHIẾU GIAO VIỆC VÀ THEO DÕI KPI – THÁNG "+month[0],2)],merge));
rr.push(rowSeg(R(3),22,[seg(0,2,"Vị trí: "+role.name,3),seg(3,4,"Tháng: "+month[0],3),seg(5,6,"A: 30đ  |  B: 70đ  |  Tổng: 100đ",3)],merge));
rr.push(rowSeg(R(4),18,[seg(0,6,note,4)],merge));
rr.push(rowSeg(R(5),18,[seg(0,6,"A. TIÊU CHÍ CHUNG – 30 ĐIỂM (THEO DÕI SUỐT THÁNG; GIỮ NGUYÊN QUY CHẾ)",5)],merge));
rr.push(rowSeg(R(6),20,[seg(0,3,"A1 (15đ): Đạo đức, chấp hành quy chế, trung thực, bảo mật.",14),seg(4,6,"A2 (7đ): Chủ động, đoàn kết, phối hợp công việc.",14)],merge));
rr.push(rowSeg(R(7),20,[seg(0,3,"A3 (4đ): Giờ giấc, tác phong và trách nhiệm bàn giao.",14),seg(4,6,"A4 (4đ): Tự học, cải tiến, CNTT phù hợp nhiệm vụ.",14)],merge));
rr.push(rowSeg(R(8),20,[seg(0,0,"STT",6),seg(1,1,"Mã KPI",6),seg(2,2,"Đầu việc cần thực hiện",6),seg(3,3,"Kết quả cần đạt",6),seg(4,4,"Minh chứng",6),seg(5,5,"Kết quả thực tế",6),seg(6,6,"Trạng thái",6)],merge));
const tasks=getTasks(role,mi);
tasks.forEach((x,k)=>rr.push(rowSeg(R(9+k),34,[seg(0,0,String(k+1),7),seg(1,1,x.code,8),seg(2,2,x.task,9),seg(3,3,x.target,10),seg(4,4,x.proof,11),seg(5,5,"",12),seg(6,6,"",13)],merge)));
rr.push(rowSeg(R(17),24,[seg(0,6,"NHIỆM VỤ PHÁT SINH: Chỉ ghi việc có phân công, sản phẩm và xác nhận; kết quả vượt kế hoạch không tự cộng điểm KPI.",15)],merge));
rr.push(rowSeg(R(18),26,[seg(0,6,role.id==="GV"?"HUY ĐỘNG TRẺ (nếu giao): Ghi theo nhà trẻ, 3, 4, 5 tuổi – Chưa đạt / Đạt / Vượt. Không chấm điểm riêng ngoài B1.4.":"GHI CHÚ: Không phát sinh hoặc không được giao không tự tính là chưa hoàn thành; nghỉ hợp lệ thực hiện theo Quy chế.",15)],merge));
rr.push(rowSeg(R(19),18,[seg(0,1,"NGƯỜI THỰC HIỆN",16),seg(2,4,"TỔ TRƯỞNG / NGƯỜI PHỤ TRÁCH",16),seg(5,6,"BAN GIÁM HIỆU",16)],merge));
rr.push(rowSeg(R(20),34,[seg(0,1,"(Ký, ghi rõ họ tên)",17),seg(2,4,"(Ký, ghi rõ họ tên)",17),seg(5,6,"(Ký, ghi rõ họ tên)",17)],merge));
ranges.push("G"+R(9)+":G"+R(16));
if(ii<monthIndexes.length-1)breaks.push(R(20));
}
return{xml:sheetXML(rr,merge,[6,14,34,43,30,23,19],{last:monthIndexes.length*20,breaks,statusRanges:ranges,fitHeight:monthIndexes.length===1?1:0}),area:"$A$1:$G$"+monthIndexes.length*20};
}
function makeGuide(){
let rr=[],m=[];const add=(n,h,t,s)=>rr.push(rowSeg(n,h,[seg(0,2,t,s)],m,3));
add(1,25,"TRƯỜNG MẦM NON AN BÌNH",1);
add(2,32,"HƯỚNG DẪN SỬ DỤNG BẢNG ĐẦU VIỆC KPI",2);
add(3,26,"Năm học 2026–2027 | Áp dụng theo Quy chế số 89/QĐ-MNAB",3);
const notes=[
"1. Cấu trúc Quy chế hiện hành: A – Tiêu chí chung 30 điểm; B – Kết quả thực hiện nhiệm vụ 70 điểm.",
"2. Mỗi tháng có một phiếu A4 ngang cho từng vị trí. Các đầu việc là nội dung đề xuất để giao và theo dõi, không phải điểm chấm mới.",
"3. Đầu tháng: Hiệu trưởng hoặc người được giao xác định nhiệm vụ, sản phẩm, thời hạn, chỉ tiêu và người phụ trách.",
"4. Trong tháng: Ghi kết quả thực tế tại cột màu vàng; chọn trạng thái Hoàn thành / Đang làm / Chưa thực hiện / Không phát sinh.",
"5. Cuối tháng: Đối chiếu minh chứng hiện có, chấm đúng các mã KPI và mức điểm trong Phụ lục I hoặc II của Quy chế.",
"6. Nhiệm vụ đột xuất chỉ áp dụng khi được giao. Thành tích vượt kế hoạch theo Điều 10 được theo dõi riêng, không cộng quá 100 điểm.",
"7. Huy động trẻ nhà trẻ và mẫu giáo 3, 4, 5 tuổi: ghi nhận Chưa đạt / Đạt / Vượt ở B1.4 nếu có giao nhiệm vụ; không chấm riêng.",
"8. Tháng 6–8/2027 là gợi ý công việc hè. Chỉ đánh giá công việc thực tế được phân công; không trừ KPI vì nghỉ hợp lệ.",
"9. Không tự động chấm 0 hay 100 điểm cho công việc không phát sinh hoặc tháng nghỉ trọn theo chế độ.",
"10. Khi in: chọn trang tính của vị trí, Print > A4 > Landscape. Mỗi trang là một tháng; có thể in trang 1–12 theo tháng.",
"11. Tab LICH_NAM giúp xem trọng tâm 12 tháng. Tab của từng vị trí có đủ 12 phiếu, có ngắt trang và phần ký.",
"12. CẦN RÀ SOÁT QUY CHẾ: B1.2 cấp dưỡng tối đa 8 điểm nhưng bản đính kèm ghi 9 điểm tại một mức chấm; cần đính chính trước khi áp dụng.",
"13. Phụ lục II hiện chưa có bảng điểm riêng cho nhân viên thư viện; vì vậy file không tự bổ sung điểm chấm cho vị trí này."
];
notes.forEach((t,i)=>add(i+4,37,t,i>=11?18:9));
add(17,25,"TÀI LIỆU HƯỚNG DẪN GIAO VIỆC – KHÔNG THAY THẾ QUY CHẾ ĐÃ BAN HÀNH",5);
return{xml:sheetXML(rr,m,[18,30,66],{orientation:"portrait",fitHeight:1,last:17}),area:"$A$1:$C$17"};
}
function makeYearOverview(which){
let rr=[],m=[];const upto=which||Array.from({length:12},(_,i)=>i);
rr.push(rowSeg(1,23,[seg(0,4,"TRƯỜNG MẦM NON AN BÌNH – KHUNG TRỌNG TÂM NĂM HỌC 2026–2027",1)],m,5));
rr.push(rowSeg(2,28,[seg(0,4,"LỊCH TRIỂN KHAI ĐẦU VIỆC KPI THEO THÁNG",2)],m,5));
rr.push(rowSeg(3,22,[seg(0,0,"Tháng",6),seg(1,1,"Trọng tâm chung",6),seg(2,2,"Giáo viên",6),seg(3,3,"Nhân viên",6),seg(4,4,"Lưu ý",6)],m,5));
for(let i=0;i<upto.length;i++){
const mi=upto[i],mon=months[mi],g=roles[0].focus[mi].map(s=>parse(s).task).join("; "),s=roles.slice(1).map(p=>p.focus[mi][0]&&parse(p.focus[mi][0]).task).slice(0,3).join("; ");
rr.push(rowSeg(i+4,38,[seg(0,0,mon[0],8),seg(1,1,mon[1],9),seg(2,2,g,10),seg(3,3,s,11),seg(4,4,mi>=9?"Theo phân công thực tế; không mặc nhiên chấm nhiệm vụ hè.":"Có thể điều chỉnh theo kế hoạch tháng của trường.",9)],m,5));
}
return{xml:sheetXML(rr,m,[13,37,55,68,43],{orientation:"landscape",fitHeight:1,last:upto.length+3}),area:"$A$1:$E$"+(upto.length+3)};
}
function makeWorkbook(sheets){
const ct=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'];
sheets.forEach((s,i)=>ct.push('<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'));ct.push('</Types>');
const wb='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'+sheets.map((s,i)=>'<sheet name="'+e(s.name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join("")+'</sheets><definedNames>'+sheets.map((s,i)=>'<definedName name="_xlnm.Print_Area" localSheetId="'+i+'">&apos;'+e(s.name)+'&apos;!'+s.area+'</definedName>').join("")+'</definedNames></workbook>';
const rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((s,i)=>'<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join("")+'<Relationship Id="rId'+(sheets.length+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
const files=[["[Content_Types].xml",ct.join("")],["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],["xl/workbook.xml",wb],["xl/_rels/workbook.xml.rels",rels],["xl/styles.xml",styles()]];
sheets.forEach((s,i)=>files.push(["xl/worksheets/sheet"+(i+1)+".xml",s.xml]));
return zip(files);
}
function run(mode){
const status=root.querySelector("[data-status]");
try{
status.textContent="Đang tạo các trang tính và kiểm tra dữ liệu...";
if(roles.length!==8||months.length!==12||roles.some(p=>p.base.length!==6||p.focus.length!==12||p.focus.some(x=>x.length!==2)))throw Error("Danh mục đầu việc không đầy đủ.");
const role=roles.find(x=>x.id===$role.value)||roles[0],mi=+$month.value;
let sheets=[],filename;
const allMonths=months.map((_,i)=>i);
if(mode==="one"){
sheets=[{name:"PHIEU_IN",...makeRoleSheet(role,[mi])},{name:"HUONG_DAN",...makeGuide()},{name:"LICH_NAM",...makeYearOverview([mi])}];
filename="MNAB_KPI_"+role.id+"_"+months[mi][0].replace("/","_")+"_A4.xlsx";
}else if(mode==="year"){
sheets=[{name:"HUONG_DAN",...makeGuide()},{name:"LICH_NAM",...makeYearOverview()},{name:role.sheet,...makeRoleSheet(role,allMonths)}];
filename="MNAB_KPI_12_thang_"+role.id+"_2026_2027.xlsx";
}else{
sheets=[{name:"HUONG_DAN",...makeGuide()},{name:"LICH_NAM",...makeYearOverview()},...roles.map(p=>({name:p.sheet,...makeRoleSheet(p,allMonths)}))];
filename="MNAB_KPI_Dau_viec_toan_truong_2026_2027.xlsx";
}
const blob=makeWorkbook(sheets);
const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();
status.textContent="Đã gửi yêu cầu tải "+filename+". Mở bằng Excel và kiểm tra Print Preview trước khi in.";
setTimeout(()=>URL.revokeObjectURL(url),30000);
}catch(err){status.textContent="Chưa thể tạo file: "+String(err.message||err);}
}
root.querySelector("[data-single]").addEventListener("click",()=>run("one"));
root.querySelector("[data-year]").addEventListener("click",()=>run("year"));
root.querySelector("[data-all]").addEventListener("click",()=>run("all"));
})();
</script>

```

**Hướng dẫn in:** Mở file Excel, chọn trang tính theo chức danh → **File → Print → A4 → Landscape**. Với bản cả năm, mỗi trang in tương ứng một tháng; bạn chỉ cần chọn số trang muốn in.

⚠️ Tôi lưu ý thêm hai điểm để nhà trường hoàn thiện hồ sơ:

- Trong Phụ lục II, **B1.2 của nhân viên cấp dưỡng có điểm tối đa 8 nhưng mức hoàn thành 90% đến dưới 100% lại ghi 9 điểm**. Đây là điểm cần đính chính trước khi áp dụng chấm chính thức.
- Quy chế đính kèm chưa có bảng KPI riêng cho **nhân viên thư viện**, nên file này chỉ bao gồm các chức danh đã có tiêu chí trong Quy chế.

Các đầu việc theo tháng là **bản đề xuất để giao nhiệm vụ**, có thể điều chỉnh theo kế hoạch thực tế. Việc chấm điểm vẫn thực hiện đúng các mức điểm đã ban hành, không tự tăng hoặc phân bổ lại điểm KPI.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

Tôi đã lập cấu trúc phiếu in theo tháng: phần **A – 30 điểm** nhắc các yêu cầu chung, phần **B – 70 điểm** liệt kê đầu việc cụ thể của từng vị trí, có ô để ghi kết quả và minh chứng. Tôi cũng phát hiện một lỗi điểm trong phụ lục cấp dưỡng: **B1.2 tối đa 8 điểm nhưng một mức chấm lại ghi 9 điểm**; tôi sẽ giữ nguyên điểm gốc trong mẫu giao việc và đánh dấu để nhà trường đính chính trước khi chấm.

---

USER

File Excel bạn cho tôi tải về không mở được, bạn hãy tạo và gởi lại giúp tôi

---

ASSISTANT

Xin lỗi bạn vì file Excel trước không mở được. Tôi sẽ thay cách tạo file để khắc phục lỗi định dạng.

Bản tạo lại vẫn bám sát Quy chế của Trường Mầm non An Bình năm học **2026–2027**, gồm **giáo viên và 7 vị trí nhân viên**, với các đầu việc KPI từ tháng 9/2026 đến tháng 8/2027.

Tôi giữ nguyên cơ cấu **30 điểm tiêu chí chung + 70 điểm kết quả thực hiện nhiệm vụ**, bố trí từng phiếu trên **khổ A4 ngang**, có mã KPI, đầu việc, yêu cầu cần đạt, minh chứng, kết quả thực tế và phần ký xác nhận.

## Tải lại Excel KPI hằng tháng 2026–2027

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="mnab-xlsx-v2" class="w-full space-y-3">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="font-semibold">BẢNG GIAO VIỆC KPI HẰNG THÁNG</div>
    <div class="text-sm opacity-70">Trường Mầm non An Bình · Năm học 2026–2027 · A4 ngang · 100 điểm</div>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <label class="text-sm flex flex-col gap-1"><span class="font-medium">Chức danh</span><select data-role class="w-full rounded-lg border p-2 bg-transparent"></select></label>
      <label class="text-sm flex flex-col gap-1"><span class="font-medium">Tháng</span><select data-month class="w-full rounded-lg border p-2 bg-transparent"></select></label>
    </div>
    <div class="rounded-lg p-3 bg-black/5 dark:bg-white/5 text-sm space-y-1">
      <div class="font-medium" data-heading></div>
      <div class="opacity-75" data-focus></div>
      <div class="text-xs opacity-70 mt-1">Phiếu có 8 đầu việc cụ thể, các cột theo dõi kết quả và phần ký xác nhận.</div>
    </div>
    <button data-download="all" class="w-full rounded-lg bg-blue-700 text-white font-semibold py-3 px-3 cursor-pointer">Tải file Excel toàn trường (.xlsx)</button>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
      <button data-download="year" class="rounded-lg border p-3 font-medium cursor-pointer">Tải 12 tháng của vị trí</button>
      <button data-download="single" class="rounded-lg border p-3 font-medium cursor-pointer">Tải phiếu một tháng</button>
    </div>
    <p data-status role="status" class="text-xs opacity-75">Tệp sẽ được tạo trực tiếp trên thiết bị khi bạn nhấn nút tải.</p>
  </div>
  <div class="text-xs opacity-65">Bộ biểu mẫu dùng để giao việc và theo dõi; mức điểm chấm chính thức thực hiện theo Phụ lục I, II của Quy chế. Tháng hè áp dụng theo nhiệm vụ thực tế được giao.</div>
</div>
<script>
(function(){
const host=document.getElementById("mnab-xlsx-v2");if(!host||host.dataset.init)return;host.dataset.init="yes";
const mons=[
["09/2026","Ổn định đầu năm, chuẩn bị nề nếp"],
["10/2026","Rà soát nền nếp và chất lượng công việc"],
["11/2026","Thực hiện hoạt động chuyên môn, phong trào theo phân công"],
["12/2026","Rà soát hồ sơ, kết quả học kỳ I"],
["01/2027","Sơ kết và chuẩn bị an toàn trước kỳ nghỉ"],
["02/2027","Ổn định hoạt động sau kỳ nghỉ"],
["03/2027","Nâng cao chất lượng, thực hiện chuyên đề"],
["04/2027","Rà soát chất lượng, an toàn cuối năm học"],
["05/2027","Tổng kết, kiểm kê, bàn giao"],
["06/2027","Nhiệm vụ hè theo phân công"],
["07/2027","Tuyển sinh, rà soát chuẩn bị năm học mới"],
["08/2027","Chuẩn bị cơ sở vật chất và khai giảng"]
];
const raw=[
{
id:"GV",name:"Giáo viên",tab:"GIAO_VIEN",
base:[
"B1.1|Xây dựng kế hoạch giáo dục|Hoàn thành kế hoạch tháng, tuần và nhiệm vụ được giao đúng hạn.|Kế hoạch giáo dục",
"B1.2|Tổ chức hoạt động chăm sóc, giáo dục|Thực hiện đầy đủ hoạt động được phân công và kế hoạch đã duyệt.|Kế hoạch, kiểm tra thực tế",
"B1.3/B2.4|Hồ sơ lớp và theo dõi trẻ|Cập nhật hồ sơ, quan sát và đánh giá trẻ đúng thời điểm.|Hồ sơ lớp, theo dõi trẻ",
"B2.1|Bảo đảm an toàn thể chất và tinh thần|Đúng quy trình điểm danh, giám sát, đón trả; không bạo lực.|Bảng kiểm, sổ lớp",
"B2.2|Tổ chức ăn, ngủ và vệ sinh cho trẻ|Đúng quy trình chăm sóc, theo dõi tình trạng sức khỏe.|Kiểm tra ăn ngủ, vệ sinh",
"B2.3|Tổ chức giáo dục lấy trẻ làm trung tâm|Chuẩn bị học liệu, tương tác tích cực, hỗ trợ trẻ phù hợp.|Phiếu quan sát, giáo án",
"B3.1/B4.3|Nộp báo cáo và phối hợp cha mẹ trẻ|Hồ sơ đúng hạn, trao đổi thông tin hỗ trợ trẻ kịp thời.|Sổ liên lạc, báo cáo"
],
focus:[
"B1.4|Huy động trẻ đầu năm theo phân công|Đối chiếu chỉ tiêu nhà trẻ, 3, 4, 5 tuổi; ghi chưa đạt, đạt hoặc vượt.|Chỉ tiêu, danh sách trẻ",
"B4.1|Dự giờ, sinh hoạt chuyên môn|Tham gia và vận dụng nội dung chuyên môn được phân công.|Biên bản, sản phẩm",
"B3.3|Tham gia phong trào phát sinh|Hoàn thành phần việc, sản phẩm khi có nhiệm vụ hợp lệ.|Phân công, sản phẩm",
"B2.4|Tổng hợp kết quả theo dõi trẻ học kỳ I|Rà soát đánh giá, xác định nội dung hỗ trợ trẻ.|Phiếu theo dõi",
"B3.1|Hoàn thiện hồ sơ sơ kết|Nộp báo cáo, hồ sơ đến kỳ theo lịch của trường.|Báo cáo, sổ nhận",
"B1.4|Phối hợp vận động trẻ trở lại lớp|Theo dõi sĩ số và thực hiện chỉ tiêu huy động nếu được giao.|Danh sách, sổ chuyên cần",
"B4.1|Tham gia chuyên đề, chia sẻ kinh nghiệm|Thực hiện nội dung và sản phẩm chuyên môn được giao.|Biên bản, sản phẩm",
"B2.4|Đánh giá, hỗ trợ trẻ cuối năm học|Hoàn thành nội dung đánh giá trẻ đến kỳ.|Hồ sơ đánh giá",
"B1.3|Hoàn thành hồ sơ và bàn giao cuối năm|Nộp đủ hồ sơ, thực hiện bàn giao được phân công.|Hồ sơ, biên bản",
"B1.4|Thực hiện nhiệm vụ hè được giao|Chăm sóc trẻ hè hoặc hỗ trợ tuyển sinh nếu có phân công.|Lịch, giao việc",
"B1.4|Điều tra, vận động trẻ theo độ tuổi|Thực hiện phần việc huy động được giao, cập nhật số trẻ.|Danh sách, kết quả",
"B1.1|Xây dựng kế hoạch và môi trường năm mới|Chuẩn bị kế hoạch, học liệu, tiếp nhận nhóm lớp được giao.|Kế hoạch, bảng kiểm"
]
},
{
id:"CD",name:"Nhân viên cấp dưỡng",tab:"CAP_DUONG",
base:[
"B1.1|Thực hiện ca chế biến và bữa ăn|Thực hiện đủ ca, công đoạn, số suất theo phân công.|Lịch bếp",
"B1.2|Tiếp nhận và sơ chế thực phẩm|Giao nhận, sơ chế, chia suất và thu dọn đúng nhiệm vụ.|Phiếu giao nhận",
"B2.1|Thực hiện an toàn thực phẩm|Đúng bảo hộ, vệ sinh cá nhân, tách sống – chín.|Bảng kiểm ATTP",
"B2.2|Chế biến đúng thực đơn, định lượng|Thực đơn được duyệt, suất ăn đủ; kiểm thực, lưu mẫu đúng trách nhiệm.|Thực đơn, sổ kiểm thực",
"B2.3|Vệ sinh, khử khuẩn khu vực bếp|Dụng cụ, kho, khu chế biến và khu rác sạch, an toàn.|Sổ vệ sinh bếp",
"B3.1/B3.2|Bàn giao suất và hoàn tất hồ sơ đúng hạn|Không để chậm bữa ăn do lỗi cá nhân; ghi chép đúng thời điểm.|Lịch ăn, sổ giao nhận",
"B4.1/B4.2|Phối hợp, bảo quản, giảm hao hụt|Phối hợp lớp, y tế, tổ bếp; thực hiện biện pháp được giao.|Phiếu phối hợp"
],
focus:[
"B4.1|Ổn định quy trình phục vụ đầu năm|Thống nhất số suất, lịch giao thức ăn với các lớp.|Biên bản tổ bếp",
"B2.1|Rà soát phòng ngừa nhiễm chéo|Kiểm tra khu vực, dụng cụ và quy trình thao tác.|Bảng kiểm",
"B4.1|Phục vụ hoạt động có yêu cầu đặc biệt|Hoàn thành công đoạn được giao khi có hoạt động phát sinh.|Phiếu phân công",
"B4.2|Rà soát tình hình sử dụng nguyên liệu|Đánh giá hao hụt và thực hiện tiết kiệm hợp lệ.|Bảng theo dõi",
"B2.3|Vệ sinh, bảo quản thiết bị trước kỳ nghỉ|Kiểm tra điện, gas, thiết bị, khu vực bảo quản.|Bảng kiểm",
"B2.1|Rà soát nguyên liệu, thiết bị sau nghỉ|Kiểm tra chất lượng và hạn dùng trước phục vụ.|Phiếu kiểm tra",
"B4.2|Đề xuất cải tiến quy trình bếp|Có đề xuất và kết quả triển khai nếu được chấp thuận.|Phiếu đề xuất",
"B2.1|Kiểm soát an toàn thực phẩm mùa nóng|Kiểm tra việc bảo quản, chế biến và lưu mẫu.|Bảng kiểm",
"B2.3|Tổng vệ sinh, bàn giao bếp cuối năm|Vệ sinh và bàn giao dụng cụ được giao.|Biên bản",
"B1.1|Phục vụ ca bếp hè nếu được giao|Chế biến, bàn giao suất ăn hè theo thực tế.|Lịch trực bếp",
"B4.2|Rà soát nhu cầu sửa chữa dụng cụ|Lập danh sách thiết bị hỏng cần bảo trì.|Danh mục",
"B1.2|Chuẩn bị quy trình giao nhận đầu năm mới|Rà soát nhân lực, biểu mẫu, khu vực bảo quản.|Phân công, bảng kiểm"
]
},
{
id:"YT",name:"Nhân viên y tế",tab:"Y_TE",
base:[
"B1.1|Theo dõi và cập nhật sức khỏe trẻ|Thực hiện hoạt động theo dõi, cân đo đến kỳ theo kế hoạch.|Hồ sơ sức khỏe",
"B1.2|Thực hiện truyền thông sức khỏe|Triển khai nhiệm vụ tuyên truyền, phòng bệnh được giao.|Tài liệu, kế hoạch",
"B2.1|Sơ cứu, chăm sóc sức khỏe ban đầu|Đúng phạm vi chuyên môn, chuyển tuyến khi cần.|Sổ y tế",
"B2.2|Theo dõi nguy cơ dịch bệnh|Phát hiện, báo cáo, phối hợp xử lý nguy cơ kịp thời.|Nhật ký theo dõi",
"B2.3|Quản lý thuốc, vật tư và thông tin|Kiểm kê hạn dùng, bảo quản và bảo mật hồ sơ.|Sổ thuốc, sổ vật tư",
"B3.1/B3.2|Ứng phó, báo cáo kịp thời|Xử lý tình huống theo quy trình, báo cáo đúng lịch.|Sổ xử lý, báo cáo",
"B4.1/B4.2|Phối hợp giáo viên, gia đình và tổ bếp|Hướng dẫn phòng bệnh, vệ sinh và chăm sóc sức khỏe.|Biên bản, tài liệu"
],
focus:[
"B1.1|Rà soát hồ sơ sức khỏe đầu năm|Cập nhật thông tin trẻ mới và lịch theo dõi.|Danh sách sức khỏe",
"B1.1|Tổ chức cân đo theo lịch|Cập nhật số liệu các lớp trong đợt được giao.|Phiếu cân đo",
"B2.2|Giám sát bệnh truyền nhiễm theo mùa|Theo dõi, báo cáo dấu hiệu nghi ngờ đúng quy trình.|Nhật ký",
"B1.1|Tổng hợp sức khỏe học kỳ I|Hoàn thành dữ liệu, báo cáo đến hạn.|Báo cáo",
"B2.3|Rà soát thuốc và phòng y tế trước nghỉ|Kiểm tra điều kiện bảo quản và hạn sử dụng.|Bảng kiểm",
"B2.2|Theo dõi sức khỏe sau kỳ nghỉ|Phối hợp giáo viên phát hiện, xử lý kịp thời.|Nhật ký",
"B4.2|Hướng dẫn phòng bệnh cho trẻ và gia đình|Thực hiện nội dung tư vấn được giao.|Tài liệu",
"B1.1|Rà soát hồ sơ khám, cân đo cuối năm|Hoàn thiện đợt đánh giá đến hạn.|Hồ sơ sức khỏe",
"B1.1|Tổng hợp công tác y tế cuối năm|Hoàn thành báo cáo và kiểm kê được giao.|Báo cáo",
"B2.2|Theo dõi y tế hoạt động hè nếu được giao|Giám sát, hỗ trợ các tình huống phát sinh.|Sổ y tế",
"B2.3|Kiểm tra thuốc, thiết bị chuẩn bị năm mới|Đề xuất bổ sung vật tư hợp lệ.|Bảng kiểm",
"B4.1|Hướng dẫn quy trình chăm sóc đầu năm|Phối hợp giáo viên, nhân viên thống nhất xử trí ban đầu.|Tài liệu hướng dẫn"
]
},
{
id:"KT",name:"Nhân viên kế toán",tab:"KE_TOAN",
base:[
"B1.1|Tiếp nhận và xử lý chứng từ kế toán|Hoàn thành đầy đủ nghiệp vụ phát sinh hợp lệ được giao.|Chứng từ, sổ kế toán",
"B1.2|Lập báo cáo và bảng số liệu đến kỳ|Đầy đủ, chính xác, đúng lịch công việc tài chính.|Báo cáo, bảng tổng hợp",
"B2.1|Hạch toán và kiểm tra tính hợp lệ|Kiểm soát số liệu, chứng từ đúng quy trình.|Sổ sách kế toán",
"B2.2|Đối chiếu số liệu với các bộ phận|Đối chiếu thu, chi, ngân hàng, công nợ theo trách nhiệm.|Biên bản đối chiếu",
"B2.3|Lưu trữ và bảo mật thông tin tài chính|Đúng quy trình lưu trữ, công khai, giải trình.|Hồ sơ tài chính",
"B3.1/B3.2|Đáp ứng thời hạn xử lý tài chính|Nộp báo cáo, phản hồi đề nghị thanh toán hợp lệ đúng hạn.|Lịch, phiếu tiếp nhận",
"B4.1/B4.2|Hướng dẫn hồ sơ, thực hiện cải tiến|Hỗ trợ bộ phận và thực hiện nội dung số hóa được giao.|Hồ sơ, sản phẩm số"
],
focus:[
"B1.2|Rà soát hồ sơ tài chính đầu năm|Tổng hợp số liệu, chế độ và hồ sơ đến kỳ.|Bảng tổng hợp",
"B2.2|Đối chiếu khoản thu chi đầu năm|Hoàn tất đối chiếu theo lịch, xử lý chênh lệch.|Biên bản",
"B4.1|Hướng dẫn chứng từ hoạt động được duyệt|Hỗ trợ các bộ phận hoàn thiện hồ sơ hợp lệ.|Phiếu hướng dẫn",
"B1.2|Chuẩn bị báo cáo cuối năm dương lịch|Hoàn thành báo cáo, đối chiếu đến hạn.|Báo cáo",
"B3.1|Rà soát hạn nộp hồ sơ tài chính|Bám lịch báo cáo, chứng từ và hồ sơ bắt buộc.|Lịch công việc",
"B2.2|Đối chiếu số liệu sau kỳ nghỉ|Rà soát số dư và chứng từ trong phạm vi trách nhiệm.|Biên bản",
"B4.2|Cải tiến bảng theo dõi tài chính|Áp dụng biểu mẫu điện tử phù hợp.|Bảng số hóa",
"B2.3|Chuẩn bị hồ sơ công khai, kiểm tra|Hoàn thành danh mục tài liệu được yêu cầu.|Hồ sơ lưu",
"B1.2|Tổng hợp tài chính cuối năm học|Chuẩn bị số liệu tổng kết và bàn giao.|Báo cáo",
"B1.2|Theo dõi phát sinh tài chính hè nếu có|Ghi nhận nghiệp vụ hợp lệ theo phân công.|Sổ kế toán",
"B1.2|Tham mưu dự toán chuẩn bị năm mới|Lập bảng nhu cầu kinh phí được giao.|Dự thảo",
"B4.1|Hướng dẫn hồ sơ chế độ đầu năm|Phối hợp hoàn thiện hồ sơ trẻ, viên chức.|Danh sách, hồ sơ"
]
},
{
id:"VT",name:"Nhân viên văn thư",tab:"VAN_THU",
base:[
"B1.1|Quản lý văn bản đến và đi|Tiếp nhận, đăng ký, chuyển và theo dõi đầy đủ.|Sổ văn bản",
"B1.2|Phát hành, lập hồ sơ và số hóa|Thực hiện đủ việc được giao đúng trình tự.|Hồ sơ lưu",
"B2.1|Kiểm tra thể thức văn bản|Số hiệu, nơi nhận, thông tin, bảo mật đúng quy trình.|Phiếu kiểm tra",
"B2.2|Quản lý con dấu và chữ ký số|Đúng thẩm quyền và quy định bảo quản.|Nhật ký, sổ dấu",
"B2.3|Sắp xếp, lưu giữ và tra cứu hồ sơ|Lưu trữ đầy đủ, khoa học, có thể tra cứu.|Danh mục hồ sơ",
"B3.1/B3.2|Chuyển, phát hành, bàn giao đúng hạn|Ưu tiên văn bản khẩn; không chậm do nguyên nhân chủ quan.|Sổ phát hành",
"B4.1/B4.2|Hỗ trợ các tổ và cải tiến công việc|Cung cấp biểu mẫu, cập nhật danh mục, số hóa theo phân công.|Phiếu giao việc"
],
focus:[
"B4.1|Phục vụ văn bản và hồ sơ đầu năm|Cung cấp biểu mẫu, hỗ trợ các tổ theo yêu cầu.|Sổ giao nhận",
"B2.3|Rà soát danh mục hồ sơ năm học|Hoàn thiện danh mục, hồ sơ lưu theo nhiệm vụ.|Danh mục",
"B1.2|Phát hành văn bản hoạt động tháng|Đúng quy trình, thời điểm và thẩm quyền.|Sổ phát hành",
"B2.3|Rà soát tài liệu cuối năm dương lịch|Phân loại hồ sơ đến hạn lưu trữ.|Danh mục, biên bản",
"B2.2|Kiểm tra con dấu, chữ ký số trước kỳ nghỉ|Bảo quản đúng vị trí, phân quyền đúng quy định.|Bảng kiểm",
"B3.1|Xử lý văn bản sau kỳ nghỉ|Đăng ký, chuyển giao đầy đủ đúng hạn.|Nhật ký",
"B4.2|Cải tiến cách tra cứu tài liệu điện tử|Thực hiện sản phẩm số hóa hoặc danh mục được giao.|Danh mục số",
"B2.3|Rà soát tài liệu chuẩn bị cuối năm học|Đối chiếu hồ sơ sắp đến thời hạn nộp lưu.|Bảng theo dõi",
"B1.2|Phát hành và nộp lưu hồ sơ tổng kết|Thực hiện đúng phân công, lịch bàn giao.|Hồ sơ phát hành",
"B1.1|Theo dõi văn bản trong hè|Tiếp nhận và chuyển giao theo lịch phân công.|Nhật ký văn bản",
"B4.1|Hỗ trợ hồ sơ tuyển sinh nếu được giao|Thực hiện tiếp nhận, chuyển hồ sơ đúng quy trình.|Phiếu giao nhận",
"B1.2|Chuẩn bị văn bản, danh mục năm học mới|Hoàn thành phát hành và lưu trữ đúng thời hạn.|Danh mục, hồ sơ"
]
},
{
id:"TQ",name:"Nhân viên thủ quỹ",tab:"THU_QUY",
base:[
"B1.1|Thực hiện thu, chi tiền mặt hợp lệ|Giao dịch đúng phê duyệt, thẩm quyền, chứng từ.|Phiếu thu, chi",
"B1.2|Cập nhật sổ quỹ, kiểm đếm tiền|Ghi chép đầy đủ nghiệp vụ phát sinh, đúng thời điểm.|Sổ quỹ",
"B2.1|Đảm bảo số dư quỹ chính xác|Đối chiếu tiền thực tế với sổ và chứng từ.|Biên bản kiểm quỹ",
"B2.2|Kiểm tra điều kiện chứng từ giao dịch|Giao nhận, ký nhận đúng quy trình.|Chứng từ",
"B2.3|Bảo mật, lưu giữ chứng từ|Sắp xếp và bảo quản hồ sơ quỹ đúng quy định.|Hồ sơ lưu",
"B3.1/B3.2|Thực hiện giao dịch và báo cáo đúng hạn|Hoàn thành việc hợp lệ, đối chiếu, bàn giao đúng lịch.|Lịch, sổ quỹ",
"B4.1/B4.2|Phối hợp kế toán và cải tiến quản lý|Cung cấp số liệu, phát hiện chênh lệch, thực hiện cải tiến được giao.|Biên bản, ghi nhận"
],
focus:[
"B4.1|Phối hợp giao dịch đầu năm học|Thực hiện giao nhận hồ sơ, chứng từ với kế toán.|Biên bản",
"B2.3|Kiểm tra và sắp xếp chứng từ quỹ|Đối chiếu hồ sơ với sổ quỹ đến kỳ.|Sổ quỹ",
"B1.1|Thực hiện giao dịch hoạt động được duyệt|Chỉ giao dịch khi hồ sơ hợp lệ và được phê duyệt.|Chứng từ",
"B2.1|Kiểm kê quỹ cuối năm dương lịch|Đối chiếu và xác nhận số dư thực tế theo lịch.|Biên bản",
"B2.3|Kiểm tra an toàn quỹ trước kỳ nghỉ|Rà soát điều kiện bảo quản tiền, chìa khóa, chứng từ.|Bảng kiểm",
"B2.1|Đối chiếu quỹ sau kỳ nghỉ|Kiểm đếm, xác nhận số dư đúng quy trình.|Biên bản",
"B4.2|Rà soát biện pháp phòng ngừa sai lệch|Thực hiện cải tiến theo phân công và phê duyệt.|Phiếu đề xuất",
"B2.3|Kiểm tra bảo mật dữ liệu quỹ|Sắp xếp, bảo quản hồ sơ đúng phân quyền.|Bảng kiểm",
"B1.2|Tổng hợp sổ quỹ cuối năm học|Hoàn tất cập nhật và bàn giao được giao.|Sổ quỹ, biên bản",
"B1.1|Giao dịch phát sinh hè nếu có|Thực hiện đúng chứng từ, phê duyệt.|Phiếu thu, chi",
"B4.2|Rà soát quy trình kiểm đếm tiền mặt|Đề xuất điều chỉnh khi có khó khăn, rủi ro.|Biên bản",
"B4.1|Phối hợp chuẩn bị giao dịch đầu năm|Thống nhất lịch, biểu mẫu và trách nhiệm.|Lịch công tác"
]
},
{
id:"BV",name:"Nhân viên bảo vệ",tab:"BAO_VE",
base:[
"B1.1|Thực hiện các ca trực được giao|Có mặt và bàn giao theo lịch trực hợp lệ.|Sổ trực",
"B1.2|Tuần tra, kiểm tra cổng và tài sản|Thực hiện đủ lượt kiểm tra đã phân công.|Sổ tuần tra",
"B2.1|Kiểm soát cổng, người ra vào|Đúng quy trình; phối hợp an toàn đón, trả trẻ.|Sổ khách",
"B2.2|Kiểm tra PCCC, lối thoát hiểm|Đúng lịch; kịp thời báo nguy cơ.|Bảng kiểm PCCC",
"B2.3|Kiểm tra cửa, khóa, điện, nước|Phát hiện và báo hỏng, mất an toàn kịp thời.|Bảng kiểm",
"B3.1/B3.2|Báo cáo sự cố, bàn giao ca đúng hạn|Phản hồi nguy cơ ngay; ghi sổ đầy đủ.|Nhật ký, biên bản",
"B4.1/B4.2|Phối hợp và phòng ngừa nguy cơ|Hỗ trợ bộ phận, đề xuất biện pháp an ninh theo nhiệm vụ.|Phân công, kiến nghị"
],
focus:[
"B4.1|Phân luồng cổng trường đầu năm|Giữ trật tự khu vực đón, trả trẻ.|Lịch trực",
"B2.2|Rà soát an toàn phòng cháy|Kiểm tra theo lịch, báo vị trí có nguy cơ.|Bảng kiểm",
"B4.1|Bảo đảm an ninh sự kiện được giao|Hướng dẫn khách, kiểm soát khu vực hoạt động.|Phiếu phân công",
"B2.3|Kiểm tra cửa, khóa trước kỳ nghỉ|Ghi nhận và báo nguy cơ hư hỏng.|Bảng kiểm",
"B3.2|Hoàn thiện lịch trực và bàn giao trước nghỉ|Bàn giao tài sản, chìa khóa theo quy định.|Sổ bàn giao",
"B2.1|Ổn định an ninh khi trẻ trở lại trường|Kiểm soát khách, cổng và phương tiện.|Sổ trực",
"B2.3|Rà soát an toàn sân, khuôn viên|Báo vật nguy hiểm, hư hỏng, điểm rủi ro.|Bảng kiểm",
"B4.2|Theo dõi nguy cơ thời tiết, cây xanh|Cảnh báo và đề xuất khắc phục nguy cơ thuộc trách nhiệm.|Phiếu báo",
"B4.1|Phối hợp bảo đảm an ninh tổng kết|Thực hiện nhiệm vụ được giao khi có sự kiện.|Lịch phân công",
"B1.1|Trực và bảo vệ tài sản trong hè|Bảo đảm đúng lịch trực thực tế.|Sổ trực hè",
"B2.3|Theo dõi sửa chữa, bảo trì an ninh|Báo hỏng, kiểm tra thiết bị được giao.|Bảng kiểm",
"B2.1|Kiểm soát khách tuyển sinh đầu năm|Hướng dẫn phụ huynh ra vào đúng quy trình.|Sổ khách"
]
},
{
id:"PV",name:"Nhân viên phục vụ, vệ sinh",tab:"PHUC_VU",
base:[
"B1.1|Vệ sinh khu vực theo phân công|Hoàn thành đủ khu vực, hạng mục và ca được giao.|Lịch vệ sinh",
"B1.2|Thu gom rác và bổ sung vật tư|Thực hiện đầy đủ phần việc đúng quy trình.|Sổ công việc",
"B2.1|Bảo đảm chất lượng vệ sinh|Khu vực sạch, không còn rác và nước đọng do bỏ sót.|Bảng kiểm",
"B2.2|Sử dụng hóa chất an toàn|Cất giữ ngoài tầm với trẻ, đúng hướng dẫn.|Kiểm tra thực tế",
"B2.3|Thu gom, phân loại rác và chống trơn trượt|Đúng quy trình, có cảnh báo khi cần.|Bảng kiểm",
"B3.1/B3.2|Hoàn thành đúng giờ, xử lý việc phát sinh|Vệ sinh xong trước giờ sử dụng, phản hồi kịp thời.|Nhật ký",
"B4.1/B4.2|Phối hợp và tiết kiệm vật tư|Hỗ trợ bộ phận, bảo quản dụng cụ, giảm hao hụt hợp lý.|Sổ vật tư"
],
focus:[
"B4.1|Tổng vệ sinh chuẩn bị đón trẻ|Hoàn thành phòng, hành lang, nhà vệ sinh được giao.|Bảng kiểm",
"B2.3|Rà soát điểm dễ trơn trượt|Phát hiện, xử lý nước đọng, khu vực nguy hiểm.|Biên bản",
"B4.1|Phục vụ vệ sinh sự kiện được giao|Vệ sinh trước và sau hoạt động theo phân công.|Phiếu giao việc",
"B4.2|Kiểm kê dụng cụ, vật tư cuối kỳ|Tổng hợp số lượng, tình trạng sử dụng.|Sổ vật tư",
"B2.2|Bảo quản hóa chất, dụng cụ trước kỳ nghỉ|Khóa cất và bàn giao đúng quy định.|Bảng kiểm",
"B2.1|Tổng vệ sinh sau kỳ nghỉ|Hoàn thành khu vực trước khi trẻ đến trường.|Bảng kiểm",
"B4.2|Cải tiến bảo quản dụng cụ|Đề xuất, áp dụng phương án tiết kiệm phù hợp.|Phiếu đề xuất",
"B2.3|Phòng ngừa nước đọng và côn trùng|Kiểm tra khu vực chung theo lịch.|Bảng kiểm",
"B4.1|Phục vụ tổng kết, bàn giao cuối năm|Hoàn thành vệ sinh, kiểm kê được giao.|Biên bản",
"B1.1|Thực hiện lịch vệ sinh hè|Chỉ thực hiện nhiệm vụ được giao thực tế.|Lịch phân công",
"B1.2|Rà soát vật tư trước năm học mới|Thống kê vật tư cần bổ sung, dụng cụ hỏng.|Danh mục",
"B4.1|Vệ sinh, sắp xếp môi trường trước khai giảng|Hoàn thành khu vực chung đúng kế hoạch.|Bảng kiểm"
]
}
];
const parse=s=>{const p=s.split("|");return{code:p[0],task:p[1],target:p[2],proof:p[3]}};
const roles=raw.map(r=>({...r,base:r.base.map(parse),focus:r.focus.map(parse)}));
const re=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
const roleInput=host.querySelector("[data-role]"),monthInput=host.querySelector("[data-month]");
roles.forEach(r=>{const o=document.createElement("option");o.value=r.id;o.textContent=r.name;roleInput.appendChild(o)});
mons.forEach((m,i)=>{const o=document.createElement("option");o.value=i;o.textContent="Tháng "+m[0];monthInput.appendChild(o)});
monthInput.value="2";
function preview(){const r=roles.find(x=>x.id===roleInput.value)||roles[0],k=Number(monthInput.value);host.querySelector("[data-heading]").textContent=r.name+" · "+mons[k][0];host.querySelector("[data-focus]").textContent="Trọng tâm: "+r.focus[k].task+". "+mons[k][1]+"."}
roleInput.addEventListener("change",preview);monthInput.addEventListener("change",preview);preview();
function u16(a,n){a.push(n&255,(n>>>8)&255)}
function u32(a,n){a.push(n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255)}
function crc32(bytes){let c=0xFFFFFFFF;for(let j=0;j<bytes.length;j++){c^=bytes[j];for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xEDB88320:0)}return(c^0xFFFFFFFF)>>>0}
function makeZip(files){const encoder=new TextEncoder(),locals=[],centers=[];let offset=0;
for(const [name,xml] of files){const n=encoder.encode(name),d=encoder.encode(xml),crc=crc32(d);let l=[];u32(l,0x04034b50);u16(l,20);u16(l,0x0800);u16(l,0);u16(l,0);u16(l,0);u32(l,crc);u32(l,d.length);u32(l,d.length);u16(l,n.length);u16(l,0);let lh=new Uint8Array(l);locals.push(lh,n,d);
let c=[];u32(c,0x02014b50);u16(c,20);u16(c,20);u16(c,0x0800);u16(c,0);u16(c,0);u16(c,0);u32(c,crc);u32(c,d.length);u32(c,d.length);u16(c,n.length);u16(c,0);u16(c,0);u16(c,0);u16(c,0);u32(c,0);u32(c,offset);centers.push(new Uint8Array(c),n);offset+=lh.length+n.length+d.length}
const cSize=centers.reduce((a,b)=>a+b.length,0);let end=[];u32(end,0x06054b50);u16(end,0);u16(end,0);u16(end,files.length);u16(end,files.length);u32(end,cSize);u32(end,offset);u16(end,0);
return new Blob([...locals,...centers,new Uint8Array(end)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})}
function styleXML(){
const ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const fonts=['<font><sz val="9"/><name val="Times New Roman"/><color rgb="FF202E3A"/></font>','<font><sz val="10"/><b/><name val="Times New Roman"/><color rgb="FF163A59"/></font>','<font><sz val="14"/><b/><name val="Times New Roman"/><color rgb="FF163A59"/></font>','<font><sz val="9"/><b/><name val="Times New Roman"/><color rgb="FFFFFFFF"/></font>'];
const fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>',...["FF173B5D","FFE9F2F8","FFFFF2D5"].map(c=>'<fill><patternFill patternType="solid"><fgColor rgb="'+c+'"/><bgColor indexed="64"/></patternFill></fill>')];
const borders=['<border><left/><right/><top/><bottom/><diagonal/></border>','<border><left style="thin"><color rgb="FFB4C1CC"/></left><right style="thin"><color rgb="FFB4C1CC"/></right><top style="thin"><color rgb="FFB4C1CC"/></top><bottom style="thin"><color rgb="FFB4C1CC"/></bottom><diagonal/></border>'];
const defs=[[0,0,0,"left"],[1,0,0,"left"],[2,0,0,"center"],[3,2,0,"left"],[1,3,1,"left"],[3,2,1,"center"],[0,0,1,"left"],[0,0,1,"center"],[0,4,1,"left"],[0,4,1,"center"],[1,0,0,"center"],[0,3,0,"left"]];
const xfs=defs.map(x=>'<xf numFmtId="0" fontId="'+x[0]+'" fillId="'+x[1]+'" borderId="'+x[2]+'" xfId="0" applyAlignment="1"><alignment horizontal="'+x[3]+'" vertical="center" wrapText="1"/></xf>');
return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="'+ns+'"><fonts count="'+fonts.length+'">'+fonts.join("")+'</fonts><fills count="'+fills.length+'">'+fills.join("")+'</fills><borders count="'+borders.length+'">'+borders.join("")+'</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellStyleXfs><cellXfs count="'+defs.length+'">'+xfs.join("")+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'}
function RBuilder(){
const data=[],merges=[],letters="ABCDEFG";
function add(height,blocks){const row=data.length+1,a=Array.from({length:7},()=>({t:"",s:0}));for(const b of blocks){for(let j=b[0];j<=b[1];j++)a[j]={t:j===b[0]?b[2]:"",s:b[3]};if(b[1]>b[0])merges.push(letters[b[0]]+row+":"+letters[b[1]]+row)}
const cs=a.map((v,i)=>{const id=letters[i]+row;if(v.t==="")return '<c r="'+id+'" s="'+v.s+'"/>';return '<c r="'+id+'" s="'+v.s+'" t="inlineStr"><is><t xml:space="preserve">'+re(v.t)+'</t></is></c>'}).join("");
data.push('<row r="'+row+'" ht="'+height+'" customHeight="1">'+cs+'</row>');return row}
return{add,data,merges}}
const block=(a,b,t,s)=>[a,b,t,s];
function sheet(role,selected){
const x=RBuilder(),br=[],sq=[];
selected.forEach((mi,i)=>{
const start=x.data.length+1,mon=mons[mi],focus=role.focus[mi],tasks=[...role.base,focus];
x.add(19,[block(0,6,"UBND PHƯỜNG AN BÌNH  –  TRƯỜNG MẦM NON AN BÌNH",1)]);
x.add(28,[block(0,6,"PHIẾU GIAO VIỆC KPI THÁNG "+mon[0]+" | NĂM HỌC 2026–2027",2)]);
x.add(22,[block(0,2,"Vị trí: "+role.name,3),block(3,4,"Tháng: "+mon[0],3),block(5,6,"A: 30đ | B: 70đ | Tổng: 100đ",3)]);
x.add(19,[block(0,6,"Trọng tâm: "+mon[1]+". Các đầu việc được xác nhận theo phân công thực tế.",11)]);
x.add(20,[block(0,6,"A. TIÊU CHÍ CHUNG – 30 ĐIỂM (THEO DÕI HẰNG THÁNG)",4)]);
x.add(19,[block(0,3,"A1 – 15đ: Đạo đức, kỷ luật, trung thực, bảo mật.",11),block(4,6,"A2 – 7đ: Trách nhiệm, đoàn kết, phối hợp.",11)]);
x.add(19,[block(0,3,"A3 – 4đ: Giờ giấc, tác phong, lề lối làm việc.",11),block(4,6,"A4 – 4đ: Tự học, cải tiến, chuyển đổi số.",11)]);
x.add(20,[block(0,6,"B. KẾT QUẢ THỰC HIỆN NHIỆM VỤ – 70 ĐIỂM (MÃ KPI THEO QUY CHẾ)",4)]);
x.add(25,[block(0,0,"STT",5),block(1,1,"Mã KPI",5),block(2,2,"Đầu việc",5),block(3,3,"Kết quả cần đạt",5),block(4,4,"Minh chứng",5),block(5,5,"Kết quả thực tế",5),block(6,6,"Trạng thái",5)]);
tasks.forEach((t,k)=>x.add(33,[block(0,0,String(k+1),7),block(1,1,t.code,7),block(2,2,t.task,6),block(3,3,t.target,6),block(4,4,t.proof,6),block(5,5,"",8),block(6,6,"",9)]));
const note=role.id==="GV"?"HUY ĐỘNG TRẺ (nếu giao): nhà trẻ, 3, 4, 5 tuổi – ghi nhận Chưa đạt / Đạt / Vượt tại B1.4; không cộng điểm riêng.":"NHIỆM VỤ CHƯA PHÁT SINH: không tự động chấm 0 hoặc 100 điểm; căn cứ nhiệm vụ thực tế được giao.";
x.add(23,[block(0,6,note,11)]);
x.add(23,[block(0,6,"Hội thi/phong trào ngoài kế hoạch (nếu có): ghi nhận thành tích riêng; không cộng vượt tổng 100 điểm KPI.",11)]);
x.add(18,[block(0,1,"NGƯỜI THỰC HIỆN",10),block(2,4,"TỔ TRƯỞNG / NGƯỜI PHỤ TRÁCH",10),block(5,6,"BAN GIÁM HIỆU",10)]);
x.add(30,[block(0,1,"(Ký, ghi rõ họ tên)",10),block(2,4,"(Ký, ghi rõ họ tên)",10),block(5,6,"(Ký, ghi rõ họ tên)",10)]);
sq.push("G"+(start+9)+":G"+(start+16));if(i<selected.length-1)br.push(x.data.length);
});
return produceSheet(x,[6,14,34,44,25,26,18],br,sq,selected.length===1?1:0)}
function guide(){
const x=RBuilder();
x.add(24,[block(0,6,"TRƯỜNG MẦM NON AN BÌNH",1)]);
x.add(29,[block(0,6,"HƯỚNG DẪN SỬ DỤNG FILE KPI THEO THÁNG",2)]);
x.add(22,[block(0,6,"Năm học 2026–2027 | Khổ in: A4 ngang | Nguồn: Quy chế số 89/QĐ-MNAB",3)]);
const notes=[
"1. Cơ cấu điểm không đổi: A – Tiêu chí chung 30 điểm; B – Kết quả nhiệm vụ 70 điểm.",
"2. Mỗi chức danh có một trang tính. Mỗi cụm 21 dòng là phiếu một tháng, có ngắt trang khi in.",
"3. Đầu tháng: Ban giám hiệu xác nhận đầu việc, chỉ tiêu, thời hạn và trách nhiệm theo kế hoạch thực tế.",
"4. Trong tháng: Người thực hiện ghi kết quả, minh chứng tại cột màu vàng và chọn trạng thái.",
"5. Cuối tháng: Chấm điểm theo các mức ở Phụ lục I hoặc Phụ lục II; bảng này không tự tạo điểm mới.",
"6. Chỉ đánh giá nhiệm vụ được giao hợp lệ; tháng nghỉ trọn theo chế độ không tự động chấm 0 hoặc 100 điểm.",
"7. Với giáo viên, huy động trẻ là một căn cứ đánh giá B1.4; chỉ ghi Chưa đạt, Đạt, Vượt nếu có chỉ tiêu.",
"8. Nhiệm vụ hội thi, phong trào phát sinh được ghi nhận riêng theo Quy chế, không cộng quá 100 điểm KPI.",
"9. Công việc tháng 6, 7, 8 chỉ áp dụng cho người được phân công; không trừ điểm khi nghỉ hợp lệ.",
"10. Chọn File > Print, giấy A4, hướng ngang, vừa chiều rộng một trang; kiểm tra bản xem trước.",
"11. Lưu ý rà soát bản Quy chế: B1.2 cấp dưỡng tối đa 8 điểm nhưng một mức chấm ghi 9 điểm.",
"12. Bản Quy chế cung cấp chưa có phụ lục KPI riêng cho thư viện, nên không tạo thêm thang điểm vị trí này."
];
notes.forEach((t,i)=>x.add(31,[block(0,6,t,i>9?4:6)]));
x.add(24,[block(0,6,"ĐÂY LÀ BẢNG GIAO VIỆC MẪU; CHẤM KPI THEO QUY CHẾ CHÍNH THỨC.",4)]);
return produceSheet(x,[6,14,34,44,25,26,18],[],[],1)}
function produceSheet(x,widths,breaks,statusRanges,fitHeight){
const ns="http://schemas.openxmlformats.org/spreadsheetml/2006/main",last=x.data.length;
const cols=widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join("");
const merges=x.merges.length?'<mergeCells count="'+x.merges.length+'">'+x.merges.map(r=>'<mergeCell ref="'+r+'"/>').join("")+'</mergeCells>':"";
const val=statusRanges.length?'<dataValidations count="1"><dataValidation type="list" allowBlank="1" showDropDown="0" sqref="'+statusRanges.join(" ")+'"><formula1>"Hoàn thành,Đang thực hiện,Chưa đạt,Không phát sinh"</formula1></dataValidation></dataValidations>':"";
const rb=breaks.length?'<rowBreaks count="'+breaks.length+'" manualBreakCount="'+breaks.length+'">'+breaks.map(v=>'<brk id="'+v+'" min="0" max="16383" man="1"/>').join("")+'</rowBreaks>':"";
const xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="'+ns+'"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:G'+last+'"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>'+cols+'</cols><sheetData>'+x.data.join("")+'</sheetData>'+merges+val+'<printOptions gridLines="0" headings="0" horizontalCentered="1"/><pageMargins left="0.22" right="0.22" top="0.26" bottom="0.26" header="0.12" footer="0.12"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="'+fitHeight+'"/><headerFooter><oddFooter>&amp;CTrường Mầm non An Bình - Trang &amp;P</oddFooter></headerFooter>'+rb+'</worksheet>';
return{xml,last}}
function workbook(namedSheets){
const nsMain="http://schemas.openxmlformats.org/spreadsheetml/2006/main";
const ct=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'];
namedSheets.forEach((s,i)=>ct.push('<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'));ct.push('</Types>');
const wxml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="'+nsMain+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'+namedSheets.map((s,i)=>'<sheet name="'+re(s.name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join("")+'</sheets><definedNames>'+namedSheets.map((s,i)=>'<definedName name="_xlnm.Print_Area" localSheetId="'+i+'">&apos;'+re(s.name)+'&apos;!$A$1:$G

Sau khi tải, bạn mở bằng **Microsoft Excel**, chọn **File → Print** để xem trước bản in. Bản toàn trường được chia thành các trang tính theo chức danh, mỗi tháng có ngắt trang riêng để in A4 ngang.

Tôi đã bổ sung bước kiểm tra cấu trúc XML trước khi tải, nhưng chưa thể trực tiếp mở tệp bằng Microsoft Excel trong phiên này để xác nhận tương thích hoàn toàn.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.+s.last+'</definedName>').join("")+'</definedNames></workbook>';
const rootR='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
const wr='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+namedSheets.map((s,i)=>'<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join("")+'<Relationship Id="rId'+(namedSheets.length+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
const files=[["[Content_Types].xml",ct.join("")],["_rels/.rels",rootR],["xl/workbook.xml",wxml],["xl/_rels/workbook.xml.rels",wr],["xl/styles.xml",styleXML()]];
namedSheets.forEach((s,i)=>files.push(["xl/worksheets/sheet"+(i+1)+".xml",s.xml]));
const parser=new DOMParser();
for(const [name,content] of files){if(name.endsWith(".xml")||name.endsWith(".rels")||name==="[Content_Types].xml"){const parsed=parser.parseFromString(content,"application/xml");if(parsed.getElementsByTagName("parsererror").length){throw Error("Dữ liệu XML chưa hợp lệ: "+name)}}}
const blob=makeZip(files);
if(blob.size<4000)throw Error("Dung lượng tệp không hợp lệ.");
return blob}
function download(mode){
const status=host.querySelector("[data-status]");
try{
if(roles.length!==8||mons.length!==12||roles.some(r=>r.base.length!==7||r.focus.length!==12))throw Error("Thiếu dữ liệu đầu việc.");
status.textContent="Đang tạo tệp và kiểm tra cấu trúc XML...";
const role=roles.find(r=>r.id===roleInput.value)||roles[0],m=Number(monthInput.value),all=mons.map((_,i)=>i);
let sheets=[],fname="";
if(mode==="single"){sheets=[{name:"PHIEU_THANG",...sheet(role,[m])}];fname="MNAB_KPI_"+role.id+"_"+mons[m][0].replace("/","-")+"_A4.xlsx"}
else if(mode==="year"){sheets=[{name:"HUONG_DAN",...guide()},{name:role.tab,...sheet(role,all)}];fname="MNAB_KPI_12_thang_"+role.id+"_2026-2027.xlsx"}
else{sheets=[{name:"HUONG_DAN",...guide()},...roles.map(r=>({name:r.tab,...sheet(r,all)}))];fname="MNAB_KPI_TOAN_TRUONG_2026-2027.xlsx"}
const blob=workbook(sheets);
const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=fname;a.style.display="none";document.body.appendChild(a);a.click();a.remove();
status.textContent="Đã tạo tệp "+fname+" ("+Math.round(blob.size/1024)+" KB), kiểm tra cú pháp XML thành công. Kiểm tra Print Preview sau khi mở Excel.";
setTimeout(()=>URL.revokeObjectURL(url),60000);
}catch(err){status.textContent="Không thể tạo tệp: "+String(err.message||err)}}
host.querySelectorAll("[data-download]").forEach(b=>b.addEventListener("click",()=>download(b.dataset.download)));
})();
</script>

```

Sau khi tải, bạn mở bằng **Microsoft Excel**, chọn **File → Print** để xem trước bản in. Bản toàn trường được chia thành các trang tính theo chức danh, mỗi tháng có ngắt trang riêng để in A4 ngang.

Tôi đã bổ sung bước kiểm tra cấu trúc XML trước khi tải, nhưng chưa thể trực tiếp mở tệp bằng Microsoft Excel trong phiên này để xác nhận tương thích hoàn toàn.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

trong nội dung này lại chưa  thể  hiện được mức đạt theo KPI chuẩn. Bên cạnh đó phần tiêu chí chung lại chưa có các thang điểm cụ thể. bạn có thể thiết kế lại để dễ xác định được các mức theo KPI chính

---

ASSISTANT

Đúng, mẫu trước mới là **danh sách giao việc**, chưa phải **phiếu chấm KPI** vì thiếu các ngưỡng điểm để giáo viên tự đối chiếu. Tôi sẽ thiết kế lại theo hướng: mỗi dòng có **mã KPI, yêu cầu, đủ các mức điểm chuẩn, minh chứng, ô tự chấm và ô người đánh giá chấm**; cuối phiếu tự tổng hợp 30 điểm phần A, 70 điểm phần B và tổng 100 điểm.

---

ASSISTANT

## Mẫu chấm điểm mới sẽ thể hiện như sau

Ví dụ với **giáo viên tháng 11/2026**, các mức điểm được lấy từ Phụ lục I của Quy chế:

| Mã KPI | Điểm tối đa | Các mức điểm phải hiển thị |
|--------|--------|--------|
| **A1.1 – Đạo đức nhà giáo** | 6 | 6đ: Không vi phạm; 4đ: 1 sai sót nhẹ; 2đ: 2 sai sót nhẹ; 0đ: từ 3 sai sót hoặc vi phạm nghiêm trọng |
| **B1.4 – Nhiệm vụ khác, huy động trẻ** | 3 | 3đ: Hoàn thành 100%; 2đ: từ 90% đến dưới 100%; 1đ: từ 70% đến dưới 90%; 0đ: dưới 70% |
| **B2.3 – Tổ chức hoạt động giáo dục** | 8 | 8đ: đạt 9–10 chỉ báo; 6đ: đạt 7–8; 3đ: đạt 5–6; 0đ: đạt 0–4 |
| **B3.1 – Nộp hồ sơ đúng hạn** | 4 | 4đ: đúng hạn toàn bộ; 3đ: trễ 1 lần không quá 1 ngày; 1đ: trễ 2 lần hoặc 1 lần quá 1 ngày; 0đ: từ 3 lần trễ hoặc không nộp nhiệm vụ bắt buộc |

Mỗi dòng sẽ có ô **“Kết quả thực tế”, “Giáo viên tự chấm”, “Người đánh giá chấm”**. Như vậy, người chấm không phải mở Quy chế để tìm lại các ngưỡng điểm.

Tôi cũng sẽ tách bảng **giao đầu việc trong tháng** khỏi **phiếu chấm theo thang điểm chuẩn**, để giáo viên không nhầm giữa việc cần làm và tiêu chí dùng để chấm.

## 📊 Tải mẫu Excel KPI đã thiết kế lại

Mẫu mới tách thành **4 trang tính**: tiêu chí chung A (30 điểm), tiêu chí chuyên môn B (70 điểm), bảng giao việc tháng và bảng tổng hợp điểm. Trong phiếu chấm, mỗi tiêu chí có đầy đủ các mức điểm theo Quy chế và ô nhập điểm riêng cho người tự đánh giá, người đánh giá.

## Mẫu Excel chấm KPI theo thang điểm chuẩn

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="mnab-score-v3" class="w-full space-y-3">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="font-semibold">TRƯỜNG MẦM NON AN BÌNH</div>
    <div class="text-sm opacity-70">Phiếu giao việc và chấm KPI theo Quy chế năm học 2026–2027</div>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <label class="text-sm flex flex-col gap-1"><span class="font-medium">Chức danh</span><select data-role class="w-full rounded-lg border p-2 bg-transparent"></select></label>
      <label class="text-sm flex flex-col gap-1"><span class="font-medium">Tháng</span><select data-month class="w-full rounded-lg border p-2 bg-transparent"></select></label>
    </div>
    <div class="rounded-lg bg-black/5 dark:bg-white/5 p-3 space-y-2">
      <div class="font-medium" data-preview-title></div>
      <div class="grid grid-cols-3 gap-2 text-center">
        <div class="rounded-lg border p-2"><div class="text-lg font-semibold">30</div><div class="text-xs opacity-70">Điểm phần A</div></div>
        <div class="rounded-lg border p-2"><div class="text-lg font-semibold">70</div><div class="text-xs opacity-70">Điểm phần B</div></div>
        <div class="rounded-lg border p-2"><div class="text-lg font-semibold">100</div><div class="text-xs opacity-70">Tổng tối đa</div></div>
      </div>
      <div class="text-sm" data-preview-note></div>
    </div>
    <button data-export="one" class="w-full rounded-lg p-3 bg-blue-700 text-white font-semibold cursor-pointer">Tải phiếu KPI tháng đã chọn (.xlsx)</button>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
      <button data-export="year" class="rounded-lg border p-3 font-medium cursor-pointer">Tải 12 tháng của vị trí</button>
      <button data-export="school" class="rounded-lg border p-3 font-medium cursor-pointer">Tải 8 vị trí của tháng</button>
    </div>
    <div data-status class="text-xs opacity-70" role="status">Các ô chấm điểm được để trống, không tự gán điểm tối đa.</div>
  </div>
</div>
<script>
(function(){
const box=document.getElementById("mnab-score-v3");if(!box||box.dataset.ready)return;box.dataset.ready="yes";
const months=[["09","2026","Ổn định đầu năm"],["10","2026","Củng cố nề nếp"],["11","2026","Chuyên môn và phong trào"],["12","2026","Rà soát học kỳ I"],["01","2027","Sơ kết, chuẩn bị nghỉ Tết"],["02","2027","Ổn định sau kỳ nghỉ"],["03","2027","Chuyên đề, nâng cao chất lượng"],["04","2027","Đánh giá trẻ và an toàn cuối năm"],["05","2027","Tổng kết, bàn giao"],["06","2027","Nhiệm vụ hè theo phân công"],["07","2027","Tuyển sinh, chuẩn bị năm mới"],["08","2027","Chuẩn bị khai giảng"]];
const l=(v,t)=>[v,t];
const entry=(code,title,max,levels,proof)=>({code,title,max,levels,proof});
const pct=(a,b,c)=>[l(a,"Hoàn thành 100% nhiệm vụ hợp lệ"),l(b,"Từ 90% đến dưới 100%"),l(c,"Từ 70% đến dưới 90%"),l(0,"Dưới 70%")];
const q=(a,b,c)=>[l(a,"Thực hiện đúng, đầy đủ; không sai sót"),l(b,"1 sai sót nhẹ, đã khắc phục kịp thời"),l(c,"2 sai sót nhẹ, đã khắc phục"),l(0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh")];
const punctual4=[l(4,"100% công việc đúng hạn"),l(3,"1 lần chậm không quá 1 ngày"),l(1,"2 lần chậm hoặc 1 lần chậm quá 1 ngày"),l(0,"Từ 3 lần chậm hoặc không làm nhiệm vụ bắt buộc")];
const punctual6=[l(6,"100% công việc, báo cáo đúng hạn"),l(4,"1 lần chậm nhẹ không quá 1 ngày"),l(2,"2 lần chậm hoặc 1 lần chậm quá 1 ngày"),l(0,"Từ 3 lần chậm hoặc vi phạm thời hạn bắt buộc")];
const improve=[l(4,"Hoàn thành 100%, có minh chứng hiệu quả"),l(3,"Hoàn thành 100%, chưa đánh giá hiệu quả"),l(1,"Hoàn thành từ 70% đến dưới 100%"),l(0,"Dưới 70% hoặc không triển khai nhiệm vụ")];
const teacherA=[
entry("A1.1","Đạo đức nhà giáo, tôn trọng trẻ",6,[l(6,"Không vi phạm"),l(4,"1 sai sót giao tiếp nhẹ, khắc phục ngay"),l(2,"2 sai sót nhẹ"),l(0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng")],"Quan sát; biên bản; phản ánh xác minh"),
entry("A1.2","Chấp hành pháp luật, quy chế, nội quy",5,[l(5,"Không vi phạm"),l(4,"1 vi phạm nhẹ"),l(2,"2–3 vi phạm nhẹ (theo bản Quy chế)"),l(0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng")],"Kiểm tra nội bộ; biên bản"),
entry("A1.3","Trung thực hồ sơ, bảo mật thông tin trẻ",4,[l(4,"Đúng, đầy đủ"),l(3,"1 sai sót không cố ý, sửa ngay"),l(1,"2 sai sót"),l(0,"Từ 3 sai sót; cố ý sai lệch hoặc lộ thông tin")],"Hồ sơ; kết quả đối chiếu"),
entry("A2.1","Chủ động thực hiện nhiệm vụ",4,[l(4,"Chủ động, không phải nhắc"),l(3,"1 lần phải nhắc"),l(1,"2 lần phải nhắc"),l(0,"Từ 3 lần nhắc hoặc từ chối nhiệm vụ hợp lệ")],"Ghi nhận của tổ trưởng"),
entry("A2.2","Đoàn kết, hợp tác và hỗ trợ đồng nghiệp",3,[l(3,"Phối hợp đầy đủ"),l(2,"1 lần chưa phối hợp, phải nhắc"),l(1,"2 lần phải nhắc"),l(0,"Từ 3 lần hoặc gây mất đoàn kết được xác minh")],"Biên bản; kết quả phối hợp"),
entry("A3.1","Chấp hành giờ làm việc, nhận lớp, bàn giao",2,[l(2,"Đúng giờ; nghỉ hợp lệ không bị tính vi phạm"),l(1,"1 lần đi muộn, về sớm hoặc nghỉ không phép"),l(0,"Từ 2 lần vi phạm thời gian làm việc")],"Bảng công; lịch trực; biên bản"),
entry("A3.2","Trang phục, tác phong, giao tiếp",2,[l(2,"Thực hiện đúng"),l(1,"1 sai sót nhẹ, đã khắc phục"),l(0,"Từ 2 sai sót hoặc vi phạm nghiêm trọng")],"Kiểm tra thực tế"),
entry("A4.1","Tự học, bồi dưỡng và vận dụng",2,[l(2,"Có ít nhất 1 nội dung học được vận dụng"),l(1,"Có học, chưa có minh chứng vận dụng"),l(0,"Không có minh chứng theo yêu cầu")],"Sản phẩm bồi dưỡng"),
entry("A4.2","Ứng dụng CNTT, STEAM, AI hoặc cải tiến",2,[l(2,"Ít nhất 1 cải tiến được áp dụng, có hiệu quả"),l(1,"Có thử nghiệm, chưa đánh giá hiệu quả"),l(0,"Không có cải tiến được ghi nhận")],"Giáo án; học liệu; sản phẩm")
];
const staffA=teacherA.map(x=>({...x}));
staffA[0]={...staffA[0],title:"Trung thực, liêm chính; tôn trọng trẻ, đồng nghiệp, phụ huynh"};
staffA[1]={...staffA[1],title:"Chấp hành pháp luật, nội quy và quy trình nghiệp vụ"};
staffA[2]={...staffA[2],title:"Trung thực báo cáo, bảo mật, bảo vệ tài sản và dữ liệu"};
staffA[5]={...staffA[5],title:"Chấp hành giờ làm việc, lịch trực và bàn giao"};
staffA[6]={...staffA[6],title:"Trang phục, tác phong, giao tiếp theo vị trí"};
staffA[7]={...staffA[7],title:"Tự học, cập nhật nghiệp vụ và vận dụng"};
staffA[8]={...staffA[8],title:"Cải tiến thao tác, công nghệ hoặc biện pháp tiết kiệm"};
const teacherB=[
entry("B1.1","Xây dựng kế hoạch giáo dục tháng, tuần",5,pct(5,4,2),"Kế hoạch giáo dục; sổ chuyên môn"),
entry("B1.2","Tổ chức hoạt động chăm sóc, nuôi dưỡng, giáo dục",8,pct(8,6,3),"Kế hoạch; kiểm tra thực tế"),
entry("B1.3","Hồ sơ chuyên môn, hồ sơ lớp, thông tin trẻ",4,pct(4,3,1),"Hồ sơ chuyên môn; phiếu kiểm tra"),
entry("B1.4","Nhiệm vụ chung; vận động, huy động trẻ nếu được giao",3,pct(3,2,1),"Phân công; lịch trực; chỉ tiêu và kết quả huy động"),
entry("B2.1","An toàn thể chất, tinh thần; điểm danh, giám sát, đón trả",10,[l(10,"Không sai sót"),l(7,"1 sai sót thủ tục nhẹ, chưa nguy hiểm, sửa ngay"),l(3,"2 sai sót nhẹ, đã khắc phục"),l(0,"Từ 3 sai sót hoặc 1 vi phạm an toàn nghiêm trọng")],"Bảng kiểm an toàn; biên bản"),
entry("B2.2","Ăn, ngủ, vệ sinh, chăm sóc và theo dõi sức khỏe",7,[l(7,"Thực hiện đúng, không sai sót"),l(5,"1 sai sót nhẹ"),l(2,"2–3 sai sót nhẹ"),l(0,"Từ 4 sai sót hoặc vi phạm nghiêm trọng")],"Kiểm tra ăn, ngủ, vệ sinh"),
entry("B2.3","Giáo dục lấy trẻ làm trung tâm; STEAM phù hợp",8,[l(8,"Đạt 9–10/10 chỉ báo quan sát"),l(6,"Đạt 7–8/10 chỉ báo"),l(3,"Đạt 5–6/10 chỉ báo"),l(0,"Đạt 0–4/10 chỉ báo")],"Phiếu quan sát 2 lượt trong tháng"),
entry("B2.4","Theo dõi, đánh giá sự phát triển và hỗ trợ trẻ",5,pct(5,4,2),"Hồ sơ theo dõi; kế hoạch hỗ trợ"),
entry("B3.1","Nộp kế hoạch, hồ sơ, báo cáo đúng thời hạn",4,punctual4,"Lịch nộp; thời điểm tiếp nhận"),
entry("B3.2","Bảo đảm tiến độ hoạt động theo kế hoạch",4,[l(4,"100% đúng hạn"),l(3,"Từ 90% đến dưới 100%"),l(1,"Từ 70% đến dưới 90%"),l(0,"Dưới 70%")],"Kế hoạch; lịch công tác"),
entry("B3.3","Thực hiện nhiệm vụ đột xuất đúng hạn",2,[l(2,"Tất cả nhiệm vụ đúng hạn"),l(1,"1 nhiệm vụ trễ không quá 1 ngày"),l(0,"Từ 2 nhiệm vụ trễ hoặc không thực hiện hợp lệ")],"Phiếu giao việc; xác nhận"),
entry("B4.1","Sinh hoạt chuyên môn, bồi dưỡng, chia sẻ",4,[l(4,"Đủ buổi; có ý kiến, góp ý hoặc sản phẩm"),l(3,"Đủ buổi; chưa có minh chứng vận dụng"),l(1,"Tham gia từ 50% đến dưới 100%"),l(0,"Dưới 50% không có lý do chính đáng")],"Biên bản sinh hoạt; sản phẩm"),
entry("B4.2","Phối hợp giáo viên cùng lớp, nhân viên liên quan",3,pct(3,2,1),"Sổ bàn giao; kế hoạch phối hợp"),
entry("B4.3","Phối hợp cha mẹ trẻ, trao đổi và hỗ trợ trẻ",3,pct(3,2,1),"Sổ liên lạc; ghi nhận trao đổi")
];
const spec=[
{id:"CD",name:"Nhân viên cấp dưỡng",meta:[
["Ca chế biến, bữa ăn, công đoạn theo phân công","Lịch bếp; nhật ký"],
["Tiếp nhận thực phẩm, sơ chế, chia suất, thu dọn","Phiếu giao nhận"],
["Vệ sinh an toàn thực phẩm; bảo hộ, tách sống – chín","Bảng kiểm bếp"],
["Đúng thực đơn, định lượng; kiểm thực và lưu mẫu","Thực đơn; sổ kiểm thực"],
["Khử khuẩn, bảo quản nguyên liệu, dụng cụ; thu gom rác","Sổ vệ sinh"],
["Hoàn thành, bàn giao suất ăn đúng giờ","Sổ giao nhận"],
["Ghi kiểm thực, lưu mẫu và hồ sơ bếp đúng hạn","Sổ bếp"],
["Phối hợp giáo viên, y tế và tổ bếp","Phiếu giao việc"],
["Tiết kiệm nguyên liệu, bảo quản tài sản, cải tiến","Phiếu theo dõi"]
],focus:[
"B4.1|Ổn định giao suất ăn đầu năm|Hoàn thành lịch phối hợp với các lớp|Biên bản",
"B2.1|Rà soát phòng ngừa nhiễm chéo|Thực hiện đúng vệ sinh, bảo quản thực phẩm|Bảng kiểm",
"B4.1|Phục vụ hoạt động phát sinh được giao|Hoàn thành phần việc tổ bếp được phân công|Phiếu phân công",
"B4.2|Rà soát hao hụt và tiết kiệm nguyên liệu|Thực hiện biện pháp tiết kiệm hợp lệ|Phiếu theo dõi",
"B2.3|Vệ sinh, bảo quản bếp trước kỳ nghỉ|Hoàn thành kiểm tra điện, gas, dụng cụ|Bảng kiểm",
"B2.1|Rà soát thực phẩm và thiết bị sau kỳ nghỉ|Đảm bảo đủ điều kiện phục vụ an toàn|Phiếu kiểm tra",
"B4.2|Đề xuất cải tiến công đoạn chế biến|Có sản phẩm hoặc đề xuất được xem xét|Phiếu đề xuất",
"B2.1|Kiểm soát ATTP mùa nóng|Thực hiện đầy đủ kiểm tra bảo quản thực phẩm|Bảng kiểm",
"B2.3|Bàn giao dụng cụ, tổng vệ sinh cuối năm|Hoàn thành các nội dung được phân công|Biên bản",
"B1.1|Thực hiện ca bếp hè nếu được giao|Đủ ca và suất ăn thực tế theo phân công|Lịch bếp",
"B4.2|Rà soát thiết bị, vật tư bếp|Báo hỏng và đề xuất sửa chữa đúng hạn|Danh mục",
"B1.2|Chuẩn bị giao nhận thực phẩm đầu năm|Thống nhất biểu mẫu và công đoạn được giao|Biên bản"
]},
{id:"YT",name:"Nhân viên y tế",meta:[
["Theo dõi sức khỏe, cân đo và quản lý hồ sơ trẻ","Hồ sơ sức khỏe"],
["Truyền thông, kiểm tra vệ sinh, phòng dịch","Tài liệu; biên bản"],
["Sơ cứu, chăm sóc ban đầu, chuyển tuyến đúng thẩm quyền","Sổ y tế"],
["Phát hiện nguy cơ dịch bệnh và trẻ cần quan tâm","Nhật ký theo dõi"],
["Quản lý thuốc, vật tư, hạn dùng và hồ sơ y tế","Sổ thuốc; kiểm kê"],
["Tiếp nhận và xử lý tình huống sức khỏe khẩn cấp","Nhật ký xử lý"],
["Báo cáo y tế, tổng hợp sức khỏe đúng hạn","Báo cáo"],
["Phối hợp giáo viên, cha mẹ trẻ, tổ bếp, cơ sở y tế","Nhật ký phối hợp"],
["Hướng dẫn vệ sinh, chăm sóc sức khỏe, phòng bệnh","Tài liệu truyền thông"]
],focus:[
"B1.1|Cập nhật hồ sơ sức khỏe đầu năm|Đủ thông tin trẻ theo phân công|Danh sách",
"B1.1|Thực hiện đợt cân đo theo kế hoạch|Hoàn thành số lượt được giao|Phiếu cân đo",
"B2.2|Giám sát dịch bệnh theo mùa|Báo cáo dấu hiệu bất thường kịp thời|Nhật ký",
"B1.1|Tổng hợp hồ sơ sức khỏe học kỳ I|Hoàn thành báo cáo đến kỳ|Báo cáo",
"B2.3|Kiểm tra tủ thuốc trước kỳ nghỉ|Bảo quản an toàn, rà soát hạn dùng|Bảng kiểm",
"B2.2|Theo dõi sức khỏe sau nghỉ|Phối hợp nhận diện nguy cơ, phòng bệnh|Nhật ký",
"B4.2|Truyền thông phòng bệnh tháng|Hoàn thành tài liệu, hướng dẫn được giao|Tài liệu",
"B1.1|Rà soát đợt khám, cân đo cuối năm|Cập nhật đầy đủ hồ sơ đến kỳ|Hồ sơ",
"B1.1|Tổng hợp công tác y tế cuối năm|Báo cáo và bàn giao theo phân công|Báo cáo",
"B2.2|Theo dõi y tế hè nếu được giao|Giám sát, xử lý đúng phạm vi trách nhiệm|Sổ y tế",
"B2.3|Rà soát vật tư chuẩn bị năm mới|Đề xuất bổ sung theo nhu cầu thực tế|Danh mục",
"B4.1|Hướng dẫn phối hợp y tế đầu năm|Thống nhất quy trình và thông tin liên hệ|Biên bản"
]},
{id:"KT",name:"Nhân viên kế toán",meta:[
["Tiếp nhận, kiểm tra, xử lý chứng từ kế toán","Chứng từ; sổ kế toán"],
["Lập bảng tổng hợp, báo cáo, dự toán, quyết toán","Báo cáo tài chính"],
["Hạch toán chính xác, hợp pháp","Kết quả kiểm tra"],
["Đối chiếu với thủ quỹ, ngân hàng, các bộ phận","Biên bản đối chiếu"],
["Lưu trữ, bảo mật, công khai, giải trình tài chính","Hồ sơ lưu"],
["Hoàn thành chứng từ, báo cáo, mốc tài chính đúng hạn","Lịch báo cáo"],
["Phản hồi đề nghị thanh toán, điều chỉnh chứng từ","Phiếu tiếp nhận"],
["Hướng dẫn các bộ phận hoàn thiện hồ sơ tài chính","Danh sách phối hợp"],
["Số hóa, kiểm soát chi phí, sử dụng nguồn lực tiết kiệm","Sản phẩm số"]
],focus:[
"B1.2|Tổng hợp hồ sơ tài chính đầu năm|Đầy đủ số liệu đến kỳ|Báo cáo",
"B2.2|Đối chiếu thu chi đầu năm|Phát hiện, xử lý sai lệch đúng quy định|Biên bản",
"B4.1|Hướng dẫn chứng từ hoạt động phát sinh|Hồ sơ hợp lệ, đúng thẩm quyền|Phiếu hướng dẫn",
"B1.2|Tổng hợp số liệu cuối năm dương lịch|Hoàn thành mốc báo cáo bắt buộc|Báo cáo",
"B3.1|Rà soát hạn nộp hồ sơ tài chính|Đảm bảo đúng thời hạn được giao|Lịch",
"B2.2|Đối chiếu số liệu sau kỳ nghỉ|Đúng số dư và chứng từ|Biên bản",
"B4.2|Cải tiến bảng theo dõi tài chính|Có sản phẩm số được áp dụng|Bảng số",
"B2.3|Rà soát hồ sơ công khai tài chính|Hoàn thiện danh mục đến kỳ|Hồ sơ",
"B1.2|Tổng hợp tài chính cuối năm học|Đúng số liệu phục vụ tổng kết|Báo cáo",
"B1.1|Xử lý nghiệp vụ phát sinh hè|Đúng quy định và phân công|Chứng từ",
"B1.2|Chuẩn bị dự toán năm mới|Hoàn thành bảng đề xuất được giao|Dự toán",
"B4.1|Hướng dẫn hồ sơ chế độ đầu năm|Đúng hạn và đúng đối tượng|Danh sách"
]},
{id:"VT",name:"Nhân viên văn thư",meta:[
["Tiếp nhận, đăng ký và theo dõi văn bản đến, đi","Sổ văn bản"],
["Soạn thảo, phát hành, lập hồ sơ, số hóa theo phân công","Danh mục hồ sơ"],
["Kiểm tra thể thức, số hiệu, nơi nhận, bảo mật văn bản","Phiếu kiểm tra"],
["Quản lý con dấu, chữ ký số, văn bản điện tử","Nhật ký"],
["Sắp xếp, lập và lưu trữ tài liệu đúng quy trình","Hồ sơ lưu"],
["Chuyển văn bản và chỉ đạo đúng thời hạn","Thời điểm tiếp nhận"],
["Phát hành, nộp lưu, bàn giao hồ sơ đúng tiến độ","Sổ phát hành"],
["Phối hợp tổ, bộ phận cung cấp văn bản, biểu mẫu","Phiếu giao việc"],
["Cải tiến quản lý, số hóa và tra cứu tài liệu","Danh mục số"]
],focus:[
"B4.1|Phục vụ hồ sơ đầu năm|Cung cấp biểu mẫu kịp thời|Sổ giao nhận",
"B2.3|Rà soát danh mục hồ sơ|Sắp xếp và tra cứu đúng quy trình|Danh mục",
"B1.2|Phát hành văn bản hoạt động tháng|Đúng thể thức, đúng hạn|Sổ phát hành",
"B2.3|Sắp xếp hồ sơ cuối năm dương lịch|Đầy đủ tài liệu đến kỳ|Biên bản",
"B2.2|Kiểm tra an toàn con dấu, chữ ký số|Đúng phân quyền và quy trình|Bảng kiểm",
"B3.1|Tiếp nhận văn bản sau kỳ nghỉ|Chuyển giao không chậm trễ|Sổ văn bản",
"B4.2|Cải tiến tra cứu tài liệu điện tử|Có sản phẩm áp dụng được|Danh mục",
"B2.3|Rà soát hồ sơ cuối năm học|Đúng tiến độ lưu trữ|Danh mục",
"B1.2|Phát hành hồ sơ tổng kết|Đúng hạn, đúng thẩm quyền|Sổ phát hành",
"B1.1|Theo dõi văn bản hè|Đúng lịch phân công|Sổ văn bản",
"B4.1|Hỗ trợ hồ sơ tuyển sinh nếu được giao|Đúng quy trình tiếp nhận|Sổ giao nhận",
"B1.2|Chuẩn bị hồ sơ năm mới|Hoàn thành nhiệm vụ được giao|Danh mục"
]},
{id:"TQ",name:"Nhân viên thủ quỹ",meta:[
["Thực hiện nghiệp vụ thu, chi tiền mặt hợp lệ","Phiếu thu, chi"],
["Cập nhật sổ quỹ, kiểm đếm và bàn giao","Sổ quỹ"],
["Đối chiếu tiền thực tế với sổ và chứng từ; bảo quản quỹ","Biên bản kiểm kê"],
["Kiểm tra điều kiện chứng từ, giao nhận, ký nhận","Chứng từ"],
["Bảo mật, lưu chứng từ, đối chiếu với kế toán","Sổ đối chiếu"],
["Thực hiện giao dịch hợp lệ đúng hạn","Phiếu giao dịch"],
["Hoàn tất sổ quỹ, báo cáo, bàn giao đúng hạn","Sổ quỹ"],
["Phối hợp kế toán, BGH và bộ phận liên quan","Biên bản"],
["Kiểm soát, báo chênh lệch và cải tiến quản lý quỹ","Ghi nhận cải tiến"]
],focus:[
"B4.1|Phối hợp thu chi đầu năm|Đúng hồ sơ và thẩm quyền|Chứng từ",
"B2.3|Rà soát lưu trữ chứng từ|Khớp sổ và hồ sơ đến kỳ|Sổ quỹ",
"B1.1|Thực hiện giao dịch hoạt động được duyệt|Có đầy đủ chứng từ hợp lệ|Phiếu thu chi",
"B2.1|Kiểm kê quỹ cuối năm dương lịch|Đối chiếu số dư thực tế|Biên bản",
"B2.3|Bảo quản quỹ trước kỳ nghỉ|Đảm bảo an toàn tiền, hồ sơ|Bảng kiểm",
"B2.1|Kiểm đếm quỹ sau kỳ nghỉ|Số liệu khớp, sai lệch được báo cáo|Biên bản",
"B4.2|Cải tiến cách kiểm soát quỹ|Có biện pháp phù hợp được áp dụng|Đề xuất",
"B2.3|Kiểm tra bảo mật chứng từ|Đúng phân quyền|Bảng kiểm",
"B1.2|Hoàn tất sổ quỹ cuối năm học|Đúng thời hạn|Sổ quỹ",
"B1.1|Giao dịch hè nếu được giao|Đúng phê duyệt và chứng từ|Phiếu thu chi",
"B4.2|Rà soát phương án kiểm đếm|Phát hiện và phòng ngừa sai lệch|Bảng kiểm",
"B4.1|Phối hợp chuẩn bị đầu năm|Thống nhất lịch giao nhận|Biên bản"
]},
{id:"BV",name:"Nhân viên bảo vệ",meta:[
["Thực hiện đủ các ca trực theo phân công","Lịch trực"],
["Kiểm soát cổng, tuần tra, kiểm tra tài sản","Sổ trực"],
["Kiểm soát người ra vào, phối hợp đón trả trẻ","Sổ khách"],
["Kiểm tra PCCC, lối thoát hiểm, báo nguy cơ","Bảng kiểm PCCC"],
["Kiểm tra cửa, khóa, điện, nước, tài sản, khuôn viên","Phiếu kiểm tra"],
["Phát hiện, báo cáo nguy cơ an ninh, an toàn kịp thời","Nhật ký sự việc"],
["Kiểm tra cuối ca, ghi sổ, bàn giao đúng hạn","Sổ trực"],
["Phối hợp BGH, giáo viên và các bộ phận","Phiếu phân công"],
["Phòng ngừa nguy cơ, cải thiện an ninh, bảo vệ tài sản","Kiến nghị; kết quả xử lý"]
],focus:[
"B4.1|Phân luồng cổng trường đầu năm|Đảm bảo trật tự đón trả trẻ|Sổ trực",
"B2.2|Kiểm tra phòng cháy|Báo nguy cơ kịp thời|Bảng kiểm",
"B4.1|Bảo đảm an ninh hoạt động tháng|Thực hiện nhiệm vụ phát sinh hợp lệ|Phân công",
"B2.3|Rà soát cửa, khóa trước kỳ nghỉ|Đầy đủ, báo hỏng kịp thời|Bảng kiểm",
"B3.2|Bàn giao ca trực trước nghỉ|Đúng lịch và quy trình|Sổ bàn giao",
"B2.1|Ổn định an ninh khi trẻ trở lại|Kiểm soát cổng, khách đúng quy định|Sổ trực",
"B2.3|Rà soát an toàn sân trường|Báo nguy cơ mất an toàn|Bảng kiểm",
"B4.2|Theo dõi nguy cơ cây xanh, thời tiết|Phát hiện, báo cáo đúng trách nhiệm|Phiếu báo",
"B4.1|Đảm bảo an ninh hoạt động tổng kết|Hoàn thành nhiệm vụ được giao|Lịch trực",
"B1.1|Trực hè theo phân công|Đảm bảo an toàn tài sản|Sổ trực",
"B2.3|Kiểm tra khuôn viên và tài sản hè|Báo điểm nguy cơ|Bảng kiểm",
"B2.1|Kiểm soát người ra vào đợt tuyển sinh|Thực hiện đúng quy trình|Sổ khách"
]},
{id:"PV",name:"Nhân viên phục vụ, vệ sinh",meta:[
["Vệ sinh khu vực, ca và hạng mục được phân công","Lịch vệ sinh"],
["Thu gom rác, bổ sung vật tư, vệ sinh dụng cụ","Sổ công việc"],
["Đảm bảo khu vực sạch, không rác, nước đọng","Bảng kiểm"],
["Sử dụng hóa chất, dụng cụ đúng hướng dẫn an toàn","Phiếu kiểm tra"],
["Phân loại, thu gom rác; phòng ngừa trơn trượt","Biên bản"],
["Hoàn thành vệ sinh đúng thời điểm","Lịch vệ sinh"],
["Xử lý nhiệm vụ vệ sinh phát sinh đúng hạn","Phiếu giao việc"],
["Phối hợp chuẩn bị môi trường và khắc phục sự cố","Phân công"],
["Tiết kiệm vật tư, bảo quản dụng cụ, phòng nguy cơ","Sổ vật tư"]
],focus:[
"B4.1|Tổng vệ sinh chuẩn bị đón trẻ|Hoàn thành khu vực được phân công|Bảng kiểm",
"B2.3|Phòng ngừa điểm trơn trượt|Xử lý kịp thời vị trí có nguy cơ|Bảng kiểm",
"B4.1|Phục vụ vệ sinh hoạt động tháng|Đúng lịch phân công|Phiếu giao việc",
"B4.2|Kiểm kê dụng cụ, vật tư cuối kỳ|Báo thiếu, hư hỏng kịp thời|Sổ vật tư",
"B2.2|Bảo quản hóa chất trước kỳ nghỉ|Không để trẻ tiếp cận dụng cụ nguy hiểm|Bảng kiểm",
"B2.1|Tổng vệ sinh sau kỳ nghỉ|Hoàn thành trước khi trẻ đến lớp|Bảng kiểm",
"B4.2|Cải tiến bảo quản dụng cụ|Có phương án thực tế phù hợp|Phiếu đề xuất",
"B2.3|Rà soát điểm nước đọng, rác|Ngăn ngừa nguy cơ mất vệ sinh|Bảng kiểm",
"B4.1|Phục vụ vệ sinh tổng kết|Thực hiện nhiệm vụ được giao|Phân công",
"B1.1|Thực hiện vệ sinh hè theo phân công|Hoàn thành ca, khu vực được giao|Lịch vệ sinh",
"B1.2|Rà soát vật tư chuẩn bị năm mới|Đề xuất bổ sung hợp lý|Danh mục",
"B4.1|Chuẩn bị môi trường sạch trước khai giảng|Hoàn thành khu vực chung được giao|Bảng kiểm"
]}
];
const order=["B1.1","B1.2","B2.1","B2.2","B2.3","B3.1","B3.2","B4.1","B4.2"];
function staffBands(role,i){
if(i===0)return pct(12,9,5);
if(i===1){if(role.id==="CD")return[l(8,"Hoàn thành 100%"),l(9,"90%–<100%: bản gốc ghi 9đ, vượt tối đa 8đ!"),l(5,"70%–<90%"),l(0,"Dưới 70%")];return pct(8,6,3)}
if(i===2)return q(12,9,5);
if(i===3)return q(10,8,4);
if(i===4)return q(8,6,3);
if(i===5){
if(role.id==="CD")return[l(6,"100% bữa ăn bàn giao đúng giờ"),l(4,"1 lần chậm nhẹ, không ảnh hưởng giờ ăn"),l(2,"2 lần chậm nhẹ hoặc 1 lần ảnh hưởng lịch ăn"),l(0,"Từ 3 lần chậm hoặc có sai sót nghiêm trọng")];
if(role.id==="YT"||role.id==="BV")return[l(6,"Xử lý đúng thời điểm; không phát sinh thì sẵn sàng ứng phó"),l(4,"1 lần chậm báo cáo không khẩn cấp"),l(2,"2 lần chậm báo cáo không khẩn cấp"),l(0,"Chậm nghiêm trọng trong tình huống khẩn cấp hoặc từ 3 lần")];
return punctual6
}
if(i===6){if(role.id==="CD")return[l(4,"100% hồ sơ kiểm thực, lưu mẫu đúng hạn"),l(3,"1 lần chậm ghi chép thông thường ≤1 ngày"),l(1,"2 lần chậm hoặc 1 lần quá 1 ngày"),l(0,"Từ 3 lần chậm hoặc bỏ việc bắt buộc")];return punctual4}
if(i===7)return pct(6,4,2);
return improve
}
const positions=[{id:"GV",name:"Giáo viên",a:teacherA,b:teacherB,focus:[
"B1.4|Huy động trẻ theo chỉ tiêu đầu năm|Ghi chưa đạt, đạt, vượt theo từng độ tuổi|Chỉ tiêu; danh sách",
"B4.1|Tham gia sinh hoạt chuyên môn|Có ý kiến hoặc sản phẩm vận dụng|Biên bản",
"B3.3|Hoàn thành nhiệm vụ hội thi, phong trào phát sinh|Đúng phân công, có kết quả xác nhận|Sản phẩm; biên bản",
"B2.4|Rà soát đánh giá trẻ học kỳ I|Đầy đủ nội dung theo kế hoạch|Hồ sơ theo dõi",
"B3.1|Hoàn thành hồ sơ sơ kết|Đúng lịch, đầy đủ nội dung|Báo cáo",
"B1.4|Theo dõi sĩ số, huy động bổ sung khi được giao|Đối chiếu chỉ tiêu tháng|Danh sách",
"B4.1|Tham gia chuyên đề được phân công|Có nội dung, minh chứng vận dụng|Sản phẩm",
"B2.4|Rà soát, đánh giá trẻ cuối năm|Hoàn thành nội dung đến kỳ|Hồ sơ",
"B1.3|Hoàn thành hồ sơ, bàn giao cuối năm|Đủ và đúng hạn|Biên bản",
"B1.4|Thực hiện nhiệm vụ hè nếu được giao|Theo phân công thực tế|Lịch hè",
"B1.4|Điều tra và huy động trẻ theo độ tuổi|Ghi kết quả so với chỉ tiêu|Danh sách",
"B1.1|Chuẩn bị kế hoạch, môi trường năm mới|Hoàn thành hồ sơ được giao|Kế hoạch"
].map(s=>s.split("|"))},
...spec.map(r=>({...r,a:staffA,b:r.meta.map((v,i)=>entry(order[i],v[0],[12,8,12,10,8,6,4,6,4][i],staffBands(r,i),v[1])),focus:r.focus.map(s=>s.split("|"))}))];
const els={r:box.querySelector("[data-role]"),m:box.querySelector("[data-month]"),title:box.querySelector("[data-preview-title]"),note:box.querySelector("[data-preview-note]"),status:box.querySelector("[data-status]")};
positions.forEach(r=>{const o=document.createElement("option");o.value=r.id;o.textContent=r.name;els.r.appendChild(o)});
months.forEach((m,i)=>{const o=document.createElement("option");o.value=i;o.textContent="Tháng "+m[0]+"/"+m[1];els.m.appendChild(o)});
els.m.value="2";
function selected(){return positions.find(r=>r.id===els.r.value)||positions[0]}
function preview(){const r=selected(),m=Number(els.m.value);els.title.textContent=r.name+" · "+months[m][0]+"/"+months[m][1];els.note.textContent="Phiếu chấm có "+r.a.length+" tiêu chí phần A và "+r.b.length+" tiêu chí phần B. Đầu việc trọng tâm: "+r.focus[m][1]+"."}
els.r.addEventListener("change",preview);els.m.addEventListener("change",preview);preview();
const xmlEscape=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
function rowsBuilder(){
const rows=[],merges=[],validations=[];const cols="ABCDEFG";
function add(height,groups){const n=rows.length+1,slots=Array.from({length:7},()=>({value:"",style:0}));for(const g of groups){for(let j=g[0];j<=g[1];j++)slots[j]={value:j===g[0]?g[2]:"",style:g[3]};if(g[1]>g[0])merges.push(cols[g[0]]+n+":"+cols[g[1]]+n)}
let body=slots.map((v,i)=>{const c=cols[i]+n;if(v.value&&typeof v.value==="object"&&v.value.formula!==undefined)return'<c r="'+c+'" s="'+v.style+'"><f>'+xmlEscape(v.value.formula)+'</f><v></v></c>';
if(v.value&&typeof v.value==="object"&&v.value.num!==undefined)return'<c r="'+c+'" s="'+v.style+'" t="n"><v>'+v.value.num+'</v></c>';
if(v.value===""||v.value==null)return'<c r="'+c+'" s="'+v.style+'"/>';
return'<c r="'+c+'" s="'+v.style+'" t="inlineStr"><is><t xml:space="preserve">'+xmlEscape(v.value)+'</t></is></c>'}).join("");
rows.push('<row r="'+n+'" ht="'+height+'" customHeight="1">'+body+'</row>');return n}
return{rows,merges,validations,add,get length(){return rows.length}}}
const G=(i,j,t,s)=>[i,j,t,s];
function makeSheet(b,widths,opts={}){
const cols=widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join("");
const mrg=b.merges.length?'<mergeCells count="'+b.merges.length+'">'+b.merges.map(v=>'<mergeCell ref="'+v+'"/>').join("")+'</mergeCells>':"";
const dv=b.validations.length?'<dataValidations count="'+b.validations.length+'">'+b.validations.map(v=>'<dataValidation type="list" allowBlank="1" showErrorMessage="1" errorTitle="Điểm không hợp lệ" error="Chọn một mức điểm trong Quy chế." sqref="'+v.addr+'"><formula1>"'+v.options.join(",")+'"</formula1></dataValidation>').join("")+'</dataValidations>':"";
const breaks=(opts.breaks||[]).length?'<rowBreaks count="'+opts.breaks.length+'" manualBreakCount="'+opts.breaks.length+'">'+opts.breaks.map(n=>'<brk id="'+n+'" min="0" max="16383" man="1"/>').join("")+'</rowBreaks>':"";
const xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:G'+b.length+'"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>'+cols+'</cols><sheetData>'+b.rows.join("")+'</sheetData>'+mrg+dv+'<printOptions gridLines="0" headings="0" horizontalCentered="1"/><pageMargins left="0.22" right="0.22" top="0.27" bottom="0.27" header="0.12" footer="0.15"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="'+(opts.fitHeight===undefined?1:opts.fitHeight)+'"/><headerFooter><oddFooter>&amp;CTrường Mầm non An Bình – Trang &amp;P</oddFooter></headerFooter>'+breaks+'</worksheet>';
return{xml,last:b.length,repeat:!!opts.repeat}}
function makeScoring(role,m,part){
const data=part==="A"?role.a:role.b,b=rowsBuilder(),mon=months[m],isA=part==="A",sumMax=isA?30:70;
b.add(19,[G(0,6,"UBND PHƯỜNG AN BÌNH — TRƯỜNG MẦM NON AN BÌNH",1)]);
b.add(27,[G(0,6,"PHIẾU CHẤM KPI PHẦN "+part+" – THÁNG "+mon[0]+"/"+mon[1],2)]);
b.add(20,[G(0,3,"Chức danh: "+role.name,1),G(4,6,"Phần "+part+": tối đa "+sumMax+" điểm",1)]);
b.add(22,[G(0,6,"Người thực hiện: ...........................................  Tổ/Nhóm: ...........................................",10)]);
b.add(24,[G(0,0,"MÃ",4),G(1,1,"TIÊU CHÍ / MINH CHỨNG",4),G(2,2,"ĐIỂM\nTỐI ĐA",4),G(3,3,"CÁC MỨC ĐIỂM THEO QUY CHẾ",4),G(4,4,"KẾT QUẢ THỰC TẾ / MINH CHỨNG",4),G(5,5,"TỰ CHẤM",4),G(6,6,"NGƯỜI CHẤM",4)]);
b.add(20,[G(0,6,isA?"A. TIÊU CHÍ CHUNG – 30 ĐIỂM":"B. KẾT QUẢ THỰC HIỆN NHIỆM VỤ – 70 ĐIỂM",3)]);
const first=b.length+1;
data.forEach(d=>{
const levels=d.levels.map(k=>k[0]+" điểm: "+k[1]).join("\n");
const row=b.add(59,[G(0,0,d.code,6),G(1,1,d.title+"\nMC: "+d.proof,5),G(2,2,{num:d.max},7),G(3,3,levels,5),G(4,4,"",8),G(5,5,"",9),G(6,6,"",9)]);
if(!(role.id==="CD"&&part==="B"&&d.code==="B1.2"))b.validations.push({addr:"F"+row+" G"+row,options:d.levels.map(v=>v[0])})
});
const last=b.length,sub=b.add(26,[G(0,1,"TỔNG ĐIỂM PHẦN "+part,11),G(2,2,{num:sumMax},11),G(3,4,"Chỉ tổng hợp các mức đã nhập.",11),G(5,5,{formula:'IF(COUNT(F'+first+':F'+last+')=0,"",SUM(F'+first+':F'+last+'))'},11),G(6,6,{formula:'IF(COUNT(G'+first+':G'+last+')=0,"",SUM(G'+first+':G'+last+'))'},11)]);
let note="Không tự chấm tối đa cho nhiệm vụ không phát sinh. Điểm phải có minh chứng phù hợp; thực hiện đúng Quy chế.";
if(part==="A")note="Lưu ý A1.2: bản Quy chế có ngưỡng 3 sai sót nhẹ bị giao nhau giữa 2 điểm và 0 điểm; cần thống nhất cách áp dụng.";
if(part==="B"&&role.id==="CD")note="CẦN ĐÍNH CHÍNH B1.2 CẤP DƯỠNG: Mức 90%–<100% bản gốc ghi 9 điểm nhưng điểm tối đa chỉ 8; không tự dùng 9 điểm.";
if(part==="B"&&role.id==="GV")note="B1.4: Kết quả huy động trẻ (chưa đạt/đạt/vượt) chỉ là minh chứng của nhiệm vụ; không cộng điểm riêng.";
b.add(28,[G(0,6,note,10)]);
b.add(21,[G(0,2,"NGƯỜI TỰ ĐÁNH GIÁ",12),G(3,4,"TỔ TRƯỞNG / PHỤ TRÁCH",12),G(5,6,"NGƯỜI ĐÁNH GIÁ",12)]);
b.add(28,[G(0,2,"(Ký và ghi rõ họ tên)",12),G(3,4,"(Ký và ghi rõ họ tên)",12),G(5,6,"(Ký và ghi rõ họ tên)",12)]);
const opts={fitHeight:role.id==="GV"&&!isA?0:1,repeat:role.id==="GV"&&!isA,breaks:role.id==="GV"&&!isA?[first+7]:[]};
return{...makeSheet(b,[9,29,9,58,27,11,11],opts),first,last,subtotal:sub,count:data.length}}
function makeTasks(role,m){
const b=rowsBuilder(),mon=months[m];
b.add(19,[G(0,6,"TRƯỜNG MẦM NON AN BÌNH – NĂM HỌC 2026–2027",1)]);
b.add(27,[G(0,6,"BẢNG GIAO VÀ THEO DÕI ĐẦU VIỆC KPI THÁNG "+mon[0]+"/"+mon[1],2)]);
b.add(22,[G(0,3,"Chức danh: "+role.name,1),G(4,6,"Trọng tâm: "+mon[2],1)]);
b.add(22,[G(0,6,"Giao việc phải có kết quả cần đạt, thời hạn và trách nhiệm; các chỉ tiêu số lượng cụ thể do nhà trường xác nhận.",10)]);
b.add(23,[G(0,0,"STT",4),G(1,1,"MÃ KPI",4),G(2,2,"ĐẦU VIỆC",4),G(3,3,"KẾT QUẢ CẦN ĐẠT",4),G(4,4,"MINH CHỨNG",4),G(5,5,"HẠN HOÀN THÀNH",4),G(6,6,"KẾT QUẢ THỰC HIỆN",4)]);
const bases=role.id==="GV"?[
["B1.1","Xây dựng kế hoạch tháng, tuần","100% nội dung được giao","Kế hoạch"],
["B1.2","Tổ chức hoạt động chăm sóc, giáo dục","Đầy đủ theo kế hoạch, phù hợp độ tuổi","Hồ sơ, quan sát"],
["B2.1","Đảm bảo an toàn thể chất, tinh thần","Đúng quy trình, không sai sót","Bảng kiểm"],
["B2.2","Tổ chức ăn, ngủ và vệ sinh cho trẻ","Đúng chế độ, quy trình được giao","Sổ lớp"],
["B2.3","Giáo dục lấy trẻ làm trung tâm","Đạt yêu cầu phiếu quan sát","Phiếu quan sát"],
["B1.3/B2.4","Hồ sơ lớp và theo dõi, đánh giá trẻ","Đầy đủ, đúng hạn","Hồ sơ trẻ"],
["B4.2/B4.3","Phối hợp giáo viên, cha mẹ trẻ","Đúng trách nhiệm, kịp thời","Sổ liên lạc"]
]:role.b.slice(0,7).map(x=>[x.code,x.title,x.code.startsWith("B1")?"Hoàn thành 100% phần việc được giao":x.code.startsWith("B2")?"Đúng quy trình, an toàn, không sai sót":"Đúng hạn theo nhiệm vụ thực tế",x.proof]);
const all=[...bases,role.focus[m]];
all.forEach((r,i)=>b.add(40,[G(0,0,String(i+1),7),G(1,1,r[0],6),G(2,2,r[1],5),G(3,3,r[2],5),G(4,4,r[3],5),G(5,5,"",8),G(6,6,"",8)]));
b.add(23,[G(0,6,"Nhiệm vụ phong trào ngoài kế hoạch (nếu có): giao bổ sung và ghi thành tích riêng; không cộng vượt 100 điểm KPI.",10)]);
b.add(23,[G(0,6,role.id==="GV"?"Huy động trẻ: ghi chỉ tiêu tháng, số trẻ thực tế và mức chưa đạt/đạt/vượt khi có giao nhiệm vụ B1.4.":"Nhiệm vụ không phát sinh hoặc nghỉ hợp lệ: xử lý theo Quy chế; không tự xác định 0 điểm.",10)]);
b.add(19,[G(0,2,"NGƯỜI THỰC HIỆN",12),G(3,4,"NGƯỜI PHỤ TRÁCH",12),G(5,6,"BAN GIÁM HIỆU",12)]);
b.add(31,[G(0,2,"(Ký, ghi rõ họ tên)",12),G(3,4,"(Ký, ghi rõ họ tên)",12),G(5,6,"(Ký, ghi rõ họ tên)",12)]);
return makeSheet(b,[7,13,39,42,25,18,29],{fitHeight:1})}
function makeSummary(role,m,aName,bName,sa,sb){
const x=rowsBuilder(),mon=months[m];x.add(20,[G(0,6,"TRƯỜNG MẦM NON AN BÌNH – NĂM HỌC 2026–2027",1)]);
x.add(29,[G(0,6,"BẢNG TỔNG HỢP ĐIỂM KPI THÁNG "+mon[0]+"/"+mon[1],2)]);
x.add(24,[G(0,6,"Chức danh: "+role.name+"  |  Người được đánh giá: ................................................................",1)]);
x.add(22,[G(0,6,"Chỉ nhập điểm theo từng tiêu chí trong hai tab A và B. Bảng này tự tổng hợp khi mở bằng Excel.",10)]);
x.add(25,[G(0,2,"NHÓM TIÊU CHÍ",4),G(3,4,"ĐIỂM TỐI ĐA",4),G(5,5,"TỰ CHẤM",4),G(6,6,"NGƯỜI CHẤM",4)]);
x.add(29,[G(0,2,"A. Tiêu chí chung",5),G(3,4,{num:30},7),G(5,5,{formula:'IF(\''+aName+'\'!F'+sa.subtotal+'="","",\''+aName+'\'!F'+sa.subtotal+')'},11),G(6,6,{formula:'IF(\''+aName+'\'!G'+sa.subtotal+'="","",\''+aName+'\'!G'+sa.subtotal+')'},11)]);
x.add(29,[G(0,2,"B. Kết quả thực hiện nhiệm vụ",5),G(3,4,{num:70},7),G(5,5,{formula:'IF(\''+bName+'\'!F'+sb.subtotal+'="","",\''+bName+'\'!F'+sb.subtotal+')'},11),G(6,6,{formula:'IF(\''+bName+'\'!G'+sb.subtotal+'="","",\''+bName+'\'!G'+sb.subtotal+')'},11)]);
x.add(32,[G(0,2,"TỔNG CỘNG KPI",11),G(3,4,{num:100},11),G(5,5,{formula:'IF(COUNT(F6:F7)<2,"",SUM(F6:F7))'},11),G(6,6,{formula:'IF(COUNT(G6:G7)<2,"",SUM(G6:G7))'},11)]);
x.add(26,[G(0,4,"Tình trạng nhập điểm người đánh giá:",1),G(5,6,{formula:'IF(COUNT(\''+aName+'\'!G'+sa.first+':G'+sa.last+')+COUNT(\''+bName+'\'!G'+sb.first+':G'+sb.last+')='+ (sa.count+sb.count)+',"Đã đủ điểm","Chưa đủ điểm")'},11)]);
x.add(24,[G(0,6,"Các ngưỡng điểm: từ 90; từ 70 đến dưới 90; từ 50 đến dưới 70; dưới 50. Xếp loại chính thức phải đáp ứng thêm điều kiện của Quy chế và pháp luật.",10)]);
x.add(26,[G(0,6,"Nhận xét kết quả: ...............................................................................................................................",5)]);
x.add(26,[G(0,6,"Nội dung cần khắc phục: .........................................................................................................................",5)]);
x.add(24,[G(0,2,"NGƯỜI TỰ ĐÁNH GIÁ",12),G(3,4,"TỔ TRƯỞNG / PHỤ TRÁCH",12),G(5,6,"BAN GIÁM HIỆU",12)]);
x.add(43,[G(0,2,"(Ký, ghi rõ họ tên)",12),G(3,4,"(Ký, ghi rõ họ tên)",12),G(5,6,"(Ký, ghi rõ họ tên)",12)]);
return makeSheet(x,[9,22,15,22,22,17,19],{fitHeight:1})}
function styles(){
const fs=[
'<font><sz val="9"/><name val="Times New Roman"/><color rgb="FF283644"/></font>',
'<font><sz val="10"/><b/><name val="Times New Roman"/><color rgb="FF173957"/></font>',
'<font><sz val="14"/><b/><name val="Times New Roman"/><color rgb="FF173957"/></font>',
'<font><sz val="9"/><b/><name val="Times New Roman"/><color rgb="FFFFFFFF"/></font>',
'<font><sz val="9"/><i/><name val="Times New Roman"/><color rgb="FF4F6172"/></font>'];
const fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>',...["FF183B5D","FFEAF2F8","FFFFF3D5"].map(c=>'<fill><patternFill patternType="solid"><fgColor rgb="'+c+'"/><bgColor indexed="64"/></patternFill></fill>')];
const borders=['<border><left/><right/><top/><bottom/><diagonal/></border>','<border><left style="thin"><color rgb="FFBCC8D2"/></left><right style="thin"><color rgb="FFBCC8D2"/></right><top style="thin"><color rgb="FFBCC8D2"/></top><bottom style="thin"><color rgb="FFBCC8D2"/></bottom><diagonal/></border>'];
const defs=[[0,0,0,"left"],[1,0,0,"left"],[2,0,0,"center"],[3,2,0,"left"],[3,2,1,"center"],[0,0,1,"left"],[1,0,1,"center"],[0,0,1,"center"],[0,4,1,"left"],[0,4,1,"center"],[4,3,0,"left"],[1,3,1,"center"],[1,0,0,"center"]];
const xfs=defs.map(v=>'<xf numFmtId="0" fontId="'+v[0]+'" fillId="'+v[1]+'" borderId="'+v[2]+'" xfId="0" applyAlignment="1"><alignment horizontal="'+v[3]+'" vertical="center" wrapText="1"/></xf>');
return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="'+fs.length+'">'+fs.join("")+'</fonts><fills count="'+fills.length+'">'+fills.join("")+'</fills><borders count="'+borders.length+'">'+borders.join("")+'</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="'+defs.length+'">'+xfs.join("")+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'}
function workbook(sheets){
const ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const parts=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'];
sheets.forEach((s,i)=>parts.push('<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'));parts.push('</Types>');
let names=[];
sheets.forEach((s,i)=>{names.push('<definedName name="_xlnm.Print_Area" localSheetId="'+i+'">&apos;'+xmlEscape(s.name)+'&apos;!$A$1:$G

### Cách sử dụng

Sau khi tải, bạn mở file và sử dụng theo thứ tự: **Giao việc tháng → Chấm phần A → Chấm phần B → Xem tổng hợp**. Trong hai bảng chấm, chỉ cần nhập kết quả thực tế và chọn mức điểm phù hợp ở các ô màu vàng.

Tôi đã giữ nguyên các mức điểm của Quy chế nguồn. Riêng hai chỗ có dấu hiệu chưa thống nhất cần nhà trường xem xét trước khi áp dụng chính thức: **A1.2 có ngưỡng 3 sai sót nhẹ bị trùng giữa hai mức**, và **B1.2 cấp dưỡng ghi 9 điểm trong khi điểm tối đa là 8**. Mẫu không tự sửa hai mức này để tránh thay đổi Quy chế đã ban hành.

**Lưu ý:** File được tạo trực tiếp khi bạn nhấn nút tải và có bước kiểm tra cấu trúc dữ liệu. Tôi chưa có điều kiện kiểm chứng bằng cách mở trực tiếp trong Microsoft Excel trên thiết bị của bạn.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.+s.last+'</definedName>');
if(s.repeat)names.push('<definedName name="_xlnm.Print_Titles" localSheetId="'+i+'">&apos;'+xmlEscape(s.name)+'&apos;!$1:$5</definedName>')});
const wb='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="'+ns+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'+sheets.map((s,i)=>'<sheet name="'+xmlEscape(s.name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join("")+'</sheets><definedNames>'+names.join("")+'</definedNames><calcPr calcId="191029" calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>';
const rel='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((s,i)=>'<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join("")+'<Relationship Id="rId'+(sheets.length+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
const files=[["[Content_Types].xml",parts.join("")],["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],["xl/workbook.xml",wb],["xl/_rels/workbook.xml.rels",rel],["xl/styles.xml",styles()]];
sheets.forEach((s,i)=>files.push(["xl/worksheets/sheet"+(i+1)+".xml",s.xml]));
const parser=new DOMParser();for(const [name,data]of files){const p=parser.parseFromString(data,"application/xml");if(p.getElementsByTagName("parsererror").length)throw Error("Cấu trúc XML chưa hợp lệ: "+name)}
return zip(files)}
function put16(a,n){a.push(n&255,n>>>8&255)}
function put32(a,n){a.push(n&255,n>>>8&255,n>>>16&255,n>>>24&255)}
function crc(bytes){let c=0xffffffff;for(let j=0;j<bytes.length;j++){c^=bytes[j];for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0)}return(c^0xffffffff)>>>0}
function zip(files){let local=[],central=[],offset=0;const enc=new TextEncoder();for(const [name,str]of files){const n=enc.encode(name),data=enc.encode(str),sum=crc(data);let l=[];put32(l,0x04034b50);put16(l,20);put16(l,0x0800);put16(l,0);put16(l,0);put16(l,0);put32(l,sum);put32(l,data.length);put32(l,data.length);put16(l,n.length);put16(l,0);const lh=new Uint8Array(l);local.push(lh,n,data);
let c=[];put32(c,0x02014b50);put16(c,20);put16(c,20);put16(c,0x0800);put16(c,0);put16(c,0);put16(c,0);put32(c,sum);put32(c,data.length);put32(c,data.length);put16(c,n.length);put16(c,0);put16(c,0);put16(c,0);put16(c,0);put32(c,0);put32(c,offset);central.push(new Uint8Array(c),n);offset+=lh.length+n.length+data.length}
const centSize=central.reduce((s,v)=>s+v.length,0),end=[];put32(end,0x06054b50);put16(end,0);put16(end,0);put16(end,files.length);put16(end,files.length);put32(end,centSize);put32(end,offset);put16(end,0);return new Blob([...local,...central,new Uint8Array(end)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})}
function packMonth(role,m){const prefix=role.id+"_"+months[m][0]+"_"+months[m][1].slice(2),aName=prefix+"_A",bName=prefix+"_B",vName=prefix+"_VIEC",tName=prefix+"_TONG",sa=makeScoring(role,m,"A"),sb=makeScoring(role,m,"B");return[{name:tName,...makeSummary(role,m,aName,bName,sa,sb)},{name:aName,...sa},{name:bName,...sb},{name:vName,...makeTasks(role,m)}]}
function go(mode){
try{els.status.textContent="Đang tạo bảng mức điểm và kiểm tra cấu trúc Excel...";const role=selected(),m=Number(els.m.value);let sheets=[],filename;
if(mode==="one"){sheets=packMonth(role,m);filename="MNAB_CHAM_KPI_"+role.id+"_"+months[m][0]+"-"+months[m][1]+".xlsx"}
else if(mode==="year"){for(let i=0;i<12;i++)sheets.push(...packMonth(role,i));filename="MNAB_CHAM_KPI_12_THANG_"+role.id+"_2026-2027.xlsx"}
else{for(const r of positions)sheets.push(...packMonth(r,m));filename="MNAB_CHAM_KPI_8_VI_TRI_"+months[m][0]+"-"+months[m][1]+".xlsx"}
if(sheets.length!==4*(mode==="one"?1:mode==="year"?12:8))throw Error("Số lượng trang tính không hợp lệ.");
const blob=workbook(sheets);if(blob.size<5000)throw Error("Dung lượng file không hợp lệ.");const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=filename;a.style.display="none";document.body.appendChild(a);a.click();a.remove();els.status.textContent="Đã tạo "+filename+" ("+Math.round(blob.size/1024)+" KB). Vui lòng mở bằng Microsoft Excel và xem trước bản in.";setTimeout(()=>URL.revokeObjectURL(url),60000);
}catch(err){els.status.textContent="Không tạo được file: "+String(err.message||err)}}
box.querySelectorAll("[data-export]").forEach(btn=>btn.addEventListener("click",()=>go(btn.dataset.export)));
})();
</script>

```

### Cách sử dụng

Sau khi tải, bạn mở file và sử dụng theo thứ tự: **Giao việc tháng → Chấm phần A → Chấm phần B → Xem tổng hợp**. Trong hai bảng chấm, chỉ cần nhập kết quả thực tế và chọn mức điểm phù hợp ở các ô màu vàng.

Tôi đã giữ nguyên các mức điểm của Quy chế nguồn. Riêng hai chỗ có dấu hiệu chưa thống nhất cần nhà trường xem xét trước khi áp dụng chính thức: **A1.2 có ngưỡng 3 sai sót nhẹ bị trùng giữa hai mức**, và **B1.2 cấp dưỡng ghi 9 điểm trong khi điểm tối đa là 8**. Mẫu không tự sửa hai mức này để tránh thay đổi Quy chế đã ban hành.

**Lưu ý:** File được tạo trực tiếp khi bạn nhấn nút tải và có bước kiểm tra cấu trúc dữ liệu. Tôi chưa có điều kiện kiểm chứng bằng cách mở trực tiếp trong Microsoft Excel trên thiết bị của bạn.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

chỗ này k có thang đei63m cụ thể từng mục nè

---

ASSISTANT

Bạn chỉ đúng chỗ còn thiếu. Trong **Phiếu giao việc KPI tháng 11/2026**, phần A mới ghi tổng điểm của từng nhóm A1, A2, A3, A4. Giáo viên nhìn vào đó **không biết khi nào được điểm tối đa, khi nào bị giảm điểm**.

Phần này phải thể hiện đủ **09 tiêu chí thành phần** và mức chấm cụ thể, ngay trong phiếu, không chỉ ghi “A1 – 15 điểm”.

### Bảng chấm phần A cần hiển thị như sau

| Mã | Nội dung | Tối đa | Các mức chấm theo Quy chế |
|--------|--------|--------|--------|
| **A1.1** | Đạo đức nhà giáo, tôn trọng trẻ | 6 | **6 – 4 – 2 – 0** điểm, theo số sai sót và mức độ vi phạm |
| **A1.2** | Chấp hành pháp luật, nội quy | 5 | **5 – 4 – 2 – 0** điểm, theo số vi phạm |
| **A1.3** | Trung thực hồ sơ, bảo mật thông tin | 4 | **4 – 3 – 1 – 0** điểm |
| **A2.1** | Chủ động thực hiện nhiệm vụ | 4 | **4 – 3 – 1 – 0** điểm, theo số lần phải nhắc |
| **A2.2** | Đoàn kết, phối hợp | 3 | **3 – 2 – 1 – 0** điểm |
| **A3.1** | Chấp hành giờ làm việc | 2 | **2 – 1 – 0** điểm |
| **A3.2** | Trang phục, tác phong, giao tiếp | 2 | **2 – 1 – 0** điểm |
| **A4.1** | Tự học, bồi dưỡng và vận dụng | 2 | **2 – 1 – 0** điểm |
| **A4.2** | Ứng dụng CNTT, STEAM, AI hoặc cải tiến | 2 | **2 – 1 – 0** điểm |
| **Tổng phần A** |  | **30** |  |

Trong file sửa, mỗi dòng còn phải ghi rõ **điều kiện ứng với từng mức điểm**, ví dụ A2.1: *4 điểm khi chủ động không phải nhắc; 3 điểm khi phải nhắc một lần; 1 điểm khi phải nhắc hai lần; 0 điểm khi phải nhắc từ ba lần hoặc từ chối nhiệm vụ hợp lệ không có lý do chính đáng*.

Phần B cũng cần trình bày tương tự, theo đúng mức điểm chuẩn của từng mã B1.1 đến B4.3; có cột **tự chấm**, **Ban giám hiệu chấm**, không gộp nhiều mã KPI vào một dòng để chấm.

Tôi đã thiết kế lại **đúng phần giáo viên bạn chụp**, đưa đầy đủ thang điểm phần A vào cùng phiếu giao việc, đồng thời giữ bảng chấm chi tiết phần B và bảng tổng hợp riêng.

## Excel KPI giáo viên – Có đầy đủ mức điểm A và B

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="mnab-fix-a" class="w-full space-y-3">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="font-semibold">PHIẾU GIAO VIỆC VÀ CHẤM KPI GIÁO VIÊN</div>
    <div class="text-sm opacity-70">Trường Mầm non An Bình · Năm học 2026–2027 · Thang điểm 100</div>
    <label class="block text-sm space-y-1"><span class="font-medium">Chọn tháng</span><select data-month class="w-full rounded-lg border p-2 bg-transparent"></select></label>
    <div class="grid grid-cols-3 gap-2">
      <div class="border rounded-lg p-2 text-center"><div class="font-semibold text-lg">09</div><div class="text-xs opacity-70">Tiêu chí A</div></div>
      <div class="border rounded-lg p-2 text-center"><div class="font-semibold text-lg">14</div><div class="text-xs opacity-70">Tiêu chí B</div></div>
      <div class="border rounded-lg p-2 text-center"><div class="font-semibold text-lg">100</div><div class="text-xs opacity-70">Điểm tối đa</div></div>
    </div>
    <div class="text-sm space-y-1 p-3 rounded-lg bg-black/5 dark:bg-white/5">
      <div><strong>Trang 01:</strong> Giao việc tháng và đầy đủ 09 thang điểm phần A.</div>
      <div><strong>Trang 02:</strong> Chấm 14 tiêu chí phần B, đủ các mức điểm.</div>
      <div><strong>Trang 03:</strong> Tổng hợp điểm tự chấm và điểm đánh giá.</div>
    </div>
    <button data-download class="w-full rounded-lg bg-blue-700 p-3 text-white font-semibold cursor-pointer">Tạo và tải Excel đã sửa (.xlsx)</button>
    <p data-status class="text-xs opacity-70" role="status">Các ô chấm điểm để trống; chỉ tính tổng khi đã nhập đủ từng tiêu chí.</p>
  </div>
</div>
<script>
(function(){
const host=document.getElementById("mnab-fix-a");if(!host||host.dataset.ready)return;host.dataset.ready="1";
const months=[["09","2026","Ổn định đầu năm, huy động trẻ"],["10","2026","Củng cố nề nếp, sinh hoạt chuyên môn"],["11","2026","Hoạt động chuyên môn, phong trào phát sinh"],["12","2026","Rà soát, tổng hợp kết quả học kỳ I"],["01","2027","Sơ kết, chuẩn bị an toàn kỳ nghỉ"],["02","2027","Ổn định nề nếp sau kỳ nghỉ"],["03","2027","Chuyên đề, nâng cao chất lượng giáo dục"],["04","2027","Đánh giá trẻ, tăng cường an toàn"],["05","2027","Hoàn thiện hồ sơ, tổng kết và bàn giao"],["06","2027","Nhiệm vụ hè theo phân công"],["07","2027","Tuyển sinh, điều tra huy động trẻ"],["08","2027","Chuẩn bị kế hoạch và môi trường giáo dục"]];
const A=[
["A1.1","Đạo đức nhà giáo; tôn trọng, đối xử công bằng với trẻ",6,[[6,"Không vi phạm"],[4,"1 sai sót giao tiếp nhẹ, khắc phục ngay"],[2,"2 sai sót nhẹ"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh"]],"Quan sát, biên bản, phản ánh xác minh"],
["A1.2","Chấp hành pháp luật, quy chế, nội quy",5,[[5,"Không vi phạm"],[4,"1 vi phạm nhẹ"],[2,"2–3 vi phạm nhẹ (theo bản Quy chế)"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh"]],"Biên bản, phiếu kiểm tra"],
["A1.3","Trung thực báo cáo, hồ sơ; bảo mật thông tin trẻ",4,[[4,"Đúng, đầy đủ"],[3,"1 sai sót không cố ý, sửa ngay"],[1,"2 sai sót"],[0,"Từ 3 sai sót hoặc cố ý sai lệch, tiết lộ thông tin"]],"Hồ sơ, kết quả đối chiếu"],
["A2.1","Chủ động thực hiện nhiệm vụ, đề xuất giải pháp",4,[[4,"Chủ động, không phải nhắc"],[3,"1 lần phải nhắc"],[1,"2 lần phải nhắc"],[0,"Từ 3 lần phải nhắc hoặc từ chối nhiệm vụ hợp lệ"]],"Nhận xét tổ trưởng"],
["A2.2","Đoàn kết, hợp tác, hỗ trợ đồng nghiệp",3,[[3,"Phối hợp đầy đủ"],[2,"1 lần chưa phối hợp, phải nhắc"],[1,"2 lần phải nhắc"],[0,"Từ 3 lần hoặc gây mất đoàn kết được xác minh"]],"Biên bản sinh hoạt, phối hợp"],
["A3.1","Chấp hành giờ làm việc, nhận lớp, bàn giao",2,[[2,"Đúng thời gian; nghỉ hợp lệ không tính vi phạm"],[1,"1 lần vi phạm thời gian làm việc"],[0,"Từ 2 lần vi phạm thời gian làm việc"]],"Bảng công, lịch trực"],
["A3.2","Trang phục, tác phong, giao tiếp sư phạm",2,[[2,"Thực hiện đúng"],[1,"1 sai sót nhẹ, đã khắc phục"],[0,"Từ 2 sai sót hoặc vi phạm nghiêm trọng"]],"Kiểm tra thực tế"],
["A4.1","Tự học, bồi dưỡng, vận dụng vào công việc",2,[[2,"Có ít nhất 1 nội dung được vận dụng"],[1,"Có học, chưa có minh chứng vận dụng"],[0,"Không có minh chứng theo yêu cầu"]],"Sản phẩm bồi dưỡng"],
["A4.2","Ứng dụng CNTT, STEAM, AI hoặc cải tiến",2,[[2,"Có ít nhất 1 cải tiến áp dụng, chứng minh hiệu quả"],[1,"Có thử nghiệm, chưa đánh giá hiệu quả"],[0,"Không có cải tiến được ghi nhận"]],"Giáo án, học liệu, sản phẩm"]
];
const p=(a,b,c)=>[[a,"Hoàn thành 100% nhiệm vụ được giao"],[b,"Từ 90% đến dưới 100%"],[c,"Từ 70% đến dưới 90%"],[0,"Dưới 70%"]];
const B=[
["B1.1","Xây dựng kế hoạch giáo dục tháng, tuần",5,p(5,4,2),"Kế hoạch giáo dục, sổ chuyên môn"],
["B1.2","Tổ chức hoạt động chăm sóc, nuôi dưỡng, giáo dục",8,p(8,6,3),"Kế hoạch, kiểm tra thực tế"],
["B1.3","Hồ sơ chuyên môn, hồ sơ lớp, theo dõi trẻ",4,p(4,3,1),"Hồ sơ, phiếu kiểm tra"],
["B1.4","Nhiệm vụ khác; huy động trẻ theo chỉ tiêu nếu được giao",3,p(3,2,1),"Phân công, chỉ tiêu, danh sách huy động"],
["B2.1","Bảo đảm an toàn thể chất, tinh thần của trẻ",10,[[10,"Không sai sót"],[7,"1 sai sót thủ tục nhẹ, sửa ngay, chưa gây nguy hiểm"],[3,"2 sai sót nhẹ, đã khắc phục"],[0,"Từ 3 sai sót hoặc 1 vi phạm nghiêm trọng về an toàn"]],"Bảng kiểm an toàn, biên bản"],
["B2.2","Chăm sóc vệ sinh, ăn, ngủ, theo dõi sức khỏe",7,[[7,"Thực hiện đúng, không sai sót"],[5,"1 sai sót nhẹ"],[2,"2–3 sai sót nhẹ"],[0,"Từ 4 sai sót hoặc vi phạm nghiêm trọng"]],"Kiểm tra ăn ngủ, vệ sinh"],
["B2.3","Hoạt động giáo dục lấy trẻ làm trung tâm",8,[[8,"Đạt 9–10/10 chỉ báo"],[6,"Đạt 7–8/10 chỉ báo"],[3,"Đạt 5–6/10 chỉ báo"],[0,"Đạt 0–4/10 chỉ báo"]],"Phiếu quan sát 2 lượt"],
["B2.4","Theo dõi, đánh giá phát triển và hỗ trợ trẻ",5,p(5,4,2),"Hồ sơ theo dõi trẻ"],
["B3.1","Nộp kế hoạch, hồ sơ, báo cáo đúng hạn",4,[[4,"100% đúng hạn"],[3,"1 lần trễ không quá 1 ngày"],[1,"2 lần trễ hoặc 1 lần quá 1 ngày"],[0,"Từ 3 lần trễ hoặc không nộp nhiệm vụ bắt buộc"]],"Lịch nộp, thời điểm tiếp nhận"],
["B3.2","Đảm bảo tiến độ công việc theo kế hoạch",4,[[4,"100% đúng hạn"],[3,"Từ 90% đến dưới 100%"],[1,"Từ 70% đến dưới 90%"],[0,"Dưới 70%"]],"Kế hoạch, lịch công tác"],
["B3.3","Thực hiện nhiệm vụ đột xuất đúng thời hạn",2,[[2,"Tất cả nhiệm vụ đúng hạn"],[1,"1 nhiệm vụ trễ không quá 1 ngày"],[0,"Từ 2 nhiệm vụ trễ hoặc không thực hiện nhiệm vụ hợp lệ"]],"Phiếu giao việc"],
["B4.1","Sinh hoạt chuyên môn, bồi dưỡng, chia sẻ",4,[[4,"Đủ buổi, có ý kiến/góp ý hoặc sản phẩm vận dụng"],[3,"Đủ buổi, chưa có minh chứng trao đổi, vận dụng"],[1,"Tham gia từ 50% đến dưới 100%"],[0,"Dưới 50% không có lý do chính đáng"]],"Biên bản, sản phẩm"],
["B4.2","Phối hợp giáo viên cùng lớp, nhân viên liên quan",3,p(3,2,1),"Sổ bàn giao, kế hoạch"],
["B4.3","Phối hợp cha mẹ trẻ, hỗ trợ trẻ",3,p(3,2,1),"Sổ liên lạc, trao đổi"]
];
const tasks=[
["B1.1","Xây dựng kế hoạch giáo dục","Đầy đủ kế hoạch tháng, tuần theo phân công","Kế hoạch"],
["B1.2","Tổ chức hoạt động chăm sóc, giáo dục","Đủ hoạt động theo kế hoạch được duyệt","Sổ lớp, quan sát"],
["B2.1","Bảo đảm an toàn của trẻ","Thực hiện đúng điểm danh, giám sát, đón trả","Bảng kiểm"],
["B2.2","Tổ chức ăn, ngủ, vệ sinh","Đúng quy trình, theo dõi sức khỏe","Sổ lớp"],
["B2.3","Tổ chức hoạt động lấy trẻ làm trung tâm","Tham gia 2 lượt quan sát, đạt chỉ báo theo Quy chế","Phiếu quan sát"],
["B1.3/B2.4","Cập nhật hồ sơ và đánh giá trẻ","Đầy đủ, chính xác, đúng hạn","Hồ sơ trẻ"],
["B4.2/B4.3","Phối hợp giáo viên và cha mẹ trẻ","Bàn giao và trao đổi thông tin kịp thời","Ghi nhận phối hợp"]
];
const focus=[
["B1.4","Huy động trẻ đầu năm theo phân công","Ghi chỉ tiêu, thực tế; chưa đạt/đạt/vượt","Danh sách"],
["B4.1","Tham gia sinh hoạt chuyên môn","Có ý kiến hoặc sản phẩm vận dụng","Biên bản"],
["B3.3","Hội thi, phong trào phát sinh nếu được giao","Hoàn thành phần việc và kết quả xác nhận","Phân công"],
["B2.4","Rà soát kết quả theo dõi trẻ học kỳ I","Hoàn thành đánh giá đến kỳ","Hồ sơ"],
["B3.1","Hoàn thành hồ sơ sơ kết","Đúng hạn và đầy đủ","Báo cáo"],
["B1.4","Theo dõi sĩ số, huy động bổ sung nếu được giao","Ghi nhận theo chỉ tiêu tháng","Danh sách"],
["B4.1","Tham gia chuyên đề và chia sẻ","Có nội dung được vận dụng","Sản phẩm"],
["B2.4","Rà soát đánh giá trẻ cuối năm","Hoàn thành theo kế hoạch","Hồ sơ"],
["B1.3","Hoàn thiện hồ sơ, bàn giao","Đúng hạn và đầy đủ","Biên bản"],
["B1.4","Thực hiện nhiệm vụ hè nếu được giao","Theo phân công hợp lệ","Lịch hè"],
["B1.4","Điều tra, huy động trẻ theo độ tuổi","Đối chiếu chỉ tiêu tháng được giao","Danh sách"],
["B1.1","Chuẩn bị kế hoạch năm học mới","Đúng phân công và tiến độ","Kế hoạch"]
];
const pick=host.querySelector("[data-month]");
months.forEach((m,i)=>{const o=document.createElement("option");o.value=i;o.textContent="Tháng "+m[0]+"/"+m[1];pick.appendChild(o)});pick.value="2";
const E=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
function builder(){const lines=[],merges=[],valid=[];const cols="ABCDEFG";
function add(h,items){const n=lines.length+1,cells=Array.from({length:7},()=>({v:"",s:0}));for(const [first,last,v,s] of items){for(let j=first;j<=last;j++)cells[j]={v:j===first?v:"",s};if(last>first)merges.push(cols[first]+n+":"+cols[last]+n)}
const c=cells.map((item,j)=>{const r=cols[j]+n,v=item.v,s=item.s;if(v&&typeof v==="object"&&v.f!==undefined)return'<c r="'+r+'" s="'+s+'"><f>'+E(v.f)+'</f><v></v></c>';if(typeof v==="number")return'<c r="'+r+'" s="'+s+'" t="n"><v>'+v+'</v></c>';if(v===""||v==null)return'<c r="'+r+'" s="'+s+'"/>';return'<c r="'+r+'" s="'+s+'" t="inlineStr"><is><t xml:space="preserve">'+E(v)+'</t></is></c>'}).join("");lines.push('<row r="'+n+'" ht="'+h+'" customHeight="1">'+c+'</row>');return n}
return{add,lines,merges,valid,get count(){return lines.length}}}
const g=(a,b,t,s)=>[a,b,t,s];
function addScoring(b,items){
const first=b.count+1;
items.forEach(x=>{const r=b.add(66,[g(0,0,x[0],6),g(1,1,x[1],5),g(2,2,x[2],7),g(3,3,x[3].map(z=>z[0]+" điểm: "+z[1]).join("\n"),5),g(4,4,x[4],5),g(5,5,"",8),g(6,6,"",8)]);b.valid.push({row:r,nums:[...new Set(x[3].map(v=>v[0]))]})});
return[first,b.count]}
function sheetXml(b,opts={}){
const widths=[10,39,10,59,28,13,13],col=widths.map((v,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+v+'" customWidth="1"/>').join("");
const merge=b.merges.length?'<mergeCells count="'+b.merges.length+'">'+b.merges.map(v=>'<mergeCell ref="'+v+'"/>').join("")+'</mergeCells>':"";
const dv=b.valid.length?'<dataValidations count="'+b.valid.length+'">'+b.valid.map(v=>'<dataValidation type="list" allowBlank="1" showErrorMessage="1" error="Vui lòng chọn đúng mức điểm cho tiêu chí." sqref="F'+v.row+' G'+v.row+'"><formula1>"'+v.nums.join(",")+'"</formula1></dataValidation>').join("")+'</dataValidations>':"";
const breaks=opts.breaks||[],rb=breaks.length?'<rowBreaks count="'+breaks.length+'" manualBreakCount="'+breaks.length+'">'+breaks.map(v=>'<brk id="'+v+'" min="0" max="16383" man="1"/>').join("")+'</rowBreaks>':"";
return{xml:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:G'+b.count+'"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>'+col+'</cols><sheetData>'+b.lines.join("")+'</sheetData>'+merge+dv+'<printOptions gridLines="0" headings="0" horizontalCentered="1"/><pageMargins left="0.22" right="0.22" top="0.26" bottom="0.26" header="0.1" footer="0.14"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/><headerFooter><oddFooter>&amp;CTrường Mầm non An Bình – Trang &amp;P</oddFooter></headerFooter>'+rb+'</worksheet>',last:b.count}}
function partA(k){
const b=builder(),m=months[k];
b.add(20,[g(0,6,"UBND PHƯỜNG AN BÌNH – TRƯỜNG MẦM NON AN BÌNH",1)]);
b.add(28,[g(0,6,"PHIẾU GIAO VIỆC VÀ CHẤM KPI GIÁO VIÊN – THÁNG "+m[0]+"/"+m[1],2)]);
b.add(22,[g(0,3,"Chức danh: Giáo viên",3),g(4,6,"A: 30 điểm | B: 70 điểm | Tổng: 100 điểm",3)]);
b.add(21,[g(0,6,"A. TIÊU CHÍ CHUNG – 30 ĐIỂM: MỖI DÒNG CÓ MỨC CHẤM CỤ THỂ",4)]);
b.add(24,[g(0,0,"Mã",3),g(1,1,"NỘI DUNG TIÊU CHÍ",3),g(2,2,"Điểm tối đa",3),g(3,3,"QUY ĐỊNH CÁC MỨC ĐIỂM",3),g(4,4,"Minh chứng",3),g(5,5,"Tự chấm",3),g(6,6,"BGH chấm",3)]);
const [from,to]=addScoring(b,A);
const total=b.add(28,[g(0,1,"TỔNG PHẦN A",9),g(2,2,30,9),g(3,4,"Chỉ tổng hợp sau khi nhập đủ 9 tiêu chí.",9),g(5,5,{f:'IF(COUNT(F'+from+':F'+to+')<9,"",SUM(F'+from+':F'+to+'))'},9),g(6,6,{f:'IF(COUNT(G'+from+':G'+to+')<9,"",SUM(G'+from+':G'+to+'))'},9)]);
b.add(32,[g(0,6,"LƯU Ý A1.2: Bản Quy chế đang trùng ngưỡng “3 sai sót nhẹ” ở mức 2 và 0 điểm. Nhà trường cần đính chính để chấm thống nhất.",10)]);
const border=b.count;
b.add(23,[g(0,6,"B. ĐẦU VIỆC TRỌNG TÂM CỦA THÁNG – CHẤM CHI TIẾT THEO TRANG 02_CHAM_B",4)]);
b.add(24,[g(0,0,"STT",3),g(1,1,"Mã KPI",3),g(2,2,"",3),g(3,3,"Đầu việc – kết quả cần đạt",3),g(4,4,"Minh chứng",3),g(5,5,"Thời hạn",3),g(6,6,"Kết quả",3)]);
[...tasks,focus[k]].forEach((t,i)=>b.add(38,[g(0,0,i+1,7),g(1,2,t[0],6),g(3,3,t[1]+"\nYêu cầu: "+t[2],5),g(4,4,t[3],5),g(5,5,"",8),g(6,6,"",8)]));
b.add(29,[g(0,6,"Nhiệm vụ huy động trẻ và phong trào phát sinh: ghi theo phân công thực tế; không cộng thêm điểm ngoài thang KPI.",10)]);
b.add(20,[g(0,2,"NGƯỜI THỰC HIỆN",11),g(3,4,"TỔ TRƯỞNG / PHỤ TRÁCH",11),g(5,6,"BAN GIÁM HIỆU",11)]);
b.add(36,[g(0,2,"(Ký, ghi rõ họ tên)",11),g(3,4,"(Ký, ghi rõ họ tên)",11),g(5,6,"(Ký, ghi rõ họ tên)",11)]);
return{...sheetXml(b,{breaks:[border]}),total,from,to}}
function partB(k){
const b=builder(),m=months[k];
b.add(20,[g(0,6,"TRƯỜNG MẦM NON AN BÌNH – NĂM HỌC 2026–2027",1)]);
b.add(28,[g(0,6,"PHIẾU CHẤM KPI PHẦN B – THÁNG "+m[0]+"/"+m[1],2)]);
b.add(22,[g(0,6,"Giáo viên: ............................................................ | KẾT QUẢ NHIỆM VỤ: 70 ĐIỂM",1)]);
b.add(21,[g(0,6,"Chọn mức điểm tương ứng theo Quy chế; đối chiếu kết quả thực tế và minh chứng.",4)]);
b.add(24,[g(0,0,"Mã",3),g(1,1,"NỘI DUNG TIÊU CHÍ",3),g(2,2,"Điểm tối đa",3),g(3,3,"QUY ĐỊNH CÁC MỨC ĐIỂM",3),g(4,4,"Minh chứng",3),g(5,5,"Tự chấm",3),g(6,6,"BGH chấm",3)]);
const [from,to]=addScoring(b,B);
const total=b.add(28,[g(0,1,"TỔNG PHẦN B",9),g(2,2,70,9),g(3,4,"Chỉ tổng hợp sau khi nhập đủ 14 tiêu chí.",9),g(5,5,{f:'IF(COUNT(F'+from+':F'+to+')<14,"",SUM(F'+from+':F'+to+'))'},9),g(6,6,{f:'IF(COUNT(G'+from+':G'+to+')<14,"",SUM(G'+from+':G'+to+'))'},9)]);
b.add(31,[g(0,6,"B1.4: Huy động trẻ chưa đạt/đạt/vượt là minh chứng nhiệm vụ; không có điểm cộng riêng. Nhiệm vụ không phát sinh xử lý theo Quy chế.",10)]);
b.add(20,[g(0,2,"NGƯỜI TỰ CHẤM",11),g(3,4,"TỔ TRƯỞNG / PHỤ TRÁCH",11),g(5,6,"BAN GIÁM HIỆU",11)]);
b.add(37,[g(0,2,"(Ký, ghi rõ họ tên)",11),g(3,4,"(Ký, ghi rõ họ tên)",11),g(5,6,"(Ký, ghi rõ họ tên)",11)]);
return{...sheetXml(b,{breaks:[13]}),total,from,to}}
function summary(k,a,b){
const x=builder(),m=months[k];
x.add(21,[g(0,6,"UBND PHƯỜNG AN BÌNH – TRƯỜNG MẦM NON AN BÌNH",1)]);
x.add(31,[g(0,6,"BẢNG TỔNG HỢP KPI GIÁO VIÊN – THÁNG "+m[0]+"/"+m[1],2)]);
x.add(29,[g(0,6,"Họ tên giáo viên: ...........................................................................  Lớp: ........................................",1)]);
x.add(27,[g(0,6,"Chỉ tính điểm khi đã chấm đủ các tiêu chí A và B. Mức xếp loại chính thức theo Quy chế.",10)]);
x.add(25,[g(0,2,"NHÓM TIÊU CHÍ",3),g(3,4,"TỐI ĐA",3),g(5,5,"TỰ CHẤM",3),g(6,6,"BGH CHẤM",3)]);
x.add(36,[g(0,2,"A – Tiêu chí chung",5),g(3,4,30,7),g(5,5,{f:'IF(\'01_GIAO_VIEC\'!F'+a.total+'="","",\'01_GIAO_VIEC\'!F'+a.total+')'},9),g(6,6,{f:'IF(\'01_GIAO_VIEC\'!G'+a.total+'="","",\'01_GIAO_VIEC\'!G'+a.total+')'},9)]);
x.add(36,[g(0,2,"B – Kết quả nhiệm vụ",5),g(3,4,70,7),g(5,5,{f:'IF(\'02_CHAM_B\'!F'+b.total+'="","",\'02_CHAM_B\'!F'+b.total+')'},9),g(6,6,{f:'IF(\'02_CHAM_B\'!G'+b.total+'="","",\'02_CHAM_B\'!G'+b.total+')'},9)]);
x.add(39,[g(0,2,"TỔNG CỘNG",9),g(3,4,100,9),g(5,5,{f:'IF(COUNT(F6:F7)<2,"",SUM(F6:F7))'},9),g(6,6,{f:'IF(COUNT(G6:G7)<2,"",SUM(G6:G7))'},9)]);
x.add(29,[g(0,6,"Từ 90 điểm; từ 70 đến dưới 90; từ 50 đến dưới 70; dưới 50. Việc xếp loại còn phụ thuộc điều kiện pháp luật và Quy chế.",10)]);
x.add(34,[g(0,6,"Nhận xét: ........................................................................................................................................................",5)]);
x.add(34,[g(0,6,"Nhiệm vụ cần khắc phục: ...................................................................................................................................",5)]);
x.add(22,[g(0,2,"GIÁO VIÊN",11),g(3,4,"TỔ TRƯỞNG",11),g(5,6,"BAN GIÁM HIỆU",11)]);
x.add(44,[g(0,2,"(Ký, ghi rõ họ tên)",11),g(3,4,"(Ký, ghi rõ họ tên)",11),g(5,6,"(Ký, ghi rõ họ tên)",11)]);
return sheetXml(x)}
function styles(){
const fonts=[
'<font><sz val="9"/><name val="Times New Roman"/><color rgb="FF263746"/></font>',
'<font><sz val="10"/><b/><name val="Times New Roman"/><color rgb="FF153954"/></font>',
'<font><sz val="14"/><b/><name val="Times New Roman"/><color rgb="FF153954"/></font>',
'<font><sz val="9"/><b/><name val="Times New Roman"/><color rgb="FFFFFFFF"/></font>',
'<font><sz val="9"/><i/><name val="Times New Roman"/><color rgb="FF596778"/></font>'];
const fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>',...["FF173B5C","FFE8F1F8","FFFFF3D9"].map(c=>'<fill><patternFill patternType="solid"><fgColor rgb="'+c+'"/><bgColor indexed="64"/></patternFill></fill>')];
const borders=['<border><left/><right/><top/><bottom/><diagonal/></border>','<border><left style="thin"><color rgb="FFB5C1CA"/></left><right style="thin"><color rgb="FFB5C1CA"/></right><top style="thin"><color rgb="FFB5C1CA"/></top><bottom style="thin"><color rgb="FFB5C1CA"/></bottom><diagonal/></border>'];
const defs=[[0,0,0,"left"],[1,0,0,"left"],[2,0,0,"center"],[3,2,0,"left"],[3,2,1,"center"],[0,0,1,"left"],[1,0,1,"center"],[1,0,1,"center"],[0,4,1,"center"],[1,3,1,"center"],[4,3,0,"left"],[1,0,0,"center"]];
return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="'+fonts.length+'">'+fonts.join("")+'</fonts><fills count="'+fills.length+'">'+fills.join("")+'</fills><borders count="'+borders.length+'">'+borders.join("")+'</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="'+defs.length+'">'+defs.map(v=>'<xf numFmtId="0" fontId="'+v[0]+'" fillId="'+v[1]+'" borderId="'+v[2]+'" xfId="0" applyAlignment="1"><alignment horizontal="'+v[3]+'" vertical="center" wrapText="1"/></xf>').join("")+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'}
const put16=(a,n)=>a.push(n&255,n>>>8&255),put32=(a,n)=>a.push(n&255,n>>>8&255,n>>>16&255,n>>>24&255);
function crc(bytes){let v=0xffffffff;for(const n of bytes){v^=n;for(let i=0;i<8;i++)v=(v>>>1)^((v&1)?0xedb88320:0)}return(v^0xffffffff)>>>0}
function zip(files){const enc=new TextEncoder(),loc=[],cen=[];let off=0;for(const [name,src] of files){const n=enc.encode(name),d=enc.encode(src),crcval=crc(d),l=[];put32(l,0x04034b50);put16(l,20);put16(l,0x0800);put16(l,0);put16(l,0);put16(l,0);put32(l,crcval);put32(l,d.length);put32(l,d.length);put16(l,n.length);put16(l,0);const header=new Uint8Array(l);loc.push(header,n,d);
const c=[];put32(c,0x02014b50);put16(c,20);put16(c,20);put16(c,0x0800);put16(c,0);put16(c,0);put16(c,0);put32(c,crcval);put32(c,d.length);put32(c,d.length);put16(c,n.length);put16(c,0);put16(c,0);put16(c,0);put16(c,0);put32(c,0);put32(c,off);cen.push(new Uint8Array(c),n);off+=header.length+n.length+d.length}
const size=cen.reduce((s,v)=>s+v.length,0),end=[];put32(end,0x06054b50);put16(end,0);put16(end,0);put16(end,files.length);put16(end,files.length);put32(end,size);put32(end,off);put16(end,0);return new Blob([...loc,...cen,new Uint8Array(end)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})}
function workbook(sheets){
const defs=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'];
sheets.forEach((s,i)=>defs.push('<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'));defs.push('</Types>');
const w='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+sheets.map((s,i)=>'<sheet name="'+E(s.name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join("")+'</sheets><definedNames>'+sheets.map((s,i)=>'<definedName name="_xlnm.Print_Area" localSheetId="'+i+'">&apos;'+s.name+'&apos;!$A$1:$G

**Lưu ý nhỏ trước khi áp dụng:** Quy chế hiện có một điểm chưa thống nhất tại A1.2: *3 sai sót nhẹ* xuất hiện ở cả mức 2 điểm và 0 điểm. Tôi giữ nguyên nội dung nguồn trong mẫu, đồng thời đánh dấu để nhà trường đính chính, tránh mỗi người chấm một cách.

Với mẫu này, giáo viên sẽ nhìn thấy trực tiếp **từng mức điểm ngay trong phiếu**, thay vì chỉ thấy tổng A1, A2, A3, A4 như ảnh bạn gửi.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.+s.last+'</definedName>').join("")+'</definedNames><calcPr calcMode="auto" fullCalcOnLoad="1"/></workbook>';
const relations='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((s,i)=>'<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join("")+'<Relationship Id="rId'+(sheets.length+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
const files=[["[Content_Types].xml",defs.join("")],["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],["xl/workbook.xml",w],["xl/_rels/workbook.xml.rels",relations],["xl/styles.xml",styles()]];
sheets.forEach((s,i)=>files.push(["xl/worksheets/sheet"+(i+1)+".xml",s.xml]));
const dom=new DOMParser();for(const [n,x] of files){const parsed=dom.parseFromString(x,"application/xml");if(parsed.getElementsByTagName("parsererror").length)throw Error("Lỗi cấu trúc XML trong "+n)}
return zip(files)}
host.querySelector("[data-download]").addEventListener("click",()=>{
const status=host.querySelector("[data-status]");
try{
const k=Number(pick.value),a=partA(k),b=partB(k),c=summary(k,a,b);
if(A.reduce((s,v)=>s+v[2],0)!==30||B.reduce((s,v)=>s+v[2],0)!==70)throw Error("Tổng điểm không đúng Quy chế.");
status.textContent="Đang kiểm tra cấu trúc bảng và tạo file Excel...";
const blob=workbook([{name:"01_GIAO_VIEC",...a},{name:"02_CHAM_B",...b},{name:"03_TONG_HOP",...c}]);
if(blob.size<5000)throw Error("File tạo ra chưa hợp lệ.");
const url=URL.createObjectURL(blob),link=document.createElement("a");link.href=url;link.download="MNAB_KPI_GIAO_VIEC_VA_CHAM_GV_"+months[k][0]+"-"+months[k][1]+".xlsx";document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
status.textContent="Đã tạo file ("+Math.round(blob.size/1024)+" KB) và kiểm tra cấu trúc XML. Mở bằng Excel, xem trước in A4 ngang.";
}catch(e){status.textContent="Không tạo được file: "+(e.message||String(e))}
});
})();
</script>

```

**Lưu ý nhỏ trước khi áp dụng:** Quy chế hiện có một điểm chưa thống nhất tại A1.2: *3 sai sót nhẹ* xuất hiện ở cả mức 2 điểm và 0 điểm. Tôi giữ nguyên nội dung nguồn trong mẫu, đồng thời đánh dấu để nhà trường đính chính, tránh mỗi người chấm một cách.

Với mẫu này, giáo viên sẽ nhìn thấy trực tiếp **từng mức điểm ngay trong phiếu**, thay vì chỉ thấy tổng A1, A2, A3, A4 như ảnh bạn gửi.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

trong nội dung này rất chi tiết, cụ thể các đầu việc. Tuy nhiên mình muốn bổ sung thêm vào hoạt động truyền thông : Viết tin bài, đăng tải các video hoạt động học, hoạt động ngoài trời, hoạt động góc, trải nghiệm  của trẻ ở nhóm lớp để phục vụ kho học liệu số.  bên cạnh đó, Hoạt động tổ chức ngoài trời, hoạt động góc  để tránh việc các lớp không thực hiện. Lưu ý không làm thay đổi số điểm các mục trong KPI (bổ sung rõ đầu việc) để giáo viên dễ  dàng tiếp nhận, tránh việc chống đối

---

ASSISTANT

Tôi sẽ bổ sung ngay vào các mã KPI hiện có, không tạo tiêu chí hay điểm mới. Hai nội dung cần làm rõ là **tổ chức thực chất hoạt động ngoài trời, hoạt động góc** và **sản phẩm truyền thông đưa vào kho học liệu số**. Tôi cũng sẽ quy định minh chứng vừa đủ, phân công theo nhóm lớp và có ngoại lệ về thời tiết, quyền riêng tư của trẻ để giáo viên dễ thực hiện.

---

ASSISTANT

Tôi hiểu yêu cầu của bạn: **giáo viên phải tổ chức đầy đủ hoạt động ngoài trời, hoạt động góc; đồng thời có sản phẩm truyền thông và đóng góp cho kho học liệu số**, nhưng không cảm thấy nhà trường đang bổ sung một loạt tiêu chí để trừ điểm.

Giải pháp là **làm rõ đầu việc ngay trong các mã KPI hiện có**, không thêm mã mới, không tăng điểm và không chấm trùng một công việc ở nhiều tiêu chí.

## 1. Các nội dung cần bổ sung vào phiếu KPI giáo viên

| Mã KPI hiện có | Nội dung cần làm rõ | Điểm giữ nguyên |
|--------|--------|--------|
| **B1.2** | Tổ chức đầy đủ hoạt động học, hoạt động ngoài trời, hoạt động góc và trải nghiệm theo kế hoạch giáo dục được duyệt. | **8** |
| **B2.3** | Đánh giá chất lượng tổ chức các hoạt động trên theo các chỉ báo quan sát hiện hành, chú trọng trẻ được chơi, lựa chọn và trải nghiệm thực chất. | **8** |
| **B1.4** | Thực hiện nhiệm vụ truyền thông được phân công: viết tin bài, chuẩn bị video và cung cấp học liệu số của nhóm lớp. | **3** |
| **A4.2** | Khuyến khích ứng dụng công nghệ, biên tập và khai thác học liệu số có hiệu quả; vẫn chấm theo mức đổi mới, cải tiến đã quy định. | **2** |

**Lưu ý:** B1.2 chấm *số hoạt động đã thực hiện*; B2.3 chấm *chất lượng tổ chức*. B1.4 ghi nhận *sản phẩm truyền thông được giao*. Không lấy một video làm căn cứ tự động cộng điểm ở cả ba mục.

## 2. Đề xuất chỉ tiêu truyền thông dễ thực hiện

Tôi đề xuất giao theo **nhóm/lớp**, không giao riêng mỗi giáo viên:

- **01 tin/bài ngắn và 01 video ngắn mỗi nhóm/lớp/tháng**, sử dụng tư liệu từ hoạt động giáo dục thực tế.
- Chủ đề video luân phiên giữa hoạt động học, hoạt động ngoài trời, hoạt động góc và hoạt động trải nghiệm; **không yêu cầu quay đủ bốn loại trong một tháng**.
- Giáo viên nộp sản phẩm vào kho học liệu số của trường; việc đăng công khai chỉ thực hiện qua người có trách nhiệm sau khi kiểm duyệt và bảo đảm quyền riêng tư của trẻ.

Đây là **định mức tổ chức thực hiện tôi đề xuất**, chưa phải chỉ tiêu có sẵn trong Quy chế. Nhà trường nên thống nhất trước khi giao chính thức để bảo đảm khả thi.

## 3. Tải phiếu Excel đã bổ sung đầu việc

Bản này giữ nguyên **09 tiêu chí phần A, 14 tiêu chí phần B, toàn bộ mức điểm chuẩn và công thức tổng hợp**. Tôi bổ sung riêng các dòng theo dõi hoạt động ngoài trời, hoạt động góc, trải nghiệm, tin bài và video.

## Phiếu KPI giáo viên – Bổ sung hoạt động và học liệu số

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="mnab-kpi-media" class="w-full space-y-3">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="font-semibold">TRƯỜNG MẦM NON AN BÌNH</div>
    <div class="text-sm opacity-70">Phiếu giao việc và chấm KPI giáo viên · Năm học 2026–2027</div>
    <label class="flex flex-col gap-1 text-sm"><span class="font-medium">Tháng áp dụng</span><select data-month class="w-full rounded-lg border p-2 bg-transparent"></select></label>
    <div class="grid grid-cols-3 gap-2 text-center">
      <div class="rounded-lg border p-2"><div class="font-semibold text-lg">30</div><div class="text-xs opacity-70">Phần A</div></div>
      <div class="rounded-lg border p-2"><div class="font-semibold text-lg">70</div><div class="text-xs opacity-70">Phần B</div></div>
      <div class="rounded-lg border p-2"><div class="font-semibold text-lg">100</div><div class="text-xs opacity-70">Tổng điểm</div></div>
    </div>
    <div class="p-3 rounded-lg bg-black/5 dark:bg-white/5 text-sm space-y-1">
      <div class="font-medium">4 trang tính trong file:</div>
      <div>01 – Giao việc: bổ sung rõ ngoài trời, hoạt động góc, trải nghiệm và truyền thông</div>
      <div>02 – Chấm A: đủ 09 tiêu chí và mức điểm</div>
      <div>03 – Chấm B: đủ 14 tiêu chí và mức điểm</div>
      <div>04 – Tổng hợp: công thức cộng điểm A + B</div>
    </div>
    <button data-export class="w-full rounded-lg bg-blue-700 text-white font-semibold p-3 cursor-pointer">Tạo và tải Excel bổ sung (.xlsx)</button>
    <p class="text-xs opacity-70" data-status role="status">Các ô kết quả và chấm điểm để trống. Mẫu dùng để rà soát và giao việc; không tự gán điểm.</p>
  </div>
</div>
<script>
(function(){
const root=document.getElementById("mnab-kpi-media");if(!root||root.dataset.ok)return;root.dataset.ok="1";
const months=[["09","2026"],["10","2026"],["11","2026"],["12","2026"],["01","2027"],["02","2027"],["03","2027"],["04","2027"],["05","2027"],["06","2027"],["07","2027"],["08","2027"]];
const topic=["hoạt động học","hoạt động ngoài trời","hoạt động góc","hoạt động trải nghiệm"];
const choose=root.querySelector("[data-month]");months.forEach((m,i)=>{let x=document.createElement("option");x.value=i;x.textContent="Tháng "+m.join("/");choose.appendChild(x)});choose.value="2";
const pct=(a,b,c)=>[[a,"Hoàn thành 100%"],[b,"Từ 90% đến dưới 100%"],[c,"Từ 70% đến dưới 90%"],[0,"Dưới 70%"]];
const A=[
["A1.1","Đạo đức nhà giáo, tôn trọng trẻ",6,[[6,"Không vi phạm"],[4,"1 sai sót giao tiếp nhẹ, sửa ngay"],[2,"2 sai sót nhẹ"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng"]],"Kiểm tra, phản ánh xác minh"],
["A1.2","Chấp hành pháp luật, nội quy, quy chế",5,[[5,"Không vi phạm"],[4,"1 vi phạm nhẹ"],[2,"2–3 vi phạm nhẹ (theo Quy chế)"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng"]],"Biên bản kiểm tra"],
["A1.3","Trung thực trong hồ sơ, bảo mật thông tin trẻ",4,[[4,"Đúng, đầy đủ"],[3,"1 sai sót không cố ý, sửa ngay"],[1,"2 sai sót"],[0,"Từ 3 sai sót hoặc cố ý sai lệch, lộ thông tin"]],"Hồ sơ, dữ liệu"],
["A2.1","Chủ động thực hiện nhiệm vụ",4,[[4,"Chủ động, không phải nhắc"],[3,"1 lần phải nhắc"],[1,"2 lần phải nhắc"],[0,"Từ 3 lần nhắc hoặc từ chối nhiệm vụ hợp lệ"]],"Nhận xét tổ trưởng"],
["A2.2","Hợp tác, đoàn kết, phối hợp",3,[[3,"Hợp tác đầy đủ"],[2,"1 lần chưa phối hợp, phải nhắc"],[1,"2 lần phải nhắc"],[0,"Từ 3 lần hoặc gây mất đoàn kết được xác minh"]],"Biên bản, kết quả phối hợp"],
["A3.1","Giờ làm việc, nhận lớp, bàn giao",2,[[2,"Đúng giờ; nghỉ hợp lệ không là vi phạm"],[1,"1 lần vi phạm thời gian làm việc"],[0,"Từ 2 lần vi phạm"]],"Bảng chấm công, lịch trực"],
["A3.2","Trang phục, tác phong, giao tiếp",2,[[2,"Thực hiện đúng"],[1,"1 sai sót nhẹ, khắc phục"],[0,"Từ 2 sai sót hoặc vi phạm nghiêm trọng"]],"Kiểm tra thực tế"],
["A4.1","Tự học, bồi dưỡng và vận dụng",2,[[2,"Ít nhất 1 nội dung học được vận dụng"],[1,"Có học nhưng chưa có minh chứng vận dụng"],[0,"Không có minh chứng"]],"Sản phẩm vận dụng"],
["A4.2","CNTT, STEAM, AI hoặc cải tiến hoạt động giáo dục",2,[[2,"Có ít nhất 1 cải tiến áp dụng, chứng minh hiệu quả"],[1,"Có thử nghiệm, chưa đánh giá hiệu quả"],[0,"Không có cải tiến được ghi nhận"]],"Giáo án, học liệu, sản phẩm số"]
];
const B=[
["B1.1","Kế hoạch giáo dục tháng, tuần",5,pct(5,4,2),"Kế hoạch giáo dục"],
["B1.2","Thực hiện hoạt động học, ngoài trời, góc, trải nghiệm và chăm sóc theo kế hoạch",8,pct(8,6,3),"Kế hoạch tuần, lịch, quan sát thực tế"],
["B1.3","Hồ sơ chuyên môn, hồ sơ lớp, theo dõi trẻ",4,pct(4,3,1),"Hồ sơ, phiếu kiểm tra"],
["B1.4","Nhiệm vụ khác, huy động trẻ và truyền thông số theo phân công",3,pct(3,2,1),"Phân công, danh sách trẻ, tin bài, video"],
["B2.1","An toàn thể chất, tinh thần của trẻ",10,[[10,"Không sai sót"],[7,"1 sai sót thủ tục nhẹ, sửa ngay, chưa nguy hiểm"],[3,"2 sai sót nhẹ, đã khắc phục"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng"]],"Bảng kiểm an toàn"],
["B2.2","Ăn, ngủ, vệ sinh và chăm sóc sức khỏe",7,[[7,"Đúng, không sai sót"],[5,"1 sai sót nhẹ"],[2,"2–3 sai sót nhẹ"],[0,"Từ 4 sai sót hoặc vi phạm nghiêm trọng"]],"Sổ lớp, kiểm tra thực tế"],
["B2.3","Chất lượng giáo dục lấy trẻ làm trung tâm, bao gồm hoạt động góc/ngoài trời",8,[[8,"9–10/10 chỉ báo"],[6,"7–8/10 chỉ báo"],[3,"5–6/10 chỉ báo"],[0,"0–4/10 chỉ báo"]],"Phiếu quan sát 2 lượt"],
["B2.4","Theo dõi, đánh giá sự phát triển trẻ",5,pct(5,4,2),"Hồ sơ, kế hoạch hỗ trợ"],
["B3.1","Nộp hồ sơ, kế hoạch, báo cáo đúng hạn",4,[[4,"100% đúng hạn"],[3,"1 lần chậm không quá 1 ngày"],[1,"2 lần chậm hoặc 1 lần quá 1 ngày"],[0,"Từ 3 lần chậm hoặc không nộp nhiệm vụ bắt buộc"]],"Thời điểm nộp"],
["B3.2","Tiến độ chuẩn bị và tổ chức công việc",4,pct(4,3,1),"Kế hoạch, lịch công tác"],
["B3.3","Thực hiện nhiệm vụ đột xuất đúng hạn",2,[[2,"Tất cả nhiệm vụ đúng hạn"],[1,"1 nhiệm vụ chậm không quá 1 ngày"],[0,"Từ 2 nhiệm vụ chậm hoặc không thực hiện"]],"Phiếu giao việc"],
["B4.1","Sinh hoạt chuyên môn, bồi dưỡng và chia sẻ",4,[[4,"Đủ buổi, có ý kiến hoặc sản phẩm vận dụng"],[3,"Đủ buổi, chưa có minh chứng trao đổi/vận dụng"],[1,"Tham gia 50% đến dưới 100%"],[0,"Dưới 50% không lý do chính đáng"]],"Biên bản, sản phẩm"],
["B4.2","Phối hợp giáo viên cùng lớp và nhân viên",3,pct(3,2,1),"Sổ bàn giao"],
["B4.3","Trao đổi, phối hợp cha mẹ trẻ",3,pct(3,2,1),"Ghi nhận trao đổi"]
];
const tasks=[
["B1.1","Xây dựng kế hoạch tháng, tuần","Có đủ hoạt động học, ngoài trời, góc, trải nghiệm theo kế hoạch được duyệt.","Kế hoạch lớp"],
["B1.2","Tổ chức hoạt động học","Thực hiện đầy đủ số hoạt động trong kế hoạch; không tổ chức hình thức.","Kế hoạch; kiểm tra lớp"],
["B1.2","Tổ chức hoạt động ngoài trời","Đủ số hoạt động theo lịch tuần; bảo đảm an toàn. Khi thời tiết không phù hợp, điều chỉnh nội dung và ghi lý do.","Lịch tuần; kiểm tra thực tế"],
["B1.2","Tổ chức hoạt động góc","Đủ số hoạt động theo lịch; chuẩn bị góc chơi, học liệu phù hợp; trẻ được lựa chọn và chơi tích cực.","Kế hoạch; quan sát góc chơi"],
["B1.2","Tổ chức hoạt động trải nghiệm","Thực hiện hoạt động theo kế hoạch được duyệt, phù hợp điều kiện lớp và lứa tuổi.","Kế hoạch; sản phẩm trẻ"],
["B2.3","Bảo đảm chất lượng hoạt động","Tổ chức lấy trẻ làm trung tâm; đánh giá theo 10 chỉ báo của 2 lượt quan sát hiện có.","Phiếu quan sát"],
["B1.3/B2.4","Hồ sơ lớp, theo dõi và đánh giá trẻ","Cập nhật đúng tiến độ theo trách nhiệm; không phát sinh hồ sơ hình thức.","Hồ sơ lớp"],
["B2.1/B2.2","An toàn, chăm sóc ăn, ngủ, vệ sinh","Thực hiện đúng quy trình và bảo đảm an toàn thể chất, tinh thần của trẻ.","Sổ lớp; bảng kiểm"],
["B1.4","Viết tin bài truyền thông nhóm lớp","Đề xuất 01 tin/bài ngắn/nhóm lớp/tháng; phản ánh hoạt động thực tế, nộp đầu mối được giao.","Bản tin; xác nhận nhận bài"],
["B1.4","Video hoạt động phục vụ kho học liệu số","Đề xuất 01 video ngắn/nhóm lớp/tháng; luân phiên 4 chủ đề, nộp kho học liệu sau kiểm tra nội dung.","Tệp video; danh mục học liệu"],
["A4.2","Ứng dụng hoặc cải tiến học liệu số","Khi có cải tiến thực chất: vận dụng video, học liệu số và ghi nhận hiệu quả. Nộp video thông thường không tự được 2 điểm.","Sản phẩm; ghi nhận vận dụng"],
["B4.3","Phối hợp cha mẹ trẻ và bảo mật","Trao đổi qua kênh phù hợp; chỉ dùng hình ảnh trẻ khi đủ điều kiện và được nhà trường chấp thuận.","Sổ liên lạc"],
["B1.4/B3.3","Nhiệm vụ huy động hoặc phong trào phát sinh","Thực hiện khi có phân công hợp lệ; huy động trẻ ghi chưa đạt/đạt/vượt theo chỉ tiêu tháng.","Phiếu giao việc"]
];
const E=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
const G=(a,b,t,s)=>[a,b,t,s];
function rows(){const body=[],merge=[],dv=[];const L="ABCDEFG";function add(h,groups){let i=body.length+1,c=Array.from({length:7},()=>({v:"",s:0}));for(const [f,l,v,s] of groups){for(let j=f;j<=l;j++)c[j]={v:j===f?v:"",s};if(l>f)merge.push(L[f]+i+":"+L[l]+i)}body.push('<row r="'+i+'" ht="'+h+'" customHeight="1">'+c.map((v,j)=>{const a=L[j]+i;if(v.v&&typeof v.v==="object"&&v.v.f!==undefined)return'<c r="'+a+'" s="'+v.s+'"><f>'+E(v.v.f)+'</f><v></v></c>';if(typeof v.v==="number")return'<c r="'+a+'" s="'+v.s+'" t="n"><v>'+v.v+'</v></c>';if(v.v===""||v.v==null)return'<c r="'+a+'" s="'+v.s+'"/>';return'<c r="'+a+'" s="'+v.s+'" t="inlineStr"><is><t xml:space="preserve">'+E(v.v)+'</t></is></c>'}).join("")+'</row>');return i}return{add,body,merge,dv,get n(){return body.length}}}
function xmlSheet(x,widths,breaks=[]){const w=widths.map((n,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+n+'" customWidth="1"/>').join("");
const m=x.merge.length?'<mergeCells count="'+x.merge.length+'">'+x.merge.map(v=>'<mergeCell ref="'+v+'"/>').join("")+'</mergeCells>':"";
const d=x.dv.length?'<dataValidations count="'+x.dv.length+'">'+x.dv.map(v=>'<dataValidation type="list" allowBlank="1" sqref="F'+v.row+':G'+v.row+'"><formula1>"'+v.values.join(",")+'"</formula1></dataValidation>').join("")+'</dataValidations>':"";
const br=breaks.length?'<rowBreaks count="'+breaks.length+'" manualBreakCount="'+breaks.length+'">'+breaks.map(n=>'<brk id="'+n+'" min="0" max="16383" man="1"/>').join("")+'</rowBreaks>':"";
return{xml:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:G'+x.n+'"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>'+w+'</cols><sheetData>'+x.body.join("")+'</sheetData>'+m+d+'<printOptions horizontalCentered="1" gridLines="0" headings="0"/><pageMargins left="0.23" right="0.23" top="0.28" bottom="0.28" header="0.1" footer="0.12"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/><headerFooter><oddFooter>&amp;CTrường Mầm non An Bình - Trang &amp;P</oddFooter></headerFooter>'+br+'</worksheet>',last:x.n}}
function heading(x,text,month){x.add(19,[G(0,6,"UBND PHƯỜNG AN BÌNH – TRƯỜNG MẦM NON AN BÌNH",1)]);x.add(29,[G(0,6,text+" – THÁNG "+month.join("/")+" | NĂM HỌC 2026–2027",2)]);x.add(22,[G(0,3,"Họ tên giáo viên: ........................................",1),G(4,6,"Lớp: ..............................",1)]);}
function taskSheet(m){const x=rows();heading(x,"PHIẾU GIAO VIỆC KPI",m);x.add(22,[G(0,6,"Đầu việc được cụ thể hóa theo mã KPI gốc; cùng mã không cộng điểm lặp. BGH xác nhận chỉ tiêu, thời hạn trước khi áp dụng.",9)]);x.add(23,[G(0,0,"STT",4),G(1,1,"Mã KPI",4),G(2,2,"Đầu việc cần thực hiện",4),G(3,3,"Yêu cầu cần đạt",4),G(4,4,"Minh chứng",4),G(5,5,"Thực tế",4),G(6,6,"Xác nhận",4)]);
tasks.forEach((t,i)=>{let q=t.slice();if(i===9)q[2]="Đề xuất 01 video/nhóm lớp/tháng; chủ đề gợi ý kỳ này: "+topic[Number(choose.value)%4]+". Tư liệu từ hoạt động thật, nộp kho số; công khai khi được duyệt.";x.add(47,[G(0,0,i+1,6),G(1,1,q[0],6),G(2,2,q[1],5),G(3,3,q[2],5),G(4,4,q[3],5),G(5,5,"",7),G(6,6,"",7)])});
x.add(31,[G(0,6,"Lưu ý: Định mức 01 tin và 01 video/lớp/tháng là ĐỀ XUẤT. Giao nhiệm vụ chung của lớp; không bắt mỗi cô nộp riêng. Không quay/đăng khi thiếu điều kiện bảo vệ trẻ.",9)]);
x.add(30,[G(0,6,"Ngoài trời: không đủ điều kiện an toàn thì điều chỉnh hợp lý, ghi lý do. Không buộc quay video từng tiết; ưu tiên hoạt động thật và minh chứng sẵn có.",9)]);
x.add(20,[G(0,2,"GIÁO VIÊN",10),G(3,4,"TỔ TRƯỞNG",10),G(5,6,"BAN GIÁM HIỆU",10)]);
x.add(36,[G(0,2,"(Ký, ghi họ tên)",10),G(3,4,"(Ký, ghi họ tên)",10),G(5,6,"(Ký, ghi họ tên)",10)]);
return xmlSheet(x,[7,15,37,62,27,15,15])}
function scoring(m,what){const x=rows(),data=what==="A"?A:B;heading(x,"PHIẾU CHẤM KPI PHẦN "+what,m);x.add(21,[G(0,6,what==="A"?"A – TIÊU CHÍ CHUNG: 30 ĐIỂM":"B – KẾT QUẢ THỰC HIỆN NHIỆM VỤ: 70 ĐIỂM",3)]);x.add(25,[G(0,0,"Mã",4),G(1,1,"Tiêu chí",4),G(2,2,"Tối đa",4),G(3,3,"Các mức điểm chuẩn của Quy chế",4),G(4,4,"Minh chứng",4),G(5,5,"Tự chấm",4),G(6,6,"BGH chấm",4)]);
let first=x.n+1;data.forEach(t=>{const r=x.add(what==="A"?60:59,[G(0,0,t[0],6),G(1,1,t[1],5),G(2,2,t[2],6),G(3,3,t[3].map(v=>v[0]+" điểm: "+v[1]).join("\n"),5),G(4,4,t[4],5),G(5,5,"",7),G(6,6,"",7)]);x.dv.push({row:r,values:[...new Set(t[3].map(v=>v[0]))]})});
const last=x.n,max=what==="A"?30:70;const summary=x.add(29,[G(0,1,"TỔNG PHẦN "+what,8),G(2,2,max,8),G(3,4,"Chỉ tổng hợp khi đã nhập đủ "+data.length+" tiêu chí.",8),G(5,5,{f:'IF(COUNT(F'+first+':F'+last+')='+data.length+',SUM(F'+first+':F'+last+'),"")'},8),G(6,6,{f:'IF(COUNT(G'+first+':G'+last+')='+data.length+',SUM(G'+first+':G'+last+'),"")'},8)]);
x.add(32,[G(0,6,what==="A"?"A4.2 vẫn chấm theo hiệu quả cải tiến; nộp video thông thường không tự động đạt 2 điểm. A1.2 có ngưỡng cần được nhà trường làm rõ trước khi chấm.":"B1.2 đánh giá đủ hoạt động theo kế hoạch; B2.3 đánh giá chất lượng 2 lượt quan sát; B1.4 có truyền thông theo phân công. Không thêm điểm.",9)]);
x.add(20,[G(0,2,"GIÁO VIÊN",10),G(3,4,"TỔ TRƯỞNG",10),G(5,6,"BAN GIÁM HIỆU",10)]);
x.add(35,[G(0,2,"(Ký, ghi họ tên)",10),G(3,4,"(Ký, ghi họ tên)",10),G(5,6,"(Ký, ghi họ tên)",10)]);
return{...xmlSheet(x,[10,38,10,63,26,13,13],what==="B"?[12]:[]),summary,first,last,count:data.length}}
function totalSheet(m,a,b){const x=rows();heading(x,"BẢNG TỔNG HỢP KPI",m);x.add(25,[G(0,6,"Phiếu tự cộng điểm sau khi đã chấm đủ tiêu chí phần A và B.",9)]);x.add(25,[G(0,2,"Nhóm tiêu chí",4),G(3,4,"Tối đa",4),G(5,5,"Tự chấm",4),G(6,6,"BGH chấm",4)]);
x.add(35,[G(0,2,"A – Tiêu chí chung",5),G(3,4,30,6),G(5,5,{f:"IF('02_CHAM_A'!F"+a.summary+'="","",\'02_CHAM_A\'!F'+a.summary+")"},7),G(6,6,{f:"IF('02_CHAM_A'!G"+a.summary+'="","",\'02_CHAM_A\'!G'+a.summary+")"},7)]);
x.add(35,[G(0,2,"B – Kết quả nhiệm vụ",5),G(3,4,70,6),G(5,5,{f:"IF('03_CHAM_B'!F"+b.summary+'="","",\'03_CHAM_B\'!F'+b.summary+")"},7),G(6,6,{f:"IF('03_CHAM_B'!G"+b.summary+'="","",\'03_CHAM_B\'!G'+b.summary+")"},7)]);
x.add(38,[G(0,2,"TỔNG KPI",8),G(3,4,100,8),G(5,5,{f:'IF(COUNT(F6:F7)=2,SUM(F6:F7),"")'},8),G(6,6,{f:'IF(COUNT(G6:G7)=2,SUM(G6:G7),"")'},8)]);
x.add(28,[G(0,6,"Tổng điểm tối đa không đổi: 100. Việc xếp loại chính thức phải đáp ứng các điều kiện của Quy chế và pháp luật.",9)]);
x.add(36,[G(0,6,"Nhận xét: ...................................................................................................................................................",5)]);
x.add(36,[G(0,6,"Nội dung cần hỗ trợ, khắc phục: ..................................................................................................................",5)]);
x.add(20,[G(0,2,"GIÁO VIÊN",10),G(3,4,"TỔ TRƯỞNG",10),G(5,6,"BAN GIÁM HIỆU",10)]);
x.add(45,[G(0,2,"(Ký, ghi họ tên)",10),G(3,4,"(Ký, ghi họ tên)",10),G(5,6,"(Ký, ghi họ tên)",10)]);
return xmlSheet(x,[10,28,20,23,24,18,18])}
function styles(){const fonts=['<font><sz val="9"/><name val="Times New Roman"/><color rgb="FF26384B"/></font>','<font><sz val="10"/><b/><name val="Times New Roman"/><color rgb="FF133A5C"/></font>','<font><sz val="14"/><b/><name val="Times New Roman"/><color rgb="FF133A5C"/></font>','<font><sz val="9"/><b/><name val="Times New Roman"/><color rgb="FFFFFFFF"/></font>'];
const fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>',...["FF163B5A","FFEAF2F8","FFFFF2D3"].map(v=>'<fill><patternFill patternType="solid"><fgColor rgb="'+v+'"/><bgColor indexed="64"/></patternFill></fill>')];
const border=['<border><left/><right/><top/><bottom/><diagonal/></border>','<border><left style="thin"><color rgb="FFB4C4CF"/></left><right style="thin"><color rgb="FFB4C4CF"/></right><top style="thin"><color rgb="FFB4C4CF"/></top><bottom style="thin"><color rgb="FFB4C4CF"/></bottom><diagonal/></border>'];
const xfs=[[0,0,0,"left"],[1,0,0,"left"],[2,0,0,"center"],[3,2,0,"left"],[3,2,1,"center"],[0,0,1,"left"],[1,0,1,"center"],[0,4,1,"center"],[1,3,1,"center"],[0,3,0,"left"],[1,0,0,"center"]].map(v=>'<xf numFmtId="0" fontId="'+v[0]+'" fillId="'+v[1]+'" borderId="'+v[2]+'" xfId="0" applyAlignment="1"><alignment horizontal="'+v[3]+'" vertical="center" wrapText="1"/></xf>');
return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="4">'+fonts.join("")+'</fonts><fills count="5">'+fills.join("")+'</fills><borders count="2">'+border.join("")+'</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellStyleXfs><cellXfs count="'+xfs.length+'">'+xfs.join("")+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'}
const u16=(a,n)=>a.push(n&255,(n>>>8)&255),u32=(a,n)=>a.push(n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255);
function crc32(d){let c=0xffffffff;for(const v of d){c^=v;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0)}return(c^0xffffffff)>>>0}
function zip(files){const enc=new TextEncoder(),local=[],cent=[];let offset=0;
for(const [name,data] of files){const n=enc.encode(name),d=enc.encode(data),crc=crc32(d),h=[];u32(h,0x04034b50);u16(h,20);u16(h,0x800);u16(h,0);u16(h,0);u16(h,0);u32(h,crc);u32(h,d.length);u32(h,d.length);u16(h,n.length);u16(h,0);const lh=new Uint8Array(h);local.push(lh,n,d);const c=[];u32(c,0x02014b50);u16(c,20);u16(c,20);u16(c,0x800);u16(c,0);u16(c,0);u16(c,0);u32(c,crc);u32(c,d.length);u32(c,d.length);u16(c,n.length);u16(c,0);u16(c,0);u16(c,0);u16(c,0);u32(c,0);u32(c,offset);cent.push(new Uint8Array(c),n);offset+=lh.length+n.length+d.length}
const size=cent.reduce((s,v)=>s+v.length,0),end=[];u32(end,0x06054b50);u16(end,0);u16(end,0);u16(end,files.length);u16(end,files.length);u32(end,size);u32(end,offset);u16(end,0);
return new Blob([...local,...cent,new Uint8Array(end)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})}
function workbook(sheets){let content=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'];
sheets.forEach((s,i)=>content.push('<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'));content.push("</Types>");
const book='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+sheets.map((s,i)=>'<sheet name="'+E(s.name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join("")+'</sheets><definedNames>'+sheets.map((s,i)=>'<definedName name="_xlnm.Print_Area" localSheetId="'+i+'">&apos;'+s.name+'&apos;!$A$1:$G

## 4. Cách triển khai để giáo viên dễ đồng thuận

Bạn có thể sử dụng lời giải thích ngắn sau trong cuộc họp chuyên môn:

> **writing · document**
>
> Nhà trường bổ sung hướng dẫn thực hiện một số đầu việc trong phiếu KPI hằng tháng nhằm nâng cao chất lượng tổ chức hoạt động giáo dục, công tác truyền thông và xây dựng kho học liệu số.
>
> Đối với hoạt động ngoài trời và hoạt động góc, giáo viên thực hiện theo kế hoạch giáo dục đã được phê duyệt, phù hợp điều kiện thực tế và bảo đảm an toàn cho trẻ. Đối với công tác truyền thông, mỗi nhóm lớp phối hợp xây dựng tin bài, video ngắn từ những hoạt động thực tế, theo kế hoạch và sự phân công của nhà trường.
>
> Việc thực hiện không yêu cầu giáo viên tổ chức thêm hoạt động chỉ để quay phim, chụp ảnh; không yêu cầu mỗi giáo viên nộp sản phẩm riêng. Nhà trường hướng dẫn, hỗ trợ về kỹ thuật và kiểm duyệt nội dung trước khi đăng tải.
>
> Các nội dung trên được theo dõi trong những tiêu chí KPI hiện có; **không bổ sung điểm, không thay đổi mức điểm, không làm tăng tổng điểm KPI 100 điểm**. Việc đánh giá căn cứ vào nhiệm vụ thực tế, kết quả thực hiện và minh chứng phù hợp.

**Khuyến nghị:** Khi triển khai, nên giao chỉ tiêu truyền thông theo **nhóm lớp** và phân công luân phiên giữa các giáo viên. Nhà trường chịu trách nhiệm quản lý kho học liệu số, duyệt nội dung và quyết định việc công khai hình ảnh, video của trẻ. Đây là cách vừa bảo đảm hoạt động được thực hiện thường xuyên, vừa tránh biến KPI thành áp lực làm hồ sơ hoặc quay dựng video.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.+s.last+'</definedName>').join("")+'</definedNames><calcPr calcMode="auto" fullCalcOnLoad="1"/></workbook>';
const rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((s,i)=>'<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join("")+'<Relationship Id="rId'+(sheets.length+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
const files=[["[Content_Types].xml",content.join("")],["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],["xl/workbook.xml",book],["xl/_rels/workbook.xml.rels",rels],["xl/styles.xml",styles()]];sheets.forEach((s,i)=>files.push(["xl/worksheets/sheet"+(i+1)+".xml",s.xml]));
const parser=new DOMParser();for(const [name,src] of files){if(parser.parseFromString(src,"application/xml").getElementsByTagName("parsererror").length)throw Error("Dữ liệu XML không hợp lệ trong "+name)}
return zip(files)}
root.querySelector("[data-export]").addEventListener("click",()=>{
const status=root.querySelector("[data-status]");
try{
status.textContent="Đang xây dựng phiếu, giữ nguyên các mức điểm...";
if(A.reduce((s,v)=>s+v[2],0)!==30||B.reduce((s,v)=>s+v[2],0)!==70)throw Error("Sai tổng điểm");
const m=months[Number(choose.value)],tasksFile=taskSheet(m),aa=scoring(m,"A"),bb=scoring(m,"B"),total=totalSheet(m,aa,bb);
const blob=workbook([{name:"01_GIAO_VIEC",...tasksFile},{name:"02_CHAM_A",...aa},{name:"03_CHAM_B",...bb},{name:"04_TONG_HOP",...total}]);
if(blob.size<4000)throw Error("Dung lượng tệp không hợp lệ");
const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="MNAB_KPI_GV_BO_SUNG_TRUYEN_THONG_NGOAI_TROI_GOC_"+m.join("-")+".xlsx";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
status.textContent="Đã tạo tệp ("+Math.round(blob.size/1024)+" KB). Mở bằng Excel và kiểm tra Print Preview A4 ngang trước khi in.";
}catch(err){status.textContent="Chưa tạo được tệp: "+String(err.message||err)}
});
})();
</script>

```

## 4. Cách triển khai để giáo viên dễ đồng thuận

Bạn có thể sử dụng lời giải thích ngắn sau trong cuộc họp chuyên môn:

> **writing · document**
>
> Nhà trường bổ sung hướng dẫn thực hiện một số đầu việc trong phiếu KPI hằng tháng nhằm nâng cao chất lượng tổ chức hoạt động giáo dục, công tác truyền thông và xây dựng kho học liệu số.
>
> Đối với hoạt động ngoài trời và hoạt động góc, giáo viên thực hiện theo kế hoạch giáo dục đã được phê duyệt, phù hợp điều kiện thực tế và bảo đảm an toàn cho trẻ. Đối với công tác truyền thông, mỗi nhóm lớp phối hợp xây dựng tin bài, video ngắn từ những hoạt động thực tế, theo kế hoạch và sự phân công của nhà trường.
>
> Việc thực hiện không yêu cầu giáo viên tổ chức thêm hoạt động chỉ để quay phim, chụp ảnh; không yêu cầu mỗi giáo viên nộp sản phẩm riêng. Nhà trường hướng dẫn, hỗ trợ về kỹ thuật và kiểm duyệt nội dung trước khi đăng tải.
>
> Các nội dung trên được theo dõi trong những tiêu chí KPI hiện có; **không bổ sung điểm, không thay đổi mức điểm, không làm tăng tổng điểm KPI 100 điểm**. Việc đánh giá căn cứ vào nhiệm vụ thực tế, kết quả thực hiện và minh chứng phù hợp.

**Khuyến nghị:** Khi triển khai, nên giao chỉ tiêu truyền thông theo **nhóm lớp** và phân công luân phiên giữa các giáo viên. Nhà trường chịu trách nhiệm quản lý kho học liệu số, duyệt nội dung và quyết định việc công khai hình ảnh, video của trẻ. Đây là cách vừa bảo đảm hoạt động được thực hiện thường xuyên, vừa tránh biến KPI thành áp lực làm hồ sơ hoặc quay dựng video.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

Tôi đã xác định cách đưa vào phiếu mà không chồng chéo điểm: **B1.2 kiểm tra có tổ chức hoạt động hay không; B2.3 kiểm tra chất lượng hoạt động; B1.4 theo dõi tin bài và video đã giao**. Tôi sẽ giữ toàn bộ thang chấm A và B đang dùng, chỉ bổ sung các dòng đầu việc và minh chứng, đồng thời ghi rõ một nhóm lớp cùng thực hiện để tránh tăng việc cho từng giáo viên.

---

USER

ít nhất 2 video , 01 tin/bài ngắnsử dụng tư liệu từ hoạt động giáo dục thực tế. Chủ đề video luân phiên giữa hoạt động học, hoạt động ngoài trời, hoạt động góc và hoạt động trải nghiệm; không yêu cầu quay đủ bốn loại trong một tháng. Điều chỉnh và hoàn chỉnh file excel giúp mình

---

ASSISTANT

Tôi sẽ điều chỉnh file KPI giáo viên theo đúng định mức bạn vừa chốt:

- **Mỗi nhóm/lớp: ít nhất 02 video và 01 tin/bài ngắn trong tháng**, sử dụng tư liệu từ hoạt động giáo dục thực tế.
- Hai video lựa chọn luân phiên từ bốn nội dung: hoạt động học, hoạt động ngoài trời, hoạt động góc và hoạt động trải nghiệm. **Không bắt buộc thực hiện đủ bốn chủ đề trong một tháng.**
- Sản phẩm được nộp, cập nhật vào **kho học liệu số của nhà trường**; chỉ đăng công khai khi đã được kiểm duyệt và bảo đảm quyền riêng tư của trẻ.

Trong phiếu KPI, tôi giữ nguyên **B1.4 tối đa 3 điểm**, bổ sung ba sản phẩm truyền thông thành các đầu việc có thể kiểm tra. Các mục B1.2, B2.3 và A4.2 vẫn giữ nguyên điểm và thang chấm. **Tổng KPI không thay đổi: 100 điểm.**

## 📥 File Excel KPI giáo viên đã bổ sung chỉ tiêu truyền thông

Tôi bố trí thêm một trang tính **“Theo dõi truyền thông”** để ghi riêng kết quả của 01 tin/bài và 02 video, có cột chủ đề, đường dẫn học liệu, tình trạng nộp và xác nhận. Phần giao việc cũng ghi rõ từng sản phẩm, giúp tổ trưởng dễ kiểm tra vào cuối tháng.

## Excel KPI giáo viên – 2 video và 1 tin/bài mỗi tháng

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="mnab-media-v4" class="w-full space-y-3">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="font-semibold">TRƯỜNG MẦM NON AN BÌNH</div>
    <div class="text-sm opacity-70">Phiếu KPI giáo viên năm học 2026–2027 · In A4 ngang</div>
    <label class="flex flex-col gap-1 text-sm">
      <span class="font-medium">Chọn tháng</span>
      <select data-month class="w-full rounded-lg border p-2 bg-transparent"></select>
    </label>
    <div class="grid grid-cols-3 gap-2 text-center">
      <div class="border rounded-lg p-2"><div class="text-lg font-semibold">02</div><div class="text-xs opacity-70">Video tối thiểu</div></div>
      <div class="border rounded-lg p-2"><div class="text-lg font-semibold">01</div><div class="text-xs opacity-70">Tin/bài ngắn</div></div>
      <div class="border rounded-lg p-2"><div class="text-lg font-semibold">100</div><div class="text-xs opacity-70">Điểm KPI tối đa</div></div>
    </div>
    <div class="text-sm rounded-lg p-3 bg-black/5 dark:bg-white/5 space-y-1">
      <div class="font-medium">File gồm 5 trang tính</div>
      <div>01 · Giao việc chi tiết theo tháng</div>
      <div>02 · Theo dõi 2 video và 1 tin/bài</div>
      <div>03 · Chấm 9 tiêu chí A – 30 điểm</div>
      <div>04 · Chấm 14 tiêu chí B – 70 điểm</div>
      <div>05 · Tổng hợp KPI – 100 điểm</div>
      <div class="text-xs opacity-70 pt-1" data-topic></div>
    </div>
    <button data-download class="w-full rounded-lg bg-blue-700 text-white font-semibold p-3 cursor-pointer">Tạo và tải file Excel hoàn chỉnh (.xlsx)</button>
    <p class="text-xs opacity-70" data-status role="status">Các ô kết quả thực tế và chấm điểm được để trống để nhà trường cập nhật.</p>
  </div>
</div>
<script>
(function(){
const root=document.getElementById("mnab-media-v4");if(!root||root.dataset.done)return;root.dataset.done="1";
const months=[["09","2026"],["10","2026"],["11","2026"],["12","2026"],["01","2027"],["02","2027"],["03","2027"],["04","2027"],["05","2027"],["06","2027"],["07","2027"],["08","2027"]];
const pairs=[
["Hoạt động học","Hoạt động ngoài trời"],["Hoạt động góc","Hoạt động trải nghiệm"],
["Hoạt động ngoài trời","Hoạt động góc"],["Hoạt động học","Hoạt động trải nghiệm"],
["Hoạt động góc","Hoạt động ngoài trời"],["Hoạt động học","Hoạt động trải nghiệm"],
["Hoạt động ngoài trời","Hoạt động trải nghiệm"],["Hoạt động học","Hoạt động góc"],
["Hoạt động trải nghiệm","Hoạt động góc"],["Hoạt động học","Hoạt động ngoài trời"],
["Hoạt động góc","Hoạt động trải nghiệm"],["Hoạt động học","Hoạt động ngoài trời"]
];
const sel=root.querySelector("[data-month]");months.forEach((m,i)=>{let o=document.createElement("option");o.value=i;o.textContent="Tháng "+m.join("/");sel.appendChild(o)});sel.value="2";
const topic=root.querySelector("[data-topic]");
function preview(){const i=+sel.value;topic.textContent="Gợi ý chủ đề hai video tháng "+months[i].join("/")+": "+pairs[i].join(" và ")+". Có thể điều chỉnh theo hoạt động thực tế."}
sel.addEventListener("change",preview);preview();
const P=(a,b,c)=>[[a,"Hoàn thành 100% nhiệm vụ được giao"],[b,"Từ 90% đến dưới 100%"],[c,"Từ 70% đến dưới 90%"],[0,"Dưới 70%"]];
const A=[
["A1.1","Đạo đức nhà giáo, tôn trọng trẻ",6,[[6,"Không vi phạm"],[4,"1 sai sót giao tiếp nhẹ, khắc phục ngay"],[2,"2 sai sót nhẹ"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh"]],"Quan sát, biên bản"],
["A1.2","Chấp hành pháp luật, quy chế và nội quy",5,[[5,"Không vi phạm"],[4,"1 vi phạm nhẹ"],[2,"2–3 vi phạm nhẹ (theo Quy chế)"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh"]],"Biên bản kiểm tra"],
["A1.3","Trung thực hồ sơ, bảo mật thông tin trẻ",4,[[4,"Đúng, đầy đủ"],[3,"1 sai sót không cố ý, sửa ngay"],[1,"2 sai sót"],[0,"Từ 3 sai sót hoặc cố ý sai lệch, tiết lộ thông tin"]],"Hồ sơ, dữ liệu"],
["A2.1","Chủ động thực hiện nhiệm vụ, báo cáo khó khăn",4,[[4,"Chủ động, không phải nhắc"],[3,"1 lần phải nhắc"],[1,"2 lần phải nhắc"],[0,"Từ 3 lần nhắc hoặc từ chối nhiệm vụ hợp lệ"]],"Ghi nhận tổ trưởng"],
["A2.2","Hợp tác, đoàn kết, phối hợp",3,[[3,"Phối hợp đầy đủ"],[2,"1 lần chưa phối hợp, phải nhắc"],[1,"2 lần phải nhắc"],[0,"Từ 3 lần hoặc gây mất đoàn kết được xác minh"]],"Biên bản, công việc phối hợp"],
["A3.1","Chấp hành giờ làm việc, nhận lớp, bàn giao",2,[[2,"Đúng giờ; nghỉ hợp lệ không tính là vi phạm"],[1,"1 lần vi phạm thời gian làm việc"],[0,"Từ 2 lần vi phạm thời gian làm việc"]],"Bảng công, lịch trực"],
["A3.2","Trang phục, tác phong, giao tiếp sư phạm",2,[[2,"Thực hiện đúng"],[1,"1 sai sót nhẹ, đã khắc phục"],[0,"Từ 2 sai sót hoặc vi phạm nghiêm trọng"]],"Kiểm tra thực tế"],
["A4.1","Tự học, bồi dưỡng và vận dụng",2,[[2,"Có ít nhất 1 nội dung được vận dụng"],[1,"Có học, chưa có minh chứng vận dụng"],[0,"Không có minh chứng theo yêu cầu"]],"Sản phẩm bồi dưỡng"],
["A4.2","CNTT, STEAM, AI hoặc cải tiến phương pháp",2,[[2,"Có ít nhất 1 cải tiến áp dụng, chứng minh hiệu quả"],[1,"Có thử nghiệm, chưa đánh giá hiệu quả"],[0,"Không có cải tiến được ghi nhận"]],"Giáo án, học liệu, sản phẩm số"]
];
const B=[
["B1.1","Kế hoạch giáo dục tháng, tuần",5,P(5,4,2),"Kế hoạch giáo dục"],
["B1.2","Tổ chức hoạt động học, ngoài trời, góc, trải nghiệm và chăm sóc theo kế hoạch",8,P(8,6,3),"Kế hoạch, quan sát thực tế"],
["B1.3","Hồ sơ chuyên môn, hồ sơ lớp, theo dõi trẻ",4,P(4,3,1),"Hồ sơ lớp, phiếu kiểm tra"],
["B1.4","Nhiệm vụ chung; huy động trẻ và sản phẩm truyền thông được giao",3,P(3,2,1),"Phân công, danh sách trẻ, tin bài và 2 video"],
["B2.1","Bảo đảm an toàn thể chất, tinh thần của trẻ",10,[[10,"Không sai sót"],[7,"1 sai sót thủ tục nhẹ, khắc phục ngay, chưa nguy hiểm"],[3,"2 sai sót nhẹ, đã khắc phục"],[0,"Từ 3 sai sót hoặc vi phạm an toàn nghiêm trọng"]],"Bảng kiểm an toàn"],
["B2.2","Chăm sóc vệ sinh, ăn, ngủ, theo dõi sức khỏe",7,[[7,"Đúng quy trình, không sai sót"],[5,"1 sai sót nhẹ"],[2,"2–3 sai sót nhẹ"],[0,"Từ 4 sai sót hoặc vi phạm nghiêm trọng"]],"Sổ lớp, kiểm tra"],
["B2.3","Giáo dục lấy trẻ làm trung tâm, chất lượng hoạt động góc và ngoài trời",8,[[8,"Đạt 9–10/10 chỉ báo quan sát"],[6,"Đạt 7–8/10 chỉ báo"],[3,"Đạt 5–6/10 chỉ báo"],[0,"Đạt 0–4/10 chỉ báo"]],"Phiếu quan sát 2 lượt"],
["B2.4","Theo dõi, đánh giá sự phát triển và hỗ trợ trẻ",5,P(5,4,2),"Hồ sơ theo dõi"],
["B3.1","Nộp hồ sơ, kế hoạch, báo cáo đúng hạn",4,[[4,"100% đúng hạn"],[3,"1 lần trễ không quá 1 ngày"],[1,"2 lần trễ hoặc 1 lần trễ quá 1 ngày"],[0,"Từ 3 lần trễ hoặc không nộp nhiệm vụ bắt buộc"]],"Lịch nộp hồ sơ"],
["B3.2","Tiến độ chuẩn bị, tổ chức và hoàn thành công việc",4,[[4,"100% đúng hạn"],[3,"Từ 90% đến dưới 100%"],[1,"Từ 70% đến dưới 90%"],[0,"Dưới 70%"]],"Kế hoạch, lịch công tác"],
["B3.3","Thực hiện nhiệm vụ đột xuất đúng thời hạn",2,[[2,"Tất cả nhiệm vụ đúng hạn"],[1,"1 nhiệm vụ chậm không quá 1 ngày"],[0,"Từ 2 nhiệm vụ chậm hoặc không thực hiện nhiệm vụ hợp lệ"]],"Phiếu giao việc"],
["B4.1","Sinh hoạt chuyên môn, bồi dưỡng và chia sẻ",4,[[4,"Đủ buổi, có ý kiến hoặc sản phẩm vận dụng"],[3,"Đủ buổi, chưa có minh chứng trao đổi/vận dụng"],[1,"Tham gia 50% đến dưới 100% số buổi"],[0,"Dưới 50% không có lý do chính đáng"]],"Biên bản sinh hoạt"],
["B4.2","Phối hợp giáo viên cùng lớp và nhân viên liên quan",3,P(3,2,1),"Sổ bàn giao"],
["B4.3","Phối hợp cha mẹ trẻ, trao đổi và hỗ trợ trẻ",3,P(3,2,1),"Ghi nhận trao đổi"]
];
const tasks=[
["B1.1","Lập kế hoạch giáo dục","Đủ kế hoạch tháng và tuần; thể hiện hoạt động học, ngoài trời, góc, trải nghiệm.","Kế hoạch lớp"],
["B1.2","Tổ chức hoạt động học","Thực hiện đủ số hoạt động đã duyệt, không tổ chức hình thức.","Kế hoạch, kiểm tra"],
["B1.2","Tổ chức hoạt động ngoài trời","Thực hiện theo lịch; bảo đảm an toàn; điều chỉnh hợp lý khi thời tiết không phù hợp.","Lịch tuần, quan sát"],
["B1.2","Tổ chức hoạt động góc","Có chuẩn bị góc chơi, học liệu; trẻ chủ động lựa chọn, tham gia.","Lịch tuần, quan sát"],
["B1.2","Tổ chức hoạt động trải nghiệm","Thực hiện theo kế hoạch phù hợp độ tuổi, điều kiện lớp.","Kế hoạch, sản phẩm"],
["B2.3","Nâng cao chất lượng hoạt động","Bảo đảm lấy trẻ làm trung tâm theo 10 chỉ báo trong 2 lượt quan sát.","Phiếu quan sát"],
["B2.1","Bảo đảm an toàn cho trẻ","Thực hiện đúng giám sát, điểm danh, đón trả; phát hiện nguy cơ.","Sổ lớp, bảng kiểm"],
["B2.2","Tổ chức ăn, ngủ và vệ sinh","Thực hiện đúng quy trình nuôi dưỡng, chăm sóc.","Kiểm tra thực tế"],
["B1.3/B2.4","Hồ sơ lớp, theo dõi và đánh giá trẻ","Cập nhật đầy đủ, chính xác và đúng hạn.","Hồ sơ chuyên môn"],
["B1.4","Viết tin/bài truyền thông của nhóm lớp","Ít nhất 01 tin/bài ngắn/tháng, sử dụng tư liệu hoạt động thực tế; gửi đầu mối được giao.","Bản tin, xác nhận nộp"],
["B1.4","Video hoạt động số 1","Ít nhất 01 video từ hoạt động thực tế; chủ đề luân phiên; cập nhật kho học liệu số.","Tệp, đường dẫn học liệu"],
["B1.4","Video hoạt động số 2","Ít nhất 01 video khác từ hoạt động thực tế; chủ đề luân phiên; cập nhật kho học liệu số.","Tệp, đường dẫn học liệu"],
["A4.2","Ứng dụng và cải tiến học liệu số","Khi có cải tiến hiệu quả thì ghi nhận; nộp đủ video không tự động đạt 2 điểm A4.2.","Sản phẩm, kết quả vận dụng"],
["B4.3","Phối hợp cha mẹ trẻ, bảo vệ thông tin","Trao đổi đúng trách nhiệm; bảo vệ quyền riêng tư và hình ảnh trẻ.","Sổ liên lạc"],
["B1.4","Huy động trẻ theo chỉ tiêu (nếu được giao)","Ghi nhận chưa đạt/đạt/vượt với nhà trẻ và từng tuổi 3, 4, 5.","Chỉ tiêu, danh sách"],
["B3.3","Hoạt động, hội thi phát sinh (nếu được giao)","Thực hiện đúng nội dung, thời hạn được phân công.","Phiếu giao việc"],
["B4.1/B4.2","Sinh hoạt chuyên môn và phối hợp đồng nghiệp","Tham gia, trao đổi, phối hợp đầy đủ theo nhiệm vụ.","Biên bản"]
];
const E=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
const C=(a,b,t,s)=>[a,b,t,s];
function makeRows(){const arr=[],merges=[],valid=[];const letters="ABCDEFG";
function add(height,blocks){let n=arr.length+1,values=Array.from({length:7},()=>({v:"",s:0}));for(const [a,b,v,s]of blocks){for(let j=a;j<=b;j++)values[j]={v:j===a?v:"",s};if(b>a)merges.push(letters[a]+n+":"+letters[b]+n)}
let xml=values.map((item,j)=>{const ref=letters[j]+n,v=item.v,s=item.s;
if(v&&typeof v==="object"&&v.f!==undefined)return'<c r="'+ref+'" s="'+s+'"><f>'+E(v.f)+'</f><v></v></c>';
if(typeof v==="number")return'<c r="'+ref+'" s="'+s+'" t="n"><v>'+v+'</v></c>';
if(v===""||v==null)return'<c r="'+ref+'" s="'+s+'"/>';
return'<c r="'+ref+'" s="'+s+'" t="inlineStr"><is><t xml:space="preserve">'+E(v)+'</t></is></c>'}).join("");
arr.push('<row r="'+n+'" ht="'+height+'" customHeight="1">'+xml+'</row>');return n}
return{add,arr,merges,valid,get count(){return arr.length}}}
function sheet(x,widths,opts={}){
const cs=widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join("");
const mc=x.merges.length?'<mergeCells count="'+x.merges.length+'">'+x.merges.map(m=>'<mergeCell ref="'+m+'"/>').join("")+'</mergeCells>':"";
const dv=x.valid.length?'<dataValidations count="'+x.valid.length+'">'+x.valid.map(v=>'<dataValidation type="list" allowBlank="1" showErrorMessage="1" error="Vui lòng chọn giá trị trong danh sách." sqref="'+v.addr+'"><formula1>"'+E(v.options.join(","))+'"</formula1></dataValidation>').join("")+'</dataValidations>':"";
const breaks=opts.breaks||[],rb=breaks.length?'<rowBreaks count="'+breaks.length+'" manualBreakCount="'+breaks.length+'">'+breaks.map(id=>'<brk id="'+id+'" min="0" max="16383" man="1"/>').join("")+'</rowBreaks>':"";
const xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:G'+x.count+'"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>'+cs+'</cols><sheetData>'+x.arr.join("")+'</sheetData>'+mc+dv+'<printOptions horizontalCentered="1" gridLines="0" headings="0"/><pageMargins left="0.22" right="0.22" top="0.24" bottom="0.25" header="0.1" footer="0.12"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="'+(opts.fitHeight===undefined?0:opts.fitHeight)+'"/><headerFooter><oddFooter>&amp;CTrường Mầm non An Bình – Trang &amp;P</oddFooter></headerFooter>'+rb+'</worksheet>';
return{xml,last:x.count,printTitle:opts.printTitle||0}}
function heading(x,title,month){
x.add(18,[C(0,6,"UBND PHƯỜNG AN BÌNH – TRƯỜNG MẦM NON AN BÌNH",1)]);
x.add(28,[C(0,6,title+" – THÁNG "+month.join("/")+" | NĂM HỌC 2026–2027",2)]);
x.add(21,[C(0,3,"Giáo viên: ..........................................................",1),C(4,6,"Nhóm/lớp: ........................................",1)]);
}
function makeTaskSheet(m){
const x=makeRows();heading(x,"PHIẾU GIAO VIỆC KPI GIÁO VIÊN",m);
x.add(23,[C(0,6,"Mỗi nhóm/lớp: ít nhất 02 video + 01 tin/bài ngắn/tháng. Các nhiệm vụ gắn với mã KPI hiện có, không tạo điểm mới.",9)]);
x.add(24,[C(0,0,"STT",4),C(1,1,"Mã KPI",4),C(2,2,"Đầu việc",4),C(3,3,"Kết quả cần đạt",4),C(4,4,"Minh chứng",4),C(5,5,"Kết quả thực tế",4),C(6,6,"Xác nhận",4)]);
const f=tasks.map(t=>t.slice());f[10][2]="Ít nhất 01 video thực tế; chủ đề gợi ý: "+pairs[months.findIndex(v=>v[0]===m[0]&&v[1]===m[1])][0]+". Nộp vào kho học liệu số.";
f[11][2]="Ít nhất 01 video thực tế khác; chủ đề gợi ý: "+pairs[months.findIndex(v=>v[0]===m[0]&&v[1]===m[1])][1]+". Nộp vào kho học liệu số.";
f.forEach((t,i)=>x.add(39,[C(0,0,i+1,6),C(1,1,t[0],6),C(2,2,t[1],5),C(3,3,t[2],5),C(4,4,t[3],5),C(5,5,"",7),C(6,6,"",7)]));
x.add(27,[C(0,6,"Lưu ý: Không yêu cầu quay đủ 4 loại hoạt động trong tháng; không buộc từng giáo viên nộp 2 video riêng. Phân công thực hiện theo nhóm/lớp.",9)]);
x.add(25,[C(0,6,"Nộp kho số khác với đăng công khai. Nội dung/hình ảnh trẻ chỉ được công khai sau kiểm duyệt và đáp ứng yêu cầu về quyền riêng tư.",9)]);
x.add(20,[C(0,2,"GIÁO VIÊN",10),C(3,4,"TỔ TRƯỞNG",10),C(5,6,"BAN GIÁM HIỆU",10)]);
x.add(32,[C(0,2,"(Ký, ghi rõ họ tên)",10),C(3,4,"(Ký, ghi rõ họ tên)",10),C(5,6,"(Ký, ghi rõ họ tên)",10)]);
return sheet(x,[7,15,37,61,27,20,16],{breaks:[13],printTitle:5})}
function makeMediaSheet(m,i){
const x=makeRows();heading(x,"BẢNG THEO DÕI SẢN PHẨM TRUYỀN THÔNG",m);
x.add(27,[C(0,6,"CHỈ TIÊU MỖI NHÓM/LỚP: 01 TIN/BÀI NGẮN VÀ ÍT NHẤT 02 VIDEO TỪ HOẠT ĐỘNG GIÁO DỤC THỰC TẾ.",3)]);
x.add(29,[C(0,6,"Hai chủ đề video gợi ý: "+pairs[i][0]+"; "+pairs[i][1]+". Có thể thay đổi luân phiên theo hoạt động thực tế của lớp; không bắt buộc đủ cả bốn chủ đề.",9)]);
x.add(28,[C(0,0,"STT",4),C(1,1,"Sản phẩm",4),C(2,2,"Nội dung/chủ đề",4),C(3,3,"Chỉ tiêu",4),C(4,4,"Đường dẫn/tên tệp kho học liệu số",4),C(5,5,"Trạng thái",4),C(6,6,"Người xác nhận",4)]);
const r1=x.add(51,[C(0,0,1,6),C(1,1,"Tin/bài ngắn",5),C(2,2,"Giới thiệu hoạt động giáo dục đã thực hiện; nội dung trung thực, phù hợp.",5),C(3,3,"Ít nhất 01",6),C(4,4,"",7),C(5,5,"",7),C(6,6,"",7)]);
const r2=x.add(51,[C(0,0,2,6),C(1,1,"Video số 1",5),C(2,2,pairs[i][0]+" (gợi ý; có thể thay đổi)",5),C(3,3,"Ít nhất 01",6),C(4,4,"",7),C(5,5,"",7),C(6,6,"",7)]);
const r3=x.add(51,[C(0,0,3,6),C(1,1,"Video số 2",5),C(2,2,pairs[i][1]+" (gợi ý; có thể thay đổi)",5),C(3,3,"Ít nhất 01",6),C(4,4,"",7),C(5,5,"",7),C(6,6,"",7)]);
const options=["Chưa nộp","Đã nộp","Chờ duyệt","Đã duyệt","Cần sửa"];
[r1,r2,r3].forEach(n=>x.valid.push({addr:"F"+n,options}));
x.add(30,[C(0,3,"SỐ SẢN PHẨM ĐÃ NỘP / CHỜ DUYỆT / ĐÃ DUYỆT",8),C(4,4,{f:'COUNTIF(F'+r1+':F'+r3+',"Đã nộp")+COUNTIF(F'+r1+':F'+r3+',"Chờ duyệt")+COUNTIF(F'+r1+':F'+r3+',"Đã duyệt")'},8),C(5,6,"Mục tiêu: 3 sản phẩm",8)]);
x.add(31,[C(0,6,"Hoàn thành đầu việc khi có sản phẩm, đường dẫn nộp và xác nhận phù hợp. Việc chờ nhà trường phê duyệt không tự xem là lỗi của giáo viên.",9)]);
x.add(32,[C(0,6,"Sản phẩm dùng hình ảnh trẻ phải đúng phạm vi cho phép; tránh tiết lộ thông tin cá nhân, tình trạng sức khỏe; đăng công khai sau khi được duyệt.",9)]);
x.add(31,[C(0,6,"Tháng hè: áp dụng khi nhóm/lớp có hoạt động và được giao nhiệm vụ; nghỉ hợp lệ không tự động bị trừ KPI.",9)]);
x.add(22,[C(0,2,"ĐẠI DIỆN NHÓM/LỚP",10),C(3,4,"NGƯỜI PHỤ TRÁCH TRUYỀN THÔNG",10),C(5,6,"BAN GIÁM HIỆU",10)]);
x.add(43,[C(0,2,"(Ký, ghi rõ họ tên)",10),C(3,4,"(Ký, ghi rõ họ tên)",10),C(5,6,"(Ký, ghi rõ họ tên)",10)]);
return sheet(x,[7,23,39,15,45,20,25],{fitHeight:1})}
function makeScoringSheet(m,part){
const x=makeRows(),data=part==="A"?A:B,max=part==="A"?30:70;
heading(x,"PHIẾU CHẤM KPI PHẦN "+part,m);
x.add(21,[C(0,6,"THANG ĐIỂM PHẦN "+part+": "+max+" ĐIỂM. Mỗi mã giữ nguyên điểm tối đa và các mức chấm theo Quy chế.",3)]);
x.add(26,[C(0,0,"Mã",4),C(1,1,"Nội dung tiêu chí",4),C(2,2,"Tối đa",4),C(3,3,"Các mức điểm theo Quy chế",4),C(4,4,"Minh chứng",4),C(5,5,"Tự chấm",4),C(6,6,"BGH chấm",4)]);
const first=x.count+1;data.forEach(t=>{
const levels=t[3].map(v=>v[0]+" điểm: "+v[1]).join("\n");
const r=x.add(62,[C(0,0,t[0],6),C(1,1,t[1],5),C(2,2,t[2],6),C(3,3,levels,5),C(4,4,t[4],5),C(5,5,"",7),C(6,6,"",7)]);
x.valid.push({addr:"F"+r+" G"+r,options:[...new Set(t[3].map(v=>String(v[0])))]})});
const last=x.count,n=data.length;
const row=x.add(30,[C(0,1,"TỔNG ĐIỂM PHẦN "+part,8),C(2,2,max,8),C(3,4,"Chỉ cộng khi có đủ "+n+" mức điểm.",8),
C(5,5,{f:'IF(COUNTA(F'+first+':F'+last+')='+n+',SUMPRODUCT(IFERROR(1*F'+first+':F'+last+',0)),"")'},8),
C(6,6,{f:'IF(COUNTA(G'+first+':G'+last+')='+n+',SUMPRODUCT(IFERROR(1*G'+first+':G'+last+',0)),"")'},8)]);
x.add(32,[C(0,6,part==="A"?"A4.2: Không tự cộng điểm cải tiến khi chỉ nộp video thông thường. Lưu ý mức 3 sai sót nhẹ của A1.2 đang có giao nhau trong Quy chế.":"B1.4: Ghi nhận đủ 2 video + 1 tin/bài cùng nhiệm vụ khác; không chấm 3 điểm riêng cho truyền thông. B1.2 kiểm tra đủ hoạt động, B2.3 kiểm tra chất lượng.",9)]);
x.add(20,[C(0,2,"NGƯỜI TỰ ĐÁNH GIÁ",10),C(3,4,"TỔ TRƯỞNG",10),C(5,6,"BAN GIÁM HIỆU",10)]);
x.add(35,[C(0,2,"(Ký, ghi rõ họ tên)",10),C(3,4,"(Ký, ghi rõ họ tên)",10),C(5,6,"(Ký, ghi rõ họ tên)",10)]);
return{...sheet(x,[10,40,10,64,28,13,13],{breaks:part==="A"?[10]:[10,15],printTitle:5}),summary:row,first,last,count:n}}
function makeSummary(m,a,b){
const x=makeRows();heading(x,"BẢNG TỔNG HỢP CHẤM KPI GIÁO VIÊN",m);
x.add(26,[C(0,6,"Điểm chỉ hiển thị khi nhập đủ toàn bộ tiêu chí; đối chiếu thang điểm chuẩn ở trang 03_CHAM_A và 04_CHAM_B.",9)]);
x.add(25,[C(0,2,"Nhóm tiêu chí",4),C(3,4,"Điểm tối đa",4),C(5,5,"Tự chấm",4),C(6,6,"BGH chấm",4)]);
x.add(34,[C(0,2,"A – Tiêu chí chung",5),C(3,4,30,6),C(5,5,{f:"IF('03_CHAM_A'!F"+a.summary+'="","",\'03_CHAM_A\'!F'+a.summary+")"},7),C(6,6,{f:"IF('03_CHAM_A'!G"+a.summary+'="","",\'03_CHAM_A\'!G'+a.summary+")"},7)]);
x.add(34,[C(0,2,"B – Kết quả thực hiện nhiệm vụ",5),C(3,4,70,6),C(5,5,{f:"IF('04_CHAM_B'!F"+b.summary+'="","",\'04_CHAM_B\'!F'+b.summary+")"},7),C(6,6,{f:"IF('04_CHAM_B'!G"+b.summary+'="","",\'04_CHAM_B\'!G'+b.summary+")"},7)]);
x.add(37,[C(0,2,"TỔNG KPI",8),C(3,4,100,8),C(5,5,{f:'IF(COUNT(F6:F7)=2,SUM(F6:F7),"")'},8),C(6,6,{f:'IF(COUNT(G6:G7)=2,SUM(G6:G7),"")'},8)]);
x.add(29,[C(0,6,"Truyền thông: 01 tin/bài và ít nhất 02 video / nhóm lớp / tháng; được kiểm tra cùng nhiệm vụ B1.4, không cộng điểm vượt 100.",9)]);
x.add(30,[C(0,6,"Kết quả vượt chỉ tiêu huy động trẻ, phong trào phát sinh: ghi nhận riêng theo Quy chế; không cộng thêm điểm vượt mức tối đa.",9)]);
x.add(31,[C(0,6,"Nhận xét, ghi nhận sản phẩm nổi bật: ..........................................................................................................................",5)]);
x.add(31,[C(0,6,"Nội dung cần cải thiện: ................................................................................................................................................",5)]);
x.add(21,[C(0,2,"GIÁO VIÊN",10),C(3,4,"TỔ TRƯỞNG",10),C(5,6,"BAN GIÁM HIỆU",10)]);
x.add(43,[C(0,2,"(Ký, ghi rõ họ tên)",10),C(3,4,"(Ký, ghi rõ họ tên)",10),C(5,6,"(Ký, ghi rõ họ tên)",10)]);
return sheet(x,[10,28,20,23,24,18,18],{fitHeight:1})}
function styles(){
const fonts=['<font><sz val="9"/><name val="Times New Roman"/><color rgb="FF233547"/></font>','<font><sz val="10"/><b/><name val="Times New Roman"/><color rgb="FF183B58"/></font>','<font><sz val="14"/><b/><name val="Times New Roman"/><color rgb="FF183B58"/></font>','<font><sz val="9"/><b/><name val="Times New Roman"/><color rgb="FFFFFFFF"/></font>'];
const fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>',...["FF193D5D","FFE9F2F8","FFFFF2D6"].map(v=>'<fill><patternFill patternType="solid"><fgColor rgb="'+v+'"/><bgColor indexed="64"/></patternFill></fill>')];
const borders=['<border><left/><right/><top/><bottom/><diagonal/></border>','<border><left style="thin"><color rgb="FFB6C5CE"/></left><right style="thin"><color rgb="FFB6C5CE"/></right><top style="thin"><color rgb="FFB6C5CE"/></top><bottom style="thin"><color rgb="FFB6C5CE"/></bottom><diagonal/></border>'];
const opts=[[0,0,0,"left"],[1,0,0,"left"],[2,0,0,"center"],[3,2,0,"left"],[3,2,1,"center"],[0,0,1,"left"],[1,0,1,"center"],[0,4,1,"left"],[1,3,1,"center"],[0,3,0,"left"],[1,0,0,"center"]];
return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="4">'+fonts.join("")+'</fonts><fills count="5">'+fills.join("")+'</fills><borders count="2">'+borders.join("")+'</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellStyleXfs><cellXfs count="'+opts.length+'">'+opts.map(o=>'<xf numFmtId="0" fontId="'+o[0]+'" fillId="'+o[1]+'" borderId="'+o[2]+'" xfId="0" applyAlignment="1"><alignment horizontal="'+o[3]+'" vertical="center" wrapText="1"/></xf>').join("")+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'}
const put16=(a,n)=>a.push(n&255,(n>>>8)&255),put32=(a,n)=>a.push(n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255);
function crc(bytes){let c=0xffffffff;for(const n of bytes){c^=n;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0)}return(c^0xffffffff)>>>0}
function zip(files){const enc=new TextEncoder(),local=[],central=[];let offset=0;
for(const [name,src]of files){const n=enc.encode(name),d=enc.encode(src),sum=crc(d),lh=[];put32(lh,0x04034b50);put16(lh,20);put16(lh,0x0800);put16(lh,0);put16(lh,0);put16(lh,0);put32(lh,sum);put32(lh,d.length);put32(lh,d.length);put16(lh,n.length);put16(lh,0);const h=new Uint8Array(lh);local.push(h,n,d);
const cd=[];put32(cd,0x02014b50);put16(cd,20);put16(cd,20);put16(cd,0x0800);put16(cd,0);put16(cd,0);put16(cd,0);put32(cd,sum);put32(cd,d.length);put32(cd,d.length);put16(cd,n.length);put16(cd,0);put16(cd,0);put16(cd,0);put16(cd,0);put32(cd,0);put32(cd,offset);central.push(new Uint8Array(cd),n);offset+=h.length+n.length+d.length}
const size=central.reduce((v,p)=>v+p.length,0),end=[];put32(end,0x06054b50);put16(end,0);put16(end,0);put16(end,files.length);put16(end,files.length);put32(end,size);put32(end,offset);put16(end,0);
return new Blob([...local,...central,new Uint8Array(end)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})}
function workbook(sheets){
const types=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'];
sheets.forEach((s,i)=>types.push('<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'));types.push("</Types>");
let names=[];sheets.forEach((s,i)=>{names.push('<definedName name="_xlnm.Print_Area" localSheetId="'+i+'">&apos;'+E(s.name)+'&apos;!$A$1:$G

**Cách áp dụng:** Mỗi tháng, tổ trưởng kiểm tra kết quả ở trang **02\_TRUYEN\_THONG** cùng các nhiệm vụ khác thuộc B1.4. Giáo viên không phải nộp video riêng cho từng người; các giáo viên trong cùng nhóm/lớp phối hợp thực hiện và phân công trách nhiệm cụ thể.

File được tạo khi bạn nhấn nút tải và có bước kiểm tra cấu trúc dữ liệu. Tôi chưa thể mở kiểm thử trực tiếp bằng Microsoft Excel trên thiết bị của bạn.

**Lưu ý trước khi chấm chính thức:** Mức “3 sai sót nhẹ” ở tiêu chí A1.2 của Quy chế đang bị trùng giữa hai mức điểm; nhà trường nên thống nhất, đính chính nội dung này để tránh cách hiểu khác nhau.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.+s.last+'</definedName>');if(s.printTitle)names.push('<definedName name="_xlnm.Print_Titles" localSheetId="'+i+'">&apos;'+E(s.name)+'&apos;!$1:

**Cách áp dụng:** Mỗi tháng, tổ trưởng kiểm tra kết quả ở trang **02\_TRUYEN\_THONG** cùng các nhiệm vụ khác thuộc B1.4. Giáo viên không phải nộp video riêng cho từng người; các giáo viên trong cùng nhóm/lớp phối hợp thực hiện và phân công trách nhiệm cụ thể.

File được tạo khi bạn nhấn nút tải và có bước kiểm tra cấu trúc dữ liệu. Tôi chưa thể mở kiểm thử trực tiếp bằng Microsoft Excel trên thiết bị của bạn.

**Lưu ý trước khi chấm chính thức:** Mức “3 sai sót nhẹ” ở tiêu chí A1.2 của Quy chế đang bị trùng giữa hai mức điểm; nhà trường nên thống nhất, đính chính nội dung này để tránh cách hiểu khác nhau.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.+s.printTitle+'</definedName>')});
const book='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'+sheets.map((s,i)=>'<sheet name="'+E(s.name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join("")+'</sheets><definedNames>'+names.join("")+'</definedNames><calcPr calcMode="auto" fullCalcOnLoad="1"/></workbook>';
const rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((s,i)=>'<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join("")+'<Relationship Id="rId'+(sheets.length+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
const files=[["[Content_Types].xml",types.join("")],["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],["xl/workbook.xml",book],["xl/_rels/workbook.xml.rels",rels],["xl/styles.xml",styles()]];
sheets.forEach((s,i)=>files.push(["xl/worksheets/sheet"+(i+1)+".xml",s.xml]));
const parser=new DOMParser();for(const [name,src]of files){if(parser.parseFromString(src,"application/xml").getElementsByTagName("parsererror").length)throw Error("Cấu trúc XML lỗi: "+name)}
return zip(files)}
root.querySelector("[data-download]").addEventListener("click",()=>{
const status=root.querySelector("[data-status]");
try{
status.textContent="Đang cập nhật đầu việc, mức điểm và kiểm tra cấu trúc Excel...";
if(A.reduce((v,t)=>v+t[2],0)!==30||B.reduce((v,t)=>v+t[2],0)!==70)throw Error("Tổng điểm không khớp Quy chế.");
const i=+sel.value,m=months[i],task=makeTaskSheet(m),media=makeMediaSheet(m,i),a=makeScoringSheet(m,"A"),b=makeScoringSheet(m,"B"),sum=makeSummary(m,a,b);
const blob=workbook([{name:"01_GIAO_VIEC",...task},{name:"02_TRUYEN_THONG",...media},{name:"03_CHAM_A",...a},{name:"04_CHAM_B",...b},{name:"05_TONG_HOP",...sum}]);
if(blob.size<7000)throw Error("Dung lượng tệp không hợp lệ.");
const url=URL.createObjectURL(blob),link=document.createElement("a");link.href=url;link.download="MNAB_KPI_GV_2_VIDEO_1_TIN_BAI_"+m.join("-")+".xlsx";document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
status.textContent="Đã tạo tệp Excel ("+Math.round(blob.size/1024)+" KB) và kiểm tra cú pháp XML. Hãy mở bằng Microsoft Excel và xem trước bản in.";
}catch(err){status.textContent="Không tạo được tệp: "+String(err.message||err)}
});
})();
</script>

```

**Cách áp dụng:** Mỗi tháng, tổ trưởng kiểm tra kết quả ở trang **02\_TRUYEN\_THONG** cùng các nhiệm vụ khác thuộc B1.4. Giáo viên không phải nộp video riêng cho từng người; các giáo viên trong cùng nhóm/lớp phối hợp thực hiện và phân công trách nhiệm cụ thể.

File được tạo khi bạn nhấn nút tải và có bước kiểm tra cấu trúc dữ liệu. Tôi chưa thể mở kiểm thử trực tiếp bằng Microsoft Excel trên thiết bị của bạn.

**Lưu ý trước khi chấm chính thức:** Mức “3 sai sót nhẹ” ở tiêu chí A1.2 của Quy chế đang bị trùng giữa hai mức điểm; nhà trường nên thống nhất, đính chính nội dung này để tránh cách hiểu khác nhau.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

## 📥 File Excel KPI giáo viên đã bổ sung chỉ tiêu truyền thông

Tôi bố trí thêm một trang tính **“Theo dõi truyền thông”** để ghi riêng kết quả của 01 tin/bài và 02 video, có cột chủ đề, đường dẫn học liệu, tình trạng nộp và xác nhận. Phần giao việc cũng ghi rõ từng sản phẩm, giúp tổ trưởng dễ kiểm tra vào cuối tháng.

<AppBlock title="Excel KPI giáo viên – 2 video và 1 tin/bài mỗi tháng" app_block_id="mnab-kpi-gv-media-2videos-final" icon="app-chatgpt" variant="inline">
<div id="mnab-media-v4" class="w-full space-y-3">
  <div class="rounded-xl border p-4 space-y-3">
    <div class="font-semibold">TRƯỜNG MẦM NON AN BÌNH</div>
    <div class="text-sm opacity-70">Phiếu KPI giáo viên năm học 2026–2027 · In A4 ngang</div>
    <label class="flex flex-col gap-1 text-sm">
      <span class="font-medium">Chọn tháng</span>
      <select data-month class="w-full rounded-lg border p-2 bg-transparent"></select>
    </label>
    <div class="grid grid-cols-3 gap-2 text-center">
      <div class="border rounded-lg p-2"><div class="text-lg font-semibold">02</div><div class="text-xs opacity-70">Video tối thiểu</div></div>
      <div class="border rounded-lg p-2"><div class="text-lg font-semibold">01</div><div class="text-xs opacity-70">Tin/bài ngắn</div></div>
      <div class="border rounded-lg p-2"><div class="text-lg font-semibold">100</div><div class="text-xs opacity-70">Điểm KPI tối đa</div></div>
    </div>
    <div class="text-sm rounded-lg p-3 bg-black/5 dark:bg-white/5 space-y-1">
      <div class="font-medium">File gồm 5 trang tính</div>
      <div>01 · Giao việc chi tiết theo tháng</div>
      <div>02 · Theo dõi 2 video và 1 tin/bài</div>
      <div>03 · Chấm 9 tiêu chí A – 30 điểm</div>
      <div>04 · Chấm 14 tiêu chí B – 70 điểm</div>
      <div>05 · Tổng hợp KPI – 100 điểm</div>
      <div class="text-xs opacity-70 pt-1" data-topic></div>
    </div>
    <button data-download class="w-full rounded-lg bg-blue-700 text-white font-semibold p-3 cursor-pointer">Tạo và tải file Excel hoàn chỉnh (.xlsx)</button>
    <p class="text-xs opacity-70" data-status role="status">Các ô kết quả thực tế và chấm điểm được để trống để nhà trường cập nhật.</p>
  </div>
</div>
<script>
(function(){
const root=document.getElementById("mnab-media-v4");if(!root||root.dataset.done)return;root.dataset.done="1";
const months=[["09","2026"],["10","2026"],["11","2026"],["12","2026"],["01","2027"],["02","2027"],["03","2027"],["04","2027"],["05","2027"],["06","2027"],["07","2027"],["08","2027"]];
const pairs=[
["Hoạt động học","Hoạt động ngoài trời"],["Hoạt động góc","Hoạt động trải nghiệm"],
["Hoạt động ngoài trời","Hoạt động góc"],["Hoạt động học","Hoạt động trải nghiệm"],
["Hoạt động góc","Hoạt động ngoài trời"],["Hoạt động học","Hoạt động trải nghiệm"],
["Hoạt động ngoài trời","Hoạt động trải nghiệm"],["Hoạt động học","Hoạt động góc"],
["Hoạt động trải nghiệm","Hoạt động góc"],["Hoạt động học","Hoạt động ngoài trời"],
["Hoạt động góc","Hoạt động trải nghiệm"],["Hoạt động học","Hoạt động ngoài trời"]
];
const sel=root.querySelector("[data-month]");months.forEach((m,i)=>{let o=document.createElement("option");o.value=i;o.textContent="Tháng "+m.join("/");sel.appendChild(o)});sel.value="2";
const topic=root.querySelector("[data-topic]");
function preview(){const i=+sel.value;topic.textContent="Gợi ý chủ đề hai video tháng "+months[i].join("/")+": "+pairs[i].join(" và ")+". Có thể điều chỉnh theo hoạt động thực tế."}
sel.addEventListener("change",preview);preview();
const P=(a,b,c)=>[[a,"Hoàn thành 100% nhiệm vụ được giao"],[b,"Từ 90% đến dưới 100%"],[c,"Từ 70% đến dưới 90%"],[0,"Dưới 70%"]];
const A=[
["A1.1","Đạo đức nhà giáo, tôn trọng trẻ",6,[[6,"Không vi phạm"],[4,"1 sai sót giao tiếp nhẹ, khắc phục ngay"],[2,"2 sai sót nhẹ"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh"]],"Quan sát, biên bản"],
["A1.2","Chấp hành pháp luật, quy chế và nội quy",5,[[5,"Không vi phạm"],[4,"1 vi phạm nhẹ"],[2,"2–3 vi phạm nhẹ (theo Quy chế)"],[0,"Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh"]],"Biên bản kiểm tra"],
["A1.3","Trung thực hồ sơ, bảo mật thông tin trẻ",4,[[4,"Đúng, đầy đủ"],[3,"1 sai sót không cố ý, sửa ngay"],[1,"2 sai sót"],[0,"Từ 3 sai sót hoặc cố ý sai lệch, tiết lộ thông tin"]],"Hồ sơ, dữ liệu"],
["A2.1","Chủ động thực hiện nhiệm vụ, báo cáo khó khăn",4,[[4,"Chủ động, không phải nhắc"],[3,"1 lần phải nhắc"],[1,"2 lần phải nhắc"],[0,"Từ 3 lần nhắc hoặc từ chối nhiệm vụ hợp lệ"]],"Ghi nhận tổ trưởng"],
["A2.2","Hợp tác, đoàn kết, phối hợp",3,[[3,"Phối hợp đầy đủ"],[2,"1 lần chưa phối hợp, phải nhắc"],[1,"2 lần phải nhắc"],[0,"Từ 3 lần hoặc gây mất đoàn kết được xác minh"]],"Biên bản, công việc phối hợp"],
["A3.1","Chấp hành giờ làm việc, nhận lớp, bàn giao",2,[[2,"Đúng giờ; nghỉ hợp lệ không tính là vi phạm"],[1,"1 lần vi phạm thời gian làm việc"],[0,"Từ 2 lần vi phạm thời gian làm việc"]],"Bảng công, lịch trực"],
["A3.2","Trang phục, tác phong, giao tiếp sư phạm",2,[[2,"Thực hiện đúng"],[1,"1 sai sót nhẹ, đã khắc phục"],[0,"Từ 2 sai sót hoặc vi phạm nghiêm trọng"]],"Kiểm tra thực tế"],
["A4.1","Tự học, bồi dưỡng và vận dụng",2,[[2,"Có ít nhất 1 nội dung được vận dụng"],[1,"Có học, chưa có minh chứng vận dụng"],[0,"Không có minh chứng theo yêu cầu"]],"Sản phẩm bồi dưỡng"],
["A4.2","CNTT, STEAM, AI hoặc cải tiến phương pháp",2,[[2,"Có ít nhất 1 cải tiến áp dụng, chứng minh hiệu quả"],[1,"Có thử nghiệm, chưa đánh giá hiệu quả"],[0,"Không có cải tiến được ghi nhận"]],"Giáo án, học liệu, sản phẩm số"]
];
const B=[
["B1.1","Kế hoạch giáo dục tháng, tuần",5,P(5,4,2),"Kế hoạch giáo dục"],
["B1.2","Tổ chức hoạt động học, ngoài trời, góc, trải nghiệm và chăm sóc theo kế hoạch",8,P(8,6,3),"Kế hoạch, quan sát thực tế"],
["B1.3","Hồ sơ chuyên môn, hồ sơ lớp, theo dõi trẻ",4,P(4,3,1),"Hồ sơ lớp, phiếu kiểm tra"],
["B1.4","Nhiệm vụ chung; huy động trẻ và sản phẩm truyền thông được giao",3,P(3,2,1),"Phân công, danh sách trẻ, tin bài và 2 video"],
["B2.1","Bảo đảm an toàn thể chất, tinh thần của trẻ",10,[[10,"Không sai sót"],[7,"1 sai sót thủ tục nhẹ, khắc phục ngay, chưa nguy hiểm"],[3,"2 sai sót nhẹ, đã khắc phục"],[0,"Từ 3 sai sót hoặc vi phạm an toàn nghiêm trọng"]],"Bảng kiểm an toàn"],
["B2.2","Chăm sóc vệ sinh, ăn, ngủ, theo dõi sức khỏe",7,[[7,"Đúng quy trình, không sai sót"],[5,"1 sai sót nhẹ"],[2,"2–3 sai sót nhẹ"],[0,"Từ 4 sai sót hoặc vi phạm nghiêm trọng"]],"Sổ lớp, kiểm tra"],
["B2.3","Giáo dục lấy trẻ làm trung tâm, chất lượng hoạt động góc và ngoài trời",8,[[8,"Đạt 9–10/10 chỉ báo quan sát"],[6,"Đạt 7–8/10 chỉ báo"],[3,"Đạt 5–6/10 chỉ báo"],[0,"Đạt 0–4/10 chỉ báo"]],"Phiếu quan sát 2 lượt"],
["B2.4","Theo dõi, đánh giá sự phát triển và hỗ trợ trẻ",5,P(5,4,2),"Hồ sơ theo dõi"],
["B3.1","Nộp hồ sơ, kế hoạch, báo cáo đúng hạn",4,[[4,"100% đúng hạn"],[3,"1 lần trễ không quá 1 ngày"],[1,"2 lần trễ hoặc 1 lần trễ quá 1 ngày"],[0,"Từ 3 lần trễ hoặc không nộp nhiệm vụ bắt buộc"]],"Lịch nộp hồ sơ"],
["B3.2","Tiến độ chuẩn bị, tổ chức và hoàn thành công việc",4,[[4,"100% đúng hạn"],[3,"Từ 90% đến dưới 100%"],[1,"Từ 70% đến dưới 90%"],[0,"Dưới 70%"]],"Kế hoạch, lịch công tác"],
["B3.3","Thực hiện nhiệm vụ đột xuất đúng thời hạn",2,[[2,"Tất cả nhiệm vụ đúng hạn"],[1,"1 nhiệm vụ chậm không quá 1 ngày"],[0,"Từ 2 nhiệm vụ chậm hoặc không thực hiện nhiệm vụ hợp lệ"]],"Phiếu giao việc"],
["B4.1","Sinh hoạt chuyên môn, bồi dưỡng và chia sẻ",4,[[4,"Đủ buổi, có ý kiến hoặc sản phẩm vận dụng"],[3,"Đủ buổi, chưa có minh chứng trao đổi/vận dụng"],[1,"Tham gia 50% đến dưới 100% số buổi"],[0,"Dưới 50% không có lý do chính đáng"]],"Biên bản sinh hoạt"],
["B4.2","Phối hợp giáo viên cùng lớp và nhân viên liên quan",3,P(3,2,1),"Sổ bàn giao"],
["B4.3","Phối hợp cha mẹ trẻ, trao đổi và hỗ trợ trẻ",3,P(3,2,1),"Ghi nhận trao đổi"]
];
const tasks=[
["B1.1","Lập kế hoạch giáo dục","Đủ kế hoạch tháng và tuần; thể hiện hoạt động học, ngoài trời, góc, trải nghiệm.","Kế hoạch lớp"],
["B1.2","Tổ chức hoạt động học","Thực hiện đủ số hoạt động đã duyệt, không tổ chức hình thức.","Kế hoạch, kiểm tra"],
["B1.2","Tổ chức hoạt động ngoài trời","Thực hiện theo lịch; bảo đảm an toàn; điều chỉnh hợp lý khi thời tiết không phù hợp.","Lịch tuần, quan sát"],
["B1.2","Tổ chức hoạt động góc","Có chuẩn bị góc chơi, học liệu; trẻ chủ động lựa chọn, tham gia.","Lịch tuần, quan sát"],
["B1.2","Tổ chức hoạt động trải nghiệm","Thực hiện theo kế hoạch phù hợp độ tuổi, điều kiện lớp.","Kế hoạch, sản phẩm"],
["B2.3","Nâng cao chất lượng hoạt động","Bảo đảm lấy trẻ làm trung tâm theo 10 chỉ báo trong 2 lượt quan sát.","Phiếu quan sát"],
["B2.1","Bảo đảm an toàn cho trẻ","Thực hiện đúng giám sát, điểm danh, đón trả; phát hiện nguy cơ.","Sổ lớp, bảng kiểm"],
["B2.2","Tổ chức ăn, ngủ và vệ sinh","Thực hiện đúng quy trình nuôi dưỡng, chăm sóc.","Kiểm tra thực tế"],
["B1.3/B2.4","Hồ sơ lớp, theo dõi và đánh giá trẻ","Cập nhật đầy đủ, chính xác và đúng hạn.","Hồ sơ chuyên môn"],
["B1.4","Viết tin/bài truyền thông của nhóm lớp","Ít nhất 01 tin/bài ngắn/tháng, sử dụng tư liệu hoạt động thực tế; gửi đầu mối được giao.","Bản tin, xác nhận nộp"],
["B1.4","Video hoạt động số 1","Ít nhất 01 video từ hoạt động thực tế; chủ đề luân phiên; cập nhật kho học liệu số.","Tệp, đường dẫn học liệu"],
["B1.4","Video hoạt động số 2","Ít nhất 01 video khác từ hoạt động thực tế; chủ đề luân phiên; cập nhật kho học liệu số.","Tệp, đường dẫn học liệu"],
["A4.2","Ứng dụng và cải tiến học liệu số","Khi có cải tiến hiệu quả thì ghi nhận; nộp đủ video không tự động đạt 2 điểm A4.2.","Sản phẩm, kết quả vận dụng"],
["B4.3","Phối hợp cha mẹ trẻ, bảo vệ thông tin","Trao đổi đúng trách nhiệm; bảo vệ quyền riêng tư và hình ảnh trẻ.","Sổ liên lạc"],
["B1.4","Huy động trẻ theo chỉ tiêu (nếu được giao)","Ghi nhận chưa đạt/đạt/vượt với nhà trẻ và từng tuổi 3, 4, 5.","Chỉ tiêu, danh sách"],
["B3.3","Hoạt động, hội thi phát sinh (nếu được giao)","Thực hiện đúng nội dung, thời hạn được phân công.","Phiếu giao việc"],
["B4.1/B4.2","Sinh hoạt chuyên môn và phối hợp đồng nghiệp","Tham gia, trao đổi, phối hợp đầy đủ theo nhiệm vụ.","Biên bản"]
];
const E=s=>String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
const C=(a,b,t,s)=>[a,b,t,s];
function makeRows(){const arr=[],merges=[],valid=[];const letters="ABCDEFG";
function add(height,blocks){let n=arr.length+1,values=Array.from({length:7},()=>({v:"",s:0}));for(const [a,b,v,s]of blocks){for(let j=a;j<=b;j++)values[j]={v:j===a?v:"",s};if(b>a)merges.push(letters[a]+n+":"+letters[b]+n)}
let xml=values.map((item,j)=>{const ref=letters[j]+n,v=item.v,s=item.s;
if(v&&typeof v==="object"&&v.f!==undefined)return'<c r="'+ref+'" s="'+s+'"><f>'+E(v.f)+'</f><v></v></c>';
if(typeof v==="number")return'<c r="'+ref+'" s="'+s+'" t="n"><v>'+v+'</v></c>';
if(v===""||v==null)return'<c r="'+ref+'" s="'+s+'"/>';
return'<c r="'+ref+'" s="'+s+'" t="inlineStr"><is><t xml:space="preserve">'+E(v)+'</t></is></c>'}).join("");
arr.push('<row r="'+n+'" ht="'+height+'" customHeight="1">'+xml+'</row>');return n}
return{add,arr,merges,valid,get count(){return arr.length}}}
function sheet(x,widths,opts={}){
const cs=widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join("");
const mc=x.merges.length?'<mergeCells count="'+x.merges.length+'">'+x.merges.map(m=>'<mergeCell ref="'+m+'"/>').join("")+'</mergeCells>':"";
const dv=x.valid.length?'<dataValidations count="'+x.valid.length+'">'+x.valid.map(v=>'<dataValidation type="list" allowBlank="1" showErrorMessage="1" error="Vui lòng chọn giá trị trong danh sách." sqref="'+v.addr+'"><formula1>"'+E(v.options.join(","))+'"</formula1></dataValidation>').join("")+'</dataValidations>':"";
const breaks=opts.breaks||[],rb=breaks.length?'<rowBreaks count="'+breaks.length+'" manualBreakCount="'+breaks.length+'">'+breaks.map(id=>'<brk id="'+id+'" min="0" max="16383" man="1"/>').join("")+'</rowBreaks>':"";
const xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:G'+x.count+'"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>'+cs+'</cols><sheetData>'+x.arr.join("")+'</sheetData>'+mc+dv+'<printOptions horizontalCentered="1" gridLines="0" headings="0"/><pageMargins left="0.22" right="0.22" top="0.24" bottom="0.25" header="0.1" footer="0.12"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="'+(opts.fitHeight===undefined?0:opts.fitHeight)+'"/><headerFooter><oddFooter>&amp;CTrường Mầm non An Bình – Trang &amp;P</oddFooter></headerFooter>'+rb+'</worksheet>';
return{xml,last:x.count,printTitle:opts.printTitle||0}}
function heading(x,title,month){
x.add(18,[C(0,6,"UBND PHƯỜNG AN BÌNH – TRƯỜNG MẦM NON AN BÌNH",1)]);
x.add(28,[C(0,6,title+" – THÁNG "+month.join("/")+" | NĂM HỌC 2026–2027",2)]);
x.add(21,[C(0,3,"Giáo viên: ..........................................................",1),C(4,6,"Nhóm/lớp: ........................................",1)]);
}
function makeTaskSheet(m){
const x=makeRows();heading(x,"PHIẾU GIAO VIỆC KPI GIÁO VIÊN",m);
x.add(23,[C(0,6,"Mỗi nhóm/lớp: ít nhất 02 video + 01 tin/bài ngắn/tháng. Các nhiệm vụ gắn với mã KPI hiện có, không tạo điểm mới.",9)]);
x.add(24,[C(0,0,"STT",4),C(1,1,"Mã KPI",4),C(2,2,"Đầu việc",4),C(3,3,"Kết quả cần đạt",4),C(4,4,"Minh chứng",4),C(5,5,"Kết quả thực tế",4),C(6,6,"Xác nhận",4)]);
const f=tasks.map(t=>t.slice());f[10][2]="Ít nhất 01 video thực tế; chủ đề gợi ý: "+pairs[months.findIndex(v=>v[0]===m[0]&&v[1]===m[1])][0]+". Nộp vào kho học liệu số.";
f[11][2]="Ít nhất 01 video thực tế khác; chủ đề gợi ý: "+pairs[months.findIndex(v=>v[0]===m[0]&&v[1]===m[1])][1]+". Nộp vào kho học liệu số.";
f.forEach((t,i)=>x.add(39,[C(0,0,i+1,6),C(1,1,t[0],6),C(2,2,t[1],5),C(3,3,t[2],5),C(4,4,t[3],5),C(5,5,"",7),C(6,6,"",7)]));
x.add(27,[C(0,6,"Lưu ý: Không yêu cầu quay đủ 4 loại hoạt động trong tháng; không buộc từng giáo viên nộp 2 video riêng. Phân công thực hiện theo nhóm/lớp.",9)]);
x.add(25,[C(0,6,"Nộp kho số khác với đăng công khai. Nội dung/hình ảnh trẻ chỉ được công khai sau kiểm duyệt và đáp ứng yêu cầu về quyền riêng tư.",9)]);
x.add(20,[C(0,2,"GIÁO VIÊN",10),C(3,4,"TỔ TRƯỞNG",10),C(5,6,"BAN GIÁM HIỆU",10)]);
x.add(32,[C(0,2,"(Ký, ghi rõ họ tên)",10),C(3,4,"(Ký, ghi rõ họ tên)",10),C(5,6,"(Ký, ghi rõ họ tên)",10)]);
return sheet(x,[7,15,37,61,27,20,16],{breaks:[13],printTitle:5})}
function makeMediaSheet(m,i){
const x=makeRows();heading(x,"BẢNG THEO DÕI SẢN PHẨM TRUYỀN THÔNG",m);
x.add(27,[C(0,6,"CHỈ TIÊU MỖI NHÓM/LỚP: 01 TIN/BÀI NGẮN VÀ ÍT NHẤT 02 VIDEO TỪ HOẠT ĐỘNG GIÁO DỤC THỰC TẾ.",3)]);
x.add(29,[C(0,6,"Hai chủ đề video gợi ý: "+pairs[i][0]+"; "+pairs[i][1]+". Có thể thay đổi luân phiên theo hoạt động thực tế của lớp; không bắt buộc đủ cả bốn chủ đề.",9)]);
x.add(28,[C(0,0,"STT",4),C(1,1,"Sản phẩm",4),C(2,2,"Nội dung/chủ đề",4),C(3,3,"Chỉ tiêu",4),C(4,4,"Đường dẫn/tên tệp kho học liệu số",4),C(5,5,"Trạng thái",4),C(6,6,"Người xác nhận",4)]);
const r1=x.add(51,[C(0,0,1,6),C(1,1,"Tin/bài ngắn",5),C(2,2,"Giới thiệu hoạt động giáo dục đã thực hiện; nội dung trung thực, phù hợp.",5),C(3,3,"Ít nhất 01",6),C(4,4,"",7),C(5,5,"",7),C(6,6,"",7)]);
const r2=x.add(51,[C(0,0,2,6),C(1,1,"Video số 1",5),C(2,2,pairs[i][0]+" (gợi ý; có thể thay đổi)",5),C(3,3,"Ít nhất 01",6),C(4,4,"",7),C(5,5,"",7),C(6,6,"",7)]);
const r3=x.add(51,[C(0,0,3,6),C(1,1,"Video số 2",5),C(2,2,pairs[i][1]+" (gợi ý; có thể thay đổi)",5),C(3,3,"Ít nhất 01",6),C(4,4,"",7),C(5,5,"",7),C(6,6,"",7)]);
const options=["Chưa nộp","Đã nộp","Chờ duyệt","Đã duyệt","Cần sửa"];
[r1,r2,r3].forEach(n=>x.valid.push({addr:"F"+n,options}));
x.add(30,[C(0,3,"SỐ SẢN PHẨM ĐÃ NỘP / CHỜ DUYỆT / ĐÃ DUYỆT",8),C(4,4,{f:'COUNTIF(F'+r1+':F'+r3+',"Đã nộp")+COUNTIF(F'+r1+':F'+r3+',"Chờ duyệt")+COUNTIF(F'+r1+':F'+r3+',"Đã duyệt")'},8),C(5,6,"Mục tiêu: 3 sản phẩm",8)]);
x.add(31,[C(0,6,"Hoàn thành đầu việc khi có sản phẩm, đường dẫn nộp và xác nhận phù hợp. Việc chờ nhà trường phê duyệt không tự xem là lỗi của giáo viên.",9)]);
x.add(32,[C(0,6,"Sản phẩm dùng hình ảnh trẻ phải đúng phạm vi cho phép; tránh tiết lộ thông tin cá nhân, tình trạng sức khỏe; đăng công khai sau khi được duyệt.",9)]);
x.add(31,[C(0,6,"Tháng hè: áp dụng khi nhóm/lớp có hoạt động và được giao nhiệm vụ; nghỉ hợp lệ không tự động bị trừ KPI.",9)]);
x.add(22,[C(0,2,"ĐẠI DIỆN NHÓM/LỚP",10),C(3,4,"NGƯỜI PHỤ TRÁCH TRUYỀN THÔNG",10),C(5,6,"BAN GIÁM HIỆU",10)]);
x.add(43,[C(0,2,"(Ký, ghi rõ họ tên)",10),C(3,4,"(Ký, ghi rõ họ tên)",10),C(5,6,"(Ký, ghi rõ họ tên)",10)]);
return sheet(x,[7,23,39,15,45,20,25],{fitHeight:1})}
function makeScoringSheet(m,part){
const x=makeRows(),data=part==="A"?A:B,max=part==="A"?30:70;
heading(x,"PHIẾU CHẤM KPI PHẦN "+part,m);
x.add(21,[C(0,6,"THANG ĐIỂM PHẦN "+part+": "+max+" ĐIỂM. Mỗi mã giữ nguyên điểm tối đa và các mức chấm theo Quy chế.",3)]);
x.add(26,[C(0,0,"Mã",4),C(1,1,"Nội dung tiêu chí",4),C(2,2,"Tối đa",4),C(3,3,"Các mức điểm theo Quy chế",4),C(4,4,"Minh chứng",4),C(5,5,"Tự chấm",4),C(6,6,"BGH chấm",4)]);
const first=x.count+1;data.forEach(t=>{
const levels=t[3].map(v=>v[0]+" điểm: "+v[1]).join("\n");
const r=x.add(62,[C(0,0,t[0],6),C(1,1,t[1],5),C(2,2,t[2],6),C(3,3,levels,5),C(4,4,t[4],5),C(5,5,"",7),C(6,6,"",7)]);
x.valid.push({addr:"F"+r+" G"+r,options:[...new Set(t[3].map(v=>String(v[0])))]})});
const last=x.count,n=data.length;
const row=x.add(30,[C(0,1,"TỔNG ĐIỂM PHẦN "+part,8),C(2,2,max,8),C(3,4,"Chỉ cộng khi có đủ "+n+" mức điểm.",8),
C(5,5,{f:'IF(COUNTA(F'+first+':F'+last+')='+n+',SUMPRODUCT(IFERROR(1*F'+first+':F'+last+',0)),"")'},8),
C(6,6,{f:'IF(COUNTA(G'+first+':G'+last+')='+n+',SUMPRODUCT(IFERROR(1*G'+first+':G'+last+',0)),"")'},8)]);
x.add(32,[C(0,6,part==="A"?"A4.2: Không tự cộng điểm cải tiến khi chỉ nộp video thông thường. Lưu ý mức 3 sai sót nhẹ của A1.2 đang có giao nhau trong Quy chế.":"B1.4: Ghi nhận đủ 2 video + 1 tin/bài cùng nhiệm vụ khác; không chấm 3 điểm riêng cho truyền thông. B1.2 kiểm tra đủ hoạt động, B2.3 kiểm tra chất lượng.",9)]);
x.add(20,[C(0,2,"NGƯỜI TỰ ĐÁNH GIÁ",10),C(3,4,"TỔ TRƯỞNG",10),C(5,6,"BAN GIÁM HIỆU",10)]);
x.add(35,[C(0,2,"(Ký, ghi rõ họ tên)",10),C(3,4,"(Ký, ghi rõ họ tên)",10),C(5,6,"(Ký, ghi rõ họ tên)",10)]);
return{...sheet(x,[10,40,10,64,28,13,13],{breaks:part==="A"?[10]:[10,15],printTitle:5}),summary:row,first,last,count:n}}
function makeSummary(m,a,b){
const x=makeRows();heading(x,"BẢNG TỔNG HỢP CHẤM KPI GIÁO VIÊN",m);
x.add(26,[C(0,6,"Điểm chỉ hiển thị khi nhập đủ toàn bộ tiêu chí; đối chiếu thang điểm chuẩn ở trang 03_CHAM_A và 04_CHAM_B.",9)]);
x.add(25,[C(0,2,"Nhóm tiêu chí",4),C(3,4,"Điểm tối đa",4),C(5,5,"Tự chấm",4),C(6,6,"BGH chấm",4)]);
x.add(34,[C(0,2,"A – Tiêu chí chung",5),C(3,4,30,6),C(5,5,{f:"IF('03_CHAM_A'!F"+a.summary+'="","",\'03_CHAM_A\'!F'+a.summary+")"},7),C(6,6,{f:"IF('03_CHAM_A'!G"+a.summary+'="","",\'03_CHAM_A\'!G'+a.summary+")"},7)]);
x.add(34,[C(0,2,"B – Kết quả thực hiện nhiệm vụ",5),C(3,4,70,6),C(5,5,{f:"IF('04_CHAM_B'!F"+b.summary+'="","",\'04_CHAM_B\'!F'+b.summary+")"},7),C(6,6,{f:"IF('04_CHAM_B'!G"+b.summary+'="","",\'04_CHAM_B\'!G'+b.summary+")"},7)]);
x.add(37,[C(0,2,"TỔNG KPI",8),C(3,4,100,8),C(5,5,{f:'IF(COUNT(F6:F7)=2,SUM(F6:F7),"")'},8),C(6,6,{f:'IF(COUNT(G6:G7)=2,SUM(G6:G7),"")'},8)]);
x.add(29,[C(0,6,"Truyền thông: 01 tin/bài và ít nhất 02 video / nhóm lớp / tháng; được kiểm tra cùng nhiệm vụ B1.4, không cộng điểm vượt 100.",9)]);
x.add(30,[C(0,6,"Kết quả vượt chỉ tiêu huy động trẻ, phong trào phát sinh: ghi nhận riêng theo Quy chế; không cộng thêm điểm vượt mức tối đa.",9)]);
x.add(31,[C(0,6,"Nhận xét, ghi nhận sản phẩm nổi bật: ..........................................................................................................................",5)]);
x.add(31,[C(0,6,"Nội dung cần cải thiện: ................................................................................................................................................",5)]);
x.add(21,[C(0,2,"GIÁO VIÊN",10),C(3,4,"TỔ TRƯỞNG",10),C(5,6,"BAN GIÁM HIỆU",10)]);
x.add(43,[C(0,2,"(Ký, ghi rõ họ tên)",10),C(3,4,"(Ký, ghi rõ họ tên)",10),C(5,6,"(Ký, ghi rõ họ tên)",10)]);
return sheet(x,[10,28,20,23,24,18,18],{fitHeight:1})}
function styles(){
const fonts=['<font><sz val="9"/><name val="Times New Roman"/><color rgb="FF233547"/></font>','<font><sz val="10"/><b/><name val="Times New Roman"/><color rgb="FF183B58"/></font>','<font><sz val="14"/><b/><name val="Times New Roman"/><color rgb="FF183B58"/></font>','<font><sz val="9"/><b/><name val="Times New Roman"/><color rgb="FFFFFFFF"/></font>'];
const fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>',...["FF193D5D","FFE9F2F8","FFFFF2D6"].map(v=>'<fill><patternFill patternType="solid"><fgColor rgb="'+v+'"/><bgColor indexed="64"/></patternFill></fill>')];
const borders=['<border><left/><right/><top/><bottom/><diagonal/></border>','<border><left style="thin"><color rgb="FFB6C5CE"/></left><right style="thin"><color rgb="FFB6C5CE"/></right><top style="thin"><color rgb="FFB6C5CE"/></top><bottom style="thin"><color rgb="FFB6C5CE"/></bottom><diagonal/></border>'];
const opts=[[0,0,0,"left"],[1,0,0,"left"],[2,0,0,"center"],[3,2,0,"left"],[3,2,1,"center"],[0,0,1,"left"],[1,0,1,"center"],[0,4,1,"left"],[1,3,1,"center"],[0,3,0,"left"],[1,0,0,"center"]];
return'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="4">'+fonts.join("")+'</fonts><fills count="5">'+fills.join("")+'</fills><borders count="2">'+borders.join("")+'</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellStyleXfs><cellXfs count="'+opts.length+'">'+opts.map(o=>'<xf numFmtId="0" fontId="'+o[0]+'" fillId="'+o[1]+'" borderId="'+o[2]+'" xfId="0" applyAlignment="1"><alignment horizontal="'+o[3]+'" vertical="center" wrapText="1"/></xf>').join("")+'</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'}
const put16=(a,n)=>a.push(n&255,(n>>>8)&255),put32=(a,n)=>a.push(n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255);
function crc(bytes){let c=0xffffffff;for(const n of bytes){c^=n;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0)}return(c^0xffffffff)>>>0}
function zip(files){const enc=new TextEncoder(),local=[],central=[];let offset=0;
for(const [name,src]of files){const n=enc.encode(name),d=enc.encode(src),sum=crc(d),lh=[];put32(lh,0x04034b50);put16(lh,20);put16(lh,0x0800);put16(lh,0);put16(lh,0);put16(lh,0);put32(lh,sum);put32(lh,d.length);put32(lh,d.length);put16(lh,n.length);put16(lh,0);const h=new Uint8Array(lh);local.push(h,n,d);
const cd=[];put32(cd,0x02014b50);put16(cd,20);put16(cd,20);put16(cd,0x0800);put16(cd,0);put16(cd,0);put16(cd,0);put32(cd,sum);put32(cd,d.length);put32(cd,d.length);put16(cd,n.length);put16(cd,0);put16(cd,0);put16(cd,0);put16(cd,0);put32(cd,0);put32(cd,offset);central.push(new Uint8Array(cd),n);offset+=h.length+n.length+d.length}
const size=central.reduce((v,p)=>v+p.length,0),end=[];put32(end,0x06054b50);put16(end,0);put16(end,0);put16(end,files.length);put16(end,files.length);put32(end,size);put32(end,offset);put16(end,0);
return new Blob([...local,...central,new Uint8Array(end)],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})}
function workbook(sheets){
const types=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'];
sheets.forEach((s,i)=>types.push('<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'));types.push("</Types>");
let names=[];sheets.forEach((s,i)=>{names.push('<definedName name="_xlnm.Print_Area" localSheetId="'+i+'">&apos;'+E(s.name)+'&apos;!$A$1:$G$'+s.last+'</definedName>');if(s.printTitle)names.push('<definedName name="_xlnm.Print_Titles" localSheetId="'+i+'">&apos;'+E(s.name)+'&apos;!$1:$'+s.printTitle+'</definedName>')});
const book='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'+sheets.map((s,i)=>'<sheet name="'+E(s.name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join("")+'</sheets><definedNames>'+names.join("")+'</definedNames><calcPr calcMode="auto" fullCalcOnLoad="1"/></workbook>';
const rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((s,i)=>'<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join("")+'<Relationship Id="rId'+(sheets.length+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
const files=[["[Content_Types].xml",types.join("")],["_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],["xl/workbook.xml",book],["xl/_rels/workbook.xml.rels",rels],["xl/styles.xml",styles()]];
sheets.forEach((s,i)=>files.push(["xl/worksheets/sheet"+(i+1)+".xml",s.xml]));
const parser=new DOMParser();for(const [name,src]of files){if(parser.parseFromString(src,"application/xml").getElementsByTagName("parsererror").length)throw Error("Cấu trúc XML lỗi: "+name)}
return zip(files)}
root.querySelector("[data-download]").addEventListener("click",()=>{
const status=root.querySelector("[data-status]");
try{
status.textContent="Đang cập nhật đầu việc, mức điểm và kiểm tra cấu trúc Excel...";
if(A.reduce((v,t)=>v+t[2],0)!==30||B.reduce((v,t)=>v+t[2],0)!==70)throw Error("Tổng điểm không khớp Quy chế.");
const i=+sel.value,m=months[i],task=makeTaskSheet(m),media=makeMediaSheet(m,i),a=makeScoringSheet(m,"A"),b=makeScoringSheet(m,"B"),sum=makeSummary(m,a,b);
const blob=workbook([{name:"01_GIAO_VIEC",...task},{name:"02_TRUYEN_THONG",...media},{name:"03_CHAM_A",...a},{name:"04_CHAM_B",...b},{name:"05_TONG_HOP",...sum}]);
if(blob.size<7000)throw Error("Dung lượng tệp không hợp lệ.");
const url=URL.createObjectURL(blob),link=document.createElement("a");link.href=url;link.download="MNAB_KPI_GV_2_VIDEO_1_TIN_BAI_"+m.join("-")+".xlsx";document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
status.textContent="Đã tạo tệp Excel ("+Math.round(blob.size/1024)+" KB) và kiểm tra cú pháp XML. Hãy mở bằng Microsoft Excel và xem trước bản in.";
}catch(err){status.textContent="Không tạo được tệp: "+String(err.message||err)}
});
})();
</script>
</AppBlock>

**Cách áp dụng:** Mỗi tháng, tổ trưởng kiểm tra kết quả ở trang **02_TRUYEN_THONG** cùng các nhiệm vụ khác thuộc B1.4. Giáo viên không phải nộp video riêng cho từng người; các giáo viên trong cùng nhóm/lớp phối hợp thực hiện và phân công trách nhiệm cụ thể.

File được tạo khi bạn nhấn nút tải và có bước kiểm tra cấu trúc dữ liệu. Tôi chưa thể mở kiểm thử trực tiếp bằng Microsoft Excel trên thiết bị của bạn.

**Lưu ý trước khi chấm chính thức:** Mức “3 sai sót nhẹ” ở tiêu chí A1.2 của Quy chế đang bị trùng giữa hai mức điểm; nhà trường nên thống nhất, đính chính nội dung này để tránh cách hiểu khác nhau.

---

