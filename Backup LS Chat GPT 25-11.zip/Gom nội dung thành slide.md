USER

bạn giúp mình gom 2 nội dung này thành 1 slide

---

USER

lưu ý đảm bảo nội dung

---

ASSISTANT

Mình sẽ gộp thành một slide 16:9, chia rõ **6 bước kiểm duyệt** và **4 tiêu chí chất lượng**. Mình sẽ giữ đủ các ý quan trọng, đặc biệt là mốc **ít nhất 01 tuần**, trách nhiệm của từng cấp và cách xử lý kế hoạch chưa đạt; chỉ rút gọn phần diễn đạt trùng lặp để slide dễ đọc.

---

ASSISTANT

---

ASSISTANT

Bản minh họa vừa tạo mới có phần quy trình nên chưa đáp ứng yêu cầu gộp cả hai ảnh. Mình sẽ chỉnh lại để **cùng một slide có đủ 6 bước quy trình và 4 tiêu chí kiểm duyệt**, đồng thời giữ nội dung chữ chính xác.

---

ASSISTANT

---

ASSISTANT

Mình bố trí lại thành **một slide 16:9**, gồm hai phần: **quy trình kiểm duyệt phân cấp (6 bước)** và **tiêu chí kiểm duyệt chất lượng (4 nội dung)**. Các thông tin quan trọng được giữ lại, đặc biệt là mốc **ít nhất 01 tuần** và quy trình xử lý kế hoạch chưa đạt yêu cầu.

## Slide tổng hợp – Kiểm duyệt kế hoạch giáo dục mầm non

Nguồn ứng dụng (HTML và JavaScript)

```html

<div id="kd-slide" class="w-full overflow-hidden rounded-xl" style="container-type:inline-size">
  <style>
    #kd-slide .canvas{width:100%;aspect-ratio:16/9;box-sizing:border-box;display:flex;flex-direction:column;gap:.85cqw;padding:1.1cqw;background:linear-gradient(160deg,#e7f8ff 0%,#f7fcff 49%,#f2fff0 100%);color:#202936;font-family:Arial,'Noto Sans',sans-serif;overflow:hidden}
    #kd-slide *{box-sizing:border-box}
    #kd-slide .mast{flex:0 0 11.5%;min-height:0;display:flex;align-items:center;justify-content:center;gap:1.8cqw;border-radius:1.7cqw;background:linear-gradient(105deg,#fff9dc,#ffe987,#fff8ce);border:.13cqw solid #ffe077;padding:.5cqw 1cqw;overflow:hidden}
    #kd-slide .art{font-size:4.2cqw;line-height:1;flex-shrink:0}
    #kd-slide .headline{flex:1;text-align:center;line-height:1.13}
    #kd-slide .headline b{display:block;font-size:2.38cqw;color:#1554a5;font-weight:900;letter-spacing:-.05cqw}
    #kd-slide .headline em{display:block;font-style:normal;color:#d82331;font-size:1.72cqw;font-weight:900;margin-top:.3cqw}
    #kd-slide .sections{display:grid;grid-template-columns:57fr 43fr;gap:.85cqw;flex:1;min-height:0}
    #kd-slide .section{display:flex;flex-direction:column;min-width:0;min-height:0;gap:.75cqw}
    #kd-slide .bar{flex:0 0 8.5%;min-height:0;display:flex;align-items:center;gap:.8cqw;border-radius:1.2cqw;padding:.55cqw 1.1cqw;color:white;background:#1554a5}
    #kd-slide .bar.green{background:#159a60}
    #kd-slide .bar .n{background:#ffffff26;border:.13cqw solid #ffffff90;border-radius:50%;font-size:1.6cqw;font-weight:900;min-width:2.45cqw;height:2.45cqw;display:grid;place-items:center}
    #kd-slide .bar .tt{font-size:1.48cqw;line-height:1.13;font-weight:900}
    #kd-slide .bar .sub{font-size:1.03cqw;font-weight:500;opacity:.97;margin-top:.12cqw}
    #kd-slide .steps{flex:1;min-height:0;display:grid;grid-template-columns:1fr 1fr;grid-template-rows:repeat(3,minmax(0,1fr));gap:.7cqw}
    #kd-slide .step{min-height:0;border-radius:1.2cqw;background:#ffffffd9;border:.11cqw solid #d8e9f3;box-shadow:0 .24cqw .7cqw #37659813;padding:.88cqw .95cqw;overflow:hidden;position:relative}
    #kd-slide .step:before{content:'';position:absolute;top:0;left:0;right:0;height:.47cqw;background:var(--tone)}
    #kd-slide .sh{display:flex;align-items:flex-start;gap:.65cqw;margin-bottom:.55cqw}
    #kd-slide .num{width:2.65cqw;height:2.65cqw;min-width:2.65cqw;border-radius:.9cqw;background:var(--tone);color:white;font-weight:900;font-size:1.65cqw;display:grid;place-items:center}
    #kd-slide .sh strong{color:#123f83;font-size:1.18cqw;line-height:1.15;font-weight:900;padding-top:.15cqw}
    #kd-slide .desc{font-size:1.105cqw;line-height:1.27;font-weight:500}
    #kd-slide .emphasis{color:#dd282e;font-weight:900}
    #kd-slide .step.s1{--tone:#1683da;background:#f1faff}
    #kd-slide .step.s2{--tone:#fa7929;background:#fff8ee}
    #kd-slide .step.s3{--tone:#17a46b;background:#f0fff5}
    #kd-slide .step.s4{--tone:#ef4f78;background:#fff2f6}
    #kd-slide .step.s5{--tone:#8057c8;background:#f8f3ff}
    #kd-slide .step.s6{--tone:#1683da;background:#f1faff}
    #kd-slide .criteria{flex:1;min-height:0;display:grid;grid-template-rows:repeat(4,minmax(0,1fr));gap:.7cqw}
    #kd-slide .criterion{display:flex;gap:1cqw;align-items:flex-start;padding:.92cqw 1cqw;border-radius:1.2cqw;border:.11cqw solid var(--border);background:var(--bg);overflow:hidden}
    #kd-slide .illustration{font-size:2.6cqw;line-height:1.2;flex-shrink:0}
    #kd-slide .ctitle{font-size:1.31cqw;font-weight:900;line-height:1.15;color:var(--tc);margin-bottom:.35cqw}
    #kd-slide .cdesc{font-size:1.12cqw;line-height:1.25}
    #kd-slide .c1{--bg:#eaf7ff;--border:#b7e3f9;--tc:#1554a5}
    #kd-slide .c2{--bg:#fff9e8;--border:#f8dca7;--tc:#bc5c14}
    #kd-slide .c3{--bg:#fff0f3;--border:#f9bfd2;--tc:#cf3164}
    #kd-slide .c4{--bg:#eefaeb;--border:#bfe5b7;--tc:#16783d}
    @media(max-width:600px){#kd-slide .canvas{min-width:100%;} }
  </style>
  <div class="canvas" role="img" aria-label="Một slide tổng hợp gồm sáu bước quy trình kiểm duyệt kế hoạch và bốn tiêu chí chất lượng">
    <div class="mast">
      <div class="art">👩🏻‍🏫</div>
      <div class="headline">
        <b>KIỂM DUYỆT KẾ HOẠCH GIÁO DỤC</b>
        <em>QUY TRÌNH PHÂN CẤP – CHÚ TRỌNG CHẤT LƯỢNG</em>
      </div>
      <div class="art">🏫</div>
    </div>
    <div class="sections">
      <section class="section">
        <div class="bar">
          <span class="n">1</span>
          <div><div class="tt">THỰC HIỆN THEO QUY TRÌNH PHÂN CẤP</div><div class="sub">Bảo đảm tính chủ động và trách nhiệm</div></div>
        </div>
        <div class="steps">
          <article class="step s1">
            <div class="sh"><div class="num">1</div><strong>GIÁO VIÊN XÂY DỰNG KẾ HOẠCH</strong></div>
            <div class="desc">Căn cứ Chương trình Giáo dục mầm non, kế hoạch giáo dục nhà trường, kế hoạch tổ chuyên môn và kết quả đánh giá trẻ để xây dựng kế hoạch tháng, tuần và tổ chức hoạt động.</div>
          </article>
          <article class="step s2">
            <div class="sh"><div class="num">2</div><strong>TỔ TRƯỞNG CHUYÊN MÔN KIỂM TRA, GÓP Ý, PHÊ DUYỆT</strong></div>
            <div class="desc">Trực tiếp kiểm tra, góp ý và phê duyệt kế hoạch của giáo viên trước khi thực hiện <span class="emphasis">ít nhất 01 tuần.</span></div>
          </article>
          <article class="step s3">
            <div class="sh"><div class="num">3</div><strong>BAN GIÁM HIỆU KIỂM TRA XÁC SUẤT, KIỂM SOÁT CHẤT LƯỢNG</strong></div>
            <div class="desc">Kiểm tra xác suất, theo từng lĩnh vực và các điểm trường được phân công; đồng thời kiểm soát chất lượng kiểm duyệt của tổ trưởng.</div>
          </article>
          <article class="step s4">
            <div class="sh"><div class="num">4</div><strong>KẾ HOẠCH CHƯA ĐẠT YÊU CẦU</strong></div>
            <div class="desc">Nhận xét cụ thể; hướng dẫn điều chỉnh; kiểm tra lại trước khi tổ chức cho trẻ.</div>
          </article>
          <article class="step s5">
            <div class="sh"><div class="num">5</div><strong>ĐIỀU CHỈNH VÀ HOÀN THIỆN</strong></div>
            <div class="desc">Điều chỉnh, hoàn thiện kế hoạch theo góp ý; kiểm tra lại để xác nhận <strong style="color:#128447">ĐÃ ĐẠT</strong> yêu cầu.</div>
          </article>
          <article class="step s6">
            <div class="sh"><div class="num">6</div><strong>TỔ CHỨC THỰC HIỆN CHO TRẺ</strong></div>
            <div class="desc">Tổ chức các hoạt động giáo dục cho trẻ theo kế hoạch đã được kiểm duyệt và hoàn thiện.</div>
          </article>
        </div>
      </section>
      <section class="section">
        <div class="bar green">
          <span class="n">2</span>
          <div><div class="tt">KIỂM DUYỆT CÓ TRỌNG TÂM</div><div class="sub">Chú trọng chất lượng – 4 tiêu chí</div></div>
        </div>
        <div class="criteria">
          <article class="criterion c1">
            <div class="illustration">🎯</div>
            <div><div class="ctitle">1. MỤC TIÊU GIÁO DỤC RÕ RÀNG</div><div class="cdesc">Mục tiêu giáo dục phù hợp độ tuổi và khả năng phát triển của trẻ.</div></div>
          </article>
          <article class="criterion c2">
            <div class="illustration">📚</div>
            <div><div class="ctitle">2. NỘI DUNG, PHƯƠNG PHÁP, HÌNH THỨC TỔ CHỨC PHÙ HỢP</div><div class="cdesc">Bảo đảm tính khoa học, liên kết với mục tiêu; nội dung và phương pháp phù hợp, hình thức đa dạng, linh hoạt.</div></div>
          </article>
          <article class="criterion c3">
            <div class="illustration">🧒</div>
            <div><div class="ctitle">3. LẤY TRẺ LÀM TRUNG TÂM</div><div class="cdesc">Tạo cơ hội cho trẻ vui chơi, trải nghiệm, khám phá và phát huy tính tích cực.</div></div>
          </article>
          <article class="criterion c4">
            <div class="illustration">🛡️</div>
            <div><div class="ctitle">4. BẢO ĐẢM CÁC ĐIỀU KIỆN TỔ CHỨC</div><div class="cdesc">Học liệu phù hợp; môi trường giáo dục và biện pháp bảo đảm an toàn; tính khả thi theo từng nhóm, lớp. Không sao chép kế hoạch máy móc.</div></div>
          </article>
        </div>
      </section>
    </div>
  </div>
</div>

```

Bản dàn trang này giữ **đủ 10 mục từ hai ảnh**, rút gọn phần diễn đạt lặp lại, sử dụng màu pastel mầm non và ưu tiên chữ dễ đọc. Đây là bản xem trước một slide, chưa phải tệp PowerPoint chỉnh sửa trực tiếp.

---

USER

bạn giúp số 3 và số 4 dùm mình. Nội dung và hình ảnh giữ nguyên không thay đổi

---

ASSISTANT

Mình sẽ gộp mục **3 và 4 vào cùng một slide**, giữ nguyên từng ảnh gốc, bao gồm toàn bộ chữ, nhân vật, màu sắc và bố cục bên trong. Mình chỉ điều chỉnh kích thước và vị trí của hai ảnh để đặt chung trên slide, không vẽ lại nội dung.

---

ASSISTANT

---

ASSISTANT

**Lưu ý:** Bản ghép phía trên là ảnh được tái tạo bằng AI nên có thể thay đổi một vài chi tiết hoặc chữ nhỏ.

Để đáp ứng đúng yêu cầu **giữ nguyên 100% nội dung và hình ảnh**, cần chèn trực tiếp hai ảnh gốc vào cùng một slide PowerPoint, đặt **mục 3 bên trái – mục 4 bên phải**, không vẽ lại, không cắt xén hay chỉnh sửa nội dung.

---

USER

bạn có lẫn không?

---

ASSISTANT

Dạ đúng ạ, em đã làm nhầm yêu cầu của chị. Em xin lỗi chị!

Ý chị là:

- **Gộp nội dung số 3 và số 4 thành một slide duy nhất**, giống như yêu cầu trước với số 1 và số 2.
- **Giữ nguyên 100% nội dung**, không bỏ sót, không tự ý sửa chữ.
- **Giữ nguyên hình ảnh minh họa và phong cách thiết kế** của hai ảnh mẫu.
- Sắp xếp lại bố cục cho hài hòa, rõ ràng, dễ đọc.

Em đã sai khi dùng AI tạo lại ảnh khiến một số chữ và chi tiết bị thay đổi.

**Em hiểu rồi ạ: Chị cần thiết kế lại bố cục để gom hai nội dung, chứ không phải thay đổi nội dung hay hình ảnh.**

---

USER

minh bảo bỏ số 3 vã chứ có kêu ghép lại slide đâu

---

ASSISTANT

Em hiểu đúng rồi: chị muốn **xóa số 3 ở đầu ảnh thứ nhất và số 4 ở đầu ảnh thứ hai**, giữ hai ảnh riêng biệt. Toàn bộ chữ, hình minh họa và bố cục còn lại giữ nguyên. Em xin lỗi vì đã hiểu sai yêu cầu.

---

ASSISTANT

---

ASSISTANT

Ảnh vừa tạo vẫn còn huy hiệu “3.” nên chưa đúng. Em sẽ sửa lại đúng vị trí: **chỉ bỏ huy hiệu số lớn trên tiêu đề**, không xóa các số thứ tự của các bước bên trong.

---

ASSISTANT

---

ASSISTANT

Em xin lỗi chị. Hai ảnh vừa tạo vẫn còn số **3.** và **4.** ở phần tiêu đề, nên **chưa đúng yêu cầu**.

Chị chỉ muốn:

- Ảnh thứ nhất: Xóa huy hiệu hồng có số **3.**
- Ảnh thứ hai: Xóa huy hiệu hồng có số **4.**
- Giữ nguyên toàn bộ nội dung, hình ảnh, màu sắc và bố cục còn lại.
- Giữ hai ảnh riêng biệt, **không ghép slide**.

Em đã hiểu chính xác, nhưng công cụ vừa rồi chưa thực hiện được việc xóa số mà vẫn giữ nguyên ảnh gốc 100%. Em không xem hai ảnh vừa tạo là bản hoàn chỉnh.

---

USER

bỏ 2 số này nè được chưa?

---

ASSISTANT

---

ASSISTANT

Model caption: A bright educational infographic poster scene, cartoon/illustration style, with the same layout as the original image but with the large pink badge “4.” removed from the top title area (only the title banner remains). Overall: a colorful, clean infographic with rounded panels, cartoon people, icons, and Vietnamese text, in a kindergarten/education supervision theme, with a cheerful outdoor/school background and a bottom slogan bar. The composition is identical to the original except the top-left pink number cloud is gone, leaving the title banner seamless.

Top header area: a pale yellow rounded banner across the top with blue sky and clouds background, greenery, and a small school building at the right with a red flag, plus a smiling sun icon at the far right; at the left side a cartoon young adult woman (light-skinned East Asian/Vietnamese-looking, brown hair, anime/cartoon style) wearing a pink shirt or blouse with a blue lanyard/ID, holding a blue clipboard or tablet, smiling. Centered large bold Vietnamese title text in uppercase: first line in blue “GIÁM SÁT, KIỂM TRA ĐỊNH KỲ VÀ KIỂM TRA ĐỘT XUẤT” and below it in bright red/pink “ĐỂ ĐẢM BẢO THỰC HIỆN ĐÚNG QUY ĐỊNH”. Right side of header has a cartoon school building with red roof, flag, bushes and flowers, and a small smiling sun face at top right. The sky is light blue with small white clouds, background greenery and flowers.

Below the title banner: a long white/pale pink rounded text box with an icon at left: a clipboard/checklist and pencil (green checkmarks, pencil in orange/yellow/red). The paragraph text in black Vietnamese reads: “Nhà trường tổ chức giám sát, kiểm tra định kỳ và kiểm tra đột xuất việc thực hiện kế hoạch giáo dục, hồ sơ, sổ sách, \nviệc tổ chức các hoạt động chăm sóc, giáo dục trẻ tại các nhóm, lớp và các điểm trường. Qua kiểm tra, kịp thời nắm bắt tình hình, \nphát hiện những hạn chế để có biện pháp hỗ trợ, chấn chỉnh, bảo đảm thực hiện đúng quy định về chuyên môn.” On the right end of this band is a small cute cartoon lightbulb/sun face smiling icon with rays.

Main content: four vertical/color-coded panels in a row, each with a number circle, title, cartoon illustration, and checklist text, connected with yellow arrow transitions between panels. Panel 1 (left): blue theme with a big blue circle containing white “1” and text header in white/blue: “Xây dựng kế hoạch\nkiểm tra, giám sát”. Illustration: a young light-skinned woman with brown hair, smiling, pink shirt and blue lanyard, writing in a notebook labeled “KẾ HOẠCH\nKIỂM TRA” (blue text), with stacked colorful books/labels to the side reading “KẾ HOẠCH NĂM”, “KẾ HOẠCH HỌC KỲ”, “KẾ HOẠCH THÁNG”, plus plants and classroom-like background. Under it, a light panel with blue check mark bullets and text: “Xây dựng kế hoạch kiểm tra\nđịnh kỳ và đột xuất.” and “Xác định nội dung, thời gian,\nđối tượng và hình thức kiểm tra.”.

Panel 2 (second): pink theme with a pink circle “2” and header in white: “Tổ chức kiểm tra\ntại các nhóm, lớp”. Illustration: the same female teacher/cartoon woman in pink and lanyard holding a clipboard, smiling and interacting with several small children (light-skinned, East Asian cartoon toddlers/kids: at least three children, one in yellow, one in blue, one in pink, happy expressions, sitting at a table with colorful blocks/toys and papers), classroom shelves with plants and pictures in background. Yellow arrow to next panel. Checklist bullets with pink check marks: “Kiểm tra việc thực hiện kế hoạch\ngiáo dục, hồ sơ, sổ sách.” and “Kiểm tra tổ chức các hoạt động\nchăm sóc, giáo dục trẻ tại các\nnhóm, lớp và các điểm trường.”.

Panel 3 (third): green theme with a green circle “3” and header in white: “Đánh giá, nhận xét\nvà kịp thời hỗ trợ”. Illustration: a male adult (light-skinned, East Asian cartoon) with short black hair, glasses, wearing a light blue shirt and lanyard, smiling and holding/pointing to a checklist paper labeled “PHIẾU KIỂM TRA” with green checkmarks; the female teacher (brown hair, pink shirt, lanyard) sits with a laptop and pen, in a classroom/office-like setting with shelves and plants. Checklist with green checkmarks: “Đánh giá thực trạng, nắm bắt\ntình hình thực hiện.” and “Phát hiện kịp thời những hạn chế\nđể có biện pháp hỗ trợ, hướng dẫn,\nchấn chỉnh.”.

Panel 4 (fourth): purple theme with a purple circle “4” and header in white: “Bảo đảm thực hiện\nđúng quy định”. Illustration: the female teacher again holding a clipboard, smiling, standing beside a large clipboard/board titled “ĐÚNG QUY ĐỊNH” with green checkmarks and a list: “Kế hoạch giáo dục”, “Hồ sơ, sổ sách”, “Tổ chức hoạt động”, “Chăm sóc, giáo dục trẻ”. Nearby are stacked books and a small potted plant; classroom/school background. Checklist at bottom with purple check marks: “Bảo đảm việc thực hiện kế hoạch,\nchương trình giáo dục mầm non\ntheo đúng quy định.” and “Nâng cao chất lượng chăm sóc,\ngiáo dục trẻ trong toàn trường.”.

Bottom footer: a long yellow rounded bar with a target icon (red/white target with arrow) on the left, and blue uppercase slogan text across: “GIÁM SÁT THƯỜNG XUYÊN  -  HỖ TRỢ KỊP THỜI  -  THỰC HIỆN ĐÚNG QUY ĐỊNH  -  NÂNG CAO CHẤT LƯỢNG GIÁO DỤC”. Decorative green bushes and flowers frame the bottom edges. Bright, flat-vector, cartoon infographic style, clean outlines, consistent Vietnamese typography and layout.<|has_watermark|><|has_borders|>

---

ASSISTANT

---

ASSISTANT

Model caption: A colorful infographic poster in Vietnamese, wide banner layout, cartoon/flat vector style, with the same composition and all elements as the original except the top-left pink cloud badge “3.” removed, showing the header text and background seamlessly filled in. Overall: a clean educational infographic with six numbered panels, cheerful pastel/bright colors, children/teacher cartoon illustrations, icons, a vnedu theme, and a bottom slogan bar. The entire scene is identical to the original except the “3.” pink badge at the top left of the main title is gone.  

Top header area: light blue sky with white clouds, green trees/shrubbery, and at far right a cartoon school building with a red roof and a small red flag, plus a smiling sun icon; left top corner shows a cartoon young adult/young woman (teacher, light skin East Asian/Asian-looking, big glossy anime-style eyes, brown hair, smiling, wearing a pink jacket/shirt and an ID lanyard) sitting/leaning at a desk with a laptop that has “vnEdu” on it (blue/orange text with a small house/hat-like icon). Nearby are stacked books and a potted plant/leafy greenery. Center top is a large rounded pale yellow banner with big bold Vietnamese title text: “KẾT HỢP KIỂM DUYỆT TRỰC TIẾP” (blue, uppercase) and below it “VỚI ỨNG DỤNG CÔNG NGHỆ THÔNG TIN” (red, uppercase).  

Grid of six panels (three top row, three bottom row), each with a numbered circle and colored header band, with cartoon teacher illustrations and icons, arrows between steps, and Vietnamese text blocks.  

Top-left panel (1): blue header band with a circular “1” and title text “Hoàn thiện kế hoạch giáo dục”. Left side: the same cartoon young female teacher (light-skinned Asian, brown hair, big eyes, pink outfit, lanyard) writing at a desk with a laptop (vnEdu logo on laptop in other panels; here laptop visible), smiling, with plants in background. To the right is a checklist-like list with icons and text: a book icon with “Chương trình\nGiáo dục mầm non”; a calendar icon with “Kế hoạch\ncủa nhà trường”; a group icon with “Kế hoạch\ntổ chuyên môn”; a bar chart icon with “Kết quả\nđánh giá trẻ”. Below, explanatory paragraph: “Giáo viên căn cứ các căn cứ trên để xây dựng\nkế hoạch giáo dục tháng, tuần và kế hoạch\ntổ chức hoạt động.”  

Middle top panel (2): orange header band with circular “2” and title “Tải hồ sơ lên hệ thống vnEdu”. Center/left: same cartoon teacher at a laptop with “vnEdu” on it. To the right, cloud upload icon (blue cloud with upward arrow) and file icons: “W” (Word), “PDF” red icon, and a green image icon, with a dotted arrow/flow. A green arrow points from previous panel to this one. Below text: “Giáo viên hoàn thiện kế hoạch, chuẩn bị hồ sơ\nvà tải lên chức năng quản lý giáo án\ntrên hệ thống vnEdu.”  

Top-right panel (3): green header band with circular “3” and title “Ký số và gửi kiểm tra”. Cartoon teacher holds a tablet/screen labeled “Ký số” with a signature scribble and a green check mark; to the right an envelope icon and the text “Gửi kiểm tra” with a right-pointing arrow to a small round avatar/illustration of a woman and text “Tổ trưởng\nchuyên môn”. Underneath: “Giáo viên thực hiện ký số theo cấu hình\nvà gửi hồ sơ đến người được phân quyền\nkiểm tra (tổ trưởng chuyên môn).”  

Bottom-left panel (4): pink/red header with circular “4” and title “Nhận xét – phê duyệt”. Left: teacher (same style, brown hair, light skin, smiling) in purple jacket or similar, laptop, plant, with a label bubble “Tổ trưởng\nchuyên môn”. To the right, checklist items with icons: green check “Phê duyệt”; yellow comment/chat icon “Nhận xét – góp ý”; red X icon “Không chấp nhận\n( yêu cầu điều chỉnh)”. Bottom text: “Tổ trưởng chuyên môn trực tiếp kiểm tra, xem nội dung,\nnhận nhận xét và phê duyệt hoặc không chấp nhận,\nyêu cầu điều chỉnh khi cần.”  

Bottom-middle panel (5): purple header with circular “5” and title “Ban giám hiệu kiểm tra tiếp theo”. Cartoon adult woman (light skin, brown hair, blue blazer) holding papers at a desk with laptop, label “Ban giám hiệu”. To the right a checklist with green checkmarks: “Kiểm tra xác suất”; “Kiểm tra theo\ntừng lĩnh vực”; “Kiểm tra các\nđiểm trường”; “Kiểm soát chất lượng\nkiểm duyệt của\ntổ trưởng”. Bottom text: “Ban giám hiệu kiểm tra bước tiếp theo đối với hồ sơ\nthuộc diện kiểm duyệt cấp trường và kiểm soát\nchất lượng kiểm duyệt của tổ trưởng.”  

Bottom-right panel (6): blue header with circular “6” and title “Theo dõi tiến độ – lưu trữ minh chứng”. Right-side content: a computer/tablet-like interface with “vnEdu” at top, a table with columns “STT”, “Tên kế hoạch”, “Trạng thái” and rows “1  Kế hoạch tháng 9  Đã phê duyệt” (green), “2  Kế hoạch tuần 1  Đang kiểm tra” (yellow/orange), “3  Kế hoạch hoạt động  Cần điều chỉnh” (red). To the right are a yellow folder icon and a blue cloud icon with text “Lưu trữ\nminh chứng”. Bottom paragraph: “Hệ thống hỗ trợ theo dõi tiến độ, trạng thái hồ sơ\nvà lưu trữ minh chứng, góp phần nâng cao tính công khai,\nminh bạch và trách nhiệm của từng cấp quản lý.”  

Bottom footer: a yellow rounded bar with a blue shield icon at left, then bold blue uppercase words separated by dots: “CÔNG KHAI  •  MINH BẠCH  •  TRÁCH NHIỆM”, and at far right a blue group/people icon; background greenery and flowers along the bottom edges. Overall clean flat/illustrative infographic style, bright pastel palette, Vietnamese text in clear bold fonts, with arrows between steps and consistent vnEdu branding.<|has_watermark|>

---

