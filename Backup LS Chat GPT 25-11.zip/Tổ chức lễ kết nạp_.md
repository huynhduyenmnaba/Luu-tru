USER

sinh hoạt chi bộ có thể tổ chức lễ kết nạp cho đảng viên không? nếu được vì sao? không đượic vì sao?

---

ASSISTANT

Tôi sẽ đối chiếu quy định, hướng dẫn thi hành Điều lệ Đảng để làm rõ việc tổ chức lễ kết nạp trong cùng buổi sinh hoạt chi bộ và những điều kiện cần bảo đảm.

---

ASSISTANT

---

ASSISTANT

Tôi đang áp dụng hướng dẫn của Cố vấn công tác Đảng, tập trung vào căn cứ hiện hành và cách tổ chức phù hợp với chi bộ.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

**Có thể bố trí lễ kết nạp đảng viên và sinh hoạt chi bộ trong cùng một buổi, nhưng cần tổ chức thành hai phần riêng, thực hiện đầy đủ chương trình của từng phần.** Không nên hiểu là chỉ đưa việc đọc quyết định, tuyên thệ vào giữa cuộc họp rồi coi đã hoàn thành lễ kết nạp.

**Vì sao có thể tổ chức cùng buổi?**

Hướng dẫn số **02-HD/TW ngày 07/8/2026 của Ban Bí thư**, tại mục 3.8, quy định lễ kết nạp phải trang nghiêm, đúng nghi thức và kết nạp từng người; không quy định bắt buộc phải tổ chức vào một ngày riêng. Vì vậy, từ các yêu cầu này, có thể bố trí lễ kết nạp trước hoặc sau sinh hoạt thường kỳ, miễn bảo đảm đầy đủ thủ tục. Đây là cách vận dụng tổ chức, không phải một điều khoản ghi trực tiếp “được kết hợp”. https://tulieuvankien.dangcongsan.vn/upload/2006988/20260818/hdtw02_signed_a0749.pdf
https://tulieuvankien.dangcongsan.vn/upload/2006988/20260818/hdtw02_signed_a0749.pdf?utm_source=chatgpt.com

Trong thực tế, các chi bộ cũng tổ chức sinh hoạt thường kỳ và lễ kết nạp trong cùng buổi, có cấp ủy cấp trên dự, chỉ đạo; chẳng hạn Chi bộ xóm Đoàn Kết, Đảng bộ xã Dân Tiến, ngày 03/8/2026. Thực tiễn này là minh họa, không thay thế căn cứ quy định. https://dantien.thainguyen.gov.vn/tin-noi-bat/dong-chi-bi-thu-dang-uy-xa-dan-tien-du-sinh-hoat-thuong-ky-va-le-ket-nap-dang-vien-moi-tai-chi-bo-x-284597
https://dantien.thainguyen.gov.vn/tin-noi-bat/dong-chi-bi-thu-dang-uy-xa-dan-tien-du-sinh-hoat-thuong-ky-va-le-ket-nap-dang-vien-moi-tai-chi-bo-x-284597?utm_source=chatgpt.com

**Trường hợp nào không được? Vì sao?**

- **Chưa có quyết định kết nạp của cấp ủy có thẩm quyền:** chi bộ chưa được tổ chức lễ kết nạp; việc chi bộ biểu quyết đề nghị kết nạp chưa thay thế quyết định này.
- **Chỉ đọc quyết định, cho tuyên thệ rồi tiếp tục họp, bỏ các nghi thức bắt buộc:** không bảo đảm chương trình lễ kết nạp theo mục 3.8, gồm chào cờ, công bố quyết định, tuyên thệ, giao nhiệm vụ và phân công đảng viên chính thức giúp đỡ, bế mạc… https://tulieuvankien.dangcongsan.vn/upload/2006988/20260818/hdtw02_signed_a0749.pdf
https://tulieuvankien.dangcongsan.vn/upload/2006988/20260818/hdtw02_signed_a0749.pdf?utm_source=chatgpt.com
- **Dùng lễ kết nạp để thay thế hoặc cắt giảm sinh hoạt thường kỳ:** không bảo đảm chế độ sinh hoạt. Hướng dẫn **42-HD/BTCTW ngày 28/10/2025** yêu cầu đầy đủ nội dung, quy trình và thời lượng sinh hoạt; đồng thời quy định: “Tuyệt đối không được họp chi bộ kết hợp với các cuộc họp khác.” Vì vậy, cần phân biệt bố trí nối tiếp hai hoạt động với gộp thành một chương trình lẫn lộn. https://sct.dongnai.gov.vn/vi/news/Dang-bo-So-Cong-Thuong/huong-dan-thuc-hien-sinh-hoat-chi-bo-trong-giai-doan-moi-51395.html?download=1&id=0
https://sct.dongnai.gov.vn/vi/news/Dang-bo-So-Cong-Thuong/huong-dan-thuc-hien-sinh-hoat-chi-bo-trong-giai-doan-moi-51395.html?download=1&id=0&utm_source=chatgpt.com

**Với Chi bộ Trường Mầm non An Bình, tôi đề xuất:** tổ chức **lễ kết nạp trước, bế mạc đầy đủ**, sau đó bắt đầu **sinh hoạt chi bộ thường kỳ** với chương trình riêng; bố trí đủ thời gian cho đánh giá, thảo luận và quyết nghị. Cách này vừa trang trọng, vừa giúp đảng viên mới tham gia ngay kỳ sinh hoạt đầu tiên sau khi được kết nạp.

---

