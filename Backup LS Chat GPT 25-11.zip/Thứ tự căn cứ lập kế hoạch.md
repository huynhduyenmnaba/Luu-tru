USER

Văn  bản cùng nôih dung. 1. UbND phường ngày 13/10. 1 văn bane của phonhg vh- xh ngày 12 tháng 10. Viết căn cứ nào trước khi lập KH

---

ASSISTANT

Với vai trò Hiệu trưởng khi xây dựng kế hoạch triển khai tại trường, **nên viện dẫn văn bản của UBND phường ngày 13/10 trước, sau đó đến văn bản của Phòng Văn hóa – Xã hội ngày 12/10**, mặc dù văn bản của Phòng ban hành sớm hơn một ngày.

**Lý do:**

- **Văn bản UBND phường:** Là văn bản chỉ đạo của cơ quan quản lý cấp trên, làm căn cứ chính để nhà trường xây dựng kế hoạch.
- **Văn bản Phòng Văn hóa – Xã hội:** Là văn bản hướng dẫn, triển khai thực hiện các nội dung thuộc lĩnh vực chuyên môn.

**Cách trình bày phần căn cứ:**

*Căn cứ Kế hoạch số …/KH-UBND ngày 13 tháng 10 năm 2026 của Ủy ban nhân dân phường An Bình về việc …;*

*Thực hiện Công văn số …/VHXH ngày 12 tháng 10 năm 2026 của Phòng Văn hóa – Xã hội phường An Bình về việc …;*

*Căn cứ tình hình thực tế của Trường Mầm non An Bình;*

*Trường Mầm non An Bình xây dựng Kế hoạch … với các nội dung cụ thể như sau:*

**Lưu ý:** Thứ tự viện dẫn không chỉ căn cứ vào ngày ban hành mà còn phụ thuộc vào tính chất, nội dung và mối quan hệ giữa các văn bản.

Nếu văn bản của Phòng Văn hóa – Xã hội ngày 12/10 là văn bản giao nhiệm vụ trực tiếp cho trường, còn văn bản UBND phường ngày 13/10 là kế hoạch chỉ đạo chung, thì vẫn có thể trình bày theo thứ tự trên, nhưng cần bảo đảm nội dung kế hoạch của trường thực hiện đầy đủ yêu cầu của cả hai văn bản.

---

