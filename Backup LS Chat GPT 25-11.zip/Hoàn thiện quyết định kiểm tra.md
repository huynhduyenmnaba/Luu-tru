USER

với vai trò hiệu trưởng và các văn bạn đính kèm, bạn hãy giúp tôi hoàn thành quyết định ban hành kiểm tra nội bộ theo đúng hướng dẫn các văn bản. Lặp luận logic chặt chẽ đảm  bảo đúng, đủ nội dung văn bản quy định

---

ASSISTANT

Tôi sẽ đối chiếu dự thảo của Trường Mầm non An Bình với mẫu của Sở GDĐT và các văn bản chỉ đạo của UBND phường, sau đó chỉnh lý Quyết định và hoàn thiện Kế hoạch kèm theo. Tôi sẽ rà soát kỹ căn cứ, thời hạn báo cáo, danh mục kiểm tra và trách nhiệm thực hiện để văn bản có thể sử dụng trong nhà trường.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 Rà soát và hoàn thiện Quyết định ban hành Kế hoạch kiểm tra nội bộ năm học 2026–2027

Tôi đã đối chiếu dự thảo của **Trường Mầm non An Bình** với Công văn số 1134/SGDĐT-TCCB của Sở GDĐT, Công văn số 3266/UBND-VX và Kế hoạch số 3458/KH-UBND của UBND phường An Bình.

## I. Những nội dung cần chỉnh sửa trước khi ban hành

| Nội dung | Kết quả rà soát và hướng xử lý |
|--------|--------|
| Thể thức quyết định | Áp dụng Mẫu số 01 kèm Công văn 1134; có Quyết định và Kế hoạch đính kèm. |
| Ngày ban hành | Dự thảo ghi 01/10/2026 nhưng dẫn Kế hoạch ngày 28/10/2026. Phải sửa ngày ký, không sớm hơn ngày 28/10/2026. |
| Căn cứ pháp lý | Bổ sung văn bản chỉ đạo KTNB năm 2026–2027 và cập nhật Điều lệ trường mầm non đã được sửa đổi năm 2026. |
| Nội dung kế hoạch | Cần cụ thể hóa các trọng tâm phù hợp cấp học mầm non, không sao chép máy móc nội dung dành cho phổ thông. |
| Danh mục các cuộc kiểm tra | Dự thảo đang để trống. Cần xác định nội dung, đối tượng, thời gian, hình thức và người phụ trách. |
| Quy trình, hồ sơ | Bổ sung quy trình kiểm tra, xử lý sau kiểm tra và các mẫu hồ sơ theo hướng dẫn của Sở. |
| Thời hạn báo cáo | Sửa hạn sơ kết trước 15/01/2027 và tổng kết trước 13/05/2027 theo Kế hoạch 3458, thay cho các mốc muộn hơn trong dự thảo. |

**Một điểm pháp lý mới:** Thông tư 52/2020/TT-BGDĐT về Điều lệ trường mầm non đã được sửa đổi, bổ sung bởi Thông tư 51/2026/TT-BGDĐT, có hiệu lực từ ngày 15/8/2026. Vì vậy, căn cứ này cần được cập nhật trong quyết định. [Thông tư số 51/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Sửa đổi, bổ sung một số điều của Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy chế tố chức, hoạt động nhóm trẻ độc lập, lớp mẫu giáo độc lập, lớp mầm non độc lập loại hình dân lập và tư thục ban hành kèm theo Thông tư số 49/2021/TT\-BGDĐT ngày 31 tháng 12 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy định tiêu chuẩn, quy trình biên soạn, chỉnh sửa Chương trình giáo dục mầm non, tổ chức và hoạt động của Hội đồng quốc gia thẩm định chương trình giáo dục mầm non ban hành kèm theo Thông tư số 49/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo](<https://vanban.chinhphu.vn/?classid=1&docid=218796&orggroupid=4&pageid=27160>)

Dưới đây là bản hoàn chỉnh theo hướng **Quyết định ban hành Kế hoạch kiểm tra nội bộ**, kèm Kế hoạch thực hiện và danh mục kiểm tra dự kiến 10 cuộc. Các vị trí chưa có dữ liệu xác thực như số văn bản, ngày ký được để trống để nhà trường điền đúng trước khi phát hành.

## II. Quyết định ban hành Kế hoạch kiểm tra nội bộ

> **writing · document**
>
> **ỦY BAN NHÂN DÂN PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> Số: ……/QĐ-MNAB
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập - Tự do - Hạnh phúc**
>
> *An Bình, ngày …… tháng 10 năm 2026*
>
> # QUYẾT ĐỊNH
> **Ban hành Kế hoạch kiểm tra nội bộ năm học 2026 - 2027**
>
> **HIỆU TRƯỞNG TRƯỜNG MẦM NON AN BÌNH**
>
> Căn cứ Thông tư số 52/2020/TT-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Điều lệ trường mầm non, được sửa đổi, bổ sung bởi Thông tư số 51/2026/TT-BGDĐT ngày 30 tháng 6 năm 2026 của Bộ trưởng Bộ Giáo dục và Đào tạo;
>
> Căn cứ Công văn số 4933/VP-VX ngày 19 tháng 8 năm 2026 của Văn phòng Hội đồng nhân dân và Ủy ban nhân dân phường An Bình về việc ban hành khung kế hoạch thời gian năm học 2026 - 2027 đối với giáo dục mầm non, giáo dục phổ thông và giáo dục thường xuyên;
>
> Căn cứ Công văn số 5375/VP-VX ngày 14 tháng 9 năm 2026 của Văn phòng Hội đồng nhân dân và Ủy ban nhân dân phường An Bình về việc hướng dẫn thực hiện nhiệm vụ giáo dục mầm non năm học 2026 - 2027;
>
> Thực hiện Công văn số 1134/SGDĐT-TCCB ngày 17 tháng 10 năm 2025 của Sở Giáo dục và Đào tạo Đồng Tháp về việc hướng dẫn thực hiện công tác kiểm tra nội bộ năm học 2025 - 2026;
>
> Thực hiện Công văn số 3953/SGDĐT-TCCB ngày 08 tháng 10 năm 2026 của Sở Giáo dục và Đào tạo Đồng Tháp về việc thực hiện công tác kiểm tra nội bộ tại đơn vị năm học 2026 - 2027;
>
> Thực hiện Công văn số 3266/UBND-VX ngày 13 tháng 10 năm 2026 của Ủy ban nhân dân phường An Bình về việc triển khai và hướng dẫn công tác kiểm tra nội bộ tại các cơ sở giáo dục năm học 2026 - 2027;
>
> Thực hiện Kế hoạch số 3458/KH-UBND ngày 28 tháng 10 năm 2026 của Ủy ban nhân dân phường An Bình về việc triển khai thực hiện công tác kiểm tra nội bộ tại các cơ sở giáo dục năm học 2026 - 2027;
>
> Xét đề nghị của Tổ Văn phòng Trường Mầm non An Bình,
>
> **QUYẾT ĐỊNH:**
>
> **Điều 1.** Ban hành kèm theo Quyết định này Kế hoạch kiểm tra nội bộ năm học 2026 - 2027 của Trường Mầm non An Bình.
>
> **Điều 2.** Quyết định này có hiệu lực kể từ ngày ký.
>
> Ban Giám hiệu, các tổ chuyên môn, Tổ Văn phòng, cán bộ quản lý, giáo viên, nhân viên Trường Mầm non An Bình và các tổ chức, cá nhân có liên quan chịu trách nhiệm thi hành Quyết định này./.
>
> **Nơi nhận:**
>
> - Như Điều 2;
> - UBND phường An Bình (để báo cáo);
> - Phòng Văn hóa - Xã hội (để tổng hợp);
> - Lưu: VT.
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên và đóng dấu)*
>
> **Huỳnh Hồng Loan**

Quyết định được giữ gọn theo cấu trúc Mẫu số 01. Nội dung triển khai, quy trình và phân công chi tiết được đưa vào Kế hoạch kèm theo, tránh lặp lại trong phần quyết định.

## III. Kế hoạch kiểm tra nội bộ ban hành kèm theo Quyết định

Bản kế hoạch dưới đây được xây dựng theo 4 phần chính của mẫu Sở GDĐT: mục đích, yêu cầu; nội dung kiểm tra; tổ chức thực hiện; danh mục các cuộc kiểm tra. Lịch 10 cuộc là phương án đề xuất để nhà trường tổ chức thực hiện, không phải chỉ tiêu bắt buộc do Sở quy định.

> **writing · document**
>
> **ỦY BAN NHÂN DÂN PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> Số: ……/KH-MNAB
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập - Tự do - Hạnh phúc**
>
> *An Bình, ngày …… tháng 10 năm 2026*
>
> # KẾ HOẠCH
> **Kiểm tra nội bộ năm học 2026 - 2027**
>
> *(Ban hành kèm theo Quyết định số ……/QĐ-MNAB ngày …… tháng 10 năm 2026 của Hiệu trưởng Trường Mầm non An Bình)*
>
> ## I. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> Tăng cường hiệu lực, hiệu quả công tác quản lý, chỉ đạo và điều hành của Hiệu trưởng; đánh giá khách quan, thực chất việc chấp hành các quy định của pháp luật, các văn bản chỉ đạo của ngành và việc thực hiện nhiệm vụ năm học của các tổ chuyên môn, bộ phận, cán bộ quản lý, giáo viên, nhân viên trong nhà trường.
>
> Thông qua hoạt động kiểm tra nội bộ, kịp thời phát hiện những ưu điểm, cách làm hiệu quả để biểu dương, nhân rộng; đồng thời xác định những hạn chế, thiếu sót, nguyên nhân và trách nhiệm có liên quan để đề ra biện pháp chấn chỉnh, khắc phục phù hợp, góp phần nâng cao chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> Chủ động phòng ngừa, phát hiện và xử lý hoặc kiến nghị xử lý những hành vi vi phạm theo thẩm quyền; nâng cao ý thức trách nhiệm, tinh thần tự giác và năng lực thực hiện nhiệm vụ của đội ngũ cán bộ quản lý, giáo viên, nhân viên.
>
> Tăng cường kiểm tra việc thực hiện các kiến nghị, biện pháp khắc phục hạn chế sau kiểm tra; từng bước nâng cao chất lượng quản trị nhà trường, bảo đảm môi trường giáo dục an toàn, lành mạnh, thân thiện, lấy trẻ làm trung tâm.
>
> ### 2. Yêu cầu
>
> Công tác kiểm tra nội bộ phải được thực hiện theo đúng quy định pháp luật, hướng dẫn của Sở Giáo dục và Đào tạo, chỉ đạo của Ủy ban nhân dân phường An Bình và phù hợp với chức năng, nhiệm vụ, điều kiện thực tế của nhà trường.
>
> Nội dung kiểm tra phải có trọng tâm, trọng điểm, bám sát nhiệm vụ năm học 2026 - 2027, gắn với việc rà soát, khắc phục những hạn chế của năm học 2025 - 2026; ưu tiên các lĩnh vực có nguy cơ phát sinh sai sót hoặc ảnh hưởng trực tiếp đến an toàn, sức khỏe và chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Hoạt động kiểm tra bảo đảm tính chính xác, khách quan, công khai, dân chủ, kịp thời; không chồng chéo về nội dung, đối tượng, thời gian; không gây áp lực không cần thiết hoặc làm ảnh hưởng đến hoạt động bình thường của nhà trường.
>
> Việc nhận xét, đánh giá, kết luận phải dựa trên hồ sơ, tài liệu, minh chứng và kết quả kiểm tra thực tế; xác định rõ ưu điểm, hạn chế, nguyên nhân, trách nhiệm và biện pháp khắc phục. Không đưa ra nhận định thiếu căn cứ hoặc vượt thẩm quyền.
>
> Thực hiện đầy đủ quy trình kiểm tra, lập và lưu trữ hồ sơ theo hướng dẫn; bảo đảm các đối tượng được kiểm tra có điều kiện trình bày ý kiến, giải trình và tiếp nhận kết quả kiểm tra.
>
> ## II. NỘI DUNG KIỂM TRA NỘI BỘ
>
> ### 1. Phạm vi, đối tượng, thời kỳ và hình thức kiểm tra
>
> **1.1. Phạm vi, đối tượng kiểm tra**
>
> Hoạt động quản lý, điều hành của Ban Giám hiệu; việc thực hiện nhiệm vụ của các tổ chuyên môn, Tổ Văn phòng, các bộ phận và cá nhân thuộc phạm vi quản lý của Trường Mầm non An Bình.
>
> Đối tượng kiểm tra gồm cán bộ quản lý, giáo viên, nhân viên, các tổ chuyên môn, Tổ Văn phòng và các bộ phận có liên quan đến hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ và quản trị nhà trường.
>
> **1.2. Thời kỳ và thời gian kiểm tra**
>
> Thời kỳ kiểm tra chủ yếu là năm học 2026 - 2027; đối với từng nội dung, thời kỳ kiểm tra cụ thể được xác định trong quyết định kiểm tra, có thể bao gồm hồ sơ, kết quả thực hiện từ đầu năm học đến thời điểm kiểm tra.
>
> Dự kiến tổ chức **10 cuộc kiểm tra theo kế hoạch** từ tháng 11 năm 2026 đến đầu tháng 5 năm 2027, theo Danh mục tại Mục IV của Kế hoạch này.
>
> Thời hạn thực hiện từng cuộc kiểm tra, thành phần tổ kiểm tra và đối tượng kiểm tra cụ thể được xác định tại quyết định kiểm tra của Hiệu trưởng.
>
> Ngoài kiểm tra theo kế hoạch, nhà trường tổ chức kiểm tra đột xuất khi có chỉ đạo của cấp có thẩm quyền hoặc khi phát sinh vụ việc cần kiểm tra thuộc phạm vi quản lý, bảo đảm đúng thẩm quyền và quy trình.
>
> **1.3. Hình thức kiểm tra**
>
> Kiểm tra hồ sơ, sổ sách, dữ liệu điện tử; kiểm tra, quan sát thực tế; dự giờ, quan sát hoạt động chăm sóc và giáo dục trẻ; trao đổi, xác minh thông tin; làm việc trực tiếp với tổ chức, bộ phận, cá nhân có liên quan.
>
> Lựa chọn hình thức phù hợp với nội dung, đối tượng kiểm tra; chú trọng kiểm chứng giữa hồ sơ và kết quả thực hiện thực tế, hạn chế hình thức, tránh yêu cầu phát sinh hồ sơ không cần thiết.
>
> ### 2. Nội dung kiểm tra trọng tâm
>
> **2.1. Kiểm tra công tác quản lý, chỉ đạo và điều hành của nhà trường**
>
> Kiểm tra việc xây dựng, ban hành, cập nhật và tổ chức thực hiện chiến lược phát triển nhà trường, kế hoạch thực hiện nhiệm vụ năm học, kế hoạch giáo dục, quy chế tổ chức và hoạt động, quy chế thực hiện dân chủ ở cơ sở; việc công khai các nội dung theo quy định.
>
> Kiểm tra công tác phân công nhiệm vụ, quản lý, sử dụng, đánh giá, bồi dưỡng đội ngũ; thực hiện chế độ, chính sách đối với cán bộ quản lý, giáo viên, nhân viên và người lao động theo thẩm quyền.
>
> Kiểm tra công tác giáo dục chính trị, tư tưởng; phổ biến, giáo dục pháp luật; thực hiện đạo đức nhà giáo, văn hóa ứng xử; công tác thi đua, khen thưởng, thực hành tiết kiệm, chống lãng phí và phòng, chống tham nhũng.
>
> Kiểm tra việc thực hiện trách nhiệm phối hợp giữa nhà trường với chính quyền địa phương, các tổ chức đoàn thể, Ban đại diện cha mẹ trẻ và các tổ chức, cá nhân liên quan; công tác truyền thông, tiếp nhận và giải quyết ý kiến, kiến nghị, phản ánh thuộc thẩm quyền.
>
> Kiểm tra công tác quản lý hành chính, tài chính, tài sản, cơ sở vật chất, trang thiết bị, thực hiện công khai; trách nhiệm tổ chức thực hiện và kiểm tra, giám sát các nhiệm vụ được giao.
>
> **2.2. Kiểm tra việc thực hiện nhiệm vụ chăm sóc, nuôi dưỡng và giáo dục trẻ**
>
> Kiểm tra việc xây dựng, triển khai và điều chỉnh kế hoạch giáo dục của nhà trường, tổ chuyên môn và các nhóm, lớp; mức độ phù hợp với Chương trình Giáo dục mầm non, điều kiện thực tế và nhu cầu phát triển của trẻ.
>
> Kiểm tra công tác tổ chức các hoạt động giáo dục, xây dựng môi trường giáo dục lấy trẻ làm trung tâm; việc lựa chọn nội dung, phương pháp, hình thức tổ chức các hoạt động phù hợp với đặc điểm tâm sinh lý, độ tuổi và khả năng của trẻ.
>
> Kiểm tra việc tổ chức chế độ sinh hoạt hằng ngày, quản lý trẻ, bảo đảm an toàn trong các hoạt động; công tác phối hợp với cha mẹ trẻ, quan tâm hỗ trợ trẻ có nhu cầu đặc biệt, trẻ khuyết tật học hòa nhập khi có đối tượng.
>
> Kiểm tra việc quan sát, theo dõi và đánh giá sự phát triển của trẻ; sử dụng kết quả đánh giá để điều chỉnh kế hoạch chăm sóc, nuôi dưỡng, giáo dục phù hợp; việc quản lý và lưu trữ hồ sơ theo quy định.
>
> **2.3. Kiểm tra hoạt động sư phạm của giáo viên và hoạt động của các tổ chuyên môn**
>
> Kiểm tra việc chấp hành quy định về đạo đức nhà giáo, quy tắc ứng xử, thời gian làm việc, nội quy và quy chế chuyên môn của nhà trường.
>
> Kiểm tra việc xây dựng, thực hiện kế hoạch giáo dục, chuẩn bị và tổ chức các hoạt động chăm sóc, giáo dục trẻ; quản lý nhóm, lớp; bảo đảm an toàn thể chất và tinh thần cho trẻ.
>
> Đánh giá năng lực tổ chức hoạt động giáo dục của giáo viên thông qua dự giờ, quan sát thực tế, hồ sơ chuyên môn, kết quả chăm sóc, giáo dục và sự phát triển của trẻ; chú trọng tư vấn, hỗ trợ và nâng cao năng lực nghề nghiệp.
>
> Kiểm tra việc tham gia sinh hoạt chuyên môn, tự học, tự bồi dưỡng, ứng dụng công nghệ thông tin, chuyển đổi số; tinh thần phối hợp với đồng nghiệp và cha mẹ trẻ.
>
> Kiểm tra công tác quản lý của tổ trưởng chuyên môn; xây dựng và thực hiện kế hoạch tổ; quản lý hồ sơ, tổ chức sinh hoạt chuyên môn, bồi dưỡng giáo viên, kiểm tra việc thực hiện nhiệm vụ của các thành viên và triển khai các chuyên đề giáo dục mầm non.
>
> **2.4. Kiểm tra hoạt động của Tổ Văn phòng và nhân viên**
>
> Kiểm tra việc xây dựng kế hoạch công tác, thực hiện chức trách, nhiệm vụ, thời gian lao động, nội quy, quy chế làm việc của các nhân viên và bộ phận phục vụ hoạt động giáo dục.
>
> Kiểm tra công tác văn thư, hành chính, quản lý và sử dụng con dấu; tiếp nhận, xử lý, ban hành và lưu trữ văn bản; quản lý hồ sơ, sổ sách và việc phối hợp giữa Tổ Văn phòng với các tổ chuyên môn.
>
> Kiểm tra công tác kế toán, thủ quỹ, quản lý thu - chi ngân sách, các khoản thu dịch vụ và các nguồn kinh phí hợp pháp khác; việc thực hiện chế độ kế toán, chứng từ, thanh quyết toán, công khai tài chính và các quy định liên quan.
>
> Kiểm tra việc quản lý, sử dụng và bảo quản tài sản, cơ sở vật chất, trang thiết bị, đồ dùng, đồ chơi; công tác kiểm kê, duy tu, sửa chữa, mua sắm và sử dụng tài sản đúng mục đích, tiết kiệm, hiệu quả.
>
> Kiểm tra công tác phối hợp và các hồ sơ liên quan đến hoạt động của Ban đại diện cha mẹ trẻ, việc huy động, tiếp nhận và sử dụng các nguồn hỗ trợ hợp pháp theo quy định, nếu có phát sinh.
>
> Kiểm tra hoạt động của nhân viên y tế, bảo vệ, cấp dưỡng và các vị trí việc làm khác; việc thực hiện quy định về an toàn lao động, vệ sinh môi trường và trách nhiệm bảo vệ, chăm sóc trẻ.
>
> **2.5. Kiểm tra công tác bán trú, an toàn trường học và y tế**
>
> Kiểm tra việc tổ chức và quản lý hoạt động bán trú; điều kiện cơ sở vật chất, trang thiết bị phục vụ nuôi dưỡng; quy trình giao nhận, chế biến, chia ăn và tổ chức bữa ăn cho trẻ.
>
> Kiểm tra nguồn gốc, chất lượng thực phẩm, việc thực hiện quy định về an toàn thực phẩm, vệ sinh bếp ăn, kiểm thực, lưu mẫu thức ăn, hồ sơ có liên quan và trách nhiệm của nhân viên nuôi dưỡng.
>
> Kiểm tra việc xây dựng thực đơn, khẩu phần ăn, theo dõi tình trạng dinh dưỡng và sức khỏe trẻ; thực hiện các biện pháp phòng, chống suy dinh dưỡng, thừa cân, béo phì và phòng, chống dịch bệnh.
>
> Kiểm tra việc bảo đảm an ninh, an toàn trường học; phòng cháy, chữa cháy; phòng, chống tai nạn thương tích, bạo lực và xâm hại trẻ em; an toàn đồ dùng, đồ chơi, sân chơi, phòng học, hệ thống điện, nước sạch và công trình vệ sinh.
>
> Kiểm tra các phương án phòng ngừa, xử lý tình huống khẩn cấp, phân công trách nhiệm bảo đảm an toàn cho trẻ và việc thực hiện công tác y tế trường học.
>
> **2.6. Kiểm tra công tác chuyển đổi số, dữ liệu ngành và quản lý chất lượng**
>
> Kiểm tra việc xây dựng, triển khai kế hoạch chuyển đổi số; phân công trách nhiệm, sử dụng phần mềm quản lý, hệ thống văn bản điện tử, chữ ký số và các ứng dụng công nghệ thông tin phục vụ quản lý, chăm sóc, giáo dục trẻ.
>
> Kiểm tra việc cập nhật, chuẩn hóa, quản lý và khai thác cơ sở dữ liệu ngành theo yêu cầu **“Đúng - Đủ - Sạch - Sống”**; độ chính xác, đồng bộ, tính kịp thời của thông tin, số liệu và các báo cáo.
>
> Kiểm tra việc thực hiện các biện pháp bảo đảm an toàn, bảo mật thông tin; quản lý, sử dụng tài khoản và dữ liệu thuộc phạm vi trách nhiệm.
>
> Kiểm tra việc thống kê, báo cáo kết quả nuôi dưỡng, chăm sóc, giáo dục; công tác tự đánh giá, kiểm định chất lượng giáo dục, cải tiến chất lượng và lưu trữ hồ sơ minh chứng theo quy định.
>
> ### 3. Rà soát, lựa chọn nội dung và tập trung khắc phục hạn chế
>
> Căn cứ kết quả thực hiện nhiệm vụ, báo cáo tổng kết, hồ sơ kiểm tra nội bộ năm học 2025 - 2026, các kiến nghị của cơ quan quản lý và tình hình thực tế năm học 2026 - 2027, nhà trường tổ chức rà soát, xác định những nội dung còn hạn chế, thiếu sót hoặc có nguy cơ phát sinh sai sót để ưu tiên kiểm tra.
>
> Trong quá trình thực hiện, tập trung kiểm soát các lĩnh vực có ảnh hưởng trực tiếp đến chất lượng và uy tín của nhà trường, đặc biệt là an toàn của trẻ; an toàn thực phẩm và chất lượng bán trú; quản lý tài chính, các khoản thu, tài sản và công khai; chất lượng thực hiện chương trình giáo dục; việc cập nhật cơ sở dữ liệu ngành và thực hiện nhiệm vụ của đội ngũ.
>
> Đối với các hạn chế đã được chỉ ra qua kiểm tra, xác định rõ nội dung cần khắc phục, bộ phận hoặc cá nhân chịu trách nhiệm, thời hạn hoàn thành và minh chứng kết quả. Tổ chức kiểm tra lại việc thực hiện kiến nghị sau kiểm tra, không chỉ dừng ở việc ban hành thông báo kết quả.
>
> Khi kết quả rà soát thực tế cho thấy cần thay đổi thứ tự ưu tiên hoặc bổ sung nội dung kiểm tra, Hiệu trưởng xem xét điều chỉnh kế hoạch bằng văn bản theo thẩm quyền, bảo đảm phù hợp chỉ đạo của cấp trên.
>
> ## III. TỔ CHỨC THỰC HIỆN
>
> ### 1. Các biện pháp thực hiện
>
> **1.1. Thành lập và kiện toàn Ban kiểm tra nội bộ**
>
> Hiệu trưởng ban hành Quyết định thành lập Ban kiểm tra nội bộ năm học 2026 - 2027 theo Mẫu số 02 kèm Công văn số 1134/SGDĐT-TCCB.
>
> Ban kiểm tra nội bộ gồm Trưởng ban, Phó Trưởng ban và các thành viên được lựa chọn phù hợp với quy mô, đặc điểm tổ chức của nhà trường; ưu tiên những người có phẩm chất đạo đức tốt, uy tín, năng lực chuyên môn và khả năng thực hiện nhiệm vụ kiểm tra.
>
> Hiệu trưởng chỉ đạo xây dựng, hoàn thiện Quy chế hoạt động của Ban kiểm tra nội bộ; phân công nhiệm vụ cụ thể, tổ chức hướng dẫn, bồi dưỡng nghiệp vụ kiểm tra cho các thành viên.
>
> Bảo đảm nguyên tắc khách quan trong phân công, không giao cá nhân trực tiếp kiểm tra, đánh giá phần việc do chính mình thực hiện. Những nội dung liên quan đến trách nhiệm quản lý của Hiệu trưởng phải được rà soát trên cơ sở minh chứng khách quan; trường hợp cần thiết báo cáo cơ quan quản lý cấp trên để được chỉ đạo.
>
> **1.2. Thực hiện quy trình kiểm tra nội bộ**
>
> Mỗi cuộc kiểm tra được tổ chức theo 03 bước:
>
> **Bước 1. Chuẩn bị kiểm tra**
>
> Căn cứ Kế hoạch kiểm tra nội bộ năm học, Hiệu trưởng ban hành Quyết định kiểm tra từng cuộc hoặc từng đợt, xác định rõ nội dung, đối tượng, thời kỳ, thời hạn kiểm tra và thành phần đoàn hoặc tổ kiểm tra.
>
> Trưởng đoàn hoặc Tổ trưởng kiểm tra xây dựng Kế hoạch tiến hành kiểm tra theo Mẫu số 03, phân công nhiệm vụ cho thành viên, chuẩn bị hồ sơ, tài liệu, biểu mẫu; trình Hiệu trưởng phê duyệt và thông báo nội dung, lịch làm việc đến đối tượng kiểm tra theo yêu cầu của từng cuộc kiểm tra.
>
> **Bước 2. Tiến hành kiểm tra**
>
> Thu thập, nghiên cứu hồ sơ, tài liệu, minh chứng; kiểm tra thực tế hoạt động của đối tượng; trao đổi, làm rõ những nội dung cần xác minh và ghi nhận ý kiến giải trình, phản hồi.
>
> Lập Biên bản kiểm tra theo Mẫu số 04, thể hiện đầy đủ nội dung đã kiểm tra, kết quả ghi nhận, ưu điểm, tồn tại, nguyên nhân, kiến nghị và ý kiến của đối tượng kiểm tra; có xác nhận của các bên theo quy định.
>
> Mọi nhận xét phải có căn cứ, đối chiếu với quy định hoặc nhiệm vụ được giao; không kết luận thiếu cơ sở hoặc suy diễn từ những thông tin chưa được xác minh.
>
> **Bước 3. Kết thúc kiểm tra**
>
> Trưởng đoàn hoặc Tổ trưởng kiểm tra tổng hợp kết quả, lập Báo cáo kết quả kiểm tra theo Mẫu số 05, nêu rõ quá trình kiểm tra, kết quả xác minh, nhận xét, đánh giá từng nội dung, trách nhiệm có liên quan và kiến nghị biện pháp xử lý, khắc phục.
>
> Căn cứ Báo cáo kết quả kiểm tra và các tài liệu có liên quan, Hiệu trưởng xem xét, xác minh bổ sung khi cần thiết, ban hành Thông báo kết quả kiểm tra theo Mẫu số 06; gửi đến đối tượng kiểm tra, các cá nhân, bộ phận liên quan và thực hiện công khai theo hướng dẫn.
>
> Thông báo kết quả kiểm tra phải nêu rõ ưu điểm, hạn chế, nguyên nhân, trách nhiệm, biện pháp và thời hạn khắc phục; bảo đảm khách quan, đúng thẩm quyền, đồng thời bảo vệ các thông tin thuộc diện cần bảo mật.
>
> **1.3. Theo dõi, xử lý và kiểm tra việc khắc phục sau kiểm tra**
>
> Hiệu trưởng chỉ đạo các bộ phận, cá nhân được kiểm tra xây dựng hoặc thực hiện biện pháp khắc phục theo nội dung Thông báo kết quả kiểm tra; phân công người theo dõi, đôn đốc và xác nhận kết quả thực hiện.
>
> Định kỳ trong các cuộc họp giao ban, sinh hoạt chuyên môn hoặc hội nghị của nhà trường, thông tin kết quả kiểm tra và tình hình khắc phục hạn chế; biểu dương, nhân rộng các mô hình, cách làm hiệu quả; nhắc nhở, chấn chỉnh các thiếu sót theo quy định.
>
> Đối với những vấn đề có nguy cơ ảnh hưởng đến an toàn của trẻ, sức khỏe, tài sản hoặc hoạt động chung của nhà trường, phải kịp thời áp dụng hoặc kiến nghị biện pháp xử lý phù hợp, không chờ đến kỳ kiểm tra tiếp theo.
>
> Kết quả kiểm tra và mức độ thực hiện kiến nghị sau kiểm tra là một trong những nguồn thông tin phục vụ việc đánh giá kết quả thực hiện nhiệm vụ, thi đua và xây dựng kế hoạch cải tiến chất lượng theo quy định.
>
> **1.4. Lập và lưu trữ hồ sơ kiểm tra nội bộ**
>
> Hồ sơ kiểm tra nội bộ năm học gồm Quyết định ban hành Kế hoạch, Kế hoạch kiểm tra nội bộ, Quyết định thành lập Ban kiểm tra nội bộ, Quy chế hoạt động của Ban và các tài liệu chỉ đạo, phân công có liên quan.
>
> Hồ sơ từng cuộc kiểm tra gồm Quyết định kiểm tra; Kế hoạch tiến hành kiểm tra; hồ sơ, tài liệu và minh chứng thu thập; báo cáo hoặc giải trình của đối tượng kiểm tra nếu có; Biên bản kiểm tra; Báo cáo kết quả kiểm tra; Thông báo kết quả kiểm tra; hồ sơ theo dõi, thực hiện kiến nghị sau kiểm tra và nhật ký đoàn, tổ kiểm tra nếu có.
>
> Sau khi hoàn tất cuộc kiểm tra, Trưởng đoàn hoặc Tổ trưởng kiểm tra bàn giao hồ sơ cho bộ phận văn thư để quản lý, lưu trữ theo từng cuộc, bảo đảm thuận tiện cho việc tra cứu, kiểm chứng và phục vụ công tác quản lý.
>
> Việc quản lý, lập hồ sơ và lưu trữ thực hiện theo Nghị định số 30/2020/NĐ-CP ngày 05 tháng 3 năm 2020 của Chính phủ về công tác văn thư; Thông tư số 08/2025/TT-BGDĐT ngày 12 tháng 5 năm 2025 của Bộ Giáo dục và Đào tạo quy định thời hạn lưu trữ hồ sơ, tài liệu thuộc lĩnh vực giáo dục và đào tạo cùng các quy định pháp luật có liên quan.
>
> ### 2. Trách nhiệm thực hiện
>
> **2.1. Hiệu trưởng**
>
> Chịu trách nhiệm chung về công tác kiểm tra nội bộ của nhà trường; chỉ đạo xây dựng, ban hành và tổ chức thực hiện Kế hoạch kiểm tra nội bộ năm học 2026 - 2027.
>
> Ban hành Quyết định thành lập Ban kiểm tra nội bộ, các quyết định kiểm tra theo kế hoạch hoặc đột xuất; phê duyệt kế hoạch tiến hành kiểm tra và phân công nhiệm vụ phù hợp.
>
> Chỉ đạo, giám sát tiến độ và chất lượng các cuộc kiểm tra; xem xét báo cáo, ban hành Thông báo kết quả kiểm tra; quyết định hoặc kiến nghị biện pháp xử lý thuộc thẩm quyền; theo dõi, kiểm tra việc thực hiện các kiến nghị sau kiểm tra.
>
> Tổ chức đánh giá, rút kinh nghiệm, điều chỉnh kế hoạch khi cần thiết; chỉ đạo thực hiện đầy đủ chế độ thông tin, báo cáo với cơ quan quản lý cấp trên.
>
> **2.2. Phó Hiệu trưởng**
>
> Căn cứ lĩnh vực được phân công phụ trách, phối hợp tham mưu triển khai kế hoạch; chỉ đạo các tổ chuyên môn, bộ phận chuẩn bị hồ sơ, minh chứng; tham gia hoạt động kiểm tra theo quyết định và phân công của Hiệu trưởng.
>
> Theo dõi việc thực hiện nhiệm vụ và khắc phục các hạn chế trong lĩnh vực phụ trách; tổng hợp kết quả, báo cáo Hiệu trưởng theo quy định.
>
> **2.3. Ban kiểm tra nội bộ và các đoàn, tổ kiểm tra**
>
> Thực hiện nhiệm vụ theo quyết định và phân công; tổ chức kiểm tra bảo đảm đúng nội dung, trình tự, thủ tục, thời gian và phạm vi được giao.
>
> Chịu trách nhiệm về tính chính xác, khách quan của kết quả kiểm tra; lập hồ sơ đầy đủ, báo cáo kịp thời; đề xuất biện pháp khắc phục phù hợp, có khả năng thực hiện.
>
> Theo dõi, xác minh kết quả khắc phục theo nhiệm vụ được giao; bảo quản tài liệu, thông tin thu thập trong quá trình kiểm tra theo quy định.
>
> **2.4. Các tổ chuyên môn, Tổ Văn phòng**
>
> Tổ trưởng chịu trách nhiệm phổ biến Kế hoạch đến các thành viên; tổ chức tự rà soát việc thực hiện nhiệm vụ của tổ và cá nhân; chuẩn bị hồ sơ, tài liệu liên quan theo yêu cầu của từng cuộc kiểm tra.
>
> Phối hợp với Ban kiểm tra nội bộ, thực hiện đầy đủ kết luận, kiến nghị thuộc phạm vi trách nhiệm; báo cáo kết quả khắc phục đúng thời hạn.
>
> Tổ Văn phòng tham mưu công tác tổng hợp, theo dõi, bảo đảm điều kiện phục vụ kiểm tra; thực hiện công tác văn thư, lưu trữ hồ sơ và tổng hợp báo cáo theo chỉ đạo của Hiệu trưởng.
>
> **2.5. Giáo viên, nhân viên**
>
> Nghiêm túc thực hiện chức trách, nhiệm vụ được giao; chủ động tự kiểm tra, rà soát, hoàn thiện việc thực hiện nhiệm vụ và hồ sơ chuyên môn theo quy định.
>
> Cung cấp thông tin, tài liệu, minh chứng trung thực, đầy đủ; phối hợp với đoàn, tổ kiểm tra và thực hiện các kiến nghị, biện pháp khắc phục sau kiểm tra.
>
> Kịp thời phản ánh khó khăn, vướng mắc với người phụ trách và Hiệu trưởng để được hướng dẫn, giải quyết.
>
> ### 3. Chế độ thông tin, báo cáo
>
> Nhà trường thực hiện chế độ thông tin, báo cáo về công tác kiểm tra nội bộ năm học 2026 - 2027 với Ủy ban nhân dân phường An Bình **(qua Phòng Văn hóa - Xã hội)** để tổng hợp, báo cáo Sở Giáo dục và Đào tạo theo quy định, cụ thể:
>
> **Trước ngày 31/10/2026:** Gửi Quyết định ban hành Kế hoạch kiểm tra nội bộ, Kế hoạch kiểm tra nội bộ kèm theo và Quyết định thành lập Ban kiểm tra nội bộ năm học 2026 - 2027.
>
> **Trước ngày 15/01/2027:** Gửi Báo cáo sơ kết công tác kiểm tra nội bộ học kỳ I năm học 2026 - 2027.
>
> **Trước ngày 13/05/2027:** Gửi Báo cáo tổng kết công tác kiểm tra nội bộ năm học 2026 - 2027.
>
> Thực hiện báo cáo đột xuất khi có vấn đề phức tạp phát sinh hoặc khi có yêu cầu của cơ quan quản lý cấp trên.
>
> Hiệu trưởng giao Tổ Văn phòng phối hợp với các Phó Hiệu trưởng, Ban kiểm tra nội bộ và các bộ phận có liên quan tổng hợp số liệu, hồ sơ minh chứng, tham mưu báo cáo bảo đảm chính xác, đầy đủ, đúng thời hạn.
>
> ## IV. DANH MỤC CÁC CUỘC KIỂM TRA
>
> **Tổng số cuộc kiểm tra dự kiến: 10 cuộc.**
>
> | TT | Nội dung kiểm tra | Đối tượng kiểm tra | Thời gian tiến hành | Hình thức kiểm tra | Người phụ trách | Ghi chú |
> |---|---|---|---|---|---|---|
> | 1 | Công tác quản lý, điều hành; kế hoạch năm học, quy chế, công khai, quản lý đội ngũ và việc thực hiện nhiệm vụ của Ban Giám hiệu | Ban Giám hiệu và bộ phận liên quan | 11/2026 | Hồ sơ, xác minh, trao đổi | Trưởng ban KTNB phân công thành viên phù hợp | Chú trọng rà soát hạn chế năm trước |
> | 2 | Hoạt động sư phạm giáo viên đợt I; thực hiện chương trình, kế hoạch giáo dục, nền nếp nhóm lớp và bảo đảm an toàn cho trẻ | Giáo viên, nhóm lớp theo danh sách kiểm tra | 11/2026 | Hồ sơ, dự giờ, quan sát thực tế | Phó Hiệu trưởng phụ trách chuyên môn | Xác định giáo viên cụ thể trong quyết định kiểm tra |
> | 3 | Quản lý tài chính, các khoản thu - chi, công khai, sử dụng kinh phí, quản lý tài sản và các nguồn hỗ trợ hợp pháp (nếu có) | Bộ phận kế toán, thủ quỹ và bộ phận liên quan | 12/2026 | Hồ sơ, chứng từ, đối chiếu thực tế | Hiệu trưởng phân công tổ kiểm tra | Người kiểm tra không trực tiếp phụ trách nghiệp vụ được kiểm tra |
> | 4 | Công tác nuôi dưỡng, bán trú; thực đơn, khẩu phần, an toàn thực phẩm, vệ sinh bếp ăn, chăm sóc sức khỏe trẻ | Bộ phận cấp dưỡng, y tế, giáo viên và bộ phận liên quan | 12/2026 | Hồ sơ, quan sát, kiểm tra thực tế | Phó Hiệu trưởng phụ trách nuôi dưỡng | Kiểm tra trọng tâm an toàn thực phẩm |
> | 5 | Công tác chuyển đổi số, dữ liệu ngành, báo cáo thống kê, văn thư và quản lý hồ sơ hành chính | Tổ Văn phòng, người phụ trách dữ liệu và bộ phận liên quan | 01/2027 | Hồ sơ điện tử, dữ liệu, đối chiếu | Trưởng ban KTNB phân công | Trọng tâm “Đúng - Đủ - Sạch - Sống” |
> | 6 | Hoạt động của tổ chuyên môn; sinh hoạt chuyên môn, bồi dưỡng giáo viên, theo dõi và đánh giá sự phát triển của trẻ | Các tổ chuyên môn, giáo viên liên quan | 02/2027 | Hồ sơ, dự sinh hoạt, trao đổi | Phó Hiệu trưởng phụ trách chuyên môn | Chú trọng chất lượng, hiệu quả thực tế |
> | 7 | Hoạt động sư phạm giáo viên đợt II; đổi mới phương pháp, tổ chức môi trường giáo dục lấy trẻ làm trung tâm | Giáo viên, nhóm lớp theo danh sách kiểm tra | 03/2027 | Dự giờ, quan sát, hồ sơ | Phó Hiệu trưởng phụ trách chuyên môn | Không chồng chéo đợt I |
> | 8 | An toàn trường học, phòng cháy chữa cháy, phòng chống tai nạn thương tích, y tế; rà soát việc bảo đảm an toàn trong hoạt động bán trú | Bộ phận y tế, bảo vệ, cấp dưỡng, các nhóm lớp | 03/2027 | Kiểm tra thực tế, hồ sơ, xác minh | Hiệu trưởng phân công tổ kiểm tra | Ưu tiên nguy cơ ảnh hưởng đến trẻ |
> | 9 | Việc thực hiện nhiệm vụ của nhân viên, hoạt động Tổ Văn phòng; công tác hành chính, chế độ chính sách, tài sản và thiết bị | Tổ Văn phòng và các nhân viên liên quan | 04/2027 | Hồ sơ, đối chiếu, kiểm tra thực tế | Trưởng ban KTNB phân công | Không lặp lại phạm vi đã kiểm tra |
> | 10 | Kiểm tra việc khắc phục các kiến nghị; công tác quản lý chất lượng, thống kê, tự đánh giá và hoàn thiện hồ sơ kiểm tra nội bộ | Các bộ phận, cá nhân có kiến nghị; bộ phận tổng hợp | Trước 10/05/2027 | Hậu kiểm, đối chiếu minh chứng | Hiệu trưởng chỉ đạo, phân công | Phục vụ tổng kết năm học |
>
> **Lưu ý thực hiện danh mục:** Nội dung, thời kỳ, thời hạn, đối tượng và thành phần kiểm tra cụ thể của mỗi cuộc phải được xác định trong quyết định kiểm tra và kế hoạch tiến hành kiểm tra do Hiệu trưởng phê duyệt. Danh mục này là căn cứ triển khai, không thay thế hồ sơ của từng cuộc kiểm tra.
>
> Trường hợp phát sinh nội dung cần kiểm tra hoặc cần điều chỉnh thời gian, đối tượng kiểm tra, Hiệu trưởng xem xét, quyết định theo thẩm quyền; bảo đảm không chồng chéo, không ảnh hưởng đến hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ và đáp ứng yêu cầu chỉ đạo của cơ quan quản lý cấp trên.
>
> Trên đây là Kế hoạch kiểm tra nội bộ năm học 2026 - 2027 của Trường Mầm non An Bình. Yêu cầu Ban Giám hiệu, Ban kiểm tra nội bộ, các tổ chuyên môn, Tổ Văn phòng, cán bộ quản lý, giáo viên, nhân viên và các bộ phận có liên quan nghiêm túc triển khai thực hiện. Trong quá trình thực hiện, nếu có khó khăn, vướng mắc, kịp thời báo cáo Hiệu trưởng để xem xét, giải quyết theo thẩm quyền hoặc báo cáo cơ quan quản lý cấp trên để được hướng dẫn./.

## IV. Lưu ý quan trọng trước khi ký ban hành

**1. Về hồ sơ bắt buộc:** Theo Công văn 1134 và Kế hoạch 3458, ngoài Quyết định ban hành Kế hoạch và Kế hoạch kèm theo, nhà trường còn phải ban hành riêng **Quyết định thành lập Ban kiểm tra nội bộ theo Mẫu số 02**, đồng thời hoàn thiện Quy chế hoạt động của Ban.

**2. Về tính thực tiễn:** Tôi chưa có báo cáo tổng kết, kết quả kiểm tra năm học 2025–2026 và danh sách nhân sự Ban kiểm tra. Do đó, bản kế hoạch chưa khẳng định trường đã tồn tại sai sót ở lĩnh vực cụ thể nào. Nhà trường cần đối chiếu kết quả rà soát thực tế để xác định các nội dung ưu tiên và điều chỉnh danh mục 10 cuộc nếu cần.

**3. Về tính chính xác của căn cứ:** Số hiệu, trích yếu của Công văn 4933 và 5375 được giữ theo dự thảo của trường; Công văn 3953 được viện dẫn theo các văn bản chỉ đạo đã cung cấp. Cần đối chiếu bản gốc các công văn này trước khi ký chính thức.

**4. Về thời hạn:** Nhà trường cần hoàn thành việc ban hành và gửi hồ sơ **trước ngày 31/10/2026**, không sử dụng ngày 01/10/2026 trên dự thảo cũ.

## ✅ Kết luận

Bản chỉnh lý đã hoàn thiện cấu trúc Quyết định theo Mẫu số 01, bổ sung kế hoạch triển khai, trách nhiệm, quy trình, hồ sơ và danh mục kiểm tra phù hợp với trường mầm non.

**Khuyến nghị của tôi:** Trước khi Hiệu trưởng ký, cần rà soát lần cuối danh mục kiểm tra trên cơ sở tình hình thực tế của Trường Mầm non An Bình. Đây là khâu quan trọng để kế hoạch không chỉ đầy đủ về thể thức, nội dung mà còn có tính khả thi, phục vụ trực tiếp cho công tác quản lý và nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ.

---

USER

bạn xuất file word giúp mình nhé

---

ASSISTANT

Tôi sẽ xuất bản Word gồm Quyết định và Kế hoạch kiểm tra nội bộ kèm theo, giữ bố cục hành chính và bảng danh mục các cuộc kiểm tra để nhà trường có thể chỉnh sửa, ký ban hành.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đã chuẩn bị đầy đủ nội dung **Quyết định ban hành Kế hoạch kiểm tra nội bộ và Kế hoạch kiểm tra nội bộ năm học 2026–2027 của Trường Mầm non An Bình**.

Tuy nhiên, phiên này chưa có công cụ tạo tệp Word để tôi đính kèm trực tiếp đường dẫn tải `.docx`.

Để xuất thành file Word, bạn hãy chọn **\@document** trong ô trò chuyện và gửi yêu cầu:

> Xuất toàn bộ Quyết định và Kế hoạch kiểm tra nội bộ năm học 2026–2027 vừa hoàn thiện thành một file Word (.docx). Trình bày đúng thể thức văn bản hành chính, phông Times New Roman, cỡ chữ 13–14, khổ A4; giữ đầy đủ nội dung và bảng danh mục 10 cuộc kiểm tra.

**Tên file đề xuất:** `Quyet_dinh_va_Ke_hoach_KTNB_MN_An_Binh_2026-2027.docx`

Bạn cũng có thể sao chép hai bản thảo ở câu trả lời trước vào Microsoft Word, sau đó lưu dưới định dạng `.docx`.

---

USER

nộ dung kiểm tra bạn hãy thực hiện bám sát vào nội dung của văn bản 1134 của SGD. Cụ thể nội dung thực hiện từng mục để bám sát thực tiễn

---

ASSISTANT

Tôi sẽ chỉnh riêng Mục II theo đúng thứ tự của Công văn 1134: 18 nội dung kiểm tra công tác quản lý của Hiệu trưởng, tiếp đến hoạt động giáo viên, nhân viên, các tổ/bộ phận và quản lý chất lượng. Với mỗi mục, tôi sẽ nêu rõ việc cần kiểm tra và minh chứng đối chiếu, đồng thời điều chỉnh các nội dung chung của cấp phổ thông cho phù hợp với mầm non.

---

ASSISTANT

# 📌 Hoàn thiện nội dung kiểm tra nội bộ Trường Mầm non An Bình năm học 2026–2027

Sau khi đối chiếu Mục II, từ trang 2 đến trang 5 của **Công văn số 1134/SGDĐT-TCCB ngày 17/10/2025 của Sở Giáo dục và Đào tạo Đồng Tháp**, tôi đề xuất chỉnh lý toàn bộ nội dung kiểm tra trong Kế hoạch của nhà trường.

**Nguyên tắc chỉnh lý:** Giữ nguyên hệ thống nội dung, thứ tự các mục 1.1 đến 1.18 và 2.1 đến 2.4 của Công văn 1134; cụ thể hóa thành những công việc có thể kiểm tra, đánh giá, đối chiếu bằng minh chứng tại trường mầm non. Những nội dung đặc thù của giáo dục phổ thông sẽ được vận dụng phù hợp, không đưa vào thành yêu cầu kiểm tra không đúng đối tượng.

Bản dưới đây có thể **thay trực tiếp cho Mục II. NỘI DUNG KIỂM TRA NỘI BỘ** trong Kế hoạch năm học 2026–2027 đã soạn trước đó.

> **writing · document**
>
> # II. NỘI DUNG KIỂM TRA NỘI BỘ
>
> Căn cứ nội dung hướng dẫn tại Công văn số 1134/SGDĐT-TCCB ngày 17 tháng 10 năm 2025 của Sở Giáo dục và Đào tạo Đồng Tháp; Công văn số 3953/SGDĐT-TCCB ngày 08 tháng 10 năm 2026 của Sở Giáo dục và Đào tạo; Kế hoạch số 3458/KH-UBND ngày 28 tháng 10 năm 2026 của Ủy ban nhân dân phường An Bình và nhiệm vụ năm học 2026 - 2027, Trường Mầm non An Bình xác định nội dung kiểm tra nội bộ như sau:
>
> ## 1. Kiểm tra việc thực hiện một số nhiệm vụ được giao của Thủ trưởng đơn vị
>
> ### 1.1. Chiến lược phát triển và Quy chế tổ chức
>
> Kiểm tra việc xây dựng, ban hành, rà soát, cập nhật và tổ chức thực hiện Chiến lược phát triển nhà trường; mức độ phù hợp của mục tiêu, chỉ tiêu, nhiệm vụ và giải pháp với tình hình đội ngũ, cơ sở vật chất, quy mô nhóm, lớp và yêu cầu phát triển giáo dục mầm non của địa phương.
>
> Kiểm tra việc xây dựng, ban hành và thực hiện Quy chế tổ chức và hoạt động của nhà trường; quy trình lấy ý kiến, thẩm quyền ban hành, phân công trách nhiệm và sự thống nhất giữa các quy chế với nhiệm vụ thực tế của từng bộ phận.
>
> Kiểm tra việc công khai, phổ biến các nội dung chiến lược, quy chế đến đội ngũ; việc cụ thể hóa mục tiêu phát triển trong kế hoạch năm học và kết quả rà soát, đánh giá, điều chỉnh trong quá trình thực hiện.
>
> **Hồ sơ, minh chứng đối chiếu:** Chiến lược phát triển nhà trường; Quy chế tổ chức và hoạt động; kế hoạch năm học; quyết định ban hành; biên bản họp lấy ý kiến; tài liệu công khai; báo cáo đánh giá kết quả thực hiện.
>
> ### 1.2. Kế hoạch giáo dục
>
> Kiểm tra việc xây dựng và ban hành kế hoạch giáo dục nhà trường; bảo đảm phù hợp Chương trình Giáo dục mầm non, nhiệm vụ năm học, điều kiện thực tế và đặc điểm phát triển của trẻ ở từng độ tuổi.
>
> Kiểm tra sự thống nhất giữa kế hoạch giáo dục nhà trường, kế hoạch của tổ chuyên môn và kế hoạch giáo dục các nhóm, lớp; việc phân bổ nội dung, thời gian thực hiện, tổ chức các hoạt động giáo dục, hoạt động trải nghiệm và chuẩn bị điều kiện thực hiện.
>
> Kiểm tra việc chỉ đạo giáo viên xây dựng, điều chỉnh kế hoạch giáo dục theo khả năng, nhu cầu và mức độ phát triển của trẻ; không thực hiện chương trình một cách máy móc, không gây áp lực hoặc yêu cầu trẻ đạt kết quả vượt quá đặc điểm lứa tuổi.
>
> Kiểm tra việc triển khai, theo dõi, đánh giá tiến độ thực hiện chương trình; kết quả tổ chức hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ và biện pháp điều chỉnh những nội dung chưa phù hợp.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch giáo dục nhà trường; kế hoạch của tổ chuyên môn, nhóm, lớp; hồ sơ chỉ đạo chuyên môn; biên bản sinh hoạt chuyên môn; kết quả quan sát hoạt động giáo dục và hồ sơ đánh giá sự phát triển của trẻ.
>
> ### 1.3. Công tác chính trị, pháp chế và truyền thông
>
> Kiểm tra việc xây dựng và triển khai kế hoạch giáo dục chính trị, tư tưởng; tuyên truyền, phổ biến các chủ trương, chính sách của Đảng, pháp luật của Nhà nước, quy định của ngành và nội quy, quy chế của nhà trường.
>
> Kiểm tra việc thực hiện quy định về đạo đức nhà giáo, quy tắc ứng xử, văn hóa giao tiếp trong trường học; thái độ, trách nhiệm của cán bộ quản lý, giáo viên, nhân viên khi giao tiếp với trẻ, phụ huynh và đồng nghiệp.
>
> Kiểm tra công tác tuyên truyền, phổ biến kiến thức chăm sóc, nuôi dưỡng, giáo dục trẻ; phòng, chống tai nạn thương tích, bạo lực, xâm hại trẻ em và xây dựng môi trường giáo dục an toàn, thân thiện.
>
> Kiểm tra việc thực hiện kế hoạch truyền thông của nhà trường; quản lý nội dung đăng tải trên website, trang thông tin và các kênh truyền thông; bảo đảm nội dung chính xác, phù hợp, bảo vệ thông tin cá nhân và hình ảnh của trẻ theo quy định.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch phổ biến, giáo dục pháp luật; kế hoạch truyền thông; biên bản họp, tài liệu tuyên truyền; nội dung đăng tải trên các kênh truyền thông; hồ sơ tiếp nhận, xử lý thông tin và phản ánh có liên quan.
>
> ### 1.4. Quản lý đội ngũ
>
> Kiểm tra việc quản lý số lượng, cơ cấu, trình độ đào tạo, vị trí việc làm của cán bộ quản lý, giáo viên, nhân viên; việc phân công nhiệm vụ phù hợp với năng lực, chuyên môn, điều kiện thực tế và yêu cầu chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Kiểm tra công tác quản lý hồ sơ viên chức, người lao động; việc thực hiện tuyển dụng, tiếp nhận, bố trí, sử dụng nhân sự theo thẩm quyền; việc chấp hành kỷ luật lao động, nội quy, quy chế của nhà trường.
>
> Kiểm tra việc xây dựng và tổ chức thực hiện kế hoạch bồi dưỡng chuyên môn, nghiệp vụ, bồi dưỡng thường xuyên; việc hỗ trợ giáo viên còn hạn chế về năng lực và phát huy vai trò của giáo viên cốt cán.
>
> Kiểm tra công tác đánh giá, xếp loại cán bộ quản lý, giáo viên, nhân viên; việc đánh giá theo chuẩn nghề nghiệp và các quy định có liên quan; bảo đảm khách quan, có minh chứng, gắn với kết quả thực hiện nhiệm vụ.
>
> Kiểm tra việc thực hiện công tác thi đua, khen thưởng, kỷ luật và giải quyết những vấn đề phát sinh trong quản lý đội ngũ.
>
> Đối với nội dung quản lý dạy thêm, học thêm nêu trong hướng dẫn chung của Sở, nhà trường chỉ kiểm tra những hoạt động thực tế có phát sinh và thuộc phạm vi điều chỉnh của quy định tương ứng; không áp dụng máy móc các yêu cầu dành riêng cho giáo dục phổ thông.
>
> **Hồ sơ, minh chứng đối chiếu:** Hồ sơ nhân sự; quyết định và bảng phân công nhiệm vụ; kế hoạch bồi dưỡng; hồ sơ đánh giá viên chức, đánh giá chuẩn nghề nghiệp; biên bản sinh hoạt chuyên môn; hồ sơ thi đua, khen thưởng, kỷ luật.
>
> ### 1.5. Công tác quản lý và tổ chức giáo dục trẻ
>
> Kiểm tra công tác tuyển sinh, huy động trẻ ra lớp, quản lý sĩ số, theo dõi chuyên cần, duy trì nền nếp sinh hoạt và tổ chức thực hiện các nhiệm vụ chăm sóc, nuôi dưỡng, giáo dục trẻ ở từng nhóm, lớp.
>
> Kiểm tra việc chỉ đạo thực hiện chế độ sinh hoạt hằng ngày; tổ chức hoạt động học, chơi, ăn, ngủ, vệ sinh, hoạt động ngoài trời phù hợp với từng độ tuổi, bảo đảm an toàn và đáp ứng nhu cầu phát triển của trẻ.
>
> Kiểm tra việc tổ chức giáo dục kỹ năng tự phục vụ, kỹ năng giao tiếp, ứng xử, kỹ năng bảo vệ bản thân; việc hình thành nền nếp, thói quen tốt và tổ chức các hoạt động trải nghiệm phù hợp với trẻ mầm non.
>
> Kiểm tra công tác theo dõi, hỗ trợ trẻ có khó khăn trong phát triển, trẻ cần được quan tâm đặc biệt; việc tổ chức giáo dục hòa nhập đối với trẻ khuyết tật khi có đối tượng; bảo đảm quyền được chăm sóc, giáo dục của trẻ.
>
> Kiểm tra công tác phối hợp với gia đình trong theo dõi sức khỏe, chuyên cần, tâm lý, hành vi và sự phát triển của trẻ; việc phát hiện, hỗ trợ kịp thời những trường hợp trẻ có biểu hiện bất thường.
>
> **Hồ sơ, minh chứng đối chiếu:** Hồ sơ tuyển sinh; danh sách trẻ; sổ theo dõi chuyên cần; kế hoạch và hồ sơ giáo dục nhóm, lớp; hồ sơ theo dõi sự phát triển của trẻ; hồ sơ phối hợp với phụ huynh; kết quả quan sát thực tế.
>
> ### 1.6. Công tác phối hợp với chính quyền, đoàn thể, Ban đại diện cha mẹ trẻ và các tổ chức liên quan
>
> Kiểm tra việc xây dựng và thực hiện kế hoạch phối hợp giữa nhà trường với chính quyền địa phương, các tổ chức đoàn thể và các đơn vị liên quan trong công tác huy động trẻ ra lớp, bảo đảm an toàn, chăm sóc sức khỏe, phòng, chống dịch bệnh và tổ chức các hoạt động giáo dục.
>
> Kiểm tra việc tổ chức họp cha mẹ trẻ, trao đổi thông tin hai chiều, tuyên truyền kiến thức chăm sóc, nuôi dưỡng, giáo dục trẻ; việc tiếp thu ý kiến góp ý và xử lý những vấn đề phụ huynh quan tâm.
>
> Kiểm tra việc phối hợp với Ban đại diện cha mẹ trẻ theo đúng chức năng, nhiệm vụ; tính tự nguyện, công khai, minh bạch của các hoạt động phối hợp và các nguồn hỗ trợ hợp pháp nếu có.
>
> Đánh giá hiệu quả phối hợp thông qua kết quả thực hiện các nhiệm vụ cụ thể, mức độ tham gia của các bên và những vấn đề đã được giải quyết.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch phối hợp; biên bản họp cha mẹ trẻ; hồ sơ hoạt động của Ban đại diện; thông báo, báo cáo, biên bản làm việc và minh chứng kết quả phối hợp.
>
> ### 1.7. Hành chính, tài chính, tài sản
>
> Kiểm tra việc chỉ đạo thực hiện công tác hành chính, cải cách hành chính; ban hành, quản lý, sử dụng và lưu trữ văn bản; thực hiện quy trình giải quyết công việc theo phân công.
>
> Kiểm tra việc xây dựng và thực hiện dự toán thu, chi ngân sách; quản lý, sử dụng nguồn kinh phí được giao; các khoản thu dịch vụ phục vụ, hỗ trợ hoạt động giáo dục và các khoản thu hợp pháp khác theo quy định.
>
> Kiểm tra việc tổ chức thu, chi, quản lý chứng từ kế toán, thanh toán, quyết toán; sự phù hợp giữa khoản thu, khoản chi với nội dung được phê duyệt và kết quả thực hiện thực tế.
>
> Kiểm tra công tác quản lý, sử dụng các nguồn tài trợ, hỗ trợ hợp pháp và kinh phí hoạt động của Ban đại diện cha mẹ trẻ theo đúng thẩm quyền, trách nhiệm của từng chủ thể.
>
> Kiểm tra công tác quản lý, sử dụng tài sản công; mua sắm, kiểm kê, sửa chữa, thanh lý tài sản theo quy định; việc công khai các nội dung tài chính, tài sản thuộc diện phải công khai.
>
> **Hồ sơ, minh chứng đối chiếu:** Dự toán, quyết toán; quy chế chi tiêu nội bộ; hồ sơ các khoản thu; chứng từ, sổ kế toán; hợp đồng, hóa đơn; hồ sơ mua sắm, kiểm kê tài sản; biên bản và tài liệu công khai.
>
> ### 1.8. Cơ sở vật chất, thiết bị
>
> Kiểm tra việc xây dựng kế hoạch đầu tư, sửa chữa, bổ sung cơ sở vật chất, trang thiết bị, đồ dùng, đồ chơi phục vụ hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Kiểm tra thực trạng phòng học, phòng chức năng, bếp ăn, nhà vệ sinh, sân chơi, đồ chơi ngoài trời, hệ thống điện, nước, thiết bị phòng cháy, chữa cháy và các điều kiện bảo đảm an toàn.
>
> Kiểm tra việc bố trí, sử dụng, bảo quản thiết bị, đồ dùng, đồ chơi; việc phát hiện và khắc phục những hạng mục hư hỏng, xuống cấp, không bảo đảm an toàn.
>
> Kiểm tra công tác kiểm kê, bảo dưỡng, sửa chữa, mua sắm, điều chuyển và thanh lý tài sản theo quy định; đối chiếu số liệu quản lý tài sản với hiện trạng sử dụng.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch cơ sở vật chất; sổ theo dõi tài sản; biên bản kiểm kê; hồ sơ mua sắm, sửa chữa; biên bản kiểm tra an toàn và kết quả kiểm tra hiện trạng thực tế.
>
> ### 1.9. Việc thực hiện chế độ, chính sách đối với tập thể, cá nhân
>
> Kiểm tra việc triển khai, thực hiện các chế độ, chính sách đối với cán bộ quản lý, giáo viên, nhân viên và người lao động thuộc phạm vi trách nhiệm của nhà trường.
>
> Kiểm tra việc thực hiện chế độ tiền lương, phụ cấp, bảo hiểm, nâng lương, bồi dưỡng, khen thưởng và các quyền lợi khác theo quy định, phù hợp với từng đối tượng.
>
> Kiểm tra việc thực hiện các chế độ, chính sách đối với trẻ mầm non thuộc diện được hỗ trợ, miễn, giảm hoặc hưởng chính sách theo quy định, nếu có.
>
> Kiểm tra trình tự lập danh sách, xét duyệt, xác nhận, chi trả, công khai và lưu trữ hồ sơ; đối chiếu giữa đối tượng thụ hưởng, chế độ được phê duyệt và kết quả thực hiện.
>
> **Hồ sơ, minh chứng đối chiếu:** Danh sách đối tượng; quyết định phê duyệt; hồ sơ đề nghị hưởng chế độ; bảng thanh toán, chứng từ chi trả và hồ sơ xác nhận có liên quan.
>
> ### 1.10. Thực hiện Quy chế dân chủ ở cơ sở
>
> Kiểm tra việc xây dựng, ban hành, phổ biến và thực hiện Quy chế dân chủ ở cơ sở; bảo đảm quyền được biết, tham gia ý kiến, giám sát của viên chức, người lao động theo quy định.
>
> Kiểm tra việc tổ chức hội nghị viên chức, người lao động; quy trình lấy ý kiến đối với các nội dung liên quan đến hoạt động nhà trường, phân công nhiệm vụ, quy chế nội bộ và quyền lợi của đội ngũ.
>
> Kiểm tra việc công khai, tiếp nhận, giải quyết ý kiến, kiến nghị; thực hiện các nội dung đã thống nhất tại hội nghị và các cuộc họp của nhà trường.
>
> **Hồ sơ, minh chứng đối chiếu:** Quy chế dân chủ; hồ sơ hội nghị viên chức, người lao động; biên bản họp; kết quả lấy ý kiến, tài liệu công khai và hồ sơ giải quyết kiến nghị.
>
> ### 1.11. Công tác xã hội hóa giáo dục
>
> Kiểm tra việc xây dựng chủ trương, kế hoạch và tổ chức thực hiện các hoạt động huy động nguồn lực hỗ trợ giáo dục phù hợp với điều kiện của nhà trường.
>
> Kiểm tra việc thực hiện nguyên tắc tự nguyện, công khai, minh bạch, đúng mục đích, đúng đối tượng và đúng thẩm quyền đối với các nguồn tài trợ, hỗ trợ hợp pháp.
>
> Kiểm tra việc tiếp nhận, quản lý, sử dụng, quyết toán hoặc công khai kết quả sử dụng nguồn lực theo quy định; hiệu quả thực tế đối với việc cải thiện điều kiện chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch, văn bản phê duyệt hoặc thống nhất theo thẩm quyền; hồ sơ tiếp nhận tài trợ, hỗ trợ; biên bản bàn giao, chứng từ, hồ sơ quản lý tài sản và tài liệu công khai.
>
> ### 1.12. Việc chỉ đạo thực hiện các phong trào thi đua, cuộc vận động trong ngành
>
> Kiểm tra việc xây dựng, triển khai kế hoạch thi đua, các cuộc vận động và phong trào phù hợp với nhiệm vụ năm học và điều kiện thực tế của nhà trường.
>
> Kiểm tra việc đăng ký, theo dõi, đánh giá kết quả thi đua của tập thể, cá nhân; sự công khai, khách quan, minh bạch trong bình xét, đề nghị khen thưởng.
>
> Kiểm tra hiệu quả thực hiện các phong trào gắn với nâng cao đạo đức nhà giáo, đổi mới phương pháp giáo dục, xây dựng môi trường giáo dục lấy trẻ làm trung tâm, bảo đảm an toàn và nâng cao chất lượng chăm sóc trẻ.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch thi đua; hồ sơ đăng ký; tiêu chí, biên bản xét thi đua; báo cáo kết quả; sản phẩm, minh chứng thực tế của các hoạt động.
>
> ### 1.13. Công tác phòng, chống tham nhũng, thực hành tiết kiệm, chống lãng phí
>
> Kiểm tra việc tuyên truyền, phổ biến, tổ chức thực hiện các quy định về phòng, chống tham nhũng, thực hành tiết kiệm, chống lãng phí.
>
> Kiểm tra việc thực hiện công khai, minh bạch trong quản lý tài chính, tài sản, mua sắm, sử dụng nguồn kinh phí, phân công nhiệm vụ và giải quyết chế độ, chính sách.
>
> Kiểm tra các biện pháp phòng ngừa sai phạm trong quản lý thu, chi; quản lý tài sản, trang thiết bị, nguyên vật liệu, thực phẩm phục vụ bán trú.
>
> Kiểm tra việc thực hành tiết kiệm điện, nước, văn phòng phẩm, thực phẩm và các nguồn lực khác; phát hiện những biểu hiện sử dụng không đúng mục đích, gây thất thoát hoặc lãng phí để kịp thời chấn chỉnh.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch và tài liệu tuyên truyền; quy chế chi tiêu nội bộ; hồ sơ mua sắm, tài chính, tài sản; tài liệu công khai; biên bản kiểm tra và kết quả thực hiện biện pháp khắc phục.
>
> ### 1.14. Thực hiện công khai theo quy định
>
> Kiểm tra việc tổ chức thực hiện công khai các nội dung thuộc trách nhiệm của cơ sở giáo dục mầm non theo quy định hiện hành.
>
> Tập trung kiểm tra việc công khai thông tin về tổ chức và hoạt động nhà trường; điều kiện bảo đảm chất lượng; đội ngũ; cơ sở vật chất; chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ; các khoản thu và nội dung tài chính thuộc diện phải công khai.
>
> Kiểm tra thời điểm, hình thức, nội dung công khai; tính chính xác, đầy đủ, kịp thời và khả năng tiếp cận thông tin của viên chức, người lao động, cha mẹ trẻ và các đối tượng có liên quan.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch hoặc phân công thực hiện công khai; thông báo; dữ liệu công khai trên website, bảng tin; hồ sơ tài chính và biên bản kiểm tra việc công khai.
>
> ### 1.15. Việc tiếp công dân; giải quyết kiến nghị, phản ánh, khiếu nại, tố cáo
>
> Kiểm tra việc thực hiện trách nhiệm tiếp công dân; công khai thông tin tiếp nhận phản ánh, kiến nghị; bố trí người phụ trách và thực hiện các quy trình thuộc thẩm quyền nhà trường.
>
> Kiểm tra việc tiếp nhận, phân loại, xử lý, giải quyết hoặc chuyển cơ quan có thẩm quyền đối với các đơn thư, phản ánh, kiến nghị, khiếu nại, tố cáo nếu có.
>
> Kiểm tra thời hạn, trình tự xử lý, kết quả giải quyết, việc thông tin cho người có liên quan; bảo đảm giữ bí mật thông tin theo quy định và không để phát sinh mâu thuẫn do thiếu trách nhiệm trong xử lý.
>
> **Hồ sơ, minh chứng đối chiếu:** Lịch, sổ tiếp công dân; sổ theo dõi đơn thư; đơn, văn bản tiếp nhận; hồ sơ xác minh, giải quyết; văn bản trả lời và tài liệu lưu trữ có liên quan.
>
> ### 1.16. Chuyển đổi số, công nghệ thông tin và dữ liệu
>
> Kiểm tra việc xây dựng, ban hành, triển khai kế hoạch chuyển đổi số của nhà trường; phân công trách nhiệm quản lý, cập nhật, kiểm tra và sử dụng các hệ thống phần mềm, cơ sở dữ liệu.
>
> Kiểm tra việc sử dụng hệ thống quản lý văn bản điện tử, chữ ký số, thư điện tử công vụ, website, phần mềm quản lý trường học và các ứng dụng phục vụ công tác quản lý, chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Kiểm tra việc cập nhật thông tin trường, lớp, cán bộ quản lý, giáo viên, nhân viên, trẻ và các dữ liệu chuyên ngành theo nguyên tắc **“Đúng - Đủ - Sạch - Sống”**; đối chiếu dữ liệu điện tử với hồ sơ thực tế để phát hiện thông tin thiếu, trùng lặp, không thống nhất hoặc chưa kịp thời.
>
> Kiểm tra việc phân quyền sử dụng, quản lý tài khoản, bảo vệ dữ liệu cá nhân, sao lưu và bảo đảm an toàn thông tin.
>
> Kiểm tra việc khai thác dữ liệu phục vụ thống kê, báo cáo; thời hạn báo cáo, độ chính xác của thông tin và trách nhiệm của từng cá nhân được giao quản lý dữ liệu.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch chuyển đổi số; quyết định hoặc bảng phân công nhiệm vụ; tài khoản, dữ liệu trên hệ thống phần mềm; báo cáo thống kê; hồ sơ gốc và kết quả đối chiếu dữ liệu.
>
> ### 1.17. An toàn trường học và môi trường giáo dục
>
> Kiểm tra việc xây dựng và tổ chức thực hiện kế hoạch bảo đảm an toàn trường học; phòng, chống tai nạn thương tích, bạo lực, xâm hại trẻ em và các nguy cơ ảnh hưởng đến sức khỏe, tính mạng của trẻ.
>
> Kiểm tra việc thực hiện quy trình đón, trả trẻ; quản lý trẻ trong các hoạt động học, chơi, ăn, ngủ, vệ sinh và hoạt động ngoài trời; phân công trách nhiệm giám sát, chăm sóc, bảo vệ trẻ.
>
> Kiểm tra công tác phòng cháy, chữa cháy; việc bảo đảm an toàn hệ thống điện, nước, thiết bị, đồ dùng, đồ chơi, sân chơi, cổng trường, khu vực bếp ăn, nhà vệ sinh và các khu vực có nguy cơ mất an toàn.
>
> Kiểm tra công tác y tế trường học, theo dõi sức khỏe, phòng, chống dịch bệnh; điều kiện vệ sinh môi trường, nước sạch và xử lý các nguy cơ gây bệnh.
>
> Kiểm tra công tác an toàn thực phẩm: nguồn gốc thực phẩm, hợp đồng cung cấp, tiếp nhận, kiểm tra chất lượng thực phẩm, quy trình sơ chế, chế biến, chia ăn, kiểm thực, lưu mẫu thức ăn và vệ sinh dụng cụ, khu vực bếp ăn theo quy định.
>
> Kiểm tra việc xây dựng và tổ chức thực hiện các phương án xử lý tình huống khẩn cấp; công tác tuyên truyền, tập huấn, diễn tập và khả năng ứng phó của đội ngũ trước những tình huống có nguy cơ xảy ra.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch an toàn trường học; hồ sơ phòng cháy, chữa cháy; kế hoạch phòng, chống tai nạn thương tích; hồ sơ y tế; hồ sơ an toàn thực phẩm, kiểm thực, lưu mẫu; biên bản kiểm tra và kết quả quan sát thực tế.
>
> ### 1.18. Tham gia sinh hoạt chuyên môn; tự học, tự bồi dưỡng và thực hiện nhiệm vụ giảng dạy của cán bộ quản lý
>
> Kiểm tra việc tham gia sinh hoạt tổ chuyên môn của Hiệu trưởng, Phó Hiệu trưởng; vai trò chỉ đạo, tư vấn, hỗ trợ giáo viên giải quyết những khó khăn trong thực hiện Chương trình Giáo dục mầm non.
>
> Kiểm tra việc xây dựng và thực hiện kế hoạch tự học, tự bồi dưỡng; tham gia tập huấn, bồi dưỡng nâng cao năng lực quản lý, chuyên môn, nghiệp vụ và ứng dụng công nghệ thông tin trong quản trị trường học.
>
> Kiểm tra việc thực hiện nhiệm vụ tham gia hoạt động giáo dục, giảng dạy của Hiệu trưởng, Phó Hiệu trưởng theo định mức và quy định áp dụng đối với cán bộ quản lý cơ sở giáo dục mầm non.
>
> Đánh giá hiệu quả của hoạt động tự bồi dưỡng và việc vận dụng kiến thức, kỹ năng đã được bồi dưỡng trong công tác chỉ đạo, quản lý, nâng cao chất lượng giáo dục.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch công tác cá nhân; lịch tham gia hoạt động giáo dục; kế hoạch bồi dưỡng; hồ sơ dự sinh hoạt chuyên môn; biên bản họp; tài liệu, sản phẩm và kết quả thực hiện nhiệm vụ.
>
> ## 2. Kiểm tra việc thực hiện nhiệm vụ được giao của giáo viên và nhân viên
>
> ### 2.1. Kiểm tra hoạt động sư phạm của giáo viên
>
> **a) Phẩm chất, đạo đức, lối sống và văn hóa công vụ**
>
> Kiểm tra việc chấp hành chủ trương, chính sách của Đảng, pháp luật của Nhà nước, quy định của ngành, nội quy và quy chế của nhà trường.
>
> Kiểm tra việc thực hiện đạo đức nhà giáo, quy tắc ứng xử, tinh thần trách nhiệm, ý thức tổ chức kỷ luật; thái độ giao tiếp, chăm sóc, đối xử công bằng và tôn trọng trẻ.
>
> Kiểm tra tinh thần phối hợp với đồng nghiệp, cha mẹ trẻ; ý thức giữ gìn uy tín nhà giáo và bảo vệ quyền, lợi ích hợp pháp, an toàn thể chất, tinh thần của trẻ.
>
> **b) Việc thực hiện quy chế chuyên môn và nhiệm vụ được giao**
>
> Kiểm tra việc xây dựng, thực hiện kế hoạch giáo dục nhóm, lớp phù hợp với kế hoạch giáo dục nhà trường, Chương trình Giáo dục mầm non và đặc điểm của trẻ.
>
> Kiểm tra việc chuẩn bị môi trường giáo dục, đồ dùng, đồ chơi, học liệu và các điều kiện tổ chức hoạt động; tính chủ động, sáng tạo trong lựa chọn phương pháp, hình thức giáo dục.
>
> Kiểm tra việc thực hiện chế độ sinh hoạt hằng ngày; tổ chức các hoạt động đón trẻ, chơi, học, hoạt động ngoài trời, ăn, ngủ, vệ sinh và trả trẻ.
>
> Kiểm tra việc theo dõi chuyên cần, sức khỏe, sự phát triển của trẻ; thực hiện đánh giá trẻ, phối hợp với cha mẹ trẻ và điều chỉnh nội dung chăm sóc, giáo dục theo kết quả đánh giá.
>
> Kiểm tra việc tham gia sinh hoạt chuyên môn, thực hiện chuyên đề, tự học, tự bồi dưỡng và các nhiệm vụ khác theo phân công.
>
> **c) Trình độ chuyên môn, nghiệp vụ và năng lực sư phạm**
>
> Kiểm tra thông qua dự giờ, quan sát hoạt động giáo dục, tổ chức sinh hoạt trong ngày và nghiên cứu hồ sơ chuyên môn của giáo viên.
>
> Tập trung đánh giá khả năng xác định mục tiêu giáo dục; lựa chọn nội dung, phương pháp, hình thức tổ chức hoạt động; tạo cơ hội để trẻ được trải nghiệm, thực hành, giao tiếp và phát huy tính tích cực.
>
> Kiểm tra khả năng quản lý nhóm, lớp; xử lý tình huống sư phạm; quan sát, hỗ trợ trẻ; tổ chức môi trường giáo dục lấy trẻ làm trung tâm và bảo đảm an toàn trong quá trình tổ chức hoạt động.
>
> **d) Kết quả chăm sóc, nuôi dưỡng và giáo dục trẻ**
>
> Kiểm tra việc thực hiện kế hoạch giáo dục; mức độ tiến bộ của trẻ về thể chất, nhận thức, ngôn ngữ, tình cảm, kỹ năng xã hội và thẩm mỹ phù hợp với từng độ tuổi.
>
> Kiểm tra việc hình thành nền nếp, thói quen vệ sinh, kỹ năng tự phục vụ, kỹ năng giao tiếp và khả năng tham gia hoạt động của trẻ.
>
> Đánh giá kết quả trên cơ sở quá trình phát triển của trẻ, điều kiện thực tế của nhóm, lớp và minh chứng quan sát; không sử dụng kết quả kiểm tra, thi cử hoặc xếp hạng trẻ theo cách áp dụng đối với học sinh phổ thông.
>
> **đ) Thực hiện các nhiệm vụ khác**
>
> Kiểm tra việc quản lý hồ sơ nhóm, lớp; công tác phối hợp với phụ huynh; thực hiện nhiệm vụ tuyên truyền, chuyên đề, phong trào thi đua và hoạt động chung của nhà trường.
>
> Kiểm tra việc ứng dụng công nghệ thông tin, sử dụng phần mềm, quản lý thông tin nhóm, lớp, bảo vệ dữ liệu cá nhân và hình ảnh của trẻ.
>
> Kiểm tra tinh thần đổi mới, khả năng tự học, tự bồi dưỡng, tiếp thu ý kiến góp ý và khắc phục những hạn chế sau kiểm tra.
>
> **e) Khả năng phát triển chuyên môn, nghiệp vụ**
>
> Đánh giá khả năng vận dụng kiến thức, kỹ năng mới vào thực tiễn chăm sóc, giáo dục trẻ; năng lực xây dựng kế hoạch, giải quyết tình huống sư phạm và phối hợp trong hoạt động chuyên môn.
>
> Xác định những mặt mạnh cần phát huy và những nội dung giáo viên cần tiếp tục bồi dưỡng, hỗ trợ nhằm nâng cao năng lực nghề nghiệp.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch giáo dục nhóm, lớp; hồ sơ chuyên môn của giáo viên; phiếu dự giờ; hồ sơ theo dõi, đánh giá trẻ; sản phẩm hoạt động; biên bản sinh hoạt chuyên môn; kết quả quan sát thực tế và ý kiến trao đổi với giáo viên.
>
> ### 2.2. Kiểm tra hoạt động phục vụ dạy và học của nhân viên
>
> **a) Kiểm tra việc xây dựng và thực hiện kế hoạch công tác**
>
> Kiểm tra kế hoạch thực hiện nhiệm vụ năm học của từng nhân viên, bộ phận; sự phù hợp với nhiệm vụ được phân công và kế hoạch chung của nhà trường.
>
> Kiểm tra việc thực hiện tiến độ công việc, chế độ thông tin, báo cáo; chủ động phối hợp với các bộ phận trong thực hiện nhiệm vụ.
>
> **b) Kiểm tra việc chấp hành thời gian lao động, nội quy, quy chế**
>
> Kiểm tra việc thực hiện giờ làm việc, phân công trực, kỷ luật lao động, quy định về an toàn lao động, vệ sinh môi trường, bảo đảm an toàn trong quá trình thực hiện nhiệm vụ.
>
> **c) Kiểm tra việc thực hiện chức trách, nhiệm vụ theo vị trí việc làm**
>
> - **Nhân viên văn thư:** Tiếp nhận, xử lý, ban hành, quản lý văn bản; quản lý con dấu; lập và lưu trữ hồ sơ; bảo đảm đúng quy trình, thời hạn.
> - **Nhân viên kế toán, thủ quỹ:** Thực hiện các nghiệp vụ tài chính, kế toán, quản lý tiền và chứng từ; báo cáo, quyết toán, công khai, quản lý hồ sơ theo nhiệm vụ được phân công.
> - **Nhân viên y tế:** Theo dõi sức khỏe trẻ; thực hiện công tác y tế trường học, phòng, chống dịch bệnh, sơ cấp cứu ban đầu; quản lý hồ sơ y tế và phối hợp bảo đảm an toàn cho trẻ.
> - **Nhân viên cấp dưỡng:** Thực hiện quy trình tiếp nhận, sơ chế, chế biến, chia ăn, bảo quản thực phẩm; vệ sinh cá nhân, dụng cụ, khu vực bếp; bảo đảm an toàn thực phẩm.
> - **Nhân viên bảo vệ:** Thực hiện nhiệm vụ trực, bảo đảm an ninh, trật tự, kiểm soát cổng trường, phối hợp quản lý việc đón, trả trẻ và phòng ngừa nguy cơ mất an toàn.
> - **Nhân viên hoặc người được phân công phụ trách thiết bị, tài sản:** Quản lý, theo dõi, bảo quản, cấp phát, kiểm kê và đề xuất sửa chữa, bổ sung tài sản, thiết bị.
>
> **d) Kiểm tra công tác phối hợp và thực hiện nhiệm vụ khác**
>
> Kiểm tra tinh thần trách nhiệm, thái độ phục vụ, khả năng phối hợp giữa các nhân viên với giáo viên, tổ chuyên môn và Ban Giám hiệu.
>
> Kiểm tra việc thực hiện các nhiệm vụ khác do Hiệu trưởng phân công, kết quả khắc phục các hạn chế đã được góp ý hoặc kiểm tra trước đó.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch, bảng phân công nhiệm vụ; sổ theo dõi công việc; hồ sơ, chứng từ chuyên môn của từng vị trí; bảng chấm công; kết quả quan sát thực tế và báo cáo của nhân viên.
>
> ### 2.3. Kiểm tra hoạt động của các tổ chuyên môn, Tổ Văn phòng và các bộ phận
>
> **2.3.1. Kiểm tra hoạt động của các tổ chuyên môn**
>
> Kiểm tra việc xây dựng kế hoạch hoạt động của tổ; sự phù hợp với kế hoạch năm học, kế hoạch giáo dục và nhiệm vụ chuyên môn được giao.
>
> Kiểm tra vai trò, trách nhiệm của tổ trưởng trong phân công nhiệm vụ, điều hành sinh hoạt chuyên môn, theo dõi tiến độ thực hiện chương trình và quản lý chất lượng chăm sóc, giáo dục trẻ.
>
> Kiểm tra việc quản lý hồ sơ, sổ sách; nền nếp, nội dung, chất lượng sinh hoạt chuyên môn; việc tổ chức trao đổi, dự giờ, rút kinh nghiệm và giải quyết khó khăn trong thực tiễn tổ chức hoạt động giáo dục.
>
> Kiểm tra việc thực hiện kế hoạch bồi dưỡng, tự bồi dưỡng giáo viên; triển khai chuyên đề; hỗ trợ giáo viên nâng cao năng lực, đổi mới phương pháp và xây dựng môi trường giáo dục lấy trẻ làm trung tâm.
>
> Kiểm tra việc ứng dụng công nghệ thông tin, chuẩn hóa thông tin chuyên môn, phối hợp cập nhật dữ liệu ngành, quản lý hồ sơ điện tử và bảo đảm an toàn thông tin.
>
> Đánh giá chất lượng hoạt động của tổ thông qua kết quả thực hiện kế hoạch, sự tiến bộ của giáo viên và chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ tại các nhóm, lớp.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch tổ; hồ sơ sinh hoạt chuyên môn; biên bản họp; hồ sơ dự giờ, bồi dưỡng; kết quả thực hiện chuyên đề; hồ sơ giáo dục nhóm, lớp và kết quả quan sát thực tế.
>
> **2.3.2. Kiểm tra công tác mua sắm, bảo quản và sử dụng thiết bị, đồ dùng, đồ chơi**
>
> Kiểm tra việc lập kế hoạch mua sắm, bổ sung thiết bị, đồ dùng, đồ chơi; sự phù hợp với nhu cầu thực tế, yêu cầu của Chương trình Giáo dục mầm non và điều kiện ngân sách.
>
> Kiểm tra việc tiếp nhận, cấp phát, quản lý, sử dụng, bảo quản tài sản, trang thiết bị; việc kiểm kê, sửa chữa, xử lý những thiết bị hư hỏng, không bảo đảm an toàn.
>
> Kiểm tra hiệu quả sử dụng thiết bị, đồ dùng, đồ chơi trong hoạt động chăm sóc, giáo dục; không để thiết bị có nhưng không được khai thác hoặc sử dụng sai mục đích.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch mua sắm; hồ sơ mua sắm, bàn giao; sổ tài sản, thiết bị; biên bản kiểm kê; hồ sơ sửa chữa và hiện trạng sử dụng.
>
> **2.3.3. Kiểm tra công tác thư viện, sách, tài liệu và học liệu**
>
> Kiểm tra việc quản lý, bổ sung, bảo quản, sắp xếp và sử dụng sách, truyện, tài liệu, tranh ảnh, học liệu phục vụ giáo viên và trẻ.
>
> Kiểm tra việc tổ chức các góc sách, góc thư viện hoặc không gian đọc nếu có; sự phù hợp của sách, truyện, học liệu với độ tuổi, bảo đảm an toàn và khả năng tiếp cận của trẻ.
>
> Kiểm tra việc theo dõi mượn, trả, sử dụng sách, tài liệu; bảo quản, thống kê, đề xuất bổ sung học liệu theo điều kiện thực tế của trường.
>
> **Hồ sơ, minh chứng đối chiếu:** Danh mục sách, tài liệu; sổ quản lý, theo dõi mượn trả nếu có; hồ sơ bổ sung học liệu và kết quả kiểm tra thực tế.
>
> **2.3.4. Kiểm tra công tác kế toán, tài chính và tài sản**
>
> Kiểm tra việc lập, quản lý, thực hiện dự toán; tổ chức thu, chi; hạch toán, ghi chép sổ sách, lưu giữ chứng từ, thanh toán, quyết toán và thực hiện chế độ báo cáo tài chính, kế toán.
>
> Kiểm tra tính hợp pháp, hợp lệ của chứng từ; sự chính xác, thống nhất giữa số liệu, hồ sơ và kết quả thu, chi thực tế.
>
> Kiểm tra việc quản lý và sử dụng các khoản kinh phí, quỹ được phép hình thành; công khai tài chính, thực hiện các quy định về quản lý nguồn thu, chi trong nhà trường.
>
> Kiểm tra công tác quản lý tài sản công, kiểm kê, mua sắm, sửa chữa, bảo quản, sử dụng tài sản và thiết bị; đối chiếu số liệu trên sổ sách với thực tế.
>
> **Hồ sơ, minh chứng đối chiếu:** Dự toán, quyết toán; chứng từ và sổ kế toán; hồ sơ thu, chi; báo cáo tài chính; hồ sơ mua sắm, quản lý, kiểm kê tài sản; tài liệu công khai.
>
> **2.3.5. Kiểm tra hoạt động của bộ phận văn thư, hành chính**
>
> Kiểm tra quy trình tiếp nhận, đăng ký, xử lý và phát hành văn bản đi, đến; việc quản lý, sử dụng con dấu, chữ ký số theo quy định.
>
> Kiểm tra việc lập hồ sơ công việc; thu thập, sắp xếp, bảo quản và lưu trữ hồ sơ, tài liệu của nhà trường.
>
> Kiểm tra việc quản lý, cấp phát văn phòng phẩm, thiết bị hành chính được giao; tinh thần trách nhiệm, thái độ phục vụ và khả năng phối hợp với các bộ phận.
>
> **Hồ sơ, minh chứng đối chiếu:** Hệ thống quản lý văn bản; sổ theo dõi văn bản; hồ sơ lưu trữ; hồ sơ quản lý con dấu, chữ ký số; biên bản giao nhận, báo cáo công việc.
>
> **2.3.6. Kiểm tra công tác bán trú**
>
> Kiểm tra việc xây dựng, triển khai kế hoạch nuôi dưỡng và tổ chức hoạt động bán trú; phân công trách nhiệm của Ban Giám hiệu, giáo viên, nhân viên cấp dưỡng và các cá nhân liên quan.
>
> Kiểm tra việc quản lý, sử dụng cơ sở vật chất, trang thiết bị bếp ăn; vệ sinh khu vực chế biến, kho thực phẩm, dụng cụ nấu ăn, dụng cụ chia ăn và khu vực tổ chức bữa ăn của trẻ.
>
> Kiểm tra việc xây dựng thực đơn, tính khẩu phần, bảo đảm chế độ dinh dưỡng phù hợp với độ tuổi; việc tiếp nhận, chế biến, chia ăn, bảo quản thực phẩm và thực hiện các quy định về an toàn thực phẩm.
>
> Kiểm tra việc tổ chức bữa ăn, giấc ngủ, chăm sóc vệ sinh cá nhân, theo dõi sức khỏe và bảo đảm an toàn cho trẻ trong thời gian bán trú.
>
> Kiểm tra kết quả nuôi dưỡng thông qua hồ sơ theo dõi sức khỏe, cân nặng, chiều cao, tình trạng dinh dưỡng và kết quả thực hiện các biện pháp chăm sóc sức khỏe phù hợp.
>
> Kiểm tra công tác phối hợp giữa bộ phận nuôi dưỡng, giáo viên và nhân viên y tế trong phát hiện, phòng ngừa và xử lý các vấn đề ảnh hưởng đến sức khỏe, an toàn của trẻ.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch nuôi dưỡng; thực đơn, khẩu phần; hồ sơ giao nhận thực phẩm; hồ sơ kiểm thực, lưu mẫu; chứng từ thực phẩm; hồ sơ sức khỏe, đánh giá tình trạng dinh dưỡng của trẻ; biên bản kiểm tra bếp ăn và kết quả quan sát thực tế.
>
> ### 2.4. Quản lý chất lượng
>
> Kiểm tra việc tổ chức thực hiện công tác theo dõi, đánh giá chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ theo Chương trình Giáo dục mầm non và hướng dẫn chuyên môn áp dụng đối với từng độ tuổi.
>
> Kiểm tra việc theo dõi sự phát triển của trẻ trong quá trình tổ chức hoạt động; thực hiện đánh giá theo quy định, sử dụng kết quả đánh giá để xác định nhu cầu hỗ trợ và điều chỉnh kế hoạch giáo dục.
>
> Kiểm tra việc quản lý hồ sơ, dữ liệu, số liệu về trẻ, nhóm, lớp, đội ngũ, chất lượng giáo dục, sức khỏe và tình trạng dinh dưỡng; sự thống nhất giữa số liệu báo cáo và minh chứng thực tế.
>
> Kiểm tra công tác tự đánh giá, kiểm định chất lượng giáo dục, xây dựng và thực hiện kế hoạch cải tiến chất lượng; mức độ khắc phục những hạn chế đã được phát hiện qua tự đánh giá, kiểm tra nội bộ và kiểm tra của cơ quan có thẩm quyền.
>
> Kiểm tra việc thực hiện các chế độ thống kê, tổng hợp và báo cáo định kỳ, đột xuất; tính chính xác, kịp thời và trách nhiệm của cá nhân, bộ phận được giao.
>
> Đối với các nội dung về đề kiểm tra, ma trận đề, coi, chấm thi nêu tại Công văn số 1134/SGDĐT-TCCB dành cho các cấp học có kiểm tra, thi cử, nhà trường không áp dụng máy móc vào đánh giá trẻ mầm non; thay bằng kiểm tra hoạt động quan sát, theo dõi và đánh giá sự phát triển của trẻ phù hợp với Chương trình Giáo dục mầm non.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch giáo dục; hồ sơ đánh giá trẻ; báo cáo chất lượng chăm sóc, nuôi dưỡng, giáo dục; số liệu thống kê; hồ sơ tự đánh giá, kiểm định chất lượng, cải tiến chất lượng và kết quả khắc phục sau kiểm tra.
>
> ---
>
> **Yêu cầu chung khi tổ chức thực hiện nội dung kiểm tra**
>
> Các nội dung nêu trên được lựa chọn, bố trí thành từng cuộc kiểm tra phù hợp với Kế hoạch kiểm tra nội bộ năm học 2026 - 2027. Không nhất thiết thực hiện toàn bộ nội dung trong cùng một đợt kiểm tra; ưu tiên những vấn đề có nguy cơ ảnh hưởng trực tiếp đến an toàn của trẻ, chất lượng chăm sóc, nuôi dưỡng, giáo dục, quản lý tài chính, tài sản và việc khắc phục các hạn chế của năm học trước.
>
> Mỗi cuộc kiểm tra phải xác định rõ nội dung, đối tượng, thời kỳ, thời hạn, thành phần kiểm tra và yêu cầu về hồ sơ, minh chứng; được tổ chức theo trình tự, thủ tục và biểu mẫu hướng dẫn tại Công văn số 1134/SGDĐT-TCCB.
>
> Việc kiểm tra kết hợp giữa nghiên cứu hồ sơ, đối chiếu quy định, quan sát thực tế, trao đổi, xác minh và đánh giá kết quả thực hiện. Các hồ sơ, minh chứng được nêu trong Kế hoạch là nguồn tài liệu để lựa chọn đối chiếu phù hợp, không làm phát sinh yêu cầu lập thêm hồ sơ ngoài quy định.
>
> Kết quả kiểm tra phải thể hiện rõ ưu điểm, hạn chế, nguyên nhân, trách nhiệm, kiến nghị và thời hạn khắc phục. Hiệu trưởng chỉ đạo theo dõi, đôn đốc, kiểm tra việc thực hiện kiến nghị sau kiểm tra, bảo đảm khắc phục thực chất, góp phần nâng cao hiệu quả quản lý và chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ của nhà trường.

## 📋 Đề xuất điều chỉnh danh mục 10 cuộc kiểm tra cho thống nhất

Để các nội dung chi tiết trên không chỉ dừng ở kế hoạch, tôi đề xuất gắn trực tiếp với danh mục các cuộc kiểm tra đã xây dựng trước đó như sau:

| Thời gian dự kiến | Nội dung trọng tâm | Mục tương ứng Công văn 1134 |
|--------|--------|--------|
| 11/2026 | Quản lý, chỉ đạo điều hành; chiến lược, kế hoạch giáo dục, quy chế, công khai, dân chủ | 1.1, 1.2, 1.10, 1.14, 1.18 |
| 11/2026 | Hoạt động sư phạm giáo viên đợt I; quản lý nhóm lớp, chăm sóc, giáo dục trẻ | 1.5, 2.1 |
| 12/2026 | Công tác quản lý tài chính, thu chi, chính sách, tài sản, xã hội hóa và thực hành tiết kiệm | 1.7, 1.9, 1.11, 1.13, 2.3 |
| 12/2026 | Công tác bán trú, dinh dưỡng, an toàn thực phẩm và chăm sóc sức khỏe | 1.17, 2.3 |
| 01/2027 | Công tác văn thư, hành chính, chuyển đổi số, dữ liệu và giải quyết kiến nghị | 1.15, 1.16, 2.2, 2.3 |
| 02/2027 | Hoạt động tổ chuyên môn, quản lý đội ngũ, bồi dưỡng và các phong trào thi đua | 1.4, 1.12, 2.3 |
| 03/2027 | Hoạt động sư phạm giáo viên đợt II; đổi mới phương pháp, đạo đức nhà giáo và truyền thông | 1.3, 2.1 |
| 03/2027 | An toàn trường học, phòng chống tai nạn thương tích, phòng cháy chữa cháy, y tế | 1.17, 2.2, 2.3 |
| 04/2027 | Cơ sở vật chất, thiết bị, sách, tài liệu; phối hợp cha mẹ trẻ và hoạt động của nhân viên | 1.6, 1.8, 2.2, 2.3 |
| Đầu 05/2027 | Quản lý chất lượng, hồ sơ kiểm tra nội bộ và kết quả khắc phục hạn chế sau kiểm tra | 2.4 và kiến nghị các cuộc trước |

Đây là **phương án phân kỳ đề xuất**, cần đối chiếu với kết quả kiểm tra năm học 2025–2026 và tình hình thực tế của trường để quyết định trọng tâm, số lượng và thời điểm kiểm tra. Các cuộc kiểm tra có nội dung liên quan nhau cần phân định rõ phạm vi để tránh trùng lặp.

## ⚠️ Ba vấn đề cần đặc biệt chú ý

Thứ nhất, Công văn 1134 dùng chung cho các cấp học nên có một số nội dung như dạy thêm, học thêm; bồi dưỡng học sinh giỏi; đề kiểm tra, ma trận, coi chấm thi. Khi vận dụng tại Trường Mầm non An Bình, cần giữ đúng tinh thần kiểm tra công tác quản lý và chất lượng giáo dục nhưng sử dụng tiêu chí phù hợp với trẻ mầm non, không đưa những nhiệm vụ không áp dụng thành yêu cầu bắt buộc.

Thứ hai, việc kiểm tra nhiệm vụ của Hiệu trưởng cần phân biệt với kiểm tra trách nhiệm của các tổ chuyên môn và nhân viên. Ban kiểm tra nội bộ có chức năng tham mưu, giúp Hiệu trưởng tự rà soát công tác quản lý; không thay thế hoạt động kiểm tra của cơ quan quản lý cấp trên.

Thứ ba, cần phân biệt rõ giữa **kiểm tra công tác quản lý** \(mục 1) và **kiểm tra hoạt động thực hiện nhiệm vụ** \(mục 2). Chẳng hạn, mục 1.7 xem xét trách nhiệm quản lý tài chính của nhà trường, còn mục 2.3 kiểm tra việc thực hiện nghiệp vụ của bộ phận kế toán, tài chính. Như vậy mới bảo đảm đầy đủ nội dung mà không chồng chéo.

## ✅ Kết luận

Bản chỉnh lý này đã giữ đầy đủ **18 nội dung quản lý và 4 nhóm nội dung kiểm tra giáo viên, nhân viên, các tổ/bộ phận và quản lý chất lượng** theo Mục II của Công văn 1134, đồng thời cụ thể hóa nội dung và nguồn minh chứng phù hợp với hoạt động của Trường Mầm non An Bình.

Để Kế hoạch thực sự sát thực tiễn, khâu tiếp theo quan trọng nhất là đối chiếu từng nội dung với **những hạn chế và kiến nghị đã có trong năm học 2025–2026**. Khi có căn cứ đó, nhà trường sẽ xác định được nội dung nào cần kiểm tra trọng tâm, nội dung nào chỉ cần kiểm tra thường xuyên, tránh xây dựng kế hoạch quá rộng nhưng khó thực hiện hiệu quả.

---

USER

bạn viết nội dung kiểm tra nội bộ theo hướng dẫn này của ủy ban phường. Lặp luận logic, chặt chẽ, dễ hiểu, bám sát thực tiễn  không quá dài dòng

---

ASSISTANT

Dưới đây là nội dung **Mục II. NỘI DUNG TRỌNG TÂM KIỂM TRA** được biên soạn lại theo đúng 3 nhóm nội dung tại Kế hoạch số 3458/KH-UBND ngày 28/10/2026 của UBND phường An Bình, đồng thời cụ thể hóa phù hợp với công tác quản lý, chăm sóc, nuôi dưỡng và giáo dục trẻ tại Trường Mầm non An Bình.

Nội dung được trình bày ngắn gọn, rõ việc cần kiểm tra, tránh trùng lặp và có thể đưa trực tiếp vào Kế hoạch kiểm tra nội bộ năm học 2026–2027.

> **writing · document**
>
> ## II. NỘI DUNG TRỌNG TÂM KIỂM TRA
>
> Căn cứ Công văn số 1134/SGDĐT-TCCB ngày 17/10/2025 của Sở Giáo dục và Đào tạo và các văn bản chỉ đạo về công tác kiểm tra nội bộ năm học 2026 - 2027, nhà trường lựa chọn nội dung kiểm tra phù hợp với nhiệm vụ năm học và tình hình thực tế; tập trung vào các nội dung trọng tâm sau:
>
> ### 1. Kiểm tra việc thực hiện nhiệm vụ của Thủ trưởng đơn vị
>
> - **Chiến lược phát triển và quy chế tổ chức:** Kiểm tra việc xây dựng, ban hành, rà soát, cập nhật và tổ chức thực hiện Chiến lược phát triển nhà trường, kế hoạch năm học, Quy chế tổ chức và hoạt động, Quy chế dân chủ ở cơ sở; việc phân công nhiệm vụ, thực hiện công khai và trách nhiệm chỉ đạo, điều hành các hoạt động của nhà trường theo quy định.
>
> - **Tài chính và tài sản:** Kiểm tra công tác quản lý thu, chi ngân sách; các khoản thu dịch vụ phục vụ hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ; việc quản lý, sử dụng các nguồn tài trợ, hỗ trợ hợp pháp và việc phối hợp, giám sát các khoản kinh phí hoạt động của Ban đại diện cha mẹ trẻ theo đúng thẩm quyền. Kiểm tra việc thực hiện chế độ tài chính, công khai thu chi; công tác mua sắm, kiểm kê, quản lý, bảo quản và sử dụng cơ sở vật chất, tài sản, trang thiết bị, đồ dùng, đồ chơi của nhà trường.
>
> - **Quản lý đội ngũ và thực hiện các quy định chuyên môn:** Kiểm tra công tác quản lý, phân công, sử dụng, đánh giá, xếp loại cán bộ quản lý, giáo viên, nhân viên; việc thực hiện chế độ, chính sách, bồi dưỡng chuyên môn, đạo đức nhà giáo, quy chế làm việc và nhiệm vụ được giao. Kiểm tra việc chấp hành các quy định về tổ chức hoạt động giáo dục; đối với nội dung dạy thêm, học thêm theo hướng dẫn chung của Sở, chỉ kiểm tra khi có hoạt động phát sinh thuộc phạm vi áp dụng của quy định.
>
> - **Chuyển đổi số và dữ liệu ngành:** Kiểm tra việc xây dựng, triển khai kế hoạch chuyển đổi số; sử dụng hệ thống quản lý văn bản điện tử, chữ ký số, các phần mềm quản lý và ứng dụng công nghệ thông tin trong điều hành, chăm sóc, giáo dục trẻ. Kiểm tra việc cập nhật, quản lý, khai thác cơ sở dữ liệu ngành bảo đảm nguyên tắc **“Đúng - Đủ - Sạch - Sống”**; tính chính xác của số liệu báo cáo và việc bảo đảm an toàn, bảo mật thông tin.
>
> - **An toàn trường học và công tác bán trú:** Kiểm tra việc thực hiện các quy định về phòng cháy, chữa cháy; an ninh, an toàn trường học; phòng, chống tai nạn thương tích, bạo lực, xâm hại trẻ em; công tác y tế, vệ sinh môi trường và phòng, chống dịch bệnh. Kiểm tra công tác quản lý, tổ chức bán trú; nguồn gốc thực phẩm, quy trình giao nhận, chế biến, kiểm thực, lưu mẫu thức ăn; thực đơn, khẩu phần dinh dưỡng, vệ sinh an toàn thực phẩm và việc bảo đảm an toàn cho trẻ trong các hoạt động ăn, ngủ, sinh hoạt hằng ngày.
>
> ### 2. Kiểm tra hoạt động của giáo viên, nhân viên và các bộ phận
>
> - **Đối với giáo viên:** Kiểm tra việc chấp hành quy chế chuyên môn, đạo đức nhà giáo; xây dựng và thực hiện kế hoạch giáo dục, tổ chức các hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ theo Chương trình Giáo dục mầm non. Kiểm tra năng lực sư phạm thông qua dự giờ, quan sát hoạt động thực tế; việc xây dựng môi trường giáo dục lấy trẻ làm trung tâm, quản lý nhóm lớp, bảo đảm an toàn, theo dõi và đánh giá sự phát triển của trẻ. Kiểm tra việc tham gia sinh hoạt chuyên môn, tự bồi dưỡng, ứng dụng công nghệ thông tin và phối hợp với cha mẹ trẻ trong thực hiện nhiệm vụ.
>
> - **Đối với nhân viên:** Kiểm tra việc xây dựng kế hoạch công tác, chấp hành nội quy, thời gian làm việc và thực hiện chức trách, nhiệm vụ được giao. Tập trung kiểm tra công tác văn thư, hành chính, quản lý văn bản, con dấu và lưu trữ hồ sơ; nghiệp vụ kế toán, thủ quỹ, quản lý tài chính, tài sản; công tác y tế trường học, bảo vệ, nuôi dưỡng, chế biến thực phẩm và phục vụ bán trú. Đánh giá tinh thần trách nhiệm, thái độ phục vụ, kết quả thực hiện nhiệm vụ và sự phối hợp giữa các bộ phận.
>
> - **Đối với các tổ chuyên môn và Tổ Văn phòng:** Kiểm tra việc xây dựng, triển khai kế hoạch hoạt động; công tác quản lý của tổ trưởng, nền nếp sinh hoạt tổ, thực hiện hồ sơ chuyên môn, bồi dưỡng đội ngũ và kết quả thực hiện nhiệm vụ. Kiểm tra việc quản lý, sử dụng thiết bị, đồ dùng, đồ chơi, hồ sơ hành chính, tài chính và công tác phối hợp trong tổ chức các hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> ### 3. Rà soát, lựa chọn nội dung và tập trung khắc phục hạn chế
>
> **a) Chủ động rà soát hạn chế năm học trước**
>
> Căn cứ kết quả thực hiện nhiệm vụ, hồ sơ kiểm tra nội bộ và các kiến nghị sau kiểm tra năm học 2025 - 2026, nhà trường tổ chức rà soát, đánh giá những ưu điểm, hạn chế, tồn tại và nguyên nhân trong từng lĩnh vực công tác.
>
> Trên cơ sở đó, xác định nội dung cần tập trung kiểm tra trong năm học 2026 - 2027, ưu tiên các lĩnh vực có nguy cơ phát sinh sai sót hoặc ảnh hưởng trực tiếp đến chất lượng chăm sóc, nuôi dưỡng, giáo dục và sự an toàn của trẻ, nhất là công tác quản lý thu chi tài chính, bán trú, vệ sinh an toàn thực phẩm, thực hiện quy chế chuyên môn và cập nhật dữ liệu ngành.
>
> Việc lựa chọn nội dung kiểm tra phải có trọng tâm, trọng điểm, phù hợp điều kiện thực tế; tránh dàn trải, trùng lặp, bảo đảm hiệu quả và tính khả thi trong tổ chức thực hiện.
>
> **b) Xử lý dứt điểm sau kiểm tra**
>
> Mỗi cuộc kiểm tra phải thực hiện đầy đủ quy trình, hồ sơ theo hướng dẫn của Sở Giáo dục và Đào tạo; lập Biên bản kiểm tra (Mẫu số 04), Báo cáo kết quả kiểm tra (Mẫu số 05) và ban hành Thông báo kết quả kiểm tra (Mẫu số 06) gửi đến đối tượng được kiểm tra và các bộ phận có liên quan.
>
> Kết quả kiểm tra phải đánh giá khách quan, có căn cứ; nêu rõ ưu điểm, hạn chế, nguyên nhân, trách nhiệm của tập thể, cá nhân và kiến nghị biện pháp khắc phục cụ thể.
>
> Hiệu trưởng phân công trách nhiệm, xác định thời hạn khắc phục; chỉ đạo theo dõi, đôn đốc và kiểm tra kết quả thực hiện kiến nghị sau kiểm tra. Đối với những hạn chế có nguy cơ ảnh hưởng đến an toàn của trẻ, chất lượng giáo dục, tài chính, tài sản hoặc uy tín nhà trường, phải kịp thời chấn chỉnh, xử lý dứt điểm theo thẩm quyền.
>
> Kết quả kiểm tra và việc khắc phục hạn chế được thông tin, công khai trong phạm vi phù hợp tại các cuộc họp giao ban, sinh hoạt chuyên môn; làm cơ sở điều chỉnh công tác quản lý, nâng cao trách nhiệm của đội ngũ và chất lượng hoạt động nhà trường.

### ✅ Nhận xét về tính phù hợp

Bản này bảo đảm ba yêu cầu quan trọng:

- **Đúng định hướng của UBND phường:** Giữ nguyên 3 nhóm nội dung và 5 lĩnh vực trọng tâm kiểm tra trách nhiệm Thủ trưởng đơn vị.
- **Phù hợp đặc thù mầm non:** Chuyển các yêu cầu chung thành nội dung kiểm tra về kế hoạch giáo dục, hoạt động sư phạm, bảo đảm an toàn cho trẻ, dinh dưỡng, bán trú và quản lý đội ngũ.
- **Thuận lợi khi triển khai:** Nội dung đủ cụ thể để xây dựng danh mục các cuộc kiểm tra, quyết định kiểm tra, kế hoạch tiến hành kiểm tra và đánh giá kết quả thực tế.

**Tôi đề xuất sử dụng bản này trong Kế hoạch chính thức.** Nội dung đã được tinh gọn so với bản trước nhưng vẫn giữ các trọng tâm của UBND phường. Khi lập Danh mục các cuộc kiểm tra tại Mục IV, cần lựa chọn và phân bổ các nội dung trên thành từng cuộc kiểm tra cụ thể, không nhất thiết kiểm tra tất cả nội dung trong một đợt.

---

USER

bạn trình bày theo cách trước đây, nội dung này ngắn gọn quá. nhớ đảm bảo nội dung mới này  hhe

---

ASSISTANT

Tôi sẽ trình bày lại theo cách trước đây: **nội dung đầy đủ, phân chia thành các tiểu mục rõ ràng, cụ thể từng công việc cần kiểm tra và hồ sơ, minh chứng đối chiếu**. Đồng thời, giữ đúng 3 nhóm nội dung và các trọng tâm mới tại Kế hoạch số 3458/KH-UBND ngày 28/10/2026 của UBND phường An Bình, bám sát Công văn số 1134/SGDĐT-TCCB của Sở Giáo dục và Đào tạo.

Dưới đây là nội dung đã chỉnh lý theo văn phong hành chính, phù hợp để đưa trực tiếp vào **Mục II của Kế hoạch kiểm tra nội bộ năm học 2026–2027 của Trường Mầm non An Bình**.

> **writing · document**
>
> # II. NỘI DUNG TRỌNG TÂM KIỂM TRA
>
> Căn cứ Công văn số 1134/SGDĐT-TCCB ngày 17 tháng 10 năm 2025 của Sở Giáo dục và Đào tạo Đồng Tháp và các văn bản chỉ đạo, hướng dẫn về công tác kiểm tra nội bộ năm học 2026 - 2027; trên cơ sở nhiệm vụ năm học, điều kiện thực tế và kết quả rà soát những hạn chế, tồn tại của năm học 2025 - 2026, Trường Mầm non An Bình xác định các nội dung kiểm tra trọng tâm như sau:
>
> ## 1. Kiểm tra việc thực hiện nhiệm vụ của Thủ trưởng đơn vị
>
> ### 1.1. Chiến lược phát triển và quy chế tổ chức
>
> Kiểm tra việc xây dựng, ban hành, rà soát, bổ sung và tổ chức thực hiện Chiến lược phát triển nhà trường; việc xác định mục tiêu, nhiệm vụ, giải pháp phát triển phù hợp với quy mô trường lớp, điều kiện đội ngũ, cơ sở vật chất và yêu cầu phát triển giáo dục mầm non của địa phương.
>
> Kiểm tra việc xây dựng, ban hành và tổ chức thực hiện Quy chế tổ chức và hoạt động, Quy chế dân chủ ở cơ sở, các quy chế, quy định nội bộ; việc thực hiện đúng thẩm quyền, quy trình lấy ý kiến và công khai trước khi triển khai thực hiện.
>
> Kiểm tra việc xây dựng, ban hành, triển khai kế hoạch thực hiện nhiệm vụ năm học, kế hoạch giáo dục nhà trường và các kế hoạch chuyên môn; sự thống nhất giữa mục tiêu, chỉ tiêu, nội dung, giải pháp và phân công trách nhiệm thực hiện.
>
> Kiểm tra công tác quản lý, chỉ đạo, điều hành của Ban Giám hiệu; việc phân công nhiệm vụ cho cán bộ quản lý, giáo viên, nhân viên; công tác phối hợp giữa các tổ chuyên môn, Tổ Văn phòng và các bộ phận trong thực hiện nhiệm vụ.
>
> Kiểm tra việc tổ chức thực hiện công khai theo quy định, tập trung vào các nội dung về tổ chức và hoạt động nhà trường, điều kiện bảo đảm chất lượng giáo dục, đội ngũ, cơ sở vật chất, chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ và các khoản thu, chi thuộc diện phải công khai.
>
> Đánh giá kết quả tổ chức thực hiện các kế hoạch, quy chế; xác định những nội dung đã thực hiện hiệu quả, những hạn chế trong công tác chỉ đạo, điều hành và trách nhiệm của các bộ phận, cá nhân có liên quan.
>
> **Hồ sơ, minh chứng đối chiếu:** Chiến lược phát triển nhà trường; kế hoạch năm học; kế hoạch giáo dục; các quy chế, quy định; quyết định phân công nhiệm vụ; biên bản họp; hồ sơ công khai; báo cáo kết quả thực hiện nhiệm vụ và các minh chứng thực tế có liên quan.
>
> ### 1.2. Công tác quản lý tài chính và tài sản
>
> Kiểm tra việc xây dựng, phân bổ, quản lý và sử dụng dự toán ngân sách được giao; việc thực hiện các khoản thu, chi theo đúng quy định, bảo đảm công khai, minh bạch, tiết kiệm và hiệu quả.
>
> Kiểm tra công tác quản lý các khoản thu dịch vụ phục vụ, hỗ trợ hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ; việc xây dựng dự toán, xác định mức thu, tổ chức thu, sử dụng, thanh toán, quyết toán và công khai các khoản thu theo quy định.
>
> Kiểm tra việc quản lý, tiếp nhận và sử dụng các nguồn tài trợ, hỗ trợ hợp pháp, các khoản huy động xã hội hóa giáo dục (nếu có); việc thực hiện nguyên tắc tự nguyện, đúng mục đích, đúng thẩm quyền và công khai kết quả sử dụng.
>
> Kiểm tra việc phối hợp với Ban đại diện cha mẹ trẻ trong thực hiện các hoạt động theo quy định; việc quản lý, sử dụng kinh phí hoạt động của Ban đại diện đúng chức năng, trách nhiệm của từng chủ thể; không sử dụng các khoản kinh phí này để thay thế những nhiệm vụ chi thuộc trách nhiệm của nhà trường.
>
> Kiểm tra công tác kế toán, tài chính, thủ quỹ; việc lập, quản lý chứng từ, sổ sách kế toán, thanh toán, quyết toán, đối chiếu số liệu và thực hiện các quy định về quản lý tài chính.
>
> Kiểm tra việc quản lý, sử dụng cơ sở vật chất, tài sản công, thiết bị, đồ dùng, đồ chơi; công tác mua sắm, tiếp nhận, bàn giao, kiểm kê, sửa chữa, bảo quản, thanh lý tài sản theo quy định.
>
> Kiểm tra việc thực hiện các chế độ, chính sách đối với cán bộ quản lý, giáo viên, nhân viên và trẻ em thuộc diện được hưởng chính sách; việc lập hồ sơ, xét duyệt, chi trả bảo đảm đúng đối tượng, đúng chế độ và thời gian quy định.
>
> Đánh giá việc thực hành tiết kiệm, chống lãng phí trong quản lý, sử dụng kinh phí, tài sản, thiết bị và các nguồn lực của nhà trường; kịp thời phát hiện, chấn chỉnh các hạn chế, sai sót trong công tác quản lý.
>
> **Hồ sơ, minh chứng đối chiếu:** Dự toán, quyết toán ngân sách; quy chế chi tiêu nội bộ; hồ sơ các khoản thu, chi; chứng từ, sổ kế toán; hồ sơ tài trợ, hỗ trợ; tài liệu công khai tài chính; hồ sơ mua sắm, quản lý và kiểm kê tài sản; hồ sơ thực hiện chế độ, chính sách và các tài liệu liên quan.
>
> ### 1.3. Công tác quản lý đội ngũ và thực hiện các quy định chuyên môn
>
> Kiểm tra việc quản lý, sử dụng đội ngũ cán bộ quản lý, giáo viên, nhân viên; việc bố trí, phân công nhiệm vụ phù hợp với vị trí việc làm, trình độ chuyên môn, năng lực thực tế và yêu cầu tổ chức hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Kiểm tra việc quản lý hồ sơ viên chức, người lao động; công tác tuyển dụng, tiếp nhận, hợp đồng, phân công, đánh giá, xếp loại, khen thưởng, kỷ luật và thực hiện chế độ, chính sách theo thẩm quyền.
>
> Kiểm tra việc xây dựng và thực hiện kế hoạch bồi dưỡng chuyên môn, nghiệp vụ, bồi dưỡng thường xuyên; công tác tổ chức sinh hoạt chuyên môn, triển khai chuyên đề, hỗ trợ giáo viên nâng cao năng lực nghề nghiệp và đổi mới phương pháp giáo dục.
>
> Kiểm tra việc chỉ đạo thực hiện Chương trình Giáo dục mầm non; xây dựng, triển khai kế hoạch giáo dục nhà trường; tổ chức các hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ phù hợp với từng độ tuổi, điều kiện thực tế và quan điểm giáo dục lấy trẻ làm trung tâm.
>
> Kiểm tra việc thực hiện quy chế chuyên môn, đạo đức nhà giáo, quy tắc ứng xử, kỷ luật lao động; tinh thần trách nhiệm, thái độ giao tiếp, ứng xử của cán bộ quản lý, giáo viên, nhân viên với trẻ, cha mẹ trẻ và đồng nghiệp.
>
> Kiểm tra việc tổ chức theo dõi, đánh giá sự phát triển của trẻ; công tác quản lý nhóm, lớp, duy trì nền nếp, chuyên cần, bảo đảm an toàn và phối hợp với cha mẹ trẻ trong thực hiện nhiệm vụ.
>
> Kiểm tra việc chấp hành các quy định về tổ chức hoạt động giáo dục và các hoạt động dịch vụ, hỗ trợ giáo dục trong nhà trường (nếu có). Đối với nội dung dạy thêm, học thêm theo hướng dẫn chung của Sở, thực hiện kiểm tra trong phạm vi có liên quan và thuộc đối tượng áp dụng của quy định, không áp dụng máy móc các yêu cầu dành riêng cho giáo dục phổ thông.
>
> Đánh giá hiệu quả công tác quản lý, sử dụng và phát triển đội ngũ; xác định những khó khăn, hạn chế trong thực hiện nhiệm vụ để có biện pháp chỉ đạo, hỗ trợ, bồi dưỡng phù hợp.
>
> **Hồ sơ, minh chứng đối chiếu:** Hồ sơ quản lý đội ngũ; quyết định và bảng phân công nhiệm vụ; kế hoạch bồi dưỡng; hồ sơ đánh giá, xếp loại viên chức; kế hoạch giáo dục nhà trường; hồ sơ chuyên môn; biên bản sinh hoạt chuyên môn; kết quả dự giờ, kiểm tra và các minh chứng thực tế.
>
> ### 1.4. Công tác chuyển đổi số và quản lý dữ liệu ngành
>
> Kiểm tra việc xây dựng, ban hành, triển khai kế hoạch chuyển đổi số, ứng dụng công nghệ thông tin trong công tác quản lý, chỉ đạo, điều hành và tổ chức các hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Kiểm tra việc phân công trách nhiệm quản lý, sử dụng các hệ thống phần mềm, cơ sở dữ liệu; việc vận hành hệ thống quản lý văn bản điện tử, chữ ký số, thư điện tử công vụ, website và các nền tảng số được triển khai tại nhà trường.
>
> Kiểm tra công tác quản lý, cập nhật, khai thác cơ sở dữ liệu ngành đối với thông tin nhà trường, nhóm lớp, đội ngũ, trẻ và các nội dung quản lý khác; bảo đảm nguyên tắc **“Đúng - Đủ - Sạch - Sống”**, cụ thể:
>
> - **Đúng:** Thông tin, số liệu được cập nhật chính xác, thống nhất với hồ sơ thực tế.
> - **Đủ:** Các trường thông tin, dữ liệu bắt buộc được cập nhật đầy đủ theo yêu cầu.
> - **Sạch:** Dữ liệu được rà soát, chuẩn hóa, khắc phục sai lệch, trùng lặp và thông tin không còn phù hợp.
> - **Sống:** Dữ liệu được cập nhật thường xuyên, kịp thời khi có biến động, phục vụ hiệu quả công tác quản lý và báo cáo.
>
> Kiểm tra việc thực hiện chế độ thống kê, báo cáo; tính chính xác, thống nhất giữa dữ liệu trên phần mềm với hồ sơ, sổ sách và số liệu thực tế tại các nhóm, lớp, bộ phận.
>
> Kiểm tra việc quản lý tài khoản, phân quyền truy cập, bảo đảm an toàn thông tin, bảo vệ dữ liệu cá nhân, thông tin và hình ảnh của trẻ; việc lưu trữ, sao lưu dữ liệu và thực hiện các quy định về an toàn không gian mạng.
>
> Đánh giá hiệu quả ứng dụng công nghệ thông tin, chuyển đổi số trong quản trị nhà trường, giảm hồ sơ giấy không cần thiết, nâng cao chất lượng quản lý và thực hiện nhiệm vụ chuyên môn.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch chuyển đổi số; quyết định hoặc bảng phân công trách nhiệm; hệ thống văn bản điện tử, chữ ký số; dữ liệu trên phần mềm quản lý; các báo cáo thống kê; hồ sơ gốc và kết quả đối chiếu thông tin, số liệu thực tế.
>
> ### 1.5. Công tác an toàn trường học và tổ chức bán trú
>
> Kiểm tra việc xây dựng, ban hành và tổ chức thực hiện các kế hoạch, phương án bảo đảm an toàn trường học; phòng, chống tai nạn thương tích, bạo lực, xâm hại trẻ em; phòng cháy, chữa cháy, an ninh, trật tự và phòng, chống dịch bệnh.
>
> Kiểm tra việc quản lý, bảo đảm an toàn cho trẻ trong các hoạt động hằng ngày; quy trình đón, trả trẻ, tổ chức hoạt động học, chơi, ăn, ngủ, vệ sinh, hoạt động ngoài trời và các hoạt động trải nghiệm; việc phân công trách nhiệm quản lý, giám sát trẻ của giáo viên, nhân viên.
>
> Kiểm tra điều kiện an toàn của phòng học, phòng chức năng, sân chơi, đồ chơi ngoài trời, cổng trường, hệ thống điện, nước, nhà vệ sinh và các khu vực có nguy cơ gây tai nạn, thương tích; việc phát hiện, xử lý kịp thời các yếu tố mất an toàn.
>
> Kiểm tra công tác y tế trường học; việc theo dõi, quản lý hồ sơ sức khỏe, tổ chức cân đo, theo dõi tình trạng dinh dưỡng; công tác phòng, chống dịch bệnh, vệ sinh môi trường, nước sạch và chăm sóc sức khỏe ban đầu cho trẻ.
>
> Kiểm tra việc tổ chức, quản lý công tác bán trú; điều kiện cơ sở vật chất, trang thiết bị phục vụ nuôi dưỡng; việc phân công nhiệm vụ, quản lý hoạt động của nhân viên cấp dưỡng và phối hợp giữa bộ phận nuôi dưỡng với giáo viên, nhân viên y tế.
>
> Kiểm tra công tác bảo đảm an toàn thực phẩm, tập trung vào các nội dung: hợp đồng và nguồn gốc cung cấp thực phẩm; tiếp nhận, kiểm tra chất lượng thực phẩm; bảo quản, sơ chế, chế biến, chia ăn; thực hiện kiểm thực, lưu mẫu thức ăn; vệ sinh bếp ăn, dụng cụ chế biến và vệ sinh cá nhân của nhân viên cấp dưỡng.
>
> Kiểm tra việc xây dựng thực đơn, tính khẩu phần, tổ chức bữa ăn phù hợp với độ tuổi, bảo đảm chất lượng dinh dưỡng; việc theo dõi tình trạng dinh dưỡng, phòng, chống suy dinh dưỡng, thừa cân, béo phì và thực hiện các biện pháp cải thiện chất lượng nuôi dưỡng trẻ.
>
> Kiểm tra công tác tập huấn, tuyên truyền kiến thức an toàn trường học, an toàn thực phẩm; phương án và kỹ năng xử lý các tình huống khẩn cấp, sự cố phát sinh trong quá trình chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Đánh giá kết quả thực hiện các biện pháp bảo đảm an toàn; kịp thời phát hiện, chấn chỉnh và khắc phục những nguy cơ ảnh hưởng trực tiếp đến sức khỏe, tính mạng, sự phát triển của trẻ và hoạt động chung của nhà trường.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch an toàn trường học; hồ sơ phòng cháy, chữa cháy; hồ sơ phòng, chống tai nạn thương tích; hồ sơ y tế; kế hoạch nuôi dưỡng; thực đơn, khẩu phần; hợp đồng thực phẩm; hồ sơ giao nhận, kiểm thực, lưu mẫu thức ăn; hồ sơ theo dõi sức khỏe, tình trạng dinh dưỡng của trẻ; biên bản kiểm tra và kết quả quan sát thực tế.
>
> ## 2. Kiểm tra hoạt động của giáo viên, nhân viên và các bộ phận
>
> ### 2.1. Kiểm tra hoạt động sư phạm của giáo viên
>
> **a) Việc thực hiện phẩm chất, đạo đức và quy chế chuyên môn**
>
> Kiểm tra việc chấp hành chủ trương, chính sách của Đảng, pháp luật của Nhà nước, quy định của ngành; đạo đức nhà giáo, quy tắc ứng xử, nội quy, quy chế và nhiệm vụ được phân công.
>
> Kiểm tra việc thực hiện thời gian làm việc, nền nếp chuyên môn, tinh thần trách nhiệm trong chăm sóc, nuôi dưỡng, giáo dục trẻ; thái độ giao tiếp, ứng xử với trẻ, cha mẹ trẻ và đồng nghiệp; việc bảo đảm an toàn về thể chất, tinh thần cho trẻ.
>
> **b) Việc xây dựng và thực hiện kế hoạch giáo dục**
>
> Kiểm tra việc xây dựng kế hoạch giáo dục nhóm, lớp phù hợp với Chương trình Giáo dục mầm non, kế hoạch giáo dục nhà trường, độ tuổi, đặc điểm, khả năng và nhu cầu phát triển của trẻ.
>
> Kiểm tra nội dung, tiến độ thực hiện kế hoạch giáo dục; việc chuẩn bị đồ dùng, đồ chơi, học liệu, môi trường giáo dục; tính linh hoạt trong tổ chức và điều chỉnh hoạt động theo tình hình thực tế của nhóm, lớp.
>
> Kiểm tra việc tổ chức chế độ sinh hoạt hằng ngày; thực hiện các hoạt động học, chơi, hoạt động ngoài trời, ăn, ngủ, vệ sinh; bảo đảm hài hòa giữa chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> **c) Năng lực chuyên môn, nghiệp vụ và kỹ năng sư phạm**
>
> Kiểm tra thông qua dự giờ, quan sát thực tế hoạt động của giáo viên; đánh giá việc xác định mục tiêu, lựa chọn nội dung, phương pháp, hình thức tổ chức hoạt động phù hợp với đặc điểm tâm sinh lý và khả năng của trẻ.
>
> Kiểm tra kỹ năng tổ chức môi trường giáo dục lấy trẻ làm trung tâm; tạo cơ hội cho trẻ được trải nghiệm, thực hành, giao tiếp, hợp tác và phát huy tính tích cực, chủ động trong các hoạt động.
>
> Kiểm tra năng lực quản lý nhóm, lớp; kỹ năng quan sát, hỗ trợ trẻ, xử lý tình huống sư phạm; việc quan tâm, hỗ trợ trẻ có khó khăn trong học tập, sinh hoạt, trẻ có nhu cầu đặc biệt và trẻ khuyết tật học hòa nhập (nếu có).
>
> **d) Kết quả chăm sóc, nuôi dưỡng, giáo dục trẻ**
>
> Kiểm tra việc theo dõi chuyên cần, sức khỏe, nền nếp và kết quả thực hiện các hoạt động chăm sóc, giáo dục trẻ; việc quan sát, theo dõi, đánh giá sự phát triển của trẻ theo quy định.
>
> Đánh giá sự tiến bộ của trẻ về thể chất, nhận thức, ngôn ngữ, tình cảm, kỹ năng xã hội và thẩm mỹ; việc hình thành kỹ năng tự phục vụ, thói quen vệ sinh, giao tiếp và tham gia hoạt động phù hợp với từng độ tuổi.
>
> Kiểm tra việc sử dụng kết quả đánh giá trẻ để điều chỉnh kế hoạch giáo dục; sự phối hợp với cha mẹ trẻ trong chăm sóc, nuôi dưỡng, giáo dục và hỗ trợ trẻ phát triển.
>
> **đ) Công tác bồi dưỡng và thực hiện các nhiệm vụ khác**
>
> Kiểm tra việc tham gia sinh hoạt chuyên môn, dự giờ, học tập chuyên đề, bồi dưỡng thường xuyên, tự học, tự bồi dưỡng và vận dụng kiến thức, kỹ năng vào thực tiễn giảng dạy.
>
> Kiểm tra việc ứng dụng công nghệ thông tin, sử dụng phần mềm, quản lý hồ sơ, dữ liệu nhóm lớp; việc bảo vệ thông tin cá nhân và hình ảnh của trẻ theo quy định.
>
> Kiểm tra việc phối hợp với cha mẹ trẻ, thực hiện công tác tuyên truyền, tham gia các phong trào thi đua, hoạt động tập thể và các nhiệm vụ khác được nhà trường phân công.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch giáo dục nhóm, lớp; hồ sơ chuyên môn của giáo viên; phiếu dự giờ; kết quả quan sát hoạt động thực tế; hồ sơ theo dõi, đánh giá sự phát triển của trẻ; biên bản sinh hoạt chuyên môn và minh chứng thực hiện nhiệm vụ.
>
> ### 2.2. Kiểm tra việc thực hiện nhiệm vụ của nhân viên
>
> **a) Việc xây dựng kế hoạch và chấp hành quy định làm việc**
>
> Kiểm tra việc xây dựng kế hoạch công tác cá nhân phù hợp với chức trách, nhiệm vụ được giao; việc thực hiện thời gian lao động, nội quy, quy chế của nhà trường, quy định về an toàn lao động và vệ sinh môi trường.
>
> Kiểm tra tinh thần trách nhiệm, thái độ phục vụ, ý thức phối hợp trong thực hiện nhiệm vụ; việc chấp hành sự phân công và kết quả thực hiện công việc.
>
> **b) Việc thực hiện chức trách, nhiệm vụ theo từng vị trí**
>
> - **Đối với nhân viên văn thư, hành chính:** Kiểm tra việc tiếp nhận, xử lý, ban hành, chuyển giao và lưu trữ văn bản; quản lý, sử dụng con dấu, chữ ký số; lập, quản lý hồ sơ hành chính và thực hiện công tác báo cáo theo nhiệm vụ được giao.
>
> - **Đối với nhân viên kế toán, thủ quỹ:** Kiểm tra việc thực hiện các nghiệp vụ thu, chi; quản lý tiền, chứng từ, sổ sách kế toán; lập dự toán, thanh toán, quyết toán, công khai tài chính; quản lý tài sản và thực hiện các chế độ, chính sách theo phân công.
>
> - **Đối với nhân viên y tế:** Kiểm tra công tác quản lý hồ sơ sức khỏe trẻ; theo dõi sức khỏe, tình trạng dinh dưỡng; phòng, chống dịch bệnh, sơ cấp cứu ban đầu; công tác vệ sinh trường học, tuyên truyền, phối hợp bảo đảm an toàn cho trẻ.
>
> - **Đối với nhân viên cấp dưỡng:** Kiểm tra việc thực hiện quy trình giao nhận, bảo quản, sơ chế, chế biến và chia ăn; vệ sinh an toàn thực phẩm, vệ sinh cá nhân, dụng cụ, khu vực bếp ăn; việc thực hiện thực đơn, khẩu phần và các nhiệm vụ nuôi dưỡng được phân công.
>
> - **Đối với nhân viên bảo vệ:** Kiểm tra việc thực hiện nhiệm vụ trực, bảo vệ tài sản, bảo đảm an ninh, trật tự trường học; kiểm soát người ra vào, phối hợp bảo đảm an toàn trong giờ đón, trả trẻ; công tác phòng ngừa, phát hiện và xử lý các nguy cơ mất an toàn.
>
> - **Đối với nhân viên hoặc người được phân công phụ trách tài sản, thiết bị:** Kiểm tra việc quản lý, cấp phát, bảo quản, kiểm kê, theo dõi sử dụng, đề xuất sửa chữa, bổ sung trang thiết bị, đồ dùng, đồ chơi phục vụ hoạt động của nhà trường.
>
> **c) Công tác phối hợp và kết quả thực hiện nhiệm vụ**
>
> Kiểm tra việc phối hợp giữa các nhân viên với giáo viên, tổ chuyên môn, Tổ Văn phòng và Ban Giám hiệu; việc thực hiện chế độ thông tin, báo cáo, hoàn thành nhiệm vụ đúng tiến độ, chất lượng.
>
> Đánh giá kết quả thực hiện chức trách, nhiệm vụ của từng vị trí; những ưu điểm, hạn chế, nguyên nhân và biện pháp khắc phục nhằm nâng cao hiệu quả hoạt động phục vụ chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch công tác; bảng phân công nhiệm vụ; hồ sơ nghiệp vụ của từng vị trí; sổ theo dõi công việc; bảng chấm công; báo cáo kết quả thực hiện nhiệm vụ và kết quả kiểm tra thực tế.
>
> ### 2.3. Kiểm tra hoạt động của các tổ chuyên môn và các bộ phận
>
> **a) Đối với các tổ chuyên môn**
>
> Kiểm tra việc xây dựng, triển khai và thực hiện kế hoạch hoạt động của tổ; công tác quản lý, chỉ đạo, điều hành của tổ trưởng và việc phân công nhiệm vụ cho các thành viên.
>
> Kiểm tra hồ sơ quản lý, hồ sơ chuyên môn; nền nếp, nội dung và chất lượng sinh hoạt chuyên môn; việc tổ chức dự giờ, trao đổi, góp ý, rút kinh nghiệm và giải quyết những khó khăn trong thực hiện Chương trình Giáo dục mầm non.
>
> Kiểm tra việc tổ chức thực hiện kế hoạch giáo dục tại các nhóm, lớp; công tác bồi dưỡng, tự bồi dưỡng chuyên môn nghiệp vụ, triển khai các chuyên đề, đổi mới phương pháp và xây dựng môi trường giáo dục lấy trẻ làm trung tâm.
>
> Kiểm tra việc ứng dụng công nghệ thông tin trong quản lý, tổ chức hoạt động chuyên môn; việc cập nhật, quản lý hồ sơ, dữ liệu và phối hợp thực hiện nhiệm vụ chuyển đổi số.
>
> Đánh giá chất lượng hoạt động của tổ thông qua kết quả thực hiện nhiệm vụ, sự tiến bộ về năng lực của giáo viên và chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ tại các nhóm, lớp.
>
> **b) Đối với Tổ Văn phòng**
>
> Kiểm tra việc xây dựng và tổ chức thực hiện kế hoạch hoạt động của tổ; phân công nhiệm vụ, thực hiện nội quy, quy chế và công tác phối hợp giữa các thành viên.
>
> Kiểm tra công tác văn thư, hành chính, quản lý văn bản, con dấu, hồ sơ lưu trữ; việc quản lý, cấp phát văn phòng phẩm và thực hiện các nhiệm vụ hành chính được giao.
>
> Kiểm tra công tác kế toán, tài chính, thủ quỹ; quản lý thu, chi, thanh toán, quyết toán; việc thực hiện các chế độ, chính sách, quản lý tài sản và công khai theo quy định.
>
> Kiểm tra công tác mua sắm, quản lý, bảo quản, sử dụng trang thiết bị, đồ dùng, đồ chơi, sách, tài liệu, học liệu; việc kiểm kê, sửa chữa và đề xuất bổ sung cơ sở vật chất phục vụ hoạt động của nhà trường.
>
> Kiểm tra công tác quản lý, phục vụ bán trú; việc phối hợp giữa bộ phận nuôi dưỡng, y tế, bảo vệ và giáo viên nhằm bảo đảm chất lượng chăm sóc, nuôi dưỡng và an toàn cho trẻ.
>
> Đánh giá tinh thần trách nhiệm, thái độ phục vụ, hiệu quả phối hợp và kết quả thực hiện nhiệm vụ của tổ, bộ phận và từng cá nhân có liên quan.
>
> **Hồ sơ, minh chứng đối chiếu:** Kế hoạch hoạt động tổ; biên bản sinh hoạt; hồ sơ chuyên môn, hành chính, tài chính, tài sản, thiết bị, nuôi dưỡng; hồ sơ phân công nhiệm vụ; kết quả kiểm tra thực tế và các tài liệu liên quan.
>
> ## 3. Rà soát, lựa chọn nội dung và tập trung khắc phục hạn chế
>
> ### 3.1. Chủ động rà soát hạn chế năm học trước
>
> Căn cứ báo cáo tổng kết năm học 2025 - 2026, kết quả kiểm tra nội bộ, kết quả kiểm tra của cơ quan quản lý cấp trên và tình hình thực hiện nhiệm vụ của các tổ chuyên môn, bộ phận, nhà trường tổ chức rà soát, đánh giá toàn diện những ưu điểm, hạn chế, tồn tại và nguyên nhân trong công tác quản lý, chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Việc rà soát tập trung vào các lĩnh vực: công tác chỉ đạo, điều hành; thực hiện chương trình và quy chế chuyên môn; quản lý, sử dụng đội ngũ; quản lý tài chính, tài sản; công tác bán trú, vệ sinh an toàn thực phẩm; an toàn trường học; chuyển đổi số, cập nhật dữ liệu ngành và các nhiệm vụ khác có liên quan.
>
> Đối với từng hạn chế, tồn tại được xác định qua rà soát, cần làm rõ nội dung chưa thực hiện hoặc thực hiện chưa đạt yêu cầu, nguyên nhân, trách nhiệm của bộ phận, cá nhân có liên quan và kết quả khắc phục đến thời điểm xây dựng kế hoạch.
>
> Trên cơ sở kết quả rà soát, lựa chọn những nội dung có nguy cơ phát sinh sai sót, những nhiệm vụ thực hiện chưa hiệu quả hoặc có ảnh hưởng trực tiếp đến chất lượng chăm sóc, nuôi dưỡng, giáo dục và an toàn của trẻ để đưa vào kế hoạch kiểm tra trọng tâm năm học 2026 - 2027.
>
> Ưu tiên kiểm tra việc thực hiện quy chế chuyên môn, tổ chức hoạt động chăm sóc, giáo dục trẻ; công tác quản lý các khoản thu, chi; công tác nuôi dưỡng, bán trú, an toàn thực phẩm; phòng, chống tai nạn thương tích; quản lý tài sản và cập nhật, quản trị cơ sở dữ liệu ngành.
>
> Việc xác định nội dung, đối tượng, thời gian và hình thức kiểm tra phải phù hợp với điều kiện thực tế, có trọng tâm, trọng điểm; tránh kiểm tra dàn trải, trùng lặp hoặc làm ảnh hưởng đến hoạt động bình thường của nhà trường.
>
> ### 3.2. Xử lý dứt điểm sau kiểm tra
>
> Tổ chức thực hiện nghiêm túc quy trình kiểm tra nội bộ theo hướng dẫn của Sở Giáo dục và Đào tạo; bảo đảm mỗi cuộc kiểm tra được thực hiện đúng nội dung, đối tượng, thời gian, thẩm quyền và có đầy đủ hồ sơ, minh chứng.
>
> Sau mỗi cuộc kiểm tra, đoàn hoặc tổ kiểm tra phải lập Biên bản kiểm tra (Mẫu số 04), Báo cáo kết quả kiểm tra (Mẫu số 05) và tham mưu Hiệu trưởng ban hành Thông báo kết quả kiểm tra (Mẫu số 06) gửi đến đối tượng được kiểm tra và các tổ chức, cá nhân có liên quan theo quy định.
>
> Nội dung đánh giá, kết luận kiểm tra phải chính xác, khách quan, dựa trên hồ sơ, tài liệu, minh chứng và kết quả xác minh thực tế; xác định rõ những ưu điểm, kết quả đạt được, hạn chế, thiếu sót, nguyên nhân và trách nhiệm của từng tập thể, cá nhân liên quan.
>
> Đối với những hạn chế, thiếu sót được phát hiện, Hiệu trưởng chỉ đạo xác định cụ thể nội dung cần khắc phục, biện pháp thực hiện, người hoặc bộ phận chịu trách nhiệm và thời hạn hoàn thành; bảo đảm việc khắc phục có kết quả thực chất, không mang tính hình thức.
>
> Giao Ban kiểm tra nội bộ và các cá nhân, bộ phận được phân công theo dõi, đôn đốc, kiểm tra việc thực hiện các kiến nghị sau kiểm tra; yêu cầu đối tượng được kiểm tra báo cáo kết quả, cung cấp minh chứng khắc phục theo thời hạn quy định.
>
> Đối với những hạn chế có nguy cơ ảnh hưởng đến sức khỏe, tính mạng, sự an toàn của trẻ, chất lượng chăm sóc, giáo dục, tài chính, tài sản hoặc uy tín nhà trường, phải kịp thời chỉ đạo xử lý, khắc phục dứt điểm theo thẩm quyền; trường hợp vượt thẩm quyền phải báo cáo cơ quan quản lý cấp trên để được hướng dẫn, giải quyết.
>
> Định kỳ trong các cuộc họp giao ban, sinh hoạt chuyên môn và hội nghị của nhà trường, thông tin kết quả kiểm tra, tiến độ và kết quả khắc phục hạn chế trong phạm vi phù hợp; kịp thời biểu dương, nhân rộng những cách làm hiệu quả, đồng thời nhắc nhở, chấn chỉnh những tập thể, cá nhân thực hiện chưa tốt.
>
> Kết quả kiểm tra và việc thực hiện các kiến nghị sau kiểm tra được sử dụng làm cơ sở phục vụ công tác đánh giá kết quả thực hiện nhiệm vụ, thi đua, bồi dưỡng đội ngũ và điều chỉnh các biện pháp quản lý theo quy định, góp phần nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ và hiệu quả hoạt động của nhà trường.

## ✅ Nhận xét và đề xuất sử dụng

Bản này chi tiết hơn bản gần nhất và vẫn giữ đúng cấu trúc theo UBND phường: **5 lĩnh vực kiểm tra nhiệm vụ Thủ trưởng; 3 nhóm kiểm tra giáo viên, nhân viên, bộ phận; 2 nội dung rà soát và xử lý sau kiểm tra.** Các nội dung của Công văn 1134 được lồng ghép vào đúng các nhóm trọng tâm, tránh mở rộng thành quá nhiều mục riêng gây dàn trải.

Phần **hồ sơ, minh chứng đối chiếu** được bổ sung để hỗ trợ xây dựng kế hoạch từng cuộc kiểm tra và biên bản kiểm tra. Đây là nguồn minh chứng cần lựa chọn theo từng nội dung, không phải yêu cầu nhà trường hoặc giáo viên phải tạo thêm hồ sơ ngoài quy định.

Tôi đề xuất sử dụng bản này làm Mục II của Kế hoạch chính thức. Riêng Mục IV – Danh mục các cuộc kiểm tra – cần bố trí các cuộc kiểm tra tương ứng, bảo đảm những nội dung đã xác định tại Mục II đều có phương án thực hiện, đặc biệt là các vấn đề còn hạn chế từ năm học 2025–2026.

---

USER

dựa vào quyết định này bạn tiếp tục thực hiện mục IV danh mục các cuộc kiểm tra bám sát nội dung bạn vừa làm nhé'

---

ASSISTANT

Căn cứ **Quyết định số 82/QĐ-MNAB ngày 27/10/2026 về thành lập Ban kiểm tra nội bộ Trường Mầm non An Bình**, tôi xây dựng Mục IV theo đúng các nội dung đã hoàn thiện tại Mục II, đồng thời gắn với thành phần Ban kiểm tra, thời gian và điều kiện thực tế của nhà trường.

Tôi đề xuất **10 cuộc kiểm tra trong năm học 2026–2027**. Cách bố trí này bảo đảm kiểm tra các lĩnh vực quản lý trọng tâm, hoạt động của giáo viên, nhân viên, các tổ chuyên môn và việc khắc phục hạn chế sau kiểm tra; tránh dàn trải hoặc kiểm tra trùng lặp.

> **writing · document**
>
> # IV. DANH MỤC CÁC CUỘC KIỂM TRA
>
> Căn cứ nội dung trọng tâm tại Mục II của Kế hoạch, kết quả rà soát những hạn chế, tồn tại của năm học 2025 - 2026 và điều kiện thực tế của nhà trường, Trường Mầm non An Bình dự kiến tổ chức 10 cuộc kiểm tra nội bộ trong năm học 2026 - 2027, cụ thể như sau:
>
> | TT | Nội dung kiểm tra | Đối tượng kiểm tra | Thời gian tiến hành | Hình thức kiểm tra | Người phụ trách | Ghi chú |
> |---|---|---|---|---|---|---|
> | 1 | **Kiểm tra công tác quản lý, chỉ đạo, điều hành nhà trường:** Việc xây dựng, ban hành và tổ chức thực hiện chiến lược phát triển, kế hoạch năm học, kế hoạch giáo dục; các quy chế, quy định nội bộ; thực hiện dân chủ, công khai, phân công nhiệm vụ và rà soát hạn chế năm học trước. | Ban Giám hiệu; Tổ Văn phòng và các bộ phận tham mưu có liên quan. | Tháng 11/2026 | Kiểm tra hồ sơ, đối chiếu kế hoạch với kết quả thực hiện, trao đổi, xác minh. | Bà Huỳnh Duyên – Phó Trưởng ban, đầu mối KTNB. | Mục II.1.1 và 3.1. Rà soát trách nhiệm quản lý trên cơ sở minh chứng khách quan. |
> | 2 | **Kiểm tra hoạt động sư phạm giáo viên đợt I:** Việc chấp hành đạo đức nhà giáo, quy chế chuyên môn; xây dựng và thực hiện kế hoạch giáo dục; tổ chức hoạt động chăm sóc, nuôi dưỡng, giáo dục; quản lý nhóm lớp, bảo đảm an toàn và đánh giá sự phát triển của trẻ. | Giáo viên các nhóm 25–36 tháng và khối Mầm theo danh sách được lựa chọn. | Tháng 11/2026 | Kiểm tra hồ sơ, dự giờ, quan sát hoạt động thực tế, trao đổi với giáo viên. | Bà Hồ Thanh Trúc – Phó Trưởng ban; phối hợp bà Cao Thị Ngọc Nga, bà Trần Thị Huỳnh Như. | Mục II.2.1. Lựa chọn giáo viên cụ thể trong quyết định kiểm tra. |
> | 3 | **Kiểm tra công tác quản lý tài chính, tài sản:** Quản lý thu, chi ngân sách và các khoản thu dịch vụ; thực hiện chế độ tài chính, chính sách; quản lý nguồn tài trợ, hỗ trợ và kinh phí hoạt động của Ban đại diện cha mẹ trẻ theo quy định; mua sắm, kiểm kê, sử dụng tài sản và công khai tài chính. | Ban Giám hiệu; kế toán, thủ quỹ và các bộ phận liên quan. | Tháng 12/2026 | Kiểm tra hồ sơ, chứng từ, sổ kế toán; đối chiếu số liệu và kiểm tra tài sản thực tế. | Bà Ngọc Phượng – Phó Trưởng ban; các thành viên có chuyên môn phù hợp do Hiệu trưởng phân công. | Mục II.1.2. Bảo đảm người kiểm tra không trực tiếp đánh giá nghiệp vụ do mình thực hiện. |
> | 4 | **Kiểm tra công tác nuôi dưỡng, bán trú và an toàn thực phẩm:** Việc thực hiện thực đơn, khẩu phần dinh dưỡng; giao nhận, bảo quản, chế biến, chia ăn; kiểm thực, lưu mẫu thức ăn; vệ sinh bếp ăn, tổ chức bữa ăn, giấc ngủ, theo dõi sức khỏe và tình trạng dinh dưỡng của trẻ. | Bộ phận cấp dưỡng, y tế; giáo viên và các bộ phận tham gia tổ chức bán trú. | Tháng 12/2026 | Kiểm tra hồ sơ nuôi dưỡng, quan sát trực tiếp tại bếp ăn và các nhóm lớp; đối chiếu quy trình thực hiện. | Bà Hồ Thanh Trúc – Phó Trưởng ban; thành viên do Hiệu trưởng phân công. | Mục II.1.5 và 2.2. Ưu tiên phát hiện, xử lý nguy cơ mất an toàn thực phẩm. |
> | 5 | **Kiểm tra công tác chuyển đổi số, dữ liệu ngành:** Việc thực hiện kế hoạch chuyển đổi số; quản lý văn bản điện tử, chữ ký số; sử dụng phần mềm quản lý; cập nhật dữ liệu ngành theo nguyên tắc “Đúng - Đủ - Sạch - Sống”; thực hiện chế độ báo cáo và bảo đảm an toàn thông tin. | Ban Giám hiệu; văn thư, nhân sự phụ trách công nghệ thông tin, cơ sở dữ liệu ngành và các bộ phận liên quan. | Đầu tháng 01/2027 | Kiểm tra dữ liệu trên phần mềm, đối chiếu với hồ sơ thực tế, kiểm tra báo cáo thống kê. | Bà Huỳnh Duyên – Phó Trưởng ban, đầu mối KTNB. | Mục II.1.4 và 2.2. Hoàn thành để phục vụ báo cáo sơ kết học kỳ I. |
> | 6 | **Kiểm tra công tác quản lý đội ngũ và hoạt động của các tổ chuyên môn:** Việc phân công, sử dụng, đánh giá, bồi dưỡng đội ngũ; thực hiện quy chế chuyên môn; xây dựng kế hoạch tổ, sinh hoạt chuyên môn, triển khai chuyên đề, dự giờ, bồi dưỡng giáo viên và quản lý chất lượng giáo dục. | Ban Giám hiệu; các tổ chuyên môn nhóm 25–36 tháng, Mầm, Chồi, Lá và giáo viên liên quan. | Tháng 02/2027 | Kiểm tra hồ sơ quản lý, hồ sơ chuyên môn; dự sinh hoạt tổ, trao đổi và đối chiếu kết quả thực hiện. | Bà Ngọc Phượng – Phó Trưởng ban; phối hợp các thành viên Ban KTNB theo phân công. | Mục II.1.3 và 2.3. Phân công chéo, không để tổ trưởng tự kiểm tra hoạt động tổ mình. |
> | 7 | **Kiểm tra hoạt động sư phạm giáo viên đợt II:** Việc thực hiện chương trình, kế hoạch giáo dục; đổi mới phương pháp, tổ chức môi trường giáo dục lấy trẻ làm trung tâm; năng lực sư phạm, quản lý nhóm lớp; theo dõi, đánh giá trẻ, ứng dụng công nghệ thông tin và phối hợp với cha mẹ trẻ. | Giáo viên các khối Chồi, Lá và những giáo viên khác được lựa chọn theo kế hoạch. | Tháng 03/2027 | Kiểm tra hồ sơ chuyên môn, dự giờ, quan sát hoạt động chăm sóc, giáo dục trẻ và trao đổi trực tiếp. | Bà Hồ Thanh Trúc – Phó Trưởng ban; phối hợp bà Nguyễn Thị Ngọc Phí, bà Nguyễn Thị Nhàn. | Mục II.2.1. Phân định đối tượng, nội dung để không trùng lặp đợt I. |
> | 8 | **Kiểm tra công tác an toàn trường học:** Phòng cháy, chữa cháy; an ninh, trật tự; phòng, chống tai nạn thương tích, bạo lực, xâm hại trẻ; quy trình đón, trả trẻ; công tác y tế, vệ sinh môi trường; an toàn cơ sở vật chất, đồ dùng, đồ chơi và phương án xử lý tình huống khẩn cấp. | Các nhóm, lớp; bộ phận y tế, bảo vệ và các cá nhân, bộ phận liên quan. | Tháng 03/2027 | Kiểm tra hồ sơ, quan sát thực tế cơ sở vật chất, môi trường giáo dục và việc thực hiện các quy trình an toàn. | Bà Ngọc Phượng – Phó Trưởng ban; thành viên do Hiệu trưởng phân công. | Mục II.1.5. Tập trung an toàn trường học, không lặp lại toàn bộ nội dung bán trú đã kiểm tra. |
> | 9 | **Kiểm tra hoạt động của Tổ Văn phòng và nhân viên:** Việc xây dựng kế hoạch, thực hiện chức trách; công tác văn thư, hành chính, quản lý hồ sơ, con dấu; quản lý, sử dụng thiết bị, đồ dùng, đồ chơi, sách, học liệu; công tác bảo vệ, y tế và phối hợp phục vụ hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ. | Tổ Văn phòng; nhân viên văn thư, y tế, bảo vệ, người phụ trách thiết bị và các cá nhân có liên quan. | Tháng 04/2027 | Kiểm tra kế hoạch, hồ sơ nghiệp vụ, sổ theo dõi công việc; kiểm tra thực tế và trao đổi với nhân viên. | Bà Huỳnh Duyên – Phó Trưởng ban; phối hợp các thành viên phù hợp. | Mục II.2.2 và 2.3. Tổ trưởng Văn phòng cung cấp hồ sơ, giải trình; không tự kiểm tra công việc của mình. |
> | 10 | **Kiểm tra việc thực hiện kiến nghị sau kiểm tra và kết quả khắc phục hạn chế:** Rà soát việc thực hiện các thông báo kết quả kiểm tra; xác định nội dung đã khắc phục, chưa khắc phục, nguyên nhân và trách nhiệm; kiểm tra hồ sơ minh chứng, kết quả cải tiến chất lượng, tổng hợp công tác kiểm tra nội bộ năm học. | Các tổ chuyên môn, Tổ Văn phòng, bộ phận, cá nhân có kiến nghị sau kiểm tra; bộ phận tổng hợp hồ sơ. | Cuối tháng 04 đến đầu tháng 05/2027, hoàn thành trước 10/05/2027. | Kiểm tra lại hồ sơ, minh chứng; đối chiếu kết quả thực tế, tổng hợp báo cáo. | Bà Huỳnh Hồng Loan – Trưởng ban chỉ đạo; bà Huỳnh Duyên – đầu mối KTNB tổng hợp, phối hợp các thành viên. | Mục II.3.2. Phục vụ báo cáo tổng kết trước ngày 13/05/2027. |
>
> ### Yêu cầu thực hiện danh mục kiểm tra
>
> Căn cứ Danh mục các cuộc kiểm tra nêu trên, Hiệu trưởng ban hành quyết định kiểm tra theo từng cuộc hoặc từng đợt, xác định cụ thể nội dung, đối tượng, thời kỳ, thời hạn kiểm tra và thành phần đoàn, tổ kiểm tra phù hợp với tính chất, yêu cầu của từng nội dung.
>
> Các Phó Trưởng ban, thành viên Ban kiểm tra nội bộ thực hiện nhiệm vụ theo phân công của Hiệu trưởng, bảo đảm đúng phạm vi, trách nhiệm, năng lực chuyên môn; không bố trí thành viên trực tiếp kiểm tra, đánh giá những nội dung thuộc trách nhiệm thực hiện của chính mình.
>
> Mỗi cuộc kiểm tra phải thực hiện đầy đủ các bước chuẩn bị, tiến hành và kết thúc kiểm tra; lập biên bản, báo cáo kết quả, ban hành thông báo kết quả kiểm tra theo các biểu mẫu hướng dẫn tại Công văn số 1134/SGDĐT-TCCB. Kết quả kiểm tra phải gắn với việc tư vấn, chấn chỉnh, xác định trách nhiệm và theo dõi thực hiện kiến nghị sau kiểm tra.
>
> Ngoài các cuộc kiểm tra theo kế hoạch, Hiệu trưởng chỉ đạo kiểm tra đột xuất khi có yêu cầu của cấp có thẩm quyền hoặc phát sinh vụ việc cần kiểm tra thuộc phạm vi quản lý, nhất là các vấn đề liên quan đến an toàn của trẻ, vệ sinh an toàn thực phẩm, quản lý tài chính, tài sản và việc chấp hành quy định chuyên môn.
>
> Trong quá trình tổ chức thực hiện, căn cứ tình hình thực tế, tiến độ nhiệm vụ năm học và kết quả các cuộc kiểm tra, Hiệu trưởng xem xét điều chỉnh, bổ sung danh mục bằng văn bản theo thẩm quyền; bảo đảm hoạt động kiểm tra có trọng tâm, trọng điểm, không chồng chéo, không ảnh hưởng đến hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Kết quả thực hiện danh mục kiểm tra là căn cứ để đánh giá công tác quản lý, việc thực hiện nhiệm vụ của các bộ phận, cá nhân; đồng thời phục vụ sơ kết, tổng kết công tác kiểm tra nội bộ và xây dựng các giải pháp nâng cao chất lượng hoạt động của nhà trường.

## 🔍 Một số lưu ý khi hoàn thiện hồ sơ

**Về phân công nhân sự:** Tôi đã sử dụng các chức danh và thành viên trong Quyết định số 82/QĐ-MNAB, đồng thời bố trí các tổ trưởng chuyên môn tham gia hỗ trợ kiểm tra chéo. Tuy nhiên, danh sách người phụ trách trong bảng là **phương án dự kiến**; cần đối chiếu với phân công nhiệm vụ thực tế của từng Phó Hiệu trưởng trước khi chốt chính thức.

**Về Quyết định số 82/QĐ-MNAB:** Tôi nhận thấy văn bản đính kèm có một số điểm cần kiểm tra, chỉnh lý:

- Điều 1 có dòng Phó Hiệu trưởng chưa điền tên, số thứ tự 5 bị lặp và họ tên bà Huỳnh Duyên bị lặp cụm “Nguyễn Thị”.
- Phần căn cứ dẫn Quyết định số 75/QĐ-MNAB ngày 01/10/2026, nhưng Điều 2 lại dẫn Quyết định số 81/QĐ-MNAB ngày 27/10/2026. Cần xác định chính xác quyết định ban hành Kế hoạch đang có hiệu lực.
- Cụm từ “Cùng Ban Thanh tra nhân dân” cần được làm rõ vai trò và thành phần; không mặc nhiên coi toàn bộ Ban Thanh tra nhân dân là thành viên Ban kiểm tra nội bộ nếu chưa được xác định trong quyết định.

## ✅ Kết luận

Danh mục đề xuất đã liên kết với các phần của Mục II, gồm 5 lĩnh vực quản lý, hoạt động của giáo viên, nhân viên, các tổ/bộ phận và công tác khắc phục sau kiểm tra.

Điểm tôi đặc biệt đề xuất nhà trường duy trì là **phân tách kiểm tra hoạt động sư phạm giáo viên thành 2 đợt, kiểm tra riêng công tác bán trú và an toàn trường học, đồng thời có cuộc hậu kiểm cuối năm**. Cách tổ chức này giúp kiểm tra đúng trọng tâm của UBND phường, bảo đảm an toàn cho trẻ và có đủ thời gian theo dõi việc khắc phục những hạn chế đã phát hiện.

---

USER

bạn điều chỉnh lại nội dung IV theo nội dung góp ý của hi65u trưởng

---

ASSISTANT

Tôi sẽ giữ nguyên 10 cuộc kiểm tra và điều chỉnh cột “Người phụ trách” theo góp ý của Hiệu trưởng: Ban Thanh tra nhân dân tham gia đối với nội dung thuộc trách nhiệm Hiệu trưởng; bà Ngọc Phượng phụ trách kiểm tra Tổ Văn phòng; các nội dung do Phó Hiệu trưởng phụ trách sẽ bố trí Phó Hiệu trưởng khác kiểm tra chéo. Tôi cũng sẽ rà soát cách ghi nhiệm vụ của Ban Thanh tra nhân dân để phù hợp thẩm quyền.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 Điều chỉnh Mục IV. Danh mục các cuộc kiểm tra nội bộ năm học 2026–2027

Căn cứ góp ý của Hiệu trưởng và Quyết định số 82/QĐ-MNAB ngày 27/10/2026 về thành lập Ban kiểm tra nội bộ, tôi điều chỉnh lại **Mục IV – Danh mục các cuộc kiểm tra** của Trường Mầm non An Bình theo ba nguyên tắc:

1. **Ban Thanh tra nhân dân:** Được phân công kiểm tra, giám sát các nội dung thuộc trách nhiệm quản lý, chỉ đạo của Hiệu trưởng trong phạm vi chức năng, nhiệm vụ, đặc biệt là thực hiện dân chủ, công khai, nghị quyết hội nghị viên chức, người lao động và các quy định nội bộ.
2. **Bà Ngọc Phượng – Phó Hiệu trưởng:** Phụ trách kiểm tra hoạt động của Tổ Văn phòng theo ý kiến chỉ đạo của Hiệu trưởng.
3. **Các Phó Hiệu trưởng còn lại:** Thực hiện kiểm tra chéo. Nội dung thuộc lĩnh vực Phó Hiệu trưởng nào trực tiếp quản lý thì bố trí Phó Hiệu trưởng khác kiểm tra, nhằm bảo đảm tính khách quan.

Về thẩm quyền, Ban Thanh tra nhân dân có nhiệm vụ kiểm tra, giám sát theo Điều 61 Luật Thực hiện dân chủ ở cơ sở; kết quả kiểm tra, giám sát của Ban không thay thế kết luận kiểm tra nội bộ thuộc trách nhiệm của người có thẩm quyền. Vì vậy, phần phân công dưới đây phân biệt rõ việc kiểm tra nội bộ với hoạt động giám sát của Ban Thanh tra nhân dân. [Văn bản hợp nhất 87/VBHN\-VPQH 2025 Luật thực hiện Dân chủ ở cơ sở](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Van-ban-hop-nhat-87-VBHN-VPQH-2025-Luat-thuc-hien-dan-chu-o-co-so-670747.aspx>); [Hướng dẫn tổ chức và hoạt động của Ban Thanh tra nhân dân ở cơ quan, đơn vị](<https://xaydungchinhsach.chinhphu.vn/huong-dan-to-chuc-va-hoat-dong-cua-ban-thanh-tra-nhan-dan-o-co-quan-don-vi-119230820163622483.htm>)

Tôi giữ nguyên **10 cuộc kiểm tra** và nội dung trọng tâm đã xây dựng, chỉ điều chỉnh phân công, đối tượng phối hợp và một số diễn đạt để bảo đảm phù hợp ý kiến của Hiệu trưởng.

> **writing · document**
>
> # IV. DANH MỤC CÁC CUỘC KIỂM TRA
>
> Căn cứ nội dung trọng tâm tại Mục II của Kế hoạch và Quyết định thành lập Ban kiểm tra nội bộ năm học 2026 - 2027, nhà trường dự kiến tổ chức 10 cuộc kiểm tra, bảo đảm phù hợp với nhiệm vụ năm học, điều kiện thực tế và nguyên tắc phân công kiểm tra chéo giữa các Phó Hiệu trưởng; phát huy vai trò kiểm tra, giám sát của Ban Thanh tra nhân dân theo chức năng, nhiệm vụ được giao.
>
> | TT | Nội dung kiểm tra | Đối tượng kiểm tra | Thời gian tiến hành | Hình thức kiểm tra | Người phụ trách | Ghi chú |
> |---|---|---|---|---|---|---|
> | 1 | **Kiểm tra công tác quản lý, chỉ đạo, điều hành của Hiệu trưởng:** Việc xây dựng, ban hành và thực hiện chiến lược phát triển, kế hoạch năm học, kế hoạch giáo dục; Quy chế tổ chức và hoạt động, Quy chế dân chủ ở cơ sở; thực hiện công khai, phân công nhiệm vụ, nghị quyết hội nghị viên chức, người lao động và khắc phục hạn chế năm học trước. | Hiệu trưởng; Ban Giám hiệu và các bộ phận tham mưu, thực hiện có liên quan. | 11/2026 | Kiểm tra, giám sát việc thực hiện nghị quyết, quy chế, công khai; đối chiếu hồ sơ, minh chứng và kết quả thực hiện thực tế. | **Ban Thanh tra nhân dân** phụ trách kiểm tra, giám sát theo chức năng; bà Nguyễn Thị Huỳnh Duyên phối hợp, tổng hợp hồ sơ. | Mục II.1.1 và 3.1. Tập trung nội dung thuộc trách nhiệm Hiệu trưởng; thực hiện đúng phạm vi, thẩm quyền của Ban Thanh tra nhân dân. |
> | 2 | **Kiểm tra hoạt động sư phạm giáo viên đợt I:** Việc chấp hành đạo đức nhà giáo, quy chế chuyên môn; xây dựng, thực hiện kế hoạch giáo dục; tổ chức hoạt động chăm sóc, nuôi dưỡng, giáo dục; quản lý nhóm lớp, bảo đảm an toàn, theo dõi và đánh giá sự phát triển của trẻ. | Giáo viên nhóm 25–36 tháng và khối Mầm được lựa chọn kiểm tra. | 11/2026 | Kiểm tra hồ sơ chuyên môn, dự giờ, quan sát hoạt động thực tế và trao đổi với giáo viên. | **Bà Ngọc Phượng** – Phó Trưởng ban; phối hợp các thành viên được phân công kiểm tra chéo. | Mục II.2.1. Bố trí thành viên không trực tiếp phụ trách nhóm, lớp được kiểm tra. |
> | 3 | **Kiểm tra công tác quản lý tài chính và tài sản:** Việc quản lý thu, chi ngân sách, các khoản thu dịch vụ; quản lý, sử dụng nguồn tài trợ, hỗ trợ và kinh phí hoạt động của Ban đại diện cha mẹ trẻ theo quy định; thực hiện chế độ, chính sách; công khai tài chính; mua sắm, kiểm kê, quản lý, sử dụng tài sản, trang thiết bị. | Hiệu trưởng, bộ phận kế toán, thủ quỹ và các cá nhân, bộ phận liên quan. | 12/2026 | Kiểm tra hồ sơ, chứng từ, sổ sách kế toán; đối chiếu số liệu, kiểm tra tài sản và việc thực hiện thực tế. | **Bà Hồ Thanh Trúc** – Phó Trưởng ban phụ trách kiểm tra nghiệp vụ; Ban Thanh tra nhân dân giám sát các nội dung thuộc chức năng, nhiệm vụ. | Mục II.1.2. Ban Thanh tra nhân dân tập trung giám sát việc công khai, thực hiện dân chủ và trách nhiệm quản lý của Hiệu trưởng. |
> | 4 | **Kiểm tra công tác nuôi dưỡng, bán trú và an toàn thực phẩm:** Việc xây dựng thực đơn, khẩu phần dinh dưỡng; giao nhận, bảo quản, chế biến và chia ăn; thực hiện kiểm thực, lưu mẫu thức ăn; vệ sinh bếp ăn, dụng cụ; tổ chức bữa ăn, giấc ngủ, theo dõi sức khỏe và tình trạng dinh dưỡng của trẻ. | Bộ phận cấp dưỡng, y tế, giáo viên và các cá nhân, bộ phận liên quan đến công tác bán trú. | 12/2026 | Kiểm tra hồ sơ nuôi dưỡng; quan sát trực tiếp hoạt động bếp ăn, các nhóm lớp; đối chiếu quy trình và kết quả thực hiện. | **Bà Nguyễn Thị Huỳnh Duyên** – Phó Trưởng ban; phối hợp các thành viên kiểm tra chéo theo phân công. | Mục II.1.5 và 2.2. Không bố trí người trực tiếp quản lý nội dung làm người đánh giá chính. |
> | 5 | **Kiểm tra công tác chuyển đổi số và quản lý dữ liệu ngành:** Việc triển khai kế hoạch chuyển đổi số; quản lý văn bản điện tử, chữ ký số, phần mềm quản lý; cập nhật dữ liệu ngành theo nguyên tắc “Đúng - Đủ - Sạch - Sống”; thực hiện chế độ thống kê, báo cáo và bảo đảm an toàn, bảo mật thông tin. | Ban Giám hiệu, người phụ trách công nghệ thông tin, dữ liệu ngành, văn thư và các bộ phận có liên quan. | Đầu 01/2027 | Kiểm tra dữ liệu trên phần mềm, hồ sơ điện tử; đối chiếu với hồ sơ gốc, số liệu thực tế và báo cáo thống kê. | **Bà Hồ Thanh Trúc** – Phó Trưởng ban; phối hợp thành viên có chuyên môn phù hợp. | Mục II.1.4. Thực hiện kiểm tra chéo, hoàn thành để phục vụ sơ kết học kỳ I. |
> | 6 | **Kiểm tra công tác quản lý đội ngũ và hoạt động của các tổ chuyên môn:** Việc phân công, sử dụng, đánh giá, bồi dưỡng giáo viên, nhân viên; thực hiện quy chế chuyên môn; xây dựng kế hoạch tổ, nền nếp sinh hoạt chuyên môn, triển khai chuyên đề, dự giờ, bồi dưỡng giáo viên và kết quả thực hiện nhiệm vụ. | Ban Giám hiệu; các tổ chuyên môn nhóm 25–36 tháng, Mầm, Chồi, Lá và giáo viên liên quan. | 02/2027 | Kiểm tra hồ sơ quản lý, hồ sơ chuyên môn; dự sinh hoạt tổ, trao đổi, xác minh và đối chiếu kết quả thực hiện. | **Bà Nguyễn Thị Huỳnh Duyên** – Phó Trưởng ban; phối hợp các thành viên Ban KTNB theo nguyên tắc kiểm tra chéo. | Mục II.1.3 và 2.3. Không giao tổ trưởng tự kiểm tra hoạt động của tổ mình. |
> | 7 | **Kiểm tra hoạt động sư phạm giáo viên đợt II:** Việc thực hiện chương trình, kế hoạch giáo dục; đổi mới phương pháp, xây dựng môi trường giáo dục lấy trẻ làm trung tâm; năng lực sư phạm, quản lý nhóm lớp; theo dõi, đánh giá trẻ; ứng dụng công nghệ thông tin và phối hợp với cha mẹ trẻ. | Giáo viên khối Chồi, Lá và giáo viên khác được lựa chọn theo kế hoạch. | 03/2027 | Dự giờ, quan sát các hoạt động chăm sóc, giáo dục; kiểm tra hồ sơ chuyên môn và trao đổi trực tiếp. | **Bà Ngọc Phượng** – Phó Trưởng ban; phối hợp các tổ trưởng chuyên môn được phân công kiểm tra chéo. | Mục II.2.1. Không trùng lặp đối tượng và nội dung đã kiểm tra ở đợt I. |
> | 8 | **Kiểm tra công tác an toàn trường học:** Việc thực hiện quy định về phòng cháy, chữa cháy; an ninh, trật tự; phòng, chống tai nạn thương tích, bạo lực, xâm hại trẻ; quy trình đón, trả trẻ; công tác y tế, vệ sinh môi trường; an toàn cơ sở vật chất, đồ dùng, đồ chơi và phương án xử lý tình huống khẩn cấp. | Các nhóm lớp; bộ phận y tế, bảo vệ và cá nhân, bộ phận có liên quan. | 03/2027 | Kiểm tra hồ sơ, phương án bảo đảm an toàn; quan sát thực tế môi trường, cơ sở vật chất và việc thực hiện quy trình. | **Bà Hồ Thanh Trúc** – Phó Trưởng ban; phối hợp thành viên Ban KTNB theo phân công. | Mục II.1.5. Tập trung an toàn trường học, không kiểm tra trùng lặp toàn bộ nội dung bán trú. |
> | 9 | **Kiểm tra hoạt động của Tổ Văn phòng và việc thực hiện nhiệm vụ của nhân viên:** Xây dựng kế hoạch, chấp hành nội quy, thực hiện chức trách; công tác văn thư, hành chính, quản lý hồ sơ, con dấu; quản lý, sử dụng thiết bị, đồ dùng, đồ chơi, sách, học liệu; thực hiện nhiệm vụ và phối hợp của nhân viên y tế, bảo vệ, cấp dưỡng và các vị trí liên quan. | Tổ Văn phòng; tổ trưởng, nhân viên văn thư, kế toán, thủ quỹ, y tế, bảo vệ, cấp dưỡng và các nhân viên có liên quan. | 04/2027 | Kiểm tra kế hoạch, hồ sơ nghiệp vụ, sổ theo dõi công việc; kiểm tra thực tế và trao đổi trực tiếp với nhân viên. | **Bà Ngọc Phượng** – Phó Trưởng ban, trực tiếp phụ trách kiểm tra hoạt động Tổ Văn phòng. | Mục II.2.2 và 2.3. Phần trách nhiệm quản lý, chỉ đạo của bà Phượng được bố trí Phó Hiệu trưởng khác kiểm tra chéo. |
> | 10 | **Kiểm tra việc thực hiện kiến nghị sau kiểm tra và kết quả khắc phục hạn chế:** Rà soát việc thực hiện các thông báo kết quả kiểm tra; đối chiếu nội dung, tiến độ, minh chứng khắc phục; xác định hạn chế chưa khắc phục, nguyên nhân, trách nhiệm và kết quả cải tiến chất lượng, phục vụ tổng kết công tác kiểm tra nội bộ năm học. | Các tổ chuyên môn, Tổ Văn phòng, bộ phận, cá nhân có kiến nghị sau kiểm tra; các cá nhân phụ trách theo dõi, tổng hợp. | Cuối 04/2027 đến trước 10/05/2027 | Kiểm tra lại hồ sơ, minh chứng; đối chiếu kết quả thực tế, tổng hợp và đánh giá việc thực hiện kiến nghị. | **Bà Nguyễn Thị Huỳnh Duyên** – đầu mối KTNB, phụ trách tổng hợp; các Phó Hiệu trưởng kiểm tra chéo theo lĩnh vực; Ban Thanh tra nhân dân giám sát phần thuộc trách nhiệm Hiệu trưởng. | Mục II.3.2. Hoàn thành để phục vụ báo cáo tổng kết trước ngày 13/05/2027. |
>
> ### Yêu cầu về phân công và tổ chức kiểm tra
>
> **1. Đối với Ban Thanh tra nhân dân**
>
> Ban Thanh tra nhân dân thực hiện nhiệm vụ kiểm tra, giám sát việc thực hiện nghị quyết hội nghị viên chức, người lao động, Quy chế dân chủ ở cơ sở, công khai và các nội dung thuộc trách nhiệm quản lý, chỉ đạo của Hiệu trưởng trong phạm vi chức năng, quyền hạn theo quy định.
>
> Trưởng Ban Thanh tra nhân dân phân công thành viên thực hiện nhiệm vụ phù hợp với nội dung kiểm tra, giám sát; phối hợp cung cấp thông tin, trao đổi kết quả và kiến nghị khắc phục những hạn chế, thiếu sót phát hiện qua kiểm tra, giám sát.
>
> Đối với nội dung thuộc trách nhiệm quản lý, điều hành của Hiệu trưởng nhưng ngoài phạm vi kiểm tra, giám sát của Ban Thanh tra nhân dân, việc đánh giá và xử lý thực hiện theo đúng thẩm quyền; trường hợp cần thiết báo cáo cơ quan quản lý cấp trên xem xét, chỉ đạo.
>
> **2. Đối với các Phó Hiệu trưởng**
>
> Thực hiện nguyên tắc phân công kiểm tra chéo giữa các Phó Hiệu trưởng nhằm bảo đảm tính khách quan, trung thực trong đánh giá kết quả thực hiện nhiệm vụ.
>
> Đối với nội dung thuộc lĩnh vực do một Phó Hiệu trưởng trực tiếp quản lý, chỉ đạo, Hiệu trưởng phân công Phó Hiệu trưởng khác phụ trách kiểm tra, đánh giá; Phó Hiệu trưởng phụ trách lĩnh vực có trách nhiệm cung cấp hồ sơ, báo cáo, giải trình và phối hợp thực hiện.
>
> Riêng hoạt động của Tổ Văn phòng, phân công bà Ngọc Phượng – Phó Hiệu trưởng phụ trách kiểm tra hoạt động của tổ và các nhân viên theo nội dung Kế hoạch. Đối với nội dung đánh giá trách nhiệm chỉ đạo, quản lý của bà Ngọc Phượng, phân công Phó Hiệu trưởng khác thực hiện kiểm tra chéo.
>
> **3. Đối với các thành viên Ban kiểm tra nội bộ**
>
> Các thành viên tham gia kiểm tra theo sự phân công cụ thể tại quyết định kiểm tra từng cuộc hoặc từng đợt; bảo đảm phù hợp năng lực chuyên môn, lĩnh vực công tác và yêu cầu của nội dung kiểm tra.
>
> Các tổ trưởng chuyên môn tham gia kiểm tra chéo giữa các tổ, nhóm, lớp; không trực tiếp kiểm tra, đánh giá hoạt động của tổ, nhóm, lớp do mình quản lý.
>
> Tổ trưởng Tổ Văn phòng và các nhân viên có trách nhiệm chuẩn bị hồ sơ, tài liệu, cung cấp thông tin, giải trình và phối hợp với tổ kiểm tra; không trực tiếp đánh giá những nội dung thuộc trách nhiệm thực hiện của chính mình.
>
> **4. Tổ chức thực hiện và xử lý sau kiểm tra**
>
> Căn cứ Danh mục các cuộc kiểm tra, Hiệu trưởng ban hành quyết định kiểm tra theo từng cuộc hoặc từng đợt, xác định rõ nội dung, đối tượng, thời kỳ, thời hạn, thành phần và người phụ trách kiểm tra.
>
> Mỗi cuộc kiểm tra phải thực hiện đầy đủ trình tự, thủ tục, hồ sơ theo hướng dẫn tại Công văn số 1134/SGDĐT-TCCB; lập Biên bản kiểm tra (Mẫu số 04), Báo cáo kết quả kiểm tra (Mẫu số 05), ban hành Thông báo kết quả kiểm tra (Mẫu số 06) và theo dõi việc thực hiện kiến nghị sau kiểm tra.
>
> Kết quả kiểm tra phải bảo đảm chính xác, khách quan, có minh chứng; nêu rõ ưu điểm, hạn chế, nguyên nhân, trách nhiệm và biện pháp khắc phục. Hiệu trưởng chỉ đạo thực hiện việc khắc phục, kiểm tra lại và xử lý hoặc kiến nghị xử lý những vấn đề phát sinh theo thẩm quyền.
>
> Trong quá trình triển khai, căn cứ tình hình thực tế và nhiệm vụ của từng thành viên, Hiệu trưởng xem xét điều chỉnh phân công bằng văn bản để bảo đảm nguyên tắc kiểm tra chéo, không chồng chéo nội dung và không ảnh hưởng đến hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.

## ⚠️ Những điểm cần kiểm tra trước khi Hiệu trưởng duyệt

**Thứ nhất, về Ban Thanh tra nhân dân:** Quyết định số 82/QĐ-MNAB có ghi “Cùng Ban Thanh tra nhân dân” nhưng chưa nêu tên Trưởng ban và các thành viên. Vì vậy, bảng phân công hiện ghi tên tập thể Ban Thanh tra nhân dân. Khi tổ chức kiểm tra, giám sát cần xác định rõ thành viên thực hiện, đồng thời phối hợp với chương trình, kế hoạch hoạt động của Ban.

**Thứ hai, về phân công các Phó Hiệu trưởng:** Tôi đã bố trí các bà Huỳnh Duyên, Hồ Thanh Trúc và Ngọc Phượng luân phiên kiểm tra, trong đó bà Ngọc Phượng được phân công rõ ở cuộc kiểm tra Tổ Văn phòng theo ý kiến của Hiệu trưởng. Tuy nhiên, hồ sơ hiện có chưa thể hiện đầy đủ lĩnh vực chuyên môn mà mỗi Phó Hiệu trưởng trực tiếp phụ trách. Do đó, **cần đối chiếu bảng phân công nhiệm vụ Ban Giám hiệu năm học 2026–2027** để xác nhận các cặp kiểm tra chéo trước khi ban hành chính thức.

**Thứ ba, về nội dung kiểm tra trách nhiệm Hiệu trưởng:** Ban Thanh tra nhân dân thực hiện đúng chức năng kiểm tra, giám sát của mình, không thay thế quyền kiểm tra, đánh giá của cơ quan quản lý cấp trên. Cách phân công này vừa tiếp thu góp ý của Hiệu trưởng, vừa bảo đảm phân định trách nhiệm và thẩm quyền.

**Kết luận:** Mục IV đã được điều chỉnh theo góp ý của Hiệu trưởng, đặc biệt là vai trò của Ban Thanh tra nhân dân, trách nhiệm kiểm tra Tổ Văn phòng của bà Ngọc Phượng và nguyên tắc kiểm tra chéo. Danh mục vẫn bám sát toàn bộ các nhóm nội dung trọng tâm đã xây dựng tại Mục II và giữ được sự liên kết giữa nội dung, đối tượng, người phụ trách và kết quả cần kiểm tra.

---

ASSISTANT

<WritingBlock id="68427" variant="document"># IV. DANH MỤC CÁC CUỘC KIỂM TRA

Căn cứ nội dung trọng tâm tại Mục II của Kế hoạch và Quyết định thành lập Ban kiểm tra nội bộ năm học 2026 - 2027, nhà trường dự kiến tổ chức 10 cuộc kiểm tra, bảo đảm phù hợp với nhiệm vụ năm học, điều kiện thực tế và nguyên tắc phân công kiểm tra chéo giữa các Phó Hiệu trưởng; phát huy vai trò kiểm tra, giám sát của Ban Thanh tra nhân dân theo chức năng, nhiệm vụ được giao.

| TT | Nội dung kiểm tra | Đối tượng kiểm tra | Thời gian tiến hành | Hình thức kiểm tra | Người phụ trách | Ghi chú |
|---|---|---|---|---|---|---|
| 1 | **Kiểm tra công tác quản lý, chỉ đạo, điều hành của Hiệu trưởng:** Việc xây dựng, ban hành và thực hiện chiến lược phát triển, kế hoạch năm học, kế hoạch giáo dục; Quy chế tổ chức và hoạt động, Quy chế dân chủ ở cơ sở; thực hiện công khai, phân công nhiệm vụ, nghị quyết hội nghị viên chức, người lao động và khắc phục hạn chế năm học trước. | Hiệu trưởng; Ban Giám hiệu và các bộ phận tham mưu, thực hiện có liên quan. | 11/2026 | Kiểm tra, giám sát việc thực hiện nghị quyết, quy chế, công khai; đối chiếu hồ sơ, minh chứng và kết quả thực hiện thực tế. | **Ban Thanh tra nhân dân** phụ trách kiểm tra, giám sát theo chức năng; bà Nguyễn Thị Huỳnh Duyên phối hợp, tổng hợp hồ sơ. | Mục II.1.1 và 3.1. Tập trung nội dung thuộc trách nhiệm Hiệu trưởng; thực hiện đúng phạm vi, thẩm quyền của Ban Thanh tra nhân dân. |
| 2 | **Kiểm tra hoạt động sư phạm giáo viên đợt I:** Việc chấp hành đạo đức nhà giáo, quy chế chuyên môn; xây dựng, thực hiện kế hoạch giáo dục; tổ chức hoạt động chăm sóc, nuôi dưỡng, giáo dục; quản lý nhóm lớp, bảo đảm an toàn, theo dõi và đánh giá sự phát triển của trẻ. | Giáo viên nhóm 25–36 tháng và khối Mầm được lựa chọn kiểm tra. | 11/2026 | Kiểm tra hồ sơ chuyên môn, dự giờ, quan sát hoạt động thực tế và trao đổi với giáo viên. | **Bà Ngọc Phượng** – Phó Trưởng ban; phối hợp các thành viên được phân công kiểm tra chéo. | Mục II.2.1. Bố trí thành viên không trực tiếp phụ trách nhóm, lớp được kiểm tra. |
| 3 | **Kiểm tra công tác quản lý tài chính và tài sản:** Việc quản lý thu, chi ngân sách, các khoản thu dịch vụ; quản lý, sử dụng nguồn tài trợ, hỗ trợ và kinh phí hoạt động của Ban đại diện cha mẹ trẻ theo quy định; thực hiện chế độ, chính sách; công khai tài chính; mua sắm, kiểm kê, quản lý, sử dụng tài sản, trang thiết bị. | Hiệu trưởng, bộ phận kế toán, thủ quỹ và các cá nhân, bộ phận liên quan. | 12/2026 | Kiểm tra hồ sơ, chứng từ, sổ sách kế toán; đối chiếu số liệu, kiểm tra tài sản và việc thực hiện thực tế. | **Bà Hồ Thanh Trúc** – Phó Trưởng ban phụ trách kiểm tra nghiệp vụ; Ban Thanh tra nhân dân giám sát các nội dung thuộc chức năng, nhiệm vụ. | Mục II.1.2. Ban Thanh tra nhân dân tập trung giám sát việc công khai, thực hiện dân chủ và trách nhiệm quản lý của Hiệu trưởng. |
| 4 | **Kiểm tra công tác nuôi dưỡng, bán trú và an toàn thực phẩm:** Việc xây dựng thực đơn, khẩu phần dinh dưỡng; giao nhận, bảo quản, chế biến và chia ăn; thực hiện kiểm thực, lưu mẫu thức ăn; vệ sinh bếp ăn, dụng cụ; tổ chức bữa ăn, giấc ngủ, theo dõi sức khỏe và tình trạng dinh dưỡng của trẻ. | Bộ phận cấp dưỡng, y tế, giáo viên và các cá nhân, bộ phận liên quan đến công tác bán trú. | 12/2026 | Kiểm tra hồ sơ nuôi dưỡng; quan sát trực tiếp hoạt động bếp ăn, các nhóm lớp; đối chiếu quy trình và kết quả thực hiện. | **Bà Nguyễn Thị Huỳnh Duyên** – Phó Trưởng ban; phối hợp các thành viên kiểm tra chéo theo phân công. | Mục II.1.5 và 2.2. Không bố trí người trực tiếp quản lý nội dung làm người đánh giá chính. |
| 5 | **Kiểm tra công tác chuyển đổi số và quản lý dữ liệu ngành:** Việc triển khai kế hoạch chuyển đổi số; quản lý văn bản điện tử, chữ ký số, phần mềm quản lý; cập nhật dữ liệu ngành theo nguyên tắc “Đúng - Đủ - Sạch - Sống”; thực hiện chế độ thống kê, báo cáo và bảo đảm an toàn, bảo mật thông tin. | Ban Giám hiệu, người phụ trách công nghệ thông tin, dữ liệu ngành, văn thư và các bộ phận có liên quan. | Đầu 01/2027 | Kiểm tra dữ liệu trên phần mềm, hồ sơ điện tử; đối chiếu với hồ sơ gốc, số liệu thực tế và báo cáo thống kê. | **Bà Hồ Thanh Trúc** – Phó Trưởng ban; phối hợp thành viên có chuyên môn phù hợp. | Mục II.1.4. Thực hiện kiểm tra chéo, hoàn thành để phục vụ sơ kết học kỳ I. |
| 6 | **Kiểm tra công tác quản lý đội ngũ và hoạt động của các tổ chuyên môn:** Việc phân công, sử dụng, đánh giá, bồi dưỡng giáo viên, nhân viên; thực hiện quy chế chuyên môn; xây dựng kế hoạch tổ, nền nếp sinh hoạt chuyên môn, triển khai chuyên đề, dự giờ, bồi dưỡng giáo viên và kết quả thực hiện nhiệm vụ. | Ban Giám hiệu; các tổ chuyên môn nhóm 25–36 tháng, Mầm, Chồi, Lá và giáo viên liên quan. | 02/2027 | Kiểm tra hồ sơ quản lý, hồ sơ chuyên môn; dự sinh hoạt tổ, trao đổi, xác minh và đối chiếu kết quả thực hiện. | **Bà Nguyễn Thị Huỳnh Duyên** – Phó Trưởng ban; phối hợp các thành viên Ban KTNB theo nguyên tắc kiểm tra chéo. | Mục II.1.3 và 2.3. Không giao tổ trưởng tự kiểm tra hoạt động của tổ mình. |
| 7 | **Kiểm tra hoạt động sư phạm giáo viên đợt II:** Việc thực hiện chương trình, kế hoạch giáo dục; đổi mới phương pháp, xây dựng môi trường giáo dục lấy trẻ làm trung tâm; năng lực sư phạm, quản lý nhóm lớp; theo dõi, đánh giá trẻ; ứng dụng công nghệ thông tin và phối hợp với cha mẹ trẻ. | Giáo viên khối Chồi, Lá và giáo viên khác được lựa chọn theo kế hoạch. | 03/2027 | Dự giờ, quan sát các hoạt động chăm sóc, giáo dục; kiểm tra hồ sơ chuyên môn và trao đổi trực tiếp. | **Bà Ngọc Phượng** – Phó Trưởng ban; phối hợp các tổ trưởng chuyên môn được phân công kiểm tra chéo. | Mục II.2.1. Không trùng lặp đối tượng và nội dung đã kiểm tra ở đợt I. |
| 8 | **Kiểm tra công tác an toàn trường học:** Việc thực hiện quy định về phòng cháy, chữa cháy; an ninh, trật tự; phòng, chống tai nạn thương tích, bạo lực, xâm hại trẻ; quy trình đón, trả trẻ; công tác y tế, vệ sinh môi trường; an toàn cơ sở vật chất, đồ dùng, đồ chơi và phương án xử lý tình huống khẩn cấp. | Các nhóm lớp; bộ phận y tế, bảo vệ và cá nhân, bộ phận có liên quan. | 03/2027 | Kiểm tra hồ sơ, phương án bảo đảm an toàn; quan sát thực tế môi trường, cơ sở vật chất và việc thực hiện quy trình. | **Bà Hồ Thanh Trúc** – Phó Trưởng ban; phối hợp thành viên Ban KTNB theo phân công. | Mục II.1.5. Tập trung an toàn trường học, không kiểm tra trùng lặp toàn bộ nội dung bán trú. |
| 9 | **Kiểm tra hoạt động của Tổ Văn phòng và việc thực hiện nhiệm vụ của nhân viên:** Xây dựng kế hoạch, chấp hành nội quy, thực hiện chức trách; công tác văn thư, hành chính, quản lý hồ sơ, con dấu; quản lý, sử dụng thiết bị, đồ dùng, đồ chơi, sách, học liệu; thực hiện nhiệm vụ và phối hợp của nhân viên y tế, bảo vệ, cấp dưỡng và các vị trí liên quan. | Tổ Văn phòng; tổ trưởng, nhân viên văn thư, kế toán, thủ quỹ, y tế, bảo vệ, cấp dưỡng và các nhân viên có liên quan. | 04/2027 | Kiểm tra kế hoạch, hồ sơ nghiệp vụ, sổ theo dõi công việc; kiểm tra thực tế và trao đổi trực tiếp với nhân viên. | **Bà Ngọc Phượng** – Phó Trưởng ban, trực tiếp phụ trách kiểm tra hoạt động Tổ Văn phòng. | Mục II.2.2 và 2.3. Phần trách nhiệm quản lý, chỉ đạo của bà Phượng được bố trí Phó Hiệu trưởng khác kiểm tra chéo. |
| 10 | **Kiểm tra việc thực hiện kiến nghị sau kiểm tra và kết quả khắc phục hạn chế:** Rà soát việc thực hiện các thông báo kết quả kiểm tra; đối chiếu nội dung, tiến độ, minh chứng khắc phục; xác định hạn chế chưa khắc phục, nguyên nhân, trách nhiệm và kết quả cải tiến chất lượng, phục vụ tổng kết công tác kiểm tra nội bộ năm học. | Các tổ chuyên môn, Tổ Văn phòng, bộ phận, cá nhân có kiến nghị sau kiểm tra; các cá nhân phụ trách theo dõi, tổng hợp. | Cuối 04/2027 đến trước 10/05/2027 | Kiểm tra lại hồ sơ, minh chứng; đối chiếu kết quả thực tế, tổng hợp và đánh giá việc thực hiện kiến nghị. | **Bà Nguyễn Thị Huỳnh Duyên** – đầu mối KTNB, phụ trách tổng hợp; các Phó Hiệu trưởng kiểm tra chéo theo lĩnh vực; Ban Thanh tra nhân dân giám sát phần thuộc trách nhiệm Hiệu trưởng. | Mục II.3.2. Hoàn thành để phục vụ báo cáo tổng kết trước ngày 13/05/2027. |

### Yêu cầu về phân công và tổ chức kiểm tra

**1. Đối với Ban Thanh tra nhân dân**

Ban Thanh tra nhân dân thực hiện nhiệm vụ kiểm tra, giám sát việc thực hiện nghị quyết hội nghị viên chức, người lao động, Quy chế dân chủ ở cơ sở, công khai và các nội dung thuộc trách nhiệm quản lý, chỉ đạo của Hiệu trưởng trong phạm vi chức năng, quyền hạn theo quy định.

Trưởng Ban Thanh tra nhân dân phân công thành viên thực hiện nhiệm vụ phù hợp với nội dung kiểm tra, giám sát; phối hợp cung cấp thông tin, trao đổi kết quả và kiến nghị khắc phục những hạn chế, thiếu sót phát hiện qua kiểm tra, giám sát.

Đối với nội dung thuộc trách nhiệm quản lý, điều hành của Hiệu trưởng nhưng ngoài phạm vi kiểm tra, giám sát của Ban Thanh tra nhân dân, việc đánh giá và xử lý thực hiện theo đúng thẩm quyền; trường hợp cần thiết báo cáo cơ quan quản lý cấp trên xem xét, chỉ đạo.

**2. Đối với các Phó Hiệu trưởng**

Thực hiện nguyên tắc phân công kiểm tra chéo giữa các Phó Hiệu trưởng nhằm bảo đảm tính khách quan, trung thực trong đánh giá kết quả thực hiện nhiệm vụ.

Đối với nội dung thuộc lĩnh vực do một Phó Hiệu trưởng trực tiếp quản lý, chỉ đạo, Hiệu trưởng phân công Phó Hiệu trưởng khác phụ trách kiểm tra, đánh giá; Phó Hiệu trưởng phụ trách lĩnh vực có trách nhiệm cung cấp hồ sơ, báo cáo, giải trình và phối hợp thực hiện.

Riêng hoạt động của Tổ Văn phòng, phân công bà Ngọc Phượng – Phó Hiệu trưởng phụ trách kiểm tra hoạt động của tổ và các nhân viên theo nội dung Kế hoạch. Đối với nội dung đánh giá trách nhiệm chỉ đạo, quản lý của bà Ngọc Phượng, phân công Phó Hiệu trưởng khác thực hiện kiểm tra chéo.

**3. Đối với các thành viên Ban kiểm tra nội bộ**

Các thành viên tham gia kiểm tra theo sự phân công cụ thể tại quyết định kiểm tra từng cuộc hoặc từng đợt; bảo đảm phù hợp năng lực chuyên môn, lĩnh vực công tác và yêu cầu của nội dung kiểm tra.

Các tổ trưởng chuyên môn tham gia kiểm tra chéo giữa các tổ, nhóm, lớp; không trực tiếp kiểm tra, đánh giá hoạt động của tổ, nhóm, lớp do mình quản lý.

Tổ trưởng Tổ Văn phòng và các nhân viên có trách nhiệm chuẩn bị hồ sơ, tài liệu, cung cấp thông tin, giải trình và phối hợp với tổ kiểm tra; không trực tiếp đánh giá những nội dung thuộc trách nhiệm thực hiện của chính mình.

**4. Tổ chức thực hiện và xử lý sau kiểm tra**

Căn cứ Danh mục các cuộc kiểm tra, Hiệu trưởng ban hành quyết định kiểm tra theo từng cuộc hoặc từng đợt, xác định rõ nội dung, đối tượng, thời kỳ, thời hạn, thành phần và người phụ trách kiểm tra.

Mỗi cuộc kiểm tra phải thực hiện đầy đủ trình tự, thủ tục, hồ sơ theo hướng dẫn tại Công văn số 1134/SGDĐT-TCCB; lập Biên bản kiểm tra (Mẫu số 04), Báo cáo kết quả kiểm tra (Mẫu số 05), ban hành Thông báo kết quả kiểm tra (Mẫu số 06) và theo dõi việc thực hiện kiến nghị sau kiểm tra.

Kết quả kiểm tra phải bảo đảm chính xác, khách quan, có minh chứng; nêu rõ ưu điểm, hạn chế, nguyên nhân, trách nhiệm và biện pháp khắc phục. Hiệu trưởng chỉ đạo thực hiện việc khắc phục, kiểm tra lại và xử lý hoặc kiến nghị xử lý những vấn đề phát sinh theo thẩm quyền.

Trong quá trình triển khai, căn cứ tình hình thực tế và nhiệm vụ của từng thành viên, Hiệu trưởng xem xét điều chỉnh phân công bằng văn bản để bảo đảm nguyên tắc kiểm tra chéo, không chồng chéo nội dung và không ảnh hưởng đến hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.</WritingBlock>

## ⚠️ Những điểm cần kiểm tra trước khi Hiệu trưởng duyệt

**Thứ nhất, về Ban Thanh tra nhân dân:** Quyết định số 82/QĐ-MNAB có ghi “Cùng Ban Thanh tra nhân dân” nhưng chưa nêu tên Trưởng ban và các thành viên. Vì vậy, bảng phân công hiện ghi tên tập thể Ban Thanh tra nhân dân. Khi tổ chức kiểm tra, giám sát cần xác định rõ thành viên thực hiện, đồng thời phối hợp với chương trình, kế hoạch hoạt động của Ban.

**Thứ hai, về phân công các Phó Hiệu trưởng:** Tôi đã bố trí các bà Huỳnh Duyên, Hồ Thanh Trúc và Ngọc Phượng luân phiên kiểm tra, trong đó bà Ngọc Phượng được phân công rõ ở cuộc kiểm tra Tổ Văn phòng theo ý kiến của Hiệu trưởng. Tuy nhiên, hồ sơ hiện có chưa thể hiện đầy đủ lĩnh vực chuyên môn mà mỗi Phó Hiệu trưởng trực tiếp phụ trách. Do đó, **cần đối chiếu bảng phân công nhiệm vụ Ban Giám hiệu năm học 2026–2027** để xác nhận các cặp kiểm tra chéo trước khi ban hành chính thức.

**Thứ ba, về nội dung kiểm tra trách nhiệm Hiệu trưởng:** Ban Thanh tra nhân dân thực hiện đúng chức năng kiểm tra, giám sát của mình, không thay thế quyền kiểm tra, đánh giá của cơ quan quản lý cấp trên. Cách phân công này vừa tiếp thu góp ý của Hiệu trưởng, vừa bảo đảm phân định trách nhiệm và thẩm quyền.

**Kết luận:** Mục IV đã được điều chỉnh theo góp ý của Hiệu trưởng, đặc biệt là vai trò của Ban Thanh tra nhân dân, trách nhiệm kiểm tra Tổ Văn phòng của bà Ngọc Phượng và nguyên tắc kiểm tra chéo. Danh mục vẫn bám sát toàn bộ các nhóm nội dung trọng tâm đã xây dựng tại Mục II và giữ được sự liên kết giữa nội dung, đối tượng, người phụ trách và kết quả cần kiểm tra.

---

