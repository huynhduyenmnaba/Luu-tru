USER

[@Chuyên gia Giáo dục mầm non](plugin://gpt-10d60647f7dfc69465055636721f7c6c@openai-curated-remote) dựa vào kế hoạch của sở bạn giúp tôi lập kế họach BDTX cho trường bám vào nội dung vb sở . Lặp luận chặt chẽ, lo gic dễ hiểu không tự tiện thêm các ý khác nhé

---

ASSISTANT

Tôi sẽ đọc kỹ kế hoạch của Sở và dùng hướng dẫn của plugin Chuyên gia Giáo dục mầm non để xây dựng kế hoạch BDTX cho trường, bám sát nội dung văn bản và cụ thể hóa phần việc thuộc trách nhiệm nhà trường.

---

ASSISTANT

Dưới đây là dự thảo kế hoạch cho **Trường Mầm non An Bình**, giữ nguyên 9 mục của **Kế hoạch số 1157/KH-SGDĐT ngày 22/9/2026 của Sở GDĐT Đồng Tháp**, cụ thể hóa trách nhiệm thực hiện tại trường. Văn bản của Sở chưa quy định tên chuyên đề và mô đun cụ thể nên phần này được trình bày theo hướng dẫn và đăng ký của từng đối tượng, không tự bổ sung nội dung bồi dưỡng. *[Source: .pdf]*

---

**UBND XÃ/PHƯỜNG ………………**  
**TRƯỜNG MẦM NON AN BÌNH**  
Số: ……/KH-MNAB

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
**Độc lập - Tự do - Hạnh phúc**

*An Bình, ngày …… tháng …… năm 2026*

# KẾ HOẠCH
**Bồi dưỡng thường xuyên cho cán bộ quản lý, giáo viên  
Trường Mầm non An Bình năm học 2026 - 2027**

Căn cứ Thông tư số 19/2019/TT-BGDĐT ngày 12 tháng 11 năm 2019 của Bộ Giáo dục và Đào tạo ban hành Quy chế bồi dưỡng thường xuyên giáo viên, cán bộ quản lý cơ sở giáo dục mầm non, cơ sở giáo dục phổ thông và giáo viên trung tâm giáo dục thường xuyên, được sửa đổi, bổ sung tại Thông tư số 17/2022/TT-BGDĐT;

Căn cứ Thông tư số 11/2019/TT-BGDĐT ngày 26 tháng 8 năm 2019 của Bộ Giáo dục và Đào tạo ban hành Chương trình bồi dưỡng thường xuyên cán bộ quản lý cơ sở giáo dục mầm non;

Căn cứ Thông tư số 12/2019/TT-BGDĐT ngày 26 tháng 8 năm 2019 của Bộ Giáo dục và Đào tạo ban hành Chương trình bồi dưỡng thường xuyên giáo viên mầm non;

Căn cứ Kế hoạch số 1157/KH-SGDĐT ngày 22 tháng 9 năm 2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp về bồi dưỡng thường xuyên cho cán bộ quản lý, giáo viên cơ sở giáo dục mầm non, phổ thông và trung tâm giáo dục thường xuyên năm học 2026 - 2027 trên địa bàn tỉnh Đồng Tháp;

Trường Mầm non An Bình xây dựng Kế hoạch bồi dưỡng thường xuyên (BDTX) cho cán bộ quản lý và giáo viên năm học 2026 - 2027 như sau:

## I. MỤC ĐÍCH, YÊU CẦU BỒI DƯỠNG THƯỜNG XUYÊN

1. Bồi dưỡng kiến thức, kỹ năng chuyên ngành theo yêu cầu vị trí việc làm nhằm nâng cao phẩm chất, năng lực chuyên môn, nghiệp vụ của cán bộ quản lý và giáo viên; đáp ứng yêu cầu thực hiện nhiệm vụ quản lý, nuôi dưỡng, chăm sóc, giáo dục trẻ và yêu cầu của chuẩn nghề nghiệp.

2. Phát triển năng lực tự học, tự bồi dưỡng và tự đánh giá của cán bộ quản lý, giáo viên; nâng cao năng lực tổ chức, quản lý hoạt động BDTX của nhà trường.

3. Xác định rõ nhiệm vụ, cách thức tổ chức và các điều kiện thực hiện BDTX, bảo đảm việc triển khai tại trường phù hợp với kế hoạch của Sở và điều kiện thực tế của đơn vị.

4. Gắn hoạt động BDTX với kiểm tra, đánh giá cán bộ quản lý, giáo viên theo chuẩn và yêu cầu đổi mới giáo dục của ngành; từng bước nâng cao năng lực đội ngũ qua từng năm học.

5. Thực hiện đầy đủ nội dung, thời lượng và yêu cầu đánh giá của các chương trình bồi dưỡng. Chủ động bố trí thời gian trong năm học, tránh tập trung bồi dưỡng vào tháng cuối năm học làm ảnh hưởng đến hiệu quả thực hiện.

## II. ĐỐI TƯỢNG, NỘI DUNG VÀ THỜI LƯỢNG BỒI DƯỠNG THƯỜNG XUYÊN

### 1. Đối tượng bồi dưỡng

- Cán bộ quản lý: Hiệu trưởng, Phó Hiệu trưởng Trường Mầm non An Bình.
- Giáo viên đang thực hiện nhiệm vụ nuôi dưỡng, chăm sóc, giáo dục trẻ tại trường.

### 2. Nội dung và thời lượng bồi dưỡng

#### a) Nội dung kiến thức bắt buộc

**Chương trình bồi dưỡng 01: 40 tiết/năm học**

Bồi dưỡng kiến thức, kỹ năng theo yêu cầu vị trí việc làm nhằm nâng cao phẩm chất, năng lực chuyên môn, nghiệp vụ của cán bộ quản lý và giáo viên; đáp ứng yêu cầu phát triển giáo dục mầm non và chuẩn nghề nghiệp.

Nội dung thực hiện:

- Chủ trương, đường lối, chính sách phát triển giáo dục mầm non.
- Chương trình giáo dục mầm non và các hoạt động giáo dục thuộc chương trình.
- Kiến thức, kỹ năng, nghiệp vụ lãnh đạo, quản trị cơ sở giáo dục mầm non đối với cán bộ quản lý.

Nhà trường tổ chức cho cán bộ quản lý, giáo viên tham gia các nội dung bồi dưỡng theo kế hoạch, hướng dẫn và yêu cầu triệu tập của cơ quan quản lý giáo dục; triển khai thực hiện tại đơn vị phù hợp với nhiệm vụ của từng đối tượng.

**Chương trình bồi dưỡng 02: 40 tiết/năm học**

Cập nhật kiến thức, kỹ năng đáp ứng yêu cầu thực hiện nhiệm vụ phát triển giáo dục mầm non của địa phương.

Nội dung thực hiện:

- Kiến thức về phát triển giáo dục mầm non của địa phương.
- Nội dung về chương trình và kiến thức giáo dục địa phương phù hợp với cấp học mầm non theo hướng dẫn.
- Nội dung bồi dưỡng theo kế hoạch của các dự án, nếu có.

Thực hiện tự bồi dưỡng qua mạng kết hợp với bồi dưỡng trực tiếp và sinh hoạt chuyên môn trong trường hoặc cụm trường.

Minh chứng thực hiện Chương trình bồi dưỡng 02 được thực hiện theo Phụ lục 1 kèm theo Kế hoạch của Sở hoặc hình thức phù hợp theo hướng dẫn và Quy chế BDTX.

#### b) Nội dung kiến thức tự chọn

**Chương trình bồi dưỡng 03: 40 tiết/năm học**

Cán bộ quản lý và giáo viên tự chọn các mô đun thuộc chương trình BDTX dành cho từng đối tượng, nhằm phát triển phẩm chất, năng lực nghề nghiệp đáp ứng yêu cầu vị trí việc làm:

- Cán bộ quản lý lựa chọn mô đun theo Thông tư số 11/2019/TT-BGDĐT.
- Giáo viên lựa chọn mô đun theo Thông tư số 12/2019/TT-BGDĐT.

Các mô đun lựa chọn được thể hiện trong kế hoạch BDTX cá nhân, làm căn cứ tổng hợp và tổ chức thực hiện tại trường.

Nhà trường thực hiện theo phân cấp quản lý, tham mưu cấp có thẩm quyền phối hợp với cơ sở giáo dục được Bộ GDĐT cho phép thực hiện nhiệm vụ BDTX để tổ chức bồi dưỡng phù hợp với điều kiện của đơn vị.

#### c) Tổng thời lượng

Tổng thời lượng BDTX đối với mỗi cán bộ quản lý, giáo viên là **120 tiết/năm học**, gồm:

| Chương trình | Tính chất | Thời lượng |
|---|---|---:|
| Chương trình bồi dưỡng 01 | Bắt buộc | 40 tiết |
| Chương trình bồi dưỡng 02 | Bắt buộc | 40 tiết |
| Chương trình bồi dưỡng 03 | Tự chọn | 40 tiết |
| **Tổng cộng** | | **120 tiết** |

Trong quá trình thực hiện, căn cứ yêu cầu nhiệm vụ và kế hoạch năm học, có thể điều chỉnh thời lượng Chương trình bồi dưỡng 01 và Chương trình bồi dưỡng 02 cho phù hợp; giữ nguyên thời lượng Chương trình bồi dưỡng 03 và bảo đảm tổng thời lượng 120 tiết/năm học.

## III. HÌNH THỨC BỒI DƯỠNG THƯỜNG XUYÊN

1. Lựa chọn hình thức bồi dưỡng phù hợp với điều kiện thực tế của trường; kết hợp với sinh hoạt chuyên môn và sự hỗ trợ của đội ngũ cốt cán.

2. Tham gia bồi dưỡng tập trung theo yêu cầu triệu tập các đợt tập huấn của Bộ GDĐT, Sở GDĐT trong việc triển khai, thực hiện nhiệm vụ chuyên môn.

3. Thực hiện bồi dưỡng từ xa thông qua ứng dụng công nghệ thông tin, tập huấn qua mạng internet và các phần mềm trực tuyến hỗ trợ.

4. Đối với Chương trình bồi dưỡng 03, nhà trường căn cứ điều kiện thực tế và phân cấp quản lý để tham mưu cấp có thẩm quyền phối hợp với cơ sở giáo dục thực hiện nhiệm vụ BDTX, tổ chức tập huấn phù hợp với đơn vị.

## IV. CHƯƠNG TRÌNH BỒI DƯỠNG THƯỜNG XUYÊN

### 1. Đối với cán bộ quản lý

Thực hiện Chương trình BDTX cán bộ quản lý cơ sở giáo dục mầm non ban hành kèm theo Thông tư số 11/2019/TT-BGDĐT.

### 2. Đối với giáo viên

Thực hiện Chương trình BDTX giáo viên mầm non ban hành kèm theo Thông tư số 12/2019/TT-BGDĐT.

## V. ĐÁNH GIÁ VÀ CÔNG NHẬN KẾT QUẢ

### 1. Đánh giá bồi dưỡng thường xuyên

Việc đánh giá căn cứ kết quả thực hiện các Chương trình bồi dưỡng 01, 02 và 03 của từng cán bộ quản lý, giáo viên.

**a) Hoàn thành kế hoạch BDTX**

Cán bộ quản lý, giáo viên được xếp loại hoàn thành kế hoạch BDTX khi đáp ứng các yêu cầu:

- **Đối với Chương trình bồi dưỡng 01 và 02:** nội dung bồi dưỡng chính trị hè năm 2026 và hướng dẫn thực hiện nhiệm vụ năm học 2026 - 2027 được đánh giá đạt; hoặc thực hiện đầy đủ nội dung, hoàn thành đủ bài kiểm tra, bài thu hoạch với kết quả đạt yêu cầu trở lên. Nội dung tự bồi dưỡng qua mạng được hệ thống đánh giá tự động là đạt; nội dung có đội ngũ cốt cán, người được giao nhiệm vụ hỗ trợ được đánh giá là đạt theo hình thức thực hiện.
- **Đối với Chương trình bồi dưỡng 03:** các nội dung tự bồi dưỡng, bồi dưỡng trực tuyến, bồi dưỡng tập trung có đánh giá bằng bài kiểm tra lý thuyết, thực hành được cơ sở thực hiện nhiệm vụ bồi dưỡng đánh giá là đạt; hoặc thực hiện đầy đủ nội dung, hoàn thành đủ các bài kiểm tra với kết quả đạt yêu cầu trở lên, từ 5,0 điểm trở lên.

**b) Không hoàn thành kế hoạch BDTX**

Cán bộ quản lý, giáo viên không đáp ứng các yêu cầu trên được xếp loại không hoàn thành kế hoạch BDTX.

**c) Minh chứng Chương trình bồi dưỡng 02**

Bài thu hoạch có thể thực hiện theo mẫu gợi ý tại Phụ lục 1 của Kế hoạch Sở, gồm:

- Những nội dung đã học được sau khi kết thúc đợt tập huấn: 4 điểm.
- Nội dung khó thực hiện tại đơn vị và nguyên nhân: 3 điểm.
- Giải pháp giải quyết những khó khăn: 3 điểm.

Hiệu trưởng căn cứ nội dung bồi dưỡng và tình hình thực tế để xây dựng câu hỏi phù hợp hoặc sử dụng hình thức minh chứng khác theo Quy chế BDTX.

### 2. Công nhận kết quả bồi dưỡng thường xuyên

- Hệ thống TEMIS tự động thống kê kết quả BDTX của từng cá nhân.
- Nhà trường tổng hợp kết quả đánh giá các Chương trình bồi dưỡng 01, 02 và 03; báo cáo Phòng Văn hóa - Xã hội để tổng hợp, đề nghị Sở GDĐT công nhận kết quả BDTX năm học 2026 - 2027 theo phân cấp quản lý.
- Nội dung đề nghị công nhận và danh sách kèm theo thực hiện theo Phụ lục 2 của Kế hoạch Sở.
- Kết quả đánh giá, xếp loại BDTX được lưu vào hồ sơ, làm căn cứ thực hiện các chế độ, chính sách liên quan đến bồi dưỡng phát triển nghề nghiệp và sử dụng cán bộ quản lý, giáo viên.

## VI. KINH PHÍ THỰC HIỆN BỒI DƯỠNG THƯỜNG XUYÊN

Kinh phí thực hiện BDTX được sử dụng từ nguồn kinh phí được giao trong dự toán đào tạo, bồi dưỡng; kinh phí chi thường xuyên hằng năm và các nguồn kinh phí hợp pháp khác của đơn vị.

Việc bố trí kinh phí thực hiện theo chế độ và phân cấp hiện hành, bảo đảm điều kiện triển khai các nội dung bồi dưỡng theo kế hoạch.

## VII. TÀI LIỆU BỒI DƯỠNG THƯỜNG XUYÊN

1. Cán bộ quản lý, giáo viên sử dụng tài khoản TEMIS của mình để tự học các khóa học công khai và tham khảo tài liệu trên hệ thống khi các khóa học, tài liệu được mở.

2. Sử dụng tài liệu do Bộ GDĐT tổ chức biên soạn, thẩm định, phê duyệt và các tài liệu phù hợp khác đã được cơ quan có thẩm quyền thẩm định, phê duyệt theo quy định tại khoản 2 Điều 7 Quy chế BDTX ban hành kèm theo Thông tư số 19/2019/TT-BGDĐT.

## VIII. THỜI GIAN BÁO CÁO CÔNG TÁC BỒI DƯỠNG THƯỜNG XUYÊN TRÊN HỆ THỐNG TEMIS

### 1. Thực hiện báo cáo chính thức trên hệ thống TEMIS

Việc quản lý và báo cáo công tác BDTX của cán bộ quản lý, giáo viên thực hiện trên hệ thống TEMIS, thay thế hình thức báo cáo bằng văn bản giấy truyền thống theo Kế hoạch của Sở.

Nhà trường hướng dẫn cán bộ quản lý, giáo viên thực hiện các nội dung trên hệ thống; theo dõi, tổng hợp kết quả phục vụ công tác báo cáo.

### 2. Thời hạn báo cáo tổng kết

Nhà trường hoàn thành việc tổng hợp, báo cáo kết quả BDTX về UBND cấp xã, qua Phòng Văn hóa - Xã hội, theo thời hạn do địa phương hướng dẫn, bảo đảm cấp xã tổng hợp gửi Sở GDĐT, qua Phòng Tổ chức cán bộ, **trước ngày 05 tháng 6 năm 2027**.

## IX. TỔ CHỨC THỰC HIỆN

### 1. Ban Giám hiệu

- Triển khai Kế hoạch BDTX của Sở và kế hoạch của nhà trường đến cán bộ quản lý, giáo viên; hướng dẫn xây dựng kế hoạch BDTX cá nhân phù hợp với từng đối tượng.
- Hiệu trưởng phê duyệt kế hoạch BDTX cá nhân thuộc thẩm quyền quản lý; thực hiện việc phê duyệt kế hoạch của cán bộ quản lý theo hướng dẫn và phân cấp.
- Bố trí thời gian, tài liệu, cơ sở vật chất và các điều kiện thực hiện BDTX; tổ chức bồi dưỡng trong năm học phù hợp với hoạt động của trường.
- Thực hiện theo phân cấp việc tham mưu, phối hợp tổ chức Chương trình bồi dưỡng 03 với cơ sở giáo dục thực hiện nhiệm vụ BDTX.
- Theo dõi, kiểm tra tiến độ, nội dung, thời lượng và kết quả thực hiện kế hoạch BDTX của cán bộ quản lý, giáo viên.
- Tổ chức tổng hợp, xếp loại, báo cáo và đề nghị công nhận kết quả BDTX qua Phòng Văn hóa - Xã hội theo hướng dẫn; quản lý, lưu trữ hồ sơ và kết quả bồi dưỡng.

### 2. Giáo viên và cán bộ quản lý

- Căn cứ kế hoạch BDTX của Sở và nhà trường, xây dựng kế hoạch BDTX cá nhân, trình phê duyệt theo thẩm quyền.
- Lựa chọn mô đun thuộc Chương trình bồi dưỡng 03 phù hợp với yêu cầu vị trí việc làm và chương trình BDTX của từng đối tượng.
- Tham gia đầy đủ các nội dung bồi dưỡng; thực hiện tự học, tự bồi dưỡng theo kế hoạch đã được phê duyệt.
- Hoàn thành bài kiểm tra, bài thu hoạch và các yêu cầu đánh giá theo từng chương trình; thực hiện các nội dung trên hệ thống TEMIS theo hướng dẫn.
- Cung cấp kết quả, minh chứng bồi dưỡng để nhà trường tổng hợp, đánh giá và báo cáo đúng thời hạn.
- Nghiêm túc thực hiện các quy định về BDTX của cơ quan quản lý giáo dục và nhà trường.

Trên đây là Kế hoạch BDTX cho cán bộ quản lý, giáo viên Trường Mầm non An Bình năm học 2026 - 2027. Trong quá trình thực hiện, nếu có vướng mắc, cán bộ quản lý và giáo viên báo cáo Ban Giám hiệu để tổng hợp, đề nghị cơ quan quản lý hướng dẫn, giải quyết./.

**Nơi nhận:**

- Phòng Văn hóa - Xã hội ………………;
- Cán bộ quản lý, giáo viên trường;
- Lưu: VT, hồ sơ BDTX.

**HIỆU TRƯỞNG**  
*(Ký, ghi rõ họ tên và đóng dấu)*

---

USER

làm giúp mình phụ lục đính kèm thoe hướng dẫn của sở

---

ASSISTANT

Tôi sẽ soạn các phụ lục theo mẫu của Sở, gồm bài thu hoạch, văn bản đề nghị công nhận và danh sách kết quả BDTX của Trường Mầm non An Bình; để trống thông tin cá nhân và kết quả chưa có.

---

ASSISTANT

Sở có 2 phụ lục: mẫu bài thu hoạch và mẫu đề nghị công nhận kèm danh sách. Tôi sẽ gộp thành một file Word để dễ điền và in, giữ nguyên ba câu hỏi cùng thang điểm 4–3–3. Phần đề nghị công nhận sẽ điều chỉnh theo tuyến nhà trường gửi qua Phòng Văn hóa – Xã hội để tổng hợp trình Sở. Tôi sẽ dùng hướng dẫn tạo tài liệu Word để trình bày và kiểm tra bản in.

---

ASSISTANT

Mình đã hoàn thành file Word gồm **2 phụ lục theo hướng dẫn của Sở**:

- **Phụ lục 1:** Bài thu hoạch với 3 câu hỏi, thang điểm **4–3–3**.
- **Phụ lục 2:** Mẫu đề nghị công nhận kết quả BDTX và danh sách kèm theo, dành cho Trường Mầm non An Bình.

Các thông tin chưa có được để trống để trường điền trước khi sử dụng.

[Phu_luc_BDTX_Mam_non_An_Binh_2026_2027.docx](sandbox:/workspace/scratch/cf9777e016fb/output/Phu_luc_BDTX_Mam_non_An_Binh_2026_2027.docx)

---

