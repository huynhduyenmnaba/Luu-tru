USER

Viết giúp mình nội dung này để đang trên facebook của trường Mầm non

---

ASSISTANT

Mình sẽ soạn lời đăng Facebook ngắn gọn, dễ đọc, bám sát thông tin trong ảnh.

---

ASSISTANT

> **writing · social_post**
>
> 📢 THÔNG TIN TUYỂN DỤNG NHÀ GIÁO NĂM 2026 (ĐỢT 1) – TỈNH ĐỒNG THÁP
>
> Trường Mầm non An Bình thông tin đến quý thầy cô, quý phụ huynh và các cá nhân có nhu cầu về tuyển dụng nhà giáo tại các cơ sở giáo dục công lập trực thuộc Sở Giáo dục và Đào tạo và UBND các xã, phường trên địa bàn tỉnh Đồng Tháp.
>
> 🌟 Tổng chỉ tiêu tuyển dụng toàn tỉnh: 235 chỉ tiêu, gồm:
> 🔹 140 chỉ tiêu tại các cơ sở giáo dục trực thuộc Sở Giáo dục và Đào tạo.
> 🔹 95 chỉ tiêu tại các cơ sở giáo dục trực thuộc UBND cấp xã.
>
> 📝 Hình thức tuyển dụng: Xét tuyển qua 02 vòng:
> 🔸 Vòng 1: Kiểm tra điều kiện dự tuyển tại Phiếu đăng ký dự tuyển.
> 🔸 Vòng 2: Đánh giá năng lực thông qua thực hành giảng dạy 01 tiết (thang điểm 100).
>
> 📅 Thời gian tiếp nhận Phiếu đăng ký dự tuyển: Từ ngày 12/10/2026 đến hết ngày 10/11/2026, trong giờ hành chính từ thứ Hai đến thứ Sáu.
>
> 📬 Phương thức nộp hồ sơ: Nộp trực tiếp, gửi qua đường bưu điện hoặc qua cổng thông tin điện tử.
>
> 📍 Địa điểm tiếp nhận: Phòng Tổ chức cán bộ – Sở Giáo dục và Đào tạo tỉnh Đồng Tháp, số 397, đường Hùng Vương, phường Đạo Thạnh, tỉnh Đồng Tháp.
> ☎️ Điện thoại: 0273 3 872 604.
>
> 🔎 Chi tiết về hồ sơ và các nội dung liên quan được thể hiện trong hình ảnh đính kèm. Người dự tuyển thường xuyên theo dõi thông báo trên Cổng thông tin điện tử Sở Giáo dục và Đào tạo tỉnh Đồng Tháp:
> 🌐 https://dongthap.edu.vn
>
> 💌 Kính mời quý thầy cô, quý phụ huynh chia sẻ thông tin để các cá nhân có nhu cầu được biết và đăng ký dự tuyển đúng thời gian quy định.
>
> #MamNonAnBinh #TuyenDungNhaGiao2026 #GiaoDucDongThap

---

