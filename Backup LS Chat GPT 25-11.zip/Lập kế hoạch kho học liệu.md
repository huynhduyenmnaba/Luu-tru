USER

Với vai trò Hiệu trưởng bạn giúp tôi lập kế hoạch xây dựng kho tài liệu, học liệu dùng chung năm học 2026-2027. Lưu ý kế hoạch bám sát thực tiễn cơ sở, lặp luận logic, chặt chẽ thuyết phục

---

ASSISTANT

Tôi sẽ xây dựng kế hoạch theo thể thức văn bản của nhà trường, tập trung vào cách tổ chức kho học liệu để giáo viên thực sự sử dụng được, không làm phát sinh hồ sơ hình thức. Tôi cũng sẽ kiểm tra căn cứ pháp lý và xác định rõ chỉ tiêu, tiến độ, phân công, tiêu chí nghiệm thu cho năm học 2026–2027.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 KẾ HOẠCH XÂY DỰNG KHO TÀI LIỆU, HỌC LIỆU DÙNG CHUNG NĂM HỌC 2026–2027

Dưới góc độ quản lý nhà trường, tôi đề xuất xây dựng kế hoạch theo định hướng: **“Chuẩn hóa tài liệu – Chia sẻ nguồn lực – Khai thác hiệu quả – Nâng cao chất lượng nuôi dưỡng, chăm sóc và giáo dục trẻ”.**

Kế hoạch cần giải quyết ba vấn đề thực tiễn: tài liệu chuyên môn đang phân tán ở nhiều giáo viên; học liệu có chất lượng chưa được chia sẻ và kế thừa hiệu quả; năng lực ứng dụng công nghệ thông tin của đội ngũ chưa đồng đều.

Đặc biệt, kế hoạch phải phù hợp với những yêu cầu mới của năm học 2026–2027:

- Công văn số **5385/BGDĐT-GDMN ngày 12/8/2026** nhấn mạnh đổi mới quản trị, chuyển đổi số, khai thác học liệu hiện có và cắt giảm hồ sơ, thủ tục không cần thiết. [Công văn 5385/BGDĐT\-GDMN 2026 hướng dẫn nhiệm vụ giáo dục mầm non năm học 2026 2027](<https://thuvienphapluat.vn/cong-van/Giao-duc/Cong-van-5385-BGDDT-GDMN-2026-huong-dan-nhiem-vu-giao-duc-mam-non-nam-hoc-2026-2027-719453.aspx>)
- Thông tư số **60/2026/TT-BGDĐT**, có hiệu lực ngày 01/9/2026, quy định việc lựa chọn đồ chơi, học liệu sử dụng trong cơ sở giáo dục mầm non; đây là căn cứ quan trọng để xây dựng quy trình kiểm soát chất lượng học liệu. [Thông tư số 60/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non](<https://vanban.chinhphu.vn/?classid=1&docid=218922&pageid=27160>)
- Luật Bảo vệ dữ liệu cá nhân số **91/2025/QH15**, có hiệu lực từ ngày 01/01/2026, đặt ra yêu cầu bảo vệ thông tin cá nhân của trẻ, gia đình và giáo viên khi xây dựng kho tài nguyên số. [Luật số 91/2025/QH15 của Quốc hội: Luật Bảo vệ dữ liệu cá nhân](<https://vanban.chinhphu.vn/?classid=1&docid=214590&orggroupid=1&pageid=27160>)

Dưới đây là **bản kế hoạch theo thể thức hành chính**, có thể điều chỉnh tên trường, các số liệu khảo sát và ban hành tại đơn vị. Các chỉ tiêu được xây dựng ở mức đề xuất, ưu tiên khả thi, không chạy theo số lượng học liệu hoặc làm tăng áp lực hành chính cho giáo viên.

> **writing · document**
>
> **ỦY BAN NHÂN DÂN [XÃ/PHƯỜNG]**  
> **TRƯỜNG MẦM NON [TÊN TRƯỜNG]**
>
> Số: …/KH-MN…
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *[Địa danh], ngày … tháng 11 năm 2026*
>
> # KẾ HOẠCH
> **Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027**
>
> Căn cứ Luật Giáo dục số 43/2019/QH14 và các văn bản sửa đổi, bổ sung có liên quan;
>
> Căn cứ Điều lệ Trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020 của Bộ Giáo dục và Đào tạo, được sửa đổi, bổ sung bởi Thông tư số 51/2026/TT-BGDĐT ngày 30/6/2026;
>
> Căn cứ Thông tư số 60/2026/TT-BGDĐT ngày 17/7/2026 của Bộ Giáo dục và Đào tạo quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non;
>
> Căn cứ Công văn số 5385/BGDĐT-GDMN ngày 12/8/2026 của Bộ Giáo dục và Đào tạo về hướng dẫn thực hiện nhiệm vụ giáo dục mầm non năm học 2026–2027;
>
> Căn cứ kế hoạch thực hiện nhiệm vụ năm học 2026–2027 và điều kiện thực tế về đội ngũ, cơ sở vật chất, trang thiết bị, nguồn tài liệu, học liệu của nhà trường;
>
> Trường Mầm non [Tên trường] xây dựng Kế hoạch xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 với những nội dung sau:
>
> ## I. ĐẶC ĐIỂM TÌNH HÌNH VÀ SỰ CẦN THIẾT
>
> ### 1. Đặc điểm tình hình
>
> Trong những năm học qua, nhà trường quan tâm chỉ đạo đội ngũ cán bộ quản lý, giáo viên đổi mới phương pháp tổ chức các hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ; tăng cường ứng dụng công nghệ thông tin, khai thác các nguồn tài liệu, học liệu phục vụ công tác chuyên môn.
>
> Qua quá trình thực hiện nhiệm vụ, giáo viên đã từng bước tích lũy được nhiều nguồn tài liệu, kế hoạch giáo dục, hình ảnh, video, trò chơi, đồ dùng và học liệu có giá trị thực tiễn. Đây là nguồn lực cần được rà soát, chọn lọc, chuẩn hóa và sử dụng hiệu quả trong phạm vi toàn trường.
>
> Tuy nhiên, việc xây dựng và sử dụng nguồn tài liệu dùng chung cần được tổ chức có hệ thống để khắc phục những hạn chế thường gặp trong thực tiễn, như:
>
> - Tài liệu, học liệu được lưu trữ phân tán tại máy tính, điện thoại hoặc tài khoản cá nhân của giáo viên; việc tìm kiếm, chia sẻ và kế thừa chưa thực sự thuận tiện.
> - Chất lượng tài liệu chưa đồng đều; một số nội dung cần được rà soát về tính chính xác, sự phù hợp với độ tuổi, điều kiện tổ chức và yêu cầu của Chương trình giáo dục mầm non.
> - Việc lựa chọn, sắp xếp, cập nhật và sử dụng học liệu chưa có quy trình thống nhất; một số sản phẩm có thể trùng lặp hoặc chưa phát huy hết giá trị sử dụng.
> - Năng lực ứng dụng công nghệ thông tin của giáo viên có thể còn chênh lệch; điều kiện thiết bị, đường truyền Internet và khả năng tiếp cận học liệu tại các nhóm, lớp cần được đánh giá cụ thể.
>
> Nhà trường thực hiện khảo sát, xác định mức độ của từng nội dung nêu trên, không mặc nhiên coi đây là những hạn chế đã xảy ra tại đơn vị.
>
> ### 2. Sự cần thiết
>
> Xây dựng kho tài liệu, học liệu dùng chung là giải pháp nhằm tập hợp và phát huy nguồn lực chuyên môn hiện có, đồng thời tạo điều kiện để giáo viên tiếp cận những tài liệu đã được chọn lọc, chia sẻ kinh nghiệm và chủ động lựa chọn học liệu phù hợp với trẻ.
>
> Việc hình thành kho dùng chung góp phần hạn chế tình trạng giáo viên phải tìm kiếm, xây dựng lại những tài liệu đã có; tiết kiệm thời gian chuẩn bị hoạt động, giảm sự trùng lặp và nâng cao hiệu quả sử dụng các nguồn lực của nhà trường.
>
> Đây cũng là giải pháp thiết thực để phát huy vai trò của tổ chuyên môn, giáo viên cốt cán trong hỗ trợ đồng nghiệp, thúc đẩy sinh hoạt chuyên môn theo hướng nghiên cứu, chia sẻ và vận dụng vào thực tiễn.
>
> Từ những yêu cầu trên, việc xây dựng kho tài liệu, học liệu dùng chung cần được xác định là nhiệm vụ chuyên môn gắn với đổi mới quản trị nhà trường, có kế hoạch, lộ trình, phân công trách nhiệm và cơ chế kiểm soát chất lượng cụ thể; không thực hiện theo phong trào hoặc chạy theo số lượng sản phẩm.
>
> ## II. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> **1.1. Đối với công tác quản lý**
>
> Hình thành nguồn tài liệu chuyên môn được lưu trữ tập trung, phân loại khoa học, thuận tiện trong tra cứu, cập nhật và khai thác; phục vụ công tác chỉ đạo, điều hành, kiểm tra, đánh giá và bồi dưỡng đội ngũ.
>
> Tăng cường quản lý, sử dụng hiệu quả các tài liệu, học liệu đã có; từng bước chuẩn hóa công tác lưu trữ và chia sẻ tài nguyên chuyên môn, góp phần thực hiện chuyển đổi số trong quản trị nhà trường.
>
> **1.2. Đối với đội ngũ giáo viên**
>
> Tạo môi trường trao đổi, chia sẻ và kế thừa những kinh nghiệm, sản phẩm chuyên môn có chất lượng; khuyến khích tinh thần tự học, tự bồi dưỡng và sáng tạo của giáo viên.
>
> Hỗ trợ giáo viên giảm thời gian tìm kiếm, chuẩn bị tài liệu, tập trung nhiều hơn cho việc quan sát, chăm sóc, tổ chức hoạt động và đánh giá sự phát triển của trẻ.
>
> **1.3. Đối với hoạt động giáo dục trẻ**
>
> Bổ sung nguồn học liệu phù hợp với từng độ tuổi, đáp ứng yêu cầu giáo dục lấy trẻ làm trung tâm, tăng cường cơ hội cho trẻ học thông qua chơi, thực hành, trải nghiệm và khám phá.
>
> Góp phần nâng cao chất lượng tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục, bảo đảm mọi nhóm, lớp có cơ hội tiếp cận nguồn học liệu phù hợp với điều kiện thực tế.
>
> ### 2. Yêu cầu
>
> - Kho tài liệu, học liệu phải được xây dựng trên cơ sở nhu cầu thực tế của nhà trường, giáo viên và trẻ; phù hợp với Chương trình giáo dục mầm non đang thực hiện tại đơn vị.
> - Tài liệu đưa vào sử dụng phải được lựa chọn, kiểm tra chất lượng, xác định rõ nguồn gốc và phạm vi sử dụng; bảo đảm tính khoa học, sư phạm, an toàn và phù hợp độ tuổi.
> - Việc phân loại, lưu trữ và khai thác phải đơn giản, dễ sử dụng, phù hợp với năng lực công nghệ thông tin của đội ngũ.
> - Kết hợp khai thác nguồn tài liệu sẵn có với xây dựng học liệu mới khi thực sự cần thiết; ưu tiên học liệu có khả năng sử dụng nhiều lần và điều chỉnh linh hoạt.
> - Bảo đảm phân quyền truy cập, an toàn thông tin, bảo vệ dữ liệu cá nhân và tôn trọng quyền tác giả.
> - Không yêu cầu giáo viên xây dựng sản phẩm hình thức, không phát sinh hồ sơ, báo cáo ngoài quy định; lồng ghép việc chia sẻ, đánh giá học liệu vào hoạt động chuyên môn thường xuyên.
> - Lấy chất lượng và hiệu quả khai thác thực tế làm căn cứ đánh giá kết quả thực hiện.
>
> ## III. MỤC TIÊU VÀ CHỈ TIÊU PHẤN ĐẤU
>
> ### 1. Mục tiêu chung
>
> Xây dựng và từng bước hoàn thiện kho tài liệu, học liệu dùng chung của nhà trường theo hướng khoa học, thiết thực, dễ tiếp cận, có cơ chế cập nhật và kiểm soát chất lượng; tạo điều kiện để cán bộ quản lý, giáo viên khai thác, chia sẻ và sử dụng thường xuyên, góp phần nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ và phát triển năng lực chuyên môn của đội ngũ.
>
> ### 2. Chỉ tiêu cụ thể
>
> **2.1. Về xây dựng và quản lý kho**
>
> - Hoàn thành việc khảo sát nhu cầu, rà soát các nguồn tài liệu, học liệu hiện có và điều kiện triển khai trong tháng 11/2026.
> - Đến tháng 12/2026, xây dựng và đưa vào vận hành 01 kho tài liệu, học liệu dùng chung cấp trường trên nền tảng phù hợp với điều kiện thực tế, có cấu trúc thư mục, danh mục tra cứu và phân quyền quản lý rõ ràng.
> - 100% tổ chuyên môn tham gia rà soát, lựa chọn, bổ sung và khai thác nguồn tài liệu theo nhiệm vụ được phân công.
>
> **2.2. Về phát triển học liệu**
>
> - 100% khối tuổi đang tổ chức tại trường có thư mục học liệu riêng, phù hợp với kế hoạch giáo dục và đặc điểm phát triển của trẻ.
> - Phấn đấu mỗi khối tuổi có tối thiểu 03 gói học liệu cốt lõi được lựa chọn từ nguồn hiện có hoặc xây dựng mới, bảo đảm chất lượng và khả năng áp dụng trước tháng 4/2027.
> - 100% học liệu được đưa vào danh mục sử dụng chính thức đáp ứng yêu cầu về nguồn gốc, nội dung, độ tuổi, an toàn và quy trình lựa chọn theo quy định áp dụng.
>
> **2.3. Về khai thác, sử dụng**
>
> - 100% cán bộ quản lý, giáo viên thuộc đối tượng sử dụng được hướng dẫn cách truy cập, tìm kiếm, khai thác và chia sẻ tài liệu.
> - Phấn đấu ít nhất 80% giáo viên sử dụng kho trong quá trình chuẩn bị hoặc tổ chức hoạt động chuyên môn sau giai đoạn triển khai thí điểm.
> - Phấn đấu ít nhất 70% số gói học liệu cốt lõi trong kho được giáo viên khai thác, vận dụng thực tế và có phản hồi về hiệu quả sử dụng trước khi kết thúc năm học.
>
> **2.4. Về hiệu quả quản lý**
>
> - Thực hiện rà soát, cập nhật và loại bỏ tài liệu không còn phù hợp theo định kỳ.
> - Bảo đảm tài liệu nội bộ, hình ảnh và thông tin cá nhân của trẻ được quản lý đúng phạm vi, không công khai trái quy định.
> - Cuối năm học tổ chức đánh giá hiệu quả sử dụng kho, xác định nội dung cần bổ sung, hoàn thiện để tiếp tục khai thác trong năm học 2027–2028.
>
> Các chỉ tiêu được điều chỉnh trên cơ sở kết quả khảo sát ban đầu, quy mô trường và khả năng thực hiện của từng tổ chuyên môn.
>
> ## IV. NỘI DUNG VÀ GIẢI PHÁP THỰC HIỆN
>
> ### 1. Khảo sát nhu cầu, rà soát nguồn tài liệu và điều kiện thực hiện
>
> Ban Giám hiệu chỉ đạo các tổ chuyên môn rà soát những tài liệu, học liệu đang được sử dụng tại nhóm, lớp; xác định nguồn tài liệu có giá trị cần lựa chọn, bảo quản và chia sẻ.
>
> Nội dung rà soát tập trung vào:
>
> - Nguồn tài liệu quản lý, kế hoạch chuyên môn, tài liệu bồi dưỡng, hướng dẫn nghiệp vụ hiện có.
> - Học liệu phục vụ tổ chức các hoạt động giáo dục: trò chơi, tranh ảnh, video, bài hát, thơ, truyện, hướng dẫn làm đồ dùng, tổ chức hoạt động trải nghiệm và các tài liệu phù hợp khác.
> - Những nội dung giáo viên thường xuyên cần tìm kiếm hoặc còn thiếu học liệu phù hợp.
> - Điều kiện về thiết bị, đường truyền Internet, tài khoản sử dụng và khả năng ứng dụng công nghệ thông tin của đội ngũ.
>
> Trên cơ sở rà soát, xác định rõ nguồn tài liệu có thể sử dụng ngay, tài liệu cần chỉnh sửa, tài liệu không phù hợp và các nội dung cần bổ sung.
>
> **Giải pháp thực hiện:** Ưu tiên khai thác tài liệu sẵn có trước khi xây dựng mới; sử dụng kết quả rà soát để lựa chọn nội dung ưu tiên, tránh đầu tư dàn trải và trùng lặp. Việc tổng hợp được thực hiện qua sinh hoạt tổ chuyên môn và dữ liệu quản lý hiện có, không lập thêm hồ sơ không cần thiết.
>
> ### 2. Thiết lập cấu trúc kho tài liệu, học liệu dùng chung
>
> Kho tài liệu, học liệu được tổ chức trên nền tảng lưu trữ số được nhà trường lựa chọn và cho phép sử dụng; trường hợp cần thiết, có thể kết hợp danh mục số với việc quản lý đồ dùng, học liệu trực quan tại các lớp hoặc phòng học liệu.
>
> Dự kiến phân thành các nhóm chính:
>
> **Nhóm 1. Tài liệu chỉ đạo, quản lý và điều hành**
>
> Gồm văn bản chỉ đạo, hướng dẫn chuyên môn; kế hoạch năm học, kế hoạch chuyên đề; biểu mẫu nghiệp vụ được phép chia sẻ và các tài liệu phục vụ quản lý nhà trường.
>
> **Nhóm 2. Tài liệu chuyên môn và bồi dưỡng đội ngũ**
>
> Gồm tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non; nội dung sinh hoạt chuyên môn, chuyên đề bồi dưỡng; tài liệu về đổi mới phương pháp giáo dục, giáo dục hòa nhập, giáo dục lấy trẻ làm trung tâm, an toàn trường học và các tài liệu hỗ trợ chuyên môn khác.
>
> **Nhóm 3. Học liệu theo độ tuổi**
>
> Phân theo những nhóm, khối lớp thực tế của nhà trường: nhà trẻ, mẫu giáo 3–4 tuổi, 4–5 tuổi, 5–6 tuổi.
>
> Trong từng khối tuổi, học liệu tiếp tục được phân loại theo lĩnh vực phát triển, nội dung giáo dục hoặc chủ đề phù hợp để thuận tiện tra cứu, lựa chọn và sử dụng.
>
> **Nhóm 4. Học liệu phục vụ chăm sóc, nuôi dưỡng và giáo dục kỹ năng**
>
> Gồm học liệu giáo dục dinh dưỡng, vệ sinh cá nhân, kỹ năng tự phục vụ, bảo vệ sức khỏe, phòng tránh tai nạn thương tích, bảo vệ môi trường và các nội dung cần thiết khác.
>
> Các tài liệu có thông tin sức khỏe, hoàn cảnh cá nhân của trẻ không được đưa vào kho dùng chung không hạn chế; phải quản lý riêng theo quy định bảo vệ dữ liệu cá nhân.
>
> **Nhóm 5. Học liệu thực hành, trải nghiệm và nguồn lực địa phương**
>
> Gồm hướng dẫn tổ chức trò chơi dân gian, hoạt động trải nghiệm, khám phá thiên nhiên, sử dụng vật liệu sẵn có tại địa phương; hình ảnh và mô tả những đồ dùng, đồ chơi tự tạo bảo đảm an toàn và có giá trị sử dụng.
>
> **Nhóm 6. Tài liệu phối hợp với cha mẹ trẻ**
>
> Gồm các tài liệu tuyên truyền, hướng dẫn chăm sóc, nuôi dưỡng, giáo dục trẻ tại gia đình đã được kiểm tra, phê duyệt về nội dung và phạm vi chia sẻ.
>
> **Giải pháp thực hiện:** Sắp xếp thư mục thống nhất, tên tài liệu ngắn gọn, dễ hiểu, có thông tin độ tuổi, nội dung và phiên bản khi cần thiết. Tài liệu nội bộ và học liệu được phép phổ biến phải được phân quyền riêng. Không tạo quá nhiều thư mục nhỏ gây khó khăn trong sử dụng.
>
> ### 3. Lựa chọn, chuẩn hóa và bổ sung tài liệu, học liệu
>
> Việc phát triển kho được thực hiện theo nguyên tắc **chọn lọc từ nguồn hiện có là chủ yếu, bổ sung có trọng tâm, xây dựng mới trên cơ sở nhu cầu sử dụng thực tế**.
>
> Nguồn tài liệu được lựa chọn gồm tài liệu hướng dẫn chính thức của ngành; tài liệu do nhà trường xây dựng; các sản phẩm chuyên môn của giáo viên có chất lượng; học liệu từ nguồn hợp pháp, được phép khai thác và sử dụng.
>
> Ưu tiên những học liệu:
>
> - Phù hợp mục tiêu, nội dung Chương trình giáo dục mầm non và đặc điểm phát triển của trẻ.
> - Hỗ trợ trẻ hoạt động tích cực thông qua vui chơi, thao tác, thực hành, trải nghiệm.
> - Có tính mở, dễ điều chỉnh theo số lượng trẻ, điều kiện nhóm lớp và khả năng của từng trẻ.
> - Có thể sử dụng lặp lại, chia sẻ giữa các lớp và phát huy giá trị lâu dài.
> - Khai thác phù hợp điều kiện tự nhiên, văn hóa và nguồn vật liệu tại địa phương.
>
> Mỗi gói học liệu cốt lõi cần thể hiện những thông tin cơ bản: tên học liệu; độ tuổi sử dụng; mục tiêu giáo dục; thành phần học liệu; hướng dẫn khai thác; lưu ý an toàn; nguồn tài liệu, tác giả và tình trạng phê duyệt.
>
> **Giải pháp thực hiện:** Phân công tổ chuyên môn lựa chọn một số nội dung thiết thực, đã được giáo viên vận dụng hiệu quả để xây dựng học liệu mẫu. Khuyến khích giáo viên cùng hoàn thiện sản phẩm, không giao chỉ tiêu sản xuất hàng loạt bài trình chiếu, video hoặc đồ dùng khi chưa xác định được nhu cầu sử dụng.
>
> ### 4. Xây dựng quy trình tiếp nhận, kiểm tra và đưa học liệu vào sử dụng
>
> Việc quản lý chất lượng tài liệu, học liệu được thực hiện theo quy trình thống nhất:
>
> **Bước 1. Đề xuất và tiếp nhận**
>
> Giáo viên, tổ chuyên môn đề xuất tài liệu, học liệu từ nhu cầu tổ chức hoạt động giáo dục; xác định rõ mục đích sử dụng, nguồn gốc và nhóm tuổi phù hợp.
>
> **Bước 2. Rà soát chuyên môn**
>
> Tổ trưởng chuyên môn phối hợp với giáo viên cốt cán kiểm tra nội dung, tính khoa học, khả năng sử dụng, mức độ an toàn và những điều kiện cần thiết trước khi đề xuất đưa vào kho.
>
> **Bước 3. Lựa chọn, phê duyệt**
>
> Đối với đồ chơi, học liệu được lựa chọn để sử dụng trong cơ sở giáo dục mầm non thuộc phạm vi Thông tư số 60/2026/TT-BGDĐT, nhà trường thực hiện thông qua Hội đồng lựa chọn đồ chơi, học liệu và quy trình phê duyệt theo quy định.
>
> Hội đồng do Hiệu trưởng thành lập, bảo đảm thành phần, số lượng thành viên và nguyên tắc hoạt động theo quy định. Danh mục được lựa chọn phải có ít nhất 3/4 tổng số thành viên Hội đồng biểu quyết đồng ý trước khi trình Hiệu trưởng phê duyệt.
>
> Đối với các tài liệu quản lý, tài liệu làm việc nội bộ không thuộc phạm vi lựa chọn nêu trên, việc kiểm tra và phê duyệt thực hiện theo phân công của Ban Giám hiệu.
>
> **Bước 4. Phân loại và cập nhật**
>
> Tài liệu đủ điều kiện được đưa vào thư mục phù hợp, có thông tin cơ bản để tra cứu. Tài liệu chưa đạt yêu cầu được đề nghị điều chỉnh hoặc không đưa vào danh mục sử dụng chính thức.
>
> **Bước 5. Khai thác và phản hồi**
>
> Giáo viên lựa chọn, vận dụng tài liệu vào kế hoạch và hoạt động thực tế; trao đổi những ưu điểm, hạn chế, đề xuất điều chỉnh trong sinh hoạt chuyên môn.
>
> **Bước 6. Điều chỉnh, hoàn thiện**
>
> Định kỳ rà soát, bổ sung, thay thế hoặc loại bỏ tài liệu không còn phù hợp. Những sản phẩm phát huy hiệu quả được ưu tiên duy trì và chia sẻ rộng hơn trong phạm vi được phép.
>
> Để giảm thủ tục, việc lựa chọn học liệu có thể được tổ chức theo danh mục, theo đợt phù hợp; không yêu cầu giáo viên lập hồ sơ riêng cho từng lần khai thác tài liệu đã được phê duyệt.
>
> ### 5. Tổ chức hướng dẫn và nâng cao năng lực khai thác kho
>
> Ban Giám hiệu tổ chức hướng dẫn giáo viên sử dụng kho tài liệu thông qua sinh hoạt chuyên môn hoặc hoạt động bồi dưỡng phù hợp.
>
> Nội dung tập trung vào kỹ năng truy cập, tìm kiếm, lưu trữ, chia sẻ; cách sử dụng tài liệu đúng phạm vi; kỹ năng lựa chọn, điều chỉnh học liệu và bảo vệ dữ liệu cá nhân.
>
> Phát huy vai trò giáo viên có năng lực công nghệ thông tin trong việc hỗ trợ đồng nghiệp, đặc biệt là giáo viên còn hạn chế kỹ năng số.
>
> **Giải pháp thực hiện:** Áp dụng phương thức hướng dẫn trực tiếp trên sản phẩm và thao tác thực tế; có tài liệu hướng dẫn ngắn gọn, dễ thực hiện. Khuyến khích giáo viên hỗ trợ nhau theo tổ, khối, không gây áp lực về kỹ năng hoặc thời gian tự học ngoài nhiệm vụ được giao.
>
> ### 6. Gắn khai thác kho học liệu với sinh hoạt chuyên môn
>
> Xác định đây là giải pháp trọng tâm để kho tài liệu thực sự phát huy hiệu quả.
>
> Các tổ chuyên môn lồng ghép việc giới thiệu, chia sẻ và trao đổi kinh nghiệm sử dụng học liệu vào nội dung sinh hoạt chuyên môn định kỳ.
>
> Khuyến khích giáo viên lựa chọn học liệu đã có trong kho để vận dụng, quan sát phản ứng của trẻ, đánh giá mức độ phù hợp và đề xuất cải tiến. Trong quá trình chia sẻ, tập trung làm rõ học liệu đã hỗ trợ hoạt động của trẻ như thế nào, những khó khăn khi sử dụng và điều kiện để giáo viên khác có thể áp dụng.
>
> Nhà trường ưu tiên phổ biến những cách làm hiệu quả, có khả năng nhân rộng; không lấy số lượng tài liệu được đăng tải làm tiêu chí duy nhất đánh giá chất lượng hoạt động chuyên môn hoặc mức độ hoàn thành nhiệm vụ của giáo viên.
>
> ### 7. Bảo đảm an toàn thông tin và duy trì hoạt động của kho
>
> Phân công cán bộ, giáo viên phụ trách quản lý tài khoản, cấu trúc thư mục, phân quyền truy cập và hỗ trợ xử lý sự cố.
>
> Ưu tiên sử dụng nền tảng được cơ quan có thẩm quyền hoặc nhà trường cho phép; sử dụng tài khoản do đơn vị kiểm soát, tránh phụ thuộc vào tài khoản cá nhân của một giáo viên.
>
> Thực hiện sao lưu dữ liệu định kỳ, kiểm soát quyền chỉnh sửa, xóa tài liệu và thu hồi quyền truy cập khi nhân sự thay đổi vị trí hoặc không còn công tác tại trường.
>
> Không tự ý đăng tải hình ảnh, video, thông tin nhận diện và dữ liệu cá nhân của trẻ lên kho dùng chung hoặc chia sẻ ra bên ngoài khi chưa đáp ứng đầy đủ điều kiện pháp luật. Không sao chép, phân phối tài liệu có bản quyền trái phép.
>
> Trường hợp đường truyền Internet không ổn định, tổ chuyên môn chủ động chuẩn bị bản học liệu ngoại tuyến được phép sử dụng để không ảnh hưởng đến việc tổ chức hoạt động giáo dục.
>
> ## V. TIẾN ĐỘ THỰC HIỆN
>
> | Thời gian | Nội dung trọng tâm | Kết quả cần đạt |
> |---|---|---|
> | **Tháng 11/2026** | Triển khai kế hoạch; khảo sát thực trạng, nhu cầu; rà soát nguồn tài liệu và điều kiện thiết bị; phân công nhiệm vụ | Xác định nhu cầu, nguồn học liệu hiện có và danh mục ưu tiên |
> | **Tháng 12/2026** | Thiết lập cấu trúc kho; phân quyền; hướng dẫn giáo viên; lựa chọn và cập nhật các tài liệu ban đầu | Kho dùng chung được đưa vào vận hành; giáo viên biết cách truy cập và khai thác |
> | **Tháng 01–02/2027** | Tiếp tục chọn lọc, bổ sung học liệu theo khối tuổi; tổ chức sử dụng thử, chia sẻ kinh nghiệm trong sinh hoạt chuyên môn | Có học liệu phù hợp từng khối tuổi và phản hồi thực tế |
> | **Tháng 3/2027** | Rà soát chất lượng, bổ sung các học liệu còn thiếu; ưu tiên hoàn thiện các gói học liệu cốt lõi | Từng khối tuổi cơ bản hoàn thành danh mục học liệu ưu tiên |
> | **Tháng 4/2027** | Đẩy mạnh khai thác, kiểm tra hiệu quả sử dụng; điều chỉnh, thay thế tài liệu chưa phù hợp | Nâng cao chất lượng và mức độ sử dụng học liệu |
> | **Tháng 5/2027** | Đánh giá, tổng kết, chuẩn hóa và lưu trữ; đề xuất hướng phát triển cho năm học tiếp theo | Kho tài liệu được hoàn thiện bước đầu; có kết quả đánh giá và định hướng duy trì |
>
> Tiến độ trên được triển khai từ thời điểm ban hành kế hoạch. Những tài liệu đã hình thành từ đầu năm học 2026–2027 được rà soát, lựa chọn để bổ sung vào kho khi bảo đảm yêu cầu.
>
> ## VI. PHÂN CÔNG TRÁCH NHIỆM
>
> ### 1. Hiệu trưởng
>
> Chịu trách nhiệm chỉ đạo chung việc xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung.
>
> Ban hành kế hoạch, phân công nhiệm vụ; thành lập Hội đồng lựa chọn đồ chơi, học liệu theo quy định; phê duyệt các nội dung thuộc thẩm quyền.
>
> Chỉ đạo bố trí điều kiện thực hiện, kiểm tra tiến độ, kịp thời tháo gỡ khó khăn và đánh giá hiệu quả triển khai.
>
> ### 2. Phó Hiệu trưởng phụ trách chuyên môn
>
> Trực tiếp tham mưu, tổ chức triển khai kế hoạch; hướng dẫn các tổ chuyên môn rà soát, lựa chọn, chuẩn hóa tài liệu, học liệu.
>
> Phối hợp tổ trưởng chuyên môn kiểm tra chất lượng nội dung; theo dõi mức độ khai thác, sử dụng; đề xuất điều chỉnh, bổ sung phù hợp.
>
> Tổng hợp kết quả thực hiện, tham mưu Hiệu trưởng đánh giá và định hướng phát triển kho.
>
> ### 3. Tổ trưởng chuyên môn
>
> Tổ chức cho giáo viên trong tổ rà soát nhu cầu, lựa chọn và chia sẻ những tài liệu, học liệu có giá trị sử dụng thực tế.
>
> Phối hợp kiểm tra, phân loại tài liệu trước khi đề xuất đưa vào kho; tổ chức trao đổi kinh nghiệm sử dụng học liệu trong sinh hoạt chuyên môn.
>
> Theo dõi những khó khăn trong quá trình khai thác, kịp thời đề xuất giải pháp hỗ trợ giáo viên.
>
> ### 4. Giáo viên các nhóm, lớp
>
> Chủ động khai thác nguồn tài liệu phù hợp với kế hoạch giáo dục, điều kiện nhóm lớp và đặc điểm của trẻ.
>
> Chia sẻ những sản phẩm, kinh nghiệm chuyên môn có chất lượng, nguồn gốc rõ ràng, được phép sử dụng; tham gia góp ý, điều chỉnh học liệu khi cần thiết.
>
> Sử dụng học liệu linh hoạt, không sao chép máy móc, không thay thế hoạt động trải nghiệm trực tiếp của trẻ bằng việc sử dụng thiết bị điện tử không phù hợp.
>
> ### 5. Nhân sự phụ trách công nghệ thông tin
>
> Tham mưu lựa chọn, thiết lập và quản lý nền tảng lưu trữ; phối hợp phân quyền tài khoản, hướng dẫn giáo viên sử dụng.
>
> Thực hiện các biện pháp bảo mật, sao lưu dữ liệu; hỗ trợ xử lý khó khăn về kỹ thuật trong quá trình vận hành.
>
> ### 6. Các bộ phận liên quan
>
> Nhân viên y tế, nuôi dưỡng và các bộ phận có liên quan phối hợp cung cấp những tài liệu chuyên môn phù hợp với nhiệm vụ, bảo đảm nội dung được kiểm tra trước khi chia sẻ.
>
> Bộ phận tài chính, kế toán tham mưu bố trí kinh phí thực hiện theo khả năng cân đối ngân sách, dự toán được phê duyệt và các quy định hiện hành.
>
> ## VII. ĐIỀU KIỆN BẢO ĐẢM VÀ KINH PHÍ
>
> ### 1. Về nhân lực
>
> Sử dụng lực lượng cán bộ quản lý, tổ trưởng chuyên môn, giáo viên cốt cán và nhân sự có năng lực công nghệ thông tin hiện có; phân công phù hợp vị trí việc làm và nhiệm vụ chuyên môn.
>
> Không thành lập thêm bộ phận trung gian khi không cần thiết; phát huy cơ chế phối hợp trong tổ chuyên môn và các bộ phận của nhà trường.
>
> ### 2. Về cơ sở vật chất và công nghệ
>
> Ưu tiên sử dụng máy tính, đường truyền Internet, thiết bị lưu trữ và nền tảng số hiện có; từng bước bổ sung trên cơ sở nhu cầu thực tế và khả năng kinh phí.
>
> Đối với nhóm, lớp có hạn chế về thiết bị hoặc kết nối, bố trí phương án hỗ trợ khai thác học liệu thông qua máy tính dùng chung hoặc bản lưu trữ phù hợp.
>
> ### 3. Về kinh phí
>
> Kinh phí thực hiện được cân đối trong nguồn kinh phí hoạt động hợp pháp của nhà trường theo dự toán, khả năng tài chính và quy định hiện hành.
>
> Ưu tiên kinh phí cho những nhiệm vụ cần thiết như bảo đảm hạ tầng lưu trữ, an toàn dữ liệu và hỗ trợ kỹ thuật; hạn chế mua sắm phần mềm, thiết bị không phù hợp với nhu cầu.
>
> Việc huy động, tiếp nhận nguồn hỗ trợ hợp pháp, nếu có, thực hiện công khai, minh bạch, tự nguyện và đúng quy định; không tạo thêm gánh nặng cho cha mẹ trẻ.
>
> ## VIII. KIỂM TRA, ĐÁNH GIÁ KẾT QUẢ
>
> ### 1. Nội dung kiểm tra
>
> Ban Giám hiệu kết hợp kiểm tra việc xây dựng và khai thác kho với công tác quản lý, kiểm tra chuyên môn thường xuyên.
>
> Tập trung vào những nội dung: mức độ hoàn thiện cấu trúc kho; chất lượng và sự phù hợp của học liệu; việc thực hiện quy trình lựa chọn, phê duyệt; khả năng tiếp cận của giáo viên; hiệu quả sử dụng thực tế và công tác bảo mật dữ liệu.
>
> ### 2. Phương pháp đánh giá
>
> Kết hợp rà soát danh mục tài liệu, kiểm tra mẫu học liệu, trao đổi với giáo viên và quan sát hoạt động giáo dục thực tế.
>
> Ưu tiên sử dụng thông tin sẵn có trong kế hoạch giáo dục, sinh hoạt chuyên môn và hoạt động quản lý để đánh giá; không yêu cầu giáo viên lập thêm hồ sơ minh chứng riêng chỉ để chứng minh số lượt sử dụng học liệu.
>
> ### 3. Tiêu chí đánh giá hiệu quả
>
> Việc đánh giá tập trung vào ba nhóm kết quả:
>
> **Thứ nhất, chất lượng kho:** Tài liệu được phân loại rõ ràng, có nguồn gốc, được kiểm tra, cập nhật, dễ tìm kiếm và phù hợp với nhiệm vụ chuyên môn.
>
> **Thứ hai, hiệu quả sử dụng:** Giáo viên có khả năng khai thác thuận lợi, chủ động lựa chọn, điều chỉnh và sử dụng học liệu trong hoạt động thực tế.
>
> **Thứ ba, tác động chuyên môn:** Học liệu hỗ trợ cải thiện chất lượng tổ chức hoạt động; giảm sự trùng lặp trong chuẩn bị tài liệu, tăng cơ hội chia sẻ kinh nghiệm và phát huy tính tích cực, chủ động của trẻ.
>
> Kết quả kiểm tra, đánh giá được sử dụng để hỗ trợ giáo viên và cải tiến hoạt động, không tạo áp lực thành tích về số lượng tài liệu.
>
> ## IX. TỔ CHỨC THỰC HIỆN
>
> Hiệu trưởng triển khai kế hoạch đến toàn thể cán bộ quản lý, giáo viên và các bộ phận có liên quan; chỉ đạo thực hiện thống nhất, phù hợp điều kiện của nhà trường.
>
> Phó Hiệu trưởng phụ trách chuyên môn căn cứ kế hoạch cụ thể hóa các nội dung theo từng giai đoạn; thường xuyên kiểm tra, hướng dẫn, hỗ trợ tổ chuyên môn và giáo viên trong quá trình thực hiện.
>
> Các tổ chuyên môn chủ động xây dựng nội dung triển khai phù hợp nhiệm vụ, nhu cầu và điều kiện thực tế của tổ; phát huy vai trò của giáo viên cốt cán, khuyến khích tinh thần hợp tác, chia sẻ và sử dụng hiệu quả nguồn học liệu.
>
> Trong quá trình thực hiện, nếu phát sinh khó khăn về nhân lực, thiết bị, nền tảng công nghệ hoặc chất lượng học liệu, các bộ phận kịp thời phản ánh để Ban Giám hiệu xem xét, điều chỉnh; bảo đảm kế hoạch được thực hiện linh hoạt, không ảnh hưởng đến hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Cuối năm học, nhà trường tổ chức đánh giá kết quả xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung; xác định những nội dung có hiệu quả để tiếp tục phát huy, những hạn chế cần khắc phục và nhiệm vụ ưu tiên trong năm học tiếp theo.
>
> **Xây dựng kho tài liệu, học liệu dùng chung là nhiệm vụ có tính kế thừa và phát triển lâu dài, không chỉ nhằm tập hợp tài liệu trong một năm học mà hướng tới hình thành nguồn tài nguyên chuyên môn có chất lượng của nhà trường.** Việc triển khai cần phát huy trách nhiệm quản lý, tinh thần hợp tác của đội ngũ và lấy hiệu quả hỗ trợ giáo viên, nâng cao chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ làm thước đo chủ yếu.
>
> Trên đây là Kế hoạch xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 của Trường Mầm non [Tên trường]. Đề nghị các tổ chuyên môn, cán bộ, giáo viên và các bộ phận có liên quan nghiêm túc triển khai thực hiện.
>
> **Nơi nhận:**
> - Các tổ chuyên môn, bộ phận liên quan (thực hiện);
> - Ban Giám hiệu (chỉ đạo);
> - Lưu: VT, CM.
>
> **HIỆU TRƯỞNG**  
> *(Ký, ghi rõ họ tên và đóng dấu)*

## 💡 Một số lưu ý quản lý trước khi ban hành

Tôi đề xuất nhà trường ưu tiên ba yếu tố quyết định thành công của kế hoạch: **có người chịu trách nhiệm quản lý kho; có học liệu được kiểm soát chất lượng; có minh chứng về việc giáo viên thực sự khai thác, sử dụng.**

Đặc biệt, Thông tư 60/2026/TT-BGDĐT đã quy định cụ thể về Hội đồng và quy trình lựa chọn đồ chơi, học liệu. Nhà trường cần thực hiện đúng phạm vi quy định này, đồng thời tránh biến việc cập nhật kho tài liệu nội bộ thành thủ tục hành chính phức tạp. [Thông tư 60/2026/TT\-BGDĐT biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non mới nhất](<https://thuvienphapluat.vn/van-ban/Giao-duc/Thong-tu-60-2026-TT-BGDDT-bien-soan-tai-lieu-huong-dan-thuc-hien-Chuong-trinh-giao-duc-mam-non-714818.aspx?anchor=dieu_10>)

Về chỉ tiêu, tôi không đề xuất bắt buộc mỗi giáo viên phải làm nhiều video hoặc bài giảng số mỗi tháng. Cách giao nhiệm vụ phù hợp hơn là **mỗi tổ chuyên môn cùng xây dựng và khai thác một số gói học liệu thật sự hữu ích**, sử dụng được nhiều lần và có thể kế thừa qua các năm học.

Trước khi ký ban hành, cần bổ sung chính xác số nhóm lớp, số giáo viên, số điểm trường, hiện trạng thiết bị và kho tài liệu đã có. Đây là những dữ liệu quan trọng nhất để kế hoạch thuyết phục và thực sự sát điều kiện của đơn vị.

---

USER

Bạn xem lại giúp mình cấu trúc kế hoạch. Về đặc điểm tình hình bạn nêu giúp mình nội dung tình hình sau sáp nhập 3 trường để nêu bật được việc quan trọng cần xây dựng kho học liệu  dùng chung

---

ASSISTANT

Tôi sẽ chỉnh lại bố cục để việc sáp nhập 3 trường trở thành căn cứ xuyên suốt kế hoạch, không chỉ là một ý bổ sung ở phần mở đầu. Trọng tâm sẽ là thống nhất quản lý nguồn học liệu của ba đơn vị cũ, phát huy tài nguyên sẵn có và bảo đảm giáo viên ở các điểm trường đều được tiếp cận, sử dụng thuận lợi.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

## 📌 1. Đề xuất điều chỉnh cấu trúc kế hoạch

Sau khi xem xét bản kế hoạch trước và bổ sung thông tin nhà trường được sáp nhập từ **3 trường mầm non**, tôi nhận thấy cần điều chỉnh cách lập luận để kế hoạch thể hiện rõ đặc thù quản lý của đơn vị sau sáp nhập.

**Điểm quan trọng nhất:** Xây dựng kho tài liệu, học liệu dùng chung không đơn thuần là nhiệm vụ ứng dụng công nghệ thông tin, mà là một giải pháp quản trị chuyên môn nhằm thống nhất nguồn lực, kết nối đội ngũ và từng bước nâng cao chất lượng giáo dục đồng đều giữa các điểm trường.

Tôi đề xuất giữ bố cục hành chính của kế hoạch nhưng điều chỉnh trọng tâm như sau:

| Phần | Trọng tâm cần thể hiện |
|--------|--------|
| I. Đặc điểm tình hình và sự cần thiết | Làm rõ bối cảnh sau sáp nhập 3 trường, thuận lợi, khó khăn và yêu cầu cấp thiết phải có kho dùng chung |
| II. Mục đích, yêu cầu | Thống nhất quản lý, chia sẻ nguồn lực, giảm trùng lặp, hỗ trợ giáo viên |
| III. Mục tiêu, chỉ tiêu | Có một kho dùng chung cấp trường; bảo đảm các tổ, khối và điểm trường tiếp cận được |
| IV. Nội dung, giải pháp | Rà soát nguồn của 3 trường cũ; lựa chọn, chuẩn hóa, lưu trữ, phân quyền và khai thác |
| V–IX. Tổ chức triển khai | Tiến độ, phân công, nguồn lực, kiểm tra, đánh giá và duy trì |

Ở phần đặc điểm tình hình, nên thể hiện **hai mặt của quá trình sáp nhập**: nguồn học liệu, kinh nghiệm chuyên môn của ba trường được tập hợp tạo nên lợi thế mới; đồng thời, phương thức lưu trữ, quản lý và chia sẻ vốn hình thành riêng ở từng đơn vị cần được rà soát và thống nhất.

Cách trình bày này làm nổi bật sự cần thiết của kế hoạch mà không quy kết rằng đội ngũ các trường cũ làm việc thiếu hiệu quả. Đồng thời, phù hợp định hướng bảo đảm chất lượng giáo dục tại tất cả các điểm trường sau tổ chức lại được Bộ Giáo dục và Đào tạo nhấn mạnh trong hướng dẫn năm học 2026–2027. [Bộ Giáo dục và Đào tạo hướng dẫn thực hiện nhiệm vụ quản lý chất lượng năm học 2026–2027](<https://vqa.moet.gov.vn/vi/news/tin-tuc-su-kien/bo-gddt-huong-dan-thuc-hien-nhiem-vu-quan-ly-chat-luong-nam-hoc-2026-2027-294.html>)

Dưới đây là bản kế hoạch được chỉnh sửa theo hướng đó, trong đó **Phần I được viết lại có chiều sâu hơn**, còn các mục tiếp theo được liên kết chặt chẽ với bối cảnh sáp nhập.

## 📖 2. Dự thảo kế hoạch điều chỉnh

> **writing · document**
>
> **ỦY BAN NHÂN DÂN [XÃ/PHƯỜNG]**  
> **TRƯỜNG MẦM NON [TÊN TRƯỜNG]**
>
> Số: …/KH-MN…
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *[Địa danh], ngày … tháng 11 năm 2026*
>
> # KẾ HOẠCH
> **Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027**
>
> Căn cứ Luật Giáo dục số 43/2019/QH14 và các văn bản sửa đổi, bổ sung có liên quan;
>
> Căn cứ Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020 của Bộ Giáo dục và Đào tạo ban hành Điều lệ trường mầm non và Thông tư số 51/2026/TT-BGDĐT ngày 30/6/2026 sửa đổi, bổ sung một số điều của Điều lệ trường mầm non;
>
> Căn cứ Thông tư số 60/2026/TT-BGDĐT ngày 17/7/2026 của Bộ Giáo dục và Đào tạo quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non;
>
> Căn cứ Công văn số 5385/BGDĐT-GDMN ngày 12/8/2026 của Bộ Giáo dục và Đào tạo về hướng dẫn thực hiện nhiệm vụ giáo dục mầm non năm học 2026–2027;
>
> Căn cứ Quyết định số …/QĐ-… ngày …/…/2026 của … về việc sáp nhập ba trường mầm non …, …, … thành Trường Mầm non …;
>
> Căn cứ Kế hoạch thực hiện nhiệm vụ năm học 2026–2027 của Trường Mầm non …;
>
> Xuất phát từ yêu cầu kiện toàn tổ chức, thống nhất công tác quản lý chuyên môn và sử dụng hiệu quả các nguồn lực giáo dục sau sáp nhập, Trường Mầm non … xây dựng Kế hoạch xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 với những nội dung sau:
>
> ## I. ĐẶC ĐIỂM TÌNH HÌNH VÀ SỰ CẦN THIẾT
>
> ### 1. Đặc điểm tình hình sau sáp nhập
>
> Năm học 2026–2027 là giai đoạn quan trọng trong việc ổn định tổ chức, kiện toàn công tác quản lý và nâng cao chất lượng hoạt động của nhà trường sau khi thực hiện sáp nhập từ ba trường mầm non thành một đơn vị giáo dục thống nhất.
>
> Việc sáp nhập tạo điều kiện tập trung nguồn lực về đội ngũ, cơ sở vật chất, trang thiết bị, tài liệu chuyên môn và học liệu của ba đơn vị trước đây; đồng thời đặt ra yêu cầu đổi mới phương thức quản lý, tăng cường sự phối hợp, thống nhất trong chỉ đạo và tổ chức thực hiện nhiệm vụ nuôi dưỡng, chăm sóc, giáo dục trẻ trên toàn trường.
>
> Trước khi sáp nhập, mỗi trường có quá trình xây dựng, tích lũy và sử dụng nguồn tài liệu, học liệu phục vụ hoạt động chuyên môn theo điều kiện thực tế của đơn vị. Các nguồn tài liệu này được hình thành qua nhiều năm học, bao gồm tài liệu hướng dẫn chuyên môn, kế hoạch giáo dục, nội dung bồi dưỡng giáo viên, học liệu số, tranh ảnh, video, trò chơi, đồ dùng, đồ chơi tự tạo và những kinh nghiệm tổ chức hoạt động giáo dục có giá trị thực tiễn.
>
> Sau sáp nhập, những nguồn lực đó trở thành tài sản chuyên môn chung, cần được kế thừa, lựa chọn và phát huy hiệu quả. Tuy nhiên, để đáp ứng yêu cầu quản lý của một đơn vị có quy mô và phạm vi hoạt động rộng hơn, nhà trường cần rà soát, kết nối và thống nhất phương thức quản lý, lưu trữ, khai thác các nguồn tài liệu vốn được hình thành tại ba trường trước đây.
>
> Đây là nhiệm vụ cần được quan tâm ngay trong giai đoạn đầu sau sáp nhập, nhằm bảo đảm sự thống nhất về định hướng chuyên môn, tạo điều kiện cho giáo viên giữa các tổ, khối và điểm trường được chia sẻ nguồn học liệu, trao đổi kinh nghiệm, đồng thời phát huy những thế mạnh riêng của từng đơn vị trước đây.
>
> ### 2. Thuận lợi
>
> Việc sáp nhập ba trường tạo điều kiện để nhà trường tập hợp đội ngũ cán bộ quản lý, giáo viên có kinh nghiệm, năng lực và thế mạnh chuyên môn khác nhau; hình thành nguồn lực thuận lợi cho hoạt động trao đổi, học hỏi và hỗ trợ đồng nghiệp.
>
> Nguồn tài liệu, học liệu được tích lũy từ ba đơn vị là cơ sở quan trọng để xây dựng kho dùng chung mà không phải bắt đầu hoàn toàn từ việc tạo lập tài liệu mới. Những sản phẩm đã được sử dụng hiệu quả có thể tiếp tục được chọn lọc, hoàn thiện và chia sẻ trong phạm vi toàn trường.
>
> Cơ chế quản lý tập trung sau sáp nhập tạo điều kiện thuận lợi cho việc thống nhất quy định, phân công trách nhiệm, tổ chức sinh hoạt chuyên môn theo khối tuổi, lựa chọn học liệu và triển khai các giải pháp ứng dụng công nghệ thông tin.
>
> Việc xây dựng kho học liệu dùng chung phù hợp với yêu cầu đổi mới công tác quản trị nhà trường, chuyển đổi số và nâng cao chất lượng giáo dục mầm non trong giai đoạn hiện nay.
>
> ### 3. Khó khăn và những vấn đề đặt ra
>
> Bên cạnh những thuận lợi, quá trình tổ chức lại nhà trường từ ba đơn vị độc lập đặt ra một số vấn đề cần được quan tâm giải quyết:
>
> **Thứ nhất, về quản lý và lưu trữ tài liệu, học liệu.** Nguồn tài liệu của ba trường trước sáp nhập được xây dựng và lưu trữ theo từng đơn vị. Nếu chưa được kiểm kê, phân loại và kết nối thành hệ thống thống nhất, việc tìm kiếm, lựa chọn và khai thác tài liệu có thể gặp khó khăn; đồng thời có nguy cơ trùng lặp, phân tán hoặc chưa tận dụng hết giá trị của những sản phẩm chuyên môn đã có.
>
> **Thứ hai, về sự thống nhất trong hoạt động chuyên môn.** Quá trình sáp nhập đòi hỏi nhà trường từng bước thống nhất cách thức xây dựng, quản lý và chia sẻ tài liệu phục vụ thực hiện Chương trình giáo dục mầm non. Trong khi đó, đội ngũ giáo viên đến từ các đơn vị khác nhau có thể có kinh nghiệm, phương pháp tổ chức hoạt động, thói quen sử dụng tài liệu và năng lực ứng dụng công nghệ thông tin chưa đồng đều. Điều này đặt ra yêu cầu cần có cơ chế chia sẻ, hỗ trợ và phát huy thế mạnh chuyên môn của từng cá nhân.
>
> **Thứ ba, về điều kiện tiếp cận và sử dụng học liệu.** Khi hoạt động giáo dục được tổ chức tại các cơ sở, điểm trường khác nhau, việc tiếp cận nguồn tài liệu và học liệu cần được bảo đảm thuận tiện, phù hợp với điều kiện thực tế. Nếu chưa có danh mục và phương thức chia sẻ thống nhất, giáo viên có thể phải tự tìm kiếm, xây dựng lại những học liệu đã có ở nhóm, lớp hoặc điểm trường khác, làm tăng thời gian chuẩn bị và chưa phát huy hiệu quả nguồn lực chung.
>
> **Thứ tư, về yêu cầu bảo đảm chất lượng giáo dục đồng đều.** Sau sáp nhập, nhà trường chịu trách nhiệm quản lý thống nhất hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ tại tất cả các nhóm, lớp thuộc phạm vi quản lý. Vì vậy, cần có nguồn học liệu được chọn lọc, kiểm soát chất lượng và chia sẻ phù hợp để hỗ trợ giáo viên tổ chức hoạt động, đồng thời từng bước thu hẹp sự khác biệt về điều kiện tiếp cận nguồn học liệu giữa các điểm trường.
>
> Những vấn đề trên cần được cụ thể hóa bằng kết quả khảo sát, kiểm kê thực tế. Đây cũng là cơ sở để nhà trường xác định nội dung ưu tiên, lựa chọn phương thức tổ chức và phân bổ nguồn lực phù hợp, tránh triển khai dàn trải, hình thức.
>
> ### 4. Sự cần thiết xây dựng kho tài liệu, học liệu dùng chung
>
> Từ đặc điểm tình hình trên, việc xây dựng kho tài liệu, học liệu dùng chung là yêu cầu cần thiết, có ý nghĩa thiết thực đối với công tác quản lý và phát triển chuyên môn của nhà trường trong giai đoạn sau sáp nhập.
>
> Trước hết, kho tài liệu, học liệu dùng chung giúp nhà trường **kế thừa, tập hợp và phát huy giá trị nguồn tài nguyên chuyên môn của ba đơn vị trước đây**, từng bước chuyển từ hình thức lưu trữ riêng lẻ sang quản lý tập trung, có hệ thống, bảo đảm thuận lợi trong tra cứu, chia sẻ, cập nhật và sử dụng.
>
> Thông qua kho dùng chung, nhà trường có điều kiện **thống nhất phương thức quản lý và nâng cao chất lượng học liệu**, đồng thời tạo môi trường để giáo viên trao đổi kinh nghiệm, học hỏi những cách làm hiệu quả, phát huy tinh thần hợp tác và trách nhiệm đối với chất lượng giáo dục chung.
>
> Đối với giáo viên, kho học liệu là nguồn hỗ trợ thiết thực trong xây dựng kế hoạch, lựa chọn và tổ chức các hoạt động giáo dục; góp phần giảm thời gian tìm kiếm, hạn chế việc xây dựng trùng lặp, tạo điều kiện tập trung nhiều hơn cho việc quan sát, chăm sóc và hỗ trợ sự phát triển của trẻ.
>
> Đối với công tác quản lý, kho dùng chung là công cụ hỗ trợ Ban Giám hiệu theo dõi, hướng dẫn và điều phối nguồn học liệu; từng bước bảo đảm sự thống nhất trong chỉ đạo chuyên môn, đồng thời tôn trọng tính linh hoạt, sáng tạo và điều kiện thực tế của từng nhóm, lớp.
>
> Như vậy, xây dựng kho tài liệu, học liệu dùng chung không chỉ nhằm đáp ứng yêu cầu ứng dụng công nghệ thông tin mà còn là **giải pháp trọng tâm để kết nối nguồn lực sau sáp nhập, phát huy sức mạnh tập thể và nâng cao chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ một cách đồng bộ, bền vững.**
>
> ## II. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> - Hình thành kho tài liệu, học liệu dùng chung thống nhất cấp trường trên cơ sở kế thừa, lựa chọn và phát triển các nguồn tài nguyên chuyên môn của ba trường trước sáp nhập.
> - Nâng cao hiệu quả quản lý, lưu trữ và khai thác học liệu; khắc phục sự phân tán, hạn chế trùng lặp và sử dụng tiết kiệm các nguồn lực hiện có.
> - Tạo môi trường chia sẻ, hợp tác chuyên môn, tăng cường kết nối giáo viên giữa các tổ, khối và điểm trường, phát huy kinh nghiệm, thế mạnh của đội ngũ.
> - Hỗ trợ giáo viên lựa chọn và sử dụng học liệu có chất lượng, phù hợp với độ tuổi, đặc điểm của trẻ và điều kiện tổ chức hoạt động giáo dục.
> - Góp phần nâng cao chất lượng hoạt động chuyên môn, từng bước bảo đảm cơ hội tiếp cận học liệu phù hợp cho các nhóm, lớp trong toàn trường.
>
> ### 2. Yêu cầu
>
> - Việc xây dựng kho phải xuất phát từ điều kiện và nhu cầu thực tế của nhà trường sau sáp nhập; có lộ trình, nhiệm vụ và trách nhiệm cụ thể.
> - Ưu tiên rà soát, khai thác hiệu quả nguồn tài liệu, học liệu của ba trường trước đây; chỉ bổ sung, xây dựng mới những nội dung thực sự cần thiết.
> - Tài liệu, học liệu được lựa chọn phải bảo đảm tính khoa học, sư phạm, an toàn, phù hợp với Chương trình giáo dục mầm non, độ tuổi và điều kiện thực tế.
> - Cấu trúc kho đơn giản, dễ tra cứu, dễ cập nhật, thuận tiện cho giáo viên tại các điểm trường.
> - Có quy trình lựa chọn, phê duyệt, phân quyền sử dụng, kiểm tra và cập nhật; bảo đảm an toàn thông tin và tuân thủ quy định về bản quyền.
> - Gắn việc xây dựng kho với sinh hoạt chuyên môn, bồi dưỡng đội ngũ và hoạt động giáo dục thực tế; không chạy theo số lượng sản phẩm, không tạo thêm áp lực hồ sơ cho giáo viên.
>
> ## III. MỤC TIÊU, CHỈ TIÊU THỰC HIỆN
>
> ### 1. Mục tiêu chung
>
> Xây dựng, quản lý và khai thác hiệu quả kho tài liệu, học liệu dùng chung cấp trường trên cơ sở tích hợp, chọn lọc và phát huy nguồn tài nguyên chuyên môn của ba trường trước sáp nhập; hình thành hệ thống học liệu có chất lượng, dễ tiếp cận, được cập nhật thường xuyên, góp phần thống nhất quản lý chuyên môn, nâng cao năng lực đội ngũ và chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ.
>
> ### 2. Chỉ tiêu cụ thể
>
> **Về xây dựng kho:**
>
> - Hoàn thành rà soát, kiểm kê nguồn tài liệu, học liệu cần kế thừa từ cả ba trường trước sáp nhập.
> - Xây dựng 01 kho tài liệu, học liệu dùng chung cấp trường, có cấu trúc thư mục thống nhất, danh mục tra cứu và phân quyền sử dụng rõ ràng.
> - 100% tổ chuyên môn tham gia lựa chọn, phát triển và khai thác học liệu phù hợp với chức năng, nhiệm vụ.
>
> **Về phát triển học liệu:**
>
> - 100% khối tuổi hiện có của nhà trường được xây dựng danh mục học liệu dùng chung phù hợp với nội dung, kế hoạch giáo dục.
> - Phấn đấu mỗi khối tuổi có ít nhất 03 gói học liệu cốt lõi được rà soát, chuẩn hóa và đưa vào danh mục sử dụng trong năm học.
> - 100% học liệu thuộc diện phải lựa chọn theo quy định được thực hiện đúng quy trình trước khi đưa vào sử dụng chính thức.
>
> **Về khai thác và sử dụng:**
>
> - 100% cán bộ quản lý, giáo viên được hướng dẫn truy cập, tìm kiếm, sử dụng và chia sẻ tài liệu.
> - Phấn đấu từ 80% giáo viên trở lên thường xuyên khai thác kho phục vụ công tác chuyên môn sau giai đoạn triển khai.
> - Mỗi tổ chuyên môn có hoạt động chia sẻ, trao đổi kinh nghiệm sử dụng học liệu trong sinh hoạt chuyên môn định kỳ.
>
> **Về quản lý và duy trì:**
>
> - Có nhân sự phụ trách quản lý, cập nhật và bảo đảm an toàn dữ liệu.
> - Thực hiện rà soát, cập nhật, loại bỏ tài liệu không phù hợp theo định kỳ.
> - Cuối năm học đánh giá hiệu quả khai thác kho và xây dựng định hướng bổ sung cho năm học tiếp theo.
>
> Các chỉ tiêu trên là mức phấn đấu dự kiến, được rà soát và điều chỉnh sau khi hoàn thành khảo sát về quy mô, nguồn học liệu và điều kiện thực tế của nhà trường.
>
> ## IV. NỘI DUNG VÀ GIẢI PHÁP THỰC HIỆN
>
> ### 1. Rà soát, kiểm kê và đánh giá nguồn tài liệu, học liệu từ ba trường trước sáp nhập
>
> Tổ chức rà soát toàn bộ các nguồn tài liệu, học liệu có giá trị sử dụng hiện đang lưu trữ tại các cơ sở, điểm trường hoặc do giáo viên quản lý.
>
> Các tổ chuyên môn phối hợp phân loại tài liệu theo nhóm nội dung, khối tuổi, nguồn gốc, tình trạng sử dụng và khả năng chia sẻ.
>
> Đối với học liệu trực quan, đồ dùng, đồ chơi hiện có, cần xác định nơi lưu giữ, tình trạng sử dụng, khả năng khai thác và điều kiện mượn, luân chuyển giữa các điểm trường.
>
> **Giải pháp:** Thống nhất một mẫu danh mục kiểm kê ngắn gọn; tận dụng kết quả bàn giao tài sản, hồ sơ chuyên môn sau sáp nhập và nguồn dữ liệu hiện có. Không yêu cầu giáo viên sao chép hoặc làm lại những tài liệu đã được lưu trữ hợp lệ.
>
> Kết quả rà soát là căn cứ xác định nguồn tài liệu kế thừa, học liệu cần chuẩn hóa, nội dung còn thiếu và những nhiệm vụ ưu tiên phát triển kho dùng chung.
>
> ### 2. Xây dựng cấu trúc kho tài liệu, học liệu dùng chung
>
> Kho được tổ chức theo hướng thống nhất, khoa học và thuận tiện sử dụng, gồm các nhóm nội dung chủ yếu:
>
> **Nhóm 1. Tài liệu chỉ đạo và quản lý chuyên môn:** Văn bản hướng dẫn của ngành; kế hoạch năm học; kế hoạch chuyên đề; tài liệu chỉ đạo và biểu mẫu nghiệp vụ được phép chia sẻ.
>
> **Nhóm 2. Tài liệu bồi dưỡng và phát triển chuyên môn:** Tài liệu sinh hoạt chuyên môn, nội dung tập huấn, hướng dẫn đổi mới phương pháp, giáo dục lấy trẻ làm trung tâm, giáo dục hòa nhập và các chuyên đề của nhà trường.
>
> **Nhóm 3. Học liệu giáo dục theo độ tuổi:** Học liệu dành cho trẻ nhà trẻ, mẫu giáo 3–4 tuổi, 4–5 tuổi, 5–6 tuổi theo các khối tuổi được tổ chức tại trường; trong từng khối phân loại theo lĩnh vực phát triển và nội dung giáo dục.
>
> **Nhóm 4. Học liệu phục vụ chăm sóc, nuôi dưỡng và giáo dục kỹ năng:** Tài liệu về dinh dưỡng, vệ sinh, sức khỏe, kỹ năng tự phục vụ, an toàn, bảo vệ môi trường và những nội dung giáo dục phù hợp.
>
> **Nhóm 5. Học liệu trải nghiệm, trò chơi và đồ dùng tự tạo:** Trò chơi dân gian, hoạt động khám phá, trải nghiệm, đồ dùng, đồ chơi từ vật liệu an toàn; ưu tiên những sản phẩm có giá trị thực tiễn, có thể áp dụng và điều chỉnh ở nhiều nhóm, lớp.
>
> **Nhóm 6. Danh mục học liệu, thiết bị và đồ dùng trực quan:** Thông tin về học liệu hiện vật, vị trí lưu giữ, đơn vị quản lý, khả năng chia sẻ và nguyên tắc sử dụng.
>
> **Giải pháp:** Sử dụng nền tảng lưu trữ số phù hợp với điều kiện nhà trường; thống nhất cách đặt tên tài liệu, phân quyền sử dụng và cách cập nhật. Đối với học liệu hiện vật, quản lý bằng danh mục dùng chung, không nhất thiết tập trung toàn bộ về một địa điểm.
>
> ### 3. Lựa chọn, chuẩn hóa và phát triển nguồn học liệu
>
> Trên cơ sở kết quả rà soát, các tổ chuyên môn lựa chọn những tài liệu, học liệu có chất lượng, phù hợp thực tiễn để bổ sung vào kho.
>
> Ưu tiên những sản phẩm có tính ứng dụng cao; học liệu hỗ trợ trẻ học thông qua chơi, thực hành, trải nghiệm; có khả năng sử dụng nhiều lần và điều chỉnh theo đặc điểm trẻ.
>
> Thực hiện rà soát nội dung, nguồn gốc, tính chính xác, sự phù hợp về độ tuổi, yêu cầu an toàn và quyền sử dụng trước khi đưa vào danh mục chính thức.
>
> Đối với đồ chơi, học liệu thuộc phạm vi quy định tại Thông tư số 60/2026/TT-BGDĐT, việc lựa chọn và phê duyệt phải thực hiện đúng quy định hiện hành.
>
> **Giải pháp:** Phát huy thế mạnh của giáo viên đến từ ba trường trước sáp nhập, giao nhiệm vụ theo năng lực, sở trường và nhu cầu thực tế; khuyến khích cùng xây dựng, điều chỉnh học liệu theo nhóm, khối tuổi.
>
> Không giao chỉ tiêu làm mới học liệu khi những sản phẩm hiện có vẫn đáp ứng tốt yêu cầu. Ưu tiên chất lượng, tính phù hợp và hiệu quả sử dụng thay vì số lượng tài liệu được đăng tải.
>
> ### 4. Thiết lập cơ chế quản lý, cập nhật và chia sẻ học liệu
>
> Ban Giám hiệu thống nhất quy định quản lý kho, xác định rõ trách nhiệm của người phụ trách, tổ chuyên môn và người sử dụng.
>
> Việc bổ sung học liệu được thực hiện qua các bước: đề xuất, rà soát nội dung, lựa chọn hoặc phê duyệt theo thẩm quyền, phân loại, cập nhật và tổ chức sử dụng.
>
> Cần phân biệt tài liệu nội bộ phục vụ quản lý với học liệu được phép chia sẻ rộng rãi; bảo đảm an toàn thông tin, quyền tác giả và bảo vệ dữ liệu cá nhân.
>
> Đối với học liệu hiện vật được sử dụng chung giữa các điểm trường, cần có cách thức đăng ký, bàn giao và bảo quản phù hợp, tránh thất lạc, hư hỏng hoặc ảnh hưởng đến hoạt động chăm sóc, giáo dục trẻ.
>
> **Giải pháp:** Phân công đầu mối quản lý kho cấp trường, tổ trưởng chuyên môn phụ trách nội dung thuộc tổ, giáo viên phối hợp cập nhật và phản hồi. Hạn chế khâu trung gian, thủ tục trùng lặp; áp dụng cơ chế lưu trữ, sao lưu và kiểm soát quyền chỉnh sửa.
>
> ### 5. Tổ chức khai thác kho gắn với sinh hoạt chuyên môn
>
> Hướng dẫn cán bộ quản lý, giáo viên truy cập, tìm kiếm, lựa chọn, chia sẻ và sử dụng học liệu theo nhu cầu.
>
> Tăng cường sinh hoạt chuyên môn giữa giáo viên các điểm trường, các khối tuổi để giới thiệu những học liệu hiệu quả, trao đổi cách tổ chức hoạt động, những khó khăn khi vận dụng và hướng điều chỉnh phù hợp.
>
> Khuyến khích giáo viên sử dụng học liệu đã được chia sẻ trong kho để tổ chức hoạt động giáo dục tại nhóm, lớp, đồng thời phát huy sự chủ động, sáng tạo trong lựa chọn phương pháp.
>
> **Giải pháp:** Lựa chọn những nội dung thiết thực để hướng dẫn, hỗ trợ giáo viên còn hạn chế kỹ năng công nghệ thông tin; phát huy vai trò giáo viên cốt cán trong hỗ trợ đồng nghiệp.
>
> Không yêu cầu sử dụng học liệu một cách máy móc, không áp dụng đồng loạt một hình thức tổ chức hoạt động cho tất cả nhóm, lớp khi điều kiện và đặc điểm trẻ khác nhau.
>
> ### 6. Kiểm tra, đánh giá và cải tiến chất lượng kho
>
> Tổ chức theo dõi việc xây dựng, cập nhật và khai thác kho trong quá trình thực hiện nhiệm vụ chuyên môn.
>
> Việc kiểm tra tập trung vào tính phù hợp của tài liệu, hiệu quả sử dụng, khả năng tiếp cận của giáo viên tại các điểm trường và những khó khăn cần tháo gỡ.
>
> Định kỳ tổ chức rà soát, loại bỏ nội dung không còn phù hợp, bổ sung những nguồn học liệu cần thiết và nhân rộng các sản phẩm phát huy hiệu quả.
>
> **Giải pháp:** Lồng ghép đánh giá vào sinh hoạt chuyên môn, kiểm tra nội bộ và sơ kết, tổng kết năm học. Sử dụng phản hồi của giáo viên, kết quả quan sát hoạt động thực tế để cải tiến kho; không đánh giá hiệu quả chỉ bằng số lượng tệp tài liệu hoặc lượt đăng tải.
>
> ## V. TIẾN ĐỘ THỰC HIỆN
>
> | Thời gian | Nội dung trọng tâm | Kết quả |
> |---|---|---|
> | Tháng 11/2026 | Triển khai kế hoạch; rà soát tài liệu, học liệu kế thừa từ ba trường; khảo sát nhu cầu và điều kiện sử dụng | Có danh mục nguồn học liệu ban đầu, xác định nội dung ưu tiên |
> | Tháng 12/2026 | Thiết lập cấu trúc kho, phân quyền quản lý; lựa chọn học liệu ban đầu và hướng dẫn giáo viên | Kho dùng chung cấp trường được đưa vào vận hành |
> | Tháng 01–02/2027 | Chuẩn hóa, bổ sung học liệu; tổ chức sử dụng thử và chia sẻ kinh nghiệm | Hình thành nguồn học liệu dùng chung theo các khối tuổi |
> | Tháng 3/2027 | Rà soát chất lượng; bổ sung nội dung còn thiếu; đẩy mạnh sinh hoạt chuyên môn liên điểm trường | Nâng cao chất lượng và khả năng khai thác học liệu |
> | Tháng 4/2027 | Kiểm tra việc khai thác, sử dụng; điều chỉnh, hoàn thiện kho | Học liệu được sử dụng thực tế và có phản hồi cải tiến |
> | Tháng 5/2027 | Đánh giá kết quả; chuẩn hóa, lưu trữ và đề xuất phương hướng năm học tiếp theo | Có báo cáo đánh giá và định hướng duy trì, phát triển kho |
>
> ## VI. PHÂN CÔNG TRÁCH NHIỆM
>
> ### 1. Hiệu trưởng
>
> Chỉ đạo chung, ban hành kế hoạch, phân công nhiệm vụ và bố trí các điều kiện cần thiết để triển khai.
>
> Chỉ đạo việc rà soát, tiếp nhận, kế thừa nguồn tài liệu, học liệu của ba trường trước sáp nhập; bảo đảm sự thống nhất trong quản lý và công bằng về cơ hội tiếp cận học liệu giữa các điểm trường.
>
> Thực hiện thành lập Hội đồng lựa chọn đồ chơi, học liệu và phê duyệt danh mục theo quy định thuộc thẩm quyền. Tổ chức kiểm tra, đánh giá kết quả thực hiện.
>
> ### 2. Phó Hiệu trưởng phụ trách chuyên môn
>
> Trực tiếp tham mưu, hướng dẫn và tổ chức triển khai kế hoạch.
>
> Chỉ đạo tổ chuyên môn kiểm kê, phân loại, lựa chọn, chuẩn hóa và phát triển nguồn học liệu; theo dõi tiến độ và chất lượng thực hiện.
>
> Phối hợp giải quyết những khó khăn, tổ chức đánh giá hiệu quả khai thác và tham mưu điều chỉnh phù hợp với thực tế.
>
> ### 3. Tổ trưởng chuyên môn
>
> Tổ chức rà soát, lựa chọn học liệu trong tổ; đề xuất danh mục học liệu cần kế thừa, hoàn thiện và bổ sung.
>
> Hướng dẫn giáo viên khai thác, sử dụng; tổ chức chia sẻ kinh nghiệm trong sinh hoạt chuyên môn; phản ánh những khó khăn, bất cập để kịp thời điều chỉnh.
>
> ### 4. Giáo viên
>
> Chủ động khai thác nguồn tài liệu, học liệu phù hợp; chia sẻ những sản phẩm chuyên môn có chất lượng, được phép sử dụng.
>
> Tích cực tham gia trao đổi, học hỏi, phối hợp xây dựng và cải tiến học liệu; sử dụng linh hoạt theo đặc điểm trẻ và điều kiện thực tế của nhóm, lớp.
>
> ### 5. Nhân sự phụ trách công nghệ thông tin
>
> Tham mưu thiết lập, quản lý nền tảng lưu trữ; phân quyền, sao lưu và bảo đảm an toàn dữ liệu.
>
> Hỗ trợ cán bộ, giáo viên trong quá trình sử dụng, cập nhật và khai thác kho.
>
> ### 6. Các bộ phận liên quan
>
> Phối hợp cung cấp, rà soát và lựa chọn những tài liệu, học liệu phù hợp với chức năng, nhiệm vụ.
>
> Bộ phận tài chính, kế toán tham mưu bảo đảm nguồn kinh phí theo dự toán và quy định hiện hành.
>
> ## VII. ĐIỀU KIỆN BẢO ĐẢM
>
> Nhà trường ưu tiên sử dụng cơ sở vật chất, thiết bị, phần mềm và nguồn tài liệu hiện có từ ba trường trước sáp nhập; đồng thời rà soát để phân bổ, khai thác hiệu quả, tránh đầu tư trùng lặp.
>
> Bố trí nhân sự phụ trách phù hợp với năng lực và nhiệm vụ được giao; phát huy vai trò của tổ chuyên môn và giáo viên có kinh nghiệm trong chia sẻ, hỗ trợ.
>
> Đối với điểm trường còn hạn chế về đường truyền hoặc thiết bị, tổ chức phương án sử dụng máy tính chung hoặc bản học liệu ngoại tuyến phù hợp, bảo đảm giáo viên được hỗ trợ tiếp cận tài liệu cần thiết.
>
> Kinh phí thực hiện được cân đối từ nguồn kinh phí hợp pháp của nhà trường theo dự toán được phê duyệt; ưu tiên những nhiệm vụ thiết thực, không tạo gánh nặng tài chính cho giáo viên và cha mẹ trẻ.
>
> ## VIII. KIỂM TRA, ĐÁNH GIÁ
>
> Ban Giám hiệu thực hiện kiểm tra, đánh giá gắn với hoạt động quản lý và chỉ đạo chuyên môn thường xuyên.
>
> Tập trung vào các nội dung:
>
> - Mức độ rà soát, kế thừa và phát huy nguồn tài liệu, học liệu của ba trường trước sáp nhập.
> - Chất lượng, tính khoa học và sự phù hợp của học liệu được đưa vào kho.
> - Khả năng tiếp cận, khai thác và sử dụng học liệu của giáo viên giữa các tổ, khối và điểm trường.
> - Hiệu quả hỗ trợ giáo viên trong chuẩn bị, tổ chức hoạt động giáo dục và chia sẻ kinh nghiệm chuyên môn.
> - Việc thực hiện các quy định về quản lý, lưu trữ, bảo mật và cập nhật tài liệu.
>
> Kết quả đánh giá được sử dụng làm căn cứ điều chỉnh cách thức tổ chức, lựa chọn nội dung cần ưu tiên bổ sung và phát triển kho trong năm học tiếp theo.
>
> Không lấy số lượng học liệu được đăng tải làm tiêu chí chủ yếu để đánh giá thi đua hoặc chất lượng thực hiện nhiệm vụ của giáo viên.
>
> ## IX. TỔ CHỨC THỰC HIỆN
>
> Ban Giám hiệu triển khai kế hoạch đến toàn thể cán bộ quản lý, giáo viên và các bộ phận có liên quan; thống nhất nhận thức về mục đích, ý nghĩa và trách nhiệm trong việc xây dựng kho tài liệu, học liệu dùng chung.
>
> Phó Hiệu trưởng phụ trách chuyên môn chủ động cụ thể hóa nhiệm vụ theo từng giai đoạn, hướng dẫn, kiểm tra tiến độ và phối hợp hỗ trợ các tổ chuyên môn trong quá trình thực hiện.
>
> Các tổ chuyên môn tổ chức rà soát nguồn học liệu, lựa chọn nội dung ưu tiên và triển khai hoạt động chia sẻ, khai thác phù hợp với điều kiện thực tế. Tăng cường phối hợp giữa giáo viên thuộc các đơn vị trước sáp nhập, phát huy tinh thần đoàn kết, trách nhiệm và những thế mạnh chuyên môn của đội ngũ.
>
> Trong quá trình thực hiện, các bộ phận kịp thời phản ánh khó khăn, vướng mắc để Ban Giám hiệu xem xét, chỉ đạo giải quyết; bảo đảm việc xây dựng kho thực hiện đúng trọng tâm, phù hợp điều kiện nhà trường, không làm ảnh hưởng đến công tác nuôi dưỡng, chăm sóc và giáo dục trẻ.
>
> Cuối năm học, nhà trường tổ chức đánh giá kết quả, xác định những nội dung cần tiếp tục duy trì, hoàn thiện và phát triển cho năm học tiếp theo.
>
> **Xây dựng kho tài liệu, học liệu dùng chung là một trong những giải pháp quan trọng nhằm phát huy hiệu quả nguồn lực của ba trường sau sáp nhập, hình thành sự thống nhất trong quản lý và sự gắn kết trong hoạt động chuyên môn. Nhà trường xác định việc xây dựng kho không dừng lại ở tập hợp, lưu trữ tài liệu mà hướng đến tạo lập nguồn tài nguyên giáo dục có chất lượng, được chia sẻ và sử dụng thực chất, góp phần nâng cao năng lực đội ngũ và chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ trên toàn trường.**
>
> Trên đây là Kế hoạch xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 của Trường Mầm non … Đề nghị các tổ chuyên môn, cán bộ, giáo viên và các bộ phận có liên quan nghiêm túc triển khai thực hiện.
>
> **Nơi nhận:**
> - Ban Giám hiệu;
> - Các tổ chuyên môn, bộ phận liên quan;
> - Lưu: VT, CM.
>
> **HIỆU TRƯỞNG**  
> *(Ký, ghi rõ họ tên, đóng dấu)*

## ✅ 3. Những điểm cần hoàn thiện để kế hoạch sát thực tế hơn

Ở bản này, phần đặc điểm tình hình đã được xây dựng theo chuỗi lập luận **sáp nhập ba trường → tập hợp nguồn lực → phát sinh yêu cầu thống nhất quản lý → cần có kho học liệu dùng chung → nâng cao chất lượng giáo dục trên toàn trường**.

Trước khi ban hành chính thức, tôi khuyến nghị bổ sung số liệu thực tế về số điểm trường còn hoạt động, số nhóm lớp, tổng số giáo viên, các nền tảng lưu trữ tài liệu hiện có và mức độ chênh lệch điều kiện thiết bị giữa các cơ sở. Không cần nêu quá nhiều số liệu, chỉ cần những thông tin trực tiếp chứng minh sự cần thiết và tính khả thi của kế hoạch.

**Một điểm tôi đặc biệt muốn nhấn mạnh:** Sau sáp nhập, mục tiêu không phải làm cho giáo viên ở cả ba trường cũ tổ chức hoạt động giống hệt nhau. Mục tiêu là thống nhất về chất lượng, chia sẻ những nguồn học liệu tốt, nhưng vẫn bảo đảm tính linh hoạt, sáng tạo và phù hợp điều kiện của từng nhóm lớp.

Đó cũng là điểm giúp kế hoạch thể hiện được tư duy quản trị của người Hiệu trưởng trong giai đoạn ổn định và phát triển nhà trường sau sáp nhập.

---

USER

phần I và II có thể đảo ngược cho nhau để logic hơn không?

---

ASSISTANT

**Hoàn toàn có thể đảo vị trí phần I và phần II.** Tôi cũng nghiêng về phương án này vì sẽ giúp kế hoạch có bố cục quen thuộc, rõ ràng hơn đối với một văn bản quản lý của nhà trường.

Tuy nhiên, để bảo đảm tính logic và sức thuyết phục, tôi đề xuất **không chỉ đảo vị trí mà cần điều chỉnh nhẹ tên mục và cách dẫn dắt**.

## 📌 1. Cấu trúc đề xuất

| Thứ tự | Nội dung |
|--------|--------|
| **I** | Mục đích, yêu cầu |
| **II** | Đặc điểm tình hình và những vấn đề đặt ra sau sáp nhập |
| **III** | Mục tiêu, chỉ tiêu thực hiện |
| **IV** | Nội dung và giải pháp thực hiện |
| **V** | Tiến độ thực hiện |
| **VI** | Phân công trách nhiệm |
| **VII** | Điều kiện bảo đảm thực hiện |
| **VIII** | Kiểm tra, đánh giá |
| **IX** | Tổ chức thực hiện |

## 🔍 2. Vì sao nên điều chỉnh như vậy?

**Thứ nhất, phần I – Mục đích, yêu cầu:** Xác định ngay định hướng của nhà trường trong việc xây dựng kho dùng chung, nhấn mạnh việc tập hợp nguồn lực của ba trường sau sáp nhập, thống nhất quản lý và hỗ trợ đội ngũ giáo viên.

**Thứ hai, phần II – Đặc điểm tình hình và những vấn đề đặt ra sau sáp nhập:** Đây là phần phân tích thực tiễn, làm rõ thuận lợi, khó khăn và những vấn đề quản lý cần giải quyết. Tôi đề xuất thay cụm từ *“sự cần thiết”* bằng *“những vấn đề đặt ra sau sáp nhập”* để tránh trùng lặp với nội dung mục đích ở phần I.

**Thứ ba, phần III – Mục tiêu, chỉ tiêu:** Chuyển các vấn đề thực tiễn đã phân tích thành những kết quả cụ thể cần đạt. Như vậy, phần II và III liên kết trực tiếp với nhau, tạo cơ sở cho việc xác định giải pháp ở phần IV.

## 💡 3. Một điều chỉnh quan trọng ở phần mở đầu

Để bảo đảm mạch lập luận khi đưa phần Mục đích, yêu cầu lên trước, ngay sau phần căn cứ nên có một đoạn dẫn ngắn:

> Năm học 2026–2027, sau khi thực hiện sáp nhập ba trường mầm non thành một đơn vị, nhà trường đứng trước yêu cầu ổn định tổ chức, thống nhất công tác quản lý, phát huy hiệu quả nguồn lực và nâng cao chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ tại các điểm trường. Trong đó, việc rà soát, kế thừa, kết nối và sử dụng hiệu quả nguồn tài liệu, học liệu của ba đơn vị trước sáp nhập là một nhiệm vụ cần thiết, góp phần tăng cường chia sẻ chuyên môn, hạn chế trùng lặp và tạo điều kiện để giáo viên khai thác nguồn học liệu có chất lượng. Trên cơ sở đó, Trường Mầm non … xây dựng Kế hoạch xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 với những nội dung sau:

## ✅ Kết luận

Tôi đề xuất **thống nhất phương án đảo phần I và II**, đồng thời dành trọng tâm phần II để phân tích những vấn đề thực tế phát sinh sau sáp nhập ba trường.

Cách bố cục này vừa phù hợp văn phong kế hoạch hành chính, vừa giúp người đọc thấy rõ mối liên hệ giữa **định hướng quản lý – điều kiện thực tiễn – mục tiêu cụ thể – giải pháp tổ chức thực hiện**.

Một lưu ý quan trọng: Phần I và phần III cần được phân biệt rõ. **Phần I nêu mục đích và yêu cầu về cách thực hiện; phần III xác định kết quả và các chỉ tiêu phải đạt**, tránh diễn đạt trùng lặp.

---

USER

Đến VIII  quá dài dòng. Bạn có thể cô đọng hơn, tuy nhiên vẫn đảm bảo ý . Kế hoạch dài quá sẽ tạo cảm giác rối, lan man khó xác định trọng tâm gì? cần làm gì? và cách yhu75c hiện thế nào?

---

ASSISTANT

Tôi đồng ý: bản trước có quá nhiều mục và lặp ý giữa mục đích, chỉ tiêu, giải pháp, kiểm tra. Tôi sẽ rút còn 5 phần, trong đó phần trọng tâm trình bày rõ từng việc phải làm, cách thực hiện, người phụ trách và thời hạn; vẫn giữ đặc thù sáp nhập ba trường làm cơ sở lập kế hoạch.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đề xuất **rút kế hoạch từ 9 phần xuống còn 5 phần**, khoảng 3 trang A4, đồng thời bỏ các nội dung diễn giải trùng lặp.

Kế hoạch cần trả lời rõ bốn câu hỏi: **Vì sao phải xây dựng? Xây dựng cái gì? Thực hiện bằng cách nào? Ai chịu trách nhiệm và khi nào hoàn thành?**

Đặc biệt, phần IV sẽ là trọng tâm, thể hiện trực tiếp các công việc cần triển khai, phù hợp với điều kiện nhà trường sau sáp nhập ba trường.

> **writing · document**
>
> **ỦY BAN NHÂN DÂN [XÃ/PHƯỜNG]**  
> **TRƯỜNG MẦM NON [TÊN TRƯỜNG]**
>
> Số: …/KH-MN…
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *[Địa danh], ngày … tháng … năm 2026*
>
> # KẾ HOẠCH
> **Xây dựng và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027**
>
> Căn cứ Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020 của Bộ Giáo dục và Đào tạo ban hành Điều lệ trường mầm non, được sửa đổi, bổ sung bởi Thông tư số 51/2026/TT-BGDĐT;
>
> Căn cứ Thông tư số 60/2026/TT-BGDĐT ngày 17/7/2026 của Bộ Giáo dục và Đào tạo quy định về tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu sử dụng trong cơ sở giáo dục mầm non;
>
> Căn cứ Công văn số 5385/BGDĐT-GDMN ngày 12/8/2026 của Bộ Giáo dục và Đào tạo về hướng dẫn thực hiện nhiệm vụ giáo dục mầm non năm học 2026–2027;
>
> Căn cứ Quyết định số … ngày … về việc sáp nhập ba trường mầm non …, …, …;
>
> Căn cứ Kế hoạch thực hiện nhiệm vụ năm học 2026–2027 và tình hình thực tế của nhà trường;
>
> Trường Mầm non … xây dựng Kế hoạch xây dựng và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027, cụ thể như sau:
>
> ## I. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> Xây dựng kho tài liệu, học liệu dùng chung trên cơ sở kế thừa, chọn lọc và phát huy nguồn tài nguyên chuyên môn của ba trường trước sáp nhập; tạo hệ thống lưu trữ thống nhất, thuận tiện cho việc quản lý, chia sẻ và khai thác trong toàn trường.
>
> Tạo điều kiện để giáo viên trao đổi kinh nghiệm, sử dụng hiệu quả nguồn học liệu sẵn có, hạn chế trùng lặp trong xây dựng tài liệu; góp phần nâng cao chất lượng tổ chức các hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ.
>
> ### 2. Yêu cầu
>
> - Kho tài liệu, học liệu được xây dựng phù hợp với điều kiện thực tế, nhu cầu chuyên môn và khả năng sử dụng của đội ngũ.
> - Tài liệu, học liệu phải được chọn lọc, bảo đảm tính khoa học, sư phạm, an toàn, phù hợp độ tuổi và Chương trình giáo dục mầm non.
> - Việc quản lý, cập nhật và khai thác phải thuận tiện, có phân công trách nhiệm rõ ràng; bảo đảm an toàn thông tin và quyền tác giả.
> - Ưu tiên khai thác nguồn học liệu hiện có; không chạy theo số lượng, không tạo thêm áp lực hồ sơ cho giáo viên.
>
> ## II. ĐẶC ĐIỂM TÌNH HÌNH
>
> Năm học 2026–2027, nhà trường được tổ chức lại trên cơ sở sáp nhập ba trường mầm non thành một đơn vị thống nhất. Việc sáp nhập tạo điều kiện tập trung nguồn lực về đội ngũ, cơ sở vật chất, trang thiết bị và tài liệu chuyên môn; đồng thời đặt ra yêu cầu thống nhất công tác quản lý, tăng cường kết nối và nâng cao hiệu quả phối hợp giữa các tổ, khối và điểm trường.
>
> Trước sáp nhập, mỗi trường đã hình thành nguồn tài liệu, học liệu và tích lũy những kinh nghiệm tổ chức hoạt động giáo dục riêng. Đây là nguồn lực có giá trị cần được kế thừa và phát huy. Tuy nhiên, các nguồn tài liệu được lưu trữ, quản lý theo từng đơn vị, cần được rà soát, phân loại, chuẩn hóa và kết nối thành hệ thống chung để thuận tiện trong khai thác, tránh trùng lặp, phân tán và lãng phí nguồn lực.
>
> Bên cạnh đó, sự khác biệt về điều kiện trang thiết bị, năng lực ứng dụng công nghệ thông tin và thói quen sử dụng học liệu của đội ngũ đòi hỏi nhà trường phải có phương thức tổ chức, hướng dẫn và hỗ trợ phù hợp, bảo đảm giáo viên tại các nhóm, lớp đều có cơ hội tiếp cận nguồn học liệu có chất lượng.
>
> Từ thực tế trên, **việc xây dựng kho tài liệu, học liệu dùng chung là giải pháp cần thiết nhằm thống nhất quản lý, kết nối nguồn lực của ba trường sau sáp nhập, phát huy thế mạnh của đội ngũ và từng bước nâng cao chất lượng giáo dục trong toàn trường.**
>
> ## III. CHỈ TIÊU THỰC HIỆN
>
> 1. Xây dựng **01 kho tài liệu, học liệu dùng chung cấp trường**, có cấu trúc thống nhất, dễ tìm kiếm, cập nhật và sử dụng.
> 2. 100% tổ chuyên môn tham gia rà soát, lựa chọn, bổ sung và khai thác học liệu; mỗi khối tuổi có danh mục học liệu dùng chung phù hợp.
> 3. 100% cán bộ quản lý, giáo viên được hướng dẫn sử dụng kho; phấn đấu ít nhất 80% giáo viên khai thác thường xuyên sau giai đoạn triển khai.
> 4. 100% tài liệu, học liệu đưa vào danh mục sử dụng chính thức được rà soát về nội dung, nguồn gốc, tính phù hợp và thực hiện quy trình lựa chọn, phê duyệt theo quy định áp dụng.
>
> ## IV. NỘI DUNG VÀ CÁCH THỰC HIỆN
>
> ### 1. Rà soát, tập hợp nguồn tài liệu, học liệu
>
> - **Nội dung:** Kiểm kê, tập hợp tài liệu chuyên môn, học liệu số, tranh ảnh, video, trò chơi, đồ dùng, đồ chơi có giá trị sử dụng từ ba trường trước sáp nhập.
> - **Cách thực hiện:** Các tổ chuyên môn rà soát, lập danh mục, phân loại tài liệu có thể sử dụng, cần điều chỉnh hoặc không còn phù hợp. Ưu tiên lựa chọn những học liệu thiết thực, có khả năng sử dụng chung.
> - **Kết quả:** Hình thành danh mục tài liệu, học liệu ban đầu.
> - **Thời gian:** Tháng 11/2026.
> - **Phụ trách:** Phó Hiệu trưởng chuyên môn, tổ trưởng chuyên môn.
>
> ### 2. Thiết lập và tổ chức kho dùng chung
>
> - **Nội dung:** Xây dựng kho lưu trữ số kết hợp danh mục quản lý học liệu hiện vật đang sử dụng tại các điểm trường.
> - **Cách thực hiện:** Lựa chọn nền tảng lưu trữ phù hợp; tổ chức thư mục theo bốn nhóm chính:
>   - Tài liệu chỉ đạo, quản lý và bồi dưỡng chuyên môn.
>   - Học liệu giáo dục theo khối tuổi, lĩnh vực phát triển.
>   - Học liệu chăm sóc, nuôi dưỡng và giáo dục kỹ năng.
>   - Học liệu trải nghiệm, trò chơi, đồ dùng, đồ chơi tự tạo.
>
>   Thống nhất cách đặt tên, cập nhật tài liệu, phân quyền truy cập và quản lý danh mục học liệu hiện vật.
> - **Kết quả:** Kho dùng chung được đưa vào hoạt động.
> - **Thời gian:** Tháng 12/2026.
> - **Phụ trách:** Ban Giám hiệu, nhân sự phụ trách công nghệ thông tin, tổ chuyên môn.
>
> ### 3. Lựa chọn, chuẩn hóa và bổ sung học liệu
>
> - **Nội dung:** Lựa chọn những tài liệu, học liệu có chất lượng, phù hợp với chương trình, độ tuổi và điều kiện tổ chức hoạt động giáo dục.
> - **Cách thực hiện:** Tổ chuyên môn rà soát nội dung, nguồn gốc, tính phù hợp và đề xuất bổ sung. Thực hiện việc lựa chọn, phê duyệt đồ chơi, học liệu theo quy định. Khuyến khích giáo viên phối hợp hoàn thiện những học liệu có giá trị sử dụng thực tế.
> - **Kết quả:** Có nguồn học liệu dùng chung được chọn lọc, cập nhật theo từng khối tuổi.
> - **Thời gian:** Tháng 12/2026 đến tháng 3/2027.
> - **Phụ trách:** Phó Hiệu trưởng chuyên môn, các tổ chuyên môn.
>
> ### 4. Tổ chức khai thác, chia sẻ và đánh giá hiệu quả
>
> - **Nội dung:** Đưa kho tài liệu, học liệu vào sử dụng thường xuyên trong hoạt động chuyên môn.
> - **Cách thực hiện:** Hướng dẫn giáo viên truy cập, tìm kiếm, sử dụng học liệu; lồng ghép việc giới thiệu, trao đổi kinh nghiệm sử dụng học liệu trong sinh hoạt chuyên môn. Định kỳ rà soát, cập nhật, điều chỉnh những nội dung chưa phù hợp.
> - **Kết quả:** Giáo viên khai thác học liệu thuận tiện, giảm trùng lặp trong chuẩn bị, nâng cao hiệu quả tổ chức hoạt động giáo dục.
> - **Thời gian:** Tháng 01–5/2027 và duy trì trong các năm học tiếp theo.
> - **Phụ trách:** Ban Giám hiệu, tổ chuyên môn, giáo viên.
>
> ## V. TỔ CHỨC THỰC HIỆN
>
> **1. Hiệu trưởng:** Chỉ đạo chung; phân công nhiệm vụ, bảo đảm điều kiện thực hiện; thành lập Hội đồng lựa chọn đồ chơi, học liệu và phê duyệt theo thẩm quyền; kiểm tra, đánh giá kết quả triển khai.
>
> **2. Phó Hiệu trưởng phụ trách chuyên môn:** Trực tiếp tổ chức thực hiện kế hoạch; hướng dẫn các tổ chuyên môn rà soát, lựa chọn, cập nhật tài liệu; theo dõi tiến độ, chất lượng và hiệu quả khai thác.
>
> **3. Tổ trưởng chuyên môn:** Tổ chức giáo viên lựa chọn, chia sẻ, sử dụng học liệu; lồng ghép đánh giá hiệu quả sử dụng trong sinh hoạt chuyên môn; đề xuất bổ sung, điều chỉnh phù hợp.
>
> **4. Giáo viên:** Chủ động khai thác, vận dụng học liệu phù hợp với trẻ và điều kiện nhóm, lớp; chia sẻ những sản phẩm có chất lượng, được phép sử dụng; tham gia góp ý, hoàn thiện nguồn học liệu.
>
> **5. Nhân sự phụ trách công nghệ thông tin:** Hỗ trợ thiết lập, quản lý, phân quyền truy cập, sao lưu dữ liệu và xử lý khó khăn kỹ thuật.
>
> Nhà trường ưu tiên sử dụng thiết bị, nền tảng lưu trữ và các nguồn lực hiện có; việc bổ sung kinh phí, nếu cần, thực hiện theo dự toán được phê duyệt và quy định hiện hành.
>
> Ban Giám hiệu theo dõi tiến độ thông qua hoạt động chuyên môn thường xuyên; cuối năm học tổ chức đánh giá kết quả, tập trung vào **chất lượng học liệu, mức độ khai thác và hiệu quả hỗ trợ giáo viên**, làm cơ sở tiếp tục hoàn thiện kho trong năm học 2027–2028.
>
> Trên đây là Kế hoạch xây dựng và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 của Trường Mầm non … Đề nghị các tổ chuyên môn, cán bộ, giáo viên và bộ phận liên quan nghiêm túc triển khai thực hiện.
>
> **Nơi nhận:**
> - Ban Giám hiệu;
> - Các tổ chuyên môn, bộ phận liên quan;
> - Lưu: VT, CM.
>
> **HIỆU TRƯỞNG**  
> *(Ký, ghi rõ họ tên, đóng dấu)*

## ✅ Điểm trọng tâm của bản rút gọn

Bản này xác định rõ bốn công việc chính, thực hiện theo trình tự:

**1. Rà soát**

Tập hợp nguồn tài liệu, học liệu của ba trường cũ.

**2. Thiết lập**

Tạo một hệ thống lưu trữ và tra cứu thống nhất.

**3. Chuẩn hóa**

Chọn lọc, kiểm tra và bổ sung học liệu cần thiết.

**4. Khai thác**

Chia sẻ, sử dụng và cải tiến trong sinh hoạt chuyên môn.

**Tôi đánh giá cấu trúc 5 phần này phù hợp hơn để Hiệu trưởng triển khai và kiểm tra thực hiện.** Phần IV trả lời trực tiếp câu hỏi *làm gì, làm như thế nào, kết quả gì, ai thực hiện và khi nào hoàn thành*. Các nội dung về kinh phí, kiểm tra, đánh giá được tích hợp vào phần tổ chức thực hiện, không cần tách thành các mục lớn.

Các căn cứ pháp lý chính cũng đã được đối chiếu với nguồn công bố văn bản năm 2026. [Source unavailable: turn133596search0]; [Source unavailable: turn133596search4]; [Source unavailable: turn133596search5] Khi hoàn thiện bản ký ban hành, nhà trường chỉ cần bổ sung số quyết định sáp nhập và thông tin thực tế của đơn vị.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

rút thì rút ngằn không tả được. Bạn vẫn chưa hiểu phong cách làm việc của mình à?

---

ASSISTANT

Bạn nhận xét đúng. Tôi đã rút ngắn theo kiểu cắt nội dung, khiến kế hoạch mất chiều sâu và chưa thể hiện rõ tư duy quản lý sau sáp nhập. Tôi sẽ chỉnh lại theo hướng **cô đọng nhưng có lập luận**, giữ phần phân tích thực trạng đủ sức thuyết phục và viết giải pháp thành những công việc có cách triển khai cụ thể, thay vì liệt kê sơ lược.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Bạn nói đúng. Tôi đã hiểu chưa đúng phong cách làm việc mà bạn thể hiện qua các lần trao đổi.

Bạn cần một bản kế hoạch **cô đọng về câu chữ nhưng phải sâu về nội dung**, chứ không phải rút ngắn bằng cách lược bỏ những lập luận và giải pháp quan trọng.

Qua những lần bạn góp ý, tôi hiểu rõ hơn yêu cầu của bạn:

- **Phần thực trạng:** Phải phân tích được bối cảnh sáp nhập 3 trường, nêu đúng vấn đề quản lý cần giải quyết, không viết chung chung.
- **Phần mục tiêu:** Phải xác định được những kết quả thực chất nhà trường cần đạt, không chạy theo chỉ tiêu hình thức.
- **Phần nội dung, giải pháp:** Phải làm rõ việc gì cần triển khai, triển khai như thế nào, ai thực hiện, kết quả ra sao. Đây là phần cần đầu tư chiều sâu nhất.
- **Văn phong:** Hành chính chuẩn mực, lập luận chặt chẽ, súc tích, có tính thuyết phục; không liệt kê nhiều ý vụn, cũng không diễn giải dài dòng.

**Tôi sẽ giữ cấu trúc 5 phần nhưng viết lại theo tư duy quản trị của Hiệu trưởng**, trong đó phần II chứng minh sự cần thiết của kế hoạch và phần IV thể hiện rõ phương án tổ chức thực hiện. Bản này không rút cơ học mà tập trung loại bỏ ý trùng, giữ đủ nội dung chuyên môn.

> **writing · document**
>
> **ỦY BAN NHÂN DÂN [XÃ/PHƯỜNG]**  
> **TRƯỜNG MẦM NON [TÊN TRƯỜNG]**
>
> Số: …/KH-MN…
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *[Địa danh], ngày … tháng … năm 2026*
>
> # KẾ HOẠCH
> **Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027**
>
> Căn cứ Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020 của Bộ Giáo dục và Đào tạo ban hành Điều lệ trường mầm non và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Thông tư số 60/2026/TT-BGDĐT ngày 17/7/2026 của Bộ Giáo dục và Đào tạo quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non;
>
> Căn cứ Công văn số 5385/BGDĐT-GDMN ngày 12/8/2026 của Bộ Giáo dục và Đào tạo về hướng dẫn thực hiện nhiệm vụ giáo dục mầm non năm học 2026–2027;
>
> Căn cứ Quyết định số … ngày … của … về việc sáp nhập ba trường mầm non …;
>
> Căn cứ Kế hoạch thực hiện nhiệm vụ năm học 2026–2027 và tình hình thực tế của nhà trường;
>
> Trường Mầm non … xây dựng Kế hoạch xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 với những nội dung sau:
>
> ## I. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> Xây dựng kho tài liệu, học liệu dùng chung trên cơ sở kế thừa, chọn lọc và phát huy nguồn tài nguyên chuyên môn của ba trường trước sáp nhập; từng bước hình thành hệ thống lưu trữ, quản lý và chia sẻ tài liệu thống nhất trong toàn trường.
>
> Tạo điều kiện để giáo viên tiếp cận nguồn học liệu có chất lượng, trao đổi kinh nghiệm, phát huy năng lực chuyên môn; hạn chế việc xây dựng trùng lặp, tiết kiệm thời gian chuẩn bị và nâng cao hiệu quả tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ.
>
> ### 2. Yêu cầu
>
> - Việc xây dựng kho phải phù hợp với điều kiện thực tế, nhu cầu sử dụng và khả năng khai thác của đội ngũ; ưu tiên tận dụng nguồn tài liệu, học liệu hiện có.
> - Tài liệu, học liệu được lựa chọn phải bảo đảm tính khoa học, sư phạm, an toàn, phù hợp với Chương trình giáo dục mầm non và đặc điểm phát triển của trẻ.
> - Kho dùng chung phải được tổ chức khoa học, dễ tìm kiếm, cập nhật và chia sẻ; có phân công quản lý, kiểm soát chất lượng và bảo đảm an toàn thông tin.
> - Gắn việc xây dựng kho với hoạt động chuyên môn thường xuyên; chú trọng hiệu quả khai thác, không chạy theo số lượng sản phẩm hoặc làm phát sinh hồ sơ không cần thiết.
>
> ## II. ĐẶC ĐIỂM TÌNH HÌNH
>
> Năm học 2026–2027, nhà trường được tổ chức lại trên cơ sở sáp nhập ba trường mầm non thành một đơn vị thống nhất. Việc sáp nhập tạo điều kiện tập trung nguồn lực về đội ngũ, cơ sở vật chất, trang thiết bị và tài liệu chuyên môn; đồng thời đặt ra yêu cầu đổi mới phương thức quản lý, tăng cường sự phối hợp, thống nhất trong chỉ đạo và tổ chức thực hiện nhiệm vụ giáo dục trên toàn trường.
>
> Trước sáp nhập, mỗi trường đã có quá trình xây dựng, tích lũy nguồn tài liệu, học liệu và những kinh nghiệm tổ chức hoạt động giáo dục phù hợp với điều kiện của đơn vị. Đây là nguồn lực chuyên môn có giá trị, tạo thuận lợi cho việc kế thừa, chia sẻ và phát huy những cách làm hiệu quả. Tuy nhiên, nguồn tài liệu, học liệu được hình thành và lưu trữ tại từng trường, chưa được tổ chức thành hệ thống dùng chung cấp trường sau sáp nhập. Nếu không được rà soát, lựa chọn và quản lý thống nhất, nguồn tài nguyên này dễ tiếp tục phân tán, trùng lặp, gây khó khăn trong tìm kiếm, khai thác và chưa phát huy hết giá trị sử dụng.
>
> Mặt khác, đội ngũ giáo viên được tập hợp từ các đơn vị khác nhau, có những thế mạnh, kinh nghiệm và cách thức khai thác học liệu riêng. Điều này vừa tạo cơ hội học hỏi, bổ trợ chuyên môn, vừa đòi hỏi nhà trường phải có cơ chế kết nối, chia sẻ và hỗ trợ phù hợp. Đặc biệt, việc bảo đảm giáo viên ở các nhóm, lớp, điểm trường được tiếp cận nguồn học liệu có chất lượng là yêu cầu quan trọng để từng bước nâng cao chất lượng giáo dục đồng đều trong toàn trường.
>
> Từ thực tế trên, việc xây dựng kho tài liệu, học liệu dùng chung là nhiệm vụ cần thiết trong giai đoạn đầu sau sáp nhập, nhằm **thống nhất quản lý, khai thác hiệu quả nguồn lực hiện có, tăng cường kết nối đội ngũ và tạo nền tảng phát triển chuyên môn bền vững**. Kho dùng chung không chỉ là nơi tập hợp tài liệu mà phải trở thành nguồn hỗ trợ thiết thực cho giáo viên trong quá trình thực hiện Chương trình giáo dục mầm non.
>
> ## III. CHỈ TIÊU THỰC HIỆN
>
> 1. Xây dựng và đưa vào sử dụng 01 kho tài liệu, học liệu dùng chung cấp trường, có cấu trúc thống nhất, phân loại khoa học và phân quyền quản lý rõ ràng.
> 2. 100% tổ chuyên môn tham gia rà soát, lựa chọn, bổ sung và khai thác học liệu; mỗi khối tuổi có danh mục học liệu dùng chung phù hợp với kế hoạch giáo dục.
> 3. 100% cán bộ quản lý, giáo viên được hướng dẫn sử dụng kho; phấn đấu ít nhất 80% giáo viên khai thác thường xuyên sau giai đoạn triển khai.
> 4. 100% học liệu đưa vào danh mục sử dụng chính thức được kiểm tra về nội dung, nguồn gốc, tính phù hợp và thực hiện quy trình lựa chọn, phê duyệt theo quy định.
> 5. Duy trì việc chia sẻ, đánh giá, bổ sung học liệu thông qua sinh hoạt chuyên môn; cuối năm học đánh giá được hiệu quả sử dụng để tiếp tục hoàn thiện kho.
>
> ## IV. NỘI DUNG VÀ GIẢI PHÁP THỰC HIỆN
>
> ### 1. Rà soát, lựa chọn và kế thừa nguồn tài liệu, học liệu của ba trường trước sáp nhập
>
> Tổ chức rà soát các nguồn tài liệu chuyên môn, học liệu số, tranh ảnh, video, trò chơi, đồ dùng, đồ chơi tự tạo và những sản phẩm giáo dục có giá trị sử dụng đang được lưu trữ tại các đơn vị trước sáp nhập.
>
> Việc rà soát không chỉ nhằm thống kê số lượng mà tập trung đánh giá chất lượng, khả năng sử dụng và mức độ phù hợp với nhu cầu chuyên môn hiện nay. Trên cơ sở đó, phân loại thành các nhóm: tài liệu có thể sử dụng ngay; tài liệu cần điều chỉnh, bổ sung; tài liệu trùng lặp hoặc không còn phù hợp.
>
> Ban Giám hiệu giao các tổ chuyên môn chủ động thực hiện, ưu tiên lựa chọn những sản phẩm đã được vận dụng hiệu quả, có khả năng chia sẻ cho nhiều nhóm, lớp. Đối với những học liệu có nội dung tương đồng, tổ chức trao đổi, chọn lọc phiên bản phù hợp thay vì lưu trữ dàn trải.
>
> **Kết quả cần đạt:** Hình thành danh mục tài liệu, học liệu được kế thừa từ ba trường, làm cơ sở xây dựng kho dùng chung; đồng thời xác định rõ những nội dung còn thiếu cần bổ sung.
>
> ### 2. Xây dựng và tổ chức quản lý kho tài liệu, học liệu dùng chung
>
> Trên cơ sở kết quả rà soát, nhà trường lựa chọn nền tảng lưu trữ số phù hợp với điều kiện thực tế để xây dựng kho dùng chung, bảo đảm dễ truy cập, dễ tìm kiếm, thuận tiện cập nhật và sử dụng.
>
> Kho được phân thành các nhóm tài liệu chủ yếu:
>
> - **Tài liệu quản lý và bồi dưỡng chuyên môn:** Văn bản hướng dẫn, tài liệu tập huấn, sinh hoạt chuyên môn, chuyên đề và những tài liệu nghiệp vụ được phép chia sẻ.
> - **Học liệu giáo dục theo độ tuổi:** Tranh ảnh, video, âm thanh, trò chơi, tài liệu hướng dẫn tổ chức hoạt động theo các lĩnh vực phát triển và nội dung giáo dục.
> - **Học liệu chăm sóc, nuôi dưỡng và giáo dục kỹ năng:** Tài liệu hướng dẫn giáo dục dinh dưỡng, vệ sinh, kỹ năng tự phục vụ, an toàn và những nội dung phù hợp.
> - **Học liệu trải nghiệm, đồ dùng, đồ chơi:** Hướng dẫn tổ chức hoạt động thực hành, trải nghiệm, trò chơi dân gian; đồ dùng, đồ chơi tự tạo và nguồn học liệu gắn với điều kiện địa phương.
>
> Đối với đồ dùng, đồ chơi và học liệu hiện vật, xây dựng danh mục dùng chung có thông tin về vị trí lưu giữ, tình trạng và khả năng sử dụng; không nhất thiết tập trung toàn bộ về một địa điểm mà tổ chức quản lý, chia sẻ phù hợp với điều kiện các cơ sở.
>
> Thống nhất cách đặt tên, phân loại, cập nhật tài liệu; phân công người phụ trách quản lý và phân quyền truy cập, chỉnh sửa. Mỗi tài liệu cần có những thông tin cơ bản về tên, nguồn gốc, độ tuổi hoặc đối tượng sử dụng để giáo viên dễ lựa chọn.
>
> **Kết quả cần đạt:** Hình thành hệ thống kho thống nhất cấp trường, có danh mục tra cứu và phương thức quản lý, khai thác rõ ràng, khắc phục tình trạng lưu trữ phân tán sau sáp nhập.
>
> ### 3. Chuẩn hóa chất lượng và bổ sung học liệu theo nhu cầu thực tế
>
> Trên cơ sở nguồn tài liệu đã được tập hợp, tổ chuyên môn tiến hành rà soát nội dung, tính chính xác, yêu cầu sư phạm, mức độ an toàn, sự phù hợp với độ tuổi và khả năng vận dụng vào hoạt động giáo dục.
>
> Việc lựa chọn, phê duyệt đồ chơi, học liệu thực hiện theo quy định hiện hành. Những tài liệu chưa phù hợp được điều chỉnh trước khi sử dụng; tài liệu không rõ nguồn gốc, vi phạm quyền tác giả hoặc không đáp ứng yêu cầu an toàn không đưa vào danh mục chính thức.
>
> Song song với chuẩn hóa nguồn hiện có, các tổ chuyên môn xác định những nội dung học liệu còn thiếu trên cơ sở kế hoạch giáo dục và nhu cầu thực tế của giáo viên. Ưu tiên phát triển học liệu hỗ trợ trẻ học thông qua chơi, thực hành, trải nghiệm; học liệu mở, dễ điều chỉnh và có thể sử dụng ở nhiều nhóm, lớp.
>
> Phát huy thế mạnh của đội ngũ giáo viên đến từ ba trường trước sáp nhập, khuyến khích giáo viên phối hợp xây dựng, cải tiến học liệu theo khối tuổi, lĩnh vực phát triển. Không giao nhiệm vụ làm mới học liệu theo số lượng cứng nhắc khi nguồn hiện có vẫn đáp ứng yêu cầu.
>
> **Kết quả cần đạt:** Hình thành nguồn học liệu được lựa chọn, chuẩn hóa theo từng khối tuổi; có khả năng sử dụng thực tế, hạn chế trùng lặp và nâng cao chất lượng tài nguyên chuyên môn chung.
>
> ### 4. Tổ chức khai thác kho gắn với sinh hoạt chuyên môn và hoạt động giáo dục
>
> Đây là nội dung trọng tâm quyết định hiệu quả của kế hoạch. Nhà trường tổ chức hướng dẫn giáo viên cách truy cập, tìm kiếm, lựa chọn và sử dụng học liệu phù hợp với kế hoạch giáo dục, đặc điểm trẻ và điều kiện nhóm, lớp.
>
> Gắn việc khai thác kho với sinh hoạt chuyên môn định kỳ. Mỗi tổ chuyên môn lựa chọn những học liệu tiêu biểu để giới thiệu, trao đổi cách sử dụng, những khó khăn khi vận dụng và đề xuất điều chỉnh. Khuyến khích giáo viên giữa các đơn vị trước sáp nhập chia sẻ kinh nghiệm, những sản phẩm có chất lượng và hỗ trợ đồng nghiệp trong quá trình sử dụng.
>
> Trong tổ chức hoạt động giáo dục, giáo viên chủ động lựa chọn, điều chỉnh học liệu theo nhu cầu, khả năng của trẻ; không sử dụng máy móc hoặc đồng loạt một hình thức cho tất cả nhóm, lớp. Ưu tiên học liệu tạo cơ hội để trẻ trực tiếp thao tác, trải nghiệm, khám phá và phát huy tính tích cực, chủ động.
>
> Ban Giám hiệu theo dõi việc khai thác thông qua kế hoạch giáo dục, dự giờ, sinh hoạt chuyên môn và trao đổi với giáo viên; kịp thời hỗ trợ những khó khăn về kỹ thuật, điều kiện thiết bị và phương pháp sử dụng.
>
> **Kết quả cần đạt:** Kho tài liệu được giáo viên sử dụng thường xuyên, góp phần tiết kiệm thời gian chuẩn bị, tăng cường chia sẻ chuyên môn và nâng cao chất lượng tổ chức hoạt động giáo dục trong toàn trường.
>
> ### 5. Duy trì, cập nhật và đánh giá hiệu quả sử dụng
>
> Nhà trường phân công đầu mối quản lý kho, phối hợp với các tổ chuyên môn định kỳ rà soát, bổ sung, điều chỉnh và loại bỏ tài liệu không còn phù hợp; thực hiện sao lưu dữ liệu, kiểm soát quyền truy cập và bảo đảm an toàn thông tin.
>
> Việc đánh giá tập trung vào chất lượng, mức độ phù hợp, khả năng tiếp cận và hiệu quả vận dụng học liệu trong thực tế; không lấy số lượng tệp tài liệu hoặc lượt đăng tải làm tiêu chí chủ yếu.
>
> Thông qua sinh hoạt chuyên môn và kiểm tra thường xuyên, ghi nhận những học liệu có giá trị sử dụng, những nội dung cần bổ sung và những khó khăn trong quá trình khai thác để có biện pháp cải tiến kịp thời.
>
> **Kết quả cần đạt:** Kho tài liệu được duy trì, cập nhật và phát huy giá trị lâu dài, từng bước trở thành nguồn tài nguyên chuyên môn ổn định của nhà trường.
>
> ## V. TỔ CHỨC THỰC HIỆN
>
> ### 1. Tiến độ thực hiện
>
> | Thời gian | Nội dung trọng tâm | Bộ phận thực hiện |
> |---|---|---|
> | **11/2026** | Rà soát, tập hợp, phân loại nguồn tài liệu, học liệu từ ba trường trước sáp nhập | BGH, tổ chuyên môn |
> | **12/2026** | Thiết lập cấu trúc kho, phân quyền, hướng dẫn giáo viên; cập nhật học liệu ban đầu | BGH, nhân sự CNTT, tổ chuyên môn |
> | **01–3/2027** | Lựa chọn, chuẩn hóa, bổ sung học liệu theo khối tuổi; tổ chức khai thác và chia sẻ chuyên môn | Phó Hiệu trưởng, tổ chuyên môn, giáo viên |
> | **4/2027** | Rà soát chất lượng, đánh giá bước đầu hiệu quả khai thác; điều chỉnh nội dung chưa phù hợp | BGH, tổ chuyên môn |
> | **5/2027** | Tổng hợp, đánh giá kết quả; hoàn thiện kho và định hướng duy trì năm học tiếp theo | BGH, các tổ chuyên môn |
>
> ### 2. Phân công trách nhiệm
>
> **Hiệu trưởng:** Chỉ đạo chung, phê duyệt kế hoạch, phân công nhiệm vụ và bảo đảm điều kiện thực hiện; thực hiện trách nhiệm lựa chọn, phê duyệt học liệu theo thẩm quyền; kiểm tra và đánh giá kết quả triển khai.
>
> **Phó Hiệu trưởng phụ trách chuyên môn:** Trực tiếp tổ chức thực hiện, hướng dẫn các tổ chuyên môn rà soát, lựa chọn, chuẩn hóa và cập nhật học liệu; theo dõi tiến độ, chất lượng và hiệu quả khai thác.
>
> **Tổ trưởng chuyên môn:** Tổ chức giáo viên trong tổ lựa chọn, chia sẻ, khai thác học liệu; lồng ghép trao đổi, đánh giá hiệu quả sử dụng vào sinh hoạt chuyên môn; đề xuất những nội dung cần bổ sung, điều chỉnh.
>
> **Giáo viên:** Chủ động khai thác, vận dụng học liệu phù hợp với trẻ; chia sẻ sản phẩm có chất lượng, được phép sử dụng; phối hợp xây dựng và cải tiến nguồn học liệu dùng chung.
>
> **Nhân sự phụ trách công nghệ thông tin:** Hỗ trợ thiết lập nền tảng, quản lý tài khoản, phân quyền, sao lưu dữ liệu và xử lý những khó khăn kỹ thuật phát sinh.
>
> Nhà trường ưu tiên sử dụng các nguồn lực, thiết bị và nền tảng hiện có; kinh phí bổ sung, nếu cần thiết, được thực hiện theo dự toán được phê duyệt và quy định hiện hành.
>
> ### 3. Kiểm tra, đánh giá
>
> Ban Giám hiệu theo dõi tiến độ thực hiện thông qua hoạt động chuyên môn thường xuyên, tập trung vào ba nội dung: mức độ hoàn thiện kho, chất lượng nguồn học liệu và hiệu quả khai thác của giáo viên.
>
> Kịp thời biểu dương những tổ, cá nhân có đóng góp thiết thực; đồng thời hỗ trợ, tháo gỡ khó khăn, bảo đảm kho học liệu được sử dụng hiệu quả tại các nhóm, lớp.
>
> Cuối năm học, tổ chức đánh giá kết quả thực hiện, xác định nội dung cần tiếp tục bổ sung, hoàn thiện để duy trì và phát triển kho trong các năm học tiếp theo.
>
> Trên đây là Kế hoạch xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 của Trường Mầm non … Đề nghị các tổ chuyên môn, cán bộ, giáo viên và bộ phận liên quan nghiêm túc triển khai thực hiện.
>
> **Nơi nhận:**
> - Ban Giám hiệu;
> - Các tổ chuyên môn, bộ phận liên quan;
> - Lưu: VT, CM.
>
> **HIỆU TRƯỞNG**  
> *(Ký, ghi rõ họ tên, đóng dấu)*

---

Điều tôi muốn giữ nhất trong bản này là **sự kết nối giữa phần II và phần IV**: thực trạng tài liệu phân tán sau sáp nhập thì phải có giải pháp rà soát, tích hợp; đội ngũ từ ba trường có thế mạnh khác nhau thì phải tổ chức chia sẻ; đã xây dựng kho thì phải có cơ chế khai thác, kiểm soát chất lượng và duy trì.

Đó mới là cách cô đọng mà vẫn giữ được chiều sâu của một kế hoạch quản lý. Các căn cứ chuyên ngành năm 2026 trong dự thảo cũng đã được kiểm tra với nguồn công bố chính thức. [Source unavailable: turn173100search0]; [Source unavailable: turn173100search1]; [Source unavailable: turn249521search0]

**Tôi hiểu yêu cầu của bạn là: văn bản không cần dài để thể hiện sự đầy đủ, nhưng mỗi nội dung được giữ lại phải thật sự có giá trị chỉ đạo và có thể tổ chức thực hiện.** Đây sẽ là nguyên tắc tôi bám sát khi tiếp tục cùng bạn hoàn thiện các văn bản chuyên môn.

---

USER

bạn còn nhớ 3 tên trường không add vô nội dung để tăng tính chuyên nghiệp

---

ASSISTANT

Tôi hiểu ý bạn. Việc nêu **tên cụ thể của ba trường trước sáp nhập** sẽ giúp kế hoạch có tính xác thực, chuyên nghiệp và thể hiện rõ đặc thù của đơn vị.

Tuy nhiên, trong nội dung cuộc trao đổi hiện tại, tôi chưa thấy tên chính thức của ba trường. Tôi không muốn tự suy đoán vì dễ làm sai thông tin trong văn bản của nhà trường.

**Bạn nhắc lại giúp tôi tên 3 trường trước sáp nhập và tên trường mới sau sáp nhập nhé.**

Tôi sẽ đưa các tên này vào những vị trí thực sự cần thiết, đặc biệt là phần **căn cứ, đặc điểm tình hình và giải pháp rà soát, kế thừa nguồn học liệu**, để tăng tính thuyết phục mà không lặp lại tên trường quá nhiều, gây nặng văn bản.

---

USER

sếp chỉ đạo Gộp chung cho KH của ban truyền thông CDS. Tuy nhiên mình đã lập KH và ban chỉ đạo rồi, nếu gộp mình phải gộp như thế nào cho hợp lý

---

ASSISTANT

Theo tôi, **chỉ đạo của lãnh đạo về việc gộp kế hoạch xây dựng kho tài liệu, học liệu dùng chung vào Kế hoạch của Ban Truyền thông và Chuyển đổi số là hợp lý**. Tuy nhiên, cần gộp đúng cách để vừa thực hiện chỉ đạo, vừa giữ được nội dung chuyên môn bạn đã xây dựng và không làm phát sinh hai hệ thống chỉ đạo song song.

Với đặc thù nhà trường vừa sáp nhập từ 3 trường, tôi đề xuất:

**Một kế hoạch chung – Một đầu mối chỉ đạo – Phân công chuyên môn rõ ràng – Không làm mất nội dung trọng tâm.**

Điều quan trọng là phải phân biệt:

- **Ban Truyền thông và Chuyển đổi số:** Chịu trách nhiệm điều phối chung, tổ chức hạ tầng số, quản lý hệ thống lưu trữ và hỗ trợ triển khai.
- **Bộ phận chuyên môn:** Chịu trách nhiệm rà soát, lựa chọn, thẩm định nội dung, tổ chức khai thác và đánh giá chất lượng tài liệu, học liệu.

Như vậy, xây dựng kho học liệu là **một nhiệm vụ trọng tâm thuộc hoạt động chuyển đổi số của nhà trường**, nhưng chất lượng học liệu vẫn phải do bộ phận chuyên môn chịu trách nhiệm. Không nên biến nhiệm vụ này thành hoạt động đăng tải, truyền thông đơn thuần.

## 1. Gộp như thế nào để không phải làm lại toàn bộ?

Tôi đề xuất phương án sau:

**KẾ HOẠCH TRUYỀN THÔNG VÀ CHUYỂN ĐỔI SỐ**

Văn bản chung, thống nhất chỉ đạo và tổ chức thực hiện

**Truyền thông**

Thông tin, hình ảnh, tuyên truyền và kết nối cộng đồng

**Chuyển đổi số**

Ứng dụng CNTT, số hóa và quản lý dữ liệu

**Nhiệm vụ trọng tâm: Xây dựng kho tài liệu, học liệu dùng chung**

Chuyên môn chịu trách nhiệm nội dung; bộ phận chuyển đổi số hỗ trợ hệ thống và vận hành

Khi đó, kế hoạch bạn đã soạn không bị bỏ đi mà được **tích hợp thành một nhiệm vụ trọng tâm của Kế hoạch Truyền thông và Chuyển đổi số**. Những nội dung chi tiết cần thiết có thể chuyển thành phụ lục triển khai.

Cách này phù hợp với chỉ đạo gộp chung, đồng thời giữ được sự đầu tư chuyên môn trong kế hoạch ban đầu.

## 2. Xử lý kế hoạch và Ban Chỉ đạo đã thành lập

Đây là vấn đề cần làm rõ nhất về mặt quản lý văn bản.

| Tình trạng hiện có | Hướng xử lý phù hợp |
|--------|--------|
| Kế hoạch xây dựng kho mới soạn, chưa ký ban hành | Tích hợp nội dung vào kế hoạch chung; không ban hành thêm kế hoạch riêng |
| Kế hoạch đã ký ban hành | Tham mưu điều chỉnh hoặc xác định rõ việc thực hiện thống nhất theo kế hoạch chung; xử lý hiệu lực văn bản cũ, tránh hai kế hoạch chồng chéo |
| Quyết định thành lập Ban Chỉ đạo xây dựng kho mới dự thảo | Không cần lập Ban riêng; bổ sung nhiệm vụ và nhân sự phù hợp vào Ban Truyền thông và Chuyển đổi số |
| Quyết định thành lập Ban Chỉ đạo đã ký | Tham mưu quyết định kiện toàn, điều chỉnh hoặc thay thế quyết định liên quan; quy định rõ trách nhiệm tiếp nhận công việc |

**Lưu ý rất quan trọng:** Ban Chỉ đạo xây dựng kho tài liệu, học liệu không đồng nhất với Hội đồng lựa chọn đồ chơi, học liệu theo Thông tư 60/2026/TT-BGDĐT. Nếu quyết định bạn đã lập thực chất là Hội đồng lựa chọn theo quy định thì cần giữ đúng cơ cấu, thẩm quyền và quy trình của Hội đồng, không tự động thay thế bằng Ban Truyền thông và Chuyển đổi số. [Thông tư số 60/2026/TT\-BGDĐT quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non](<https://congbao.chinhphu.vn/van-ban/thong-tu-so-60-2026-tt-bgddt-470131/67273.htm>); [Thông tư 60/2026/TT\-BGDĐT biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non mới nhất](<https://thuvienphapluat.vn/van-ban/Giao-duc/Thong-tu-60-2026-TT-BGDDT-bien-soan-tai-lieu-huong-dan-thuc-hien-Chuong-trinh-giao-duc-mam-non-714818.aspx?anchor=dieu_10>)

## 3. Cấu trúc kế hoạch chung sau khi gộp

Để kế hoạch không bị rối, tôi đề xuất cấu trúc 5 phần:

**I. Mục đích, yêu cầu**

**II. Đặc điểm tình hình:** Trong đó nêu rõ đặc thù nhà trường sau sáp nhập ba trường, yêu cầu thống nhất quản trị, thông tin và nguồn tài nguyên số.

**III. Chỉ tiêu thực hiện:** Phân biệt chỉ tiêu truyền thông và chỉ tiêu chuyển đổi số, trong đó có chỉ tiêu xây dựng kho học liệu dùng chung.

**IV. Nội dung và giải pháp thực hiện:**

- Công tác truyền thông.
- Công tác chuyển đổi số.
- Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung.

**V. Tổ chức thực hiện:** Tiến độ, phân công, kiểm tra, đánh giá.

Trong phần IV, nội dung kho học liệu cần có trọng tâm riêng, không chỉ viết một câu như "Xây dựng kho học liệu số phục vụ giáo viên".

### Phần tích hợp vào kế hoạch chung có thể viết như sau

> **writing · document**
>
> ### 3. Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung
>
> Trên cơ sở sáp nhập ba trường mầm non, nhà trường tập trung rà soát, kế thừa và phát huy nguồn tài liệu, học liệu đã được tích lũy tại các đơn vị trước đây; từng bước xây dựng hệ thống lưu trữ, quản lý và chia sẻ thống nhất, phục vụ công tác chỉ đạo chuyên môn và tổ chức các hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ.
>
> **3.1. Rà soát, lựa chọn và tập hợp nguồn học liệu**
>
> Các tổ chuyên môn tiến hành rà soát nguồn tài liệu, học liệu hiện có tại các điểm trường; đánh giá chất lượng, tính phù hợp và khả năng sử dụng. Ưu tiên lựa chọn những tài liệu có giá trị thực tiễn, hạn chế trùng lặp, đồng thời xác định những nội dung còn thiếu cần bổ sung.
>
> **3.2. Thiết lập và quản lý kho dùng chung**
>
> Ban Truyền thông và Chuyển đổi số phối hợp với bộ phận chuyên môn xây dựng kho lưu trữ trên nền tảng số phù hợp với điều kiện nhà trường. Tài liệu được phân loại theo nhóm nội dung, khối tuổi và lĩnh vực giáo dục; thống nhất cách đặt tên, cập nhật, phân quyền truy cập và bảo đảm an toàn dữ liệu.
>
> **3.3. Chuẩn hóa, bổ sung và kiểm soát chất lượng học liệu**
>
> Phó Hiệu trưởng phụ trách chuyên môn chỉ đạo các tổ chuyên môn lựa chọn, chuẩn hóa và đề xuất bổ sung những học liệu cần thiết. Việc lựa chọn, phê duyệt học liệu thuộc phạm vi quy định được thực hiện theo đúng thẩm quyền và quy trình hiện hành. Khuyến khích phát huy thế mạnh của giáo viên ở các đơn vị trước sáp nhập trong chia sẻ, xây dựng và cải tiến học liệu.
>
> **3.4. Tổ chức khai thác và đánh giá hiệu quả**
>
> Hướng dẫn giáo viên truy cập, tìm kiếm và sử dụng kho; lồng ghép hoạt động chia sẻ, trao đổi kinh nghiệm khai thác học liệu trong sinh hoạt chuyên môn. Ban Giám hiệu theo dõi hiệu quả sử dụng, kịp thời hỗ trợ, điều chỉnh và bổ sung, bảo đảm kho học liệu phục vụ thiết thực hoạt động giáo dục, không mang tính hình thức.
>
> **Kết quả phấn đấu:** Xây dựng 01 kho tài liệu, học liệu dùng chung cấp trường; 100% tổ chuyên môn tham gia xây dựng và khai thác; 100% giáo viên được hướng dẫn sử dụng; các khối tuổi có danh mục học liệu phù hợp, được cập nhật và phát triển thường xuyên.

## 4. Phân công như thế nào để tránh chồng chéo?

Đây là điểm tôi cho rằng bạn nên tham mưu thật rõ với lãnh đạo.

| Bộ phận | Trách nhiệm chính |
|--------|--------|
| Hiệu trưởng | Chỉ đạo, phê duyệt và kiểm tra chung |
| Ban Truyền thông và Chuyển đổi số | Điều phối nhiệm vụ, xây dựng và vận hành hệ thống, hỗ trợ kỹ thuật |
| Phó Hiệu trưởng phụ trách chuyên môn | Chủ trì nội dung kho tài liệu, học liệu; chỉ đạo lựa chọn và tổ chức khai thác |
| Tổ trưởng chuyên môn | Rà soát, phân loại, đề xuất và kiểm tra chất lượng tài liệu |
| Giáo viên | Chia sẻ, sử dụng và phản hồi hiệu quả học liệu |

Bên cạnh phân công trên, Hội đồng lựa chọn đồ chơi, học liệu thực hiện nhiệm vụ theo quy định chuyên ngành khi có nội dung thuộc phạm vi phải lựa chọn.

## 5. Phương án tôi đề xuất bạn trình lãnh đạo

Nếu kế hoạch và quyết định thành lập Ban Chỉ đạo xây dựng kho chưa ban hành, bạn có thể đề xuất với Hiệu trưởng theo hướng:

> Thực hiện ý kiến chỉ đạo của lãnh đạo về việc gộp kế hoạch, bộ phận chuyên môn đề xuất tích hợp nhiệm vụ xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung vào Kế hoạch Truyền thông và Chuyển đổi số năm học 2026–2027, xác định đây là một nhiệm vụ trọng tâm của công tác chuyển đổi số.
>
> Ban Truyền thông và Chuyển đổi số thực hiện vai trò điều phối, hỗ trợ kỹ thuật và quản lý nền tảng; bộ phận chuyên môn chủ trì nội dung, lựa chọn, khai thác và đánh giá chất lượng học liệu. Đồng thời, kiện toàn phân công nhiệm vụ để bảo đảm thống nhất đầu mối chỉ đạo, tránh thành lập các bộ phận có chức năng chồng chéo.
>
> Nội dung kế hoạch xây dựng kho đã được chuẩn bị sẽ được kế thừa, chọn lọc và tích hợp vào kế hoạch chung, bảo đảm tính khả thi và không làm mất đi những nhiệm vụ chuyên môn cần thiết.

### ✅ Kết luận

Tôi nghiêng về phương án **một kế hoạch chung, không lập Ban Chỉ đạo xây dựng kho riêng nếu nhiệm vụ đã được giao đầy đủ cho Ban Truyền thông và Chuyển đổi số**. Tuy nhiên, không nên giao toàn bộ trách nhiệm kho học liệu cho bộ phận chuyển đổi số, vì đây vẫn là nhiệm vụ có yêu cầu chuyên môn giáo dục rất rõ.

**Có một chi tiết tôi cần bạn xác nhận để hướng dẫn xử lý hồ sơ cho chính xác: Quyết định thành lập Ban Chỉ đạo và kế hoạch xây dựng kho học liệu mà bạn đã lập hiện đã được Hiệu trưởng ký ban hành hay mới ở dạng dự thảo?** Hai trường hợp này sẽ khác nhau về cách gộp và xử lý văn bản.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

USER

đây là nội dung đã thực hiện và ký duyệt. bạn giúp mình cho phương án xử lý

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# PHƯƠNG ÁN XỬ LÝ HỒ SƠ TRUYỀN THÔNG, CHUYỂN ĐỔI SỐ VÀ KHO HỌC LIỆU DÙNG CHUNG

**Trường Mầm non An Bình – Năm học 2026–2027**

Tôi đã đối chiếu hai văn bản đã ký của Trường Mầm non An Bình. Qua xem xét, tôi nhận thấy **nhà trường không cần thành lập thêm Ban Chỉ đạo xây dựng kho tài liệu, học liệu dùng chung**. Vấn đề cần giải quyết chủ yếu nằm ở việc thống nhất hệ thống kế hoạch và làm rõ trách nhiệm triển khai.

## I. Nhận xét về hai văn bản đã ban hành

| Văn bản | Nội dung và nhận xét |
|--------|--------|
| **Kế hoạch số 194/KH-MNAB ngày 24/9/2026** | Là kế hoạch thực hiện **công tác truyền thông** năm học 2026–2027. Nội dung tương đối đầy đủ về hình thức truyền thông, xử lý thông tin, giải pháp và tổ chức thực hiện, nhưng chưa xây dựng nhiệm vụ chuyển đổi số và kho học liệu dùng chung thành nội dung triển khai cụ thể. |
| **Quyết định số 75/QĐ-MNAB ngày 01/10/2026** | Đã thành lập Ban Chỉ đạo công tác **Truyền thông và Chuyển đổi số**, gồm 13 thành viên. Điều 2 đã giao nhiệm vụ ứng dụng công nghệ thông tin, số hóa tài liệu, xây dựng và khai thác học liệu số; danh sách kèm theo cũng đã phân công khá cụ thể. |

### Điểm rất thuận lợi

Trong Quyết định số 75, bà **Huỳnh Hồng Loan – Hiệu trưởng** là Trưởng ban; bà **Hồ Thanh Trúc – Phó Hiệu trưởng** được phân công trực tiếp chỉ đạo công tác chuyển đổi số. Các tổ trưởng chuyên môn cũng đã được giao nhiệm vụ hướng dẫn giáo viên xây dựng, chia sẻ và khai thác học liệu điện tử.

Điều này cho thấy **Ban Chỉ đạo hiện có đã có chức năng và nhân sự để triển khai kho học liệu**, không nhất thiết phải hình thành thêm một tổ chức khác.

Vì vậy, tôi đề xuất giữ nguyên cơ cấu Ban Chỉ đạo, không ban hành thêm một quyết định thành lập Ban Chỉ đạo riêng chỉ để thực hiện nhiệm vụ kho học liệu.

## II. Phương án nên lựa chọn

**Ban hành một kế hoạch chung thay thế kế hoạch truyền thông hiện có**

Tên kế hoạch đề xuất:

**KẾ HOẠCH
Thực hiện công tác truyền thông, chuyển đổi số và xây dựng kho tài liệu, học liệu dùng chung năm học 2026–2027**

Cụ thể, tôi đề nghị:

1. **Giữ Quyết định số 75/QĐ-MNAB** làm cơ sở tổ chức Ban Chỉ đạo, sau khi rà soát và xử lý các sai sót của văn bản đã ký.
2. **Ban hành một kế hoạch tổng hợp mới**, kế thừa các nội dung còn phù hợp của Kế hoạch số 194/KH-MNAB, đồng thời bổ sung nội dung chuyển đổi số và xây dựng kho học liệu dùng chung.
3. **Quy định rõ trong kế hoạch mới rằng kế hoạch này thay thế Kế hoạch số 194/KH-MNAB**, kể từ ngày kế hoạch mới có hiệu lực; không sửa trực tiếp lên bản PDF đã ký.
4. Không lập lại Ban Chỉ đạo hoặc phân công lại toàn bộ nhân sự nếu nhiệm vụ hiện hành vẫn phù hợp. Những nội dung cần cụ thể hóa chỉ bổ sung vào kế hoạch triển khai hoặc bảng phân công công việc.

Đây là phương án giúp nhà trường có **một kế hoạch điều hành thống nhất, một Ban Chỉ đạo chịu trách nhiệm, nhưng các nhiệm vụ chuyên môn vẫn được tổ chức rõ ràng và độc lập về chất lượng**.

## III. Những điểm trong hồ sơ đã ký cần xử lý đồng thời

Khi đối chiếu văn bản, tôi phát hiện một số nội dung chưa thống nhất. Nhà trường nên xử lý trong cùng đợt hoàn thiện hồ sơ để tránh tiếp tục sử dụng những thông tin chưa chính xác.

| Vị trí | Vấn đề cần rà soát | Hướng xử lý |
|--------|--------|--------|
| Quyết định 75, trang 1 | Dẫn Kế hoạch số **200/KH-MNAB ngày 30/9/2026**, trong khi tệp kế hoạch bạn cung cấp là **194/KH-MNAB ngày 24/9/2026** | Kiểm tra sổ văn bản và bản gốc Kế hoạch 200 trước khi xác định văn bản nào cần thay thế |
| Quyết định 75, trang 1 | Dòng chức danh ghi “Hiệu trưởng Trường Mầm non Bình” | Thống nhất tên chính thức là Trường Mầm non An Bình |
| Quyết định 75, phụ lục trang 4 | Tiêu đề danh sách ghi **năm học 2025–2026** thay vì 2026–2027 | Cần sửa vì liên quan trực tiếp đến thời gian hoạt động của Ban Chỉ đạo |
| Kế hoạch 194 | Một số mục lớn bị lặp số thứ tự; phần căn cứ có tên Trường Mầm non An Bình A | Chuẩn hóa trong kế hoạch mới, đối chiếu tên đơn vị ban hành văn bản được dẫn |

Riêng **Kế hoạch số 200** cần được kiểm tra trước. Tôi chưa có văn bản này nên không thể khẳng định đây là lỗi viện dẫn hay một kế hoạch khác đã được ban hành.

Về nguyên tắc xử lý văn bản đã phát hành, khoản 3 Điều 18 Nghị định 30/2020/NĐ-CP phân biệt sai sót về nội dung (sửa đổi hoặc thay thế bằng văn bản cùng hình thức) và sai sót về thể thức, kỹ thuật trình bày (đính chính bằng công văn). Vì Quyết định 75 có nhiều điểm cần làm rõ, tôi nghiêng về **ban hành quyết định thay thế, giữ nguyên cơ cấu nhân sự phù hợp và chỉnh lại nội dung**, thay vì chỉnh sửa trực tiếp tệp đã ký. [Nghị định 30/2020/NĐ\-CP về công tác văn thư](<https://vanban.vcci.com.vn/nghi-dinh-302020nd-cp-ve-cong-tac-van-thu>); [Bộ Nội vụ](<https://vbpl.moj.gov.vn/bonoivu/Pages/vbpq-toanvan.aspx?ItemID=141142&dvid=320>)

## IV. Trình tự thực hiện tôi đề xuất

| Bước | Công việc cần làm | Hồ sơ, kết quả |
|--------|--------|--------|
| **1** | Văn thư kiểm tra Kế hoạch 200 và các kế hoạch cùng nội dung đang có hiệu lực | Xác định chính xác văn bản cần được thay thế |
| **2** | Xây dựng kế hoạch tổng hợp, kế thừa nội dung truyền thông, bổ sung chuyển đổi số và kho học liệu | 01 kế hoạch chung có số, ngày ban hành mới |
| **3** | Rà soát, hoàn thiện Quyết định 75, giữ cơ cấu 13 thành viên nếu vẫn phù hợp; thống nhất phân công với kế hoạch mới | Quyết định sửa đổi hoặc thay thế theo nội dung cần xử lý |
| **4** | Triển khai kế hoạch, tiếp tục sử dụng kết quả và minh chứng công việc đã thực hiện | Hồ sơ theo dõi thống nhất, không làm lại công việc đã hoàn thành |

Kế hoạch mới cần có điều khoản rõ ràng về việc thay thế kế hoạch trước đây. Những hoạt động đã thực hiện hợp lệ theo kế hoạch cũ vẫn được ghi nhận trong kết quả năm học; không coi việc ban hành kế hoạch mới là bắt đầu lại toàn bộ công việc.

## V. Cách xây dựng kế hoạch chung để không mất trọng tâm

Tôi đề xuất kế hoạch tổng hợp chỉ có 5 phần, nhưng nội dung phải giữ được chiều sâu của ba nhiệm vụ.

| Phần | Trọng tâm |
|--------|--------|
| **I. Mục đích, yêu cầu** | Thống nhất quản lý truyền thông và chuyển đổi số; khai thác nguồn lực sau sáp nhập |
| **II. Đặc điểm tình hình** | Điều kiện, thuận lợi, khó khăn của Trường Mầm non An Bình sau sáp nhập ba trường |
| **III. Chỉ tiêu thực hiện** | Chỉ tiêu cụ thể của truyền thông, chuyển đổi số và kho học liệu |
| **IV. Nội dung và giải pháp** | Ba nhóm nhiệm vụ rõ ràng, có cách tổ chức và kết quả cần đạt |
| **V. Tổ chức thực hiện** | Phân công theo Quyết định Ban Chỉ đạo, tiến độ, kiểm tra và đánh giá |

Trong đó, **phần IV cần dành nội dung tương xứng cho từng nhiệm vụ**. Công tác truyền thông giữ các nội dung thiết thực của Kế hoạch 194, đặc biệt là kiểm duyệt thông tin, phối hợp cha mẹ trẻ, dự phòng và xử lý thông tin. Chuyển đổi số tập trung ứng dụng công nghệ, quản lý hồ sơ, dữ liệu và an toàn thông tin. Kho học liệu là nhiệm vụ chuyên môn cụ thể của chuyển đổi số, với quy trình rà soát tài liệu từ ba trường, thiết lập kho, chuẩn hóa học liệu và tổ chức khai thác.

Về phân công, có thể kế thừa đúng chức năng trong Quyết định 75: bà **Nguyễn Thị Huỳnh Duyên** phụ trách điều phối truyền thông; bà **Hồ Thanh Trúc** phụ trách điều phối chuyển đổi số và triển khai nền tảng kho học liệu, phối hợp các Phó Hiệu trưởng, tổ trưởng chuyên môn chịu trách nhiệm về chất lượng nội dung.

### Nội dung đề xuất trình Hiệu trưởng

> **writing · document**
>
> **ĐỀ XUẤT PHƯƠNG ÁN HOÀN THIỆN HỒ SƠ TRUYỀN THÔNG VÀ CHUYỂN ĐỔI SỐ NĂM HỌC 2026–2027**
>
> Trên cơ sở rà soát Kế hoạch số 194/KH-MNAB ngày 24/9/2026 và Quyết định số 75/QĐ-MNAB ngày 01/10/2026, đề xuất nhà trường thống nhất việc triển khai công tác truyền thông, chuyển đổi số và xây dựng kho tài liệu, học liệu dùng chung trong một kế hoạch tổng hợp.
>
> Kế hoạch mới kế thừa những nội dung đã được triển khai phù hợp, đồng thời cụ thể hóa các nhiệm vụ chuyển đổi số, trong đó xác định xây dựng kho tài liệu, học liệu dùng chung là một nhiệm vụ trọng tâm nhằm phát huy nguồn lực của ba trường sau sáp nhập.
>
> Về tổ chức thực hiện, tiếp tục sử dụng cơ cấu Ban Chỉ đạo đã được thành lập theo Quyết định số 75/QĐ-MNAB, đồng thời rà soát, hoàn thiện những nội dung chưa thống nhất trong quyết định. Không thành lập thêm Ban Chỉ đạo riêng đối với nhiệm vụ xây dựng kho tài liệu, học liệu.
>
> Giao bộ phận phụ trách chuyển đổi số chủ trì phối hợp thiết lập, quản lý nền tảng và hỗ trợ kỹ thuật; bộ phận chuyên môn chịu trách nhiệm lựa chọn, kiểm soát chất lượng, tổ chức khai thác và đánh giá hiệu quả học liệu.
>
> Việc ban hành kế hoạch tổng hợp mới phải xác định rõ phạm vi thay thế các kế hoạch đã ban hành có nội dung tương ứng, bảo đảm thống nhất đầu mối chỉ đạo, tránh trùng lặp nhiệm vụ, phát sinh hồ sơ và bảo đảm tính kế thừa trong quá trình thực hiện.

## ✅ Kết luận

Với hồ sơ thực tế của Trường Mầm non An Bình, **tôi không đề xuất bỏ toàn bộ những gì đã làm để xây dựng lại từ đầu**. Nội dung của Kế hoạch 194 có nhiều phần sử dụng tốt; Quyết định 75 cũng đã xác lập khá đầy đủ cơ cấu và trách nhiệm.

Phương án hợp lý nhất là **kế thừa nội dung, hợp nhất kế hoạch và chuẩn hóa lại quyết định chỉ đạo**, xử lý rõ hiệu lực các văn bản cũ. Như vậy vừa thực hiện đúng chỉ đạo của lãnh đạo, vừa bảo toàn kết quả công việc đã thực hiện và tránh chồng chéo trong quản lý.

Một điểm cần ưu tiên ngay là đối chiếu **Kế hoạch số 200/KH-MNAB ngày 30/9/2026** được viện dẫn tại Quyết định 75. Nếu văn bản này thực sự tồn tại và đã ký, phạm vi thay thế trong kế hoạch mới cần tính đến cả văn bản đó, không chỉ riêng Kế hoạch 194.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

USER

ý bạn là xây dựng Kế hoạch mới kế thừa lại 2 nd của văn bản trên?

---

ASSISTANT

**Đúng, nhưng tôi muốn làm rõ hơn để bạn không phải làm lại những nội dung đã được xây dựng và ký duyệt.**

Tôi đề xuất **xây dựng 01 kế hoạch chung mới, kế thừa nội dung của hai văn bản hiện có và bổ sung nhiệm vụ xây dựng kho tài liệu, học liệu dùng chung.**

Cụ thể:

| Văn bản hiện có | Hướng kế thừa, xử lý |
|--------|--------|
| **Kế hoạch 194/KH-MNAB** về công tác truyền thông | Giữ những nội dung, giải pháp đã xây dựng có chất lượng; tích hợp thành phần **Công tác truyền thông** trong kế hoạch mới |
| **Quyết định 75/QĐ-MNAB** thành lập Ban Chỉ đạo Truyền thông và Chuyển đổi số | Kế thừa các nhiệm vụ chuyển đổi số đã giao tại Điều 2 để cụ thể hóa thành nội dung, giải pháp và tiến độ trong kế hoạch mới |
| **Kế hoạch xây dựng kho tài liệu, học liệu dùng chung** đang xây dựng | Tích hợp thành **nhiệm vụ trọng tâm của công tác chuyển đổi số**, có giải pháp và phân công cụ thể |

### Cấu trúc kế hoạch mới tôi đề xuất

**Tên văn bản:**

*KẾ HOẠCH Thực hiện công tác truyền thông và chuyển đổi số năm học 2026–2027*

**I. Mục đích, yêu cầu**

**II. Đặc điểm tình hình:** Nhấn mạnh bối cảnh Trường Mầm non An Bình sau sáp nhập ba trường.

**III. Mục tiêu, chỉ tiêu thực hiện**

**IV. Nội dung và giải pháp thực hiện**

1. Công tác truyền thông.
2. Công tác chuyển đổi số, trong đó có nội dung xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung.

**V. Tổ chức thực hiện**

### Điểm quan trọng về hồ sơ

**Kế hoạch mới sẽ thay thế kế hoạch cũ về nội dung thực hiện, nhưng không mặc nhiên thay thế Quyết định số 75.**

Quyết định số 75 là văn bản thành lập và phân công Ban Chỉ đạo, nên có thể tiếp tục sử dụng sau khi xử lý các sai sót cần thiết. Kế hoạch mới là văn bản cụ thể hóa nhiệm vụ, giải pháp và tiến độ để Ban Chỉ đạo tổ chức thực hiện.

Trước khi xác định chính xác văn bản nào được thay thế, cần đối chiếu thêm Kế hoạch số 200/KH-MNAB được viện dẫn trong Quyết định 75.

### ✅ Quan điểm của tôi

Tôi muốn giữ được **giá trị nội dung của Kế hoạch 194**, vì phần truyền thông đã xây dựng tương đối kỹ, nhất là công tác phối hợp cha mẹ trẻ và xử lý thông tin.

Đồng thời, nhiệm vụ chuyển đổi số trong Quyết định 75 cần được phát triển thành những giải pháp cụ thể, thay vì chỉ dừng ở phân công trách nhiệm.

**Như vậy, chúng ta không viết lại từ đầu mà tổ chức lại nội dung đã có, bổ sung phần còn thiếu, làm thành một kế hoạch thống nhất, có chiều sâu và có thể triển khai thực tế.**

Đây là phương án tôi đánh giá phù hợp nhất với chỉ đạo gộp chung của lãnh đạo và tình trạng hồ sơ hiện nay của Trường Mầm non An Bình.

---

USER

bạn có nhầm không kế hoạch mới bạn vừa thảo chẳng đá động gì đến **Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung **

---

ASSISTANT

**Có, tôi đã nhầm trong cách đề xuất cấu trúc kế hoạch mới.** Tôi đã đặt nhiệm vụ xây dựng kho tài liệu, học liệu dùng chung vào nội dung chuyển đổi số một cách quá chung chung, khiến nhiệm vụ quan trọng mà chúng ta đang xây dựng không được thể hiện rõ.

Trong khi đó, chính **xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung** mới là nội dung bạn đang cần tích hợp theo chỉ đạo của Hiệu trưởng.

Tôi xin điều chỉnh lại phương án cho chính xác.

## 1. Tên kế hoạch mới cần thể hiện đủ 3 nội dung

Tôi đề xuất:

**KẾ HOẠCH
Thực hiện công tác truyền thông, chuyển đổi số và xây dựng kho tài liệu, học liệu dùng chung năm học 2026–2027**

Trong kế hoạch này có ba nhóm nhiệm vụ gắn kết với nhau:

| Nội dung | Cơ sở xây dựng |
|--------|--------|
| **1. Công tác truyền thông** | Kế thừa nội dung Kế hoạch số 194/KH-MNAB đã ký |
| **2. Công tác chuyển đổi số** | Cụ thể hóa các nhiệm vụ đã phân công tại Quyết định số 75/QĐ-MNAB |
| **3. Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung** | Tích hợp nội dung kế hoạch chúng ta đã xây dựng, gắn với yêu cầu quản lý sau sáp nhập ba trường |

Như vậy, kho học liệu **thuộc định hướng chuyển đổi số nhưng phải được trình bày thành một nội dung trọng tâm riêng**, không hòa lẫn vào các nhiệm vụ ứng dụng công nghệ thông tin thông thường.

## 2. Cấu trúc kế hoạch mới cần được điều chỉnh

Tôi đề xuất giữ 5 phần:

**I. Mục đích, yêu cầu**

Làm rõ mục đích chung của truyền thông và chuyển đổi số, đồng thời nhấn mạnh việc xây dựng kho tài liệu, học liệu nhằm kết nối, kế thừa nguồn lực từ ba trường trước sáp nhập.

**II. Đặc điểm tình hình**

Phân tích thực trạng sau sáp nhập, nhất là yêu cầu thống nhất thông tin, quản lý dữ liệu và kết nối các nguồn tài liệu, học liệu đang phân tán.

**III. Mục tiêu, chỉ tiêu thực hiện**

Có chỉ tiêu riêng cho truyền thông, chuyển đổi số và kho tài liệu, học liệu dùng chung.

**IV. Nội dung và giải pháp thực hiện**

Đây là trọng tâm của kế hoạch, gồm ba nội dung:

1. Công tác truyền thông.
2. Công tác chuyển đổi số.
3. Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung.

**V. Tổ chức thực hiện**

Phân công nhiệm vụ, tiến độ, trách nhiệm kiểm tra, đánh giá trên cơ sở Ban Chỉ đạo đã được thành lập.

## 3. Riêng nội dung kho học liệu phải thể hiện rõ như sau

> **writing · document**
>
> ### 3. Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung
>
> **3.1. Rà soát, kế thừa nguồn tài liệu, học liệu của ba trường trước sáp nhập**
>
> Tổ chức rà soát, tập hợp và đánh giá nguồn tài liệu chuyên môn, học liệu số, đồ dùng, đồ chơi và các sản phẩm giáo dục đã được xây dựng, sử dụng tại ba trường trước sáp nhập. Trên cơ sở đó, lựa chọn những tài liệu có chất lượng, phù hợp với Chương trình giáo dục mầm non, có khả năng chia sẻ và sử dụng chung; đồng thời xác định những nội dung còn thiếu cần bổ sung.
>
> **3.2. Thiết lập và quản lý kho tài liệu, học liệu dùng chung**
>
> Xây dựng kho lưu trữ số thống nhất cấp trường; tổ chức phân loại tài liệu theo nhóm nội dung, khối tuổi và lĩnh vực giáo dục, bảo đảm thuận tiện trong tìm kiếm, cập nhật và khai thác. Đối với học liệu hiện vật, xây dựng danh mục quản lý, xác định vị trí lưu giữ và phương thức chia sẻ phù hợp giữa các điểm trường.
>
> Phân công nhân sự quản lý, thống nhất quy trình cập nhật, phân quyền truy cập, sao lưu và bảo đảm an toàn dữ liệu.
>
> **3.3. Lựa chọn, chuẩn hóa và phát triển học liệu**
>
> Phát huy vai trò của các tổ chuyên môn trong việc lựa chọn, kiểm tra chất lượng và đề xuất bổ sung học liệu. Ưu tiên kế thừa những sản phẩm đã được sử dụng hiệu quả, khuyến khích giáo viên phối hợp cải tiến, xây dựng học liệu phù hợp với đặc điểm trẻ và điều kiện thực tế.
>
> Việc lựa chọn, phê duyệt học liệu thực hiện theo quy định hiện hành; không chạy theo số lượng sản phẩm hoặc xây dựng trùng lặp những tài liệu đã có.
>
> **3.4. Tổ chức khai thác, chia sẻ và đánh giá hiệu quả**
>
> Hướng dẫn giáo viên truy cập, tìm kiếm, lựa chọn và sử dụng nguồn học liệu; gắn việc khai thác kho với sinh hoạt chuyên môn, xây dựng kế hoạch và tổ chức hoạt động giáo dục.
>
> Tăng cường chia sẻ kinh nghiệm giữa giáo viên các điểm trường; định kỳ rà soát, điều chỉnh và bổ sung tài liệu trên cơ sở hiệu quả sử dụng thực tế. Lấy mức độ hỗ trợ giáo viên và chất lượng tổ chức hoạt động giáo dục làm căn cứ đánh giá, không chỉ dựa vào số lượng học liệu được lưu trữ.
>
> **Kết quả cần đạt:** Hình thành 01 kho tài liệu, học liệu dùng chung cấp trường, được quản lý thống nhất; có nguồn học liệu phù hợp với các khối tuổi, được giáo viên khai thác thường xuyên và tiếp tục bổ sung, phát triển trong các năm học tiếp theo.

## 4. Về Quyết định số 75 đã ký

Sau khi rà soát lại, tôi vẫn đề xuất **không thành lập thêm Ban Chỉ đạo kho học liệu riêng**.

Trong Quyết định số 75 đã có Ban Chỉ đạo Truyền thông và Chuyển đổi số gồm 13 thành viên, có phân công bà Hồ Thanh Trúc phụ trách chuyển đổi số và các tổ trưởng chuyên môn tham gia xây dựng, khai thác học liệu số.

Vì vậy, có thể giao Ban Chỉ đạo hiện có tổ chức thực hiện kế hoạch mới, đồng thời cụ thể hóa trách nhiệm quản lý và khai thác kho học liệu. Việc xử lý những sai sót trong Quyết định 75 và đối chiếu Kế hoạch số 200 được viện dẫn vẫn cần thực hiện trước khi hoàn thiện hồ sơ.

---

### ✅ Phương án tôi xác định lại

**Không phải gộp hai nội dung truyền thông và chuyển đổi số rồi chỉ nhắc đến kho học liệu như một hoạt động phụ.**

Mà là xây dựng **một kế hoạch tổng hợp có ba nhiệm vụ trọng tâm**, trong đó kho tài liệu, học liệu dùng chung là nhiệm vụ cụ thể có mục tiêu, giải pháp, tiến độ và trách nhiệm rõ ràng.

Và điều quan trọng nhất: **Phần kế hoạch xây dựng kho học liệu mà chúng ta đã đầu tư xây dựng phải được kế thừa những lập luận, giải pháp có giá trị, đặc biệt là yêu cầu kết nối nguồn học liệu của ba trường sau sáp nhập.** Không được rút lại thành vài dòng mang tính hình thức.

Đây mới là hướng gộp phù hợp với chỉ đạo của Hiệu trưởng và bảo đảm chất lượng văn bản mà bạn đang hướng đến.

---

USER

vậy lại là bỏ vb cũ làm lại mới. cách này sẽ không ổn nhe

---

ASSISTANT

Bạn nói đúng. **Những văn bản đã ký duyệt, đang triển khai thực hiện và không có vấn đề lớn về nội dung thì không nên bỏ để xây dựng lại từ đầu.** Cách tôi đề xuất trước đó chưa hợp lý về quản lý hồ sơ và làm phát sinh công việc không cần thiết.

Sau khi xem lại tình trạng hồ sơ của Trường Mầm non An Bình, tôi đề xuất điều chỉnh theo hướng **giữ nguyên văn bản đã ban hành, chỉ bổ sung nhiệm vụ còn thiếu và thống nhất đầu mối tổ chức thực hiện.**

## 1. Phương án xử lý phù hợp nhất

| Văn bản | Hướng xử lý |
|--------|--------|
| **Kế hoạch 194/KH-MNAB** về công tác truyền thông | Giữ nguyên, tiếp tục thực hiện; không viết lại |
| **Quyết định 75/QĐ-MNAB** thành lập Ban Chỉ đạo Truyền thông và Chuyển đổi số | Giữ cơ cấu và nhiệm vụ hiện có; xử lý riêng những sai sót văn bản nếu cần |
| **Nhiệm vụ xây dựng kho tài liệu, học liệu dùng chung** | Bổ sung thành nhiệm vụ triển khai cụ thể của Ban Chỉ đạo, thuộc lĩnh vực chuyển đổi số |

Như vậy, **không cần xây dựng một kế hoạch tổng hợp mới để thay thế Kế hoạch 194**, cũng không cần thành lập thêm Ban Chỉ đạo.

## 2. Bổ sung nội dung kho học liệu bằng cách nào?

Tôi đề xuất sử dụng **phụ lục triển khai nhiệm vụ xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung**, trong đó xác định rõ:

- Mục đích, yêu cầu gắn với việc kế thừa nguồn học liệu của ba trường trước sáp nhập.
- Nội dung thực hiện: rà soát, tập hợp, phân loại; thiết lập kho; lựa chọn, chuẩn hóa; tổ chức khai thác và đánh giá.
- Tiến độ, sản phẩm cần đạt và trách nhiệm từng bộ phận.
- Cơ chế phối hợp giữa người phụ trách chuyển đổi số và các tổ chuyên môn.

Phụ lục này được triển khai trong khuôn khổ nhiệm vụ của Ban Chỉ đạo theo Quyết định số 75, **không thành lập một hệ thống chỉ đạo độc lập**.

Về thủ tục, cần phân biệt hai trường hợp:

**Trường hợp 1:** Nhà trường đã có kế hoạch thực hiện công tác chuyển đổi số của Ban Chỉ đạo. Khi đó, chỉ cần ban hành văn bản bổ sung nội dung và phụ lục triển khai kho học liệu gắn với kế hoạch đang có.

**Trường hợp 2:** Nhà trường mới có Kế hoạch 194 về truyền thông và Quyết định 75 về Ban Chỉ đạo, chưa có kế hoạch triển khai chuyển đổi số. Khi đó, có thể ban hành văn bản triển khai nhiệm vụ chuyển đổi số theo Quyết định 75, kèm nội dung kho học liệu. Kế hoạch truyền thông 194 vẫn được giữ nguyên.

Không nên tự gắn phụ lục vào bản kế hoạch đã ký mà không có văn bản ban hành bổ sung hợp lệ.

## 3. Phân công trên cơ sở Quyết định 75 đã có

Trong Quyết định 75, bà **Hồ Thanh Trúc – Phó Hiệu trưởng** đã được phân công trực tiếp phụ trách chuyển đổi số. Vì vậy, có thể giao nhiệm vụ điều phối xây dựng kho học liệu trong phạm vi này.

Các tổ trưởng chuyên môn chịu trách nhiệm tổ chức giáo viên rà soát, lựa chọn, chia sẻ và sử dụng học liệu. Ban Giám hiệu kiểm soát chất lượng và thực hiện trách nhiệm phê duyệt theo thẩm quyền. Nhân sự có năng lực công nghệ thông tin hỗ trợ thiết lập và vận hành kho.

Cách phân công này tận dụng được hệ thống đã thành lập và không làm thay đổi cơ cấu tổ chức của nhà trường.

## 4. Một chi tiết cần kiểm tra trước khi quyết định

Trong Quyết định 75 có viện dẫn **Kế hoạch số 200/KH-MNAB ngày 30/9/2026 về công tác truyền thông**, trong khi văn bản bạn cung cấp là **Kế hoạch 194/KH-MNAB ngày 24/9/2026**.

Tôi chưa có Kế hoạch số 200, nên chưa thể xác định chính xác nhà trường đã có kế hoạch riêng của Ban Truyền thông và Chuyển đổi số hay chưa.

**Đây là chi tiết quyết định cách bổ sung hồ sơ mà không phải xây dựng lại văn bản đã ký.**

### ✅ Đề xuất cuối cùng

Tôi nghiêng về phương án **giữ nguyên hai văn bản đã ký, bổ sung nhiệm vụ kho học liệu vào hệ thống công việc của Ban Chỉ đạo hiện có, không lập lại kế hoạch truyền thông**.

Bạn cho tôi xác nhận một điểm: **Kế hoạch số 200/KH-MNAB ngày 30/9/2026 được dẫn trong Quyết định 75 có phải là một kế hoạch khác mà nhà trường đã ký ban hành không?**

Nếu có, bạn gửi thêm văn bản đó. Tôi sẽ xác định chính xác nên bổ sung vào mục nào, bằng hình thức văn bản nào, để vừa thực hiện chỉ đạo của Hiệu trưởng vừa không xáo trộn hồ sơ đã ban hành.

---

USER

bạn có thể làm giúp tôi 1 phụ lục  nội dung **Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 để chèn thêm vào kế hoạch truey63n thông và chuyển đổi số để logic hơn**

---

ASSISTANT

Tôi sẽ xây dựng phụ lục theo hướng **bổ sung nhiệm vụ chuyên môn vào hoạt động chuyển đổi số đã được phân công**, không làm lại Kế hoạch số 194/KH-MNAB và không thay thế Quyết định số 75/QĐ-MNAB của Trường Mầm non An Bình.

Phụ lục cần bảo đảm ba yêu cầu: thể hiện rõ sự cần thiết sau sáp nhập ba trường; xác định cụ thể nội dung, cách thực hiện và kết quả cần đạt; phân công đúng chức năng của Ban Chỉ đạo hiện có.

Dưới đây là bản dự thảo để bạn sử dụng.

> **writing · document**
>
> **TRƯỜNG MẦM NON AN BÌNH**
>
> # PHỤ LỤC
> **NỘI DUNG TRIỂN KHAI XÂY DỰNG, QUẢN LÝ VÀ KHAI THÁC KHO TÀI LIỆU, HỌC LIỆU DÙNG CHUNG NĂM HỌC 2026–2027**
>
> *(Kèm theo Văn bản số …/… ngày … tháng … năm 2026 của Trường Mầm non An Bình về việc bổ sung nhiệm vụ chuyển đổi số năm học 2026–2027)*
>
> ## I. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> Xây dựng kho tài liệu, học liệu dùng chung trên cơ sở kế thừa, chọn lọc và phát huy nguồn tài nguyên chuyên môn của ba trường trước sáp nhập; hình thành hệ thống lưu trữ, quản lý và chia sẻ thống nhất, phục vụ hiệu quả hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ trong toàn trường.
>
> Tăng cường ứng dụng công nghệ thông tin trong quản lý và khai thác học liệu; tạo điều kiện để giáo viên các tổ, khối và điểm trường tiếp cận, trao đổi, sử dụng nguồn học liệu có chất lượng, hạn chế trùng lặp trong xây dựng tài liệu, góp phần nâng cao hiệu quả sinh hoạt chuyên môn và chất lượng tổ chức hoạt động giáo dục.
>
> ### 2. Yêu cầu
>
> - Việc xây dựng kho phải phù hợp với điều kiện thực tế, nhu cầu sử dụng và khả năng khai thác của đội ngũ; ưu tiên tận dụng nguồn tài liệu, học liệu hiện có.
> - Tài liệu, học liệu được lựa chọn phải bảo đảm tính chính xác, khoa học, sư phạm, an toàn, phù hợp với Chương trình giáo dục mầm non và đặc điểm phát triển của trẻ.
> - Kho học liệu được tổ chức khoa học, dễ tìm kiếm, cập nhật và sử dụng; có phân công quản lý, kiểm soát chất lượng, bảo đảm an toàn thông tin và quyền tác giả.
> - Gắn việc xây dựng kho với sinh hoạt chuyên môn và hoạt động giáo dục thực tế; chú trọng chất lượng, hiệu quả sử dụng, không chạy theo số lượng sản phẩm hoặc làm phát sinh hồ sơ không cần thiết.
>
> ## II. NỘI DUNG VÀ GIẢI PHÁP THỰC HIỆN
>
> ### 1. Rà soát, kế thừa nguồn tài liệu, học liệu hiện có
>
> Trên cơ sở tổ chức lại nhà trường sau sáp nhập ba trường mầm non, Ban Giám hiệu chỉ đạo các tổ chuyên môn rà soát, tập hợp nguồn tài liệu chuyên môn, học liệu số, tranh ảnh, video, trò chơi, đồ dùng, đồ chơi tự tạo và những sản phẩm giáo dục có giá trị sử dụng tại các điểm trường An Bình, An Bình A và An Lộc.
>
> Việc rà soát tập trung đánh giá chất lượng, tính phù hợp, khả năng sử dụng và chia sẻ; phân loại tài liệu có thể khai thác ngay, tài liệu cần điều chỉnh và tài liệu không còn phù hợp. Ưu tiên lựa chọn những sản phẩm đã được vận dụng hiệu quả, có khả năng sử dụng ở nhiều nhóm, lớp; hạn chế lưu trữ trùng lặp hoặc xây dựng lại những tài liệu đã có.
>
> **Kết quả:** Hình thành danh mục tài liệu, học liệu được kế thừa từ các đơn vị trước sáp nhập, xác định nguồn có thể sử dụng chung và những nội dung cần bổ sung.
>
> ### 2. Thiết lập và quản lý kho tài liệu, học liệu dùng chung
>
> Lựa chọn nền tảng lưu trữ số phù hợp với điều kiện của nhà trường, từng bước xây dựng kho tài liệu, học liệu dùng chung cấp trường, bảo đảm thuận tiện trong truy cập, tìm kiếm, cập nhật và khai thác.
>
> Kho được phân loại theo các nhóm nội dung chính:
>
> - **Tài liệu quản lý, chỉ đạo và bồi dưỡng chuyên môn:** Văn bản hướng dẫn, tài liệu tập huấn, chuyên đề, sinh hoạt chuyên môn và những tài liệu nghiệp vụ được phép chia sẻ.
> - **Học liệu giáo dục theo độ tuổi:** Hình ảnh, video, âm thanh, trò chơi, tài liệu hướng dẫn tổ chức hoạt động theo các lĩnh vực phát triển, nội dung giáo dục.
> - **Học liệu chăm sóc, nuôi dưỡng và giáo dục kỹ năng:** Tài liệu phục vụ giáo dục dinh dưỡng, vệ sinh, sức khỏe, kỹ năng tự phục vụ, bảo đảm an toàn cho trẻ.
> - **Học liệu trải nghiệm, đồ dùng, đồ chơi:** Trò chơi dân gian, hoạt động thực hành, trải nghiệm; hướng dẫn làm đồ dùng, đồ chơi từ nguyên vật liệu an toàn, phù hợp với điều kiện địa phương.
>
> Đối với học liệu hiện vật, xây dựng danh mục dùng chung, xác định nơi lưu giữ, tình trạng và khả năng sử dụng, tạo điều kiện chia sẻ phù hợp giữa các điểm trường.
>
> Thống nhất cách đặt tên, sắp xếp tài liệu, phân quyền truy cập, cập nhật và sao lưu dữ liệu. Phân công nhân sự phụ trách quản lý hệ thống, phối hợp với tổ chuyên môn kiểm soát nội dung trước khi đưa vào sử dụng. Tài liệu nội bộ, thông tin và hình ảnh của trẻ được quản lý, chia sẻ đúng phạm vi quy định.
>
> **Kết quả:** Hình thành 01 kho tài liệu, học liệu dùng chung cấp trường, có cấu trúc thống nhất, danh mục tra cứu và trách nhiệm quản lý rõ ràng.
>
> ### 3. Lựa chọn, chuẩn hóa và bổ sung học liệu
>
> Các tổ chuyên môn phối hợp rà soát nội dung, nguồn gốc, tính khoa học, yêu cầu sư phạm, mức độ an toàn và khả năng vận dụng của tài liệu, học liệu trước khi đề xuất cập nhật vào kho.
>
> Việc lựa chọn, phê duyệt đồ chơi, học liệu thuộc phạm vi quy định được thực hiện theo đúng thẩm quyền và quy trình hiện hành. Những tài liệu chưa phù hợp được điều chỉnh trước khi sử dụng; tài liệu không đáp ứng yêu cầu không đưa vào danh mục chính thức.
>
> Trên cơ sở nhu cầu thực tế của từng khối tuổi, các tổ chuyên môn xác định nội dung học liệu còn thiếu để bổ sung có trọng tâm. Khuyến khích giáo viên phát huy thế mạnh, phối hợp xây dựng, cải tiến những học liệu có tính ứng dụng cao, hỗ trợ trẻ học thông qua chơi, thực hành, trải nghiệm và có thể sử dụng nhiều lần.
>
> **Kết quả:** Từng khối tuổi có danh mục học liệu được chọn lọc, bảo đảm chất lượng, phù hợp với kế hoạch giáo dục và điều kiện thực tế của nhóm, lớp.
>
> ### 4. Tổ chức khai thác, chia sẻ và đánh giá hiệu quả
>
> Tổ chức hướng dẫn giáo viên truy cập, tìm kiếm, lựa chọn và sử dụng kho tài liệu, học liệu. Phát huy vai trò của giáo viên có năng lực công nghệ thông tin trong hỗ trợ đồng nghiệp, đặc biệt tại những nhóm, lớp còn hạn chế về điều kiện thiết bị hoặc kỹ năng sử dụng.
>
> Gắn việc khai thác kho với sinh hoạt chuyên môn định kỳ; khuyến khích giáo viên giới thiệu những học liệu hiệu quả, trao đổi kinh nghiệm vận dụng, những khó khăn và đề xuất điều chỉnh phù hợp. Tăng cường phối hợp, chia sẻ kinh nghiệm giữa giáo viên các điểm trường, từng bước hình thành nguồn tài nguyên chuyên môn chung có tính kế thừa và phát triển.
>
> Ban Giám hiệu theo dõi hiệu quả khai thác thông qua hoạt động chuyên môn thường xuyên, phản hồi của giáo viên và thực tế tổ chức hoạt động giáo dục; định kỳ rà soát, cập nhật, bổ sung hoặc loại bỏ học liệu không còn phù hợp.
>
> **Kết quả:** Kho tài liệu, học liệu được khai thác thường xuyên, góp phần giảm thời gian chuẩn bị, hạn chế trùng lặp và nâng cao hiệu quả tổ chức các hoạt động giáo dục.
>
> ## III. CHỈ TIÊU VÀ TIẾN ĐỘ THỰC HIỆN
>
> ### 1. Chỉ tiêu phấn đấu
>
> - Xây dựng và đưa vào sử dụng 01 kho tài liệu, học liệu dùng chung cấp trường.
> - 100% tổ chuyên môn tham gia rà soát, lựa chọn, bổ sung và khai thác học liệu; các khối tuổi có danh mục học liệu phù hợp.
> - 100% cán bộ quản lý, giáo viên được hướng dẫn cách truy cập, tìm kiếm và sử dụng kho; phấn đấu ít nhất 80% giáo viên khai thác thường xuyên sau giai đoạn triển khai.
> - 100% học liệu đưa vào danh mục sử dụng chính thức được kiểm tra về nội dung, nguồn gốc, tính phù hợp và thực hiện quy trình lựa chọn, phê duyệt theo quy định áp dụng.
>
> ### 2. Tiến độ thực hiện
>
> | Thời gian | Nội dung trọng tâm | Kết quả cần đạt |
> |---|---|---|
> | **11/2026** | Rà soát, tập hợp và phân loại nguồn tài liệu, học liệu từ các đơn vị trước sáp nhập | Danh mục học liệu ban đầu |
> | **12/2026** | Thiết lập kho, tổ chức thư mục, phân quyền; lựa chọn và cập nhật tài liệu | Kho dùng chung được đưa vào hoạt động |
> | **01–3/2027** | Chuẩn hóa, bổ sung học liệu theo khối tuổi; hướng dẫn khai thác và chia sẻ chuyên môn | Nguồn học liệu được bổ sung, sử dụng thực tế |
> | **4–5/2027** | Kiểm tra, đánh giá hiệu quả sử dụng; điều chỉnh, hoàn thiện và định hướng duy trì | Kho học liệu được hoàn thiện bước đầu và có kết quả đánh giá |
>
> ## IV. PHÂN CÔNG VÀ TỔ CHỨC THỰC HIỆN
>
> **1. Trưởng Ban Chỉ đạo:** Chỉ đạo chung, bảo đảm sự phối hợp giữa các bộ phận; kiểm tra tiến độ, chất lượng và giải quyết những khó khăn phát sinh. Thực hiện việc phê duyệt học liệu theo thẩm quyền và quy định hiện hành.
>
> **2. Phó Trưởng ban phụ trách chuyển đổi số – bà Hồ Thanh Trúc:** Chủ trì tham mưu, điều phối việc xây dựng kho; phối hợp với các Phó Hiệu trưởng, tổ chuyên môn và nhân sự hỗ trợ kỹ thuật trong thiết lập, quản lý hệ thống, hướng dẫn khai thác và theo dõi kết quả thực hiện.
>
> **3. Các Phó Hiệu trưởng, tổ trưởng chuyên môn:** Chịu trách nhiệm chỉ đạo, tổ chức rà soát, lựa chọn, chuẩn hóa và đề xuất bổ sung học liệu thuộc phạm vi phụ trách; hướng dẫn giáo viên khai thác, sử dụng; lồng ghép việc chia sẻ, đánh giá hiệu quả học liệu trong sinh hoạt chuyên môn.
>
> **4. Giáo viên:** Chủ động lựa chọn, khai thác học liệu phù hợp với đặc điểm trẻ và điều kiện nhóm, lớp; chia sẻ những sản phẩm có chất lượng, được phép sử dụng; phối hợp điều chỉnh, hoàn thiện nguồn học liệu chung.
>
> **5. Các thành viên hỗ trợ kỹ thuật và bộ phận liên quan:** Phối hợp cập nhật, sắp xếp, sao lưu dữ liệu; hướng dẫn sử dụng công cụ số, hỗ trợ khắc phục khó khăn kỹ thuật và bảo đảm an toàn thông tin trong phạm vi nhiệm vụ được giao.
>
> Việc triển khai nội dung này thực hiện theo sự chỉ đạo của Ban Chỉ đạo công tác Truyền thông và Chuyển đổi số đã được thành lập tại Quyết định số 75/QĐ-MNAB ngày 01/10/2026; lồng ghép với hoạt động chuyên môn thường xuyên, không thành lập thêm bộ phận chỉ đạo riêng.
>
> Cuối năm học, Ban Chỉ đạo phối hợp các tổ chuyên môn đánh giá kết quả, tập trung vào chất lượng nguồn học liệu, mức độ khai thác và hiệu quả hỗ trợ giáo viên; làm cơ sở tiếp tục bổ sung, phát triển kho trong những năm học tiếp theo.

## 📋 Cách đưa phụ lục vào hệ thống văn bản đã ký

Tôi đề xuất sử dụng phụ lục này theo cách sau:

**Thứ nhất**, giữ nguyên nội dung Kế hoạch số 194/KH-MNAB về công tác truyền thông và Quyết định số 75/QĐ-MNAB về Ban Chỉ đạo. Phụ lục chỉ cụ thể hóa thêm nhiệm vụ kho tài liệu, học liệu dùng chung, không thay thế các nhiệm vụ đã giao.

**Thứ hai**, do văn bản đã ký duyệt, nên ban hành một văn bản ngắn về việc bổ sung nhiệm vụ triển khai, kèm theo phụ lục trên. Không tự chèn thêm trang vào bản PDF đã ký rồi coi đó là nội dung của văn bản gốc.

**Thứ ba**, về quản lý chuyên môn, cần phân biệt kho học liệu dùng chung với kho sản phẩm truyền thông. Học liệu phục vụ hoạt động giáo dục phải được kiểm soát về nội dung và chất lượng sư phạm; chỉ những sản phẩm phù hợp, được phép chia sẻ mới sử dụng cho công tác truyền thông.

### ✅ Đánh giá về phương án này

Tôi cho rằng phụ lục trên đủ để nhà trường xác định rõ:

- **Xây dựng cái gì:** Một kho tài liệu, học liệu dùng chung trên cơ sở nguồn lực của ba trường sau sáp nhập.
- **Làm như thế nào:** Rà soát, thiết lập, chuẩn hóa, tổ chức khai thác và đánh giá.
- **Ai chịu trách nhiệm:** Ban Chỉ đạo hiện có, với sự phối hợp của bộ phận chuyển đổi số và chuyên môn.
- **Khi nào hoàn thành:** Có tiến độ và kết quả cụ thể theo từng giai đoạn.

Điểm quan trọng nhất là **kế thừa được những nội dung của kế hoạch kho học liệu mà bạn đã đầu tư xây dựng**, đồng thời không làm xáo trộn hệ thống văn bản đã ban hành.

---

USER

bổ sung nội dung chuyển đổi số vào kế hoạch này neh1

---

ASSISTANT

Tôi đã đọc bản kế hoạch bạn gửi. Phần mục đích và thực trạng sau sáp nhập đã có nền tảng tốt, nhưng từ giữa mục IV trở đi còn lẫn nhiều nội dung của kế hoạch truyền thông cũ. Tôi sẽ giữ phần phù hợp, bổ sung chuyển đổi số thành nhiệm vụ rõ ràng, đồng thời hoàn chỉnh phần kho học liệu để văn bản thống nhất từ tên kế hoạch đến phân công thực hiện.

---

ASSISTANT

---

ASSISTANT

Tôi đã rà soát bản **Kế hoạch xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027** bạn vừa gửi của Trường Mầm non An Bình.

Tôi đề xuất **bổ sung nội dung chuyển đổi số vào chính bản kế hoạch đang soạn**, không thay thế Kế hoạch truyền thông số 194/KH-MNAB và không thành lập lại Ban Chỉ đạo theo Quyết định số 75/QĐ-MNAB.

Tên kế hoạch sau khi điều chỉnh:

**KẾ HOẠCH
Thực hiện chuyển đổi số và xây dựng, quản lý, khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027**

### Những nội dung cần chỉnh trong bản gốc

- **Phần I và II:** Giữ lập luận về sáp nhập ba trường Mầm non An Bình A, Mầm non An Bình B và Mầm non An Lộc; bổ sung yêu cầu thống nhất dữ liệu, phần mềm quản lý và phương thức làm việc trên môi trường số.
- **Phần III:** Bổ sung chỉ tiêu chuyển đổi số bên cạnh chỉ tiêu xây dựng kho học liệu.
- **Phần IV:** Giữ nội dung xây dựng kho học liệu làm trọng tâm chuyên môn; bổ sung việc ứng dụng công nghệ trong quản lý, hồ sơ điện tử, bồi dưỡng kỹ năng số và bảo đảm an toàn dữ liệu.
- **Phần V:** Phân công theo Ban Chỉ đạo đã có, xác định tiến độ và kết quả phải hoàn thành.

Đặc biệt, từ mục IV.2 của bản bạn gửi đang còn nội dung *“Tiếp nhận, xác minh và xử lý thông tin”*, tiếp theo là nhiều đoạn về công tác truyền thông. Những đoạn này cần thay bằng nhiệm vụ chuyển đổi số và kho học liệu, vì đã được triển khai trong Kế hoạch truyền thông riêng.

Dưới đây là bản nội dung hoàn chỉnh, giữ tinh thần của dự thảo nhưng chỉnh lại để thống nhất, có trọng tâm và tránh chồng chéo hồ sơ.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> Số: …/KH-MNAB
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *An Bình, ngày … tháng 11 năm 2026*
>
> # KẾ HOẠCH
> **Thực hiện chuyển đổi số và xây dựng, quản lý, khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027**
>
> Căn cứ Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020 của Bộ Giáo dục và Đào tạo ban hành Điều lệ trường mầm non và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Thông tư số 60/2026/TT-BGDĐT ngày 17/7/2026 của Bộ Giáo dục và Đào tạo quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non;
>
> Căn cứ Công văn số 3510/SGDĐT-GDMN ngày 09/9/2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp về hướng dẫn thực hiện nhiệm vụ giáo dục mầm non năm học 2026–2027;
>
> Căn cứ Kế hoạch số 129/KH-MNAB ngày 11/9/2026 về thực hiện nhiệm vụ năm học 2026–2027;
>
> Căn cứ Quyết định số 75/QĐ-MNAB ngày 01/10/2026 của Hiệu trưởng Trường Mầm non An Bình về việc thành lập Ban Chỉ đạo công tác truyền thông và chuyển đổi số năm học 2026–2027;
>
> Căn cứ tình hình thực tế và yêu cầu nâng cao hiệu quả quản lý, khai thác nguồn lực sau sáp nhập, Trường Mầm non An Bình xây dựng Kế hoạch thực hiện chuyển đổi số và xây dựng, quản lý, khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027, cụ thể như sau:
>
> ## I. MỤC ĐÍCH, YÊU CẦU
>
> ### 1. Mục đích
>
> Đẩy mạnh ứng dụng công nghệ thông tin, chuyển đổi số trong công tác quản lý, điều hành và hoạt động chuyên môn; từng bước thống nhất phương thức quản lý, lưu trữ, khai thác dữ liệu, góp phần nâng cao hiệu quả hoạt động của nhà trường sau sáp nhập.
>
> Xây dựng kho tài liệu, học liệu dùng chung trên cơ sở kế thừa, chọn lọc và phát huy nguồn tài nguyên chuyên môn của ba trường trước sáp nhập; hình thành hệ thống lưu trữ, quản lý và chia sẻ thống nhất, thuận tiện trong sử dụng, hạn chế trùng lặp và lãng phí nguồn lực.
>
> Tạo điều kiện để cán bộ quản lý, giáo viên nâng cao năng lực ứng dụng công nghệ, chia sẻ kinh nghiệm, tiếp cận nguồn học liệu có chất lượng; giảm thời gian tìm kiếm, chuẩn bị tài liệu, góp phần nâng cao hiệu quả tổ chức các hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ.
>
> ### 2. Yêu cầu
>
> - Chuyển đổi số được triển khai phù hợp với nhiệm vụ năm học, điều kiện cơ sở vật chất, năng lực đội ngũ và nhu cầu thực tế; ưu tiên khai thác hiệu quả các phần mềm, nền tảng và thiết bị hiện có.
> - Việc xây dựng kho tài liệu, học liệu phải bảo đảm tính khoa học, sư phạm, an toàn, phù hợp với Chương trình giáo dục mầm non và đặc điểm phát triển của trẻ.
> - Dữ liệu, tài liệu và học liệu được quản lý thống nhất, dễ tìm kiếm, cập nhật, chia sẻ; có phân công trách nhiệm, kiểm soát chất lượng và bảo đảm an toàn thông tin, bảo vệ dữ liệu cá nhân.
> - Gắn ứng dụng công nghệ và khai thác học liệu với hoạt động chuyên môn thường xuyên; chú trọng hiệu quả thực chất, không chạy theo số lượng sản phẩm hoặc làm phát sinh hồ sơ không cần thiết.
>
> ## II. ĐẶC ĐIỂM TÌNH HÌNH
>
> Năm học 2026–2027, nhà trường được tổ chức lại trên cơ sở sáp nhập Trường Mầm non An Bình A, Trường Mầm non An Bình B và Trường Mầm non An Lộc thành một đơn vị thống nhất. Việc sáp nhập tạo điều kiện tập trung nguồn lực về đội ngũ, cơ sở vật chất, trang thiết bị và tài liệu chuyên môn; đồng thời đặt ra yêu cầu đổi mới phương thức quản lý, tăng cường sự phối hợp, thống nhất trong chỉ đạo và tổ chức thực hiện nhiệm vụ giáo dục trên toàn trường.
>
> Trước sáp nhập, mỗi trường đã có quá trình xây dựng, tích lũy nguồn tài liệu, học liệu và những kinh nghiệm tổ chức hoạt động giáo dục phù hợp với điều kiện của đơn vị. Đây là nguồn lực chuyên môn có giá trị cần được kế thừa và phát huy. Tuy nhiên, các tài liệu, học liệu được hình thành, lưu trữ theo từng trường, chưa được kết nối thành hệ thống dùng chung. Nếu không được rà soát, lựa chọn và quản lý thống nhất, nguồn tài nguyên này dễ tiếp tục phân tán, trùng lặp, gây khó khăn trong tìm kiếm, khai thác và chưa phát huy hết giá trị sử dụng.
>
> Bên cạnh đó, việc quản lý một đơn vị có nhiều điểm trường đòi hỏi thông tin, dữ liệu và hồ sơ chuyên môn được cập nhật, lưu trữ và sử dụng thống nhất, bảo đảm thuận lợi trong chỉ đạo, điều hành. Đội ngũ được tập hợp từ các đơn vị khác nhau, có những thế mạnh, kinh nghiệm và kỹ năng ứng dụng công nghệ riêng; vì vậy cần có cơ chế phối hợp, hỗ trợ để nâng cao năng lực sử dụng các nền tảng số, đồng thời tạo điều kiện cho giáo viên các điểm trường tiếp cận nguồn học liệu có chất lượng.
>
> Từ thực tế trên, **đẩy mạnh chuyển đổi số gắn với xây dựng kho tài liệu, học liệu dùng chung là giải pháp cần thiết nhằm thống nhất quản trị, kết nối và phát huy nguồn lực của ba trường sau sáp nhập**. Trong đó, chuyển đổi số tạo điều kiện về công cụ, phương thức quản lý và chia sẻ; kho học liệu dùng chung là nguồn tài nguyên chuyên môn được khai thác trực tiếp để hỗ trợ giáo viên, từng bước nâng cao chất lượng nuôi dưỡng, chăm sóc và giáo dục trẻ trong toàn trường.
>
> ## III. CHỈ TIÊU THỰC HIỆN
>
> ### 1. Về chuyển đổi số
>
> - 100% tổ chuyên môn, bộ phận được phân công sử dụng các phần mềm, nền tảng quản lý hiện có và cập nhật dữ liệu thuộc phạm vi nhiệm vụ theo quy định.
> - 100% cán bộ quản lý, giáo viên, nhân viên được hướng dẫn, hỗ trợ sử dụng các công cụ số cần thiết phục vụ công việc; từng bước nâng cao chất lượng quản lý, lưu trữ và khai thác hồ sơ, tài liệu điện tử.
> - Các điểm trường thực hiện thống nhất việc trao đổi thông tin, lưu trữ tài liệu chuyên môn và cập nhật dữ liệu trên những hệ thống được nhà trường triển khai.
> - Thực hiện phân quyền, bảo mật và sao lưu dữ liệu phù hợp; định kỳ rà soát, khắc phục những hạn chế trong quá trình sử dụng.
>
> ### 2. Về xây dựng kho tài liệu, học liệu dùng chung
>
> - Xây dựng và đưa vào sử dụng 01 kho tài liệu, học liệu dùng chung cấp trường, có cấu trúc thống nhất, phân loại khoa học và phân quyền quản lý rõ ràng.
> - 100% tổ chuyên môn tham gia rà soát, lựa chọn, bổ sung và khai thác học liệu; mỗi khối tuổi có danh mục học liệu dùng chung phù hợp với kế hoạch giáo dục.
> - 100% cán bộ quản lý, giáo viên được hướng dẫn sử dụng kho; phấn đấu ít nhất 80% giáo viên khai thác thường xuyên sau giai đoạn triển khai.
> - 100% học liệu đưa vào danh mục sử dụng chính thức được kiểm tra về nội dung, nguồn gốc, tính phù hợp và thực hiện quy trình lựa chọn, phê duyệt theo quy định áp dụng.
> - Duy trì việc chia sẻ, đánh giá, cập nhật học liệu thông qua sinh hoạt chuyên môn; cuối năm học đánh giá hiệu quả khai thác để tiếp tục hoàn thiện kho.
>
> ## IV. NỘI DUNG VÀ GIẢI PHÁP THỰC HIỆN
>
> ### 1. Rà soát, thống nhất điều kiện và phương thức thực hiện chuyển đổi số
>
> Ban Giám hiệu chỉ đạo các tổ, bộ phận rà soát tình hình sử dụng máy tính, thiết bị công nghệ, đường truyền Internet, phần mềm quản lý và các nền tảng số đang được triển khai tại các điểm trường. Đồng thời đánh giá nhu cầu sử dụng, những khó khăn về thiết bị, kỹ năng thao tác và phương thức quản lý dữ liệu để xác định nội dung cần ưu tiên.
>
> Trên cơ sở kết quả rà soát, nhà trường thống nhất nền tảng sử dụng đối với từng nhiệm vụ, đầu mối phụ trách, trách nhiệm cập nhật và phạm vi khai thác dữ liệu. Ưu tiên tận dụng hệ thống hiện có, hạn chế sử dụng nhiều công cụ có chức năng trùng lặp hoặc làm phát sinh thao tác không cần thiết.
>
> Đối với những điểm trường hoặc cá nhân còn hạn chế về điều kiện công nghệ, tổ chức hỗ trợ phù hợp, bảo đảm các hoạt động quản lý, chuyên môn được thực hiện thống nhất mà không gây áp lực cho đội ngũ.
>
> ### 2. Đẩy mạnh ứng dụng công nghệ số trong quản lý, điều hành và hoạt động chuyên môn
>
> **Trong công tác quản lý, điều hành:** Tăng cường sử dụng các phần mềm và nền tảng số đang được triển khai để quản lý thông tin, trao đổi công việc, tiếp nhận và xử lý văn bản, theo dõi nhiệm vụ, cập nhật số liệu và tổng hợp báo cáo. Thống nhất cách thức sử dụng giữa các điểm trường, bảo đảm thông tin kịp thời, chính xác, thuận tiện trong kiểm tra, đối chiếu.
>
> **Trong quản lý hồ sơ, tài liệu:** Từng bước số hóa, sắp xếp và lưu trữ có hệ thống các tài liệu quản lý, kế hoạch chuyên môn, tài liệu bồi dưỡng và những hồ sơ được phép quản lý bằng hình thức điện tử. Ưu tiên tài liệu thường xuyên sử dụng, có giá trị kế thừa; bảo đảm đúng quy định về lập, quản lý và lưu trữ hồ sơ, không thay thế hồ sơ bắt buộc bằng hình thức điện tử khi chưa đủ điều kiện.
>
> **Trong hoạt động chuyên môn:** Khuyến khích giáo viên ứng dụng công cụ số phù hợp để xây dựng kế hoạch, thiết kế học liệu, lưu trữ tư liệu và hỗ trợ tổ chức hoạt động giáo dục. Việc sử dụng công nghệ phải xuất phát từ mục tiêu giáo dục, đặc điểm phát triển của trẻ, không lạm dụng thiết bị điện tử hoặc thay thế các hoạt động vui chơi, thao tác, trải nghiệm trực tiếp.
>
> **Trong phối hợp và trao đổi thông tin:** Khai thác hiệu quả các kênh liên lạc chính thức của nhà trường, nhóm lớp để cung cấp thông tin cần thiết, phối hợp chăm sóc, giáo dục trẻ; bảo đảm nội dung chính xác, đúng phạm vi và tuân thủ quy trình truyền thông đã được nhà trường ban hành.
>
> ### 3. Nâng cao năng lực ứng dụng công nghệ số cho đội ngũ
>
> Tổ chức hướng dẫn, hỗ trợ cán bộ quản lý, giáo viên, nhân viên sử dụng các phần mềm, nền tảng và công cụ số phục vụ trực tiếp nhiệm vụ được giao. Nội dung tập trung vào những kỹ năng thiết thực như quản lý tài khoản, cập nhật dữ liệu, lưu trữ hồ sơ điện tử, tìm kiếm và chia sẻ tài liệu, thiết kế và khai thác học liệu số, bảo vệ thông tin cá nhân.
>
> Phát huy vai trò của thành viên Ban Chỉ đạo, giáo viên có năng lực công nghệ thông tin trong hỗ trợ đồng nghiệp; khuyến khích chia sẻ những cách làm hiệu quả thông qua sinh hoạt chuyên môn, hướng dẫn trực tiếp và thực hành trên công việc thực tế.
>
> Việc bồi dưỡng được tổ chức linh hoạt, phù hợp với năng lực từng nhóm đối tượng; ưu tiên giúp giáo viên sử dụng thành thạo những công cụ cần thiết, tránh triển khai nhiều phần mềm mới khi chưa đánh giá được hiệu quả và khả năng áp dụng.
>
> ### 4. Xây dựng, quản lý và khai thác kho tài liệu, học liệu dùng chung
>
> **4.1. Rà soát, lựa chọn và kế thừa nguồn tài liệu, học liệu của các trường trước sáp nhập**
>
> Tổ chức rà soát nguồn tài liệu chuyên môn, học liệu số, tranh ảnh, video, trò chơi, đồ dùng, đồ chơi tự tạo và các sản phẩm giáo dục có giá trị sử dụng đang được lưu trữ tại các đơn vị trước sáp nhập.
>
> Việc rà soát không chỉ nhằm thống kê số lượng mà tập trung đánh giá chất lượng, khả năng sử dụng và mức độ phù hợp với nhu cầu chuyên môn hiện nay. Trên cơ sở đó, phân loại tài liệu có thể sử dụng ngay, tài liệu cần điều chỉnh, bổ sung và tài liệu trùng lặp hoặc không còn phù hợp.
>
> Các tổ chuyên môn chủ động lựa chọn những sản phẩm đã được vận dụng hiệu quả, có khả năng chia sẻ cho nhiều nhóm, lớp; đồng thời xác định những nội dung học liệu còn thiếu để bổ sung có trọng tâm, tránh xây dựng lại những tài liệu đã có.
>
> **4.2. Thiết lập và quản lý kho tài liệu, học liệu dùng chung**
>
> Trên cơ sở nguồn tài liệu đã được rà soát, nhà trường lựa chọn nền tảng lưu trữ số phù hợp để xây dựng kho dùng chung cấp trường, bảo đảm thuận tiện trong truy cập, tìm kiếm, cập nhật và khai thác.
>
> Kho được tổ chức theo các nhóm nội dung chủ yếu:
>
> - **Tài liệu quản lý và bồi dưỡng chuyên môn:** Văn bản hướng dẫn, tài liệu tập huấn, chuyên đề, sinh hoạt chuyên môn và những tài liệu nghiệp vụ được phép chia sẻ.
> - **Học liệu giáo dục theo độ tuổi:** Tranh ảnh, video, âm thanh, trò chơi và tài liệu hướng dẫn tổ chức hoạt động theo các lĩnh vực phát triển, nội dung giáo dục.
> - **Học liệu chăm sóc, nuôi dưỡng và giáo dục kỹ năng:** Tài liệu về dinh dưỡng, vệ sinh, sức khỏe, kỹ năng tự phục vụ, an toàn và các nội dung phù hợp.
> - **Học liệu trải nghiệm, đồ dùng, đồ chơi:** Trò chơi dân gian, hoạt động thực hành, trải nghiệm; đồ dùng, đồ chơi tự tạo và nguồn học liệu gắn với điều kiện địa phương.
>
> Đối với đồ dùng, đồ chơi và học liệu hiện vật, xây dựng danh mục chung thể hiện tên, vị trí lưu giữ, tình trạng và khả năng chia sẻ giữa các điểm trường, bảo đảm quản lý thuận tiện, tránh thất lạc, hư hỏng.
>
> Thống nhất cách đặt tên, phân loại và cập nhật tài liệu; phân quyền truy cập, chỉnh sửa; phân công người phụ trách quản lý hệ thống và phối hợp với các tổ chuyên môn kiểm soát nội dung trước khi đưa vào sử dụng.
>
> **4.3. Lựa chọn, chuẩn hóa và phát triển học liệu**
>
> Các tổ chuyên môn rà soát nội dung, nguồn gốc, tính khoa học, yêu cầu sư phạm, mức độ an toàn và khả năng vận dụng của tài liệu, học liệu trước khi đề xuất cập nhật vào kho. Việc lựa chọn, phê duyệt đồ chơi, học liệu thuộc phạm vi quy định được thực hiện đúng thẩm quyền và quy trình hiện hành.
>
> Ưu tiên kế thừa những sản phẩm có chất lượng, đã được sử dụng hiệu quả; khuyến khích giáo viên phối hợp điều chỉnh, bổ sung và phát triển học liệu phù hợp với đặc điểm trẻ, kế hoạch giáo dục và điều kiện từng nhóm, lớp.
>
> Việc xây dựng học liệu mới phải xuất phát từ nhu cầu thực tế, chú trọng học liệu có tính mở, dễ điều chỉnh, có thể sử dụng nhiều lần và hỗ trợ trẻ học thông qua chơi, thực hành, trải nghiệm. Không giao chỉ tiêu sản xuất học liệu theo số lượng cứng nhắc, tránh trùng lặp và hình thức.
>
> **4.4. Tổ chức khai thác, chia sẻ và đánh giá hiệu quả**
>
> Hướng dẫn giáo viên truy cập, tìm kiếm, lựa chọn và sử dụng học liệu phù hợp với mục tiêu giáo dục, đặc điểm trẻ và điều kiện tổ chức hoạt động. Đối với những nhóm, lớp còn hạn chế về thiết bị hoặc đường truyền, bố trí phương án hỗ trợ để giáo viên tiếp cận nguồn học liệu cần thiết.
>
> Gắn việc khai thác kho với sinh hoạt chuyên môn định kỳ. Khuyến khích giáo viên giới thiệu những học liệu có hiệu quả, trao đổi cách sử dụng, khó khăn khi vận dụng và đề xuất cải tiến. Tăng cường chia sẻ giữa giáo viên các điểm trường để phát huy kinh nghiệm, thế mạnh của đội ngũ sau sáp nhập.
>
> Ban Giám hiệu theo dõi hiệu quả sử dụng thông qua kế hoạch giáo dục, sinh hoạt chuyên môn và thực tế tổ chức hoạt động; định kỳ rà soát, bổ sung hoặc loại bỏ tài liệu không còn phù hợp.
>
> ### 5. Bảo đảm an toàn thông tin, kiểm tra và nâng cao hiệu quả thực hiện
>
> Thực hiện quản lý tài khoản, phân quyền truy cập và sử dụng dữ liệu đúng phạm vi nhiệm vụ. Các tài liệu, hình ảnh, video có thông tin cá nhân của trẻ và gia đình phải được kiểm soát chặt chẽ, không tự ý đăng tải, chia sẻ hoặc sử dụng ngoài mục đích được phép.
>
> Tăng cường hướng dẫn cán bộ, giáo viên, nhân viên về bảo mật tài khoản, sao lưu dữ liệu, nhận biết và phòng tránh nguy cơ mất an toàn thông tin. Phân công đầu mối hỗ trợ kỹ thuật, kịp thời xử lý những khó khăn trong quá trình sử dụng.
>
> Lồng ghép kiểm tra chuyển đổi số và khai thác kho học liệu vào hoạt động quản lý, kiểm tra chuyên môn thường xuyên. Việc đánh giá tập trung vào chất lượng dữ liệu, mức độ sử dụng nền tảng số, khả năng tiếp cận học liệu và hiệu quả hỗ trợ công việc; không chỉ dựa vào số lượng tài liệu số hóa hoặc sản phẩm được đăng tải.
>
> Trên cơ sở kết quả thực hiện, nhà trường điều chỉnh những nội dung chưa phù hợp, phát huy các giải pháp hiệu quả và từng bước hoàn thiện hệ thống quản lý, khai thác tài nguyên số trong toàn trường.
>
> ## V. TỔ CHỨC THỰC HIỆN
>
> ### 1. Tiến độ thực hiện
>
> | Thời gian | Nhiệm vụ trọng tâm | Kết quả cần đạt |
> |---|---|---|
> | **11/2026** | Rà soát điều kiện chuyển đổi số, nền tảng đang sử dụng, nhu cầu hỗ trợ; kiểm kê tài liệu, học liệu của ba trường trước sáp nhập | Xác định hiện trạng, nguồn tài liệu và các nhiệm vụ ưu tiên |
> | **12/2026** | Thống nhất cách quản lý, lưu trữ dữ liệu; thiết lập kho dùng chung, phân quyền và hướng dẫn sử dụng | Kho học liệu được đưa vào vận hành; các tổ, bộ phận nắm được cách thực hiện |
> | **01–3/2027** | Tăng cường khai thác phần mềm quản lý, hồ sơ điện tử; chuẩn hóa, bổ sung và sử dụng học liệu; hỗ trợ kỹ năng số | Nguồn học liệu được phát triển, giáo viên từng bước khai thác hiệu quả |
> | **4/2027** | Rà soát chất lượng dữ liệu, học liệu và mức độ sử dụng; khắc phục những hạn chế | Hệ thống được điều chỉnh phù hợp với thực tế |
> | **5/2027** | Đánh giá kết quả thực hiện chuyển đổi số, khai thác kho học liệu; xác định nhiệm vụ tiếp tục duy trì | Có kết quả tổng kết và định hướng thực hiện năm học tiếp theo |
>
> ### 2. Phân công trách nhiệm
>
> **Hiệu trưởng – Trưởng Ban Chỉ đạo:** Chịu trách nhiệm chỉ đạo chung; phân công nhiệm vụ, bảo đảm điều kiện thực hiện, kiểm tra và đánh giá kết quả; thực hiện việc lựa chọn, phê duyệt học liệu theo thẩm quyền và quy định hiện hành.
>
> **Phó Hiệu trưởng Hồ Thanh Trúc – Phó Trưởng ban phụ trách chuyển đổi số:** Trực tiếp tham mưu, điều phối việc triển khai kế hoạch; hướng dẫn các tổ, bộ phận ứng dụng công nghệ thông tin, quản lý hồ sơ điện tử, dữ liệu và sử dụng các nền tảng số. Phối hợp chỉ đạo thiết lập, quản lý, khai thác kho tài liệu, học liệu dùng chung; theo dõi tiến độ, tổng hợp kết quả và đề xuất giải pháp nâng cao hiệu quả thực hiện.
>
> **Các Phó Hiệu trưởng, tổ trưởng chuyên môn:** Phối hợp chỉ đạo, tổ chức rà soát, lựa chọn và kiểm soát chất lượng tài liệu, học liệu thuộc phạm vi phụ trách; hướng dẫn giáo viên khai thác, sử dụng; lồng ghép việc chia sẻ, đánh giá hiệu quả học liệu trong sinh hoạt chuyên môn và hoạt động giáo dục.
>
> **Phó Hiệu trưởng Nguyễn Thị Huỳnh Duyên – Phó Trưởng ban phụ trách truyền thông:** Phối hợp khai thác các nền tảng số phục vụ truyền thông; kiểm soát nội dung tài liệu, hình ảnh, sản phẩm giáo dục được lựa chọn để công khai trên các kênh chính thức, bảo đảm thống nhất với kế hoạch truyền thông của nhà trường.
>
> **Giáo viên, nhân viên:** Thực hiện cập nhật dữ liệu, quản lý hồ sơ điện tử và khai thác các công cụ số thuộc nhiệm vụ được giao; chủ động lựa chọn, sử dụng, chia sẻ học liệu phù hợp; bảo đảm an toàn thông tin và phản ánh kịp thời những khó khăn phát sinh.
>
> **Các thành viên hỗ trợ kỹ thuật và tổ Văn phòng:** Phối hợp hướng dẫn sử dụng công cụ số, sắp xếp, lưu trữ, sao lưu hồ sơ, tài liệu điện tử; hỗ trợ bảo đảm an toàn dữ liệu và xử lý các khó khăn kỹ thuật trong phạm vi nhiệm vụ.
>
> ### 3. Điều kiện bảo đảm và đánh giá kết quả
>
> Nhà trường ưu tiên sử dụng cơ sở vật chất, thiết bị, phần mềm và nguồn học liệu hiện có; việc bổ sung điều kiện thực hiện được xem xét trên cơ sở nhu cầu, khả năng kinh phí và quy định hiện hành.
>
> Ban Chỉ đạo công tác truyền thông và chuyển đổi số tổ chức thực hiện các nhiệm vụ theo Quyết định số 75/QĐ-MNAB ngày 01/10/2026; phối hợp với các tổ chuyên môn, bộ phận liên quan để bảo đảm thống nhất trong chỉ đạo, không thành lập thêm bộ phận quản lý riêng đối với kho học liệu.
>
> Định kỳ đánh giá tiến độ và hiệu quả thực hiện; chú trọng mức độ ứng dụng công nghệ trong công việc, chất lượng nguồn học liệu và hiệu quả khai thác của giáo viên. Kết quả được sử dụng làm cơ sở điều chỉnh, hoàn thiện và phát triển hoạt động chuyển đổi số trong các năm học tiếp theo.
>
> Trên đây là Kế hoạch thực hiện chuyển đổi số và xây dựng, quản lý, khai thác kho tài liệu, học liệu dùng chung năm học 2026–2027 của Trường Mầm non An Bình. Đề nghị các tổ chuyên môn, cán bộ, giáo viên, nhân viên và các bộ phận liên quan nghiêm túc triển khai thực hiện. Trong quá trình thực hiện, nếu có khó khăn, vướng mắc, báo cáo Ban Giám hiệu để được hướng dẫn, giải quyết kịp thời.
>
> **Nơi nhận:**
> - Phòng Văn hóa – Xã hội (để báo cáo);
> - Ban Giám hiệu;
> - Các tổ chuyên môn, giáo viên, nhân viên;
> - Lưu: VT.
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên, đóng dấu)*
>
> **Huỳnh Hồng Loan**

## ✅ Những điểm cần lưu ý trước khi hoàn thiện văn bản

Bản này giữ được **hai nội dung có quan hệ trực tiếp nhưng không đồng nhất**: chuyển đổi số là nhiệm vụ bao quát về công cụ, quản lý dữ liệu và phương thức làm việc; xây dựng kho tài liệu, học liệu dùng chung là nhiệm vụ chuyên môn trọng tâm, có quy trình và kết quả cụ thể.

Công tác truyền thông vẫn thực hiện theo Kế hoạch số 194/KH-MNAB đã ký, tránh đưa lại toàn bộ nội dung truyền thông vào văn bản này. Ban Chỉ đạo tiếp tục hoạt động theo Quyết định số 75/QĐ-MNAB, sau khi nhà trường xử lý những sai sót đã được rà soát.

Tôi đã đối chiếu thêm hiệu lực của Thông tư số 51/2026/TT-BGDĐT, Thông tư số 60/2026/TT-BGDĐT và Luật Bảo vệ dữ liệu cá nhân số 91/2025/QH15 để bảo đảm các yêu cầu về quản lý học liệu và dữ liệu phù hợp với năm học 2026–2027. [Thông tư số 51/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Sửa đổi, bổ sung một số điều của Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy chế tố chức, hoạt động nhóm trẻ độc lập, lớp mẫu giáo độc lập, lớp mầm non độc lập loại hình dân lập và tư thục ban hành kèm theo Thông tư số 49/2021/TT\-BGDĐT ngày 31 tháng 12 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy định tiêu chuẩn, quy trình biên soạn, chỉnh sửa Chương trình giáo dục mầm non, tổ chức và hoạt động của Hội đồng quốc gia thẩm định chương trình giáo dục mầm non ban hành kèm theo Thông tư số 49/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo](<https://chinhphu.vn/?docid=218796&pageid=27160>); [Thông tư số 60/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Quy định tiêu chuẩn, quy trình biên soạn tài liệu hướng dẫn thực hiện Chương trình giáo dục mầm non và việc lựa chọn đồ chơi, học liệu được sử dụng trong cơ sở giáo dục mầm non](<https://chinhphu.vn/?classid=1&docid=218922&pageid=27160&typegroupid=6>); [Bộ Công An](<https://vbpl.moj.gov.vn/bocongan/Pages/vbpq-thuoctinh.aspx?ItemID=179252&Keyword=>)

**Riêng phần căn cứ**, bạn nên kiểm tra lại tên cơ quan ban hành của Kế hoạch số 129/KH-MNAB, vì trong tệp vừa gửi ghi Trường Mầm non An Bình A, trong khi Quyết định số 75 đã ký ghi Trường Mầm non An Bình. Tôi giữ phần dẫn chiếu ngắn để tránh xác định sai trước khi đối chiếu bản gốc.

Về chất lượng quản lý, tôi đánh giá bố cục này phù hợp hơn: **không viết lại kế hoạch truyền thông, không làm mất trọng tâm kho học liệu, nhưng bổ sung đủ nhiệm vụ chuyển đổi số để Ban Chỉ đạo có cơ sở triển khai đồng bộ tại ba cơ sở sau sáp nhập.**

---

USER

\- Tài liệu quản lý và bồi dưỡng chuyên môn: Văn bản hướng dẫn, tài liệu tập huấn, chuyên đề, sinh hoạt chuyên môn và những tài liệu nghiệp vụ được phép chia sẻ.

\- Học liệu giáo dục theo độ tuổi: Tranh ảnh, video, âm thanh, trò chơi và tài liệu hướng dẫn tổ chức hoạt động theo các lĩnh vực phát triển, nội dung giáo dục.

\- Học liệu chăm sóc, nuôi dưỡng và giáo dục kỹ năng: Tài liệu về dinh dưỡng, vệ sinh, sức khỏe, kỹ năng tự phục vụ, an toàn và các nội dung phù hợp.

\- Học liệu trải nghiệm, đồ dùng, đồ chơi: Trò chơi dân gian, hoạt động thực hành, trải nghiệm; đồ dùng, đồ chơi tự tạo và nguồn học liệu gắn với điều kiện địa phương.

Thống nhất cách đặt tên, phân loại và cập nhật tài liệu; phân quyền truy cập, chỉnh sửa; phân công người phụ trách quản lý hệ thống và phối hợp với các tổ chuyên môn kiểm soát nội dung trước khi đưa vào sử dụn&#x67;**. Viết lại nội dung này sát thực tiễn **

---

ASSISTANT

Tôi đề xuất điều chỉnh theo hướng **phân loại tài liệu dựa trên nhu cầu sử dụng thực tế của giáo viên**, tận dụng nguồn học liệu của ba trường trước sáp nhập, đồng thời quy định cách quản lý đơn giản, dễ thực hiện. Không nên phân chia quá nhiều nhóm tài liệu khiến giáo viên khó tìm kiếm và người phụ trách mất thời gian cập nhật.

Bạn có thể thay toàn bộ đoạn trên bằng nội dung sau:

> **writing · standard**
>
> Kho tài liệu, học liệu dùng chung được tổ chức trên nền tảng lưu trữ số phù hợp với điều kiện nhà trường, ưu tiên sử dụng các công cụ hiện có. Tài liệu được lựa chọn, sắp xếp theo nhu cầu khai thác thực tế, gồm các nhóm chính:
>
> - **Tài liệu chỉ đạo và bồi dưỡng chuyên môn:** Các văn bản hướng dẫn còn hiệu lực, biểu mẫu chuyên môn thống nhất, tài liệu tập huấn, chuyên đề, nội dung sinh hoạt chuyên môn và những tài liệu tham khảo thiết thực phục vụ công tác quản lý, tổ chức hoạt động giáo dục.
>
> - **Học liệu giáo dục theo khối tuổi:** Phân chia theo các khối Nhà trẻ, Mầm, Chồi, Lá; tập hợp những học liệu giáo viên thường xuyên sử dụng như tranh ảnh, thơ, truyện, bài hát, trò chơi, video minh họa, tài liệu hướng dẫn tổ chức hoạt động và những sản phẩm giáo dục có chất lượng đã được vận dụng hiệu quả tại các nhóm, lớp.
>
> - **Tài liệu phục vụ chăm sóc, nuôi dưỡng và giáo dục kỹ năng:** Các nội dung hướng dẫn về dinh dưỡng, vệ sinh, chăm sóc sức khỏe, phòng tránh tai nạn thương tích, hình thành thói quen và kỹ năng tự phục vụ; ưu tiên tài liệu phù hợp với thực tế chăm sóc, giáo dục trẻ tại trường và có thể sử dụng trong phối hợp với cha mẹ trẻ.
>
> - **Học liệu thực hành, trải nghiệm và đồ dùng, đồ chơi tự tạo:** Tập hợp hình ảnh, video, hướng dẫn làm và sử dụng đồ dùng, đồ chơi; các trò chơi dân gian, hoạt động trải nghiệm, sản phẩm sáng tạo của giáo viên từ các điểm trường. Đối với học liệu hiện vật có thể sử dụng chung, lập danh mục ghi rõ nơi lưu giữ để thuận tiện trao đổi, chia sẻ khi cần thiết.
>
> Trên cơ sở nguồn tài liệu, học liệu được kế thừa từ ba trường trước sáp nhập, các tổ chuyên môn phối hợp rà soát, lựa chọn những sản phẩm phù hợp, hạn chế trùng lặp và bổ sung theo nhu cầu thực tế. Nhà trường thống nhất cách đặt tên, sắp xếp thư mục theo nhóm nội dung, khối tuổi để giáo viên dễ tìm kiếm và sử dụng; phân công người phụ trách cập nhật, quản lý quyền truy cập và sao lưu dữ liệu. Tổ trưởng chuyên môn chịu trách nhiệm rà soát chất lượng nội dung, phối hợp với Ban Giám hiệu thực hiện việc lựa chọn, phê duyệt học liệu theo quy định trước khi đưa vào sử dụng. Việc cập nhật được thực hiện thường xuyên, có chọn lọc, bảo đảm an toàn thông tin, quyền tác giả và không làm phát sinh thêm hồ sơ không cần thiết.

### 💡 Điểm tôi muốn nhấn mạnh

Với Trường Mầm non An Bình, sau sáp nhập ba trường, **không nên xây dựng ba kho riêng rồi tập hợp hình thức thành một kho chung**. Nên thống nhất một hệ thống phân loại theo khối tuổi và nhu cầu chuyên môn; những học liệu tốt của từng điểm trường đều được đưa vào nguồn dùng chung khi đáp ứng yêu cầu.

Đặc biệt, nên phân biệt rõ:

- **Học liệu số:** Được lưu trữ trực tiếp để giáo viên truy cập, sử dụng.
- **Đồ dùng, đồ chơi hiện vật:** Chỉ cần lưu hình ảnh, hướng dẫn sử dụng, vị trí bảo quản và thông tin liên hệ khi cần chia sẻ.

Như vậy, kho học liệu không chỉ là nơi lưu trữ tài liệu trên máy tính mà thực sự hỗ trợ giáo viên **tìm được học liệu cần thiết, sử dụng được ngay và kế thừa được kinh nghiệm của đồng nghiệp**.

Đây mới là cách tổ chức sát điều kiện thực tiễn và có khả năng duy trì lâu dài sau sáp nhập.

---

USER

viết cụ thể nội dung tổ chuyên môn giúp mình

---

ASSISTANT

Tôi đề xuất viết cụ thể trách nhiệm của **tổ chuyên môn** theo hướng: không chỉ tham gia xây dựng kho học liệu mà còn chịu trách nhiệm lựa chọn, kiểm tra chất lượng, hướng dẫn giáo viên khai thác và đánh giá hiệu quả sử dụng. Nội dung cần rõ việc, đúng chức năng của tổ trưởng chuyên môn và không làm phát sinh thêm hồ sơ.

Bạn có thể sử dụng đoạn sau để thay thế nội dung về tổ chuyên môn tại **mục V.2. Phân công trách nhiệm**:

> **writing · standard**
>
> **Các tổ chuyên môn:**
>
> Tổ trưởng chuyên môn tổ chức cho giáo viên rà soát, tập hợp nguồn tài liệu, học liệu hiện có tại các nhóm, lớp và những sản phẩm được kế thừa từ ba trường trước sáp nhập. Căn cứ kế hoạch giáo dục của từng khối tuổi, lựa chọn những tài liệu, học liệu có chất lượng, phù hợp với nhu cầu sử dụng; phân loại theo nội dung, lĩnh vực phát triển, đồng thời xác định những học liệu còn thiếu cần bổ sung, tránh trùng lặp và lãng phí nguồn lực.
>
> Chịu trách nhiệm kiểm tra bước đầu về nội dung chuyên môn, tính chính xác, sự phù hợp với độ tuổi, nguồn gốc và khả năng sử dụng của học liệu; đề xuất Ban Giám hiệu xem xét, thực hiện việc lựa chọn, phê duyệt theo quy định. Phối hợp với bộ phận phụ trách chuyển đổi số sắp xếp, cập nhật học liệu vào đúng thư mục dùng chung, bảo đảm thuận tiện trong tìm kiếm, chia sẻ và khai thác.
>
> Lồng ghép việc hướng dẫn sử dụng, giới thiệu và chia sẻ học liệu trong sinh hoạt chuyên môn định kỳ; khuyến khích giáo viên vận dụng những học liệu có chất lượng vào tổ chức hoạt động giáo dục, trao đổi kinh nghiệm và hỗ trợ đồng nghiệp giữa các điểm trường. Thường xuyên nắm bắt khó khăn, đánh giá hiệu quả sử dụng, đề xuất điều chỉnh, bổ sung hoặc loại bỏ những học liệu không còn phù hợp; tổng hợp kết quả thông qua hoạt động chuyên môn thường xuyên, không làm phát sinh hồ sơ riêng.

### 💡 Điểm cần lưu ý trong phân công

Ở Trường Mầm non An Bình, tôi đề xuất **tổ trưởng chuyên môn chịu trách nhiệm về chất lượng nội dung học liệu của khối tuổi mình phụ trách**, còn bộ phận chuyển đổi số chịu trách nhiệm hỗ trợ kỹ thuật, tổ chức lưu trữ và quản lý hệ thống.

Cách phân công này bảo đảm ba việc quan trọng:

- **Có nguồn học liệu phù hợp:** Tổ chuyên môn chủ động lựa chọn theo nhu cầu thực tế của giáo viên và trẻ.
- **Có kiểm soát chất lượng:** Tổ trưởng rà soát, đề xuất; Ban Giám hiệu và Hội đồng lựa chọn đồ chơi, học liệu thực hiện trách nhiệm theo thẩm quyền khi thuộc phạm vi quy định.
- **Có sử dụng thực chất:** Giáo viên được hướng dẫn, chia sẻ và vận dụng học liệu vào hoạt động giáo dục, không dừng ở việc đăng tải tài liệu lên kho.

**Tôi nghiêng về nội dung phân công này** vì vừa thể hiện được vai trò điều hành của tổ trưởng chuyên môn, vừa gắn trách nhiệm với kết quả thực hiện; đặc biệt phù hợp với yêu cầu kết nối đội ngũ sau sáp nhập ba trường.

---

