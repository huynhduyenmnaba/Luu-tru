USER

với vai trò giảng viên cao học bạn giúp tôi giải bài tập sau

---

ASSISTANT

Tôi sẽ giải đủ 40 câu theo đúng đề đã gửi, nêu đáp án và lý do chọn, đồng thời lưu ý các khái niệm dễ nhầm như *subject complement*, *object complement* và các loại mệnh đề.

---

ASSISTANT

Tôi đã xem toàn bộ tài liệu **SAMPLE MULTIPLE-CHOICE TEST – ENGLISH GRAMMAR** bạn gửi, gồm 40 câu trắc nghiệm, thời gian làm bài 60 phút.

Dưới góc độ giảng viên chuyên ngành Ngôn ngữ Anh, tôi sẽ giải từng câu theo ba nội dung: **đáp án chính xác, căn cứ ngữ pháp và giải thích vì sao đáp án đúng**. Phần cuối có những kiến thức quan trọng cần ghi nhớ để làm các đề tương tự.

## I. Bảng đáp án tổng hợp 40 câu

## II. Giải thích chi tiết từng câu

### Phần 1. Nouns and Noun Phrases – Danh từ và cụm danh từ (Câu 1–10)

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 1 | **C. Success** | *Success* \(sự thành công) là danh từ (*noun*\). *Carefully* và *quickly* là trạng từ; *beautiful* là tính từ. |
| 2 | **B** | *London* là danh từ riêng (*proper noun*\), chỉ tên một thành phố cụ thể và được viết hoa. |
| 3 | **A. Subject** | Trong câu *The old bridge collapsed yesterday*, cụm danh từ *The old bridge* giữ chức năng chủ ngữ, thực thể được nói đến trong sự việc sụp đổ. |
| 4 | **B. Direct Object** | Trong câu *She bought a new computer*, cụm *a new computer* là tân ngữ trực tiếp của động từ *bought*, trả lời câu hỏi “bought what?”. |
| 5 | **B** | *Honesty* \(sự trung thực) là danh từ trừu tượng (*abstract noun*\), diễn tả phẩm chất không thể tiếp nhận trực tiếp bằng giác quan. |
| 6 | **A** | *Audience* \(khán giả) là danh từ tập hợp (*collective noun*\), chỉ một nhóm người được xem như một tập thể. |
| 7 | **C. Advice** | *Advice* là danh từ không đếm được (*uncountable noun*\). Có thể nói *a piece of advice*, không nói *an advice* trong tiếng Anh chuẩn. |
| 8 | **A** | Trong *My father is a doctor*, cụm *a doctor* là bổ ngữ chủ ngữ (*subject complement*\), xác định nghề nghiệp của chủ ngữ *my father*. |
| 9 | **B** | *An interesting movie* là cụm danh từ giữ chức năng tân ngữ trực tiếp của động từ *watched*. |
| 10 | **B** | *The beautiful garden* có từ hạn định *the* \(*determiner*\) và tính từ *beautiful* \(*adjective*\) bổ nghĩa cho danh từ *garden*. |

**Kiến thức cần nhớ:** Cụm danh từ (*noun phrase*\) có thể đảm nhiệm nhiều chức năng cú pháp, đặc biệt là chủ ngữ (*subject*\), tân ngữ (*object*\) và bổ ngữ (*complement*\).

### Phần 2. Pronouns – Đại từ (Câu 11–15)

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 11 | **C. They** | *They* là đại từ nhân xưng dạng chủ ngữ (*subject pronoun*\). *Him, them, us* thuộc dạng tân ngữ (*object pronouns*\). |
| 12 | **A** | Trong *She called me yesterday*, *me* là đại từ tân ngữ, nhận tác động của hành động *called*. |
| 13 | **B. Hers** | *Hers* là đại từ sở hữu (*possessive pronoun*\), có thể đứng độc lập: *This book is hers*. *My, their* là từ hạn định sở hữu. |
| 14 | **A** | Trong *The man who helped us is my uncle*, *who* là đại từ quan hệ (*relative pronoun*\), mở đầu mệnh đề bổ nghĩa cho *the man*. |
| 15 | **A** | Trong *She hurt herself*, *herself* là đại từ phản thân (*reflexive pronoun*\), chỉ lại chủ ngữ *she*. |

**Điểm dễ nhầm ở câu 13:** *Her* có thể là đại từ tân ngữ (*I saw her*\) hoặc từ hạn định sở hữu (*her book*\). Trong hệ thống phân loại của đề, *hers* mới là đại từ sở hữu đứng độc lập.

### Phần 3. Adjectives – Tính từ và chức năng của tính từ (Câu 16–22)

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 16 | **C. Honest** | *Honest* \(trung thực) là tính từ. *Happiness* là danh từ, còn *quickly* và *carefully* là trạng từ. |
| 17 | **B** | Trong *She bought a red dress*, *red* là tính từ định ngữ (*attributive adjective*\) vì đứng trước và bổ nghĩa trực tiếp cho danh từ *dress*. |
| 18 | **A** | Trong *The weather is cold*, *cold* là tính từ vị ngữ (*predicative adjective*\), đứng sau động từ nối *is* để mô tả chủ ngữ. |
| 19 | **A** | Trong *They painted the wall white*, *white* là bổ ngữ tân ngữ (*object complement*\), diễn tả trạng thái của *the wall* sau hành động sơn. |
| 20 | **A** | *Small* và *black* là hai tính từ bổ nghĩa cho danh từ *bag* trong cụm *a small black bag*. |
| 21 | **B** | Trong *The children seem happy*, *seem* là động từ nối (*linking verb*\) và *happy* là tính từ làm bổ ngữ chủ ngữ. |
| 22 | **B** | Trong *She bought a beautiful painting*, *beautiful* là tính từ trực tiếp bổ nghĩa cho danh từ *painting*. |

**Phân biệt ba chức năng quan trọng của tính từ:**

| Chức năng | Ví dụ | Bản chất |
|--------|--------|--------|
| Attributive adjective | *a beautiful girl* | Tính từ bổ nghĩa cho danh từ trong cụm danh từ. |
| Predicative adjective | *The girl is beautiful.* | Tính từ làm bổ ngữ cho chủ ngữ. |
| Object complement | *They painted the door red.* | Tính từ làm bổ ngữ cho tân ngữ, mô tả trạng thái hoặc kết quả liên quan đến tân ngữ. |

### Phần 4. Noun Clauses – Mệnh đề danh từ (Câu 23–28)

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 23 | **A. Subject** | Trong *What she said surprised everyone*, mệnh đề *What she said* làm chủ ngữ của động từ *surprised*. |
| 24 | **B. Direct Object** | Trong *I don't know where he lives*, *where he lives* là mệnh đề danh từ, làm bổ ngữ cho động từ *know*, được phân loại là tân ngữ trực tiếp theo ngữ pháp truyền thống của đề. |
| 25 | **B. Subject Complement** | Trong *The problem is that we are late*, mệnh đề *that we are late* làm bổ ngữ chủ ngữ sau động từ nối *is*, nêu nội dung của *the problem*. |
| 26 | **B. Direct Object** | Trong *She asked whether I was ready*, *whether I was ready* diễn đạt nội dung câu hỏi và làm bổ ngữ cho *asked*, được đề phân loại là tân ngữ trực tiếp. |
| 27 | **B** | Trong *What he wants is impossible*, *What he wants* đóng vai trò chủ ngữ của câu. Các phương án còn lại không có mệnh đề danh từ làm chủ ngữ. |
| 28 | **B** | Trong *I wonder why she left*, *why she left* là mệnh đề danh từ làm bổ ngữ cho động từ *wonder*, được phân loại theo đề là tân ngữ. |

**Kiến thức quan trọng:** Mệnh đề danh từ (*noun clause*\) trong cách phân loại ngữ pháp truyền thống có thể giữ những chức năng như chủ ngữ, tân ngữ và bổ ngữ chủ ngữ.

Lưu ý ở mức phân tích ngôn ngữ học chuyên sâu: *where he lives*, *whether I was ready* và *why she left* cũng được mô tả chính xác hơn là các *embedded interrogative clauses* \(mệnh đề nghi vấn gián tiếp). Tuy nhiên, theo hệ thống thuật ngữ và các lựa chọn của đề thi, các đáp án trên là phù hợp.

### Phần 5. Adjective Clauses – Mệnh đề tính từ / Mệnh đề quan hệ (Câu 29–34)

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 29 | **A. Student** | Trong *The student who won the prize is my friend*, mệnh đề *who won the prize* bổ nghĩa cho danh từ *student*. |
| 30 | **A. Book** | Trong *The book that I borrowed is interesting*, mệnh đề *that I borrowed* xác định quyển sách đang được đề cập. |
| 31 | **C. Whose** | *Whose* là đại từ quan hệ mang ý nghĩa sở hữu, chẳng hạn *the girl whose father is a doctor*. |
| 32 | **B** | Trong *The girl who called is my cousin*, *who called* là mệnh đề quan hệ bổ nghĩa cho danh từ *girl*. |
| 33 | **A. Restaurant** | Trong *The restaurant where we had dinner was excellent*, mệnh đề *where we had dinner* bổ nghĩa cho danh từ *restaurant*. |
| 34 | **A. Year** | Trong *The year when I graduated was unforgettable*, mệnh đề *when I graduated* bổ nghĩa cho danh từ *year*. |

**Kiến thức cần nhớ:** Mệnh đề tính từ (*adjective clause/relative clause*\) thường đứng sau danh từ mà nó bổ nghĩa. *Who, whom, whose, which* là những đại từ quan hệ thường gặp; *where* và *when* trong câu 33–34 là trạng từ quan hệ (*relative adverbs*\).

### Phần 6. Adverb Clauses – Mệnh đề trạng ngữ (Câu 35–40)

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 35 | **B. Reason** | *Because it was raining* là mệnh đề trạng ngữ chỉ nguyên nhân (*adverb clause of reason*\). *Because* có nghĩa là “bởi vì”. |
| 36 | **A. Time** | *After the meeting ends* là mệnh đề trạng ngữ chỉ thời gian, xác định thời điểm của hành động *we'll leave*. |
| 37 | **C. Condition** | *If you study hard* là mệnh đề trạng ngữ chỉ điều kiện. *If* diễn tả điều kiện để kết quả *you will pass* xảy ra. |
| 38 | **A. Purpose** | *So that nobody could hear* là mệnh đề trạng ngữ chỉ mục đích, cho biết tại sao cô ấy nói thì thầm. |
| 39 | **A. Contrast (Concession)** | *Although he was tired* là mệnh đề trạng ngữ chỉ sự nhượng bộ (*concession*\), thể hiện sự đối lập với hành động tiếp tục làm việc. |
| 40 | **A** | Trong *You can sit wherever you like*, *wherever you like* là mệnh đề trạng ngữ chỉ nơi chốn (*adverb clause of place*\). |

## III. Hệ thống hóa kiến thức trọng tâm để ôn thi

Đề thi này tập trung vào hai nội dung cốt lõi của English Grammar: **word classes** \(các loại từ) và **syntactic functions** \(các chức năng cú pháp), đặc biệt là việc xác định vai trò của các cụm từ và mệnh đề trong câu.

## Phân biệt ba loại mệnh đề quan trọng nhất

**1. Noun Clause – Mệnh đề danh từ**

*What she said surprised me.*

→ *What she said* đóng vai trò chủ ngữ, tương tự chức năng của một cụm danh từ.

---

**2. Adjective Clause – Mệnh đề tính từ**

*The student who studies hard will succeed.*

→ *Who studies hard* bổ nghĩa cho danh từ *student*.

---

**3. Adverb Clause – Mệnh đề trạng ngữ**

*She stayed home because she was sick.*

→ *Because she was sick* diễn tả nguyên nhân của hành động.

Một điểm cần đặc biệt chú ý trong đề là sự khác nhau giữa *subject complement* và *object complement*. Bổ ngữ chủ ngữ mô tả hoặc xác định chủ ngữ (*She is happy*\), còn bổ ngữ tân ngữ mô tả hoặc xác định tân ngữ (*They made her happy*\).

## IV. Tự kiểm tra kiến thức

4 câu vận dụng /4 đã chọn

**Kết luận:** Theo hệ thống ngữ pháp được sử dụng trong đề mẫu, cả 40 câu đều có đáp án xác định. Những phần đáng ưu tiên ôn tập nhất là chức năng của *noun phrases*, chức năng bổ ngữ của tính từ và cách phân biệt *noun clauses, adjective clauses* với *adverb clauses*.

**Mức độ tin cậy: Cao** – Các đáp án được xác định trực tiếp từ nội dung đề thi và đối chiếu với các nguyên tắc ngữ pháp tiếng Anh.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

với vai trò giảng viên cao học bạn giúp tôi giải bài tập sau

---

ASSISTANT

Tài liệu có 60 câu ôn tập thuộc 6 chương và bảng đáp án ở trang 9. Tôi sẽ đối chiếu từng đáp án với kiến thức ngôn ngữ học, giải thích ngắn gọn từng câu và đánh dấu riêng những chỗ đáp án mẫu có dấu hiệu chưa chính xác hoặc đề chưa chặt chẽ.

---

ASSISTANT

Tôi đã đọc toàn bộ tài liệu **Đề cương ôn tập học phần DẪN LUẬN NGÔN NGỮ – Học kỳ 3, năm học 2025–2026** mà bạn gửi.

Với góc nhìn của giảng viên chuyên ngành Ngôn ngữ học ở trình độ sau đại học, tôi sẽ giải toàn bộ **60 câu hỏi thuộc 6 chương**, dựa trên đáp án có sẵn ở trang 9, đồng thời kiểm tra tính chính xác về mặt học thuật.

Cách trình bày gồm đáp án, giải thích bằng tiếng Việt, thuật ngữ chuyên ngành tiếng Anh và lưu ý những câu dễ nhầm. Đặc biệt, tôi sẽ phân biệt những câu **đúng theo đáp án của tài liệu** với những câu có vấn đề về kiến thức hoặc cách đặt câu hỏi.

## I. Bảng đáp án tổng hợp

Bảng dưới đây giữ nguyên đáp án của tài liệu ở trang 9. Dấu \* chỉ các câu cần lưu ý về mặt học thuật.

| Chương | Câu 1–5 | Câu 6–10 |
|--------|--------|--------|
| 1. Phonetics | C – D – A – C – D | F – T\* – T – T – T |
| 2. Phonology | A – D – A – T\* – T\* | T – F – F – T – F |
| 3. Morphology | A – A – A – B – B | F\* – F – F – F – F |
| 4. Syntax | A – A – A – D – C\* | C\* – T – F – T – F |
| 5. Semantics | C – D – C – A – F | F – T – T – F – T |
| 6. Pragmatics | D – C – B – A\* – D | A – T – T – F – F |

Lưu ý: Trong Chương 2 và Chương 5, phần True/False không bắt đầu ở cùng số câu với những chương có 5 câu Multiple Choice. Bảng trên thể hiện số câu 1–10 của từng chương theo thứ tự gốc, không phải chia cố định thành 5 câu mỗi dạng.

## II. Giải thích chi tiết từng chương

## Chapter 1 – Phonetics (Ngữ âm học)

*Phonetics* nghiên cứu âm thanh lời nói xét về cách cấu âm, đặc điểm âm học và sự tiếp nhận âm thanh.

### A. Multiple Choice – Câu 1 đến câu 5

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 1 | **C. Manner of articulation** | *Manner of articulation* \(phương thức cấu âm) chủ yếu dùng để phân loại phụ âm, chẳng hạn *plosive, fricative, nasal*. Nguyên âm thường được phân loại theo độ cao của lưỡi, vị trí trước–sau của lưỡi, độ tròn môi và các tiêu chí khác. |
| 2 | **D. Approximants** | Bán nguyên âm (*semi-vowels*\), chẳng hạn /j/ và /w/, thuộc nhóm âm tiếp cận (*approximants*\). Khi cấu âm, các cơ quan phát âm tiến gần nhau nhưng không tạo mức cản trở luồng khí đủ mạnh để hình thành âm xát. |
| 3 | **A. Labio-dental** | Phụ âm môi–răng (*labiodental consonants*\) được phát âm bằng cách đưa môi dưới tiếp xúc hoặc tiến gần răng trên. Ví dụ: /f/ và /v/. |
| 4 | **C. The position of the lips** | Cách phân loại nguyên âm thành *rounded* và *unrounded* dựa trên hình dạng, vị trí của môi khi phát âm. Ví dụ: /uː/ là nguyên âm tròn môi, còn /iː/ không tròn môi. |
| 5 | **D. Glides** | /j/ và /w/ được gọi là *glides* \(âm lướt). Trong cách phân loại cấu âm, chúng cũng thuộc nhóm approximants. |

### B. True/False – Câu 6 đến câu 10

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 6 | **F – False** | Âm đầu của *young* là /j/, một âm tiếp cận ngạc cứng (*palatal approximant*\), không phải âm thanh hầu (*glottal sound*\). /h/ là ví dụ điển hình của phụ âm thanh hầu trong tiếng Anh. |
| 7 | **T theo tài liệu; F theo phân loại ngữ âm** | *Ship* bắt đầu bằng /ʃ/, là âm xát (*fricative*\). Tuy nhiên, *church* bắt đầu bằng /tʃ/ và *judge* bằng /dʒ/, đều là âm tắc-xát (*affricates*\), không phải âm xát thuần túy. Vì vậy, nhận định rằng cả ba đều là fricatives là không chính xác. |
| 8 | **T – True** | Trong các cách phát âm như /ˈsʌdn̩/ (*sudden*\) và /ˈmʌtn̩/ (*mutton*\), /n̩/ là phụ âm âm tiết (*syllabic consonant*\), có thể làm hạt nhân âm tiết. Hiện tượng này phụ thuộc vào cách phát âm và biến thể tiếng Anh. |
| 9 | **T – True** | /p/ và /b/ đều là phụ âm tắc hai môi (*bilabial plosives*\). /p/ vô thanh (*voiceless*\), còn /b/ hữu thanh (*voiced*\). |
| 10 | **T – True** | Trong hệ thống phân loại nguyên âm có xét độ căng, nguyên âm có thể được chia thành *tense vowels* \(nguyên âm căng) và *lax vowels* \(nguyên âm lơi). |

**Kiến thức trọng tâm chương 1**

Phải phân biệt *place of articulation* \(vị trí cấu âm) với *manner of articulation* \(phương thức cấu âm). Đồng thời, cần ghi nhớ rằng /ʃ/ là *fricative*, còn /tʃ/ và /dʒ/ là *affricates*. Đây chính là căn cứ cho nhận xét về câu 7.

## Chapter 2 – Phonology (Âm vị học)

*Phonology* nghiên cứu hệ thống âm thanh của ngôn ngữ, cách các âm vị hoạt động và tổ chức thành những đối lập có chức năng phân biệt nghĩa.

### A. Multiple Choice – Câu 1 đến câu 3

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 1 | **A. Phonology** | Âm vị học nghiên cứu sự lựa chọn, tổ chức và phân bố âm thanh trong hệ thống của một ngôn ngữ. Điều này khác với *phonetics*, vốn quan tâm trực tiếp đến đặc điểm vật lý của âm thanh lời nói. |
| 2 | **D. 7** | *Extend* có phiên âm âm vị /ɪkˈstend/, gồm bảy âm vị: /ɪ/, /k/, /s/, /t/, /e/, /n/, /d/. Cần đếm âm vị, không phải số chữ cái. |
| 3 | **A. A phoneme** | *Phoneme* \(âm vị) là đơn vị âm thanh trừu tượng có chức năng phân biệt nghĩa. *Allophone* \(biến thể âm vị) là cách hiện thực hóa về mặt ngữ âm của một âm vị. |

### B. True/False – Câu 4 đến câu 10

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 4 | **T – True** | *Allophone* là một biến thể ngữ âm cụ thể của cùng một âm vị. Chẳng hạn, /p/ trong tiếng Anh có thể được hiện thực hóa thành \[pʰ\] hoặc \[p\] tùy môi trường âm thanh. |
| 5 | **T theo tài liệu; F theo định nghĩa chặt chẽ** | *Core* /kɔːr/ và *score* /skɔːr/ khác nhau do có thêm âm /s/ ở từ thứ hai. Theo định nghĩa *minimal pair* thường dùng trong âm vị học nhập môn, hai từ phải khác nhau bằng sự thay thế một âm vị tại cùng vị trí. Vì vậy, cặp này không phải ví dụ chuẩn của minimal pair. |
| 6 | **T – True** | *Minimal pair* \(cặp tối thiểu) là hai từ có nghĩa khác nhau và chỉ khác nhau ở một âm vị trong cùng vị trí tương ứng. Ví dụ: *pat* /pæt/ và *bat* /bæt/. |
| 7 | **F – False** | /t/ trong *steak* thường không bật hơi \[t\] vì đứng sau /s/. Trong *take*, /t/ ở đầu âm tiết mang trọng âm thường được bật hơi \[tʰ\]. Chúng là hai cách hiện thực hóa khác nhau của cùng âm vị /t/. |
| 8 | **F – False** | *Tag* /tæɡ/ và *pack* /pæk/ khác nhau ở ít nhất hai âm vị: /t/ so với /p/, và /ɡ/ so với /k/. Do đó, chúng không phải cặp tối thiểu. |
| 9 | **T – True** | *Places* /ˈpleɪsɪz/ có sáu âm vị: /p/, /l/, /eɪ/, /s/, /ɪ/, /z/. Âm đôi /eɪ/ được tính là một âm vị. |
| 10 | **F – False** | Phiên âm âm vị (*phonemic transcription*\) đặt trong hai dấu gạch chéo /.../, còn phiên âm ngữ âm (*phonetic transcription*\) đặt trong ngoặc vuông \[...\]. |

**Kiến thức trọng tâm chương 2**

Ba khái niệm quan trọng cần phân biệt:

| Thuật ngữ | Định nghĩa ngắn gọn |
|--------|--------|
| Phoneme | Âm vị – đơn vị có chức năng phân biệt nghĩa. |
| Allophone | Biến thể ngữ âm của một âm vị. |
| Minimal pair | Hai từ khác nghĩa chỉ khác nhau một âm vị tại cùng vị trí tương ứng, theo định nghĩa chặt chẽ thông dụng. |

Câu 5 cần đặc biệt lưu ý vì đáp án in trong đề cương không phù hợp với chính định nghĩa được hỏi ở câu 6 khi áp dụng tiêu chí vị trí tương ứng.

## Chapter 3 – Morphology (Hình thái học)

*Morphology* nghiên cứu cấu trúc bên trong của từ, các hình vị (*morphemes*\) và những quá trình tạo từ trong ngôn ngữ.

### A. Multiple Choice – Câu 1 đến câu 5

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 1 | **A. Free** | *Learn* là hình vị tự do (*free morpheme*\) vì có thể đứng độc lập và mang nghĩa. Ngược lại, những hình vị như *\-ed, -ing, un-* không thể đứng độc lập. |
| 2 | **A. 2** | *Telescope* có thể được phân tích thành hai thành tố hình thái *tele-* \(xa) và *\-scope* \(dụng cụ quan sát). Theo cách phân tích trong đề, từ này gồm hai hình vị. |
| 3 | **A. Affixes** | *Affixes* \(phụ tố) là những hình vị được thêm vào gốc từ (*root*\) hoặc thân từ (*stem*\). Chúng gồm các loại như *prefixes* \(tiền tố), *suffixes* \(hậu tố) và *infixes* \(trung tố). |
| 4 | **B. Initialism** | *TV* được hình thành từ các chữ cái đầu của *television* theo cách viết tắt và được đọc bằng tên từng chữ cái /ˌtiː ˈviː/. Vì vậy, đáp án theo đề là *initialism*. |
| 5 | **B. Compounds** | Quá trình kết hợp hai hay nhiều từ có sẵn để tạo từ mới được gọi là *compounding* \(ghép từ). Ví dụ: *blackboard, toothbrush, classroom*. Phương án B là tên của loại từ được tạo ra. |

### B. True/False – Câu 6 đến câu 10

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 6 | **F theo tài liệu – Cần lưu ý** | Đề dường như phân tích *antisocialism* thành *anti-* \+ *social* \+ *\-ism*, tức ba hình vị. Tuy nhiên, nếu phân tích *social* tiếp thành *soci-* \+ *\-al*, tổng cộng có thể là bốn hình vị. Vì vậy, câu hỏi phụ thuộc vào mức độ phân tích hình thái. |
| 7 | **F – False** | Hậu tố *\-ed* trong *played* là hình vị phụ thuộc (*bound morpheme*\), không phải hình vị tự do, vì không thể tự đứng thành một từ độc lập với chức năng này. |
| 8 | **F – False** | Việc lặp một phần hoặc toàn bộ hình thức từ được gọi là *reduplication* \(láy/lặp). *Shortening* là quá trình rút ngắn hình thức từ. |
| 9 | **F – False** | *Function words* \(từ chức năng) chủ yếu biểu thị quan hệ ngữ pháp, chẳng hạn *the, of, and, to*. Chúng thường không có nghĩa từ vựng cụ thể như danh từ, động từ hoặc tính từ nội dung. |
| 10 | **F – False** | Hình vị biến tố (*inflectional morpheme*\) thường không thay đổi từ loại của gốc. Ví dụ: *play → played* vẫn là động từ. Việc thay đổi từ loại thường gắn với quá trình phái sinh (*derivation*\). |

**Kiến thức trọng tâm chương 3**

Phân biệt Inflection và Derivation

**Inflection**

*play → played*

Thay đổi đặc điểm ngữ pháp, chẳng hạn thì hoặc số, nhưng thường không thay đổi từ loại.

**Derivation**

*happy → happiness*

Tạo từ mới và có thể thay đổi từ loại (*adjective → noun*\).

## Chapter 4 – Syntax (Cú pháp học)

*Syntax* nghiên cứu cách các từ kết hợp thành cụm từ, mệnh đề và câu theo những nguyên tắc cấu trúc của ngôn ngữ.

### A. Multiple Choice – Câu 1 đến câu 6

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 1 | **A. Phrases, clauses, and sentences** | Cú pháp học nghiên cứu cấu trúc cụm từ, mệnh đề và câu, cũng như các quan hệ giữa những thành tố trong cấu trúc đó. |
| 2 | **A. Eat** | *Eat* là động từ từ vựng (*lexical verb*\), không phải trợ động từ. *Can, will* là trợ động từ tình thái; *doesn't* chứa trợ động từ *does* và yếu tố phủ định *not*. |
| 3 | **A. A pronoun** | Theo cách phân loại truyền thống của đề, đại từ thuộc nhóm từ chức năng (*function words*\), trong khi danh từ, động từ chính và trạng từ thường là từ nội dung (*content words*\). |
| 4 | **D. Their precise meaning** | Việc xác định phạm trù từ vựng thường dựa trên đặc điểm hình thái (*morphological properties*\) và phân bố cú pháp (*syntactic distribution*\), thay vì chỉ dựa vào nghĩa chính xác của từ. |
| 5 | **C. S–V–DO–IO** | *The girl sent a letter to her parents.* Trong cách phân tích theo ý đồ của đề: *The girl* là S, *sent* là V, *a letter* là DO, còn *to her parents* chỉ người nhận. Tuy nhiên, trong phân tích cú pháp chặt chẽ, *to her parents* là cụm giới từ chỉ người nhận, không phải tân ngữ gián tiếp dạng cụm danh từ. |
| 6 | **C theo tài liệu – Câu hỏi chưa chặt chẽ** | *Gave the* không tạo thành một thành tố cú pháp (*constituent*\) vì cắt ngang cấu trúc của cụm danh từ *the students*. Tuy nhiên, *gave the students* ở phương án B cũng không nhất thiết là một thành tố trong nhiều cách phân tích cấu trúc câu thông dụng. |

### B. True/False – Câu 7 đến câu 10

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 7 | **T – True** | Trong *She might drive down my street*, *my* là từ hạn định sở hữu (*possessive determiner*\), bổ nghĩa cho danh từ *street*. |
| 8 | **F – False** | Cụm tính từ (*adjective phrase*\) thường giữ vai trò bổ nghĩa cho danh từ hoặc làm bổ ngữ, không thường trực tiếp làm chủ ngữ hay tân ngữ như cụm danh từ. Các trường hợp danh hóa cần được phân tích riêng. |
| 9 | **T – True** | Trong *The fat man ate food*, *The fat man* là cụm danh từ (*noun phrase*\), gồm từ hạn định *the*, tính từ *fat* và danh từ trung tâm *man*. |
| 10 | **F – False** | Một câu có cấu trúc cú pháp hợp lệ không nhất thiết dễ hiểu hoặc có nghĩa rõ ràng. Tính đúng ngữ pháp và tính hợp lý về ngữ nghĩa là hai khía cạnh khác nhau. |

**Kiến thức trọng tâm chương 4**

Cần nhận diện chính xác các thành phần câu:

| Ký hiệu | Thuật ngữ | Nghĩa |
|--------|--------|--------|
| S | Subject | Chủ ngữ |
| V | Verb | Động từ |
| DO | Direct Object | Tân ngữ trực tiếp |
| IO | Indirect Object | Tân ngữ gián tiếp |
| C | Complement | Bổ ngữ |

Ví dụ minh họa cấu trúc tân ngữ kép:

*The girl sent her parents a letter.*

S = *The girl*; V = *sent*; IO = *her parents*; DO = *a letter*.

Cấu trúc này khác với *The girl sent a letter to her parents*, trong đó người nhận được biểu thị bằng cụm giới từ *to her parents*.

## Chapter 5 – Semantics (Ngữ nghĩa học)

*Semantics* nghiên cứu nghĩa được mã hóa trong từ, cụm từ và câu, bao gồm các quan hệ nghĩa giữa những đơn vị ngôn ngữ.

### A. Multiple Choice – Câu 1 đến câu 4

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 1 | **C. Inclusion** | *Apple* thuộc phạm trù rộng hơn là *fruit*. Đây là quan hệ bao hàm nghĩa (*inclusion*\), cụ thể là quan hệ thượng danh – hạ danh (*hyponymy*\). |
| 2 | **D. Polysemy** | *Head* chỉ bộ phận cơ thể và *head* chỉ người đứng đầu có sự liên hệ nghĩa mang tính ẩn dụ. Đây là hiện tượng đa nghĩa (*polysemy*\), không phải hai từ đồng âm hoàn toàn không liên quan về nghĩa. |
| 3 | **C. Ben is very full** | Trong ngữ cảnh hội thoại, *I'm stuffed* là cách nói thân mật có nghĩa là “Tôi no căng rồi”, không phải bị nhồi đầy đồ vật theo nghĩa đen. |
| 4 | **A. Connotation** | *Home* có nghĩa biểu vật (*denotation*\) là nơi cư trú, nhưng còn gợi những liên tưởng như ấm áp và an toàn. Các liên tưởng bổ sung này thuộc nghĩa liên tưởng (*connotation*\). |

### B. True/False – Câu 5 đến câu 10

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 5 | **F – False** | *Meronymy* là quan hệ bộ phận – toàn thể, như *wheel–car*. Quan hệ *apple–fruit* là quan hệ loại – phạm trù (*hyponymy*\), không phải meronymy. |
| 6 | **F – False** | Trong sự phân biệt cơ bản của đề, *semantics* nghiên cứu nghĩa của biểu thức ngôn ngữ, còn *pragmatics* chú trọng cách nghĩa được hiểu trong tình huống giao tiếp. |
| 7 | **T – True theo cách hiểu của đề** | Tiền giả định (*presupposition*\) thường vẫn được duy trì khi câu chứa nó bị phủ định. Ví dụ: *John stopped smoking* và *John didn't stop smoking* thường cùng tiền giả định rằng John từng hút thuốc. Tuy nhiên, tiền giả định có thể bị bác bỏ trong một số ngữ cảnh. |
| 8 | **T – True** | *Paraphrase* là quan hệ giữa các câu có hình thức khác nhau nhưng truyền đạt cùng một nội dung nghĩa trong cách hiểu liên quan. |
| 9 | **F – False** | *Hungry–full* là cặp trái nghĩa theo mức độ (*gradable antonyms*\). Trái nghĩa quan hệ (*relational/converse antonyms*\) gồm những cặp như *buy–sell* hoặc *parent–child*. |
| 10 | **T – True** | Theo cách trình bày trong đề, nghĩa câu có thể được phân tích thông qua nghĩa từ vựng (*lexical meaning*\) và nghĩa ngữ pháp (*grammatical meaning*\), tức cả nghĩa của từ và các quan hệ cấu trúc. |

**Kiến thức trọng tâm chương 5**

Các quan hệ nghĩa rất dễ nhầm

| Quan hệ | Ví dụ | Đặc điểm |
|--------|--------|--------|
| Synonymy | *big – large* | Gần nghĩa hoặc đồng nghĩa trong ngữ cảnh nhất định |
| Antonymy | *hot – cold* | Trái nghĩa |
| Hyponymy | *rose – flower* | Quan hệ loại – phạm trù |
| Meronymy | *finger – hand* | Quan hệ bộ phận – toàn thể |
| Polysemy | *head* \(đầu/người đứng đầu) | Một từ có các nghĩa liên hệ nhau |
| Homonymy | *bank* \(ngân hàng/bờ sông) | Các từ cùng hình thức nhưng nghĩa không liên hệ trong phân tích đồng đại thông thường |

## Chapter 6 – Pragmatics (Ngữ dụng học)

*Pragmatics* nghiên cứu việc sử dụng ngôn ngữ trong ngữ cảnh, bao gồm ý định của người nói, suy luận của người nghe, hàm ngôn và hành vi ngôn từ.

### A. Multiple Choice – Câu 1 đến câu 6

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 1 | **D. The study of contextual meaning** | Ngữ dụng học chú trọng nghĩa trong ngữ cảnh giao tiếp (*contextual meaning*\), bao gồm điều người nói muốn truyền đạt ngoài nội dung được diễn đạt trực tiếp. |
| 2 | **C. Quantity** | Theo Grice, phương châm lượng (*Maxim of Quantity*\) yêu cầu cung cấp lượng thông tin phù hợp. Nói quá nhiều thông tin không cần thiết có thể vi phạm phương châm này. |
| 3 | **B. Commissive** | *I promise to help you move tomorrow* là hành vi cam kết (*commissive speech act*\). Người nói tự ràng buộc mình vào một hành động trong tương lai. |
| 4 | **A theo tài liệu – Cần lưu ý** | Câu trả lời *He forgot to go to the bank* gợi ý rằng Juan chưa trả tiền, có thể vì quên đến ngân hàng. Đáp án A suy diễn thêm rằng Juan sẽ trả tiền khi đến ngân hàng; điều này chưa được bảo đảm từ hội thoại. |
| 5 | **D. Deixis** | *Deixis* là hiện tượng chỉ xuất trong ngôn ngữ. Các từ như *I, you, here, there, now* được giải thích thông qua ngữ cảnh người nói, thời gian hoặc địa điểm. |
| 6 | **A. Pragmatics** | Cụm quảng cáo *BABY SALE* được hiểu trong ngữ cảnh thương mại là chương trình bán giảm giá sản phẩm cho trẻ nhỏ, không phải bán trẻ em. Kiến thức ngữ cảnh giúp loại bỏ cách hiểu không phù hợp. |

### B. True/False – Câu 7 đến câu 10

| Câu | Đáp án | Giải thích |
|--------|--------|--------|
| 7 | **T – True** | Tiền giả định thực hữu (*factive presupposition*\) có thể được kích hoạt bởi những động từ như *know, realize, regret*. Ví dụ: *She regrets that she failed the test* tiền giả định rằng cô ấy đã trượt bài kiểm tra. |
| 8 | **T – True** | Hành vi ngôn từ (*speech acts*\) là những hành động giao tiếp được thực hiện bằng ngôn ngữ, như yêu cầu, hứa hẹn, xin lỗi, khẳng định hoặc cảnh báo. |
| 9 | **F – False** | Phương châm quan hệ (*Maxim of Relation*\) yêu cầu sự liên quan (*relevance*\). Yêu cầu trình bày rõ ràng, ngắn gọn và có trật tự thuộc phương châm cách thức (*Maxim of Manner*\). |
| 10 | **F – False** | Hành vi ngôn từ gián tiếp (*indirect speech acts*\) thường có thể lịch sự hơn hành vi trực tiếp, tùy ngữ cảnh. Ví dụ: *Could you open the window?* thường mềm mại hơn *Open the window*. |

**Kiến thức trọng tâm chương 6: Bốn phương châm hội thoại của Grice**

| Maxim | Nội dung |
|--------|--------|
| Quantity | Cung cấp đủ lượng thông tin cần thiết |
| Quality | Nói điều có cơ sở, tránh thông tin mà mình cho là sai |
| Relation | Đóng góp thông tin có liên quan |
| Manner | Trình bày rõ ràng, tránh mơ hồ, dài dòng và thiếu trật tự |

## III. Những câu cần đặc biệt lưu ý trước khi thi

Sau khi đối chiếu bảng đáp án trang 9 với nội dung câu hỏi, tôi nhận thấy các trường hợp sau đáng chú ý:

| Vị trí | Đáp án trong tài liệu | Nhận xét học thuật |
|--------|--------|--------|
| Chương 1 – Câu 7 | T | **Nên là F** theo phân loại cấu âm chuẩn, vì /tʃ/ và /dʒ/ là affricates, không phải fricatives. |
| Chương 2 – Câu 5 | T | **Nên là F** theo định nghĩa minimal pair chặt chẽ được sử dụng trong câu 6, vì có sự thêm /s/ thay vì thay thế một âm vị cùng vị trí. |
| Chương 3 – Câu 6 | F | **Có thể gây tranh luận** vì số hình vị của *antisocialism* phụ thuộc cách phân tích *social*. |
| Chương 4 – Câu 5 | C | Là phương án gần nhất với ý định đề, nhưng *to her parents* là cụm giới từ, không phải IO theo nhiều hệ thống phân tích cú pháp chuyên sâu. |
| Chương 4 – Câu 6 | C | Đề chưa xác định rõ lý thuyết cấu trúc thành tố; phương án B cũng có thể không phải constituent. |
| Chương 6 – Câu 4 | A | Đáp án có sẵn nhưng suy luận chưa đủ căn cứ. Hàm ngôn hợp lý nhất là Juan chưa trả tiền; việc sẽ trả tiền trong tương lai chưa chắc chắn. |

Những nhận xét này không có nghĩa phải tự ý sửa đáp án khi làm bài thi theo tài liệu của giảng viên. Bạn nên **nắm đáp án do học phần cung cấp đồng thời hiểu giới hạn học thuật của chúng**, để tránh ghi nhớ sai khái niệm.

## IV. Kết luận ôn tập

Toàn bộ 60 câu đã được giải và đối chiếu với bảng đáp án gốc. Để đạt kết quả tốt, trọng tâm cần nắm là phân loại âm theo cấu âm trong *Phonetics*, phân biệt *phoneme–allophone–minimal pair* trong *Phonology*, nhận diện hình vị và phương thức tạo từ trong *Morphology*, phân tích chức năng cú pháp trong *Syntax*, phân biệt các quan hệ nghĩa trong *Semantics*, và vận dụng phương châm hội thoại cũng như hàm ngôn trong *Pragmatics*.

**Mức độ tin cậy: Cao đối với các kiến thức cơ bản và phần lớn đáp án.** Một số câu đã được đánh dấu có độ tin cậy thấp hơn vì tài liệu có đáp án chưa phù hợp với định nghĩa học thuật thông dụng hoặc câu hỏi chưa đủ chặt chẽ để có một phương án duy nhất.

Khi ôn thi, bạn nên đặc biệt học kỹ **Chương 2, Chương 4, Chương 5 và Chương 6**, vì các chương này đòi hỏi phân biệt khái niệm và suy luận ngôn ngữ học, không chỉ ghi nhớ định nghĩa.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

với vai trò giảng viên bạn giúp tôi hoàn thành bài tập này

---

ASSISTANT

Tôi đã đọc toàn bộ tài liệu **“ĐỀ CƯƠNG ÔN THI KẾT THÚC HỌC PHẦN DỊCH NÓI 3”** bạn gửi.

Với vai trò giảng viên chuyên ngành Ngôn ngữ Anh và Dịch thuật, tôi sẽ hoàn thành cả hai bài theo nguyên tắc: **chính xác về nghĩa, bám sát nội dung gốc, đúng thuật ngữ và tự nhiên khi diễn đạt**. Tôi cũng đối chiếu với bản dịch gợi ý trong tài liệu để bảo đảm phù hợp với yêu cầu ôn thi.

## BÀI 1. ENGLISH – VIETNAMESE TRANSLATION

Chủ đề: Rose Diseases – Các bệnh thường gặp ở hoa hồng

### Bản dịch hoàn chỉnh

Hôm nay, tôi muốn nói ngắn gọn về hoa hồng và một số bệnh ảnh hưởng đến loài cây này. Có hai loại bệnh phổ biến ở hoa hồng dại, đó là bệnh gỉ sắt và bệnh đốm đen.

Bệnh đầu tiên là bệnh gỉ sắt ở hoa hồng, gây rụng lá. Diễn biến của bệnh như sau: Vào đầu mùa xuân, những đốm màu cam có thể xuất hiện ở cả hai mặt lá. Sau đó, những đốm vàng nhỏ bằng đầu kim xuất hiện ở mặt dưới của lá. Cuối cùng, những đốm màu nâu đen sẽ xuất hiện và lá có thể rụng. Nếu điều này xảy ra, bạn nên đốt bỏ những chiếc lá đó để ngăn bệnh lây lan.

Bệnh phổ biến thứ hai ở hoa hồng dại được gọi là bệnh đốm đen. Khi mắc bệnh này, mặt trên của lá sẽ xuất hiện những đốm đen, đúng như tên gọi của bệnh. Những phần khác của lá sẽ chuyển sang màu vàng. Cuối cùng, toàn bộ lá chuyển sang màu vàng và rụng xuống. Tin tốt là mọi người có thể mua các sản phẩm chuyên dụng để điều trị cả hai loại bệnh này.

### Từ vựng và cấu trúc quan trọng

| Tiếng Anh | Nghĩa tiếng Việt |
|--------|--------|
| Wild roses | Hoa hồng dại |
| Rose rust | Bệnh gỉ sắt ở hoa hồng |
| Rose black spot | Bệnh đốm đen ở hoa hồng |
| Leaf loss | Hiện tượng rụng lá |
| Orange spots | Những đốm màu cam |
| Pinhead-sized yellow spots | Những đốm vàng nhỏ bằng đầu kim |
| Underside of the leaves | Mặt dưới của lá |
| Blackish brown spots | Những đốm màu nâu đen |
| Fall off | Rụng |
| Prevent the disease from spreading | Ngăn bệnh lây lan |
| Treat both of these problems | Điều trị cả hai vấn đề này |

**Lưu ý khi dịch:** Cụm *may fall off* thể hiện khả năng xảy ra nên phải dịch là “có thể rụng”, không phải “sẽ rụng”. Ngoài ra, *treat* có nghĩa là “điều trị/xử lý”, không mặc nhiên bao gồm “phòng bệnh”.

---

## BÀI 2. VIETNAMESE – ENGLISH TRANSLATION

Chủ đề: Depression – Bệnh trầm cảm

### Bản dịch hoàn chỉnh

Today, we are going to talk a little about depression. Depression is an illness that affects many people in the United States. In fact, about thirty million Americans have experienced major depression at some point in their lives.

The problem is that not everyone with depression receives treatment. Recent reports indicate that only about half of Americans with depression are receiving treatment. In the past, women were more likely than men to receive treatment. Today, the number of men receiving treatment is nearly equal to the number of women, although more women still seek treatment than men.

Whether someone receives treatment is related less to gender than to age. Depression is more common among younger people, particularly those aged 18 to 40. Meanwhile, people over 60 tend to experience depression less often than younger people.

### Từ vựng và cấu trúc quan trọng

| Tiếng Việt | Tiếng Anh |
|--------|--------|
| Bệnh trầm cảm | Depression |
| Căn bệnh ảnh hưởng đến nhiều người | An illness that affects many people |
| Hoa Kỳ | The United States |
| Khoảng ba mươi triệu người Mỹ | About thirty million Americans |
| Trầm cảm nghiêm trọng | Major depression (theo thuật ngữ của tài liệu) |
| Vào một thời điểm nào đó trong cuộc đời | At some point in their lives |
| Được điều trị | Receive treatment |
| Các báo cáo gần đây cho biết | Recent reports indicate that |
| Chỉ khoảng một nửa | Only about half |
| Gần như tương đương | Nearly equal |
| Chủ động tìm kiếm điều trị | Seek treatment |
| Giới tính | Gender |
| Độ tuổi | Age |
| Phổ biến hơn ở người trẻ | More common among younger people |
| Có xu hướng | Tend to |

### Những cấu trúc cần ghi nhớ

**1. Have experienced – Thì hiện tại hoàn thành**

*About thirty million Americans have experienced major depression at some point in their lives.*

Dùng thì hiện tại hoàn thành để diễn đạt trải nghiệm đã xảy ra vào một thời điểm không xác định trong cuộc đời tính đến hiện tại.

**2. Be more likely than – Có khả năng/xu hướng cao hơn**

*In the past, women were more likely than men to receive treatment.*

Cấu trúc này thể hiện sự so sánh về xu hướng, phù hợp với ý “trước đây, phụ nữ thường được điều trị nhiều hơn nam giới”.

**3. Not so much ... as ... – Không hẳn là ... mà chủ yếu là ...**

*Who receives treatment is not so much related to gender as to age.*

Đây là cấu trúc được sử dụng trong bản dịch gợi ý của đề, nhấn mạnh rằng độ tuổi có liên quan nhiều hơn giới tính đến việc được điều trị.

**4. Tend to + V – Có xu hướng**

*People over 60 tend to experience depression less often than younger people.*

*Tend to* thể hiện một xu hướng chung, không khẳng định điều đó đúng trong tất cả các trường hợp.

---

## III. Đánh giá và lưu ý khi thi Dịch nói 3

Hai bản dịch trên giữ nguyên thông tin, các mốc số liệu và mức độ chắc chắn của văn bản gốc. Đặc biệt, bài 2 được dịch theo đúng nội dung của đề, không xem các số liệu về trầm cảm là thống kê đã được kiểm chứng tại thời điểm hiện nay.

Đối với học phần **Dịch nói 3**, bạn cần ưu tiên ba điểm:

1. **Accuracy (Tính chính xác):** Không thay đổi các thông tin như *thirty million*, *half*, *18 to 40*, *over 60*, *may* và *nearly*.
2. **Fluency (Độ lưu loát):** Diễn đạt thành những câu hoàn chỉnh, dễ nói và dễ nghe, tránh dịch từng từ một cách máy móc.
3. **Terminology (Thuật ngữ):** Ghi nhớ những cụm trọng tâm như *rose rust, black spot, major depression, receive treatment* và *seek treatment*.

**Kết luận:** Cả hai bài đã được dịch hoàn chỉnh, có đối chiếu với bản dịch gợi ý của tài liệu. Đây là hai bản bạn có thể sử dụng để học, luyện dịch nói và chuẩn bị cho kỳ thi kết thúc học phần.

---

