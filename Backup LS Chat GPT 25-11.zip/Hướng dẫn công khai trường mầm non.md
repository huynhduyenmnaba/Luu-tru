USER

với vai trò hiệu trưởng trường mầm non và các văn bản đính kèm, bạn hãy giúp tôi giải quyết các nội dung công khai theo văn bản hướng dẫn. Cụ thể các loại danh mục minh chứng và các bộ phận phối hợp để thực hiện hoàn thành công việc

---

ASSISTANT

Tôi sẽ đối chiếu công văn hướng dẫn, mẫu báo cáo thường niên và mẫu công khai trên website để lập danh mục minh chứng cụ thể, xác định bộ phận chủ trì – phối hợp, đồng thời sắp xếp tiến độ thực hiện và kiểm tra trước khi công khai.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 HƯỚNG DẪN TỔ CHỨC THỰC HIỆN CÔNG KHAI TRONG TRƯỜNG MẦM NON NĂM HỌC 2026–2027

**Danh mục minh chứng – Phân công bộ phận chủ trì, phối hợp – Tiến độ và hồ sơ hoàn thành**

Sau khi nghiên cứu các văn bản đính kèm, trên góc độ quản lý của Hiệu trưởng trường mầm non, tôi đề xuất nhà trường triển khai theo nguyên tắc: **Mỗi nội dung công khai phải có minh chứng xác thực, một bộ phận chịu trách nhiệm chính, các bộ phận phối hợp và một người kiểm tra trước khi công bố.**

## I. Căn cứ và xác định nhiệm vụ

Các văn bản làm cơ sở triển khai gồm:

1. Thông tư số 09/2024/TT-BGDĐT ngày 03/6/2024 của Bộ Giáo dục và Đào tạo.
2. Công văn số 3965/SGDĐT-QLCL ngày 08/10/2026 của Sở GDĐT Đồng Tháp.
3. Công văn số 6051/VP-VX ngày 12/10/2026 của Văn phòng HĐND và UBND phường An Bình.
4. Phụ lục I – Mẫu báo cáo thường niên dành cho cơ sở giáo dục mầm non kèm hướng dẫn của Sở.

Đối chiếu Điều 4, 5, 6, 7 Thông tư 09, nhà trường phải thực hiện đầy đủ 4 nhóm nội dung công khai chính và báo cáo thường niên theo quy định. [Thông tư số 09/2024/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Quy định về công khai trong hoạt động của các cơ sở giáo dục thuộc hệ thống giáo dục quốc dân](<https://vanban.chinhphu.vn/?classid=0&docid=210411&pageid=27160>); [Thông tư 09/2024/tt\-bgdđt quy định về công khai trong hoạt động của các cơ sở giáo dục thuộc hệ thống giáo dục quốc dân do bộ trưởng bộ giáo dục và đào tạo ban hành](<https://hethongphapluat.com/thong-tu-09-2024-tt-bgddt-quy-dinh-ve-cong-khai-trong-hoat-dong-cua-cac-co-so-giao-duc-thuoc-he-thong-giao-duc-quoc-dan-do-bo-truong-bo-giao-duc-va-dao-tao-ban-hanh.html>); [09/2024/TT\-BGDĐT](<https://filethcs.hcm.edu.vn/data/doc/2024/thcsphantayho/2024_8/7/tt-092024tt-bgddt-ve-cong-khai-trong-hoat-dong-csgd_78202422.pdf>)

CẤU TRÚC NHIỆM VỤ CẦN QUẢN LÝ

# 04

Nhóm nội dung công khai

Điều 4, 5, 6, 7

# 07

Phần báo cáo thường niên

Theo Phụ lục I của Sở

# 01

Tổ thực hiện công khai

Hiệu trưởng làm Tổ trưởng

# 05 năm

Duy trì công khai trên website

Thời gian tối thiểu

Cần phân biệt ba loại hồ sơ để tránh bỏ sót nhiệm vụ:

- **Hồ sơ công khai:** Những thông tin, bảng tổng hợp, văn bản được phê duyệt để đăng trên website hoặc niêm yết.
- **Hồ sơ minh chứng:** Quyết định, kế hoạch, sổ sách, biên bản, báo cáo, số liệu gốc dùng để chứng minh nội dung đã công khai là chính xác. Không phải tất cả minh chứng đều được đăng công khai.
- **Hồ sơ chứng minh đã thực hiện công khai:** Đường dẫn website, bản PDF đã ký, nhật ký đăng tải, biên bản niêm yết, hình ảnh và biên bản phổ biến tại cuộc họp cha mẹ trẻ.

Điểm quan trọng là không chỉ hoàn thành một bản báo cáo thường niên mà phải duy trì công khai cả các kế hoạch giáo dục và thực đơn theo tháng, tuần đúng thời gian quy định.

## II. Danh mục 29 nhóm minh chứng và phân công thực hiện

Dưới đây là **29 nhóm hồ sơ, minh chứng đề xuất để quản lý công việc**, được hệ thống hóa theo 4 điều của Thông tư 09. Đây là cách tổ chức hồ sơ nội bộ, không phải 29 biểu mẫu bắt buộc phải lập mới.

### 1. Nhóm A – Công khai thông tin chung về nhà trường (Điều 4)

Đối chiếu Phần I, trang 1–2 của mẫu báo cáo thường niên.

| Mã | Nội dung và danh mục minh chứng cần chuẩn bị | Chủ trì | Phối hợp |
|--------|--------|--------|--------|
| CK01 | **Thông tin pháp lý:** Quyết định thành lập, sáp nhập, đổi tên (nếu có); văn bản cho phép hoạt động; thông tin trụ sở, điểm trường, điện thoại, email, website, loại hình và đơn vị quản lý | Văn thư | Hiệu trưởng, BGH |
| CK02 | **Lịch sử, tầm nhìn, sứ mạng:** Chiến lược phát triển trường, mục tiêu giáo dục, tài liệu giới thiệu quá trình thành lập và phát triển | Hiệu trưởng | Hội đồng trường, BGH |
| CK03 | **Hội đồng trường và cơ cấu tổ chức:** Quyết định công nhận Hội đồng trường, Chủ tịch và danh sách thành viên; sơ đồ tổ chức; quy chế tổ chức, hoạt động | Hiệu trưởng | Văn thư, Hội đồng trường |
| CK04 | **Thông tin lãnh đạo:** Quyết định bổ nhiệm Hiệu trưởng, Phó Hiệu trưởng; phân công nhiệm vụ; thông tin liên hệ công vụ và trách nhiệm của lãnh đạo | Văn thư | Hiệu trưởng, PHT |
| CK05 | **Quy định, quy chế nhà trường:** Quy chế dân chủ; quy chế làm việc; quản lý hành chính, nhân sự, tài chính; quy chế chi tiêu nội bộ; quản lý tài sản; nghị quyết Hội đồng trường | Hiệu trưởng | Kế toán, văn thư, các tổ |
| CK06 | **Tuyển dụng và phát triển đội ngũ:** Kế hoạch, thông báo tuyển dụng; chính sách thu hút, đào tạo, bồi dưỡng và phát triển đội ngũ (nếu có) | Bộ phận phụ trách nhân sự, văn thư | Hiệu trưởng, PHT |

**Sản phẩm cần công khai:** Bộ thông tin chung về nhà trường kèm các văn bản, quy định thuộc diện công khai đã được ban hành hợp lệ.

### 2. Nhóm B – Công khai thu, chi tài chính (Điều 5)

Đối chiếu Phần VI, trang 4–6 của mẫu báo cáo thường niên.

| Mã | Nội dung và danh mục minh chứng cần chuẩn bị | Chủ trì | Phối hợp |
|--------|--------|--------|--------|
| TC01 | **Nguồn thu:** Tổng hợp ngân sách nhà nước; học phí; các khoản thu khác; tài trợ; nguồn thu hợp pháp khác, phân theo nguồn và loại hoạt động | Kế toán | Hiệu trưởng |
| TC02 | **Cơ cấu chi:** Tổng hợp chi lương, phụ cấp, thu nhập; chi cơ sở vật chất, dịch vụ; hỗ trợ trẻ; các khoản chi khác | Kế toán | Văn thư, phụ trách tài sản |
| TC03 | **Các khoản thu đối với trẻ:** Văn bản quy định mức thu; kế hoạch thu; bảng mức thu đang áp dụng; mức dự kiến năm học tiếp theo; dịch vụ hỗ trợ giáo dục (nếu có) | Kế toán | Hiệu trưởng, PHT nuôi dưỡng |
| TC04 | **Chế độ, chính sách hỗ trợ:** Quy định hỗ trợ, miễn giảm; quyết định phê duyệt; bảng tổng hợp số trẻ và kinh phí được hưởng; chứng từ thực hiện | Kế toán | Giáo viên, văn thư |
| TC05 | **Các quỹ theo quy định:** Bảng tổng hợp số dư đầu năm, phát sinh tăng, giảm và số dư cuối năm của từng quỹ (nếu có) | Kế toán | Hiệu trưởng |
| TC06 | **Ngân sách, quyết toán, tài trợ:** Quyết định giao, điều chỉnh dự toán; báo cáo thực hiện dự toán; quyết toán được phê duyệt; hồ sơ tài trợ, viện trợ thuộc diện công khai | Kế toán | Hiệu trưởng, phụ trách tài sản |

**Sản phẩm cần công khai:** Bảng công khai tài chính có đầy đủ các khoản thu, chi, chính sách, mức thu và số dư quỹ theo Điều 5; kèm các văn bản tài chính phải công khai theo quy định liên quan.

**Điểm kiểm soát của Hiệu trưởng**

Kế toán chịu trách nhiệm cung cấp và đối chiếu số liệu, nhưng Hiệu trưởng phải kiểm tra sự thống nhất giữa báo cáo công khai, sổ kế toán, chứng từ, báo cáo quyết toán và các văn bản phê duyệt. Không công khai khoản thu chưa có căn cứ hợp lệ như một khoản đã được phê duyệt.

### 3. Nhóm C – Điều kiện bảo đảm chất lượng giáo dục (Điều 6)

Đối chiếu Phần II, III, IV và V.C, trang 2–4 của mẫu báo cáo thường niên.

| Mã | Nội dung và danh mục minh chứng cần chuẩn bị | Chủ trì | Phối hợp |
|--------|--------|--------|--------|
| CL01 | **Số lượng và trình độ đội ngũ:** Bảng tổng hợp CBQL, giáo viên, nhân viên theo vị trí việc làm, trình độ; hồ sơ nhân sự làm căn cứ đối chiếu | Văn thư hoặc phụ trách nhân sự | PHT, tổ trưởng, kế toán |
| CL02 | **Chuẩn nghề nghiệp, bồi dưỡng:** Kết quả đánh giá chuẩn nghề nghiệp CBQL, giáo viên; bảng tỷ lệ đạt chuẩn; kết quả hoàn thành bồi dưỡng hằng năm | PHT chuyên môn | Tổ trưởng chuyên môn, văn thư |
| CL03 | **Diện tích đất và điểm trường:** Hồ sơ đất, sơ đồ, bản vẽ; bảng diện tích từng điểm; diện tích bình quân/trẻ và kết quả đối chiếu yêu cầu tối thiểu | Người phụ trách CSVC | Kế toán, văn thư, PHT |
| CL04 | **Hệ thống phòng chức năng:** Bảng kiểm kê phòng học, phòng hành chính, phòng phục vụ chăm sóc, nuôi dưỡng, phòng ăn, phòng bếp và các phòng phụ trợ | Người phụ trách CSVC | PHT, kế toán, các điểm trường |
| CL05 | **Hạ tầng kỹ thuật:** Hồ sơ điện, nước sạch, thoát nước, nhà vệ sinh, phòng cháy chữa cháy, công nghệ thông tin, internet | Người phụ trách CSVC | Y tế, bảo vệ, kế toán |
| CL06 | **Thiết bị, đồ dùng, đồ chơi:** Sổ tài sản, biên bản kiểm kê; bảng thiết bị từng lớp; đồ chơi trong lớp, ngoài trời; bảng đối chiếu danh mục và yêu cầu tối thiểu | Người quản lý tài sản | Giáo viên, tổ trưởng, kế toán |
| CL07 | **Kiểm định và chuẩn quốc gia:** Báo cáo tự đánh giá; kết quả đánh giá ngoài; quyết định công nhận; kế hoạch và kết quả cải tiến chất lượng hằng năm, sau đánh giá ngoài | Hiệu trưởng, bộ phận tự đánh giá | PHT, các nhóm phụ trách tiêu chuẩn |
| CL08 | **Chương trình nước ngoài/tích hợp (nếu có):** Hồ sơ chương trình, quốc gia cung cấp, đối tác, cơ quan công nhận chất lượng, ngôn ngữ giảng dạy | Hiệu trưởng | PHT, văn thư, kế toán |

**Sản phẩm cần công khai:** Bảng thông tin đội ngũ, bảng điều kiện cơ sở vật chất có đối sánh yêu cầu tối thiểu, kết quả tự đánh giá và kiểm định, công nhận chuẩn quốc gia, thông tin chương trình đặc thù nếu có.

Đặc biệt, Điều 6 yêu cầu cả số lượng đồ chơi ngoài trời và điều kiện phục vụ chăm sóc, giáo dục. Nhà trường cần rà soát nội dung này dù không có dòng tách riêng trong bảng cơ sở vật chất của mẫu báo cáo thường niên. [Thông tư 09/2024/TT\-BGDĐT quy định về công khai trong hoạt động của các cơ sở giáo dục thuộc hệ thống giáo dục quốc dân do Bộ trưởng Bộ Giáo dục và Đào tạo ban hành](<https://thuvienphapluat.vn/van-ban/Giao-duc/Circular-09-2024-TT-BGDDT-on-prescribing-public-disclosure-of-operations-national-education-system-613840.aspx>); [Thông tư 09/2024/TT\-BGDĐT quy định công khai với Cơ sở Giáo dục thuộc hệ thống giáo dục quốc dân](<https://vqa.moet.gov.vn/vi/laws/detail/Thong-tu-09-2024-TT-BGDDT-quy-dinh-cong-khai-voi-Co-so-Giao-duc-thuoc-he-thong-giao-duc-quoc-dan-38/>)

### 4. Nhóm D – Kế hoạch và kết quả hoạt động giáo dục mầm non (Điều 7)

Đối chiếu Phần V, trang 3–4 của mẫu báo cáo thường niên.

| Mã | Nội dung và danh mục minh chứng cần chuẩn bị | Chủ trì | Phối hợp |
|--------|--------|--------|--------|
| GD01 | **Tuyển sinh:** Kế hoạch tuyển sinh; chỉ tiêu, đối tượng, phương thức, thời gian; báo cáo kết quả tuyển sinh | PHT chuyên môn | Văn thư, giáo viên |
| GD02 | **Kế hoạch nuôi dưỡng, chăm sóc, giáo dục:** Kế hoạch năm học; kế hoạch chăm sóc, nuôi dưỡng, giáo dục toàn trường; kế hoạch giáo dục tháng | PHT theo lĩnh vực được giao | Tổ trưởng chuyên môn, y tế |
| GD03 | **Kế hoạch giáo dục tuần, ngày:** Kế hoạch theo độ tuổi, nhóm lớp; bảng tổng hợp lịch giáo dục tuần/ngày để công khai đúng hạn | PHT chuyên môn | Tổ trưởng, giáo viên |
| GD04 | **Thực đơn và dịch vụ:** Thực đơn ngày/tuần, bảng tính khẩu phần, kế hoạch tổ chức bán trú; danh mục dịch vụ giáo dục mầm non (nếu có) | PHT phụ trách nuôi dưỡng | Y tế, bếp ăn, kế toán |
| GD05 | **Quy mô và kết quả nuôi dưỡng, chăm sóc, giáo dục:** Sổ theo dõi trẻ; bảng số trẻ/nhóm lớp; lớp ghép; trẻ học 2 buổi/ngày; trẻ ăn bán trú; số liệu năm học trước | PHT chuyên môn | Tổ trưởng, giáo viên, văn thư |
| GD06 | **Sức khỏe và sự phát triển trẻ:** Bảng tổng hợp số trẻ được cân đo, theo dõi biểu đồ tăng trưởng, khám sức khỏe định kỳ; kết quả đánh giá sự phát triển trẻ | Y tế và PHT chuyên môn theo lĩnh vực | Giáo viên, tổ trưởng |
| GD07 | **Phổ cập và giáo dục hòa nhập:** Báo cáo kết quả phổ cập GDMN cho trẻ 5 tuổi; tổng hợp số trẻ khuyết tật; hồ sơ theo dõi chuyên môn làm căn cứ | PHT phụ trách phổ cập | Giáo viên, văn thư, y tế |
| GD08 | **Phối hợp gia đình và xã hội:** Quy chế phối hợp; kế hoạch phối hợp giáo dục; hồ sơ tổ chức họp cha mẹ trẻ; hoạt động tuyên truyền, phối hợp | PHT chuyên môn | Giáo viên, Ban đại diện cha mẹ trẻ |
| GD09 | **Trẻ học chương trình nước ngoài/tích hợp:** Bảng tổng hợp số trẻ Việt Nam, trẻ nước ngoài đang học chương trình (nếu có) | PHT chuyên môn | Văn thư, giáo viên |

**Sản phẩm cần công khai:** Kế hoạch tuyển sinh, kế hoạch nuôi dưỡng – chăm sóc – giáo dục, quy chế phối hợp với gia đình, thực đơn, dịch vụ giáo dục và các kết quả thực hiện năm học trước theo quy định.

Đối với GD06 và GD07, nhà trường nên sử dụng **số liệu tổng hợp, không công khai hồ sơ sức khỏe cá nhân, danh tính trẻ khuyết tật hoặc thông tin nhạy cảm của trẻ**.

---

## III. Phân công trách nhiệm các bộ phận trong trường

Từ 29 nhóm minh chứng trên, tôi đề xuất Hiệu trưởng thành lập **Tổ thực hiện công khai năm học 2026–2027** với cơ cấu sau:

| Thành phần | Vai trò đề xuất | Trách nhiệm và sản phẩm bàn giao |
|--------|--------|--------|
| **Hiệu trưởng** | Tổ trưởng | Ban hành quyết định, quy định, kế hoạch công khai; phê duyệt nội dung; ký báo cáo; chịu trách nhiệm giải trình |
| **PHT chuyên môn** | Tổ phó | Chủ trì nội dung đội ngũ, kế hoạch giáo dục, tuyển sinh, kết quả giáo dục, phổ cập, kiểm định theo phân công |
| **PHT phụ trách nuôi dưỡng** | Tổ phó hoặc thành viên | Chủ trì công khai thực đơn, bán trú, dinh dưỡng, sức khỏe, an toàn trong phạm vi phụ trách |
| **Văn thư** | Thư ký/đầu mối tổng hợp | Lập danh mục hồ sơ, tiếp nhận minh chứng, kiểm tra thể thức, quản lý phiên bản và lưu trữ |
| **Kế toán** | Thành viên tài chính | Chuẩn bị toàn bộ bảng công khai thu chi, các khoản thu, hỗ trợ, quỹ, quyết toán; phối hợp tài sản |
| **Người phụ trách cơ sở vật chất** | Thành viên | Kiểm kê, đối sánh diện tích, phòng học, thiết bị, tài sản và điều kiện kỹ thuật |
| **Tổ trưởng chuyên môn** | Thành viên | Tổng hợp kế hoạch, dữ liệu lớp, kết quả giáo dục; kiểm tra hồ sơ giáo viên |
| **Giáo viên các lớp** | Bộ phận cung cấp minh chứng | Cung cấp số liệu trẻ, kế hoạch giáo dục, kết quả đánh giá, phối hợp cha mẹ trẻ |
| **Nhân viên y tế, bộ phận bếp** | Bộ phận phối hợp | Cung cấp dữ liệu sức khỏe tổng hợp, dinh dưỡng, thực đơn, hồ sơ bán trú |
| **Người quản trị website** | Thành viên kỹ thuật | Đăng file đã duyệt, kiểm tra đường dẫn, thời hạn hiển thị, lưu minh chứng đăng tải |
| **Ban Thanh tra nhân dân** | Giám sát theo chức năng | Theo dõi tính minh bạch, phản ánh thiếu sót và kiến nghị khắc phục |

Các vị trí có thể kiêm nhiệm tùy thực tế nhân sự; không nhất thiết trường phải có riêng hai Phó Hiệu trưởng hoặc một bộ phận công nghệ thông tin.

**Đề xuất quản lý:** Chỉ định một thành viên làm đầu mối công khai duy nhất, thường là văn thư hoặc một Phó Hiệu trưởng. Mọi tài liệu chuyển đến website phải đi qua đầu mối này sau khi được người có thẩm quyền phê duyệt, tránh mỗi tổ tự đăng những số liệu chưa thống nhất.

## IV. Phân công xây dựng báo cáo thường niên theo Phụ lục I

Mẫu Sở GDĐT ban hành gồm 7 phần chính, phần đánh giá chung, định hướng năm tiếp theo và các phụ lục kèm theo. Nhà trường nên tận dụng 29 nhóm minh chứng ở Mục II để biên soạn, không yêu cầu giáo viên làm lại hồ sơ đã có.

| Phần báo cáo | Người chịu trách nhiệm biên soạn | Bộ phận đối chiếu, cung cấp |
|--------|--------|--------|
| I. Thông tin chung | Văn thư, Hiệu trưởng | BGH, Hội đồng trường |
| II. Đội ngũ nhà giáo, CBQL và nhân viên | PHT chuyên môn hoặc phụ trách nhân sự | Văn thư, tổ trưởng, kế toán |
| III. Cơ sở vật chất | Người phụ trách CSVC | Kế toán, PHT, các điểm trường |
| IV. Bảo đảm chất lượng, chuẩn quốc gia | Hiệu trưởng hoặc phụ trách tự đánh giá | PHT, các nhóm phụ trách tiêu chuẩn |
| V. Kết quả hoạt động giáo dục | PHT chuyên môn | Tổ trưởng, giáo viên, y tế, phụ trách phổ cập |
| VI. Kết quả tài chính | Kế toán | Hiệu trưởng, văn thư |
| VII. Kết quả nhiệm vụ trọng tâm khác | BGH tổng hợp theo lĩnh vực | CNTT, y tế, tổ chuyên môn, thi đua, kiểm tra nội bộ |
| Đánh giá chung và định hướng năm sau | Hiệu trưởng | Toàn bộ Tổ công khai |

### Sáu phụ lục cần rà soát khi hoàn thành báo cáo

Theo trang 7 của mẫu báo cáo đính kèm:

| STT | Tài liệu, phụ lục | Bộ phận chuẩn bị |
|--------|--------|--------|
| 1 | Bảng số liệu đội ngũ và cơ sở vật chất đối sánh năm trước | Văn thư, PHT, phụ trách CSVC |
| 2 | Bảng kết quả hoạt động giáo dục | PHT chuyên môn |
| 3 | Bảng công khai tài chính theo Điều 5 | Kế toán |
| 4 | Biểu công khai ngân sách hiện hành (nếu thuộc đối tượng) | Kế toán |
| 5 | Quyết toán/báo cáo tài chính và tài liệu chứng minh liên quan | Kế toán |
| 6 | Các tài liệu khác phục vụ công khai | Văn thư tổng hợp từ các bộ phận |

Báo cáo phải lấy mốc dữ liệu ngày 31/12 của năm báo cáo, đối sánh năm trước theo các chỉ tiêu trong mẫu; ký, đóng dấu và đăng file PDF. Nếu chưa có số liệu quyết toán chính thức thì cập nhật theo thời điểm quyết toán của cơ quan có thẩm quyền.

## V. Tiến độ thực hiện và các mốc cần đặc biệt chú ý

**Việc cần ưu tiên tại thời điểm 23/10/2026**

Căn cứ thời hạn ghi tại Công văn 3965 và Thông tư 09.

---

23/10

**Hoàn tất công khai kế hoạch tuần tới và dự kiến thực đơn**

Đối với tuần 26/10–01/11/2026, phải đăng trước thứ Bảy 24/10. Nên hoàn tất ngay trong ngày 23/10 nếu chưa thực hiện.

---

23/10

**Hoàn tất công khai kế hoạch giáo dục tháng 11/2026**

Quy định công khai trước ngày 25 của tháng trước. Ngày 23/10 là ngày làm việc thuận tiện để hoàn thành.

---

Ngay

**Kiểm tra tình trạng báo cáo công khai năm học 2025–2026**

Công văn 3965 yêu cầu các trường thuộc UBND xã, phường gửi báo cáo để UBND tổng hợp. Hạn UBND báo cáo về Sở là 20/10/2026, đã qua; cần kiểm tra với UBND phường và bổ sung ngay nếu trường còn thiếu.

### Các thời hạn thực hiện thường xuyên

| Công việc | Mốc thời gian |
|--------|--------|
| Nội dung công khai theo Điều 4–7 | Trước 30/6 hằng năm |
| Cập nhật nội dung thay đổi hoặc mới có thông tin chính thức | Chậm nhất sau 10 ngày làm việc |
| Kế hoạch giáo dục tháng | Trước ngày 25 của tháng trước |
| Kế hoạch tuần, ngày; dự kiến thực đơn | Trước ngày thứ Bảy của tuần trước |
| Báo cáo thường niên năm 2026 | Số liệu đến 31/12/2026; công bố trước 30/6/2027 |
| Phổ biến nội dung công khai với cha mẹ trẻ | Tháng đầu tiên của năm học mới |
| Tự kiểm tra việc thực hiện Thông tư 09 | Ít nhất 01 lần/năm, lưu biên bản |
| Hiển thị công khai trên website | Tối thiểu 05 năm |
| Niêm yết nếu cơ sở mầm non chưa có website | Tối thiểu 90 ngày liên tục; sau đó lưu tài liệu ít nhất 05 năm |

Các mốc này căn cứ Điều 14, 15 Thông tư 09 và hướng dẫn của Sở GDĐT Đồng Tháp. [Thông tư 09/2024/TT\-BGDĐT quy định về công khai trong hoạt động của các cơ sở giáo dục thuộc hệ thống giáo dục quốc dân do Bộ trưởng Bộ Giáo dục và Đào tạo ban hành mới nhất](<https://thuvienphapluat.vn/van-ban/Giao-duc/Thong-tu-09-2024-TT-BGDDT-cong-khai-trong-hoat-dong-co-so-giao-duc-quoc-dan-581008.aspx?anchor=dieu_4>); [14

\*\*Điều 17\. Điều khoản thi hành\*\*

1\. Thông tư](<https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/6/09-bgd.pdf>)

## VI. Quy trình phối hợp 5 bước để hoàn thành

**Bước 1. Hiệu trưởng giao nhiệm vụ**

Ban hành quyết định thành lập Tổ công khai; quy định thực hiện công khai của trường; kế hoạch năm học và bảng giao 29 mã minh chứng. Xác định rõ người phụ trách từng mã, người duyệt và ngày hoàn thành.

---

**Bước 2. Các bộ phận thu thập và tổng hợp minh chứng**

Kế toán, văn thư, PHT, tổ trưởng, y tế, phụ trách tài sản nộp dữ liệu và tài liệu có nguồn gốc rõ ràng. Tài liệu gốc được lưu nội bộ; mỗi người phụ trách chuẩn bị bản tổng hợp phù hợp để công khai.

---

**Bước 3. Đối chiếu và xác nhận số liệu**

Đầu mối công khai kiểm tra đủ nội dung. PHT đối chiếu số liệu trẻ, nhóm lớp; kế toán đối chiếu tài chính; phụ trách nhân sự đối chiếu đội ngũ; phụ trách CSVC đối chiếu tài sản. Hiệu trưởng xem xét trước khi ban hành.

---

**Bước 4. Công bố đúng hình thức và thời hạn**

Quản trị website đăng tài liệu đã ký, đúng thư mục, đặt liên kết dễ truy cập; lưu ngày đăng và đường dẫn. Trường hợp thuộc diện niêm yết, văn thư lập biên bản và lưu bằng chứng niêm yết.

---

**Bước 5. Tự kiểm tra, lưu trữ và báo cáo**

Kiểm tra các đường dẫn công khai, thời gian, tính đầy đủ, độ chính xác và khả năng truy cập; lập biên bản ít nhất một lần/năm. Báo cáo kết quả, những nội dung chưa hoàn thành và biện pháp khắc phục.

## VII. Đề xuất tổ chức mục công khai trên website

Theo Công văn 3965, website cần có một mục công khai riêng và bảng theo mẫu đính kèm. Có thể tổ chức hồ sơ theo các nhóm sau để dễ quản lý và truy cập:

**CÔNG KHAI THEO THÔNG TƯ 09/2024**

01

Thông tin chung về nhà trường

Điều 4

02

Công khai tài chính

Điều 5

03

Đội ngũ, cơ sở vật chất, chất lượng

Điều 6

04

Kế hoạch và kết quả giáo dục mầm non

Điều 7

05

Báo cáo thường niên

Phụ lục I

06

Kế hoạch giáo dục tháng, tuần, ngày

Cập nhật định kỳ

07

Thực đơn nuôi dưỡng trẻ

Cập nhật định kỳ

Đây là cấu trúc gợi ý theo Thông tư 09. Tôi chưa đối chiếu được các cột cụ thể bên trong tệp `7. mau_web_mamnon.xlsx`, vì vậy khi triển khai cần giữ đúng mẫu bảng website do Sở gửi kèm nếu mẫu có quy định chi tiết khác.

Nhà trường nên quản lý thêm một bảng nội bộ gồm các cột: **Mã minh chứng – Nội dung – Người cung cấp – Người kiểm tra – Thời hạn – Tên file đã ký – Ngày đăng – Đường dẫn – Tình trạng – Ghi chú**. Bảng nội bộ này không cần công khai trên website.

## VIII. Những rủi ro Hiệu trưởng cần kiểm soát

**Thiếu hồ sơ chứng minh đã công khai**

Có file báo cáo nhưng không có đường dẫn, ngày đăng, biên bản niêm yết hoặc bằng chứng phổ biến. Cần lưu đủ hồ sơ thực hiện, không chỉ lưu bản báo cáo.

**Số liệu giữa các bộ phận không khớp**

Đội ngũ, tổng số trẻ, số nhóm lớp, trẻ bán trú, diện tích và số liệu tài chính có thể khác nhau giữa báo cáo chuyên môn, kế toán, cơ sở dữ liệu và báo cáo thường niên. Cần một đợt đối chiếu trước khi ký.

**Công khai quá mức thông tin cá nhân**

Không đăng danh sách trẻ kèm tình trạng sức khỏe, bệnh lý, khuyết tật, hồ sơ hưởng chính sách hoặc tài liệu nhân sự chứa dữ liệu riêng tư khi không có căn cứ pháp luật.

**Đăng tải không đúng hiệu lực, hình thức**

Dùng dự thảo chưa ký, thiếu dấu với báo cáo yêu cầu đóng dấu, gỡ bỏ tài liệu cũ, không cập nhật khi thay đổi hoặc chỉ đăng một báo cáo thường niên mà bỏ qua nội dung công khai định kỳ.

## IX. Kết luận và đề xuất của Hiệu trưởng

Để triển khai hiệu quả trong năm học 2026–2027, tôi đề xuất nhà trường lấy **29 nhóm minh chứng làm bảng giao việc**, dùng **7 phần của Phụ lục I làm khung tổng hợp báo cáo**, và quản lý kết quả công khai bằng đường dẫn website, tài liệu đã ký cùng hồ sơ kiểm tra.

Ưu tiên trước mắt là hoàn thành các nội dung công khai định kỳ của cuối tháng 10/2026, kiểm tra tình trạng báo cáo năm học 2025–2026 với UBND phường, sau đó rà soát những nhóm minh chứng còn thiếu và hoàn thiện hồ sơ tổ chức thực hiện của trường.

**Nguyên tắc điều hành xuyên suốt: Mỗi nội dung một người chủ trì; mỗi số liệu có nguồn kiểm chứng; mỗi tài liệu công khai có thời điểm, địa chỉ truy cập và hồ sơ lưu.**

Như vậy, Hiệu trưởng vừa kiểm soát được tiến độ và trách nhiệm của từng bộ phận, vừa hạn chế việc tạo thêm hồ sơ hành chính không cần thiết cho giáo viên, bảo đảm công khai đúng quy định và phục vụ thực chất công tác quản trị nhà trường.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

ASSISTANT

## II. Danh mục 29 nhóm minh chứng và phân công thực hiện

Dưới đây là **29 nhóm hồ sơ, minh chứng đề xuất để quản lý công việc**, được hệ thống hóa theo 4 điều của Thông tư 09. Đây là cách tổ chức hồ sơ nội bộ, không phải 29 biểu mẫu bắt buộc phải lập mới.

### 1. Nhóm A – Công khai thông tin chung về nhà trường (Điều 4)

<text color="secondary" size="xs">Đối chiếu Phần I, trang 1–2 của mẫu báo cáo thường niên.</text>

| Mã | Nội dung và danh mục minh chứng cần chuẩn bị | Chủ trì | Phối hợp |
|---|---|---|---|
| CK01 | **Thông tin pháp lý:** Quyết định thành lập, sáp nhập, đổi tên (nếu có); văn bản cho phép hoạt động; thông tin trụ sở, điểm trường, điện thoại, email, website, loại hình và đơn vị quản lý | Văn thư | Hiệu trưởng, BGH |
| CK02 | **Lịch sử, tầm nhìn, sứ mạng:** Chiến lược phát triển trường, mục tiêu giáo dục, tài liệu giới thiệu quá trình thành lập và phát triển | Hiệu trưởng | Hội đồng trường, BGH |
| CK03 | **Hội đồng trường và cơ cấu tổ chức:** Quyết định công nhận Hội đồng trường, Chủ tịch và danh sách thành viên; sơ đồ tổ chức; quy chế tổ chức, hoạt động | Hiệu trưởng | Văn thư, Hội đồng trường |
| CK04 | **Thông tin lãnh đạo:** Quyết định bổ nhiệm Hiệu trưởng, Phó Hiệu trưởng; phân công nhiệm vụ; thông tin liên hệ công vụ và trách nhiệm của lãnh đạo | Văn thư | Hiệu trưởng, PHT |
| CK05 | **Quy định, quy chế nhà trường:** Quy chế dân chủ; quy chế làm việc; quản lý hành chính, nhân sự, tài chính; quy chế chi tiêu nội bộ; quản lý tài sản; nghị quyết Hội đồng trường | Hiệu trưởng | Kế toán, văn thư, các tổ |
| CK06 | **Tuyển dụng và phát triển đội ngũ:** Kế hoạch, thông báo tuyển dụng; chính sách thu hút, đào tạo, bồi dưỡng và phát triển đội ngũ (nếu có) | Bộ phận phụ trách nhân sự, văn thư | Hiệu trưởng, PHT |

**Sản phẩm cần công khai:** Bộ thông tin chung về nhà trường kèm các văn bản, quy định thuộc diện công khai đã được ban hành hợp lệ.

### 2. Nhóm B – Công khai thu, chi tài chính (Điều 5)

<text color="secondary" size="xs">Đối chiếu Phần VI, trang 4–6 của mẫu báo cáo thường niên.</text>

| Mã | Nội dung và danh mục minh chứng cần chuẩn bị | Chủ trì | Phối hợp |
|---|---|---|---|
| TC01 | **Nguồn thu:** Tổng hợp ngân sách nhà nước; học phí; các khoản thu khác; tài trợ; nguồn thu hợp pháp khác, phân theo nguồn và loại hoạt động | Kế toán | Hiệu trưởng |
| TC02 | **Cơ cấu chi:** Tổng hợp chi lương, phụ cấp, thu nhập; chi cơ sở vật chất, dịch vụ; hỗ trợ trẻ; các khoản chi khác | Kế toán | Văn thư, phụ trách tài sản |
| TC03 | **Các khoản thu đối với trẻ:** Văn bản quy định mức thu; kế hoạch thu; bảng mức thu đang áp dụng; mức dự kiến năm học tiếp theo; dịch vụ hỗ trợ giáo dục (nếu có) | Kế toán | Hiệu trưởng, PHT nuôi dưỡng |
| TC04 | **Chế độ, chính sách hỗ trợ:** Quy định hỗ trợ, miễn giảm; quyết định phê duyệt; bảng tổng hợp số trẻ và kinh phí được hưởng; chứng từ thực hiện | Kế toán | Giáo viên, văn thư |
| TC05 | **Các quỹ theo quy định:** Bảng tổng hợp số dư đầu năm, phát sinh tăng, giảm và số dư cuối năm của từng quỹ (nếu có) | Kế toán | Hiệu trưởng |
| TC06 | **Ngân sách, quyết toán, tài trợ:** Quyết định giao, điều chỉnh dự toán; báo cáo thực hiện dự toán; quyết toán được phê duyệt; hồ sơ tài trợ, viện trợ thuộc diện công khai | Kế toán | Hiệu trưởng, phụ trách tài sản |

**Sản phẩm cần công khai:** Bảng công khai tài chính có đầy đủ các khoản thu, chi, chính sách, mức thu và số dư quỹ theo Điều 5; kèm các văn bản tài chính phải công khai theo quy định liên quan.

<box gap={1}>
  <row align="center" gap={2}>
    <icon name="alert-triangle" color="secondary" size="sm"/>
    **Điểm kiểm soát của Hiệu trưởng**
  </row>
  Kế toán chịu trách nhiệm cung cấp và đối chiếu số liệu, nhưng Hiệu trưởng phải kiểm tra sự thống nhất giữa báo cáo công khai, sổ kế toán, chứng từ, báo cáo quyết toán và các văn bản phê duyệt. Không công khai khoản thu chưa có căn cứ hợp lệ như một khoản đã được phê duyệt.
</box>

### 3. Nhóm C – Điều kiện bảo đảm chất lượng giáo dục (Điều 6)

<text color="secondary" size="xs">Đối chiếu Phần II, III, IV và V.C, trang 2–4 của mẫu báo cáo thường niên.</text>

| Mã | Nội dung và danh mục minh chứng cần chuẩn bị | Chủ trì | Phối hợp |
|---|---|---|---|
| CL01 | **Số lượng và trình độ đội ngũ:** Bảng tổng hợp CBQL, giáo viên, nhân viên theo vị trí việc làm, trình độ; hồ sơ nhân sự làm căn cứ đối chiếu | Văn thư hoặc phụ trách nhân sự | PHT, tổ trưởng, kế toán |
| CL02 | **Chuẩn nghề nghiệp, bồi dưỡng:** Kết quả đánh giá chuẩn nghề nghiệp CBQL, giáo viên; bảng tỷ lệ đạt chuẩn; kết quả hoàn thành bồi dưỡng hằng năm | PHT chuyên môn | Tổ trưởng chuyên môn, văn thư |
| CL03 | **Diện tích đất và điểm trường:** Hồ sơ đất, sơ đồ, bản vẽ; bảng diện tích từng điểm; diện tích bình quân/trẻ và kết quả đối chiếu yêu cầu tối thiểu | Người phụ trách CSVC | Kế toán, văn thư, PHT |
| CL04 | **Hệ thống phòng chức năng:** Bảng kiểm kê phòng học, phòng hành chính, phòng phục vụ chăm sóc, nuôi dưỡng, phòng ăn, phòng bếp và các phòng phụ trợ | Người phụ trách CSVC | PHT, kế toán, các điểm trường |
| CL05 | **Hạ tầng kỹ thuật:** Hồ sơ điện, nước sạch, thoát nước, nhà vệ sinh, phòng cháy chữa cháy, công nghệ thông tin, internet | Người phụ trách CSVC | Y tế, bảo vệ, kế toán |
| CL06 | **Thiết bị, đồ dùng, đồ chơi:** Sổ tài sản, biên bản kiểm kê; bảng thiết bị từng lớp; đồ chơi trong lớp, ngoài trời; bảng đối chiếu danh mục và yêu cầu tối thiểu | Người quản lý tài sản | Giáo viên, tổ trưởng, kế toán |
| CL07 | **Kiểm định và chuẩn quốc gia:** Báo cáo tự đánh giá; kết quả đánh giá ngoài; quyết định công nhận; kế hoạch và kết quả cải tiến chất lượng hằng năm, sau đánh giá ngoài | Hiệu trưởng, bộ phận tự đánh giá | PHT, các nhóm phụ trách tiêu chuẩn |
| CL08 | **Chương trình nước ngoài/tích hợp (nếu có):** Hồ sơ chương trình, quốc gia cung cấp, đối tác, cơ quan công nhận chất lượng, ngôn ngữ giảng dạy | Hiệu trưởng | PHT, văn thư, kế toán |

**Sản phẩm cần công khai:** Bảng thông tin đội ngũ, bảng điều kiện cơ sở vật chất có đối sánh yêu cầu tối thiểu, kết quả tự đánh giá và kiểm định, công nhận chuẩn quốc gia, thông tin chương trình đặc thù nếu có.

Đặc biệt, Điều 6 yêu cầu cả số lượng đồ chơi ngoài trời và điều kiện phục vụ chăm sóc, giáo dục. Nhà trường cần rà soát nội dung này dù không có dòng tách riêng trong bảng cơ sở vật chất của mẫu báo cáo thường niên. [Source unavailable: turn597117search2]; [Source unavailable: turn597117search5]

### 4. Nhóm D – Kế hoạch và kết quả hoạt động giáo dục mầm non (Điều 7)

<text color="secondary" size="xs">Đối chiếu Phần V, trang 3–4 của mẫu báo cáo thường niên.</text>

| Mã | Nội dung và danh mục minh chứng cần chuẩn bị | Chủ trì | Phối hợp |
|---|---|---|---|
| GD01 | **Tuyển sinh:** Kế hoạch tuyển sinh; chỉ tiêu, đối tượng, phương thức, thời gian; báo cáo kết quả tuyển sinh | PHT chuyên môn | Văn thư, giáo viên |
| GD02 | **Kế hoạch nuôi dưỡng, chăm sóc, giáo dục:** Kế hoạch năm học; kế hoạch chăm sóc, nuôi dưỡng, giáo dục toàn trường; kế hoạch giáo dục tháng | PHT theo lĩnh vực được giao | Tổ trưởng chuyên môn, y tế |
| GD03 | **Kế hoạch giáo dục tuần, ngày:** Kế hoạch theo độ tuổi, nhóm lớp; bảng tổng hợp lịch giáo dục tuần/ngày để công khai đúng hạn | PHT chuyên môn | Tổ trưởng, giáo viên |
| GD04 | **Thực đơn và dịch vụ:** Thực đơn ngày/tuần, bảng tính khẩu phần, kế hoạch tổ chức bán trú; danh mục dịch vụ giáo dục mầm non (nếu có) | PHT phụ trách nuôi dưỡng | Y tế, bếp ăn, kế toán |
| GD05 | **Quy mô và kết quả nuôi dưỡng, chăm sóc, giáo dục:** Sổ theo dõi trẻ; bảng số trẻ/nhóm lớp; lớp ghép; trẻ học 2 buổi/ngày; trẻ ăn bán trú; số liệu năm học trước | PHT chuyên môn | Tổ trưởng, giáo viên, văn thư |
| GD06 | **Sức khỏe và sự phát triển trẻ:** Bảng tổng hợp số trẻ được cân đo, theo dõi biểu đồ tăng trưởng, khám sức khỏe định kỳ; kết quả đánh giá sự phát triển trẻ | Y tế và PHT chuyên môn theo lĩnh vực | Giáo viên, tổ trưởng |
| GD07 | **Phổ cập và giáo dục hòa nhập:** Báo cáo kết quả phổ cập GDMN cho trẻ 5 tuổi; tổng hợp số trẻ khuyết tật; hồ sơ theo dõi chuyên môn làm căn cứ | PHT phụ trách phổ cập | Giáo viên, văn thư, y tế |
| GD08 | **Phối hợp gia đình và xã hội:** Quy chế phối hợp; kế hoạch phối hợp giáo dục; hồ sơ tổ chức họp cha mẹ trẻ; hoạt động tuyên truyền, phối hợp | PHT chuyên môn | Giáo viên, Ban đại diện cha mẹ trẻ |
| GD09 | **Trẻ học chương trình nước ngoài/tích hợp:** Bảng tổng hợp số trẻ Việt Nam, trẻ nước ngoài đang học chương trình (nếu có) | PHT chuyên môn | Văn thư, giáo viên |

**Sản phẩm cần công khai:** Kế hoạch tuyển sinh, kế hoạch nuôi dưỡng – chăm sóc – giáo dục, quy chế phối hợp với gia đình, thực đơn, dịch vụ giáo dục và các kết quả thực hiện năm học trước theo quy định.

Đối với GD06 và GD07, nhà trường nên sử dụng **số liệu tổng hợp, không công khai hồ sơ sức khỏe cá nhân, danh tính trẻ khuyết tật hoặc thông tin nhạy cảm của trẻ**.

---

## III. Phân công trách nhiệm các bộ phận trong trường

Từ 29 nhóm minh chứng trên, tôi đề xuất Hiệu trưởng thành lập **Tổ thực hiện công khai năm học 2026–2027** với cơ cấu sau:

| Thành phần | Vai trò đề xuất | Trách nhiệm và sản phẩm bàn giao |
|---|---|---|
| **Hiệu trưởng** | Tổ trưởng | Ban hành quyết định, quy định, kế hoạch công khai; phê duyệt nội dung; ký báo cáo; chịu trách nhiệm giải trình |
| **PHT chuyên môn** | Tổ phó | Chủ trì nội dung đội ngũ, kế hoạch giáo dục, tuyển sinh, kết quả giáo dục, phổ cập, kiểm định theo phân công |
| **PHT phụ trách nuôi dưỡng** | Tổ phó hoặc thành viên | Chủ trì công khai thực đơn, bán trú, dinh dưỡng, sức khỏe, an toàn trong phạm vi phụ trách |
| **Văn thư** | Thư ký/đầu mối tổng hợp | Lập danh mục hồ sơ, tiếp nhận minh chứng, kiểm tra thể thức, quản lý phiên bản và lưu trữ |
| **Kế toán** | Thành viên tài chính | Chuẩn bị toàn bộ bảng công khai thu chi, các khoản thu, hỗ trợ, quỹ, quyết toán; phối hợp tài sản |
| **Người phụ trách cơ sở vật chất** | Thành viên | Kiểm kê, đối sánh diện tích, phòng học, thiết bị, tài sản và điều kiện kỹ thuật |
| **Tổ trưởng chuyên môn** | Thành viên | Tổng hợp kế hoạch, dữ liệu lớp, kết quả giáo dục; kiểm tra hồ sơ giáo viên |
| **Giáo viên các lớp** | Bộ phận cung cấp minh chứng | Cung cấp số liệu trẻ, kế hoạch giáo dục, kết quả đánh giá, phối hợp cha mẹ trẻ |
| **Nhân viên y tế, bộ phận bếp** | Bộ phận phối hợp | Cung cấp dữ liệu sức khỏe tổng hợp, dinh dưỡng, thực đơn, hồ sơ bán trú |
| **Người quản trị website** | Thành viên kỹ thuật | Đăng file đã duyệt, kiểm tra đường dẫn, thời hạn hiển thị, lưu minh chứng đăng tải |
| **Ban Thanh tra nhân dân** | Giám sát theo chức năng | Theo dõi tính minh bạch, phản ánh thiếu sót và kiến nghị khắc phục |

Các vị trí có thể kiêm nhiệm tùy thực tế nhân sự; không nhất thiết trường phải có riêng hai Phó Hiệu trưởng hoặc một bộ phận công nghệ thông tin.

**Đề xuất quản lý:** Chỉ định một thành viên làm đầu mối công khai duy nhất, thường là văn thư hoặc một Phó Hiệu trưởng. Mọi tài liệu chuyển đến website phải đi qua đầu mối này sau khi được người có thẩm quyền phê duyệt, tránh mỗi tổ tự đăng những số liệu chưa thống nhất.

## IV. Phân công xây dựng báo cáo thường niên theo Phụ lục I

Mẫu Sở GDĐT ban hành gồm 7 phần chính, phần đánh giá chung, định hướng năm tiếp theo và các phụ lục kèm theo. Nhà trường nên tận dụng 29 nhóm minh chứng ở Mục II để biên soạn, không yêu cầu giáo viên làm lại hồ sơ đã có.

| Phần báo cáo | Người chịu trách nhiệm biên soạn | Bộ phận đối chiếu, cung cấp |
|---|---|---|
| I. Thông tin chung | Văn thư, Hiệu trưởng | BGH, Hội đồng trường |
| II. Đội ngũ nhà giáo, CBQL và nhân viên | PHT chuyên môn hoặc phụ trách nhân sự | Văn thư, tổ trưởng, kế toán |
| III. Cơ sở vật chất | Người phụ trách CSVC | Kế toán, PHT, các điểm trường |
| IV. Bảo đảm chất lượng, chuẩn quốc gia | Hiệu trưởng hoặc phụ trách tự đánh giá | PHT, các nhóm phụ trách tiêu chuẩn |
| V. Kết quả hoạt động giáo dục | PHT chuyên môn | Tổ trưởng, giáo viên, y tế, phụ trách phổ cập |
| VI. Kết quả tài chính | Kế toán | Hiệu trưởng, văn thư |
| VII. Kết quả nhiệm vụ trọng tâm khác | BGH tổng hợp theo lĩnh vực | CNTT, y tế, tổ chuyên môn, thi đua, kiểm tra nội bộ |
| Đánh giá chung và định hướng năm sau | Hiệu trưởng | Toàn bộ Tổ công khai |

### Sáu phụ lục cần rà soát khi hoàn thành báo cáo

Theo trang 7 của mẫu báo cáo đính kèm:

| STT | Tài liệu, phụ lục | Bộ phận chuẩn bị |
|---|---|---|
| 1 | Bảng số liệu đội ngũ và cơ sở vật chất đối sánh năm trước | Văn thư, PHT, phụ trách CSVC |
| 2 | Bảng kết quả hoạt động giáo dục | PHT chuyên môn |
| 3 | Bảng công khai tài chính theo Điều 5 | Kế toán |
| 4 | Biểu công khai ngân sách hiện hành (nếu thuộc đối tượng) | Kế toán |
| 5 | Quyết toán/báo cáo tài chính và tài liệu chứng minh liên quan | Kế toán |
| 6 | Các tài liệu khác phục vụ công khai | Văn thư tổng hợp từ các bộ phận |

Báo cáo phải lấy mốc dữ liệu ngày 31/12 của năm báo cáo, đối sánh năm trước theo các chỉ tiêu trong mẫu; ký, đóng dấu và đăng file PDF. Nếu chưa có số liệu quyết toán chính thức thì cập nhật theo thời điểm quyết toán của cơ quan có thẩm quyền.

## V. Tiến độ thực hiện và các mốc cần đặc biệt chú ý

<box border radius="lg" padding={3} gap={2}>
  <row align="center" justify="between">
    **Việc cần ưu tiên tại thời điểm 23/10/2026**
    <icon name="calendar-clock" color="secondary"/>
  </row>
  <text color="secondary" size="sm">Căn cứ thời hạn ghi tại Công văn 3965 và Thông tư 09.</text>
  <divider color="subtle"/>
  <row align="start" gap={3}>
    <box background="surface-secondary" radius="md" padding={2}>
      <text weight="medium" tabularNums>23/10</text>
    </box>
    <box flex="1" gap={1}>
      **Hoàn tất công khai kế hoạch tuần tới và dự kiến thực đơn**

      <text size="sm">Đối với tuần 26/10–01/11/2026, phải đăng trước thứ Bảy 24/10. Nên hoàn tất ngay trong ngày 23/10 nếu chưa thực hiện.</text>
    </box>
  </row>
  <divider color="subtle"/>
  <row align="start" gap={3}>
    <box background="surface-secondary" radius="md" padding={2}>
      <text weight="medium" tabularNums>23/10</text>
    </box>
    <box flex="1" gap={1}>
      **Hoàn tất công khai kế hoạch giáo dục tháng 11/2026**

      <text size="sm">Quy định công khai trước ngày 25 của tháng trước. Ngày 23/10 là ngày làm việc thuận tiện để hoàn thành.</text>
    </box>
  </row>
  <divider color="subtle"/>
  <row align="start" gap={3}>
    <box background="surface-secondary" radius="md" padding={2}>
      <text weight="medium" tabularNums>Ngay</text>
    </box>
    <box flex="1" gap={1}>
      **Kiểm tra tình trạng báo cáo công khai năm học 2025–2026**

      <text size="sm">Công văn 3965 yêu cầu các trường thuộc UBND xã, phường gửi báo cáo để UBND tổng hợp. Hạn UBND báo cáo về Sở là 20/10/2026, đã qua; cần kiểm tra với UBND phường và bổ sung ngay nếu trường còn thiếu.</text>
    </box>
  </row>
</box>

### Các thời hạn thực hiện thường xuyên

| Công việc | Mốc thời gian |
|---|---|
| Nội dung công khai theo Điều 4–7 | Trước 30/6 hằng năm |
| Cập nhật nội dung thay đổi hoặc mới có thông tin chính thức | Chậm nhất sau 10 ngày làm việc |
| Kế hoạch giáo dục tháng | Trước ngày 25 của tháng trước |
| Kế hoạch tuần, ngày; dự kiến thực đơn | Trước ngày thứ Bảy của tuần trước |
| Báo cáo thường niên năm 2026 | Số liệu đến 31/12/2026; công bố trước 30/6/2027 |
| Phổ biến nội dung công khai với cha mẹ trẻ | Tháng đầu tiên của năm học mới |
| Tự kiểm tra việc thực hiện Thông tư 09 | Ít nhất 01 lần/năm, lưu biên bản |
| Hiển thị công khai trên website | Tối thiểu 05 năm |
| Niêm yết nếu cơ sở mầm non chưa có website | Tối thiểu 90 ngày liên tục; sau đó lưu tài liệu ít nhất 05 năm |

Các mốc này căn cứ Điều 14, 15 Thông tư 09 và hướng dẫn của Sở GDĐT Đồng Tháp. [Source unavailable: turn597117search7]; [Source unavailable: turn597117search28]

## VI. Quy trình phối hợp 5 bước để hoàn thành

<box gap={3}>
  <row align="start" gap={3}>
    <box background="surface-secondary" radius="lg" padding={2}>
      <icon name="clipboard-list" size="lg"/>
    </box>
    <box flex="1" gap={1}>
      **Bước 1. Hiệu trưởng giao nhiệm vụ**

      Ban hành quyết định thành lập Tổ công khai; quy định thực hiện công khai của trường; kế hoạch năm học và bảng giao 29 mã minh chứng. Xác định rõ người phụ trách từng mã, người duyệt và ngày hoàn thành.
    </box>
  </row>
  <divider color="subtle"/>
  <row align="start" gap={3}>
    <box background="surface-secondary" radius="lg" padding={2}>
      <icon name="folder-open" size="lg"/>
    </box>
    <box flex="1" gap={1}>
      **Bước 2. Các bộ phận thu thập và tổng hợp minh chứng**

      Kế toán, văn thư, PHT, tổ trưởng, y tế, phụ trách tài sản nộp dữ liệu và tài liệu có nguồn gốc rõ ràng. Tài liệu gốc được lưu nội bộ; mỗi người phụ trách chuẩn bị bản tổng hợp phù hợp để công khai.
    </box>
  </row>
  <divider color="subtle"/>
  <row align="start" gap={3}>
    <box background="surface-secondary" radius="lg" padding={2}>
      <icon name="shield-check" size="lg"/>
    </box>
    <box flex="1" gap={1}>
      **Bước 3. Đối chiếu và xác nhận số liệu**

      Đầu mối công khai kiểm tra đủ nội dung. PHT đối chiếu số liệu trẻ, nhóm lớp; kế toán đối chiếu tài chính; phụ trách nhân sự đối chiếu đội ngũ; phụ trách CSVC đối chiếu tài sản. Hiệu trưởng xem xét trước khi ban hành.
    </box>
  </row>
  <divider color="subtle"/>
  <row align="start" gap={3}>
    <box background="surface-secondary" radius="lg" padding={2}>
      <icon name="globe" size="lg"/>
    </box>
    <box flex="1" gap={1}>
      **Bước 4. Công bố đúng hình thức và thời hạn**

      Quản trị website đăng tài liệu đã ký, đúng thư mục, đặt liên kết dễ truy cập; lưu ngày đăng và đường dẫn. Trường hợp thuộc diện niêm yết, văn thư lập biên bản và lưu bằng chứng niêm yết.
    </box>
  </row>
  <divider color="subtle"/>
  <row align="start" gap={3}>
    <box background="surface-secondary" radius="lg" padding={2}>
      <icon name="file-check-2" size="lg"/>
    </box>
    <box flex="1" gap={1}>
      **Bước 5. Tự kiểm tra, lưu trữ và báo cáo**

      Kiểm tra các đường dẫn công khai, thời gian, tính đầy đủ, độ chính xác và khả năng truy cập; lập biên bản ít nhất một lần/năm. Báo cáo kết quả, những nội dung chưa hoàn thành và biện pháp khắc phục.
    </box>
  </row>
</box>

## VII. Đề xuất tổ chức mục công khai trên website

Theo Công văn 3965, website cần có một mục công khai riêng và bảng theo mẫu đính kèm. Có thể tổ chức hồ sơ theo các nhóm sau để dễ quản lý và truy cập:

<box border radius="lg" padding={3} gap={2}>
  <row align="center" gap={2}>
    <icon name="folder-open" color="secondary"/>
    **CÔNG KHAI THEO THÔNG TƯ 09/2024**
  </row>
  {#each [
    ["01","Thông tin chung về nhà trường","Điều 4"],
    ["02","Công khai tài chính","Điều 5"],
    ["03","Đội ngũ, cơ sở vật chất, chất lượng","Điều 6"],
    ["04","Kế hoạch và kết quả giáo dục mầm non","Điều 7"],
    ["05","Báo cáo thường niên","Phụ lục I"],
    ["06","Kế hoạch giáo dục tháng, tuần, ngày","Cập nhật định kỳ"],
    ["07","Thực đơn nuôi dưỡng trẻ","Cập nhật định kỳ"]
  ] as item}
    <row align="center" gap={2} key={item[0]}>
      <box background="surface-secondary" radius="sm" padding={2}>
        <text color="secondary" tabularNums size="xs">{item[0]}</text>
      </box>
      <box flex="1" gap="2px">
        <text size="sm" weight="medium">{item[1]}</text>
        <caption>{item[2]}</caption>
      </box>
    </row>
  {/each}
</box>

Đây là cấu trúc gợi ý theo Thông tư 09. Tôi chưa đối chiếu được các cột cụ thể bên trong tệp `7. mau_web_mamnon.xlsx`, vì vậy khi triển khai cần giữ đúng mẫu bảng website do Sở gửi kèm nếu mẫu có quy định chi tiết khác.

Nhà trường nên quản lý thêm một bảng nội bộ gồm các cột: **Mã minh chứng – Nội dung – Người cung cấp – Người kiểm tra – Thời hạn – Tên file đã ký – Ngày đăng – Đường dẫn – Tình trạng – Ghi chú**. Bảng nội bộ này không cần công khai trên website.

## VIII. Những rủi ro Hiệu trưởng cần kiểm soát

<box gap={3}>
  <row align="start" gap={2}>
    <icon name="alert-circle" color="secondary" size="lg"/>
    <box flex="1" gap={1}>
      **Thiếu hồ sơ chứng minh đã công khai**

      Có file báo cáo nhưng không có đường dẫn, ngày đăng, biên bản niêm yết hoặc bằng chứng phổ biến. Cần lưu đủ hồ sơ thực hiện, không chỉ lưu bản báo cáo.
    </box>
  </row>
  <row align="start" gap={2}>
    <icon name="alert-circle" color="secondary" size="lg"/>
    <box flex="1" gap={1}>
      **Số liệu giữa các bộ phận không khớp**

      Đội ngũ, tổng số trẻ, số nhóm lớp, trẻ bán trú, diện tích và số liệu tài chính có thể khác nhau giữa báo cáo chuyên môn, kế toán, cơ sở dữ liệu và báo cáo thường niên. Cần một đợt đối chiếu trước khi ký.
    </box>
  </row>
  <row align="start" gap={2}>
    <icon name="alert-circle" color="secondary" size="lg"/>
    <box flex="1" gap={1}>
      **Công khai quá mức thông tin cá nhân**

      Không đăng danh sách trẻ kèm tình trạng sức khỏe, bệnh lý, khuyết tật, hồ sơ hưởng chính sách hoặc tài liệu nhân sự chứa dữ liệu riêng tư khi không có căn cứ pháp luật.
    </box>
  </row>
  <row align="start" gap={2}>
    <icon name="alert-circle" color="secondary" size="lg"/>
    <box flex="1" gap={1}>
      **Đăng tải không đúng hiệu lực, hình thức**

      Dùng dự thảo chưa ký, thiếu dấu với báo cáo yêu cầu đóng dấu, gỡ bỏ tài liệu cũ, không cập nhật khi thay đổi hoặc chỉ đăng một báo cáo thường niên mà bỏ qua nội dung công khai định kỳ.
    </box>
  </row>
</box>

## IX. Kết luận và đề xuất của Hiệu trưởng

Để triển khai hiệu quả trong năm học 2026–2027, tôi đề xuất nhà trường lấy **29 nhóm minh chứng làm bảng giao việc**, dùng **7 phần của Phụ lục I làm khung tổng hợp báo cáo**, và quản lý kết quả công khai bằng đường dẫn website, tài liệu đã ký cùng hồ sơ kiểm tra.

Ưu tiên trước mắt là hoàn thành các nội dung công khai định kỳ của cuối tháng 10/2026, kiểm tra tình trạng báo cáo năm học 2025–2026 với UBND phường, sau đó rà soát những nhóm minh chứng còn thiếu và hoàn thiện hồ sơ tổ chức thực hiện của trường.

**Nguyên tắc điều hành xuyên suốt: Mỗi nội dung một người chủ trì; mỗi số liệu có nguồn kiểm chứng; mỗi tài liệu công khai có thời điểm, địa chỉ truy cập và hồ sơ lưu.**

Như vậy, Hiệu trưởng vừa kiểm soát được tiến độ và trách nhiệm của từng bộ phận, vừa hạn chế việc tạo thêm hồ sơ hành chính không cần thiết cho giáo viên, bảo đảm công khai đúng quy định và phục vụ thực chất công tác quản trị nhà trường.

---

