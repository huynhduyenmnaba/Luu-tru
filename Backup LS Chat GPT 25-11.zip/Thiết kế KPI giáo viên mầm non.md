USER

với vai trò hiệu trưởng trường mầm non có hơn 20 năm kinh nghiệm dựa vào nội dung quy chế , bạn hãy giúp tôi thiết kế bảng KPI cho giáo viên đánh giá hàng tháng (cụ thể dễ hiểu và áp dụng) ứng với từng phần việc cụ thể  trong thực tế. Quy định rõ và cụ thể các mức đạt và số điểm tương ứng để đảm báo đanh giá sát thực tiễn công việc

---

ASSISTANT

Tôi sẽ chuyển các tiêu chí 30 điểm chung và 70 điểm dành cho giáo viên thành những đầu việc có thể kiểm tra hằng tháng, kèm thang điểm và minh chứng rõ ràng. Tôi cũng sẽ làm bảng Excel tự tính điểm để nhà trường có thể áp dụng thống nhất, đồng thời rà soát phần căn cứ xếp loại trong quy chế.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# PHỤ LỤC: BẢNG TIÊU CHÍ KPI ĐÁNH GIÁ KẾT QUẢ THỰC HIỆN NHIỆM VỤ HẰNG THÁNG ĐỐI VỚI GIÁO VIÊN MẦM NON

DỰ THẢO ĐỀ XUẤT ÁP DỤNG TẠI TRƯỜNG MẦM NON – THANG ĐIỂM 100

## I. 🎯 Mục tiêu và định hướng xây dựng

Dựa trên quy chế đánh giá mà cô cung cấp, tôi đề xuất xây dựng bảng KPI theo hướng **chấm điểm từng công việc thực tế, có mức điểm cụ thể, có minh chứng và có thể kiểm tra được**, thay vì nhận xét chung chung như “thực hiện tốt”, “có tinh thần trách nhiệm” hoặc “hoàn thành nhiệm vụ”.

Bảng KPI cần đáp ứng 5 yêu cầu:

1. Giáo viên biết rõ mỗi tháng phải làm những công việc gì, làm đến mức nào thì được điểm tối đa.
2. Tổ trưởng chuyên môn và ban giám hiệu có cùng cách chấm điểm, hạn chế đánh giá cảm tính.
3. Phân biệt được giáo viên hoàn thành đầy đủ công việc với giáo viên có chất lượng thực hiện nổi bật.
4. Chú trọng an toàn trẻ, chất lượng chăm sóc, nuôi dưỡng và tổ chức hoạt động giáo dục, không chạy theo số lượng hồ sơ hay hình thức.
5. Có thể sử dụng làm căn cứ theo dõi hằng tháng, tổng hợp định kỳ và phục vụ đánh giá, xếp loại viên chức cuối năm theo quy định.

## II. 📖 Căn cứ xây dựng

- [Nghị định số 233/2026/NĐ\-CP](<https://vanban.chinhphu.vn/?classid=1&docid=218616&pageid=27160>) ngày 26/6/2026 của Chính phủ, có hiệu lực từ ngày 01/7/2026, đặc biệt là Điều 10, Điều 11, Điều 12 và Điều 18.
- [Thông tư số 52/2020/TT\-BGDĐT](<https://chinhphu.vn/default.aspx?docid=203047&pageid=27160>) ban hành Điều lệ trường mầm non, được sửa đổi, bổ sung bởi [Thông tư số 51/2026/TT\-BGDĐT](<https://chinhphu.vn/?classid=1&docid=218796&orggroupid=4&pageid=27160>), có hiệu lực từ ngày 15/8/2026.
- Chương trình Giáo dục mầm non, kế hoạch năm học, kế hoạch chuyên môn và quy định phân công nhiệm vụ của nhà trường.
- Khung đánh giá 30 điểm tiêu chí chung và 70 điểm kết quả thực hiện nhiệm vụ giáo viên trong tài liệu cô cung cấp.

**Lưu ý pháp lý quan trọng:** Theo khoản 3 Điều 18 Nghị định 233/2026/NĐ-CP, đơn vị sự nghiệp công lập phải ban hành quy chế đánh giá của đơn vị chậm nhất ngày 30/11/2026. Bảng dưới đây là phương án cụ thể hóa để đưa vào phụ lục quy chế sau khi nhà trường thống nhất, không phải bảng phân điểm chi tiết do Chính phủ quy định sẵn. [Nghị định số 233/2026/NĐ\-CP của Chính phủ: Quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức](<https://vanban.chinhphu.vn/?classid=1&docid=218616&pageid=27160>); [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=dieu_13>); [Thông tư số 51/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Sửa đổi, bổ sung một số điều của Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy chế tố chức, hoạt động nhóm trẻ độc lập, lớp mẫu giáo độc lập, lớp mầm non độc lập loại hình dân lập và tư thục ban hành kèm theo Thông tư số 49/2021/TT\-BGDĐT ngày 31 tháng 12 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy định tiêu chuẩn, quy trình biên soạn, chỉnh sửa Chương trình giáo dục mầm non, tổ chức và hoạt động của Hội đồng quốc gia thẩm định chương trình giáo dục mầm non ban hành kèm theo Thông tư số 49/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo](<https://chinhphu.vn/?classid=1&docid=218796&orggroupid=4&pageid=27160>)

## III. 🔍 Cơ cấu điểm KPI giáo viên hằng tháng

| **Nhóm tiêu chí** | **Điểm tối đa** |
|--------|--------|
| **A. TIÊU CHÍ CHUNG** | **30** |
| **B. KẾT QUẢ THỰC HIỆN NHIỆM VỤ** | **70** |
| **TỔNG CỘNG** | **100** |

Tôi giữ nguyên toàn bộ cơ cấu điểm trong quy chế cô gửi, đồng thời chia thành **23 chỉ tiêu công việc cụ thể**, mỗi chỉ tiêu có các mức điểm xác định trước.

## IV. 📋 Bảng KPI chi tiết – Tiêu chí chung (30 điểm)

### A1. Phẩm chất chính trị, đạo đức nghề nghiệp, ý thức kỷ luật – 15 điểm

| Mã | Công việc, yêu cầu đánh giá | Quy định mức điểm cụ thể | Minh chứng |
|--------|--------|--------|--------|
| A1.1 | **Đạo đức nhà giáo, tôn trọng trẻ (6đ).** Đối xử công bằng, nhẹ nhàng; không quát mắng, xúc phạm, ép buộc hoặc phân biệt đối xử với trẻ. | **6đ:** Không có vi phạm được xác minh. **4đ:** 1 sai sót giao tiếp nhẹ, khắc phục ngay. **2đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc có hành vi nghiêm trọng được xác minh. | Quan sát lớp, biên bản kiểm tra, phản ánh đã xác minh. |
| A1.2 | **Chấp hành pháp luật, quy chế và nội quy (5đ).** Tuân thủ các quy định nghề nghiệp, những điều giáo viên không được làm và quy chế nhà trường. | **5đ:** Không vi phạm. **4đ:** 1 vi phạm nhẹ. **2đ:** 2–3 vi phạm nhẹ. **0đ:** Từ 4 vi phạm hoặc vi phạm nghiêm trọng. | Biên bản kiểm tra, sổ theo dõi việc chấp hành quy chế. |
| A1.3 | **Trung thực, bảo mật thông tin (4đ).** Ghi chép, báo cáo chính xác; bảo vệ thông tin cá nhân và hình ảnh trẻ; không làm sai lệch minh chứng. | **4đ:** Thực hiện đúng, đủ. **3đ:** 1 sai sót ghi chép không cố ý, được sửa ngay. **1đ:** 2 sai sót được xác minh. **0đ:** Từ 3 sai sót hoặc cố ý báo cáo sai, tiết lộ thông tin trái quy định. | Hồ sơ, báo cáo, kết quả đối chiếu, biên bản xác minh. |
|  | **Tổng A1** | **15 điểm** |  |

### A2. Trách nhiệm, đoàn kết, phối hợp – 7 điểm

| Mã | Công việc, yêu cầu đánh giá | Quy định mức điểm cụ thể | Minh chứng |
|--------|--------|--------|--------|
| A2.1 | **Tinh thần trách nhiệm (4đ).** Chủ động tiếp nhận nhiệm vụ, phản hồi chỉ đạo, báo cáo khó khăn và đề xuất cách giải quyết. | **4đ:** Chủ động thực hiện, không phải nhắc. **3đ:** Có 1 lần phải nhắc. **1đ:** Có 2 lần phải nhắc. **0đ:** Từ 3 lần phải nhắc hoặc từ chối nhiệm vụ hợp lệ không có lý do chính đáng. | Sổ giao việc, nhật ký công tác, ghi nhận của tổ trưởng. |
| A2.2 | **Đoàn kết, hỗ trợ đồng nghiệp (3đ).** Phối hợp tích cực, hỗ trợ khi được phân công, tôn trọng và góp ý xây dựng. | **3đ:** Hợp tác tốt, thực hiện đầy đủ phần việc phối hợp. **2đ:** 1 lần chưa phối hợp, phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần hoặc có hành vi gây mất đoàn kết được xác minh. | Biên bản sinh hoạt tổ, kết quả phân công phối hợp. |
|  | **Tổng A2** | **7 điểm** |  |

### A3. Tác phong, lề lối làm việc – 4 điểm

| Mã | Công việc, yêu cầu đánh giá | Quy định mức điểm cụ thể | Minh chứng |
|--------|--------|--------|--------|
| A3.1 | **Chấp hành giờ giấc (2đ).** Đúng giờ làm việc, giờ nhận lớp, bàn giao ca và các hoạt động bắt buộc. | **2đ:** Không có lần đi muộn/về sớm trái quy định. **1đ:** 1 lần. **0đ:** Từ 2 lần. | Bảng chấm công, lịch trực, biên bản xác minh. |
| A3.2 | **Tác phong, giao tiếp (2đ).** Trang phục phù hợp, giao tiếp chuẩn mực với phụ huynh, đồng nghiệp và người đến trường. | **2đ:** Đúng quy định. **1đ:** 1 lần sai sót nhẹ, đã khắc phục. **0đ:** Từ 2 lần hoặc vi phạm nghiêm trọng đã xác minh. | Kiểm tra thực tế, biên bản ghi nhận. |
|  | **Tổng A3** | **4 điểm** |  |

### A4. Đổi mới, sáng tạo, tự học và chuyển đổi số – 4 điểm

| Mã | Công việc, yêu cầu đánh giá | Quy định mức điểm cụ thể | Minh chứng |
|--------|--------|--------|--------|
| A4.1 | **Tự học, bồi dưỡng (2đ).** Chủ động cập nhật kiến thức và vận dụng vào thực tế lớp học. | **2đ:** Có ít nhất 1 nội dung tự học/bồi dưỡng được vận dụng. **1đ:** Có học nhưng chưa thể hiện việc vận dụng. **0đ:** Không có minh chứng tự học, bồi dưỡng theo yêu cầu. | Sản phẩm bồi dưỡng, ghi nhận vận dụng. |
| A4.2 | **Cải tiến hoạt động giáo dục (2đ).** Vận dụng CNTT, STEAM, AI hoặc một giải pháp tổ chức hoạt động phù hợp, thiết thực. | **2đ:** Có ít nhất 1 cải tiến được áp dụng và chứng minh tác dụng. **1đ:** Có thử nghiệm nhưng chưa đánh giá được hiệu quả. **0đ:** Không có hoạt động cải tiến được ghi nhận. | Giáo án cải tiến, học liệu, sản phẩm chuyên môn. |
|  | **Tổng A4** | **4 điểm** |  |

**Lưu ý khi chấm nhóm A:** Chỉ tính vi phạm, sai sót có bằng chứng rõ ràng; không dùng phản ánh chưa được xác minh để trừ điểm. Các trường hợp nghỉ có phép, nghỉ theo chế độ không được xem là vi phạm giờ giấc. Đối với A4, không bắt buộc giáo viên phải sử dụng AI hoặc có sáng kiến được công nhận cấp trên; một cải tiến nhỏ nhưng áp dụng hiệu quả tại lớp cũng được ghi nhận.

---

## V. 📋 Bảng KPI chi tiết – Kết quả thực hiện nhiệm vụ giáo viên (70 điểm)

Đây là phần cần kiểm tra kỹ nhất vì chiếm 70% tổng điểm, phản ánh trực tiếp hiệu quả thực hiện nhiệm vụ của giáo viên tại lớp.

### B1. Số lượng, khối lượng nhiệm vụ thực hiện – 20 điểm

| Mã | Công việc, yêu cầu đánh giá | Quy định mức điểm cụ thể | Minh chứng |
|--------|--------|--------|--------|
| B1.1 | **Xây dựng kế hoạch giáo dục (5đ).** Hoàn thành đủ kế hoạch tháng, tuần và các nội dung kế hoạch theo phân công, quy định của trường. | **5đ:** Đủ 100% kế hoạch phải thực hiện. **4đ:** Từ 90% đến dưới 100%. **2đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch đã được phê duyệt, sổ theo dõi chuyên môn. |
| B1.2 | **Thực hiện các hoạt động chăm sóc, giáo dục (8đ).** Tổ chức đủ các hoạt động được phân công theo kế hoạch thực tế: học, chơi, hoạt động ngoài trời, ăn, ngủ, vệ sinh, hoạt động chiều… | **8đ:** Đạt 100% khối lượng. **6đ:** Từ 90% đến dưới 100%. **3đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch, nhật ký hoạt động, kiểm tra thực tế. |
| B1.3 | **Hoàn thành hồ sơ chuyên môn (4đ).** Thực hiện đầy đủ các hồ sơ, sổ sách, thông tin theo dõi trẻ thuộc trách nhiệm giáo viên và được quy định phải có. | **4đ:** Đủ 100%. **3đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Hồ sơ chuyên môn, hồ sơ lớp, phiếu kiểm tra. |
| B1.4 | **Thực hiện các nhiệm vụ được phân công khác (3đ).** Trực lớp, đón trả trẻ, quản lý đồ dùng, chuẩn bị môi trường, tham gia nhiệm vụ chung. | **3đ:** Hoàn thành 100%. **2đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Bảng phân công, sổ trực, kết quả kiểm tra. |
|  | **Tổng B1** | **20 điểm** |  |

**Cách tính khối lượng:** Số công việc hoàn thành đạt yêu cầu chia cho số công việc thực tế được giao, nhân 100%. Các nhiệm vụ đã được điều chỉnh hợp lệ hoặc không thuộc thời gian giáo viên thực tế làm việc phải được xử lý theo nguyên tắc tại Mục VII.

Ví dụ: Giáo viên có 40 hoạt động thuộc trách nhiệm trong tháng, thực hiện 38 hoạt động, không có điều chỉnh được duyệt.

Tỷ lệ hoàn thành = 38/40 × 100 = 95%.

Như vậy, tiêu chí B1.2 được **6/8 điểm**, không chấm đủ 8 điểm.

### B2. Chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ – 30 điểm

Đây là nhóm có trọng số cao nhất. Tôi đề xuất đánh giá theo bốn nội dung: an toàn, chăm sóc, chất lượng hoạt động và theo dõi phát triển của trẻ.

| Mã | Công việc, yêu cầu đánh giá | Quy định mức điểm cụ thể | Minh chứng |
|--------|--------|--------|--------|
| B2.1 | **Bảo đảm an toàn thể chất, tinh thần cho trẻ (10đ).** Thực hiện đúng quy trình điểm danh, giám sát trẻ, đón trả, kiểm tra và báo nguy cơ mất an toàn; không có hành vi gây tổn hại trẻ. | **10đ:** Thực hiện đầy đủ, không có sai sót được xác minh. **7đ:** 1 sai sót thủ tục nhẹ, khắc phục ngay, chưa gây nguy hiểm. **3đ:** 2 sai sót nhẹ được ghi nhận, đã khắc phục. **0đ:** Từ 3 sai sót hoặc 1 vi phạm nghiêm trọng về an toàn thuộc trách nhiệm giáo viên đã được xác minh. | Kiểm tra an toàn, sổ giao nhận trẻ, biên bản sự việc. |
| B2.2 | **Chất lượng chăm sóc, vệ sinh, ăn, ngủ, sức khỏe (7đ).** Thực hiện đúng các bước chăm sóc trẻ theo lứa tuổi, bảo đảm vệ sinh, theo dõi sức khỏe, phối hợp tổ chức bữa ăn và giấc ngủ. | **7đ:** Thực hiện đúng, không có sai sót. **5đ:** 1 sai sót nhẹ, sửa ngay. **2đ:** 2–3 sai sót nhẹ. **0đ:** Từ 4 sai sót hoặc có vi phạm nghiêm trọng được xác minh. | Kiểm tra hoạt động ăn, ngủ, vệ sinh; sổ theo dõi sức khỏe. |
| B2.3 | **Chất lượng tổ chức hoạt động giáo dục lấy trẻ làm trung tâm (8đ).** Đánh giá bằng phiếu quan sát 5 chỉ báo, ít nhất 2 lượt/tháng. | **8đ:** Đạt 9–10/10 chỉ báo. **6đ:** Đạt 7–8/10. **3đ:** Đạt 5–6/10. **0đ:** Đạt 0–4/10. | Phiếu quan sát hoạt động, nhận xét chuyên môn. |
| B2.4 | **Theo dõi, đánh giá và hỗ trợ sự phát triển của trẻ (5đ).** Quan sát, ghi nhận đúng kế hoạch; nhận diện và có biện pháp hỗ trợ trẻ cần quan tâm. | **5đ:** Thực hiện đủ 100% nội dung phải theo dõi và hỗ trợ. **4đ:** Từ 90% đến dưới 100%. **2đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Hồ sơ theo dõi sự phát triển, ghi nhận quan sát, kế hoạch hỗ trợ trẻ. |
|  | **Tổng B2** | **30 điểm** |  |

**Cụ thể hóa B2.3 – Phiếu quan sát chất lượng hoạt động giáo dục**

Để hạn chế chấm theo cảm nhận của người dự giờ, mỗi lượt quan sát sử dụng 5 chỉ báo, mỗi chỉ báo đạt được 1 điểm, không đạt được 0 điểm.

| STT | Chỉ báo quan sát | Điểm/lượt |
|--------|--------|--------|
|  | **Tổng một lượt** | **5 điểm** |

Hai lượt quan sát ở hai thời điểm khác nhau tạo thành kết quả tối đa 10/10 chỉ báo để quy đổi sang điểm KPI B2.3. Phiếu quan sát cần có nhận xét ngắn về điểm mạnh và nội dung cần cải thiện.

Đây là bộ chỉ báo chấm nội bộ được đề xuất, không phải thang đánh giá tiết dạy bắt buộc của Bộ Giáo dục và Đào tạo.

Nguyên tắc đặc biệt về an toàn trẻ:

Không tự động quy trách nhiệm cho giáo viên chỉ vì một trẻ bị ngã, ốm hoặc có sự cố khách quan. Cần xác minh việc thực hiện quy trình, mức độ trách nhiệm và những yếu tố liên quan. Nếu có dấu hiệu xâm hại trẻ hoặc vi phạm nghiêm trọng, phải ưu tiên bảo vệ trẻ, báo cáo và xử lý theo quy định, không chỉ xử lý bằng việc trừ điểm KPI.

Đối với B2.4, **không lấy tỷ lệ trẻ đạt chỉ tiêu phát triển làm điểm số trực tiếp của giáo viên**, vì đặc điểm phát triển của trẻ khác nhau. Cần chấm việc quan sát, đánh giá, điều chỉnh và hỗ trợ trẻ đúng chuyên môn.

### B3. Tiến độ hoàn thành nhiệm vụ – 10 điểm

| Mã | Công việc, yêu cầu đánh giá | Quy định mức điểm cụ thể | Minh chứng |
|--------|--------|--------|--------|
| B3.1 | **Nộp kế hoạch, hồ sơ, báo cáo đúng hạn (4đ).** | **4đ:** 100% đúng hạn. **3đ:** 1 lần trễ không quá 1 ngày. **1đ:** 2 lần trễ hoặc 1 lần trễ quá 1 ngày. **0đ:** Từ 3 lần trễ hoặc không nộp nhiệm vụ bắt buộc. | Lịch hạn nộp, thời điểm nhận hồ sơ, hệ thống điện tử. |
| B3.2 | **Bảo đảm tiến độ công việc theo kế hoạch (4đ).** Chuẩn bị, tổ chức và hoàn tất các mốc công việc đã thống nhất. | **4đ:** 100% mốc đúng hạn. **3đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch tuần, lịch công tác, nhật ký hoàn thành. |
| B3.3 | **Xử lý công việc phát sinh, nhiệm vụ đột xuất (2đ).** Phản hồi, thực hiện nhiệm vụ đúng thời hạn hợp lệ. | **2đ:** Tất cả đúng hạn. **1đ:** 1 nhiệm vụ trễ không quá 1 ngày. **0đ:** Từ 2 nhiệm vụ trễ hoặc không thực hiện nhiệm vụ hợp lệ. | Phiếu giao việc, lịch xử lý, kết quả xác nhận. |
|  | **Tổng B3** | **10 điểm** |  |

Các công việc được gia hạn hoặc điều chỉnh thời gian bằng sự chấp thuận của người có thẩm quyền được tính theo hạn mới, không xem là trễ.

### B4. Chuyên môn, phối hợp và đổi mới – 10 điểm

| Mã | Công việc, yêu cầu đánh giá | Quy định mức điểm cụ thể | Minh chứng |
|--------|--------|--------|--------|
| B4.1 | **Sinh hoạt chuyên môn, bồi dưỡng (4đ).** Tham gia hoạt động chuyên môn được phân công, có trao đổi hoặc vận dụng vào thực tế. | **4đ:** Tham gia đầy đủ và có ít nhất 1 ý kiến/góp ý hoặc sản phẩm vận dụng thiết thực. **3đ:** Tham gia đầy đủ nhưng chưa có minh chứng trao đổi, vận dụng. **1đ:** Tham gia từ 50% đến dưới 100% số buổi thuộc trách nhiệm. **0đ:** Dưới 50% không có lý do chính đáng. | Biên bản sinh hoạt, sản phẩm chuyên môn, phiếu dự giờ. |
| B4.2 | **Phối hợp chuyên môn với giáo viên cùng lớp, nhân viên liên quan (3đ).** Bàn giao thông tin trẻ, thống nhất nội dung chăm sóc và giáo dục, thực hiện công việc phối hợp. | **3đ:** Đạt 100% yêu cầu phối hợp. **2đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Sổ bàn giao, kế hoạch phối hợp, ghi nhận nhiệm vụ. |
| B4.3 | **Phối hợp với cha mẹ trẻ (3đ).** Trao đổi thông tin cần thiết, kịp thời phản hồi tình hình của trẻ và thống nhất biện pháp hỗ trợ khi cần. | **3đ:** Đủ 100% nội dung trao đổi, phối hợp bắt buộc. **2đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Sổ liên lạc, ghi nhận trao đổi, minh chứng phối hợp phù hợp. |
|  | **Tổng B4** | **10 điểm** |  |

Trong trường hợp tháng đó không tổ chức sinh hoạt chuyên môn tập trung, B4.1 được đánh giá bằng nhiệm vụ tự bồi dưỡng và chia sẻ chuyên môn đã giao thay thế. Không yêu cầu giáo viên phải có nhiều tin nhắn hoặc hình ảnh để lấy điểm phối hợp phụ huynh; chỉ đánh giá những nội dung trao đổi cần thiết và chất lượng phối hợp thực tế.

## VI. Quy định chấm điểm và xác định mức hoàn thành

### 1. Quy tắc chấm điểm thống nhất

Để tránh tình trạng mỗi tổ trưởng chấm một kiểu, tôi đề xuất đưa các nguyên tắc sau vào quy chế:

| Nội dung | Quy định áp dụng |
|--------|--------|
| Cách tính | Chấm từng mã KPI theo đúng các mức điểm đã quy định, không cho điểm ngoài các mức đó. |
| Điểm tối đa | Không vượt quá 100 điểm/tháng. Không tự ý cộng điểm thưởng ngoài thang 100. |
| Tính khối lượng | Chỉ tính nhiệm vụ thực tế được giao, đến hạn thực hiện và thuộc trách nhiệm của giáo viên. |
| Minh chứng | Kết hợp kiểm tra thực tế, hồ sơ công việc, phiếu quan sát và biên bản. Không bắt buộc tạo thêm hồ sơ chỉ để chấm KPI. |
| Giáo viên cùng lớp | Chấm theo nhiệm vụ và mức độ thực hiện của từng giáo viên; không mặc nhiên cho hai giáo viên cùng một số điểm. |
| Không có nhiệm vụ phát sinh | Sử dụng nhiệm vụ thường xuyên tương đương được xác định trước; nếu không có nhiệm vụ tương đương, phải điều chỉnh phân bổ điểm trong cùng nhóm và được phê duyệt trước khi chấm. |
| Nghỉ theo chế độ | Không trừ điểm chỉ vì giáo viên nghỉ hợp pháp. Điều chỉnh khối lượng và thời hạn công việc theo thời gian làm việc thực tế, phân công được duyệt. |
| Sai sót và vi phạm | Phải có minh chứng được xác minh. Không trừ lặp cùng một sai sót ở nhiều tiêu chí nếu không có lỗi độc lập khác. |
| Quyền giải trình | Giáo viên được biết kết quả, minh chứng trừ điểm và được trình bày ý kiến khi có khác biệt. |

Đối với nhiệm vụ phát sinh không thể dự báo, tổ trưởng phải ghi nhận việc giao nhiệm vụ và thời hạn thực hiện. Không được giao việc bổ sung sau đó dùng làm căn cứ trừ điểm hồi tố.

### 2. Quy ước mức điểm theo dõi hằng tháng

| Tổng điểm | Mức điểm theo dõi | Ý nghĩa quản trị |
|--------|--------|--------|
| 90–100 | Mức xuất sắc | Chất lượng thực hiện nổi bật, cần đối chiếu các điều kiện xếp loại. |
| 70 đến dưới 90 | Mức tốt | Thực hiện công việc đạt yêu cầu, còn một số nội dung cần cải thiện. |
| 50 đến dưới 70 | Mức hoàn thành | Cần có kế hoạch hỗ trợ, khắc phục hạn chế. |
| Dưới 50 | Mức chưa hoàn thành | Cần xem xét nguyên nhân và biện pháp quản lý phù hợp. |

Các ngưỡng điểm trên tương ứng với khung điểm tại Điều 12 Nghị định 233/2026/NĐ-CP. Tuy nhiên, **điểm KPI hằng tháng là kết quả theo dõi, không phải quyết định xếp loại viên chức chính thức hằng năm**. Việc xếp loại năm còn phải căn cứ quy chế, kết quả theo dõi trong năm và các điều kiện pháp lý liên quan. Đặc biệt, tỷ lệ xếp loại hoàn thành xuất sắc nhiệm vụ chịu giới hạn theo khoản 6 Điều 12. [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=dieu_13>); [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=dieu_13>)

## VII. Ví dụ chấm KPI cho một giáo viên thực tế

Giả sử giáo viên lớp mẫu giáo 4–5 tuổi có kết quả công tác trong tháng như sau: thực hiện phần lớn kế hoạch, tổ chức hoạt động tương đối tốt, bảo đảm an toàn trẻ, nhưng có một số nội dung chậm tiến độ hoặc chưa đạt mức tối đa.

| **Nhóm tiêu chí** | **Tối đa** | **Điểm chấm** |
|--------|--------|--------|
| **TỔNG CỘNG** | **100** | **87** |

KẾT QUẢ MINH HỌA THÁNG

# 87/100

Mức tốt

Điểm mạnh: chấp hành tốt đạo đức nghề nghiệp, giữ an toàn trẻ, hoàn thành phần lớn nhiệm vụ. Nội dung cải thiện: chất lượng tổ chức hoạt động, phối hợp chuyên môn và tiến độ.

Cách đánh giá này giúp nhà trường biết **giáo viên mất điểm ở công việc nào và cần hỗ trợ điều gì**, thay vì chỉ kết luận chung là hoàn thành tốt nhiệm vụ.

## VIII. 📋 Quy trình triển khai hằng tháng tại nhà trường

**Bước 1 – Đầu tháng: Giao nhiệm vụ và định mức**

Ban giám hiệu và tổ chuyên môn xác định số công việc phải hoàn thành, phân công rõ giáo viên chịu trách nhiệm, xác định mốc thời gian và minh chứng.

---

**Bước 2 – Trong tháng: Theo dõi thực hiện**

Tổ trưởng ghi nhận kết quả công việc, kết hợp quan sát hoạt động, kiểm tra hồ sơ và theo dõi tiến độ. Mỗi giáo viên được quan sát ít nhất hai lượt theo phương án B2.3.

---

**Bước 3 – Cuối tháng: Giáo viên tự chấm**

Giáo viên đối chiếu từng mã KPI, ghi điểm tự đánh giá và những minh chứng cần thiết.

---

**Bước 4 – Đầu tháng sau: Tổ chuyên môn đối chiếu**

Tổ trưởng hoặc người được giao theo dõi kiểm tra kết quả, trao đổi với giáo viên về chênh lệch điểm, ghi rõ lý do và đề xuất điểm duyệt.

---

**Bước 5 – Hiệu trưởng xem xét, xác nhận**

Thông báo kết quả, tiếp nhận ý kiến giải trình, xác định nội dung cần cải thiện và lưu kết quả theo dõi. Thẩm quyền quyết định xếp loại viên chức hằng năm thực hiện theo quy định.

Thời hạn cụ thể cho từng bước nên được nhà trường quy định phù hợp lịch công tác, bảo đảm giáo viên không mất quá nhiều thời gian cho việc tự chấm và chuẩn bị minh chứng.

## IX. Mẫu bảng chấm KPI để sử dụng trong Excel

Tôi chuẩn bị thêm mẫu dữ liệu gồm đầy đủ 23 mã KPI theo bảng trên. Cô có thể sao chép sang Excel để giáo viên tự chấm, tổ trưởng nhập điểm duyệt và hệ thống tự cộng điểm theo từng nhóm.

**Mẫu bảng nhập điểm KPI**

23 tiêu chí • Thang điểm 100 • Có công thức cộng điểm

Điểm chung

# 30

Điểm nhiệm vụ

# 70

[Sao chép mẫu để dán vào Excel]

Mở Excel, chọn ô A1, dán dữ liệu. Nhập điểm tại cột E và F; các dòng tổng sẽ tự tính. Nếu Excel không nhận công thức, thay dấu phẩy phân tách tham số bằng dấu chấm phẩy theo thiết lập máy.

Mẫu này là bảng dữ liệu sao chép vào Excel, không phải tệp `.xlsx` đính kèm. Phần diễn giải từng mức điểm được giữ trong các bảng chi tiết phía trên để thuận tiện đối chiếu khi chấm.

## X. ⚠️ Những vấn đề hiệu trưởng cần lưu ý trước khi ban hành

Từ thực tế quản lý trường mầm non, tôi đặc biệt đề xuất nhà trường kiểm soát các vấn đề sau:

**Thứ nhất, không để hồ sơ lấn át chất lượng chăm sóc trẻ.** Chỉ đánh giá các hồ sơ được quy định và thực sự cần thiết. Trọng tâm vẫn là hoạt động thực tế của giáo viên, sự an toàn và phát triển của trẻ.

**Thứ hai, bảo đảm công bằng giữa các nhóm lớp.** Giáo viên nhà trẻ, mẫu giáo bé và mẫu giáo lớn có tính chất công việc khác nhau. Nhà trường nên dùng chung thang 100 điểm và 23 mã KPI, nhưng cụ thể hóa số công việc phải thực hiện theo độ tuổi, số trẻ, nhiệm vụ được giao và điều kiện thực tế.

**Thứ ba, không đồng nhất tai nạn của trẻ với lỗi của giáo viên.** Mọi sự việc phải được xem xét khách quan. Hành vi vi phạm nghiêm trọng, nếu có, được xử lý theo quy định chuyên ngành và pháp luật, không thay thế bằng việc chấm điểm.

**Thứ tư, có phương án cho giáo viên nghỉ thai sản, nghỉ ốm hoặc chuyển công tác.** Việc đánh giá phải theo thời gian làm việc thực tế và các trường hợp đặc biệt quy định tại Điều 14 Nghị định 233/2026/NĐ-CP; không mặc nhiên chấm điểm 0 cho các tháng không thực tế thực hiện nhiệm vụ. [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=dieu_13>)

**Thứ năm, nên lấy ý kiến giáo viên trước khi ban hành.** Tổ chức góp ý về định mức, mức điểm, cách kiểm chứng và những tình huống ngoại lệ. Sau một hoặc hai tháng triển khai thử, có thể xem xét điều chỉnh các chi tiết trong phạm vi cho phép và theo đúng thẩm quyền.

## XI. ✅ Kết luận và đề xuất áp dụng

Tôi đề xuất nhà trường sử dụng bảng KPI trên làm **Phụ lục tiêu chí đánh giá, theo dõi kết quả thực hiện nhiệm vụ hằng tháng đối với giáo viên mầm non**, gắn với quy chế đánh giá viên chức của đơn vị.

Điểm cốt lõi không phải là giáo viên đạt 90 hay 100 điểm, mà là **mỗi điểm số phải trả lời được ba câu hỏi: Giáo viên đã làm công việc gì? Chất lượng đạt đến đâu? Minh chứng nào xác nhận kết quả đó?**

Khi triển khai đồng bộ, bảng KPI sẽ giúp hiệu trưởng nhận diện đúng năng lực đội ngũ, phát hiện những vấn đề chuyên môn cần hỗ trợ và từng bước nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ một cách thực chất.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

bạn xuất nội dung vừa trình bày ở trên sang file word nhé

---

ASSISTANT

Tôi sẽ đưa toàn bộ nội dung bảng KPI vừa xây dựng vào file Word, giữ đầy đủ các bảng tiêu chí, mức điểm, minh chứng và phần hướng dẫn áp dụng; đồng thời trình bày theo dạng phụ lục để nhà trường thuận tiện chỉnh sửa, in và ban hành.

---

ASSISTANT

---

ASSISTANT

Tôi đã biên tập nội dung bảng KPI giáo viên mầm non thành một bản tài liệu có bố cục phù hợp để đưa vào Word, gồm **23 tiêu chí chấm điểm, thang điểm 100, mức đạt cụ thể, minh chứng, quy trình đánh giá và mẫu phiếu chấm hằng tháng**.

Hiện tại, tôi chưa thể tạo và đính kèm trực tiếp tệp `.docx` trong phiên trò chuyện này. Cô có thể sao chép bản tài liệu dưới đây vào Microsoft Word và lưu thành file Word để sử dụng.

> **writing · document**
>
> # PHỤ LỤC
> ## BẢNG TIÊU CHÍ KPI ĐÁNH GIÁ KẾT QUẢ THỰC HIỆN NHIỆM VỤ HẰNG THÁNG ĐỐI VỚI GIÁO VIÊN MẦM NON
> **(Thang điểm 100 điểm)**
>
> **Đơn vị:** Trường Mầm non ...............................................
>
> **Áp dụng từ tháng:** ..................... **Năm học:** .....................
>
> ---
>
> # I. MỤC ĐÍCH, YÊU CẦU
>
> 1. Đánh giá kết quả thực hiện nhiệm vụ hằng tháng của giáo viên bảo đảm khách quan, công bằng, công khai và phù hợp với vị trí việc làm.
> 2. Cụ thể hóa từng nội dung công việc, mức độ hoàn thành, số điểm tương ứng và minh chứng đánh giá.
> 3. Làm cơ sở để hiệu trưởng, phó hiệu trưởng, tổ trưởng chuyên môn theo dõi, đánh giá chất lượng công việc; đồng thời giúp giáo viên tự đánh giá và khắc phục hạn chế.
> 4. Đề cao chất lượng chăm sóc, nuôi dưỡng, giáo dục và bảo đảm an toàn cho trẻ; hạn chế đánh giá hình thức, cảm tính.
> 5. Gắn kết quả đánh giá hằng tháng với công tác bồi dưỡng đội ngũ và việc đánh giá, xếp loại viên chức theo quy định hiện hành.
>
> # II. CĂN CỨ XÂY DỰNG
>
> - Nghị định số 233/2026/NĐ-CP ngày 26/6/2026 của Chính phủ quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức.
> - Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020 ban hành Điều lệ trường mầm non và Thông tư số 51/2026/TT-BGDĐT sửa đổi, bổ sung một số điều của Điều lệ trường mầm non.
> - Chương trình Giáo dục mầm non hiện hành.
> - Kế hoạch năm học, kế hoạch chuyên môn, phân công nhiệm vụ và quy chế đánh giá của nhà trường.
> - Khung tiêu chí 30 điểm chung và 70 điểm thực hiện nhiệm vụ đối với giáo viên.
>
> # III. CƠ CẤU ĐIỂM ĐÁNH GIÁ
>
> | STT | Nhóm tiêu chí | Điểm tối đa |
> |---|---|---:|
> | **A** | **TIÊU CHÍ CHUNG** | **30** |
> | A1 | Phẩm chất chính trị, đạo đức nghề nghiệp, ý thức kỷ luật | 15 |
> | A2 | Trách nhiệm, đoàn kết, phối hợp | 7 |
> | A3 | Tác phong, lề lối làm việc | 4 |
> | A4 | Đổi mới, sáng tạo, tự học, chuyển đổi số | 4 |
> | **B** | **KẾT QUẢ THỰC HIỆN NHIỆM VỤ** | **70** |
> | B1 | Số lượng, khối lượng nhiệm vụ | 20 |
> | B2 | Chất lượng chăm sóc, nuôi dưỡng, giáo dục | 30 |
> | B3 | Tiến độ thực hiện nhiệm vụ | 10 |
> | B4 | Chuyên môn, phối hợp, đổi mới | 10 |
> | | **TỔNG CỘNG** | **100** |
>
> # IV. BẢNG KPI CHI TIẾT – TIÊU CHÍ CHUNG (30 ĐIỂM)
>
> ## A1. Phẩm chất chính trị, đạo đức nghề nghiệp, ý thức kỷ luật (15 điểm)
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | A1.1 | Đạo đức nhà giáo, tôn trọng trẻ; đối xử công bằng, không quát mắng, xúc phạm, ép buộc trẻ. | 6 | **6đ:** Không vi phạm. **4đ:** 1 sai sót giao tiếp nhẹ, khắc phục ngay. **2đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc vi phạm nghiêm trọng đã được xác minh. | Quan sát lớp; biên bản kiểm tra; phản ánh được xác minh. |
> | A1.2 | Chấp hành pháp luật, quy chế, nội quy nhà trường và quy định nghề nghiệp. | 5 | **5đ:** Không vi phạm. **4đ:** 1 vi phạm nhẹ. **2đ:** 2–3 vi phạm nhẹ. **0đ:** Từ 4 vi phạm hoặc vi phạm nghiêm trọng. | Biên bản kiểm tra; sổ theo dõi việc chấp hành quy chế. |
> | A1.3 | Trung thực trong báo cáo, ghi chép hồ sơ; bảo mật thông tin cá nhân và hình ảnh trẻ. | 4 | **4đ:** Thực hiện đúng, đầy đủ. **3đ:** 1 sai sót không cố ý, sửa ngay. **1đ:** 2 sai sót. **0đ:** Từ 3 sai sót hoặc cố ý làm sai lệch thông tin, tiết lộ thông tin trái quy định. | Hồ sơ, báo cáo, kết quả đối chiếu, biên bản xác minh. |
> | | **Tổng A1** | **15** | | |
>
> ## A2. Trách nhiệm, đoàn kết, phối hợp (7 điểm)
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | A2.1 | Chủ động thực hiện nhiệm vụ được giao; báo cáo khó khăn, đề xuất giải pháp. | 4 | **4đ:** Chủ động, không phải nhắc. **3đ:** 1 lần phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần phải nhắc hoặc từ chối nhiệm vụ hợp lệ không có lý do chính đáng. | Sổ giao việc; ghi nhận của tổ trưởng. |
> | A2.2 | Hợp tác, đoàn kết, hỗ trợ đồng nghiệp; thực hiện trách nhiệm phối hợp. | 3 | **3đ:** Hợp tác tốt, thực hiện đầy đủ. **2đ:** 1 lần chưa phối hợp, phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần hoặc có hành vi gây mất đoàn kết được xác minh. | Biên bản sinh hoạt tổ; kết quả công việc phối hợp. |
> | | **Tổng A2** | **7** | | |
>
> ## A3. Tác phong, lề lối làm việc (4 điểm)
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | A3.1 | Chấp hành giờ làm việc, giờ nhận lớp, bàn giao ca và hoạt động bắt buộc. | 2 | **2đ:** Không đi muộn, về sớm trái quy định. **1đ:** 1 lần. **0đ:** Từ 2 lần. | Bảng chấm công; lịch trực; biên bản. |
> | A3.2 | Trang phục phù hợp, tác phong sư phạm; giao tiếp chuẩn mực với phụ huynh và đồng nghiệp. | 2 | **2đ:** Thực hiện đúng. **1đ:** 1 sai sót nhẹ đã khắc phục. **0đ:** Từ 2 sai sót hoặc vi phạm nghiêm trọng. | Kiểm tra thực tế; biên bản ghi nhận. |
> | | **Tổng A3** | **4** | | |
>
> ## A4. Đổi mới, sáng tạo, tự học và chuyển đổi số (4 điểm)
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | A4.1 | Tự học, bồi dưỡng, cập nhật kiến thức, vận dụng vào công việc. | 2 | **2đ:** Có ít nhất 1 nội dung tự học/bồi dưỡng được vận dụng. **1đ:** Có học nhưng chưa có minh chứng vận dụng. **0đ:** Không có minh chứng theo yêu cầu. | Sản phẩm bồi dưỡng; ghi nhận vận dụng. |
> | A4.2 | Vận dụng CNTT, STEAM, AI hoặc cải tiến phương pháp tổ chức hoạt động giáo dục phù hợp. | 2 | **2đ:** Có ít nhất 1 cải tiến được áp dụng, chứng minh tác dụng. **1đ:** Có thử nghiệm nhưng chưa đánh giá được hiệu quả. **0đ:** Không có cải tiến được ghi nhận. | Giáo án; học liệu; sản phẩm; minh chứng áp dụng. |
> | | **Tổng A4** | **4** | | |
>
> # V. BẢNG KPI CHI TIẾT – KẾT QUẢ THỰC HIỆN NHIỆM VỤ (70 ĐIỂM)
>
> ## B1. Số lượng, khối lượng nhiệm vụ thực hiện (20 điểm)
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Xây dựng đầy đủ kế hoạch giáo dục tháng, tuần và các kế hoạch theo phân công. | 5 | **5đ:** Hoàn thành 100%. **4đ:** Từ 90% đến dưới 100%. **2đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch giáo dục; sổ theo dõi chuyên môn. |
> | B1.2 | Tổ chức các hoạt động chăm sóc, nuôi dưỡng, giáo dục theo kế hoạch và phân công. | 8 | **8đ:** Hoàn thành 100%. **6đ:** Từ 90% đến dưới 100%. **3đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch; nhật ký hoạt động; kiểm tra thực tế. |
> | B1.3 | Thực hiện đầy đủ hồ sơ chuyên môn, hồ sơ lớp, thông tin theo dõi trẻ theo quy định. | 4 | **4đ:** Đạt 100%. **3đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Hồ sơ chuyên môn; phiếu kiểm tra. |
> | B1.4 | Thực hiện nhiệm vụ khác: trực lớp, đón trả trẻ, bảo quản đồ dùng, chuẩn bị môi trường giáo dục và nhiệm vụ chung. | 3 | **3đ:** Hoàn thành 100%. **2đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Bảng phân công; sổ trực; kết quả kiểm tra. |
> | | **Tổng B1** | **20** | | |
>
> **Cách tính tỷ lệ hoàn thành công việc:**
>
> Tỷ lệ hoàn thành (%) = Số công việc hoàn thành đạt yêu cầu / Tổng số công việc được giao hợp lệ × 100%.
>
> Ví dụ: Giáo viên được giao 40 hoạt động trong tháng, thực hiện 38 hoạt động, không có điều chỉnh kế hoạch được duyệt.
>
> Tỷ lệ hoàn thành = 38 / 40 × 100 = 95%.
>
> Kết quả B1.2: 6/8 điểm.
>
> ## B2. Chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ (30 điểm)
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | B2.1 | Bảo đảm an toàn thể chất, tinh thần cho trẻ; thực hiện đúng quy trình điểm danh, giám sát, đón trả và phát hiện nguy cơ mất an toàn. | 10 | **10đ:** Không sai sót. **7đ:** 1 sai sót thủ tục nhẹ, khắc phục ngay, chưa gây nguy hiểm. **3đ:** 2 sai sót nhẹ, đã khắc phục. **0đ:** Từ 3 sai sót hoặc 1 vi phạm nghiêm trọng về an toàn thuộc trách nhiệm giáo viên được xác minh. | Kiểm tra an toàn; sổ giao nhận trẻ; biên bản. |
> | B2.2 | Chăm sóc vệ sinh cá nhân, tổ chức ăn, ngủ, theo dõi sức khỏe và thực hiện quy trình nuôi dưỡng. | 7 | **7đ:** Thực hiện đúng, không sai sót. **5đ:** 1 sai sót nhẹ. **2đ:** 2–3 sai sót nhẹ. **0đ:** Từ 4 sai sót hoặc vi phạm nghiêm trọng được xác minh. | Kiểm tra ăn, ngủ, vệ sinh; sổ sức khỏe. |
> | B2.3 | Tổ chức hoạt động giáo dục lấy trẻ làm trung tâm; bảo đảm mục tiêu, nội dung, phương pháp phù hợp độ tuổi. | 8 | **8đ:** Đạt 9–10/10 chỉ báo. **6đ:** Đạt 7–8/10. **3đ:** Đạt 5–6/10. **0đ:** Đạt 0–4/10. | Phiếu quan sát hoạt động giáo dục. |
> | B2.4 | Theo dõi, đánh giá sự phát triển của trẻ; xác định nhu cầu và biện pháp hỗ trợ phù hợp. | 5 | **5đ:** Thực hiện 100% nội dung thuộc trách nhiệm. **4đ:** Từ 90% đến dưới 100%. **2đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Hồ sơ theo dõi trẻ; ghi nhận quan sát; kế hoạch hỗ trợ. |
> | | **Tổng B2** | **30** | | |
>
> ### Hướng dẫn chấm tiêu chí B2.3
>
> Đánh giá ít nhất 2 lượt quan sát trong tháng, mỗi lượt 5 chỉ báo; mỗi chỉ báo đạt 1 điểm, không đạt 0 điểm.
>
> | STT | Chỉ báo quan sát | Điểm tối đa/lượt |
> |---|---|---:|
> | 1 | Mục tiêu, nội dung phù hợp độ tuổi và khả năng của trẻ. | 1 |
> | 2 | Môi trường, đồ dùng, học liệu chuẩn bị phù hợp. | 1 |
> | 3 | Trẻ được lựa chọn, trải nghiệm và tham gia chủ động. | 1 |
> | 4 | Giáo viên tương tác tích cực, gợi mở, khuyến khích trẻ. | 1 |
> | 5 | Giáo viên quan sát, hỗ trợ và điều chỉnh phù hợp nhu cầu cá nhân của trẻ. | 1 |
> | | **Tổng một lượt** | **5** |
> | | **Tổng hai lượt** | **10** |
>
> Kết quả tổng hai lượt được quy đổi sang thang điểm 8 của tiêu chí B2.3.
>
> **Lưu ý:** Không lấy tỷ lệ trẻ đạt yêu cầu phát triển làm điểm trực tiếp của giáo viên. Việc đánh giá cần chú trọng chất lượng quan sát, hỗ trợ và tổ chức hoạt động phù hợp với từng trẻ.
>
> ## B3. Tiến độ hoàn thành nhiệm vụ (10 điểm)
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | B3.1 | Nộp kế hoạch, hồ sơ, báo cáo đúng thời hạn. | 4 | **4đ:** 100% đúng hạn. **3đ:** 1 lần trễ không quá 1 ngày. **1đ:** 2 lần trễ hoặc 1 lần trễ quá 1 ngày. **0đ:** Từ 3 lần trễ hoặc không nộp nhiệm vụ bắt buộc. | Lịch hạn nộp; thời điểm tiếp nhận. |
> | B3.2 | Bảo đảm tiến độ chuẩn bị, tổ chức và hoàn thành công việc theo kế hoạch. | 4 | **4đ:** Đúng hạn 100%. **3đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch; lịch công tác; nhật ký công việc. |
> | B3.3 | Thực hiện nhiệm vụ đột xuất, xử lý công việc phát sinh đúng thời hạn hợp lệ. | 2 | **2đ:** Tất cả đúng hạn. **1đ:** 1 nhiệm vụ trễ không quá 1 ngày. **0đ:** Từ 2 nhiệm vụ trễ hoặc không thực hiện nhiệm vụ hợp lệ. | Phiếu giao việc; kết quả xác nhận. |
> | | **Tổng B3** | **10** | | |
>
> ## B4. Chuyên môn, phối hợp và đổi mới (10 điểm)
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | B4.1 | Tham gia sinh hoạt chuyên môn, bồi dưỡng, chia sẻ kinh nghiệm và vận dụng thực tế. | 4 | **4đ:** Tham gia đầy đủ, có ít nhất 1 ý kiến/góp ý hoặc sản phẩm vận dụng. **3đ:** Tham gia đầy đủ nhưng chưa có minh chứng trao đổi, vận dụng. **1đ:** Tham gia từ 50% đến dưới 100% số buổi thuộc trách nhiệm. **0đ:** Dưới 50% không có lý do chính đáng. | Biên bản sinh hoạt; sản phẩm chuyên môn. |
> | B4.2 | Phối hợp giáo viên cùng lớp, nhân viên liên quan; bàn giao thông tin và thực hiện công việc phối hợp. | 3 | **3đ:** Hoàn thành 100%. **2đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Sổ bàn giao; kế hoạch phối hợp. |
> | B4.3 | Phối hợp với cha mẹ trẻ; trao đổi thông tin cần thiết, kịp thời hỗ trợ trẻ. | 3 | **3đ:** Đạt 100% yêu cầu. **2đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Sổ liên lạc; ghi nhận trao đổi, phối hợp. |
> | | **Tổng B4** | **10** | | |
>
> # VI. NGUYÊN TẮC CHẤM ĐIỂM VÀ XẾP MỨC THEO DÕI
>
> ## 1. Nguyên tắc chấm điểm
>
> 1. Giáo viên tự chấm điểm theo từng tiêu chí, có minh chứng phù hợp.
> 2. Tổ trưởng chuyên môn đối chiếu khối lượng, chất lượng công việc và xác định điểm đề xuất.
> 3. Hiệu trưởng hoặc người được phân công xem xét, xác nhận kết quả.
> 4. Không cho điểm vượt mức tối đa của từng tiêu chí.
> 5. Việc trừ điểm phải dựa trên sai sót, vi phạm đã được xác minh; không trừ điểm theo cảm tính.
> 6. Không trừ lặp một sai sót ở nhiều tiêu chí khi không có lỗi độc lập khác.
> 7. Không xem việc nghỉ theo chế độ hợp pháp là vi phạm. Khối lượng nhiệm vụ phải được điều chỉnh phù hợp với thời gian làm việc thực tế.
> 8. Đối với tiêu chí không phát sinh nhiệm vụ, nhà trường phải có phương án điều chỉnh, thay thế hợp lý được phê duyệt trước khi chấm.
> 9. Giáo viên được thông báo kết quả, giải trình và đề nghị xem xét khi có nội dung chưa thống nhất.
>
> ## 2. Mức điểm theo dõi hằng tháng
>
> | Tổng điểm KPI | Mức theo dõi | Yêu cầu quản lý |
> |---|---|---|
> | 90–100 | Mức xuất sắc | Duy trì chất lượng nổi bật, đối chiếu điều kiện pháp lý khi xếp loại chính thức. |
> | 70 đến dưới 90 | Mức tốt | Phát huy điểm mạnh, khắc phục nội dung còn hạn chế. |
> | 50 đến dưới 70 | Mức hoàn thành | Xây dựng kế hoạch hỗ trợ, cải thiện chất lượng công việc. |
> | Dưới 50 | Mức chưa hoàn thành | Phân tích nguyên nhân, xác định biện pháp hỗ trợ và xử lý phù hợp. |
>
> **Chú ý:** Đây là các mức theo dõi kết quả KPI hằng tháng. Việc đánh giá, xếp loại chất lượng viên chức chính thức thực hiện theo quy chế của đơn vị và quy định pháp luật hiện hành.
>
> # VII. VÍ DỤ MINH HỌA KẾT QUẢ ĐÁNH GIÁ
>
> Giáo viên lớp mẫu giáo 4–5 tuổi có kết quả công việc như sau:
>
> | Nhóm tiêu chí | Điểm tối đa | Điểm đạt |
> |---|---:|---:|
> | A1. Phẩm chất, đạo đức, kỷ luật | 15 | 15 |
> | A2. Trách nhiệm, đoàn kết | 7 | 6 |
> | A3. Tác phong, lề lối | 4 | 4 |
> | A4. Đổi mới, tự học | 4 | 3 |
> | B1. Khối lượng công việc | 20 | 18 |
> | B2. Chất lượng chăm sóc, giáo dục | 30 | 25 |
> | B3. Tiến độ | 10 | 9 |
> | B4. Chuyên môn, phối hợp | 10 | 7 |
> | **TỔNG CỘNG** | **100** | **87** |
>
> **Kết quả:** 87/100 điểm – Mức tốt.
>
> **Điểm mạnh:** Chấp hành tốt đạo đức nghề nghiệp, bảo đảm an toàn trẻ, hoàn thành phần lớn nhiệm vụ.
>
> **Nội dung cần cải thiện:** Chất lượng một số hoạt động giáo dục, phối hợp chuyên môn và tiến độ hoàn thành công việc.
>
> # VIII. QUY TRÌNH TỔ CHỨC ĐÁNH GIÁ HẰNG THÁNG
>
> **Bước 1. Giao nhiệm vụ đầu tháng**
>
> Ban giám hiệu và tổ chuyên môn xác định công việc, chỉ tiêu, thời hạn và trách nhiệm của từng giáo viên.
>
> **Bước 2. Theo dõi trong tháng**
>
> Tổ trưởng chuyên môn, ban giám hiệu theo dõi tiến độ, chất lượng công việc, quan sát hoạt động, ghi nhận các kết quả và sai sót có minh chứng.
>
> **Bước 3. Giáo viên tự đánh giá**
>
> Cuối tháng, giáo viên tự đối chiếu từng tiêu chí, ghi mức điểm đạt được và minh chứng phù hợp.
>
> **Bước 4. Tổ chuyên môn đánh giá**
>
> Tổ trưởng xem xét kết quả, đối chiếu minh chứng, trao đổi với giáo viên và đề xuất điểm đánh giá.
>
> **Bước 5. Hiệu trưởng xác nhận**
>
> Hiệu trưởng hoặc người được phân công xem xét, xác nhận điểm; thông báo kết quả, tiếp nhận giải trình và chỉ đạo biện pháp hỗ trợ, cải thiện.
>
> # IX. MẪU PHIẾU CHẤM KPI GIÁO VIÊN HẰNG THÁNG
>
> **TRƯỜNG MẦM NON:** ........................................................
>
> **PHIẾU ĐÁNH GIÁ KPI GIÁO VIÊN THÁNG ........ NĂM ........**
>
> Họ và tên giáo viên: ...........................................................
>
> Lớp: ............................. Tổ chuyên môn: .............................
>
> | Mã KPI | Nội dung đánh giá | Điểm tối đa | GV tự chấm | Điểm duyệt |
> |---|---|---:|---:|---:|
> | A1.1 | Đạo đức nhà giáo, tôn trọng trẻ | 6 | | |
> | A1.2 | Chấp hành pháp luật, quy chế, nội quy | 5 | | |
> | A1.3 | Trung thực, bảo mật thông tin | 4 | | |
> | A2.1 | Tinh thần trách nhiệm | 4 | | |
> | A2.2 | Đoàn kết, hỗ trợ đồng nghiệp | 3 | | |
> | A3.1 | Chấp hành giờ giấc | 2 | | |
> | A3.2 | Tác phong, giao tiếp | 2 | | |
> | A4.1 | Tự học, bồi dưỡng | 2 | | |
> | A4.2 | Cải tiến hoạt động giáo dục | 2 | | |
> | | **CỘNG NHÓM A** | **30** | | |
> | B1.1 | Xây dựng kế hoạch giáo dục | 5 | | |
> | B1.2 | Thực hiện hoạt động chăm sóc, giáo dục | 8 | | |
> | B1.3 | Hoàn thành hồ sơ chuyên môn | 4 | | |
> | B1.4 | Thực hiện nhiệm vụ phân công khác | 3 | | |
> | B2.1 | Bảo đảm an toàn cho trẻ | 10 | | |
> | B2.2 | Chăm sóc, vệ sinh, ăn, ngủ, sức khỏe | 7 | | |
> | B2.3 | Chất lượng tổ chức hoạt động giáo dục | 8 | | |
> | B2.4 | Theo dõi, đánh giá và hỗ trợ trẻ | 5 | | |
> | B3.1 | Nộp kế hoạch, hồ sơ, báo cáo đúng hạn | 4 | | |
> | B3.2 | Bảo đảm tiến độ công việc | 4 | | |
> | B3.3 | Xử lý nhiệm vụ phát sinh | 2 | | |
> | B4.1 | Sinh hoạt chuyên môn, bồi dưỡng | 4 | | |
> | B4.2 | Phối hợp giáo viên, nhân viên liên quan | 3 | | |
> | B4.3 | Phối hợp cha mẹ trẻ | 3 | | |
> | | **CỘNG NHÓM B** | **70** | | |
> | | **TỔNG CỘNG** | **100** | | |
>
> **Mức điểm theo dõi:** ...............................................
>
> **1. Ưu điểm:**
>
> ....................................................................................
>
> ....................................................................................
>
> **2. Tồn tại, hạn chế:**
>
> ....................................................................................
>
> ....................................................................................
>
> **3. Nội dung cần khắc phục trong tháng tiếp theo:**
>
> ....................................................................................
>
> ....................................................................................
>
> **4. Ý kiến của giáo viên (nếu có):**
>
> ....................................................................................
>
> ....................................................................................
>
> | GIÁO VIÊN TỰ ĐÁNH GIÁ | TỔ TRƯỞNG CHUYÊN MÔN | HIỆU TRƯỞNG |
> |---|---|---|
> | (Ký, ghi rõ họ tên) | (Ký, ghi rõ họ tên) | (Ký, ghi rõ họ tên) |
> | | | |
> | | | |
>
> # X. LƯU Ý KHI TRIỂN KHAI
>
> 1. Không dùng số lượng hồ sơ làm tiêu chí thay thế chất lượng chăm sóc, giáo dục trẻ.
> 2. Phải xác định rõ trách nhiệm của từng giáo viên khi có hai hoặc nhiều giáo viên cùng phụ trách lớp.
> 3. Bảo đảm công bằng giữa giáo viên các độ tuổi, nhóm lớp, điều kiện thực tế và khối lượng nhiệm vụ được giao.
> 4. Các vụ việc liên quan đến an toàn trẻ phải được xác minh khách quan; không tự động quy lỗi cho giáo viên khi trẻ gặp tai nạn hoặc có sự cố khách quan.
> 5. Không yêu cầu giáo viên thực hiện thêm hồ sơ, chụp ảnh hoặc báo cáo không cần thiết chỉ nhằm lấy điểm KPI.
> 6. Đối với nghỉ thai sản, nghỉ ốm và các trường hợp đặc biệt, phải áp dụng quy định pháp luật và nguyên tắc đánh giá phù hợp.
> 7. Tổ chức lấy ý kiến giáo viên, tổ chuyên môn và các bộ phận liên quan trước khi ban hành chính thức.
> 8. Định kỳ rà soát mức độ phù hợp của bộ tiêu chí, điều chỉnh theo thẩm quyền để bảo đảm tính khả thi.
>
> # XI. KẾT LUẬN
>
> Bảng KPI đánh giá giáo viên hằng tháng được xây dựng trên cơ sở phân bổ 30 điểm tiêu chí chung và 70 điểm kết quả thực hiện nhiệm vụ, với 23 chỉ tiêu cụ thể.
>
> Việc tổ chức đánh giá phải dựa trên kết quả thực hiện công việc, mức độ hoàn thành, chất lượng thực tế và minh chứng có thể kiểm tra.
>
> Kết quả KPI hằng tháng được sử dụng để theo dõi, hỗ trợ, bồi dưỡng, nâng cao chất lượng đội ngũ và làm nguồn thông tin phục vụ đánh giá viên chức theo quy định.
>
> **Yêu cầu xuyên suốt:** Đánh giá đúng người, đúng việc, công bằng, khách quan, công khai; lấy chất lượng chăm sóc, nuôi dưỡng, giáo dục và sự an toàn, phát triển của trẻ làm trọng tâm.

**Gợi ý định dạng khi đưa vào Word:** Khổ giấy A4, phông Times New Roman, cỡ chữ 12–13; các bảng KPI chi tiết nên đặt trang ngang để dễ đọc, phần phiếu chấm có thể in riêng để sử dụng hằng tháng.

Tôi đã đối chiếu hai căn cứ pháp lý chính với Công báo Chính phủ: Nghị định 233/2026/NĐ-CP và Thông tư 51/2026/TT-BGDĐT. [Source unavailable: turn851789search4]; [Source unavailable: turn851789search1]

---

USER

bạn thực hiện tiếp của nhân viên và CBQL nhé

---

ASSISTANT

Tôi sẽ xây dựng tiếp hai bộ KPI hằng tháng cho **nhân viên** và **cán bộ quản lý**, giữ đúng cơ cấu 30 điểm chung và 70 điểm nhiệm vụ trong quy chế cô gửi. Phần nhân viên sẽ có tiêu chí riêng theo từng vị trí việc làm; phần cán bộ quản lý sẽ phân biệt trách nhiệm của hiệu trưởng và phó hiệu trưởng, với mức điểm và minh chứng cụ thể.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# BỘ TIÊU CHÍ KPI ĐÁNH GIÁ HẰNG THÁNG ĐỐI VỚI NHÂN VIÊN VÀ CÁN BỘ QUẢN LÝ TRƯỜNG MẦM NON

Tôi xây dựng tiếp hai phụ lục theo đúng khung quy chế cô đã cung cấp, thống nhất với bộ KPI giáo viên trước đó.

| Đối tượng | Tiêu chí chung | Kết quả nhiệm vụ | Tổng điểm |
|--------|--------|--------|--------|
| Nhân viên | 30 | 70 | **100** |
| Cán bộ quản lý (CBQL) | 30 | 70 | **100** |

Điểm khác biệt quan trọng là **nhân viên phải được đánh giá theo vị trí việc làm, còn CBQL phải được đánh giá theo kết quả quản lý và phạm vi trách nhiệm**.

Tôi cụ thể hóa cho nhân viên nuôi dưỡng, y tế, kế toán, văn thư, thủ quỹ, bảo vệ và phục vụ vệ sinh; đối với CBQL, phân biệt hiệu trưởng, phó hiệu trưởng phụ trách chuyên môn và phó hiệu trưởng phụ trách nuôi dưỡng, cơ sở vật chất.

Bộ tiêu chí này được xây dựng để đưa vào phụ lục quy chế đánh giá của trường. Căn cứ pháp lý chính là Nghị định 233/2026/NĐ-CP, trong đó quy định theo dõi viên chức theo tháng hoặc quý, gắn với sản phẩm, chất lượng và tiến độ công việc; việc cụ thể hóa điểm do đơn vị quy định. [Nghị định số 233/2026/NĐ\-CP của Chính phủ: Quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức](<https://vanban.chinhphu.vn/?classid=1&docid=218616&pageid=27160>); [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=dieu_13>)

**Lưu ý về đối tượng:** Nhân viên là viên chức áp dụng quy định đánh giá viên chức; nhân viên làm việc theo hợp đồng lao động có thể sử dụng bảng KPI để đánh giá nội bộ nếu phù hợp hợp đồng và quy chế của đơn vị, nhưng không tự động áp dụng cơ chế xếp loại viên chức.

---

## PHỤ LỤC 02 – Bảng KPI dành cho nhân viên mầm non

Bảng dưới đây sử dụng **một thang điểm chung nhưng có nội dung nhiệm vụ riêng cho từng vị trí**, giúp tránh việc đánh giá nhân viên cấp dưỡng, kế toán, y tế hoặc bảo vệ bằng những tiêu chí không thuộc chức trách của họ.

> **writing · document**
>
> # PHỤ LỤC 02
> ## BẢNG TIÊU CHÍ KPI ĐÁNH GIÁ KẾT QUẢ THỰC HIỆN NHIỆM VỤ HẰNG THÁNG ĐỐI VỚI NHÂN VIÊN TRƯỜNG MẦM NON
> **(Thang điểm 100 điểm)**
>
> **Đơn vị:** Trường Mầm non ..............................................
>
> **Áp dụng từ tháng:** ................... **Năm học:** ...................
>
> ---
>
> # I. MỤC ĐÍCH, YÊU CẦU
>
> 1. Đánh giá thực chất kết quả làm việc của từng nhân viên theo vị trí việc làm, nhiệm vụ và trách nhiệm được giao.
> 2. Xác định rõ khối lượng công việc, chất lượng thực hiện, tiến độ, trách nhiệm phối hợp và minh chứng đánh giá.
> 3. Bảo đảm sự công bằng giữa các vị trí; không dùng nhiệm vụ chuyên môn của vị trí này để đánh giá vị trí khác.
> 4. Chú trọng tính chính xác, an toàn, hiệu quả, kỷ luật lao động và chất lượng phục vụ hoạt động của nhà trường.
> 5. Sử dụng kết quả theo dõi để bồi dưỡng, điều chỉnh phân công, cải tiến quy trình và làm căn cứ quản lý phù hợp với từng loại quan hệ làm việc.
>
> # II. CƠ CẤU ĐIỂM
>
> | STT | Nhóm tiêu chí | Điểm |
> |---|---|---:|
> | A | TIÊU CHÍ CHUNG | **30** |
> | A1 | Phẩm chất, đạo đức nghề nghiệp, ý thức kỷ luật | 15 |
> | A2 | Trách nhiệm, đoàn kết, phối hợp | 7 |
> | A3 | Tác phong, lề lối làm việc | 4 |
> | A4 | Đổi mới, sáng tạo, tự học, chuyển đổi số | 4 |
> | B | KẾT QUẢ THỰC HIỆN NHIỆM VỤ | **70** |
> | B1 | Số lượng, khối lượng công việc | 20 |
> | B2 | Chất lượng, hiệu quả công việc | 30 |
> | B3 | Tiến độ thực hiện | 10 |
> | B4 | Phối hợp, phục vụ, cải tiến | 10 |
> | | **TỔNG CỘNG** | **100** |
>
> # III. TIÊU CHÍ CHUNG ÁP DỤNG CHO NHÂN VIÊN (30 ĐIỂM)
>
> ## A1. Phẩm chất, đạo đức nghề nghiệp, ý thức kỷ luật – 15 điểm
>
> | Mã | Nội dung công việc | Điểm tối đa | Các mức điểm cụ thể | Minh chứng |
> |---|---|---:|---|---|
> | A1.1 | Trung thực, liêm chính, có đạo đức nghề nghiệp; tôn trọng trẻ, đồng nghiệp, phụ huynh. | 6 | **6đ:** Không có vi phạm. **4đ:** 1 sai sót ứng xử nhẹ, được xác minh, đã khắc phục. **2đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc 1 vi phạm nghiêm trọng được xác minh. | Kiểm tra; biên bản; phản ánh đã xác minh. |
> | A1.2 | Chấp hành pháp luật, nội quy, quy chế và quy trình nghiệp vụ của nhà trường. | 5 | **5đ:** Không vi phạm. **4đ:** 1 vi phạm nhẹ. **2đ:** 2–3 vi phạm nhẹ. **0đ:** Từ 4 vi phạm hoặc vi phạm nghiêm trọng. | Kiểm tra nội bộ; sổ theo dõi; biên bản. |
> | A1.3 | Trung thực trong ghi chép, báo cáo; giữ bí mật thông tin, bảo vệ tài sản và dữ liệu được giao. | 4 | **4đ:** Đúng, đủ. **3đ:** 1 sai sót không cố ý đã khắc phục. **1đ:** 2 sai sót. **0đ:** Từ 3 sai sót hoặc cố ý báo cáo sai, tiết lộ thông tin trái quy định. | Hồ sơ; dữ liệu; kiểm tra, đối chiếu. |
> | | **TỔNG A1** | **15** | | |
>
> ## A2. Trách nhiệm, đoàn kết, phối hợp – 7 điểm
>
> | Mã | Nội dung công việc | Điểm tối đa | Các mức điểm cụ thể | Minh chứng |
> |---|---|---:|---|---|
> | A2.1 | Chủ động thực hiện nhiệm vụ; phát hiện khó khăn, báo cáo và đề xuất hướng xử lý. | 4 | **4đ:** Chủ động, không phải nhắc. **3đ:** 1 lần phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần phải nhắc hoặc không thực hiện nhiệm vụ hợp lệ không có lý do chính đáng. | Sổ giao việc; nhật ký công tác. |
> | A2.2 | Phối hợp, hỗ trợ đồng nghiệp, thực hiện trách nhiệm trong công việc chung. | 3 | **3đ:** Phối hợp đầy đủ. **2đ:** 1 lần chưa phối hợp, phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần hoặc cố ý cản trở công việc được xác minh. | Phân công công việc; nhận xét có căn cứ. |
> | | **TỔNG A2** | **7** | | |
>
> ## A3. Tác phong, lề lối làm việc – 4 điểm
>
> | Mã | Nội dung công việc | Điểm tối đa | Các mức điểm cụ thể | Minh chứng |
> |---|---|---:|---|---|
> | A3.1 | Thực hiện đúng giờ làm việc, lịch trực, thời gian bàn giao. | 2 | **2đ:** Không vi phạm giờ giấc. **1đ:** 1 lần đi muộn hoặc về sớm trái quy định. **0đ:** Từ 2 lần. | Chấm công; lịch trực; biên bản. |
> | A3.2 | Trang phục, tác phong, giao tiếp đúng chuẩn mực của vị trí việc làm. | 2 | **2đ:** Thực hiện đúng. **1đ:** 1 sai sót nhẹ. **0đ:** Từ 2 sai sót hoặc vi phạm nghiêm trọng đã xác minh. | Quan sát; kiểm tra; phản ánh đã xác minh. |
> | | **TỔNG A3** | **4** | | |
>
> ## A4. Đổi mới, sáng tạo, tự học, chuyển đổi số – 4 điểm
>
> | Mã | Nội dung công việc | Điểm tối đa | Các mức điểm cụ thể | Minh chứng |
> |---|---|---:|---|---|
> | A4.1 | Tự học, cập nhật nghiệp vụ, thực hành quy trình mới theo vị trí được phân công. | 2 | **2đ:** Có ít nhất 1 nội dung được vận dụng. **1đ:** Có học nhưng chưa có minh chứng vận dụng. **0đ:** Không thực hiện nhiệm vụ tự bồi dưỡng đã giao. | Ghi nhận bồi dưỡng; kết quả thực hành. |
> | A4.2 | Cải tiến thao tác, sử dụng công nghệ phù hợp hoặc có biện pháp tiết kiệm, nâng cao hiệu quả công việc. | 2 | **2đ:** Có ít nhất 1 cải tiến được áp dụng, ghi nhận hiệu quả. **1đ:** Có thử nghiệm nhưng chưa đánh giá được hiệu quả. **0đ:** Không có hoạt động cải tiến được ghi nhận. | Sản phẩm; quy trình được điều chỉnh; ghi nhận áp dụng. |
> | | **TỔNG A4** | **4** | | |
>
> # IV. QUY ƯỚC CHẤM ĐIỂM NHÓM NHIỆM VỤ (70 ĐIỂM)
>
> Để bảo đảm các vị trí được đánh giá thống nhất nhưng không phải lặp lại một thang điểm quá nhiều lần, sử dụng ba loại thang điểm:
>
> **1. Thang L – Khối lượng, tỷ lệ hoàn thành**
>
> Tỷ lệ hoàn thành được tính bằng số công việc hoàn thành đạt yêu cầu chia tổng số công việc hợp lệ đến hạn theo phân công, nhân 100%.
>
> | Mã thang | Đạt 100% | Từ 90% đến dưới 100% | Từ 70% đến dưới 90% | Dưới 70% |
> |---|---:|---:|---:|---:|
> | L12 | 12 | 9 | 5 | 0 |
> | L10 | 10 | 8 | 4 | 0 |
> | L8 | 8 | 6 | 3 | 0 |
> | L6 | 6 | 4 | 2 | 0 |
> | L4 | 4 | 3 | 1 | 0 |
>
> **2. Thang Q – Chất lượng và tuân thủ quy trình**
>
> | Mã thang | Không sai sót được xác minh | 1 sai sót nhẹ, đã khắc phục | 2 sai sót nhẹ, đã khắc phục | Từ 3 sai sót hoặc 1 vi phạm nghiêm trọng được xác minh |
> |---|---:|---:|---:|---:|
> | Q12 | 12 | 9 | 5 | 0 |
> | Q10 | 10 | 7 | 3 | 0 |
> | Q8 | 8 | 6 | 3 | 0 |
> | Q6 | 6 | 4 | 2 | 0 |
> | Q4 | 4 | 3 | 1 | 0 |
>
> Sai sót nhẹ là lỗi không làm mất an toàn, không gây thiệt hại đáng kể, có thể khắc phục ngay và không thuộc hành vi bị nghiêm cấm. Lỗi nghiêm trọng phải được xem xét theo quy định chuyên ngành, mức độ rủi ro, hậu quả và trách nhiệm đã xác minh.
>
> **3. Thang T – Tiến độ công việc**
>
> | Mã thang | Tất cả đúng hạn | 1 lần trễ không quá 1 ngày | 2 lần trễ hoặc 1 lần trễ quá 1 ngày | Từ 3 lần trễ hoặc bỏ nhiệm vụ bắt buộc |
> |---|---:|---:|---:|---:|
> | T6 | 6 | 4 | 2 | 0 |
> | T4 | 4 | 3 | 1 | 0 |
>
> Chỉ tính chậm trễ do trách nhiệm cá nhân. Những nhiệm vụ được gia hạn hợp lệ, không phát sinh hoặc không thuộc trách nhiệm người được chấm phải được điều chỉnh danh mục đánh giá trước khi tổng hợp.
>
> **Thang S6 – Xử lý tình huống khẩn cấp:** 6 điểm khi thực hiện đầy đủ, kịp thời các bước thuộc trách nhiệm; 3 điểm khi có một chậm trễ thủ tục không ảnh hưởng an toàn đã được khắc phục; 0 điểm khi có sai phạm nghiêm trọng về xử lý, thông báo nguy cơ thuộc trách nhiệm đã được xác minh.
>
> # V. KPI THEO TỪNG VỊ TRÍ NHÂN VIÊN
>
> ## 1. NHÂN VIÊN NUÔI DƯỠNG, CẤP DƯỠNG – 70 ĐIỂM
>
> | Mã | Công việc phải thực hiện, cách kiểm tra | Điểm tối đa | Thang chấm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Thực hiện đủ các ca chế biến, bữa ăn và công đoạn được phân công theo thực đơn, số trẻ ăn thực tế. | 12 | L12 | Lịch bếp; phân công ca; nhật ký chế biến. |
> | B1.2 | Thực hiện đủ việc tiếp nhận thực phẩm, sơ chế, chia suất, thu dọn theo phân công trong các ngày làm việc. | 8 | L8 | Phiếu giao nhận; phân công nhiệm vụ. |
> | **B1** | **Số lượng, khối lượng nhiệm vụ** | **20** | | |
> | B2.1 | Thực hiện đúng quy trình vệ sinh an toàn thực phẩm, vệ sinh cá nhân, bảo hộ, tách thực phẩm sống – chín, phòng ngừa nhiễm chéo. | 12 | Q12 | Phiếu kiểm tra bếp; biên bản kiểm tra thực tế. |
> | B2.2 | Chế biến đúng thực đơn được duyệt, định lượng theo phân công; chia suất đúng, thực hiện kiểm thực và lưu mẫu thức ăn khi được giao. | 10 | Q10 | Thực đơn; sổ giao nhận; hồ sơ kiểm thực, lưu mẫu. |
> | B2.3 | Vệ sinh, khử khuẩn dụng cụ, bảo quản thực phẩm, bố trí khu vực bếp và thu gom rác đúng quy định. | 8 | Q8 | Kiểm tra bếp; checklist vệ sinh. |
> | **B2** | **Chất lượng, hiệu quả thực hiện** | **30** | | |
> | B3.1 | Chế biến, hoàn thành và bàn giao suất ăn đúng lịch; không làm chậm bữa ăn do lỗi cá nhân. | 6 | T6 | Lịch ăn; sổ giao nhận; biên bản nếu có. |
> | B3.2 | Ghi nhận kiểm thực, lưu mẫu, giao nhận và hoàn tất công việc trong thời hạn được giao. | 4 | T4 | Sổ bếp; thời gian ghi nhận. |
> | **B3** | **Tiến độ** | **10** | | |
> | B4.1 | Phối hợp giáo viên, nhân viên y tế, các thành viên tổ bếp trong các nhiệm vụ đã được phân công. | 6 | L6 | Sổ giao việc; ghi nhận phối hợp. |
> | B4.2 | Thực hiện các nội dung cải tiến, tiết kiệm nguyên liệu, giảm hao hụt, bảo quản tài sản theo kế hoạch của tổ bếp. | 4 | L4 | Phiếu theo dõi; kết quả cải tiến. |
> | **B4** | **Phối hợp, phục vụ, cải tiến** | **10** | | |
> | | **TỔNG CỘNG** | **70** | | |
>
> **Ví dụ chấm thực tế:**
>
> Trong tháng có 22 ngày phục vụ bữa ăn, nhân viên được giao 22 ca bếp và thực hiện đầy đủ: B1.1 đạt 12 điểm. Kiểm tra vệ sinh phát hiện một sai sót nhẹ, có biên bản và đã khắc phục: B2.1 đạt 9 điểm. Một lần bàn giao suất ăn trễ do lỗi cá nhân không quá 1 ngày: B3.1 đạt 4 điểm.
>
> Không tự động trừ điểm nhân viên khi một trẻ ăn ít, thực phẩm giao từ nhà cung cấp không đúng số lượng hoặc xảy ra sự cố ngoài phạm vi kiểm soát của nhân viên. Phải xác định đúng trách nhiệm từng bộ phận.
>
> ## 2. NHÂN VIÊN Y TẾ TRƯỜNG HỌC – 70 ĐIỂM
>
> | Mã | Công việc phải thực hiện, cách kiểm tra | Điểm tối đa | Thang chấm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Thực hiện đầy đủ các hoạt động theo dõi sức khỏe, cân đo, quản lý thông tin sức khỏe, chăm sóc ban đầu theo kế hoạch tháng. | 12 | L12 | Kế hoạch y tế; hồ sơ sức khỏe; nhật ký công việc. |
> | B1.2 | Hoàn thành nội dung truyền thông, kiểm tra vệ sinh, phòng chống dịch bệnh, tham mưu y tế theo phân công. | 8 | L8 | Kế hoạch; sản phẩm truyền thông; biên bản kiểm tra. |
> | **B1** | **Số lượng, khối lượng nhiệm vụ** | **20** | | |
> | B2.1 | Thực hiện đúng quy trình sơ cứu, chăm sóc sức khỏe ban đầu; ghi nhận và chuyển tuyến theo thẩm quyền, không thực hiện vượt phạm vi chuyên môn. | 12 | Q12 | Hồ sơ xử lý; kiểm tra thực tế; biên bản. |
> | B2.2 | Theo dõi dấu hiệu bất thường, nguy cơ dịch bệnh, trẻ cần quan tâm; thực hiện biện pháp phòng ngừa, hướng dẫn phối hợp. | 10 | Q10 | Hồ sơ theo dõi; nhật ký kiểm tra. |
> | B2.3 | Quản lý tủ thuốc, vật tư y tế, hạn sử dụng, thông tin sức khỏe và hồ sơ chuyên môn đúng quy định. | 8 | Q8 | Kiểm kê thuốc; sổ vật tư; hồ sơ y tế. |
> | **B2** | **Chất lượng, hiệu quả thực hiện** | **30** | | |
> | B3.1 | Tiếp nhận, phản hồi, báo cáo và xử lý các tình huống sức khỏe, an toàn khẩn cấp đúng thời điểm và quy trình thuộc trách nhiệm. | 6 | S6 | Nhật ký xử lý; biên bản sự việc. |
> | B3.2 | Hoàn thành các báo cáo, tổng hợp thông tin sức khỏe và công việc định kỳ đúng hạn. | 4 | T4 | Lịch báo cáo; thời điểm nộp. |
> | **B3** | **Tiến độ** | **10** | | |
> | B4.1 | Phối hợp giáo viên, phụ huynh, nhân viên nuôi dưỡng và cơ sở y tế theo nhiệm vụ phát sinh, kế hoạch được giao. | 6 | L6 | Nhật ký phối hợp; ghi nhận trao đổi. |
> | B4.2 | Thực hiện các buổi hướng dẫn hoặc nội dung tư vấn về vệ sinh, chăm sóc sức khỏe, phòng bệnh được phân công. | 4 | L4 | Tài liệu; biên bản; sản phẩm hướng dẫn. |
> | **B4** | **Phối hợp, phục vụ, cải tiến** | **10** | | |
> | | **TỔNG CỘNG** | **70** | | |
>
> **Lưu ý:** Không chấm điểm nhân viên y tế dựa đơn thuần vào số trẻ bị ốm hoặc số ca mắc bệnh, vì những kết quả này chịu ảnh hưởng nhiều yếu tố. Cần chấm khả năng phát hiện, phòng ngừa, xử lý và phối hợp đúng quy trình, đúng thẩm quyền.
>
> ## 3. NHÂN VIÊN KẾ TOÁN – 70 ĐIỂM
>
> | Mã | Công việc phải thực hiện, cách kiểm tra | Điểm tối đa | Thang chấm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Tiếp nhận, kiểm tra và xử lý đủ chứng từ, nghiệp vụ kế toán phát sinh hợp lệ thuộc trách nhiệm trong tháng. | 12 | L12 | Sổ kế toán; chứng từ; danh mục công việc. |
> | B1.2 | Lập đầy đủ các bảng tổng hợp, báo cáo thu chi, dự toán, quyết toán và số liệu đến kỳ phải thực hiện. | 8 | L8 | Báo cáo; kế hoạch; phân công nhiệm vụ. |
> | **B1** | **Số lượng, khối lượng nhiệm vụ** | **20** | | |
> | B2.1 | Hạch toán, kiểm tra chứng từ đúng quy định; bảo đảm tính chính xác, hợp pháp của dữ liệu và nghiệp vụ thuộc trách nhiệm. | 12 | Q12 | Chứng từ; sổ kế toán; kết quả kiểm tra. |
> | B2.2 | Đối chiếu số liệu với thủ quỹ, ngân hàng, bộ phận liên quan; kiểm soát khoản thu, chi, công nợ, tạm ứng theo nhiệm vụ. | 10 | Q10 | Biên bản đối chiếu; sổ chi tiết. |
> | B2.3 | Lưu trữ hồ sơ kế toán, bảo mật thông tin; thực hiện công khai, giải trình đúng trách nhiệm được giao. | 8 | Q8 | Hồ sơ lưu; báo cáo công khai; phiếu kiểm tra. |
> | **B2** | **Chất lượng, hiệu quả thực hiện** | **30** | | |
> | B3.1 | Hoàn thành chứng từ, báo cáo và các mốc công việc theo lịch kế toán, tài chính. | 6 | T6 | Thời hạn quy định; thời điểm nộp hồ sơ. |
> | B3.2 | Giải quyết hoặc phản hồi đề nghị thanh toán, điều chỉnh chứng từ hợp lệ đúng thời hạn. | 4 | T4 | Phiếu đề nghị; nhật ký tiếp nhận. |
> | **B3** | **Tiến độ** | **10** | | |
> | B4.1 | Hướng dẫn, phối hợp các bộ phận hoàn thiện hồ sơ tài chính; thực hiện đúng nhiệm vụ giao. | 6 | L6 | Danh sách công việc phối hợp. |
> | B4.2 | Thực hiện nhiệm vụ cải tiến dữ liệu, số hóa hồ sơ, kiểm soát chi phí, sử dụng nguồn lực tiết kiệm theo kế hoạch. | 4 | L4 | Sản phẩm; dữ liệu; kết quả cải tiến. |
> | **B4** | **Phối hợp, phục vụ, cải tiến** | **10** | | |
> | | **TỔNG CỘNG** | **70** | | |
>
> **Lưu ý:** Chỉ chấm nghiệp vụ đến hạn và thuộc trách nhiệm kế toán; không trừ điểm vì chứng từ do bộ phận khác chưa hoàn thiện nếu kế toán đã kiểm tra, yêu cầu bổ sung đúng thời hạn. Sai phạm tài chính nghiêm trọng phải được xử lý theo thẩm quyền, không chỉ dừng ở trừ điểm.
>
> ## 4. NHÂN VIÊN VĂN THƯ – 70 ĐIỂM
>
> | Mã | Công việc phải thực hiện, cách kiểm tra | Điểm tối đa | Thang chấm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Tiếp nhận, đăng ký, phân phối và theo dõi xử lý đủ văn bản đến, đi thuộc trách nhiệm. | 12 | L12 | Sổ văn bản; hệ thống quản lý văn bản. |
> | B1.2 | Hoàn thành việc soạn thảo, phát hành, lập hồ sơ, sắp xếp, số hóa tài liệu theo phân công. | 8 | L8 | Danh mục hồ sơ; dữ liệu lưu trữ. |
> | **B1** | **Số lượng, khối lượng nhiệm vụ** | **20** | | |
> | B2.1 | Bảo đảm văn bản được kiểm tra đúng thể thức, số hiệu, thông tin, nơi nhận và yêu cầu bảo mật trước khi phát hành. | 12 | Q12 | Văn bản; phiếu kiểm tra. |
> | B2.2 | Quản lý con dấu, chữ ký số, hệ thống văn bản điện tử đúng quy trình và thẩm quyền được giao. | 10 | Q10 | Sổ theo dõi; nhật ký hệ thống. |
> | B2.3 | Sắp xếp, lập hồ sơ và lưu trữ tài liệu đầy đủ, khoa học, tra cứu được theo yêu cầu hợp lệ. | 8 | Q8 | Hồ sơ lưu; kiểm tra thực tế. |
> | **B2** | **Chất lượng, hiệu quả thực hiện** | **30** | | |
> | B3.1 | Chuyển văn bản, thông tin chỉ đạo đến người có trách nhiệm đúng thời hạn, nhất là văn bản khẩn. | 6 | T6; trường hợp khẩn xét trách nhiệm xử lý ngay | Thời điểm tiếp nhận, chuyển văn bản. |
> | B3.2 | Phát hành, nộp lưu, bàn giao các hồ sơ định kỳ đúng tiến độ. | 4 | T4 | Sổ phát hành; lịch bàn giao. |
> | **B3** | **Tiến độ** | **10** | | |
> | B4.1 | Phối hợp các tổ, bộ phận trong việc cung cấp văn bản, mẫu biểu và xử lý thủ tục hành chính. | 6 | L6 | Công việc tiếp nhận, đã xử lý. |
> | B4.2 | Thực hiện công việc cải tiến quản lý văn bản, lưu trữ số, tra cứu dữ liệu hoặc quy trình hành chính. | 4 | L4 | Sản phẩm số hóa; kết quả áp dụng. |
> | **B4** | **Phối hợp, phục vụ, cải tiến** | **10** | | |
> | | **TỔNG CỘNG** | **70** | | |
>
> Việc chậm xử lý văn bản khẩn có nguy cơ gây ảnh hưởng nghiêm trọng phải được xem xét theo trách nhiệm thực tế, không áp dụng máy móc mức chậm trễ thông thường.
>
> ## 5. NHÂN VIÊN THỦ QUỸ – 70 ĐIỂM
>
> | Mã | Công việc phải thực hiện, cách kiểm tra | Điểm tối đa | Thang chấm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Thực hiện đầy đủ các nghiệp vụ thu, chi tiền mặt hợp lệ theo thẩm quyền, phân công. | 12 | L12 | Phiếu thu, chi; sổ quỹ. |
> | B1.2 | Cập nhật đầy đủ nghiệp vụ vào sổ quỹ, thực hiện kiểm đếm và bàn giao theo quy định. | 8 | L8 | Sổ quỹ; biên bản bàn giao. |
> | **B1** | **Số lượng, khối lượng nhiệm vụ** | **20** | | |
> | B2.1 | Bảo đảm số tiền thực tế khớp chứng từ và sổ quỹ; bảo quản tiền, tài sản an toàn. | 12 | Q12 | Kiểm kê quỹ; đối chiếu thực tế. |
> | B2.2 | Kiểm tra điều kiện chứng từ thu, chi; thực hiện giao nhận và ký nhận đúng quy định. | 10 | Q10 | Chứng từ; kiểm tra nội bộ. |
> | B2.3 | Bảo mật thông tin, lưu chứng từ, phối hợp đối chiếu quỹ với kế toán đúng quy trình. | 8 | Q8 | Sổ đối chiếu; hồ sơ lưu. |
> | **B2** | **Chất lượng, hiệu quả thực hiện** | **30** | | |
> | B3.1 | Thực hiện các giao dịch hợp lệ đúng thời hạn được giao. | 6 | T6 | Thời điểm nhận, hoàn thành giao dịch. |
> | B3.2 | Hoàn tất sổ quỹ, báo cáo và bàn giao, đối chiếu tiền mặt đúng hạn. | 4 | T4 | Sổ quỹ; báo cáo; biên bản. |
> | **B3** | **Tiến độ** | **10** | | |
> | B4.1 | Phối hợp kế toán, ban giám hiệu và bộ phận liên quan trong các nhiệm vụ được giao. | 6 | L6 | Lịch công tác; công việc phối hợp. |
> | B4.2 | Thực hiện kiểm soát, báo cáo chênh lệch và cải tiến cách quản lý tiền mặt, chứng từ theo kế hoạch. | 4 | L4 | Biên bản đối chiếu; ghi nhận cải tiến. |
> | **B4** | **Phối hợp, phục vụ, cải tiến** | **10** | | |
> | | **TỔNG CỘNG** | **70** | | |
>
> Nếu một người kiêm nhiệm kế toán và thủ quỹ, phải đối chiếu quy định về phân nhiệm, kiểm soát nội bộ và tính hợp pháp của việc kiêm nhiệm; không mặc nhiên áp dụng cả hai bảng KPI.
>
> ## 6. NHÂN VIÊN BẢO VỆ – 70 ĐIỂM
>
> | Mã | Công việc phải thực hiện, cách kiểm tra | Điểm tối đa | Thang chấm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Thực hiện đầy đủ các ca trực, kiểm tra và bàn giao ca được phân công. | 12 | L12 | Lịch trực; sổ giao ca. |
> | B1.2 | Thực hiện đủ lượt kiểm tra cổng, kiểm soát người ra vào, tuần tra khu vực và kiểm tra tài sản theo lịch. | 8 | L8 | Sổ trực; ghi nhận tuần tra. |
> | **B1** | **Số lượng, khối lượng nhiệm vụ** | **20** | | |
> | B2.1 | Tuân thủ quy trình kiểm soát cổng, phối hợp đón trả trẻ, phòng ngừa người lạ vào trường trái quy định. | 12 | Q12 | Kiểm tra đột xuất; sổ trực; biên bản. |
> | B2.2 | Thực hiện kiểm tra các nội dung phòng cháy, chữa cháy, lối thoát hiểm và báo nguy cơ mất an toàn theo phân công. | 10 | Q10 | Checklist an toàn; biên bản. |
> | B2.3 | Kiểm tra khóa cửa, hệ thống điện, nước, tài sản, khuôn viên theo trách nhiệm được giao. | 8 | Q8 | Phiếu kiểm tra; ghi nhận cuối ca. |
> | **B2** | **Chất lượng, hiệu quả thực hiện** | **30** | | |
> | B3.1 | Phát hiện, báo cáo và phối hợp xử lý nguy cơ về an ninh, an toàn đúng thời điểm. | 6 | S6 | Nhật ký; biên bản sự việc. |
> | B3.2 | Hoàn thành kiểm tra cuối ca, bàn giao và xử lý các mốc công việc đúng hạn. | 4 | T4 | Sổ bàn giao ca trực. |
> | **B3** | **Tiến độ** | **10** | | |
> | B4.1 | Phối hợp ban giám hiệu, giáo viên, nhân viên và các bộ phận trong những nhiệm vụ đã giao. | 6 | L6 | Nhật ký phối hợp. |
> | B4.2 | Thực hiện các đầu việc phòng ngừa nguy cơ, cải thiện công tác an ninh, quản lý tài sản được phân công. | 4 | L4 | Kiến nghị; kết quả kiểm tra, khắc phục. |
> | **B4** | **Phối hợp, phục vụ, cải tiến** | **10** | | |
> | | **TỔNG CỘNG** | **70** | | |
>
> **Lưu ý:** Phân biệt trách nhiệm bảo vệ cổng, tài sản, khuôn viên với trách nhiệm giám sát trẻ trong lớp của giáo viên. Không quy toàn bộ sự cố an toàn cho bảo vệ khi sự việc không thuộc phạm vi kiểm soát, phân công.
>
> ## 7. NHÂN VIÊN PHỤC VỤ, TẠP VỤ, VỆ SINH – 70 ĐIỂM
>
> | Mã | Công việc phải thực hiện, cách kiểm tra | Điểm tối đa | Thang chấm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Vệ sinh đầy đủ các khu vực, ca và hạng mục được giao trong tháng. | 12 | L12 | Lịch vệ sinh; phiếu kiểm tra. |
> | B1.2 | Thực hiện đầy đủ công việc thu gom rác, bổ sung vật tư, vệ sinh dụng cụ và nhiệm vụ phục vụ theo phân công. | 8 | L8 | Danh mục công việc; kiểm tra thực tế. |
> | **B1** | **Số lượng, khối lượng nhiệm vụ** | **20** | | |
> | B2.1 | Bảo đảm các vị trí được phân công sạch sẽ, không có rác tồn đọng, nước đọng hoặc tình trạng mất vệ sinh do không thực hiện nhiệm vụ. | 12 | Q12 | Kiểm tra thực tế; checklist vệ sinh. |
> | B2.2 | Sử dụng dụng cụ, hóa chất vệ sinh đúng hướng dẫn, bảo đảm an toàn, không để trẻ tiếp cận hóa chất hoặc vật dụng nguy hiểm. | 10 | Q10 | Quan sát; phiếu kiểm tra an toàn. |
> | B2.3 | Thực hiện đúng quy trình phân loại, thu gom rác; phòng ngừa lây nhiễm chéo, trơn trượt và nguy cơ vệ sinh. | 8 | Q8 | Kiểm tra khu vực; biên bản. |
> | **B2** | **Chất lượng, hiệu quả thực hiện** | **30** | | |
> | B3.1 | Hoàn thành vệ sinh khu vực trước các thời điểm yêu cầu, không ảnh hưởng hoạt động của trẻ. | 6 | T6 | Lịch vệ sinh; kiểm tra thực tế. |
> | B3.2 | Phản hồi, xử lý nhiệm vụ vệ sinh phát sinh trong thời gian hợp lý theo phân công. | 4 | T4 | Nhật ký công việc; phiếu giao việc. |
> | **B3** | **Tiến độ** | **10** | | |
> | B4.1 | Phối hợp giáo viên, bảo vệ và các bộ phận trong việc vệ sinh, chuẩn bị môi trường và khắc phục sự cố. | 6 | L6 | Lịch phối hợp; ghi nhận thực tế. |
> | B4.2 | Thực hiện nội dung tiết kiệm vật tư, bảo quản dụng cụ, phòng ngừa các điểm mất an toàn theo kế hoạch. | 4 | L4 | Kết quả kiểm tra; ghi nhận cải tiến. |
> | **B4** | **Phối hợp, phục vụ, cải tiến** | **10** | | |
> | | **TỔNG CỘNG** | **70** | | |
>
> # VI. NGUYÊN TẮC ÁP DỤNG VÀ KIỂM SOÁT KẾT QUẢ
>
> 1. Mỗi nhân viên chỉ áp dụng một bộ tiêu chí nhiệm vụ B theo vị trí việc làm chính, trừ trường hợp có phân công kiêm nhiệm được phê duyệt.
> 2. Tại đầu tháng, người phụ trách phải xác định danh mục nhiệm vụ, khối lượng và thời hạn phù hợp với vị trí việc làm.
> 3. Với nhiệm vụ kiêm nhiệm, phải có bảng phân bổ trọng số được phê duyệt trước kỳ đánh giá, bảo đảm tổng điểm phần B vẫn là 70, không cộng gộp thành 140 điểm.
> 4. Không tính các nhiệm vụ chưa đến hạn, không thuộc trách nhiệm hoặc đã được điều chỉnh hợp lệ là nhiệm vụ không hoàn thành.
> 5. Không trừ điểm chỉ vì nhân viên nghỉ theo chế độ hợp pháp. Điều chỉnh công việc theo thời gian làm việc thực tế.
> 6. Sai sót phải được xác minh rõ người thực hiện, quy trình bị vi phạm, mức độ ảnh hưởng và trách nhiệm; không dùng thông tin chưa kiểm chứng để trừ điểm.
> 7. Không trừ trùng một sai sót ở nhiều tiêu chí nếu không phát sinh lỗi độc lập.
> 8. Sự cố nghiêm trọng về an toàn thực phẩm, tài chính, dữ liệu, an ninh và an toàn trẻ phải được báo cáo, xử lý theo quy định, không thay thế bằng việc trừ điểm KPI.
> 9. Kết quả kiểm tra định kỳ và kiểm tra thực tế phải được sử dụng làm minh chứng, tránh yêu cầu tạo thêm hồ sơ chỉ để phục vụ KPI.
> 10. Đối với vị trí không có nhiệm vụ phát sinh trong tháng, người có thẩm quyền điều chỉnh danh mục hoặc phân bổ điểm trong cùng nhóm trước khi chấm; không tự động cho điểm 0 hoặc điểm tối đa.
>
> # VII. QUY ĐỊNH MỨC ĐIỂM THEO DÕI HẰNG THÁNG
>
> | Tổng điểm | Mức theo dõi |
> |---|---|
> | 90–100 | Mức xuất sắc |
> | 70 đến dưới 90 | Mức tốt |
> | 50 đến dưới 70 | Mức hoàn thành |
> | Dưới 50 | Mức chưa hoàn thành |
>
> Các mức trên phục vụ quản lý nội bộ hằng tháng. Đối với viên chức, việc xếp loại chính thức còn phải đáp ứng quy định của Nghị định 233/2026/NĐ-CP và quy chế đánh giá của nhà trường. Đối với lao động hợp đồng, việc áp dụng kết quả phải phù hợp hợp đồng lao động, quy định nội bộ và pháp luật lao động.
>
> # VIII. MẪU PHIẾU CHẤM KPI NHÂN VIÊN HẰNG THÁNG
>
> **TRƯỜNG MẦM NON:** ....................................................
>
> **PHIẾU ĐÁNH GIÁ KPI NHÂN VIÊN THÁNG ......... NĂM .........**
>
> Họ và tên: ........................................................................
>
> Vị trí việc làm: ....................................................................
>
> Bộ phận công tác: ................................................................
>
> | Mã KPI | Tiêu chí | Điểm tối đa | Tự chấm | Điểm xác nhận |
> |---|---|---:|---:|---:|
> | A1.1 | Đạo đức nghề nghiệp, ứng xử | 6 | | |
> | A1.2 | Chấp hành pháp luật, quy chế | 5 | | |
> | A1.3 | Trung thực, bảo mật | 4 | | |
> | A2.1 | Tinh thần trách nhiệm | 4 | | |
> | A2.2 | Phối hợp, đoàn kết | 3 | | |
> | A3.1 | Chấp hành giờ giấc | 2 | | |
> | A3.2 | Tác phong, giao tiếp | 2 | | |
> | A4.1 | Tự học, bồi dưỡng | 2 | | |
> | A4.2 | Cải tiến công việc | 2 | | |
> | | **CỘNG NHÓM A** | **30** | | |
> | B1.1 | Khối lượng nhiệm vụ thứ nhất theo vị trí | 12 | | |
> | B1.2 | Khối lượng nhiệm vụ thứ hai theo vị trí | 8 | | |
> | B2.1 | Chất lượng công việc thứ nhất | 12 | | |
> | B2.2 | Chất lượng công việc thứ hai | 10 | | |
> | B2.3 | Chất lượng công việc thứ ba | 8 | | |
> | B3.1 | Tiến độ công việc thứ nhất | 6 | | |
> | B3.2 | Tiến độ công việc thứ hai | 4 | | |
> | B4.1 | Phối hợp, phục vụ | 6 | | |
> | B4.2 | Cải tiến, thực hiện nhiệm vụ chung | 4 | | |
> | | **CỘNG NHÓM B** | **70** | | |
> | | **TỔNG CỘNG** | **100** | | |
>
> *Các dòng B được thay bằng nội dung chi tiết tương ứng với vị trí nhân viên trong Mục V.*
>
> **Mức điểm theo dõi:** ...................................................
>
> **Minh chứng, lý do trừ điểm (nếu có):**
>
> ....................................................................................
>
> ....................................................................................
>
> **Ưu điểm:** ....................................................................
>
> **Tồn tại, hạn chế:** ........................................................
>
> **Biện pháp khắc phục tháng tiếp theo:**
>
> ....................................................................................
>
> ....................................................................................
>
> **Ý kiến của người được đánh giá:**
>
> ....................................................................................
>
> | NGƯỜI TỰ ĐÁNH GIÁ | NGƯỜI PHỤ TRÁCH | HIỆU TRƯỞNG |
> |---|---|---|
> | (Ký, ghi rõ họ tên) | (Ký, ghi rõ họ tên) | (Ký, ghi rõ họ tên) |
> | | | |
>
> # IX. KẾT LUẬN
>
> Bảng KPI đối với nhân viên được tổ chức theo thang 100 điểm, trong đó 30 điểm đánh giá phẩm chất, trách nhiệm, tác phong, đổi mới; 70 điểm đánh giá kết quả nhiệm vụ theo từng vị trí.
>
> Việc triển khai phải bảo đảm chấm đúng công việc thực tế, đúng trách nhiệm, có minh chứng kiểm tra và có biện pháp hỗ trợ sau đánh giá.
>
> **Yêu cầu trọng tâm:** Không đánh giá bình quân, không chấm theo cảm tính, không áp dụng cùng một bảng nhiệm vụ cho mọi vị trí; bảo đảm hoạt động phục vụ của nhà trường an toàn, hiệu quả, đúng quy định.

## PHỤ LỤC 03 – Bảng KPI dành cho cán bộ quản lý trường mầm non

Đối với cán bộ quản lý, tôi đề xuất chú trọng ba yếu tố: **kết quả thực hiện nhiệm vụ cá nhân, chất lượng lĩnh vực được phân công và năng lực tổ chức, điều hành đội ngũ**. Như vậy, điểm số sẽ phản ánh hiệu quả quản lý thực tế, không chỉ căn cứ vào việc có hoàn thành văn bản, báo cáo hay tham dự các cuộc họp.

> **writing · document**
>
> # PHỤ LỤC 03
> ## BẢNG TIÊU CHÍ KPI ĐÁNH GIÁ KẾT QUẢ THỰC HIỆN NHIỆM VỤ HẰNG THÁNG ĐỐI VỚI CÁN BỘ QUẢN LÝ TRƯỜNG MẦM NON
> **(Thang điểm 100 điểm)**
>
> **Đơn vị:** Trường Mầm non ...............................................
>
> **Đối tượng:** Hiệu trưởng, Phó Hiệu trưởng.
>
> **Áp dụng từ tháng:** ................ **Năm học:** ....................
>
> ---
>
> # I. MỤC ĐÍCH, YÊU CẦU
>
> 1. Đánh giá kết quả thực hiện nhiệm vụ của cán bộ quản lý theo chức trách, quyền hạn và lĩnh vực được giao phụ trách.
> 2. Lượng hóa kết quả quản lý bằng số lượng công việc, chất lượng, tiến độ và hiệu quả tổ chức thực hiện.
> 3. Đánh giá trách nhiệm người đứng đầu và cấp phó gắn với kết quả của nhà trường hoặc lĩnh vực quản lý, không chỉ dựa vào việc hoàn thành công việc hành chính cá nhân.
> 4. Phát hiện kịp thời những hạn chế trong công tác quản lý, kiểm tra, điều hành và phát triển đội ngũ.
> 5. Nâng cao trách nhiệm nêu gương, tinh thần đổi mới, tính công khai, minh bạch và hiệu quả quản trị trường mầm non.
>
> # II. CƠ CẤU ĐIỂM
>
> | STT | Nhóm tiêu chí | Điểm tối đa |
> |---|---|---:|
> | **A** | **TIÊU CHÍ CHUNG** | **30** |
> | A1 | Phẩm chất chính trị, đạo đức nghề nghiệp, ý thức kỷ luật | 15 |
> | A2 | Trách nhiệm, đoàn kết, phối hợp | 7 |
> | A3 | Tác phong, lề lối làm việc | 4 |
> | A4 | Đổi mới, sáng tạo, tự học, chuyển đổi số | 4 |
> | **B** | **KẾT QUẢ THỰC HIỆN NHIỆM VỤ QUẢN LÝ** | **70** |
> | B1 | Số lượng, chất lượng, tiến độ nhiệm vụ cá nhân | 25 |
> | B2 | Kết quả lĩnh vực, đơn vị phụ trách | 25 |
> | B3 | Tổ chức, điều hành, kiểm tra | 10 |
> | B4 | Tập hợp, đoàn kết đội ngũ | 10 |
> | | **TỔNG CỘNG** | **100** |
>
> # III. TIÊU CHÍ CHUNG ĐỐI VỚI CÁN BỘ QUẢN LÝ – 30 ĐIỂM
>
> ## A1. Phẩm chất chính trị, đạo đức nghề nghiệp, ý thức kỷ luật – 15 điểm
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Mức điểm cụ thể | Minh chứng |
> |---|---|---:|---|---|
> | A1.1 | Gương mẫu chấp hành chủ trương, pháp luật, đạo đức nghề nghiệp; có trách nhiệm nêu gương trong nhà trường. | 6 | **6đ:** Không vi phạm. **4đ:** 1 sai sót nhẹ đã khắc phục. **2đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh. | Biên bản; kết quả kiểm tra; hồ sơ công tác. |
> | A1.2 | Liêm chính, minh bạch, khách quan trong quản lý, phân công nhiệm vụ, sử dụng nguồn lực, giải quyết công việc. | 5 | **5đ:** Không vi phạm. **4đ:** 1 sai sót thủ tục nhẹ, đã khắc phục. **2đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về tính liêm chính, minh bạch đã xác minh. | Hồ sơ quản lý; kiểm tra; giải trình. |
> | A1.3 | Chấp hành quy chế, bảo mật thông tin, thực hiện trách nhiệm phòng ngừa và báo cáo nguy cơ mất an toàn thuộc phạm vi quản lý. | 4 | **4đ:** Đúng, đủ. **3đ:** 1 sai sót nhẹ. **1đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc vi phạm nghiêm trọng đã xác minh. | Hồ sơ; báo cáo; biên bản. |
> | | **TỔNG A1** | **15** | | |
>
> ## A2. Trách nhiệm, đoàn kết, phối hợp – 7 điểm
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Mức điểm cụ thể | Minh chứng |
> |---|---|---:|---|---|
> | A2.1 | Chủ động tiếp nhận, tổ chức thực hiện nhiệm vụ; chịu trách nhiệm và báo cáo kịp thời những khó khăn, vướng mắc. | 4 | **4đ:** Chủ động, không phải nhắc. **3đ:** 1 lần phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần phải nhắc hoặc bỏ nhiệm vụ không có lý do chính đáng. | Kế hoạch; nhật ký giao việc; văn bản chỉ đạo. |
> | A2.2 | Phối hợp trong tập thể lãnh đạo; tôn trọng đồng nghiệp, lắng nghe, hỗ trợ và thực hiện nguyên tắc làm việc tập thể. | 3 | **3đ:** Phối hợp đầy đủ. **2đ:** 1 lần phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần hoặc có hành vi cản trở, gây mất đoàn kết được xác minh. | Biên bản họp; kết quả phối hợp. |
> | | **TỔNG A2** | **7** | | |
>
> ## A3. Tác phong, lề lối làm việc – 4 điểm
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Mức điểm cụ thể | Minh chứng |
> |---|---|---:|---|---|
> | A3.1 | Chấp hành thời gian làm việc, lịch công tác và các nhiệm vụ trực, họp, điều hành bắt buộc. | 2 | **2đ:** Không vi phạm. **1đ:** 1 lần đi muộn, vắng không đúng quy định. **0đ:** Từ 2 lần. | Lịch công tác; biên bản; chấm công. |
> | A3.2 | Giao tiếp chuẩn mực, thực hiện chế độ thông tin, giải trình và phong cách làm việc khoa học. | 2 | **2đ:** Thực hiện đúng. **1đ:** 1 sai sót nhẹ. **0đ:** Từ 2 sai sót hoặc vi phạm nghiêm trọng. | Quan sát; hồ sơ; phản ánh đã xác minh. |
> | | **TỔNG A3** | **4** | | |
>
> ## A4. Đổi mới, sáng tạo, tự học và chuyển đổi số – 4 điểm
>
> | Mã | Nội dung đánh giá | Điểm tối đa | Mức điểm cụ thể | Minh chứng |
> |---|---|---:|---|---|
> | A4.1 | Tự học, cập nhật kiến thức quản lý, nghiên cứu văn bản và vận dụng vào quản trị nhà trường. | 2 | **2đ:** Có ít nhất 1 nội dung được vận dụng. **1đ:** Có học nhưng chưa có minh chứng vận dụng. **0đ:** Không thực hiện nội dung bồi dưỡng theo yêu cầu. | Nội dung bồi dưỡng; kết quả vận dụng. |
> | A4.2 | Cải tiến quy trình quản lý, ứng dụng công nghệ và chuyển đổi số phù hợp nhiệm vụ. | 2 | **2đ:** Có ít nhất 1 cải tiến được áp dụng, chứng minh hiệu quả. **1đ:** Có thử nghiệm nhưng chưa đánh giá được hiệu quả. **0đ:** Không có cải tiến được ghi nhận. | Quy trình; dữ liệu; sản phẩm cải tiến. |
> | | **TỔNG A4** | **4** | | |
>
> # IV. TIÊU CHÍ KẾT QUẢ THỰC HIỆN NHIỆM VỤ QUẢN LÝ – 70 ĐIỂM
>
> ## B1. Số lượng, chất lượng, tiến độ thực hiện nhiệm vụ cá nhân – 25 điểm
>
> | Mã | Nội dung công việc | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | B1.1 | Hoàn thành các đầu việc, sản phẩm quản lý, báo cáo, nhiệm vụ cá nhân đã được giao và đến hạn trong tháng. | 10 | **10đ:** Đủ 100%. **8đ:** Từ 90% đến dưới 100%. **4đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Bảng giao việc; kế hoạch cá nhân; sản phẩm. |
> | B1.2 | Chất lượng kế hoạch, văn bản tham mưu, quyết định, báo cáo và sản phẩm quản lý thuộc trách nhiệm cá nhân. | 8 | **8đ:** Đúng yêu cầu, không sai sót. **6đ:** 1 sai sót nhẹ đã sửa. **3đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc sai sót nghiêm trọng đã xác minh. | Văn bản; kết quả kiểm tra; ý kiến cơ quan tiếp nhận. |
> | B1.3 | Hoàn thành công việc theo tiến độ, thời hạn đã được giao hoặc được điều chỉnh hợp lệ. | 7 | **7đ:** Tất cả đúng hạn. **5đ:** 1 lần trễ không quá 1 ngày. **2đ:** 2 lần trễ hoặc 1 lần trễ quá 1 ngày. **0đ:** Từ 3 lần trễ hoặc bỏ nhiệm vụ bắt buộc. | Lịch công tác; hạn nhiệm vụ; thời điểm hoàn thành. |
> | | **TỔNG B1** | **25** | | |
>
> **Cách kiểm tra B1:** Lập bảng giao nhiệm vụ theo tháng có tối thiểu bốn thông tin: tên sản phẩm, người chịu trách nhiệm, thời hạn và tiêu chuẩn nghiệm thu. Không đưa vào đánh giá những công việc chưa đến hạn hoặc không thuộc trách nhiệm cá nhân.
>
> ## B2. Kết quả lĩnh vực, đơn vị được phân công quản lý – 25 điểm
>
> | Mã | Nội dung công việc | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | B2.1 | Mức độ hoàn thành các chỉ tiêu, nhiệm vụ trọng tâm thuộc phạm vi quản lý trong tháng. | 10 | **10đ:** Đạt 100% chỉ tiêu đến hạn. **8đ:** Từ 90% đến dưới 100%. **4đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Bảng chỉ tiêu tháng; kết quả thực hiện. |
> | B2.2 | Chất lượng quản lý lĩnh vực phụ trách: bảo đảm yêu cầu chuyên môn, an toàn, đúng quy trình và trách nhiệm chỉ đạo. | 10 | **10đ:** Không có sai sót quản lý được xác minh. **7đ:** 1 sai sót quản lý nhẹ đã khắc phục. **3đ:** 2 sai sót quản lý nhẹ. **0đ:** Từ 3 sai sót hoặc 1 sai phạm quản lý nghiêm trọng đã được xác minh. | Kết quả kiểm tra; biên bản; hồ sơ quản lý. |
> | B2.3 | Thực hiện các biện pháp khắc phục tồn tại, phòng ngừa rủi ro và cải thiện kết quả thuộc lĩnh vực phụ trách theo kế hoạch. | 5 | **5đ:** Hoàn thành 100% đầu việc đến hạn. **4đ:** Từ 90% đến dưới 100%. **2đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch khắc phục; kết quả kiểm tra lại. |
> | | **TỔNG B2** | **25** | | |
>
> **Nguyên tắc xác định trách nhiệm quản lý:** Không tự động trừ điểm hiệu trưởng hoặc phó hiệu trưởng chỉ vì giáo viên, nhân viên có sai sót. Chỉ tính trách nhiệm quản lý khi có căn cứ cho thấy người quản lý chưa thực hiện đúng nhiệm vụ chỉ đạo, phân công, kiểm tra, đôn đốc, cảnh báo hoặc xử lý thuộc thẩm quyền.
>
> Nếu có sai phạm nghiêm trọng thuộc phạm vi quản lý, việc đánh giá và xử lý còn phải tuân thủ các quy định pháp luật có liên quan.
>
> ## B3. Tổ chức, điều hành, kiểm tra – 10 điểm
>
> | Mã | Nội dung công việc | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | B3.1 | Phân công, giao việc rõ nội dung, trách nhiệm, yêu cầu sản phẩm và thời hạn cho cá nhân, bộ phận được phụ trách. | 4 | **4đ:** Đúng, đủ, không sai sót. **3đ:** 1 sai sót nhẹ được sửa. **1đ:** 2 sai sót. **0đ:** Từ 3 sai sót hoặc sai sót nghiêm trọng. | Kế hoạch; bảng giao việc. |
> | B3.2 | Thực hiện các lượt kiểm tra, hướng dẫn, giám sát, đôn đốc và theo dõi khắc phục theo kế hoạch. | 4 | **4đ:** Đủ 100%. **3đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Lịch kiểm tra; biên bản; phiếu theo dõi. |
> | B3.3 | Tiếp nhận, giải quyết hoặc phản hồi những công việc, kiến nghị thuộc thẩm quyền đúng thời hạn. | 2 | **2đ:** Đúng hạn 100%. **1đ:** 1 lần chậm nhẹ, đã khắc phục. **0đ:** Từ 2 lần chậm hoặc một trường hợp trì hoãn nghiêm trọng thuộc trách nhiệm. | Hồ sơ xử lý; nhật ký giao việc. |
> | | **TỔNG B3** | **10** | | |
>
> ## B4. Tập hợp, đoàn kết đội ngũ – 10 điểm
>
> | Mã | Nội dung công việc | Điểm tối đa | Quy định mức điểm | Minh chứng |
> |---|---|---:|---|---|
> | B4.1 | Thực hiện dân chủ, công khai, minh bạch; lắng nghe, phản hồi và phối hợp trong quản lý đội ngũ. | 4 | **4đ:** Đúng quy trình, không sai sót. **3đ:** 1 sai sót nhẹ. **1đ:** 2 sai sót. **0đ:** Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh. | Biên bản họp; hồ sơ công khai, giải quyết ý kiến. |
> | B4.2 | Hướng dẫn, hỗ trợ, bồi dưỡng, động viên đội ngũ và giải quyết khó khăn chuyên môn theo kế hoạch. | 4 | **4đ:** Hoàn thành 100% nhiệm vụ hỗ trợ. **3đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch bồi dưỡng; ghi nhận hỗ trợ. |
> | B4.3 | Giữ gìn đoàn kết nội bộ, phối hợp giải quyết bất đồng và phản ánh thuộc thẩm quyền. | 2 | **2đ:** Thực hiện đúng trách nhiệm, quy trình. **1đ:** 1 sai sót nhẹ được xác minh. **0đ:** Từ 2 sai sót hoặc hành vi nghiêm trọng gây mất đoàn kết được xác minh. | Biên bản; hồ sơ giải quyết công việc. |
> | | **TỔNG B4** | **10** | | |
>
> # V. CỤ THỂ HÓA NHIỆM VỤ THEO CHỨC DANH CÁN BỘ QUẢN LÝ
>
> ## 1. ĐỐI VỚI HIỆU TRƯỞNG
>
> Hiệu trưởng chịu trách nhiệm quản lý tổng thể hoạt động của nhà trường theo thẩm quyền, kế hoạch, nhiệm vụ được giao.
>
> **Nhóm B1 – 25 điểm: Nhiệm vụ cá nhân**
>
> - Xây dựng, tổ chức thực hiện kế hoạch công tác tháng của nhà trường.
> - Hoàn thành các văn bản quản lý, chỉ đạo, báo cáo, quyết định thuộc thẩm quyền và đến hạn.
> - Thực hiện nhiệm vụ theo yêu cầu của cơ quan quản lý.
> - Bảo đảm tiến độ xử lý các công việc thuộc trách nhiệm người đứng đầu.
>
> **Nhóm B2 – 25 điểm: Kết quả hoạt động nhà trường**
>
> Các chỉ tiêu được lượng hóa theo tháng từ những lĩnh vực trọng tâm:
>
> | Lĩnh vực | Công việc, kết quả dùng để đánh giá |
> |---|---|
> | Chăm sóc, nuôi dưỡng, giáo dục | Mức hoàn thành các chỉ tiêu chất lượng và nhiệm vụ tháng theo kế hoạch được phê duyệt. |
> | An toàn trường học | Chỉ đạo, kiểm soát, khắc phục các nguy cơ về an toàn trẻ, vệ sinh, an toàn thực phẩm và cơ sở vật chất. |
> | Quản trị đội ngũ | Phân công nhân sự, triển khai đánh giá, hỗ trợ, bồi dưỡng và giải quyết những vấn đề thuộc thẩm quyền. |
> | Tài chính, tài sản | Chỉ đạo quản lý, sử dụng nguồn lực, công khai, kiểm soát hồ sơ đúng quy định. |
> | Kiểm tra, cải tiến | Triển khai các nhiệm vụ kiểm tra, xử lý kiến nghị, khắc phục tồn tại đến hạn. |
> | Nhiệm vụ khác | Phổ cập giáo dục, kiểm định chất lượng, chuyển đổi số, nhiệm vụ cấp trên giao theo kế hoạch và thời điểm phát sinh hợp lệ. |
>
> **Nhóm B3 – 10 điểm: Điều hành**
>
> Đánh giá việc giao nhiệm vụ rõ ràng, tổ chức kiểm tra, chỉ đạo khắc phục và xử lý kịp thời các công việc thuộc thẩm quyền.
>
> **Nhóm B4 – 10 điểm: Xây dựng đội ngũ**
>
> Đánh giá trách nhiệm nêu gương, thực hiện dân chủ, công khai, giải quyết vướng mắc, tạo môi trường làm việc đoàn kết và hỗ trợ phát triển đội ngũ.
>
> **Điểm cần lưu ý:** Hiệu trưởng không tự quyết định mức xếp loại viên chức chính thức hằng năm đối với chính mình; việc đánh giá, xếp loại thực hiện theo thẩm quyền của cơ quan quản lý đơn vị.
>
> ## 2. ĐỐI VỚI PHÓ HIỆU TRƯỞNG PHỤ TRÁCH CHUYÊN MÔN
>
> **Nhóm B1 – 25 điểm: Nhiệm vụ cá nhân**
>
> - Xây dựng và thực hiện kế hoạch quản lý chuyên môn tháng.
> - Tham mưu, hoàn thành văn bản, báo cáo và nhiệm vụ chuyên môn được phân công.
> - Hoàn thành nhiệm vụ kiểm tra, hướng dẫn và điều chỉnh kế hoạch chuyên môn đúng hạn.
>
> **Nhóm B2 – 25 điểm: Kết quả lĩnh vực chuyên môn**
>
> | Lĩnh vực | Chỉ tiêu, sản phẩm cần theo dõi |
> |---|---|
> | Kế hoạch giáo dục | Tỷ lệ kế hoạch, nhiệm vụ giáo dục được triển khai và hoàn thành theo thời hạn đã thống nhất. |
> | Chất lượng hoạt động | Kết quả quan sát, kiểm tra hoạt động; mức độ thực hiện các yêu cầu chuyên môn và cải thiện sau góp ý. |
> | Môi trường giáo dục | Kết quả tổ chức môi trường học tập, vui chơi an toàn, phù hợp độ tuổi, lấy trẻ làm trung tâm. |
> | Theo dõi trẻ | Việc thực hiện quan sát, đánh giá sự phát triển và hỗ trợ trẻ của các nhóm, lớp thuộc phạm vi phụ trách. |
> | Phát triển giáo viên | Kết quả sinh hoạt chuyên môn, bồi dưỡng, dự giờ, hỗ trợ giáo viên theo kế hoạch. |
> | Kiểm tra, khắc phục | Tỷ lệ nội dung tồn tại, hạn chế chuyên môn được xử lý đúng thời hạn và đạt yêu cầu. |
>
> **Nhóm B3 – 10 điểm: Tổ chức, điều hành chuyên môn**
>
> Đánh giá chất lượng phân công giáo viên, tổ chức kiểm tra, hỗ trợ chuyên môn, theo dõi tiến độ và giải quyết khó khăn trong các nhóm lớp.
>
> **Nhóm B4 – 10 điểm: Phát triển, đoàn kết đội ngũ**
>
> Đánh giá khả năng lắng nghe, hướng dẫn, hỗ trợ chuyên môn, công bằng trong nhận xét giáo viên và phối hợp với các tổ chuyên môn.
>
> Không sử dụng riêng tỷ lệ trẻ đạt mục tiêu phát triển hoặc tỷ lệ hồ sơ giáo viên đầy đủ làm căn cứ duy nhất để đánh giá chất lượng quản lý chuyên môn.
>
> ## 3. ĐỐI VỚI PHÓ HIỆU TRƯỞNG PHỤ TRÁCH NUÔI DƯỠNG, CƠ SỞ VẬT CHẤT
>
> **Nhóm B1 – 25 điểm: Nhiệm vụ cá nhân**
>
> - Xây dựng và thực hiện kế hoạch công tác nuôi dưỡng, chăm sóc sức khỏe, cơ sở vật chất theo phân công.
> - Hoàn thành các hồ sơ, báo cáo quản lý, tham mưu và nhiệm vụ đến hạn.
> - Bảo đảm tiến độ kiểm tra, phối hợp, giám sát các bộ phận thuộc phạm vi phụ trách.
>
> **Nhóm B2 – 25 điểm: Kết quả lĩnh vực phụ trách**
>
> | Lĩnh vực | Chỉ tiêu, sản phẩm cần theo dõi |
> |---|---|
> | Tổ chức bữa ăn | Kiểm tra thực đơn, chế biến, giao nhận và tổ chức ăn theo nhiệm vụ quản lý được giao. |
> | An toàn thực phẩm | Kết quả chỉ đạo, giám sát quy trình tiếp nhận, bảo quản, chế biến, kiểm thực và lưu mẫu thức ăn. |
> | Chăm sóc sức khỏe | Kết quả phối hợp theo dõi sức khỏe, vệ sinh, phòng bệnh và các nhiệm vụ y tế trường học. |
> | Cơ sở vật chất | Mức hoàn thành kiểm tra, phát hiện hư hỏng, tham mưu sửa chữa, bảo trì và xử lý nguy cơ mất an toàn. |
> | Đội ngũ nhân viên | Kết quả phân công, hướng dẫn, kiểm tra, bồi dưỡng và phối hợp đối với nhân viên thuộc phạm vi quản lý. |
> | Khắc phục hạn chế | Tỷ lệ nhiệm vụ xử lý tồn tại, cải tiến quy trình nuôi dưỡng và cơ sở vật chất đã hoàn thành, đạt yêu cầu. |
>
> **Nhóm B3 – 10 điểm: Tổ chức, điều hành**
>
> Đánh giá việc phân công các bộ phận, tổ chức kiểm tra thực tế, giám sát, đôn đốc và xử lý công việc theo đúng trách nhiệm.
>
> **Nhóm B4 – 10 điểm: Phối hợp, phát triển đội ngũ**
>
> Đánh giá khả năng phối hợp với giáo viên, nhân viên bếp, y tế, kế toán và các bộ phận; hỗ trợ tháo gỡ khó khăn, bảo đảm đoàn kết và hiệu quả công việc.
>
> Không tự động quy trách nhiệm quản lý khi phát sinh vấn đề do nhà cung cấp, yếu tố khách quan hoặc cá nhân khác. Cần đối chiếu trách nhiệm trong quy trình kiểm tra, phát hiện, báo cáo và xử lý.
>
> # VI. MẪU BẢNG GIAO CHỈ TIÊU HẰNG THÁNG CHO CBQL
>
> Để có căn cứ chấm B1 và B2, nhà trường cần xây dựng bảng nhiệm vụ theo tháng ngay từ đầu kỳ đánh giá.
>
> | STT | Nhiệm vụ, chỉ tiêu cần hoàn thành | Sản phẩm, mức yêu cầu | Thời hạn | Kết quả thực hiện | Minh chứng |
> |---|---|---|---|---|---|
> | 1 | ................................ | ........................ | ........ | ........ | ........ |
> | 2 | ................................ | ........................ | ........ | ........ | ........ |
> | 3 | ................................ | ........................ | ........ | ........ | ........ |
> | 4 | ................................ | ........................ | ........ | ........ | ........ |
> | 5 | ................................ | ........................ | ........ | ........ | ........ |
>
> **Nguyên tắc giao chỉ tiêu:**
>
> - Chỉ tiêu phải thuộc thẩm quyền, nhiệm vụ hoặc phạm vi quản lý của người được đánh giá.
> - Mỗi chỉ tiêu phải xác định sản phẩm hoặc kết quả kiểm chứng được.
> - Chỉ đánh giá công việc đến hạn trong tháng.
> - Các chỉ tiêu chưa phát sinh phải có phương án thay thế hoặc điều chỉnh được chấp thuận.
> - Các kết quả phụ thuộc nhiều bộ phận phải có cơ chế xác định rõ trách nhiệm quản lý và trách nhiệm thực hiện.
>
> # VII. VÍ DỤ MINH HỌA CHẤM KPI CÁN BỘ QUẢN LÝ
>
> Giả sử một phó hiệu trưởng phụ trách chuyên môn có kết quả tháng như sau:
>
> | Nhóm tiêu chí | Tối đa | Điểm đạt |
> |---|---:|---:|
> | A1. Phẩm chất, đạo đức, kỷ luật | 15 | 15 |
> | A2. Trách nhiệm, đoàn kết | 7 | 7 |
> | A3. Tác phong, lề lối | 4 | 4 |
> | A4. Đổi mới, tự học | 4 | 3 |
> | B1. Nhiệm vụ cá nhân | 25 | 23 |
> | B2. Kết quả lĩnh vực phụ trách | 25 | 20 |
> | B3. Tổ chức, điều hành, kiểm tra | 10 | 9 |
> | B4. Tập hợp, đoàn kết đội ngũ | 10 | 8 |
> | **TỔNG CỘNG** | **100** | **94** |
>
> **Kết quả:** 94/100 điểm – Mức điểm theo dõi xuất sắc.
>
> **Ưu điểm:** Chủ động thực hiện công việc; hoàn thành phần lớn chỉ tiêu chuyên môn; tích cực hỗ trợ giáo viên.
>
> **Nội dung cần cải thiện:** Tăng hiệu quả khắc phục những hạn chế đã phát hiện; cải tiến chất lượng tổ chức kiểm tra, hỗ trợ chuyên môn.
>
> Điểm 94 là kết quả theo dõi tháng; không tự động xác lập mức xếp loại viên chức hoàn thành xuất sắc nhiệm vụ cuối năm.
>
> # VIII. MẪU PHIẾU CHẤM KPI CÁN BỘ QUẢN LÝ HẰNG THÁNG
>
> **TRƯỜNG MẦM NON:** .....................................................
>
> **PHIẾU ĐÁNH GIÁ KPI CÁN BỘ QUẢN LÝ THÁNG ......... NĂM .........**
>
> Họ và tên: ........................................................................
>
> Chức vụ: ..........................................................................
>
> Lĩnh vực phụ trách: .............................................................
>
> | Mã KPI | Tiêu chí đánh giá | Điểm tối đa | Tự chấm | Điểm xác nhận |
> |---|---|---:|---:|---:|
> | A1.1 | Gương mẫu, phẩm chất, đạo đức nghề nghiệp | 6 | | |
> | A1.2 | Liêm chính, minh bạch trong quản lý | 5 | | |
> | A1.3 | Chấp hành quy chế, bảo mật, trách nhiệm an toàn | 4 | | |
> | A2.1 | Trách nhiệm, chủ động thực hiện nhiệm vụ | 4 | | |
> | A2.2 | Phối hợp, đoàn kết trong tập thể | 3 | | |
> | A3.1 | Chấp hành giờ giấc, lịch công tác | 2 | | |
> | A3.2 | Tác phong, giao tiếp, giải trình | 2 | | |
> | A4.1 | Tự học, bồi dưỡng quản lý | 2 | | |
> | A4.2 | Cải tiến, chuyển đổi số | 2 | | |
> | | **CỘNG NHÓM A** | **30** | | |
> | B1.1 | Khối lượng nhiệm vụ cá nhân | 10 | | |
> | B1.2 | Chất lượng sản phẩm quản lý | 8 | | |
> | B1.3 | Tiến độ nhiệm vụ cá nhân | 7 | | |
> | | **CỘNG B1** | **25** | | |
> | B2.1 | Hoàn thành chỉ tiêu lĩnh vực, đơn vị phụ trách | 10 | | |
> | B2.2 | Chất lượng quản lý lĩnh vực | 10 | | |
> | B2.3 | Khắc phục hạn chế, phòng ngừa rủi ro | 5 | | |
> | | **CỘNG B2** | **25** | | |
> | B3.1 | Phân công, giao việc | 4 | | |
> | B3.2 | Kiểm tra, giám sát, đôn đốc | 4 | | |
> | B3.3 | Giải quyết công việc, kiến nghị | 2 | | |
> | | **CỘNG B3** | **10** | | |
> | B4.1 | Dân chủ, công khai, minh bạch | 4 | | |
> | B4.2 | Hỗ trợ, bồi dưỡng đội ngũ | 4 | | |
> | B4.3 | Giữ gìn đoàn kết, giải quyết bất đồng | 2 | | |
> | | **CỘNG B4** | **10** | | |
> | | **TỔNG CỘNG** | **100** | | |
>
> **Mức điểm theo dõi:** .................................................
>
> **1. Ưu điểm:**
>
> ....................................................................................
>
> ....................................................................................
>
> **2. Tồn tại, hạn chế:**
>
> ....................................................................................
>
> ....................................................................................
>
> **3. Nhiệm vụ, giải pháp cần thực hiện trong tháng tiếp theo:**
>
> ....................................................................................
>
> ....................................................................................
>
> **4. Ý kiến của người được đánh giá:**
>
> ....................................................................................
>
> ....................................................................................
>
> | NGƯỜI TỰ ĐÁNH GIÁ | NGƯỜI THEO DÕI, ĐÁNH GIÁ THEO THẨM QUYỀN |
> |---|---|
> | (Ký, ghi rõ họ tên) | (Ký, ghi rõ họ tên) |
> | | |
> | | |
>
> # IX. NGUYÊN TẮC VÀ QUY TRÌNH ÁP DỤNG
>
> **1. Đối với hiệu trưởng**
>
> Việc giao nhiệm vụ, theo dõi và xếp loại chất lượng thực hiện theo thẩm quyền của cơ quan quản lý đơn vị. Kết quả KPI của nhà trường có thể được sử dụng làm dữ liệu tự đánh giá, báo cáo và giải trình theo yêu cầu.
>
> **2. Đối với phó hiệu trưởng**
>
> Hiệu trưởng phân công nhiệm vụ, xác định chỉ tiêu và tổ chức theo dõi, đánh giá theo tháng trong phạm vi thẩm quyền.
>
> **3. Về thời gian triển khai**
>
> - Đầu tháng: giao nhiệm vụ và chỉ tiêu.
> - Trong tháng: theo dõi, kiểm tra, xác nhận tiến độ và chất lượng.
> - Cuối tháng: cá nhân tự đánh giá, đối chiếu minh chứng.
> - Sau kỳ đánh giá: người có thẩm quyền xem xét, thông báo điểm và xác định nội dung cần khắc phục.
>
> **4. Về công bằng trong đánh giá**
>
> Không so sánh trực tiếp hiệu trưởng với phó hiệu trưởng bằng số lượng đầu việc tuyệt đối. Việc đánh giá phải căn cứ khối lượng, mức độ phức tạp và trách nhiệm được giao.
>
> **5. Về xử lý vi phạm**
>
> Các trường hợp vi phạm nghiêm trọng phải được xác minh và giải quyết đúng quy định, không xem việc trừ điểm KPI là biện pháp thay thế trách nhiệm pháp lý hoặc trách nhiệm quản lý.
>
> **6. Về kết quả xếp loại**
>
> KPI tháng là cơ sở theo dõi. Việc xếp loại chất lượng viên chức hằng năm phải căn cứ kết quả theo dõi, các điều kiện xếp loại, thẩm quyền và trình tự theo Nghị định 233/2026/NĐ-CP.
>
> # X. KẾT LUẬN
>
> Bảng KPI cán bộ quản lý được xây dựng theo cơ cấu 30 điểm tiêu chí chung và 70 điểm kết quả nhiệm vụ, trong đó 25 điểm phản ánh nhiệm vụ cá nhân, 25 điểm phản ánh kết quả lĩnh vực hoặc đơn vị phụ trách, 10 điểm đánh giá năng lực tổ chức điều hành và 10 điểm đánh giá năng lực tập hợp, đoàn kết đội ngũ.
>
> Việc đánh giá phải tập trung vào trách nhiệm quản lý, chất lượng kết quả thực hiện, hiệu quả sử dụng nguồn lực, khả năng phòng ngừa rủi ro và phát triển đội ngũ.
>
> **Yêu cầu xuyên suốt:** Cán bộ quản lý được đánh giá bằng sản phẩm và hiệu quả quản lý thực tế, có minh chứng rõ ràng, công bằng theo thẩm quyền, trách nhiệm và phạm vi công tác được giao.

---

## 💡 Đề xuất của tôi để nhà trường áp dụng đồng bộ

Sau khi hoàn thành ba bộ KPI cho giáo viên, nhân viên và CBQL, tôi đề xuất nhà trường ban hành thành **ba phụ lục thống nhất kèm Quy chế đánh giá**, đồng thời sử dụng một bảng tổng hợp điểm chung cho toàn trường.

| Phụ lục | Đối tượng | Nội dung |
|--------|--------|--------|
| 01 | Giáo viên | 23 chỉ tiêu chi tiết |
| 02 | Nhân viên | 9 tiêu chí chung và 9 tiêu chí nhiệm vụ theo từng vị trí |
| 03 | Cán bộ quản lý | 9 tiêu chí chung và 11 tiêu chí nhiệm vụ quản lý |

Cả ba bộ đều sử dụng chung ngưỡng điểm theo dõi:

- **90–100 điểm:** Mức xuất sắc.
- **70 đến dưới 90 điểm:** Mức tốt.
- **50 đến dưới 70 điểm:** Mức hoàn thành.
- **Dưới 50 điểm:** Mức chưa hoàn thành.

Tuy nhiên, khi xếp loại viên chức cuối năm còn phải xem xét các điều kiện ngoài điểm số, giới hạn tỷ lệ hoàn thành xuất sắc nhiệm vụ và các trường hợp không hoàn thành nhiệm vụ theo Điều 12 Nghị định 233/2026/NĐ-CP. Riêng mức xếp loại người đứng đầu không được cao hơn mức xếp loại của đơn vị. [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=dieu_13>)

**Một điểm tôi đặc biệt khuyến nghị:** Trước khi áp dụng chính thức, nhà trường nên giao nhiệm vụ cụ thể theo tháng cho từng vị trí, thử chấm ít nhất một kỳ, lấy ý kiến của đội ngũ rồi hoàn thiện phụ lục. Nghị định 233/2026/NĐ-CP quy định đơn vị sự nghiệp công lập phải ban hành quy chế đánh giá chậm nhất ngày 30/11/2026. [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=dieu_13>)

Hai bản trên đã được trình bày dưới dạng tài liệu có thể chỉnh sửa, sao chép sang Word. Trong phiên này tôi chưa thể đính kèm trực tiếp tệp `.docx`. Khi đưa vào văn bản chính thức, nên dùng giấy A4 ngang cho các bảng tiêu chí chi tiết để bảo đảm dễ đọc và dễ chấm điểm.

---

ASSISTANT

Phần KPI nhân viên đã được chia theo 7 vị trí, mỗi vị trí có 9 đầu việc thuộc nhóm 70 điểm và thang quy đổi điểm chung để dễ áp dụng. Tôi đang hoàn thiện phần CBQL, chú trọng kết quả lĩnh vực phụ trách và cách xác định trách nhiệm quản lý khi phát sinh sai sót ở bộ phận.

---

ASSISTANT

## PHỤ LỤC 03 – Bảng KPI dành cho cán bộ quản lý trường mầm non

Đối với cán bộ quản lý, tôi đề xuất chú trọng ba yếu tố: **kết quả thực hiện nhiệm vụ cá nhân, chất lượng lĩnh vực được phân công và năng lực tổ chức, điều hành đội ngũ**. Như vậy, điểm số sẽ phản ánh hiệu quả quản lý thực tế, không chỉ căn cứ vào việc có hoàn thành văn bản, báo cáo hay tham dự các cuộc họp.

<WritingBlock id="62942" variant="document"># PHỤ LỤC 03
## BẢNG TIÊU CHÍ KPI ĐÁNH GIÁ KẾT QUẢ THỰC HIỆN NHIỆM VỤ HẰNG THÁNG ĐỐI VỚI CÁN BỘ QUẢN LÝ TRƯỜNG MẦM NON
**(Thang điểm 100 điểm)**

**Đơn vị:** Trường Mầm non ...............................................

**Đối tượng:** Hiệu trưởng, Phó Hiệu trưởng.

**Áp dụng từ tháng:** ................ **Năm học:** ....................

---

# I. MỤC ĐÍCH, YÊU CẦU

1. Đánh giá kết quả thực hiện nhiệm vụ của cán bộ quản lý theo chức trách, quyền hạn và lĩnh vực được giao phụ trách.
2. Lượng hóa kết quả quản lý bằng số lượng công việc, chất lượng, tiến độ và hiệu quả tổ chức thực hiện.
3. Đánh giá trách nhiệm người đứng đầu và cấp phó gắn với kết quả của nhà trường hoặc lĩnh vực quản lý, không chỉ dựa vào việc hoàn thành công việc hành chính cá nhân.
4. Phát hiện kịp thời những hạn chế trong công tác quản lý, kiểm tra, điều hành và phát triển đội ngũ.
5. Nâng cao trách nhiệm nêu gương, tinh thần đổi mới, tính công khai, minh bạch và hiệu quả quản trị trường mầm non.

# II. CƠ CẤU ĐIỂM

| STT | Nhóm tiêu chí | Điểm tối đa |
|---|---|---:|
| **A** | **TIÊU CHÍ CHUNG** | **30** |
| A1 | Phẩm chất chính trị, đạo đức nghề nghiệp, ý thức kỷ luật | 15 |
| A2 | Trách nhiệm, đoàn kết, phối hợp | 7 |
| A3 | Tác phong, lề lối làm việc | 4 |
| A4 | Đổi mới, sáng tạo, tự học, chuyển đổi số | 4 |
| **B** | **KẾT QUẢ THỰC HIỆN NHIỆM VỤ QUẢN LÝ** | **70** |
| B1 | Số lượng, chất lượng, tiến độ nhiệm vụ cá nhân | 25 |
| B2 | Kết quả lĩnh vực, đơn vị phụ trách | 25 |
| B3 | Tổ chức, điều hành, kiểm tra | 10 |
| B4 | Tập hợp, đoàn kết đội ngũ | 10 |
| | **TỔNG CỘNG** | **100** |

# III. TIÊU CHÍ CHUNG ĐỐI VỚI CÁN BỘ QUẢN LÝ – 30 ĐIỂM

## A1. Phẩm chất chính trị, đạo đức nghề nghiệp, ý thức kỷ luật – 15 điểm

| Mã | Nội dung đánh giá | Điểm tối đa | Mức điểm cụ thể | Minh chứng |
|---|---|---:|---|---|
| A1.1 | Gương mẫu chấp hành chủ trương, pháp luật, đạo đức nghề nghiệp; có trách nhiệm nêu gương trong nhà trường. | 6 | **6đ:** Không vi phạm. **4đ:** 1 sai sót nhẹ đã khắc phục. **2đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh. | Biên bản; kết quả kiểm tra; hồ sơ công tác. |
| A1.2 | Liêm chính, minh bạch, khách quan trong quản lý, phân công nhiệm vụ, sử dụng nguồn lực, giải quyết công việc. | 5 | **5đ:** Không vi phạm. **4đ:** 1 sai sót thủ tục nhẹ, đã khắc phục. **2đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về tính liêm chính, minh bạch đã xác minh. | Hồ sơ quản lý; kiểm tra; giải trình. |
| A1.3 | Chấp hành quy chế, bảo mật thông tin, thực hiện trách nhiệm phòng ngừa và báo cáo nguy cơ mất an toàn thuộc phạm vi quản lý. | 4 | **4đ:** Đúng, đủ. **3đ:** 1 sai sót nhẹ. **1đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc vi phạm nghiêm trọng đã xác minh. | Hồ sơ; báo cáo; biên bản. |
| | **TỔNG A1** | **15** | | |

## A2. Trách nhiệm, đoàn kết, phối hợp – 7 điểm

| Mã | Nội dung đánh giá | Điểm tối đa | Mức điểm cụ thể | Minh chứng |
|---|---|---:|---|---|
| A2.1 | Chủ động tiếp nhận, tổ chức thực hiện nhiệm vụ; chịu trách nhiệm và báo cáo kịp thời những khó khăn, vướng mắc. | 4 | **4đ:** Chủ động, không phải nhắc. **3đ:** 1 lần phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần phải nhắc hoặc bỏ nhiệm vụ không có lý do chính đáng. | Kế hoạch; nhật ký giao việc; văn bản chỉ đạo. |
| A2.2 | Phối hợp trong tập thể lãnh đạo; tôn trọng đồng nghiệp, lắng nghe, hỗ trợ và thực hiện nguyên tắc làm việc tập thể. | 3 | **3đ:** Phối hợp đầy đủ. **2đ:** 1 lần phải nhắc. **1đ:** 2 lần phải nhắc. **0đ:** Từ 3 lần hoặc có hành vi cản trở, gây mất đoàn kết được xác minh. | Biên bản họp; kết quả phối hợp. |
| | **TỔNG A2** | **7** | | |

## A3. Tác phong, lề lối làm việc – 4 điểm

| Mã | Nội dung đánh giá | Điểm tối đa | Mức điểm cụ thể | Minh chứng |
|---|---|---:|---|---|
| A3.1 | Chấp hành thời gian làm việc, lịch công tác và các nhiệm vụ trực, họp, điều hành bắt buộc. | 2 | **2đ:** Không vi phạm. **1đ:** 1 lần đi muộn, vắng không đúng quy định. **0đ:** Từ 2 lần. | Lịch công tác; biên bản; chấm công. |
| A3.2 | Giao tiếp chuẩn mực, thực hiện chế độ thông tin, giải trình và phong cách làm việc khoa học. | 2 | **2đ:** Thực hiện đúng. **1đ:** 1 sai sót nhẹ. **0đ:** Từ 2 sai sót hoặc vi phạm nghiêm trọng. | Quan sát; hồ sơ; phản ánh đã xác minh. |
| | **TỔNG A3** | **4** | | |

## A4. Đổi mới, sáng tạo, tự học và chuyển đổi số – 4 điểm

| Mã | Nội dung đánh giá | Điểm tối đa | Mức điểm cụ thể | Minh chứng |
|---|---|---:|---|---|
| A4.1 | Tự học, cập nhật kiến thức quản lý, nghiên cứu văn bản và vận dụng vào quản trị nhà trường. | 2 | **2đ:** Có ít nhất 1 nội dung được vận dụng. **1đ:** Có học nhưng chưa có minh chứng vận dụng. **0đ:** Không thực hiện nội dung bồi dưỡng theo yêu cầu. | Nội dung bồi dưỡng; kết quả vận dụng. |
| A4.2 | Cải tiến quy trình quản lý, ứng dụng công nghệ và chuyển đổi số phù hợp nhiệm vụ. | 2 | **2đ:** Có ít nhất 1 cải tiến được áp dụng, chứng minh hiệu quả. **1đ:** Có thử nghiệm nhưng chưa đánh giá được hiệu quả. **0đ:** Không có cải tiến được ghi nhận. | Quy trình; dữ liệu; sản phẩm cải tiến. |
| | **TỔNG A4** | **4** | | |

# IV. TIÊU CHÍ KẾT QUẢ THỰC HIỆN NHIỆM VỤ QUẢN LÝ – 70 ĐIỂM

## B1. Số lượng, chất lượng, tiến độ thực hiện nhiệm vụ cá nhân – 25 điểm

| Mã | Nội dung công việc | Điểm tối đa | Quy định mức điểm | Minh chứng |
|---|---|---:|---|---|
| B1.1 | Hoàn thành các đầu việc, sản phẩm quản lý, báo cáo, nhiệm vụ cá nhân đã được giao và đến hạn trong tháng. | 10 | **10đ:** Đủ 100%. **8đ:** Từ 90% đến dưới 100%. **4đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Bảng giao việc; kế hoạch cá nhân; sản phẩm. |
| B1.2 | Chất lượng kế hoạch, văn bản tham mưu, quyết định, báo cáo và sản phẩm quản lý thuộc trách nhiệm cá nhân. | 8 | **8đ:** Đúng yêu cầu, không sai sót. **6đ:** 1 sai sót nhẹ đã sửa. **3đ:** 2 sai sót nhẹ. **0đ:** Từ 3 sai sót hoặc sai sót nghiêm trọng đã xác minh. | Văn bản; kết quả kiểm tra; ý kiến cơ quan tiếp nhận. |
| B1.3 | Hoàn thành công việc theo tiến độ, thời hạn đã được giao hoặc được điều chỉnh hợp lệ. | 7 | **7đ:** Tất cả đúng hạn. **5đ:** 1 lần trễ không quá 1 ngày. **2đ:** 2 lần trễ hoặc 1 lần trễ quá 1 ngày. **0đ:** Từ 3 lần trễ hoặc bỏ nhiệm vụ bắt buộc. | Lịch công tác; hạn nhiệm vụ; thời điểm hoàn thành. |
| | **TỔNG B1** | **25** | | |

**Cách kiểm tra B1:** Lập bảng giao nhiệm vụ theo tháng có tối thiểu bốn thông tin: tên sản phẩm, người chịu trách nhiệm, thời hạn và tiêu chuẩn nghiệm thu. Không đưa vào đánh giá những công việc chưa đến hạn hoặc không thuộc trách nhiệm cá nhân.

## B2. Kết quả lĩnh vực, đơn vị được phân công quản lý – 25 điểm

| Mã | Nội dung công việc | Điểm tối đa | Quy định mức điểm | Minh chứng |
|---|---|---:|---|---|
| B2.1 | Mức độ hoàn thành các chỉ tiêu, nhiệm vụ trọng tâm thuộc phạm vi quản lý trong tháng. | 10 | **10đ:** Đạt 100% chỉ tiêu đến hạn. **8đ:** Từ 90% đến dưới 100%. **4đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Bảng chỉ tiêu tháng; kết quả thực hiện. |
| B2.2 | Chất lượng quản lý lĩnh vực phụ trách: bảo đảm yêu cầu chuyên môn, an toàn, đúng quy trình và trách nhiệm chỉ đạo. | 10 | **10đ:** Không có sai sót quản lý được xác minh. **7đ:** 1 sai sót quản lý nhẹ đã khắc phục. **3đ:** 2 sai sót quản lý nhẹ. **0đ:** Từ 3 sai sót hoặc 1 sai phạm quản lý nghiêm trọng đã được xác minh. | Kết quả kiểm tra; biên bản; hồ sơ quản lý. |
| B2.3 | Thực hiện các biện pháp khắc phục tồn tại, phòng ngừa rủi ro và cải thiện kết quả thuộc lĩnh vực phụ trách theo kế hoạch. | 5 | **5đ:** Hoàn thành 100% đầu việc đến hạn. **4đ:** Từ 90% đến dưới 100%. **2đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch khắc phục; kết quả kiểm tra lại. |
| | **TỔNG B2** | **25** | | |

**Nguyên tắc xác định trách nhiệm quản lý:** Không tự động trừ điểm hiệu trưởng hoặc phó hiệu trưởng chỉ vì giáo viên, nhân viên có sai sót. Chỉ tính trách nhiệm quản lý khi có căn cứ cho thấy người quản lý chưa thực hiện đúng nhiệm vụ chỉ đạo, phân công, kiểm tra, đôn đốc, cảnh báo hoặc xử lý thuộc thẩm quyền.

Nếu có sai phạm nghiêm trọng thuộc phạm vi quản lý, việc đánh giá và xử lý còn phải tuân thủ các quy định pháp luật có liên quan.

## B3. Tổ chức, điều hành, kiểm tra – 10 điểm

| Mã | Nội dung công việc | Điểm tối đa | Quy định mức điểm | Minh chứng |
|---|---|---:|---|---|
| B3.1 | Phân công, giao việc rõ nội dung, trách nhiệm, yêu cầu sản phẩm và thời hạn cho cá nhân, bộ phận được phụ trách. | 4 | **4đ:** Đúng, đủ, không sai sót. **3đ:** 1 sai sót nhẹ được sửa. **1đ:** 2 sai sót. **0đ:** Từ 3 sai sót hoặc sai sót nghiêm trọng. | Kế hoạch; bảng giao việc. |
| B3.2 | Thực hiện các lượt kiểm tra, hướng dẫn, giám sát, đôn đốc và theo dõi khắc phục theo kế hoạch. | 4 | **4đ:** Đủ 100%. **3đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Lịch kiểm tra; biên bản; phiếu theo dõi. |
| B3.3 | Tiếp nhận, giải quyết hoặc phản hồi những công việc, kiến nghị thuộc thẩm quyền đúng thời hạn. | 2 | **2đ:** Đúng hạn 100%. **1đ:** 1 lần chậm nhẹ, đã khắc phục. **0đ:** Từ 2 lần chậm hoặc một trường hợp trì hoãn nghiêm trọng thuộc trách nhiệm. | Hồ sơ xử lý; nhật ký giao việc. |
| | **TỔNG B3** | **10** | | |

## B4. Tập hợp, đoàn kết đội ngũ – 10 điểm

| Mã | Nội dung công việc | Điểm tối đa | Quy định mức điểm | Minh chứng |
|---|---|---:|---|---|
| B4.1 | Thực hiện dân chủ, công khai, minh bạch; lắng nghe, phản hồi và phối hợp trong quản lý đội ngũ. | 4 | **4đ:** Đúng quy trình, không sai sót. **3đ:** 1 sai sót nhẹ. **1đ:** 2 sai sót. **0đ:** Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh. | Biên bản họp; hồ sơ công khai, giải quyết ý kiến. |
| B4.2 | Hướng dẫn, hỗ trợ, bồi dưỡng, động viên đội ngũ và giải quyết khó khăn chuyên môn theo kế hoạch. | 4 | **4đ:** Hoàn thành 100% nhiệm vụ hỗ trợ. **3đ:** Từ 90% đến dưới 100%. **1đ:** Từ 70% đến dưới 90%. **0đ:** Dưới 70%. | Kế hoạch bồi dưỡng; ghi nhận hỗ trợ. |
| B4.3 | Giữ gìn đoàn kết nội bộ, phối hợp giải quyết bất đồng và phản ánh thuộc thẩm quyền. | 2 | **2đ:** Thực hiện đúng trách nhiệm, quy trình. **1đ:** 1 sai sót nhẹ được xác minh. **0đ:** Từ 2 sai sót hoặc hành vi nghiêm trọng gây mất đoàn kết được xác minh. | Biên bản; hồ sơ giải quyết công việc. |
| | **TỔNG B4** | **10** | | |

# V. CỤ THỂ HÓA NHIỆM VỤ THEO CHỨC DANH CÁN BỘ QUẢN LÝ

## 1. ĐỐI VỚI HIỆU TRƯỞNG

Hiệu trưởng chịu trách nhiệm quản lý tổng thể hoạt động của nhà trường theo thẩm quyền, kế hoạch, nhiệm vụ được giao.

**Nhóm B1 – 25 điểm: Nhiệm vụ cá nhân**

- Xây dựng, tổ chức thực hiện kế hoạch công tác tháng của nhà trường.
- Hoàn thành các văn bản quản lý, chỉ đạo, báo cáo, quyết định thuộc thẩm quyền và đến hạn.
- Thực hiện nhiệm vụ theo yêu cầu của cơ quan quản lý.
- Bảo đảm tiến độ xử lý các công việc thuộc trách nhiệm người đứng đầu.

**Nhóm B2 – 25 điểm: Kết quả hoạt động nhà trường**

Các chỉ tiêu được lượng hóa theo tháng từ những lĩnh vực trọng tâm:

| Lĩnh vực | Công việc, kết quả dùng để đánh giá |
|---|---|
| Chăm sóc, nuôi dưỡng, giáo dục | Mức hoàn thành các chỉ tiêu chất lượng và nhiệm vụ tháng theo kế hoạch được phê duyệt. |
| An toàn trường học | Chỉ đạo, kiểm soát, khắc phục các nguy cơ về an toàn trẻ, vệ sinh, an toàn thực phẩm và cơ sở vật chất. |
| Quản trị đội ngũ | Phân công nhân sự, triển khai đánh giá, hỗ trợ, bồi dưỡng và giải quyết những vấn đề thuộc thẩm quyền. |
| Tài chính, tài sản | Chỉ đạo quản lý, sử dụng nguồn lực, công khai, kiểm soát hồ sơ đúng quy định. |
| Kiểm tra, cải tiến | Triển khai các nhiệm vụ kiểm tra, xử lý kiến nghị, khắc phục tồn tại đến hạn. |
| Nhiệm vụ khác | Phổ cập giáo dục, kiểm định chất lượng, chuyển đổi số, nhiệm vụ cấp trên giao theo kế hoạch và thời điểm phát sinh hợp lệ. |

**Nhóm B3 – 10 điểm: Điều hành**

Đánh giá việc giao nhiệm vụ rõ ràng, tổ chức kiểm tra, chỉ đạo khắc phục và xử lý kịp thời các công việc thuộc thẩm quyền.

**Nhóm B4 – 10 điểm: Xây dựng đội ngũ**

Đánh giá trách nhiệm nêu gương, thực hiện dân chủ, công khai, giải quyết vướng mắc, tạo môi trường làm việc đoàn kết và hỗ trợ phát triển đội ngũ.

**Điểm cần lưu ý:** Hiệu trưởng không tự quyết định mức xếp loại viên chức chính thức hằng năm đối với chính mình; việc đánh giá, xếp loại thực hiện theo thẩm quyền của cơ quan quản lý đơn vị.

## 2. ĐỐI VỚI PHÓ HIỆU TRƯỞNG PHỤ TRÁCH CHUYÊN MÔN

**Nhóm B1 – 25 điểm: Nhiệm vụ cá nhân**

- Xây dựng và thực hiện kế hoạch quản lý chuyên môn tháng.
- Tham mưu, hoàn thành văn bản, báo cáo và nhiệm vụ chuyên môn được phân công.
- Hoàn thành nhiệm vụ kiểm tra, hướng dẫn và điều chỉnh kế hoạch chuyên môn đúng hạn.

**Nhóm B2 – 25 điểm: Kết quả lĩnh vực chuyên môn**

| Lĩnh vực | Chỉ tiêu, sản phẩm cần theo dõi |
|---|---|
| Kế hoạch giáo dục | Tỷ lệ kế hoạch, nhiệm vụ giáo dục được triển khai và hoàn thành theo thời hạn đã thống nhất. |
| Chất lượng hoạt động | Kết quả quan sát, kiểm tra hoạt động; mức độ thực hiện các yêu cầu chuyên môn và cải thiện sau góp ý. |
| Môi trường giáo dục | Kết quả tổ chức môi trường học tập, vui chơi an toàn, phù hợp độ tuổi, lấy trẻ làm trung tâm. |
| Theo dõi trẻ | Việc thực hiện quan sát, đánh giá sự phát triển và hỗ trợ trẻ của các nhóm, lớp thuộc phạm vi phụ trách. |
| Phát triển giáo viên | Kết quả sinh hoạt chuyên môn, bồi dưỡng, dự giờ, hỗ trợ giáo viên theo kế hoạch. |
| Kiểm tra, khắc phục | Tỷ lệ nội dung tồn tại, hạn chế chuyên môn được xử lý đúng thời hạn và đạt yêu cầu. |

**Nhóm B3 – 10 điểm: Tổ chức, điều hành chuyên môn**

Đánh giá chất lượng phân công giáo viên, tổ chức kiểm tra, hỗ trợ chuyên môn, theo dõi tiến độ và giải quyết khó khăn trong các nhóm lớp.

**Nhóm B4 – 10 điểm: Phát triển, đoàn kết đội ngũ**

Đánh giá khả năng lắng nghe, hướng dẫn, hỗ trợ chuyên môn, công bằng trong nhận xét giáo viên và phối hợp với các tổ chuyên môn.

Không sử dụng riêng tỷ lệ trẻ đạt mục tiêu phát triển hoặc tỷ lệ hồ sơ giáo viên đầy đủ làm căn cứ duy nhất để đánh giá chất lượng quản lý chuyên môn.

## 3. ĐỐI VỚI PHÓ HIỆU TRƯỞNG PHỤ TRÁCH NUÔI DƯỠNG, CƠ SỞ VẬT CHẤT

**Nhóm B1 – 25 điểm: Nhiệm vụ cá nhân**

- Xây dựng và thực hiện kế hoạch công tác nuôi dưỡng, chăm sóc sức khỏe, cơ sở vật chất theo phân công.
- Hoàn thành các hồ sơ, báo cáo quản lý, tham mưu và nhiệm vụ đến hạn.
- Bảo đảm tiến độ kiểm tra, phối hợp, giám sát các bộ phận thuộc phạm vi phụ trách.

**Nhóm B2 – 25 điểm: Kết quả lĩnh vực phụ trách**

| Lĩnh vực | Chỉ tiêu, sản phẩm cần theo dõi |
|---|---|
| Tổ chức bữa ăn | Kiểm tra thực đơn, chế biến, giao nhận và tổ chức ăn theo nhiệm vụ quản lý được giao. |
| An toàn thực phẩm | Kết quả chỉ đạo, giám sát quy trình tiếp nhận, bảo quản, chế biến, kiểm thực và lưu mẫu thức ăn. |
| Chăm sóc sức khỏe | Kết quả phối hợp theo dõi sức khỏe, vệ sinh, phòng bệnh và các nhiệm vụ y tế trường học. |
| Cơ sở vật chất | Mức hoàn thành kiểm tra, phát hiện hư hỏng, tham mưu sửa chữa, bảo trì và xử lý nguy cơ mất an toàn. |
| Đội ngũ nhân viên | Kết quả phân công, hướng dẫn, kiểm tra, bồi dưỡng và phối hợp đối với nhân viên thuộc phạm vi quản lý. |
| Khắc phục hạn chế | Tỷ lệ nhiệm vụ xử lý tồn tại, cải tiến quy trình nuôi dưỡng và cơ sở vật chất đã hoàn thành, đạt yêu cầu. |

**Nhóm B3 – 10 điểm: Tổ chức, điều hành**

Đánh giá việc phân công các bộ phận, tổ chức kiểm tra thực tế, giám sát, đôn đốc và xử lý công việc theo đúng trách nhiệm.

**Nhóm B4 – 10 điểm: Phối hợp, phát triển đội ngũ**

Đánh giá khả năng phối hợp với giáo viên, nhân viên bếp, y tế, kế toán và các bộ phận; hỗ trợ tháo gỡ khó khăn, bảo đảm đoàn kết và hiệu quả công việc.

Không tự động quy trách nhiệm quản lý khi phát sinh vấn đề do nhà cung cấp, yếu tố khách quan hoặc cá nhân khác. Cần đối chiếu trách nhiệm trong quy trình kiểm tra, phát hiện, báo cáo và xử lý.

# VI. MẪU BẢNG GIAO CHỈ TIÊU HẰNG THÁNG CHO CBQL

Để có căn cứ chấm B1 và B2, nhà trường cần xây dựng bảng nhiệm vụ theo tháng ngay từ đầu kỳ đánh giá.

| STT | Nhiệm vụ, chỉ tiêu cần hoàn thành | Sản phẩm, mức yêu cầu | Thời hạn | Kết quả thực hiện | Minh chứng |
|---|---|---|---|---|---|
| 1 | ................................ | ........................ | ........ | ........ | ........ |
| 2 | ................................ | ........................ | ........ | ........ | ........ |
| 3 | ................................ | ........................ | ........ | ........ | ........ |
| 4 | ................................ | ........................ | ........ | ........ | ........ |
| 5 | ................................ | ........................ | ........ | ........ | ........ |

**Nguyên tắc giao chỉ tiêu:**

- Chỉ tiêu phải thuộc thẩm quyền, nhiệm vụ hoặc phạm vi quản lý của người được đánh giá.
- Mỗi chỉ tiêu phải xác định sản phẩm hoặc kết quả kiểm chứng được.
- Chỉ đánh giá công việc đến hạn trong tháng.
- Các chỉ tiêu chưa phát sinh phải có phương án thay thế hoặc điều chỉnh được chấp thuận.
- Các kết quả phụ thuộc nhiều bộ phận phải có cơ chế xác định rõ trách nhiệm quản lý và trách nhiệm thực hiện.

# VII. VÍ DỤ MINH HỌA CHẤM KPI CÁN BỘ QUẢN LÝ

Giả sử một phó hiệu trưởng phụ trách chuyên môn có kết quả tháng như sau:

| Nhóm tiêu chí | Tối đa | Điểm đạt |
|---|---:|---:|
| A1. Phẩm chất, đạo đức, kỷ luật | 15 | 15 |
| A2. Trách nhiệm, đoàn kết | 7 | 7 |
| A3. Tác phong, lề lối | 4 | 4 |
| A4. Đổi mới, tự học | 4 | 3 |
| B1. Nhiệm vụ cá nhân | 25 | 23 |
| B2. Kết quả lĩnh vực phụ trách | 25 | 20 |
| B3. Tổ chức, điều hành, kiểm tra | 10 | 9 |
| B4. Tập hợp, đoàn kết đội ngũ | 10 | 8 |
| **TỔNG CỘNG** | **100** | **94** |

**Kết quả:** 94/100 điểm – Mức điểm theo dõi xuất sắc.

**Ưu điểm:** Chủ động thực hiện công việc; hoàn thành phần lớn chỉ tiêu chuyên môn; tích cực hỗ trợ giáo viên.

**Nội dung cần cải thiện:** Tăng hiệu quả khắc phục những hạn chế đã phát hiện; cải tiến chất lượng tổ chức kiểm tra, hỗ trợ chuyên môn.

Điểm 94 là kết quả theo dõi tháng; không tự động xác lập mức xếp loại viên chức hoàn thành xuất sắc nhiệm vụ cuối năm.

# VIII. MẪU PHIẾU CHẤM KPI CÁN BỘ QUẢN LÝ HẰNG THÁNG

**TRƯỜNG MẦM NON:** .....................................................

**PHIẾU ĐÁNH GIÁ KPI CÁN BỘ QUẢN LÝ THÁNG ......... NĂM .........**

Họ và tên: ........................................................................

Chức vụ: ..........................................................................

Lĩnh vực phụ trách: .............................................................

| Mã KPI | Tiêu chí đánh giá | Điểm tối đa | Tự chấm | Điểm xác nhận |
|---|---|---:|---:|---:|
| A1.1 | Gương mẫu, phẩm chất, đạo đức nghề nghiệp | 6 | | |
| A1.2 | Liêm chính, minh bạch trong quản lý | 5 | | |
| A1.3 | Chấp hành quy chế, bảo mật, trách nhiệm an toàn | 4 | | |
| A2.1 | Trách nhiệm, chủ động thực hiện nhiệm vụ | 4 | | |
| A2.2 | Phối hợp, đoàn kết trong tập thể | 3 | | |
| A3.1 | Chấp hành giờ giấc, lịch công tác | 2 | | |
| A3.2 | Tác phong, giao tiếp, giải trình | 2 | | |
| A4.1 | Tự học, bồi dưỡng quản lý | 2 | | |
| A4.2 | Cải tiến, chuyển đổi số | 2 | | |
| | **CỘNG NHÓM A** | **30** | | |
| B1.1 | Khối lượng nhiệm vụ cá nhân | 10 | | |
| B1.2 | Chất lượng sản phẩm quản lý | 8 | | |
| B1.3 | Tiến độ nhiệm vụ cá nhân | 7 | | |
| | **CỘNG B1** | **25** | | |
| B2.1 | Hoàn thành chỉ tiêu lĩnh vực, đơn vị phụ trách | 10 | | |
| B2.2 | Chất lượng quản lý lĩnh vực | 10 | | |
| B2.3 | Khắc phục hạn chế, phòng ngừa rủi ro | 5 | | |
| | **CỘNG B2** | **25** | | |
| B3.1 | Phân công, giao việc | 4 | | |
| B3.2 | Kiểm tra, giám sát, đôn đốc | 4 | | |
| B3.3 | Giải quyết công việc, kiến nghị | 2 | | |
| | **CỘNG B3** | **10** | | |
| B4.1 | Dân chủ, công khai, minh bạch | 4 | | |
| B4.2 | Hỗ trợ, bồi dưỡng đội ngũ | 4 | | |
| B4.3 | Giữ gìn đoàn kết, giải quyết bất đồng | 2 | | |
| | **CỘNG B4** | **10** | | |
| | **TỔNG CỘNG** | **100** | | |

**Mức điểm theo dõi:** .................................................

**1. Ưu điểm:**

....................................................................................

....................................................................................

**2. Tồn tại, hạn chế:**

....................................................................................

....................................................................................

**3. Nhiệm vụ, giải pháp cần thực hiện trong tháng tiếp theo:**

....................................................................................

....................................................................................

**4. Ý kiến của người được đánh giá:**

....................................................................................

....................................................................................

| NGƯỜI TỰ ĐÁNH GIÁ | NGƯỜI THEO DÕI, ĐÁNH GIÁ THEO THẨM QUYỀN |
|---|---|
| (Ký, ghi rõ họ tên) | (Ký, ghi rõ họ tên) |
| | |
| | |

# IX. NGUYÊN TẮC VÀ QUY TRÌNH ÁP DỤNG

**1. Đối với hiệu trưởng**

Việc giao nhiệm vụ, theo dõi và xếp loại chất lượng thực hiện theo thẩm quyền của cơ quan quản lý đơn vị. Kết quả KPI của nhà trường có thể được sử dụng làm dữ liệu tự đánh giá, báo cáo và giải trình theo yêu cầu.

**2. Đối với phó hiệu trưởng**

Hiệu trưởng phân công nhiệm vụ, xác định chỉ tiêu và tổ chức theo dõi, đánh giá theo tháng trong phạm vi thẩm quyền.

**3. Về thời gian triển khai**

- Đầu tháng: giao nhiệm vụ và chỉ tiêu.
- Trong tháng: theo dõi, kiểm tra, xác nhận tiến độ và chất lượng.
- Cuối tháng: cá nhân tự đánh giá, đối chiếu minh chứng.
- Sau kỳ đánh giá: người có thẩm quyền xem xét, thông báo điểm và xác định nội dung cần khắc phục.

**4. Về công bằng trong đánh giá**

Không so sánh trực tiếp hiệu trưởng với phó hiệu trưởng bằng số lượng đầu việc tuyệt đối. Việc đánh giá phải căn cứ khối lượng, mức độ phức tạp và trách nhiệm được giao.

**5. Về xử lý vi phạm**

Các trường hợp vi phạm nghiêm trọng phải được xác minh và giải quyết đúng quy định, không xem việc trừ điểm KPI là biện pháp thay thế trách nhiệm pháp lý hoặc trách nhiệm quản lý.

**6. Về kết quả xếp loại**

KPI tháng là cơ sở theo dõi. Việc xếp loại chất lượng viên chức hằng năm phải căn cứ kết quả theo dõi, các điều kiện xếp loại, thẩm quyền và trình tự theo Nghị định 233/2026/NĐ-CP.

# X. KẾT LUẬN

Bảng KPI cán bộ quản lý được xây dựng theo cơ cấu 30 điểm tiêu chí chung và 70 điểm kết quả nhiệm vụ, trong đó 25 điểm phản ánh nhiệm vụ cá nhân, 25 điểm phản ánh kết quả lĩnh vực hoặc đơn vị phụ trách, 10 điểm đánh giá năng lực tổ chức điều hành và 10 điểm đánh giá năng lực tập hợp, đoàn kết đội ngũ.

Việc đánh giá phải tập trung vào trách nhiệm quản lý, chất lượng kết quả thực hiện, hiệu quả sử dụng nguồn lực, khả năng phòng ngừa rủi ro và phát triển đội ngũ.

**Yêu cầu xuyên suốt:** Cán bộ quản lý được đánh giá bằng sản phẩm và hiệu quả quản lý thực tế, có minh chứng rõ ràng, công bằng theo thẩm quyền, trách nhiệm và phạm vi công tác được giao.
</WritingBlock>

---

## 💡 Đề xuất của tôi để nhà trường áp dụng đồng bộ

Sau khi hoàn thành ba bộ KPI cho giáo viên, nhân viên và CBQL, tôi đề xuất nhà trường ban hành thành **ba phụ lục thống nhất kèm Quy chế đánh giá**, đồng thời sử dụng một bảng tổng hợp điểm chung cho toàn trường.

| Phụ lục | Đối tượng | Nội dung |
|---|---|---|
| 01 | Giáo viên | 23 chỉ tiêu chi tiết |
| 02 | Nhân viên | 9 tiêu chí chung và 9 tiêu chí nhiệm vụ theo từng vị trí |
| 03 | Cán bộ quản lý | 9 tiêu chí chung và 11 tiêu chí nhiệm vụ quản lý |

Cả ba bộ đều sử dụng chung ngưỡng điểm theo dõi:

- **90–100 điểm:** Mức xuất sắc.
- **70 đến dưới 90 điểm:** Mức tốt.
- **50 đến dưới 70 điểm:** Mức hoàn thành.
- **Dưới 50 điểm:** Mức chưa hoàn thành.

Tuy nhiên, khi xếp loại viên chức cuối năm còn phải xem xét các điều kiện ngoài điểm số, giới hạn tỷ lệ hoàn thành xuất sắc nhiệm vụ và các trường hợp không hoàn thành nhiệm vụ theo Điều 12 Nghị định 233/2026/NĐ-CP. Riêng mức xếp loại người đứng đầu không được cao hơn mức xếp loại của đơn vị. <Cite ref="turn887157view1"/>

**Một điểm tôi đặc biệt khuyến nghị:** Trước khi áp dụng chính thức, nhà trường nên giao nhiệm vụ cụ thể theo tháng cho từng vị trí, thử chấm ít nhất một kỳ, lấy ý kiến của đội ngũ rồi hoàn thiện phụ lục. Nghị định 233/2026/NĐ-CP quy định đơn vị sự nghiệp công lập phải ban hành quy chế đánh giá chậm nhất ngày 30/11/2026. <Cite ref="turn887157view3"/>

Hai bản trên đã được trình bày dưới dạng tài liệu có thể chỉnh sửa, sao chép sang Word. Trong phiên này tôi chưa thể đính kèm trực tiếp tệp `.docx`. Khi đưa vào văn bản chính thức, nên dùng giấy A4 ngang cho các bảng tiêu chí chi tiết để bảo đảm dễ đọc và dễ chấm điểm.

---

