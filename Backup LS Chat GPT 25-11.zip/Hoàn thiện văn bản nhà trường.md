USER

dựa theo văn bản của sở và UBND cùng lịch sinh hoạt của nhà trường đính kèm. với vai trò hiệu trưởng bạn giúp mình hoàn thành nội dung văn bản theo đúng yêu cầu của Sở

---

ASSISTANT

Tôi sẽ đối chiếu công văn của Sở, chỉ đạo của UBND phường và ba lịch sinh hoạt của trường để soạn văn bản triển khai năm học 2026–2027. Tôi cũng sẽ kiểm tra các mốc thời gian và làm rõ phần quy đổi giờ trông trẻ buổi trưa, vì đây là nội dung Sở yêu cầu hiệu trưởng quyết định bằng văn bản sau khi thông qua tập thể giáo viên.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 Hoàn thiện văn bản thực hiện chế độ làm việc và quy đổi giờ trông trẻ buổi trưa năm học 2026–2027

Tôi đã đối chiếu 3 tài liệu của **Trường Mầm non An Bình**, gồm Công văn số 4172/SGDĐT-GDMN ngày 21/10/2026 của Sở GDĐT Đồng Tháp, Công văn số 6347/VP-VX ngày 23/10/2026 của Văn phòng HĐND và UBND phường An Bình và lịch sinh hoạt năm học 2026–2027 của nhà trường.

Với trách nhiệm của hiệu trưởng, tôi đề xuất nhà trường ban hành **Kế hoạch triển khai thực hiện**, sau đó tổ chức họp tập thể giáo viên và ban hành **Quyết định quy đổi thời gian trông trẻ buổi trưa ra giờ dạy**. Đây là cách tổ chức hồ sơ bảo đảm cả yêu cầu quản lý chuyên môn lẫn căn cứ tính chế độ cho giáo viên.

## 🎯 Những yêu cầu nhà trường phải thực hiện

| Nội dung | Yêu cầu |
|--------|--------|
| Thời gian làm việc | 40 giờ/tuần, tương ứng 8 giờ/ngày |
| Định mức giờ dạy lớp học 2 buổi/ngày | 5 giờ 30 phút/giáo viên/ngày |
| Trông trẻ buổi trưa | Quy đổi không quá 2 giờ dạy/giáo viên/buổi |
| Thẩm quyền quyết định | Hiệu trưởng quyết định bằng văn bản sau khi thông qua cuộc họp tập thể giáo viên |
| Chi trả dạy thêm giờ | Chỉ tính khi phát sinh giờ dạy thêm đủ điều kiện theo Thông tư 21/2025/TT-BGDĐT |
| Kinh phí | Từ nguồn tài chính hợp pháp của đơn vị theo cơ chế tự chủ |

**Lưu ý quan trọng:** Lịch sinh hoạt lớp mẫu giáo không bán trú hiện có một số điểm chưa thống nhất:

- Khung 7h00–11h00 thực tế là 240 phút, nhưng ghi 210 phút.
- Khung 15h40–16h30 là 50 phút, nhưng ghi 30 phút.
- Thời điểm trả trẻ buổi sáng ghi 11h00 trong bảng, nhưng phần quy định cuối lịch ghi 10h30.

Các điểm này cần thống nhất trước khi ban hành lịch chính thức và phân công giờ làm việc giáo viên.

## 📖 Văn bản 1. Kế hoạch triển khai thực hiện của nhà trường

Đây là văn bản triển khai chung, xác định trách nhiệm của Ban giám hiệu, tổ chuyên môn, giáo viên và kế toán. Nội dung đã được xây dựng theo lịch sinh hoạt của trường và yêu cầu tại Công văn 4172.

> **writing · document**
>
> **ỦY BAN NHÂN DÂN PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập - Tự do - Hạnh phúc**
>
> Số: …/KH-MNAB
>
> *An Bình, ngày … tháng … năm 2026*
>
> # KẾ HOẠCH
> **Triển khai thực hiện chế độ làm việc, quy đổi thời gian trông trẻ buổi trưa ra giờ dạy và chi trả tiền lương dạy thêm giờ cho giáo viên mầm non năm học 2026–2027**
>
> Căn cứ Chương trình Giáo dục mầm non ban hành kèm theo Thông tư số 17/2009/TT-BGDĐT ngày 25 tháng 7 năm 2009 của Bộ Giáo dục và Đào tạo, được sửa đổi, bổ sung bởi Thông tư số 28/2016/TT-BGDĐT ngày 30 tháng 12 năm 2016 và Thông tư số 51/2020/TT-BGDĐT ngày 31 tháng 12 năm 2020;
>
> Căn cứ Thông tư số 11/2026/TT-BGDĐT ngày 04 tháng 3 năm 2026 của Bộ trưởng Bộ Giáo dục và Đào tạo quy định chế độ làm việc đối với giáo viên mầm non;
>
> Căn cứ Thông tư số 21/2025/TT-BGDĐT ngày 23 tháng 9 năm 2025 của Bộ trưởng Bộ Giáo dục và Đào tạo quy định chế độ trả tiền lương dạy thêm giờ đối với nhà giáo trong các cơ sở giáo dục công lập;
>
> Căn cứ Quyết định số 105/2026/QĐ-UBND ngày 11 tháng 9 năm 2026 của Ủy ban nhân dân tỉnh Đồng Tháp ban hành Quy định các khoản thu, mức thu và cơ chế quản lý thu, chi đối với các dịch vụ phục vụ hoạt động giáo dục, đào tạo trong cơ sở giáo dục công lập trên địa bàn tỉnh Đồng Tháp;
>
> Thực hiện Công văn số 4172/SGDĐT-GDMN ngày 21 tháng 10 năm 2026 của Sở Giáo dục và Đào tạo Đồng Tháp về việc hướng dẫn thời gian làm việc và chi trả chế độ trông giữ trẻ buổi trưa cho giáo viên mầm non từ năm học 2026–2027;
>
> Thực hiện Công văn số 6347/VP-VX ngày 23 tháng 10 năm 2026 của Văn phòng HĐND và UBND phường An Bình về việc hướng dẫn thời gian làm việc và chi trả chế độ trông giữ trẻ buổi trưa cho giáo viên mầm non từ năm học 2026–2027;
>
> Căn cứ điều kiện thực tế về đội ngũ giáo viên, số nhóm, lớp, số trẻ tham gia bán trú và lịch sinh hoạt năm học 2026–2027 của nhà trường;
>
> Trường Mầm non An Bình xây dựng Kế hoạch triển khai thực hiện chế độ làm việc, quy đổi thời gian trông trẻ buổi trưa ra giờ dạy và chi trả tiền lương dạy thêm giờ cho giáo viên năm học 2026–2027, cụ thể như sau:
>
> ## I. MỤC ĐÍCH, YÊU CẦU
>
> **1. Mục đích**
>
> Tổ chức thực hiện thống nhất các quy định về thời gian làm việc, định mức giờ dạy và quy đổi thời gian trông trẻ buổi trưa đối với giáo viên mầm non theo hướng dẫn của Bộ Giáo dục và Đào tạo, Sở Giáo dục và Đào tạo Đồng Tháp và chỉ đạo của UBND phường An Bình.
>
> Bố trí, sử dụng đội ngũ giáo viên hợp lý, phù hợp với chế độ sinh hoạt của trẻ, bảo đảm thực hiện đầy đủ Chương trình Giáo dục mầm non và nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Bảo đảm quyền lợi chính đáng của giáo viên; thực hiện việc xác định giờ dạy, giờ dạy quy đổi và chi trả tiền lương dạy thêm giờ đúng quy định, công khai, minh bạch, phù hợp với khả năng tài chính của nhà trường.
>
> **2. Yêu cầu**
>
> Việc tổ chức thời gian làm việc của giáo viên phải căn cứ vào lịch sinh hoạt của từng độ tuổi, thời gian trẻ có mặt tại trường, số lượng trẻ bán trú và điều kiện thực tế của đơn vị.
>
> Phân công giáo viên thực hiện nhiệm vụ chăm sóc, nuôi dưỡng, giáo dục trẻ, đón trẻ, trả trẻ và trông trẻ buổi trưa hợp lý; bảo đảm thời gian làm việc, định mức giờ dạy, thời gian nghỉ theo quy định.
>
> Việc quy đổi thời gian trông trẻ buổi trưa phải được thông qua cuộc họp tập thể giáo viên và do Hiệu trưởng quyết định bằng văn bản; không thực hiện quy đổi, thanh toán theo hình thức khoán hoặc mặc nhiên áp dụng mức tối đa khi chưa đủ căn cứ.
>
> Thực hiện đầy đủ hồ sơ phân công nhiệm vụ, bảng theo dõi thời gian trông trẻ, bảng tổng hợp giờ dạy và các chứng từ liên quan, bảo đảm tính chính xác, công khai và thuận lợi cho công tác kiểm tra, đối chiếu.
>
> ## II. NỘI DUNG THỰC HIỆN
>
> **1. Thực hiện chế độ sinh hoạt trong ngày của trẻ**
>
> Nhà trường tổ chức chế độ sinh hoạt hằng ngày theo Chương trình Giáo dục mầm non, phù hợp với từng độ tuổi, nhu cầu của trẻ và điều kiện tổ chức chăm sóc, nuôi dưỡng, giáo dục tại đơn vị.
>
> Căn cứ lịch sinh hoạt năm học 2026–2027, thời gian tổ chức hoạt động của các nhóm, lớp được xác định như sau:
>
> **a) Đối với nhóm trẻ 25–36 tháng**
>
> - Thời gian trẻ có mặt tại trường: từ 07 giờ 00 phút đến 17 giờ 00 phút.
> - Tổng thời gian sinh hoạt tại trường: 600 phút/ngày.
> - Thời gian tổ chức ăn bữa chính buổi trưa: từ 10 giờ 00 phút đến 11 giờ 00 phút.
> - Thời gian ngủ trưa: từ 11 giờ 00 phút đến 13 giờ 30 phút, tổng cộng 150 phút.
> - Các hoạt động đón trẻ, chơi - tập, vệ sinh, ăn bữa phụ, ăn bữa chính buổi chiều và trả trẻ được tổ chức theo lịch sinh hoạt của nhóm trẻ.
>
> **b) Đối với lớp mẫu giáo bán trú**
>
> - Thời gian trẻ có mặt tại trường: từ 07 giờ 00 phút đến 17 giờ 00 phút.
> - Tổng thời gian sinh hoạt tại trường: 600 phút/ngày.
> - Thời gian ăn trưa, vệ sinh và chuẩn bị ngủ: từ 10 giờ 20 phút đến 11 giờ 30 phút.
> - Thời gian ngủ trưa: từ 11 giờ 30 phút đến 14 giờ 00 phút, tổng cộng 150 phút.
> - Các hoạt động còn lại được tổ chức theo lịch sinh hoạt của lớp mẫu giáo, bảo đảm cân đối thời lượng hoạt động học, vui chơi, ăn, ngủ, vệ sinh và hoạt động chiều.
>
> **c) Đối với lớp mẫu giáo học 02 buổi/ngày không tổ chức bán trú**
>
> Nhà trường rà soát, thống nhất thời gian tổ chức hoạt động buổi sáng, buổi chiều và thời điểm đón, trả trẻ theo lịch sinh hoạt được điều chỉnh, phê duyệt.
>
> Dự kiến áp dụng thời gian:
>
> - Buổi sáng: từ 07 giờ 00 phút đến 10 giờ 30 phút.
> - Buổi chiều: từ 14 giờ 00 phút đến 17 giờ 00 phút.
> - Tổng thời gian trẻ có mặt tại trường: 390 phút/ngày.
>
> Trong khoảng thời gian giữa hai buổi học, trẻ trở về gia đình để ăn trưa, nghỉ trưa và được gia đình chăm sóc. Nhà trường không tổ chức trông trẻ buổi trưa đối với các lớp này nên không thực hiện quy đổi giờ trông trẻ buổi trưa.
>
> Phó Hiệu trưởng phụ trách chuyên môn có trách nhiệm rà soát, điều chỉnh và trình Hiệu trưởng phê duyệt lịch sinh hoạt chính thức, bảo đảm thống nhất các mốc thời gian, thời lượng hoạt động và phù hợp với Chương trình Giáo dục mầm non.
>
> **2. Thực hiện chế độ làm việc và định mức giờ dạy của giáo viên**
>
> Thời gian làm việc của giáo viên mầm non thực hiện theo năm học, bảo đảm 40 giờ/tuần, tương ứng 08 giờ/ngày đối với tuần làm việc 05 ngày.
>
> Định mức giờ dạy đối với giáo viên giảng dạy tại các nhóm trẻ, lớp mẫu giáo học 02 buổi/ngày là 05 giờ 30 phút/ngày theo quy định tại Điều 7 Thông tư số 11/2026/TT-BGDĐT.
>
> Thời gian làm việc của giáo viên bao gồm thời gian giảng dạy theo định mức và thời gian thực hiện các nhiệm vụ nghề nghiệp khác như chuẩn bị giờ dạy, đón trẻ, trả trẻ, xây dựng kế hoạch giáo dục, hoàn thiện hồ sơ chuyên môn, sinh hoạt chuyên môn, bồi dưỡng và những công việc theo phân công của nhà trường.
>
> Việc phân công giáo viên phải căn cứ vào số lượng giáo viên được giao, số nhóm, lớp, số trẻ thực tế, thời gian tổ chức hoạt động và yêu cầu bảo đảm an toàn cho trẻ.
>
> Nhà trường tổ chức phân công giáo viên theo ca, theo nhiệm vụ hoặc hình thức phù hợp; bố trí giáo viên trực đầu giờ, cuối giờ và buổi trưa trên nguyên tắc công khai, công bằng, có luân phiên khi cần thiết.
>
> Không bố trí mặc nhiên một giáo viên làm việc liên tục trong toàn bộ thời gian 10 giờ trẻ có mặt tại trường. Việc sắp xếp ca làm việc phải bảo đảm đúng chế độ làm việc, nghỉ ngơi và nhiệm vụ chuyên môn theo quy định.
>
> **3. Phân công giáo viên trông trẻ buổi trưa**
>
> Căn cứ lịch sinh hoạt của nhà trường, khung thời gian ngủ trưa của trẻ tại các nhóm, lớp bán trú làm cơ sở xây dựng phương án phân công trông trẻ buổi trưa như sau:
>
> | Nhóm, lớp | Khung thời gian ngủ trưa | Thời lượng |
> |---|---|---|
> | Nhóm trẻ 25–36 tháng | 11h00–13h30 | 150 phút |
> | Lớp mẫu giáo bán trú | 11h30–14h00 | 150 phút |
> | Lớp mẫu giáo không bán trú | Không tổ chức trông trẻ buổi trưa | Không áp dụng |
>
> Việc phân công giáo viên trông trẻ buổi trưa phải bảo đảm:
>
> - Có giáo viên được giao trách nhiệm trực tiếp quản lý, quan sát, chăm sóc và bảo đảm an toàn cho trẻ trong thời gian trông giữ.
> - Số giáo viên được phân công phù hợp với số trẻ thực tế ở lại bán trú, đặc điểm độ tuổi và điều kiện tổ chức của từng nhóm, lớp.
> - Xác định rõ họ tên giáo viên, nhóm lớp phụ trách, thời gian bắt đầu, kết thúc ca trực và trách nhiệm bàn giao.
> - Thực hiện theo dõi sĩ số trẻ bán trú, thời gian thực tế tham gia trông trẻ và những thay đổi trong phân công.
> - Có phương án thay thế khi giáo viên nghỉ hoặc phát sinh tình huống đột xuất; không để trẻ thiếu người trực tiếp chăm sóc, quản lý.
>
> Phó Hiệu trưởng phụ trách chuyên môn phối hợp với các tổ trưởng chuyên môn xây dựng bảng phân công cụ thể, trình Hiệu trưởng phê duyệt và tổ chức thực hiện.
>
> **4. Quy đổi thời gian trông trẻ buổi trưa ra giờ dạy**
>
> Thực hiện khoản 4 Điều 12 Thông tư số 11/2026/TT-BGDĐT, giáo viên mầm non tham gia trông trẻ buổi trưa được xem xét quy đổi thời gian thực hiện nhiệm vụ thành giờ dạy, mỗi buổi không quá 02 giờ dạy.
>
> Việc xác định số giờ quy đổi phải căn cứ vào:
>
> - Số lượng trẻ thực tế ở lại bán trú;
> - Thời gian giáo viên trực tiếp thực hiện nhiệm vụ trông trẻ;
> - Số lượng giáo viên được phân công trong cùng thời điểm;
> - Đặc điểm độ tuổi, yêu cầu chăm sóc và bảo đảm an toàn cho trẻ;
> - Điều kiện thực tế về tổ chức bán trú và đội ngũ giáo viên của nhà trường.
>
> Đối với các ca trông trẻ theo khung thời gian ngủ trưa 150 phút, nhà trường xem xét mức quy đổi phù hợp, tối đa 02 giờ dạy/giáo viên/buổi; không mặc nhiên áp dụng mức tối đa cho tất cả các trường hợp.
>
> Trường hợp giáo viên được phân công trông trẻ không đủ thời lượng, thay ca hoặc có sự thay đổi về số trẻ, nhà trường căn cứ thời gian và khối lượng công việc thực tế để xác định mức quy đổi theo phương án đã được tập thể giáo viên thông qua và Hiệu trưởng quyết định.
>
> Việc quy đổi phải bảo đảm không tính trùng giờ dạy, không quy đổi đối với thời gian giáo viên không trực tiếp thực hiện nhiệm vụ; đồng thời tuân thủ quy định đối với nhiệm vụ đã được nhận tiền thù lao hoặc phụ cấp.
>
> **Trình tự thực hiện:**
>
> 1. Phó Hiệu trưởng phụ trách chuyên môn thống kê số nhóm, lớp bán trú, số trẻ ở lại buổi trưa, số giáo viên và thời gian trông trẻ thực tế.
> 2. Xây dựng phương án phân công giáo viên, đề xuất mức quy đổi tương ứng với từng trường hợp.
> 3. Tổ chức cuộc họp tập thể giáo viên để thảo luận, thống nhất phương án quy đổi; lập biên bản ghi rõ ý kiến, kết quả thông qua và những nội dung được thống nhất.
> 4. Hiệu trưởng căn cứ hồ sơ thực tế và kết quả cuộc họp để ban hành Quyết định bằng văn bản về số giờ quy đổi đối với giáo viên được phân công trông trẻ buổi trưa.
> 5. Tổ chức thực hiện, theo dõi và tổng hợp số giờ quy đổi thực tế theo từng giáo viên; rà soát, điều chỉnh khi có thay đổi lớn về số trẻ, thời gian hoặc phương án phân công.
>
> **5. Xác định giờ dạy thêm và chi trả tiền lương dạy thêm giờ**
>
> Việc xác định giờ dạy thêm và chi trả tiền lương dạy thêm giờ cho giáo viên được thực hiện theo Thông tư số 21/2025/TT-BGDĐT và các quy định có liên quan.
>
> Nhà trường căn cứ vào bảng phân công giảng dạy, số giờ dạy thực tế, số giờ dạy được quy đổi hợp lệ, chế độ giảm định mức và các trường hợp được tính giờ dạy theo quy định để tổng hợp, đối chiếu với định mức giờ dạy của từng giáo viên trong năm học.
>
> Chỉ xác định và thực hiện thanh toán tiền lương dạy thêm giờ đối với số giờ vượt định mức đủ điều kiện được thanh toán theo quy định.
>
> Số giờ trông trẻ buổi trưa đã được quy đổi không đồng nghĩa với việc toàn bộ số giờ quy đổi đều được thanh toán tiền lương dạy thêm giờ. Việc thanh toán phải dựa trên kết quả tổng hợp, xác định số giờ dạy thêm được chi trả theo quy định hiện hành.
>
> Không thực hiện tính trùng chế độ đối với cùng một nhiệm vụ đã được chi trả tiền thù lao hoặc phụ cấp, trừ trường hợp pháp luật có quy định khác.
>
> Việc xác định mức tiền lương dạy thêm giờ, lập hồ sơ, thời điểm thanh toán, thanh quyết toán thực hiện theo Thông tư số 21/2025/TT-BGDĐT.
>
> **6. Nguồn kinh phí thực hiện**
>
> Kinh phí chi trả tiền lương dạy thêm giờ cho giáo viên, nếu phát sinh, được thực hiện từ nguồn tài chính hợp pháp của nhà trường theo quy định về cơ chế tự chủ tài chính đối với đơn vị sự nghiệp công lập.
>
> Bộ phận kế toán có trách nhiệm rà soát nguồn kinh phí, tham mưu lập dự toán, đối chiếu các khoản chi và thực hiện chi trả đúng đối tượng, đúng chế độ, đúng nguồn kinh phí; bảo đảm công khai, minh bạch và đầy đủ chứng từ theo quy định.
>
> Việc quản lý các khoản thu, chi dịch vụ bán trú thực hiện theo Quyết định số 105/2026/QĐ-UBND và các quy định có liên quan; không tự ý gộp hoặc chi trùng chế độ giữa các nguồn kinh phí.
>
> ## III. TỔ CHỨC THỰC HIỆN
>
> **1. Hiệu trưởng**
>
> Chịu trách nhiệm chỉ đạo chung việc triển khai thực hiện Kế hoạch; bảo đảm đúng quy định của ngành và phù hợp với tình hình thực tế của nhà trường.
>
> Chỉ đạo rà soát, phê duyệt lịch sinh hoạt, phương án phân công giờ làm việc, ca trông trẻ buổi trưa và hồ sơ theo dõi giáo viên.
>
> Tổ chức cuộc họp tập thể giáo viên để thông qua phương án quy đổi; ban hành Quyết định bằng văn bản về số giờ quy đổi đối với giáo viên được phân công.
>
> Kiểm tra, giám sát việc thực hiện, xem xét và quyết định các vấn đề phát sinh theo thẩm quyền.
>
> **2. Phó Hiệu trưởng phụ trách chuyên môn**
>
> Chủ trì rà soát, hoàn thiện lịch sinh hoạt hằng ngày của các nhóm, lớp; bảo đảm phù hợp với Chương trình Giáo dục mầm non.
>
> Tham mưu bố trí thời gian làm việc, định mức giờ dạy và phân công giáo viên phụ trách các hoạt động trong ngày.
>
> Phối hợp với tổ trưởng chuyên môn xây dựng phương án trông trẻ buổi trưa, theo dõi sĩ số bán trú và tổng hợp thời gian thực hiện nhiệm vụ của giáo viên.
>
> Định kỳ kiểm tra, đối chiếu bảng phân công với tình hình thực tế; tham mưu điều chỉnh kịp thời khi cần thiết.
>
> **3. Tổ trưởng chuyên môn**
>
> Triển khai nội dung Kế hoạch đến giáo viên trong tổ.
>
> Phối hợp xây dựng phương án phân công, theo dõi việc thực hiện lịch sinh hoạt và thời gian trông trẻ buổi trưa.
>
> Tổng hợp bảng theo dõi của các nhóm, lớp, kiểm tra tính chính xác trước khi báo cáo Phó Hiệu trưởng phụ trách chuyên môn.
>
> **4. Giáo viên**
>
> Thực hiện nghiêm túc thời gian làm việc, lịch sinh hoạt của trẻ và các nhiệm vụ được phân công.
>
> Chủ động phối hợp với giáo viên cùng lớp để bảo đảm các hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ được tổ chức liên tục, an toàn và hiệu quả.
>
> Ghi chép chính xác thời gian trông trẻ buổi trưa, số trẻ thực tế và những thay đổi trong quá trình thực hiện; chịu trách nhiệm về tính trung thực của số liệu.
>
> Tham gia góp ý, thảo luận và thực hiện phương án quy đổi đã được thông qua, phê duyệt.
>
> **5. Bộ phận kế toán**
>
> Phối hợp với Phó Hiệu trưởng phụ trách chuyên môn kiểm tra bảng tổng hợp giờ dạy, giờ quy đổi và định mức của từng giáo viên.
>
> Tham mưu xác định số giờ dạy thêm đủ điều kiện thanh toán, dự toán kinh phí và thực hiện các thủ tục tài chính theo quy định.
>
> Lưu trữ đầy đủ bảng tổng hợp, quyết định, chứng từ và hồ sơ liên quan để phục vụ kiểm tra, đối chiếu, quyết toán.
>
> ## IV. CHẾ ĐỘ KIỂM TRA, THEO DÕI VÀ BÁO CÁO
>
> Các nhóm, lớp thực hiện theo dõi hằng ngày về số trẻ bán trú, thời gian trông trẻ buổi trưa và giáo viên trực tiếp thực hiện nhiệm vụ.
>
> Tổ trưởng chuyên môn kiểm tra, tổng hợp theo tháng; Phó Hiệu trưởng phụ trách chuyên môn đối chiếu với bảng phân công và báo cáo Hiệu trưởng.
>
> Bộ phận kế toán phối hợp tổng hợp số giờ dạy được quy đổi, xác định số giờ dạy thêm đủ điều kiện chi trả và thực hiện chế độ theo quy định.
>
> Hiệu trưởng tổ chức kiểm tra việc thực hiện, kịp thời chấn chỉnh các sai sót và báo cáo cơ quan có thẩm quyền đối với những khó khăn, vướng mắc vượt thẩm quyền giải quyết của nhà trường.
>
> ## V. ĐIỀU KHOẢN THỰC HIỆN
>
> Kế hoạch được triển khai thực hiện từ ngày ký ban hành và áp dụng trong năm học 2026–2027.
>
> Các bộ phận, tổ chuyên môn và giáo viên có trách nhiệm thực hiện nghiêm túc nội dung Kế hoạch. Trường hợp có thay đổi về quy định của cấp có thẩm quyền hoặc điều kiện tổ chức thực tế, nhà trường xem xét điều chỉnh, bổ sung cho phù hợp.
>
> Trên đây là Kế hoạch triển khai thực hiện chế độ làm việc, quy đổi thời gian trông trẻ buổi trưa ra giờ dạy và chi trả tiền lương dạy thêm giờ cho giáo viên của Trường Mầm non An Bình năm học 2026–2027./.
>
> **Nơi nhận:**
>
> - UBND phường An Bình (báo cáo);
> - Phòng Văn hóa - Xã hội (để biết);
> - Ban giám hiệu;
> - Các tổ chuyên môn, bộ phận liên quan;
> - Lưu: VT, CM.
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên và đóng dấu)*

## 📋 Văn bản 2. Dự thảo Quyết định quy đổi giờ trông trẻ buổi trưa

**Đây là văn bản đặc biệt quan trọng**, vì khoản 4 Điều 12 Thông tư 11/2026/TT-BGDĐT quy định hiệu trưởng phải quyết định bằng văn bản mức quy đổi, căn cứ số trẻ, thời gian trông trẻ và kết quả thông qua cuộc họp tập thể giáo viên. [Hướng dẫn cách quy đổi hoạt động chuyên môn ra giờ dạy](<https://xaydungchinhsach.chinhphu.vn/huong-dan-cach-quy-doi-hoat-dong-chuyen-mon-ra-gio-day-119260305114921557.htm>); [Bộ Giáo Dục và Đào Tạo](<https://vbpl.moj.gov.vn/bogiaoducdaotao/Pages/vbpq-print.aspx?ItemID=187963>)

Tôi đã chuẩn bị nội dung quyết định. Những thông tin chưa có trong hồ sơ đính kèm được để trống, tránh tự xác định mức quy đổi khi chưa biết sĩ số và kết quả họp.

> **writing · document**
>
> **ỦY BAN NHÂN DÂN PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập - Tự do - Hạnh phúc**
>
> Số: …/QĐ-MNAB
>
> *An Bình, ngày … tháng … năm 2026*
>
> # QUYẾT ĐỊNH
> **Về việc quy đổi thời gian trông trẻ buổi trưa ra giờ dạy đối với giáo viên Trường Mầm non An Bình năm học 2026–2027**
>
> **HIỆU TRƯỞNG TRƯỜNG MẦM NON AN BÌNH**
>
> Căn cứ Thông tư số 11/2026/TT-BGDĐT ngày 04 tháng 3 năm 2026 của Bộ trưởng Bộ Giáo dục và Đào tạo quy định chế độ làm việc đối với giáo viên mầm non;
>
> Căn cứ Thông tư số 21/2025/TT-BGDĐT ngày 23 tháng 9 năm 2025 của Bộ trưởng Bộ Giáo dục và Đào tạo quy định chế độ trả tiền lương dạy thêm giờ đối với nhà giáo trong các cơ sở giáo dục công lập;
>
> Căn cứ Công văn số 4172/SGDĐT-GDMN ngày 21 tháng 10 năm 2026 của Sở Giáo dục và Đào tạo Đồng Tháp;
>
> Căn cứ Công văn số 6347/VP-VX ngày 23 tháng 10 năm 2026 của Văn phòng HĐND và UBND phường An Bình;
>
> Căn cứ Kế hoạch số …/KH-MNAB ngày … tháng … năm 2026 của Trường Mầm non An Bình;
>
> Căn cứ Biên bản cuộc họp tập thể giáo viên ngày … tháng … năm 2026 về việc thông qua phương án quy đổi thời gian trông trẻ buổi trưa ra giờ dạy;
>
> Xét tình hình thực tế về số trẻ bán trú, thời gian trông trẻ và phương án phân công giáo viên của nhà trường;
>
> **QUYẾT ĐỊNH:**
>
> **Điều 1.** Phê duyệt số giờ quy đổi đối với giáo viên được phân công thực hiện nhiệm vụ trông trẻ buổi trưa tại Trường Mầm non An Bình năm học 2026–2027 theo Phụ lục kèm theo Quyết định này.
>
> Việc quy đổi thực hiện theo khoản 4 Điều 12 Thông tư số 11/2026/TT-BGDĐT, bảo đảm mỗi giáo viên được phân công trông trẻ buổi trưa được tính không quá 02 giờ dạy/buổi.
>
> Số giờ quy đổi cụ thể được xác định phù hợp với số lượng trẻ thực tế ở lại bán trú, thời gian trông trẻ và nhiệm vụ của giáo viên theo phương án đã được tập thể giáo viên thông qua.
>
> **Điều 2.** Giáo viên được phân công có trách nhiệm thực hiện đầy đủ nhiệm vụ trông trẻ, bảo đảm an toàn cho trẻ; theo dõi thời gian trực, số trẻ thực tế và xác nhận kết quả thực hiện nhiệm vụ theo quy định của nhà trường.
>
> Phó Hiệu trưởng phụ trách chuyên môn và các tổ trưởng chuyên môn chịu trách nhiệm kiểm tra, tổng hợp, xác nhận số giờ quy đổi theo từng giáo viên.
>
> **Điều 3.** Số giờ dạy được quy đổi theo Quyết định này là căn cứ để tổng hợp giờ dạy của giáo viên trong năm học.
>
> Việc xác định số giờ dạy thêm và chi trả tiền lương dạy thêm giờ, nếu có, phải thực hiện theo Thông tư số 21/2025/TT-BGDĐT và các quy định có liên quan.
>
> Không thanh toán trùng chế độ đối với cùng một nhiệm vụ đã được nhận tiền thù lao hoặc phụ cấp, trừ trường hợp pháp luật có quy định khác.
>
> **Điều 4.** Quyết định này có hiệu lực kể từ ngày ký.
>
> Phó Hiệu trưởng, các tổ trưởng chuyên môn, bộ phận kế toán và giáo viên có liên quan chịu trách nhiệm thi hành Quyết định này./.
>
> **Nơi nhận:**
>
> - Như Điều 4;
> - Ban giám hiệu;
> - Lưu: VT, CM.
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên và đóng dấu)*
>
> ---
>
> ## PHỤ LỤC
> **BẢNG XÁC ĐỊNH SỐ GIỜ QUY ĐỔI TRÔNG TRẺ BUỔI TRƯA NĂM HỌC 2026–2027**
>
> *(Kèm theo Quyết định số …/QĐ-MNAB ngày … tháng … năm 2026 của Hiệu trưởng Trường Mầm non An Bình)*
>
> | STT | Nhóm, lớp | Số trẻ bán trú làm căn cứ | Giáo viên được phân công | Thời gian trông trẻ | Giờ quy đổi/giáo viên/buổi |
> |---|---|---|---|---|---|
> | 1 | Nhóm 25–36 tháng | […] | […] | 11h00–13h30 | […] |
> | 2 | Lớp mẫu giáo bán trú […] | […] | […] | 11h30–14h00 | […] |
> | 3 | Lớp mẫu giáo bán trú […] | […] | […] | 11h30–14h00 | […] |
>
> *Ghi chú:*
>
> - Mỗi giáo viên được phân công và mỗi nhóm, lớp phải được thể hiện rõ; bổ sung số dòng theo thực tế.
> - Mức quy đổi tại cột cuối không được vượt quá 02 giờ dạy/giáo viên/buổi.
> - Số liệu và mức quy đổi phải được hoàn thiện trên cơ sở phương án đã được tập thể giáo viên thông qua và Hiệu trưởng quyết định.
> - Trường hợp thay đổi thời gian, số trẻ hoặc người thực hiện nhiệm vụ, nhà trường theo dõi và xử lý theo phương án đã được phê duyệt; điều chỉnh quyết định khi cần thiết.

## 🔍 Những nội dung cần hoàn thiện trước khi ký ban hành

Để bảo đảm hồ sơ được thực hiện đúng quy định, tôi đề xuất thực hiện theo trình tự sau:

1. **Rà soát, điều chỉnh lịch sinh hoạt**
   
   Thống nhất lịch mẫu giáo không bán trú và kiểm tra thời lượng các hoạt động trong lịch mẫu giáo bán trú. Riêng lịch mẫu giáo bán trú hiện có thời gian đón trẻ 90 phút, ăn trưa 70 phút, hoạt động chiều 80 phút và chuẩn bị trả trẻ 70 phút, khác một số khoảng thời lượng Sở nêu tại Công văn 4172. Nhà trường cần xem xét điều chỉnh hoặc xác định cơ sở sắp xếp phù hợp từng độ tuổi.
2. **Thống kê thực tế và xây dựng phương án quy đổi**
   
   Xác định số lớp bán trú, sĩ số trẻ ở lại buổi trưa, giáo viên được giao trực từng ca và mức giờ quy đổi dự kiến. Không sử dụng mức 02 giờ/buổi như một hệ số tự động cho mọi giáo viên.
3. **Tổ chức cuộc họp tập thể giáo viên**
   
   Lập biên bản ghi rõ thành phần tham dự, số liệu làm căn cứ, phương án mức quy đổi theo từng trường hợp, ý kiến thảo luận và kết quả thông qua. Sau đó mới hoàn thiện số giờ trong Quyết định của Hiệu trưởng.
4. **Phân công, theo dõi và tính chế độ**
   
   Ban hành bảng phân công giáo viên, xác nhận giờ trông trẻ thực tế hằng ngày, tổng hợp theo tháng và đối chiếu định mức theo năm học. Chỉ thanh toán số giờ dạy thêm đủ điều kiện, tránh tính trùng khoản hỗ trợ, thù lao đã chi.

## ⚠️ Lưu ý về chi trả

Thông tư 21/2025/TT-BGDĐT xác định giờ dạy thêm trên cơ sở tổng số giờ dạy được tính trong năm học so với định mức; tiền lương một giờ dạy thêm được tính bằng 150% tiền lương một giờ dạy theo công thức quy định. Vì vậy, nhà trường không nên tính trả ngay tiền làm thêm chỉ bằng cách nhân số buổi trực trưa với mức giờ quy đổi. [Thông tư 21/2025/TT\-BGDĐT quy định chế độ trả tiền lương dạy thêm giờ với nhà giáo trong các cơ sở giáo dục công lập](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-21-2025-tt-bgddt-quy-dinh-che-do-tra-tien-luong-day-them-gio-voi-nha-giao-trong-cac-co-so-giao-duc-cong-lap-119250923202359853.htm>); [Thông tư 21/2025/TT\-BGDĐT quy định chế độ trả tiền lương dạy thêm giờ với nhà giáo trong các cơ sở giáo dục công lập](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-21-2025-tt-bgddt-quy-dinh-che-do-tra-tien-luong-day-them-gio-voi-nha-giao-trong-cac-co-so-giao-duc-cong-lap-119250923202359853.htm>); [Thông tư 21/2025/TT\-BGDĐT quy định chế độ trả tiền lương dạy thêm giờ với nhà giáo trong các cơ sở giáo dục công lập](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-21-2025-tt-bgddt-quy-dinh-che-do-tra-tien-luong-day-them-gio-voi-nha-giao-trong-cac-co-so-giao-duc-cong-lap-119250923202359853.htm>)

Đồng thời, cần phân định rõ việc sử dụng nguồn tài chính của đơn vị và các khoản chi phục vụ bán trú theo Quyết định 105/2026/QĐ-UBND của tỉnh Đồng Tháp. [Chi tiết văn bản \- Cổng thông tin điện tử tỉnh Đồng Tháp](<https://dongthap.gov.vn/vi/web/cong-thong-tin-dtp/chi-tiet?id=11166701>); [Quyết định 105/2026/QĐ\-UBND khoản thu chi đối với các dịch vụ phục vụ hoạt động giáo dục Đồng Tháp](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Quyet-dinh-105-2026-QD-UBND-khoan-thu-chi-doi-voi-cac-dich-vu-phuc-vu-hoat-dong-giao-duc-Dong-Thap-724669.aspx?tab=3>)

## ✅ Kết luận

Với 3 tài liệu đã cung cấp, **hai dự thảo trên có thể sử dụng làm nền tảng hồ sơ triển khai của Trường Mầm non An Bình năm học 2026–2027**.

Phần còn phải hoàn thiện từ số liệu thực tế là **danh sách giáo viên, sĩ số trẻ bán trú, mức giờ quy đổi cụ thể và biên bản họp tập thể giáo viên**. Đây là những dữ liệu chưa có trong tài liệu đính kèm nên không nên tự điền hoặc ban hành quyết định khi chưa được xác minh.

Sau khi bổ sung các thông tin này và điều chỉnh lịch sinh hoạt cho thống nhất, nhà trường sẽ có căn cứ rõ ràng để tổ chức thực hiện, bảo vệ quyền lợi giáo viên và phục vụ công tác kiểm tra của cơ quan quản lý.

---

ASSISTANT

Tôi đã kiểm tra thêm quy định về giờ dạy thêm và nguồn chi. Có một điểm cần tách rõ trong văn bản: **giờ trông trẻ được quy đổi không đồng nghĩa với giờ được trả tiền dạy thêm**; việc thanh toán phải đối chiếu tổng định mức và tránh tính trùng khoản thù lao đã chi. Tôi sẽ thể hiện riêng phần này trong kế hoạch và dự thảo quyết định.

---

USER

Phần nội dung thực hiện của kế hoạch bạn làm rất tốt tuy nhiên khá khó hiểu. Bạn giúp mình trình bày để người xem có thể dễ hiểu hơn nhé

---

ASSISTANT

Tôi sẽ trình bày lại **Mục II. NỘI DUNG THỰC HIỆN** theo hướng ngắn gọn, dễ đọc, dễ hiểu nhưng vẫn giữ tính chặt chẽ của văn bản hành chính.

Điểm quan trọng là khi đọc, giáo viên và các bộ phận liên quan phải hiểu ngay: **Trẻ sinh hoạt vào thời gian nào? Giáo viên làm việc bao nhiêu giờ? Ai được phân công trông trẻ buổi trưa? Giờ trông trẻ được quy đổi như thế nào? Khi nào được thanh toán tiền dạy thêm giờ?**

Dưới đây là nội dung đề xuất thay thế trực tiếp Mục II trong kế hoạch.

> **writing · document**
>
> ## II. NỘI DUNG THỰC HIỆN
>
> ### 1. Thực hiện chế độ sinh hoạt trong ngày của trẻ
>
> Nhà trường tổ chức các hoạt động chăm sóc, nuôi dưỡng và giáo dục trẻ theo Chương trình Giáo dục mầm non và lịch sinh hoạt của từng độ tuổi. Thời gian các hoạt động được bố trí phù hợp với điều kiện thực tế, bảo đảm trẻ được ăn, ngủ, vui chơi, học tập và nghỉ ngơi hợp lý.
>
> Căn cứ lịch sinh hoạt năm học 2026–2027, nhà trường tổ chức thực hiện như sau:
>
> | Đối tượng | Thời gian trẻ ở trường | Thời gian ngủ trưa |
> |---|---|---|
> | Nhóm trẻ 25–36 tháng | 7h00–17h00 | 11h00–13h30 |
> | Lớp mẫu giáo bán trú | 7h00–17h00 | 11h30–14h00 |
> | Lớp mẫu giáo học 2 buổi/ngày không bán trú | Theo lịch học sáng, chiều được phê duyệt | Không tổ chức ngủ trưa tại trường |
>
> Đối với các nhóm, lớp bán trú, nhà trường tổ chức đầy đủ các hoạt động theo lịch sinh hoạt đã xây dựng. Trong thời gian trẻ ngủ trưa, giáo viên được phân công có trách nhiệm trực tiếp theo dõi, chăm sóc và bảo đảm an toàn cho trẻ.
>
> Đối với lớp mẫu giáo học 2 buổi/ngày không bán trú, trẻ về gia đình ăn trưa, nghỉ trưa và trở lại trường học buổi chiều. Nhà trường không phân công giáo viên trông trẻ buổi trưa đối với các lớp này.
>
> Phó Hiệu trưởng phụ trách chuyên môn có trách nhiệm rà soát, hoàn thiện lịch sinh hoạt của các nhóm, lớp và trình Hiệu trưởng phê duyệt trước khi tổ chức thực hiện.
>
> ### 2. Thực hiện thời gian làm việc của giáo viên
>
> Thực hiện Thông tư số 11/2026/TT-BGDĐT và hướng dẫn tại Công văn số 4172/SGDĐT-GDMN, nhà trường tổ chức thời gian làm việc của giáo viên như sau:
>
> - **Thời gian làm việc:** 40 giờ/tuần, tương ứng 8 giờ/ngày.
> - **Định mức giờ dạy:** 5 giờ 30 phút/ngày đối với giáo viên dạy các nhóm trẻ, lớp mẫu giáo học 2 buổi/ngày.
> - **Thời gian còn lại:** Giáo viên thực hiện các nhiệm vụ chuyên môn khác như chuẩn bị hoạt động giáo dục, xây dựng kế hoạch, làm hồ sơ, sinh hoạt chuyên môn, bồi dưỡng chuyên môn và các công việc được phân công.
>
> Thời gian 5 giờ 30 phút dạy học nằm trong tổng thời gian làm việc 8 giờ/ngày của giáo viên, không phải là thời gian cộng thêm ngoài 8 giờ.
>
> Căn cứ số lượng giáo viên, số nhóm, lớp và thời gian sinh hoạt của trẻ, nhà trường bố trí giáo viên thực hiện nhiệm vụ theo ca hoặc phân công phù hợp với điều kiện thực tế.
>
> Việc phân công phải bảo đảm các yêu cầu sau:
>
> - Có giáo viên phụ trách trẻ trong suốt thời gian trẻ có mặt tại trường.
> - Bảo đảm thời gian làm việc, định mức giờ dạy và chế độ nghỉ ngơi của giáo viên theo quy định.
> - Phân công rõ người thực hiện các nhiệm vụ đón trẻ, chăm sóc, giáo dục, trông trẻ buổi trưa và trả trẻ.
> - Bố trí công việc hợp lý, công bằng giữa các giáo viên, không để một giáo viên phải làm việc liên tục 10 giờ/ngày chỉ vì trẻ có mặt tại trường trong 10 giờ.
>
> Phó Hiệu trưởng phụ trách chuyên môn tham mưu Hiệu trưởng xây dựng bảng phân công giáo viên cụ thể, phù hợp với tình hình thực tế của nhà trường.
>
> ### 3. Phân công giáo viên trông trẻ buổi trưa
>
> Căn cứ lịch sinh hoạt của các nhóm, lớp bán trú, nhà trường bố trí giáo viên trông trẻ buổi trưa trong các khoảng thời gian sau:
>
> - **Nhóm trẻ 25–36 tháng:** Từ 11 giờ 00 phút đến 13 giờ 30 phút.
> - **Lớp mẫu giáo bán trú:** Từ 11 giờ 30 phút đến 14 giờ 00 phút.
>
> Thời gian trên là khung giờ ngủ trưa của trẻ, làm cơ sở để nhà trường xây dựng lịch phân công. Thời gian thực tế của từng giáo viên được xác định theo ca trực và nhiệm vụ được giao.
>
> Việc phân công giáo viên trông trẻ buổi trưa căn cứ vào số trẻ ở lại bán trú, độ tuổi của trẻ, số giáo viên hiện có và điều kiện thực tế của từng nhóm, lớp.
>
> Giáo viên được phân công trông trẻ buổi trưa có trách nhiệm:
>
> - Có mặt và thực hiện nhiệm vụ đúng thời gian được phân công.
> - Theo dõi giấc ngủ, tình trạng sức khỏe và bảo đảm an toàn cho trẻ.
> - Xử lý kịp thời hoặc báo cáo khi có tình huống bất thường xảy ra.
> - Ghi nhận thời gian thực hiện nhiệm vụ, số trẻ thực tế và bàn giao đầy đủ khi kết thúc ca trực.
>
> Nhà trường lập bảng phân công trông trẻ buổi trưa cụ thể, công khai đến giáo viên và điều chỉnh khi có thay đổi về sĩ số hoặc nhân sự.
>
> ### 4. Quy đổi thời gian trông trẻ buổi trưa ra giờ dạy
>
> Theo khoản 4 Điều 12 Thông tư số 11/2026/TT-BGDĐT, giáo viên được phân công trông trẻ buổi trưa được quy đổi thời gian thực hiện nhiệm vụ thành giờ dạy, **mỗi buổi không quá 02 giờ dạy**.
>
> Để thực hiện đúng quy định, nhà trường xác định mức quy đổi dựa trên ba yếu tố chính:
>
> 1. **Số lượng trẻ bán trú:** Số trẻ thực tế ở lại trường trong thời gian buổi trưa.
> 2. **Thời gian trông trẻ:** Thời gian giáo viên trực tiếp thực hiện nhiệm vụ theo phân công.
> 3. **Điều kiện tổ chức:** Số giáo viên được phân công, đặc điểm độ tuổi và yêu cầu chăm sóc trẻ của từng nhóm, lớp.
>
> Nhà trường không mặc nhiên quy đổi 02 giờ dạy cho tất cả giáo viên tham gia trông trẻ buổi trưa. Mức quy đổi cụ thể phải phù hợp với điều kiện thực tế và không vượt quá mức quy định.
>
> **Trình tự thực hiện quy đổi như sau:**
>
> **Bước 1. Xây dựng phương án quy đổi**
>
> Phó Hiệu trưởng phụ trách chuyên môn thống kê số trẻ bán trú, thời gian trông trẻ và số giáo viên được phân công; trên cơ sở đó tham mưu đề xuất mức quy đổi phù hợp.
>
> **Bước 2. Tổ chức họp tập thể giáo viên**
>
> Nhà trường tổ chức họp tập thể giáo viên để thảo luận, thông qua phương án quy đổi thời gian trông trẻ buổi trưa ra giờ dạy. Nội dung và kết quả cuộc họp phải được ghi thành biên bản.
>
> **Bước 3. Hiệu trưởng ban hành Quyết định**
>
> Căn cứ điều kiện thực tế và kết quả cuộc họp tập thể giáo viên, Hiệu trưởng ban hành Quyết định bằng văn bản xác định số giờ quy đổi đối với giáo viên được phân công trông trẻ buổi trưa.
>
> **Bước 4. Theo dõi và tổng hợp**
>
> Giáo viên thực hiện nhiệm vụ theo bảng phân công. Nhà trường theo dõi thời gian trông trẻ thực tế, tổng hợp số giờ được quy đổi và điều chỉnh khi cần thiết.
>
> Số giờ quy đổi được xác định theo Quyết định của Hiệu trưởng và kết quả thực hiện nhiệm vụ thực tế của từng giáo viên.
>
> ### 5. Xác định giờ dạy thêm và chi trả tiền lương dạy thêm giờ
>
> Việc chi trả tiền lương dạy thêm giờ cho giáo viên được thực hiện theo Thông tư số 21/2025/TT-BGDĐT và hướng dẫn của Sở Giáo dục và Đào tạo.
>
> Nhà trường thực hiện theo nguyên tắc:
>
> - Tổng hợp số giờ dạy thực tế và số giờ dạy được quy đổi hợp lệ của từng giáo viên.
> - Đối chiếu với định mức giờ dạy và các quy định có liên quan để xác định số giờ dạy thêm trong năm học.
> - Chỉ thực hiện chi trả đối với số giờ dạy thêm đủ điều kiện thanh toán theo quy định.
> - Bảo đảm công khai, chính xác và không thanh toán trùng chế độ đối với cùng một nhiệm vụ.
>
> **Cần phân biệt rõ:** Giờ trông trẻ buổi trưa được quy đổi thành giờ dạy không có nghĩa tất cả số giờ quy đổi đều được thanh toán tiền lương dạy thêm giờ. Việc thanh toán chỉ thực hiện khi xác định có số giờ dạy thêm đủ điều kiện theo quy định.
>
> Phó Hiệu trưởng phụ trách chuyên môn chịu trách nhiệm kiểm tra, xác nhận số giờ dạy và giờ quy đổi; bộ phận kế toán phối hợp tổng hợp, tham mưu tính toán và thực hiện thanh toán đúng quy định.
>
> ### 6. Nguồn kinh phí và quản lý hồ sơ
>
> **a) Nguồn kinh phí**
>
> Kinh phí chi trả tiền lương dạy thêm giờ cho giáo viên, nếu phát sinh, được thực hiện từ nguồn tài chính hợp pháp của nhà trường theo quy định về cơ chế tự chủ tài chính của đơn vị sự nghiệp công lập.
>
> Bộ phận kế toán có trách nhiệm tham mưu bố trí nguồn kinh phí, lập dự toán, thực hiện thanh toán và quyết toán theo quy định.
>
> Việc quản lý các khoản thu, chi dịch vụ bán trú phải bảo đảm phù hợp với Quyết định số 105/2026/QĐ-UBND và các quy định có liên quan.
>
> **b) Hồ sơ theo dõi**
>
> Nhà trường xây dựng và lưu trữ đầy đủ hồ sơ phục vụ việc quản lý, kiểm tra và thực hiện chế độ, gồm:
>
> - Lịch sinh hoạt của các nhóm, lớp.
> - Bảng phân công nhiệm vụ và thời gian làm việc của giáo viên.
> - Bảng phân công giáo viên trông trẻ buổi trưa.
> - Bảng theo dõi số trẻ bán trú và thời gian trông trẻ thực tế.
> - Biên bản họp tập thể giáo viên thông qua phương án quy đổi.
> - Quyết định của Hiệu trưởng về số giờ quy đổi trông trẻ buổi trưa.
> - Bảng tổng hợp giờ dạy, giờ quy đổi, giờ dạy thêm và hồ sơ thanh toán có liên quan.
>
> Hồ sơ được phân công cho các bộ phận chịu trách nhiệm lập, kiểm tra, xác nhận và lưu trữ; bảo đảm thống nhất số liệu, dễ theo dõi và thuận lợi trong quá trình kiểm tra, đối chiếu.

## 💡 Điểm cải tiến của cách trình bày này

Tôi đã điều chỉnh nội dung theo nguyên tắc **mỗi mục giải quyết một vấn đề, mỗi quy định gắn với việc nhà trường phải làm**, hạn chế diễn giải dài và lặp lại căn cứ pháp lý.

Đặc biệt, Mục 4 được trình bày theo 4 bước rõ ràng để giáo viên hiểu quy trình quy đổi; Mục 5 giải thích sự khác nhau giữa giờ được quy đổi và giờ được thanh toán tiền dạy thêm.

## ⚠️ Một lưu ý cần xử lý trước khi hoàn thiện kế hoạch

Lịch sinh hoạt lớp mẫu giáo không bán trú của trường vẫn cần thống nhất lại thời gian buổi sáng: bảng đang ghi 7h00–11h00 (240 phút), trong khi tổng thời lượng ghi 210 phút và phần quy định đón, trả trẻ ghi kết thúc trả trẻ lúc 10h30. Vì vậy, trong bản viết lại tôi chưa tự ý chọn một mốc thời gian làm chính thức.

**Đề xuất của tôi:** Sử dụng phiên bản Mục II này vì dễ triển khai đến toàn thể giáo viên, đồng thời giữ đủ các nội dung cốt lõi theo Công văn 4172 của Sở. Khi rà soát xong lịch sinh hoạt và có số liệu thực tế của các lớp bán trú, nhà trường chỉ cần bổ sung bảng phân công và mức quy đổi cụ thể, không cần viết lại toàn bộ kế hoạch.

---

USER

bạn giúp tôi hoàn chỉnh phụ lục kèm theo quyết định nhe

---

ASSISTANT

---

ASSISTANT

Tôi sẽ hoàn thiện **Phụ lục kèm theo Quyết định quy đổi thời gian trông trẻ buổi trưa ra giờ dạy** của Trường Mầm non An Bình theo hướng rõ ràng, dễ điền số liệu, thuận tiện cho giáo viên thực hiện và kế toán đối chiếu.

Phụ lục sẽ phân biệt rõ **khung giờ ngủ trưa của trẻ, thời gian giáo viên được phân công trực và số giờ dạy được quy đổi**. Đây là ba thông tin cần thể hiện riêng để tránh nhầm lẫn.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> # PHỤ LỤC
> **DANH SÁCH GIÁO VIÊN ĐƯỢC PHÂN CÔNG TRÔNG TRẺ BUỔI TRƯA VÀ MỨC QUY ĐỔI RA GIỜ DẠY NĂM HỌC 2026–2027**
>
> *(Kèm theo Quyết định số …/QĐ-MNAB ngày … tháng … năm 2026 của Hiệu trưởng Trường Mầm non An Bình)*
>
> ## I. THỜI GIAN TRÔNG TRẺ BUỔI TRƯA
>
> Căn cứ lịch sinh hoạt năm học 2026–2027 của nhà trường, khung thời gian ngủ trưa của trẻ tại các nhóm, lớp bán trú được xác định như sau:
>
> | STT | Đối tượng | Thời gian ngủ trưa | Thời lượng |
> |---|---|---|---|
> | 1 | Nhóm trẻ 25–36 tháng | 11h00–13h30 | 150 phút |
> | 2 | Lớp mẫu giáo bán trú | 11h30–14h00 | 150 phút |
>
> Đây là khung thời gian tổ chức ngủ trưa của trẻ để nhà trường làm căn cứ phân công giáo viên trông trẻ. Thời gian trực thực tế của từng giáo viên được xác định theo bảng phân công đã được Hiệu trưởng phê duyệt.
>
> Đối với các lớp mẫu giáo học 02 buổi/ngày không tổ chức bán trú, nhà trường không phân công trông trẻ buổi trưa và không thực hiện quy đổi giờ dạy đối với nhiệm vụ này.
>
> ## II. DANH SÁCH GIÁO VIÊN VÀ MỨC GIỜ QUY ĐỔI
>
> | STT | Họ và tên giáo viên | Nhóm, lớp phụ trách | Số trẻ bán trú làm căn cứ | Thời gian trực được phân công | Mức quy đổi (giờ dạy/buổi) |
> |---|---|---|---|---|---|
> | 1 | …………… | Nhóm 25–36 tháng … | … trẻ | …h…–…h… | … |
> | 2 | …………… | Nhóm 25–36 tháng … | … trẻ | …h…–…h… | … |
> | 3 | …………… | Mẫu giáo bán trú … | … trẻ | …h…–…h… | … |
> | 4 | …………… | Mẫu giáo bán trú … | … trẻ | …h…–…h… | … |
> | 5 | …………… | Mẫu giáo bán trú … | … trẻ | …h…–…h… | … |
> | 6 | …………… | Mẫu giáo bán trú … | … trẻ | …h…–…h… | … |
> | … | …………… | …………… | … | … | … |
>
> **Ghi chú:**
>
> 1. Mỗi giáo viên được phân công trông trẻ buổi trưa ghi thành một dòng riêng. Trường hợp có nhiều giáo viên cùng thực hiện nhiệm vụ tại một nhóm, lớp thì ghi rõ thời gian trực của từng người.
>
> 2. Số trẻ bán trú làm căn cứ là số trẻ được xác định tại thời điểm xây dựng phương án. Số trẻ thực tế hằng ngày được theo dõi để phục vụ kiểm tra và điều chỉnh khi cần thiết.
>
> 3. Mức quy đổi của mỗi giáo viên không quá 02 giờ dạy/buổi theo khoản 4 Điều 12 Thông tư số 11/2026/TT-BGDĐT.
>
> 4. Mức quy đổi cụ thể căn cứ vào số trẻ ở lại bán trú, thời gian giáo viên trực tiếp trông trẻ và kết quả cuộc họp tập thể giáo viên; do Hiệu trưởng quyết định bằng văn bản.
>
> ## III. NGUYÊN TẮC ÁP DỤNG
>
> **1. Đối tượng được tính giờ quy đổi**
>
> Giáo viên được Hiệu trưởng phân công và thực tế thực hiện nhiệm vụ trông trẻ buổi trưa tại các nhóm, lớp bán trú của nhà trường, đáp ứng điều kiện quy đổi theo quy định.
>
> **2. Cách xác định số giờ quy đổi**
>
> - Số giờ quy đổi của mỗi buổi thực hiện theo mức đã được Hiệu trưởng phê duyệt tại Mục II của Phụ lục này.
> - Chỉ tính số giờ quy đổi đối với những buổi giáo viên thực tế thực hiện nhiệm vụ theo phân công.
> - Giáo viên nghỉ, không tham gia trông trẻ buổi trưa thì không được tính giờ quy đổi cho buổi đó.
> - Trường hợp thay đổi người trực, thời gian trực hoặc điều kiện trông trẻ, nhà trường xem xét, điều chỉnh phương án phân công và mức quy đổi theo quy định.
>
> **3. Tổng hợp số giờ quy đổi**
>
> Số giờ dạy được quy đổi của từng giáo viên được tổng hợp trên cơ sở số buổi trông trẻ thực tế đã được xác nhận và mức quy đổi tương ứng được phê duyệt.
>
> Trường hợp mức quy đổi không thay đổi trong kỳ, việc tổng hợp thực hiện như sau:
>
> **Tổng số giờ dạy được quy đổi = Số buổi trông trẻ thực tế × Mức giờ quy đổi/buổi.**
>
> Trường hợp mức quy đổi thay đổi trong kỳ, nhà trường tổng hợp riêng từng mức trước khi cộng tổng số giờ của giáo viên.
>
> Số giờ dạy được quy đổi là căn cứ để tổng hợp giờ dạy của giáo viên theo quy định, không đồng nghĩa với số giờ được thanh toán tiền lương dạy thêm giờ.
>
> **4. Trách nhiệm thực hiện**
>
> - Giáo viên thực hiện đúng lịch phân công, theo dõi và xác nhận thời gian trông trẻ thực tế.
> - Tổ trưởng chuyên môn kiểm tra bảng theo dõi của giáo viên trong tổ.
> - Phó Hiệu trưởng phụ trách chuyên môn kiểm tra, tổng hợp và tham mưu Hiệu trưởng xác nhận số giờ quy đổi.
> - Bộ phận kế toán căn cứ hồ sơ được duyệt để phối hợp xác định số giờ dạy thêm đủ điều kiện thanh toán theo quy định.
>
> Phụ lục này là bộ phận không tách rời của Quyết định số …/QĐ-MNAB ngày … tháng … năm 2026 của Hiệu trưởng Trường Mầm non An Bình.

## 💡 Hướng dẫn hoàn thiện trước khi ban hành

Để phụ lục có thể áp dụng ngay, nhà trường cần điền các thông tin còn trống trong bảng tại Mục II. Tôi đề xuất sử dụng **một dòng cho mỗi giáo viên** thay vì chỉ ghi chung theo lớp, vì mức quy đổi phải gắn với người được phân công và thời gian thực hiện nhiệm vụ.

Có hai điểm cần lưu ý:

- **Không mặc nhiên quy đổi 150 phút ngủ trưa thành 02 giờ dạy.** Mức quy đổi tối đa 02 giờ/buổi phải được xác định phù hợp với số trẻ, thời gian trông trẻ và được tập thể giáo viên thông qua trước khi Hiệu trưởng quyết định. [Source unavailable: turn928205search1]; [Source unavailable: turn928205search2]
- **Không quy đổi giờ dạy nếu giáo viên đã nhận tiền thù lao hoặc phụ cấp cho chính nhiệm vụ trông trẻ buổi trưa đó.** Nội dung này đã được Bộ Giáo dục và Đào tạo giải đáp ngày 12/11/2026. [Source unavailable: turn928205search7]

## 📋 Thông tin cần bổ sung để chốt mức quy đổi

Có thể cung cấp số liệu tổng quát trước; danh sách họ tên giáo viên bổ sung sau.

Số nhóm trẻ bán trú

[Phần giữ chỗ của đầu vào: Ví dụ: 2] (Giá trị hiện tại không khả dụng.)

Số lớp mẫu giáo bán trú

[Phần giữ chỗ của đầu vào: Ví dụ: 6] (Giá trị hiện tại không khả dụng.)

Số trẻ bán trú bình quân/lớp

[Phần giữ chỗ của đầu vào: Ví dụ: 30] (Giá trị hiện tại không khả dụng.)

Số giáo viên trực trưa/lớp

[Phần giữ chỗ của đầu vào: Ví dụ: 2] (Giá trị hiện tại không khả dụng.)

Giáo viên đã được chi thù lao hoặc phụ cấp trông trẻ buổi trưa chưa?

Đã chi

Chưa chi

Cần kiểm tra lại

[Hoàn thiện phương án quy đổi theo số liệu]

Với các số liệu này, tôi có thể giúp nhà trường xây dựng phương án mức quy đổi cụ thể để đưa ra cuộc họp tập thể giáo viên, sau đó hoàn thiện phụ lục làm căn cứ ban hành Quyết định của Hiệu trưởng.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

