USER

tôi đang cần tạo 1 danh sách để đảng viên ký tên cam đoan đã cập nhật đúng đầy đủ hồ sơ dữ liệu để làm căn cứ đối chiếu sao này. bạn giúp tôi nhe

---

ASSISTANT

Tôi sẽ chỉnh mẫu theo hướng đảng viên xác nhận thông tin đã cập nhật và chịu trách nhiệm về tính chính xác, đầy đủ; bổ sung ngày ký để thuận tiện đối chiếu về sau.

---

ASSISTANT

Mẫu cô gửi mới xác nhận việc **thống nhất thực hiện**, chưa xác nhận **đã cập nhật đầy đủ, chính xác**. Tôi vận dụng hướng dẫn của Cố vấn công tác Đảng để chỉnh nội dung cam đoan như sau:

> **writing · standard**
>
> **CHI BỘ: ………………………………**
>
> **DANH SÁCH ĐẢNG VIÊN KÝ CAM ĐOAN**  
> **Về tính chính xác, đầy đủ của thông tin hồ sơ đã cập nhật trên Sổ tay điện tử đảng viên**
>
> Chúng tôi, các đảng viên có tên dưới đây, cam đoan đã trực tiếp rà soát, đối chiếu thông tin cá nhân trên Sổ tay điện tử đảng viên với hồ sơ, giấy tờ có liên quan; đã cập nhật đầy đủ các nội dung theo yêu cầu, bảo đảm thông tin chính xác tại thời điểm ký xác nhận.
>
> Mỗi đảng viên chịu trách nhiệm trước Chi bộ về nội dung thông tin đã xác nhận; khi phát hiện sai sót hoặc có thay đổi, kịp thời báo cáo Chi bộ để được hướng dẫn điều chỉnh, bổ sung.
>
> Danh sách này được lưu tại Chi bộ làm căn cứ theo dõi, kiểm tra và đối chiếu khi cần thiết.
>
> | STT | Họ và tên | Ngày ký xác nhận | Chữ ký | Ghi chú |
> |:---:|---|:---:|:---:|---|
> | 1 | Nguyễn Huỳnh Kim Khánh | | | |
> | 2 | Trần Thị Huỳnh Như | | | |
> | 3 | Nguyễn Phương Thủy | | | |
> | 4 | Trương Thị Kim Trang | | | |
> | 5 | Nguyễn Thị Việt Trinh | | | |
>
> *Ghi chú: Trường hợp còn nội dung chưa cập nhật hoặc đang chờ điều chỉnh, ghi rõ tại cột “Ghi chú”; chỉ ký cam đoan đầy đủ sau khi đã hoàn tất và kiểm tra lại.*

Để đối chiếu về sau rõ ràng, cô nên **lưu kèm bản xuất dữ liệu hoặc bản in thông tin tại thời điểm đảng viên ký xác nhận**, vì dữ liệu trên hệ thống có thể tiếp tục được cập nhật.

---

USER

bổ sung thông tin thời điểm duyệt hồ sơ trên app

---

ASSISTANT

Cô bổ sung cột **“Thời điểm hồ sơ được duyệt trên ứng dụng”** và điều chỉnh nội dung xác nhận như sau:

> **writing · standard**
>
> **DANH SÁCH ĐẢNG VIÊN KÝ CAM ĐOAN**  
> **Về tính chính xác, đầy đủ của thông tin hồ sơ trên Sổ tay điện tử đảng viên**
>
> Chúng tôi, các đảng viên có tên dưới đây, cam đoan đã rà soát, đối chiếu thông tin cá nhân trên Sổ tay điện tử đảng viên với hồ sơ, giấy tờ có liên quan; xác nhận thông tin hồ sơ tại thời điểm được duyệt trên ứng dụng là chính xác, đầy đủ theo yêu cầu.
>
> Mỗi đảng viên chịu trách nhiệm trước Chi bộ về thông tin đã xác nhận; khi phát hiện sai sót hoặc có thay đổi, kịp thời báo cáo Chi bộ để được hướng dẫn điều chỉnh, bổ sung. Danh sách này được lưu tại Chi bộ làm căn cứ theo dõi, kiểm tra và đối chiếu về sau.
>
> | STT | Họ và tên | Thời điểm hồ sơ được duyệt trên ứng dụng | Ngày ký xác nhận | Chữ ký | Ghi chú |
> |:---:|---|:---:|:---:|:---:|---|
> | 1 | Nguyễn Huỳnh Kim Khánh | | | | |
> | 2 | Trần Thị Huỳnh Như | | | | |
> | 3 | Nguyễn Phương Thủy | | | | |
> | 4 | Trương Thị Kim Trang | | | | |
> | 5 | Nguyễn Thị Việt Trinh | | | | |
>
> *Ghi chú: Ghi thời điểm duyệt theo thông tin hiển thị trên ứng dụng (ngày, tháng, năm; giờ, phút nếu có). Đảng viên kiểm tra lại thông tin hồ sơ đã được duyệt trước khi ký xác nhận.*

---

