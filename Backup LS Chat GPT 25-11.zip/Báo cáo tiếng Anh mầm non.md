USER

với vai trò hiệu trưởng trường mầm non bạn giúp tôi báo cáo nội dung sau theo yêu cầu của văn bản

---

ASSISTANT

Tôi sẽ đọc công văn và các phụ lục để xác định nội dung cần báo cáo, rồi soạn theo thực tế trường mầm non. Những số liệu nhà trường chưa cung cấp sẽ được để trống để cô bổ sung, tránh báo cáo sai thực tế. Tôi sử dụng kỹ năng soạn thảo văn bản mầm non để thực hiện nội dung này.

---

ASSISTANT

Qua đối chiếu văn bản, **Trường Mầm non An Bình cần báo cáo thực trạng tại thời điểm tháng 9/2026, dự kiến lộ trình đến năm 2030, 2035, 2040, 2045 và nhu cầu đầu tư, kinh phí theo 03 phụ lục**. Báo cáo gửi **Phòng Văn hóa – Xã hội phường An Bình** để phối hợp tham mưu UBND phường, hoàn thành **trước ngày 26/10/2026** theo Công văn số 6223/VP-VX. *[Source: so4102cuasgd-dttinhcungcapsolieuthuctrangvadukienlotrinhthuchiencacmuctieudeanchotreemmaugiaolamquenvoitienganhtaicaccosogiaoducmamnon_signed_signed.pdf]*

Các phụ lục cô gửi hiện chưa có số liệu của trường. Tôi soạn dự thảo dưới đây; những chỗ **[…]** cần bổ sung theo kết quả rà soát. Phần lộ trình là **đề xuất để nhà trường xem xét**, chưa phải chỉ tiêu đã được phê duyệt.

---

UBND PHƯỜNG AN BÌNH  
**TRƯỜNG MẦM NON AN BÌNH**  
Số: …/BC-MNAB

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
**Độc lập - Tự do - Hạnh phúc**

*An Bình, ngày … tháng 10 năm 2026*

**BÁO CÁO**  
**Thực trạng và dự kiến lộ trình thực hiện các mục tiêu Đề án  
cho trẻ em mẫu giáo làm quen với tiếng Anh  
tại Trường Mầm non An Bình**

**Kính gửi: Phòng Văn hóa – Xã hội phường An Bình.**

Thực hiện Công văn số 4102/SGDĐT-GDMN ngày 19/10/2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp về việc cung cấp số liệu thực trạng và dự kiến lộ trình thực hiện các mục tiêu Đề án cho trẻ em mẫu giáo làm quen với tiếng Anh tại các cơ sở giáo dục mầm non;

Thực hiện Công văn số 6223/VP-VX ngày 20/10/2026 của Văn phòng HĐND và UBND phường An Bình về việc cung cấp số liệu thực trạng và dự kiến lộ trình thực hiện các mục tiêu Đề án cho trẻ em mẫu giáo làm quen với tiếng Anh tại các cơ sở giáo dục mầm non;

Trường Mầm non An Bình báo cáo thực trạng tại thời điểm tháng 9/2026 và dự kiến lộ trình thực hiện như sau:

**I. THỰC TRẠNG TỔ CHỨC CHO TRẺ EM MẪU GIÁO LÀM QUEN VỚI TIẾNG ANH**

**1. Quy mô trường, lớp và trẻ mẫu giáo**

Nhà trường có […] điểm trường; […] nhóm, lớp, trong đó có […] lớp mẫu giáo với […] trẻ. Số trẻ mẫu giáo theo độ tuổi gồm: […] trẻ 3–4 tuổi; […] trẻ 4–5 tuổi; […] trẻ 5–6 tuổi.

Tình hình tổ chức cho trẻ mẫu giáo làm quen với tiếng Anh tại thời điểm tháng 9/2026: […].

Số lớp có trẻ tham gia làm quen với tiếng Anh: […] lớp; số trẻ tham gia: […] trẻ, chiếm […]% tổng số trẻ mẫu giáo của trường.

Hình thức tổ chức, đơn vị phối hợp nếu có, thời lượng và tài liệu đang sử dụng: […].

**2. Đội ngũ cán bộ quản lý, giáo viên**

Tổng số cán bộ quản lý: […] người; tổng số giáo viên: […] người.

Qua rà soát trình độ, năng lực tiếng Anh và điều kiện tổ chức hoạt động của đội ngũ:

- Giáo viên đủ điều kiện tổ chức hoạt động bằng tiếng Anh/song ngữ: […] người.
- Giáo viên cần đào tạo năng lực tiếng Anh: […] người.
- Giáo viên cần bồi dưỡng năng lực tiếng Anh: […] người.
- Cán bộ quản lý cần đào tạo năng lực tiếng Anh: […] người.
- Cán bộ quản lý cần bồi dưỡng năng lực tiếng Anh: […] người.

Khả năng bố trí giáo viên tổ chức hoạt động, giáo viên phối hợp và những nội dung cần hỗ trợ về chuyên môn: […].

**3. Học liệu, tài nguyên số**

Học liệu tiếng Anh/song ngữ hiện có: […] bộ; tài nguyên số, tài liệu tham khảo: […] bộ/gói; nội dung, tài nguyên phục vụ xây dựng môi trường sử dụng tiếng Anh: […] bộ/gói.

Mức độ đáp ứng đối với việc tổ chức hoạt động cho trẻ ở từng độ tuổi: […]. Những học liệu cần bổ sung hoặc thay thế: […].

**4. Cơ sở vật chất, thiết bị**

Phòng, khu vực có thể sử dụng để tổ chức hoạt động làm quen với tiếng Anh: […]. Thiết bị phục vụ hoạt động tiếng Anh/song ngữ; thiết bị nghe, nhìn, tương tác và thiết bị số hiện có: […].

Tình trạng hạ tầng mạng, đường truyền tại các điểm trường: […].

Khả năng khai thác cơ sở vật chất, thiết bị hiện có và những nội dung cần bổ sung, cải tạo: […].

**5. Nền tảng, công nghệ**

Nền tảng, công cụ hoặc hệ thống số hiện có phục vụ hoạt động giáo dục: […]; công cụ hỗ trợ phối hợp với cha mẹ trẻ: […].

Hiện trạng sử dụng công nghệ, trí tuệ nhân tạo phù hợp để hỗ trợ giáo viên chuẩn bị học liệu, tổ chức hoạt động: […].

**6. Đánh giá chung**

**a) Điều kiện đáp ứng**

Các điều kiện hiện có có thể sử dụng để triển khai hoặc duy trì hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh gồm: […].

**b) Khó khăn, hạn chế và nguyên nhân**

Những điều kiện chưa đáp ứng về đội ngũ, học liệu, cơ sở vật chất, thiết bị và công nghệ: […].

Nguyên nhân cụ thể: […].

Trên cơ sở rà soát, nhà trường xác định nội dung cần ưu tiên là […], làm cơ sở lựa chọn lộ trình phù hợp, bảo đảm khả năng tổ chức thực hiện và duy trì chất lượng hoạt động.

**II. DỰ KIẾN LỘ TRÌNH THỰC HIỆN**

**1. Định hướng thực hiện**

Xây dựng lộ trình trên cơ sở điều kiện thực tế của nhà trường, nhu cầu của trẻ và khả năng đáp ứng của đội ngũ, cơ sở vật chất, học liệu, kinh phí. Việc mở rộng quy mô phải gắn với bảo đảm chất lượng tổ chức hoạt động.

Tổ chức cho trẻ trải nghiệm, làm quen với tiếng Anh thông qua các hoạt động phù hợp độ tuổi, tạo hứng thú và cơ hội giao tiếp tự nhiên; đồng thời bảo đảm thực hiện Chương trình giáo dục mầm non.

Ưu tiên khai thác hiệu quả nguồn lực hiện có; xác định rõ điều kiện còn thiếu để đề xuất bổ sung theo từng giai đoạn. Việc xác định mức độ đạt được thực hiện theo tiêu chí, hướng dẫn của cơ quan có thẩm quyền.

**2. Dự kiến theo từng giai đoạn**

| Mốc thời gian | Nội dung dự kiến thực hiện | Chỉ tiêu cần xác định |
|---|---|---|
| **Đến năm 2030** | Tập trung hoàn thiện các điều kiện thiết yếu về đội ngũ, học liệu, thiết bị và khu vực tổ chức hoạt động; tổ chức cho trẻ làm quen với tiếng Anh phù hợp khả năng đáp ứng của trường. | Số trẻ mẫu giáo dự kiến: […] trẻ; số trẻ tham gia: […] trẻ; điều kiện bảo đảm và mức độ dự kiến đạt: […]. |
| **Đến năm 2035** | Củng cố chất lượng hoạt động; mở rộng cơ hội tham gia cho trẻ trên cơ sở đủ điều kiện; tiếp tục đào tạo, bồi dưỡng đội ngũ và bổ sung học liệu, thiết bị theo nhu cầu thực tế. | Số trẻ mẫu giáo dự kiến: […] trẻ; số trẻ tham gia: […] trẻ; mức độ dự kiến đạt: […]. |
| **Đến năm 2040** | Duy trì kết quả đã đạt; phát triển môi trường sử dụng tiếng Anh phù hợp lứa tuổi; rà soát, nâng cấp các điều kiện phục vụ hoạt động theo yêu cầu của giai đoạn. | Số trẻ mẫu giáo dự kiến: […] trẻ; số trẻ tham gia: […] trẻ; mức độ dự kiến đạt: […]. |
| **Đến năm 2045** | Duy trì bền vững các điều kiện tổ chức hoạt động, chất lượng đội ngũ và học liệu; tiếp tục nâng chất lượng thực hiện phù hợp định hướng của Đề án và điều kiện nhà trường. | Số trẻ mẫu giáo dự kiến: […] trẻ; số trẻ tham gia: […] trẻ; mức độ dự kiến đạt: […]. |

*Số liệu hiện trạng và các chỉ tiêu dự kiến được thể hiện tại Phụ lục I.*

**III. NHU CẦU BỔ SUNG ĐIỀU KIỆN VÀ KINH PHÍ THỰC HIỆN**

**1. Nhu cầu bổ sung điều kiện**

**a) Đội ngũ**

Đào tạo năng lực tiếng Anh cho […] giáo viên, […] cán bộ quản lý; bồi dưỡng năng lực tiếng Anh cho […] giáo viên, […] cán bộ quản lý. Dự kiến thực hiện trong giai đoạn […].

Việc lựa chọn người tham gia căn cứ năng lực hiện có, nhiệm vụ được phân công và khả năng bố trí sử dụng sau đào tạo, bồi dưỡng.

**b) Học liệu, tài nguyên số**

Bổ sung […] bộ học liệu tiếng Anh/song ngữ; […] bộ/gói tài nguyên số, tài liệu tham khảo; […] bộ/gói nội dung, tài nguyên phục vụ xây dựng môi trường sử dụng tiếng Anh.

Ưu tiên học liệu phù hợp trẻ mẫu giáo, dễ sử dụng trong hoạt động vui chơi, trải nghiệm và đáp ứng nhu cầu tổ chức của giáo viên.

**c) Cơ sở vật chất, thiết bị**

Bổ sung, cải tạo […] phòng/khu vực tổ chức hoạt động; bổ sung […] thiết bị phục vụ hoạt động tiếng Anh/song ngữ; […] bộ thiết bị nghe, nhìn, tương tác và thiết bị số; hoàn thiện hạ tầng mạng tại […].

Việc đề xuất đầu tư căn cứ khả năng sử dụng chung và tình trạng thiết bị hiện có, tránh mua sắm trùng lặp.

**d) Nền tảng, công nghệ**

Nhu cầu bổ sung nền tảng, công cụ, hệ thống số hỗ trợ hoạt động giáo dục: […]; công cụ phối hợp với cha mẹ trẻ: […]; nội dung, giải pháp ứng dụng công nghệ, AI phù hợp: […].

*Chi tiết hiện trạng, nhu cầu bổ sung, giai đoạn thực hiện và dự kiến kinh phí tại Phụ lục II.*

**2. Dự kiến nhu cầu kinh phí**

Tổng nhu cầu kinh phí thực hiện: **[…] triệu đồng**, gồm:

| Nội dung | Dự kiến kinh phí (triệu đồng) |
|---|---:|
| Đào tạo, bồi dưỡng đội ngũ | […] |
| Học liệu, tài liệu, tài nguyên số | […] |
| Đầu tư, cải tạo cơ sở vật chất | […] |
| Mua sắm thiết bị | […] |
| Hạ tầng, nền tảng và công nghệ số | […] |
| Các nhiệm vụ khác phục vụ thực hiện Đề án, nếu có | […] |
| **Tổng cộng** | **[…]** |

Phân kỳ kinh phí: giai đoạn 2026–2030: […] triệu đồng; giai đoạn 2031–2035: […] triệu đồng; giai đoạn 2036–2040: […] triệu đồng; giai đoạn 2041–2045: […] triệu đồng.

Nguồn kinh phí dự kiến: ngân sách nhà nước […] triệu đồng; xã hội hóa và nguồn hợp pháp khác […] triệu đồng.

*Chi tiết nhu cầu kinh phí theo nội dung, giai đoạn và nguồn kinh phí tại Phụ lục III.*

**IV. KIẾN NGHỊ, ĐỀ XUẤT**

1. Đề nghị Phòng Văn hóa – Xã hội tổng hợp nhu cầu của nhà trường, tham mưu UBND phường xem xét lộ trình thực hiện và nhu cầu hỗ trợ các điều kiện thiết yếu theo từng giai đoạn.

2. Đề nghị cơ quan chuyên môn hướng dẫn việc xác định điều kiện bảo đảm, tiêu chí đánh giá các mức độ thực hiện Đề án để nhà trường có cơ sở rà soát, đăng ký chỉ tiêu và tổ chức thực hiện thống nhất.

3. Đề nghị hỗ trợ nhà trường tiếp cận các chương trình đào tạo, bồi dưỡng năng lực tiếng Anh, phương pháp tổ chức hoạt động cho trẻ mẫu giáo; hướng dẫn lựa chọn, khai thác học liệu và tài nguyên số phù hợp.

Trên đây là báo cáo thực trạng và dự kiến lộ trình thực hiện các mục tiêu Đề án cho trẻ em mẫu giáo làm quen với tiếng Anh của Trường Mầm non An Bình. Nhà trường kính gửi Phòng Văn hóa – Xã hội phường An Bình tổng hợp, tham mưu UBND phường theo yêu cầu.

**Nơi nhận:**  
- Như trên;  
- Lưu: VT.

**HIỆU TRƯỞNG**  
*(Ký, ghi rõ họ tên, đóng dấu)*

---

**Khi hoàn thiện báo cáo, cô lưu ý:**

- **Chốt số liệu hiện trạng tháng 9/2026**, đúng mốc của biểu mẫu; không thay bằng số liệu tháng 10 mà không giải thích.
- Nộp **báo cáo kèm đủ Phụ lục I, II, III**. Các bảng trong chính văn chỉ tóm tắt, không thay thế phụ lục. *[Source: baocaosolieuthuctranglqtatemg_signed_signed.pdf]*
- Phụ lục I thống kê theo **cơ sở giáo dục**; cần phân biệt số trường với số điểm trường khi cung cấp số liệu cho phường. Không tự xác định “đạt Mức độ 1” chỉ vì trường đã tổ chức làm quen tiếng Anh.
- Tên Đề án theo Quyết định số 2371/QĐ-TTg là **giai đoạn 2025–2035, tầm nhìn đến năm 2045**. Công văn số 4102 có chỗ ghi khác về giai đoạn; khi ghi tên Đề án cần đối chiếu quyết định gốc. *[Source: 2371_QĐ Phê duyệt Đề án Đưa tiếng Anh thành ngôn ngữ thứ hai trong trường học giai đoạn 2025 - 2035, tầm nhìn đến năm 2045.pdf]*

**Cô gửi thêm số lớp, số trẻ mẫu giáo, số trẻ đang làm quen tiếng Anh, tình hình đội ngũ và thiết bị hiện có; tôi sẽ cụ thể hóa phần thực trạng và các chỉ tiêu, tránh để báo cáo chung chung.**

---

USER

27 lớp 621 trẻ mẫu giáo, trẻ LQTA 191 trẻ. Trường liên kết ngoại khóa với công tyCông ty TNHH Giáo dục Kiến Tạo Anh Việt

---

ASSISTANT

Tôi cập nhật **mục I.1 của báo cáo** theo số liệu cô cung cấp như sau:

**1. Quy mô lớp mẫu giáo và tình hình tổ chức cho trẻ làm quen với tiếng Anh**

Trường Mầm non An Bình có **27 lớp mẫu giáo với tổng số 621 trẻ**. Nhà trường tổ chức hoạt động ngoại khóa cho trẻ mẫu giáo làm quen với tiếng Anh thông qua hình thức liên kết với **Công ty TNHH Giáo dục Kiến Tạo Anh Việt**.

Tổng số trẻ tham gia làm quen với tiếng Anh là **191 trẻ, đạt tỷ lệ 30,76%** tổng số trẻ mẫu giáo toàn trường. Số trẻ chưa tham gia là **430 trẻ, chiếm 69,24%**.

Hoạt động làm quen với tiếng Anh hiện được triển khai theo hình thức liên kết ngoại khóa. Việc xây dựng lộ trình thực hiện Đề án cần căn cứ khả năng đáp ứng của đội ngũ trực tiếp tổ chức hoạt động, điều kiện cơ sở vật chất, học liệu và nhu cầu tham gia của trẻ; đồng thời xác định những điều kiện nhà trường cần bổ sung để từng bước mở rộng cơ hội cho trẻ mẫu giáo làm quen với tiếng Anh.

**Số liệu cập nhật vào Phụ lục I:**

| Nội dung | Đơn vị tính | Hiện trạng tháng 9/2026 |
|---|---|---:|
| Tổng số cơ sở đã cho trẻ làm quen tiếng Anh | Cơ sở | 1 |
| Tổng số trẻ em mẫu giáo | Trẻ MG | 621 |
| Tổng số trẻ em đã tham gia làm quen tiếng Anh | Trẻ MG | 191 |

*Các số liệu trên được đưa vào cột hiện trạng tháng 9/2026 nếu đúng tại thời điểm này. Số lớp có trẻ tham gia làm quen tiếng Anh cần thống kê riêng, chưa thể lấy tổng số 27 lớp để điền.*

**Đối với phần đội ngũ**, cần phân biệt giáo viên của nhà trường với giáo viên do công ty bố trí. Việc liên kết tổ chức ngoại khóa chưa đủ căn cứ để xác định số giáo viên nhà trường đủ điều kiện tổ chức hoạt động bằng tiếng Anh/song ngữ hoặc kết luận trường đã đạt Mức độ 1 của Đề án.

---

USER

bạn bổ sung dùm ý này trường Mầm non An Bình A có 27 lớp  với tổng số trẻ  678 trẻ. Trong đó trẻ mẫu giáo 621 trẻ.......

---

ASSISTANT

**1. Quy mô trường, lớp và tình hình tổ chức cho trẻ làm quen với tiếng Anh**

Trường Mầm non An Bình A có **27 lớp với tổng số 678 trẻ**, trong đó có **621 trẻ mẫu giáo và 57 trẻ nhà trẻ**.

Nhà trường tổ chức hoạt động ngoại khóa cho trẻ mẫu giáo làm quen với tiếng Anh thông qua hình thức liên kết với **Công ty TNHH Giáo dục Kiến Tạo Anh Việt**. Tổng số trẻ mẫu giáo tham gia là **191 trẻ, chiếm 30,76% tổng số trẻ mẫu giáo toàn trường**.

---

USER

hoàn chỉnh báo cáo giúp mình theo đúng nghị định 30

---

ASSISTANT

Tôi sẽ hoàn chỉnh báo cáo với tên Trường Mầm non An Bình A và số liệu cô vừa bổ sung, rồi xuất file Word theo thể thức Nghị định 30. Các thông tin chưa có về đội ngũ, thiết bị và kinh phí sẽ để chỗ điền rõ ràng để cô rà soát trước khi ký.

---

ASSISTANT

Tôi đã cập nhật 27 lớp, 678 trẻ; trong đó có 621 trẻ mẫu giáo, 57 trẻ nhà trẻ và 191 trẻ tham gia làm quen tiếng Anh, đạt 30,76% số trẻ mẫu giáo. File Word sẽ kèm đủ 3 phụ lục theo mẫu, đồng thời phân biệt giáo viên nhà trường với giáo viên do công ty liên kết bố trí.

---

ASSISTANT

Bản báo cáo đã được dàn trang và kiểm tra hiển thị, kèm 3 phụ lục để cô bổ sung số liệu. Cô cần xác nhận các số liệu đã cung cấp là số liệu tại tháng 9/2026 theo yêu cầu của biểu mẫu trước khi ký ban hành.

---

ASSISTANT

Đã hoàn chỉnh **bản dự thảo báo cáo và 3 phụ lục**, cập nhật số liệu của Trường Mầm non An Bình A, trình bày file Word theo thể thức Nghị định 30.

📄 [Bao_cao_LQTA_Mam_non_An_Binh_A.docx](sandbox:/workspace/scratch/907369391f1d/output/Bao_cao_LQTA_Mam_non_An_Binh_A.docx)

Cô bổ sung các chỗ **[…]**, số văn bản, ngày ký, người ký và xác nhận số liệu tại **tháng 9/2026** trước khi ban hành.

---

USER

Thực hiện Công văn số 4102/SGDĐT-GDMN ngày 19/10/2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp về việc cung cấp số liệu thực trạng và dự kiến lộ trình thực hiện các mục tiêu Đề án cho trẻ em mẫu giáo làm quen với tiếng Anh tại các cơ sở giáo dục mầm non; Công văn số 6223/VP-VX ngày 20/10/2026 của Văn phòng HĐND và UBND phường An Bình về cùng nội dung, Trường Mầm non An Bình A báo cáo như sau: bạn bổ sung  căn cứ vào điều kiện thực tế,.... trường MN  báo cáo.... sẽ logic hơn

---

ASSISTANT

Thực hiện Công văn số 4102/SGDĐT-GDMN ngày 19/10/2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp về việc cung cấp số liệu thực trạng và dự kiến lộ trình thực hiện các mục tiêu Đề án cho trẻ em mẫu giáo làm quen với tiếng Anh tại các cơ sở giáo dục mầm non; Công văn số 6223/VP-VX ngày 20/10/2026 của Văn phòng HĐND và UBND phường An Bình về cùng nội dung;

Căn cứ điều kiện thực tế về đội ngũ, cơ sở vật chất, học liệu và tình hình tổ chức hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh, Trường Mầm non An Bình A báo cáo thực trạng và dự kiến lộ trình thực hiện các mục tiêu của Đề án tại đơn vị như sau:

---

USER

số liệu LQTA này trường liên kết công ty ngoại khóa tổ chức vào đầu tháng 11. bạn giúp tôi trình bày để logic nhé

---

ASSISTANT

Đúng rồi cô, **191 trẻ là số đăng ký tham gia hoạt động dự kiến tổ chức từ đầu tháng 11/2026**, nên báo cáo không ghi là trẻ “đã tham gia” tại thời điểm tháng 9/2026. Cô thay phần này như sau:

**1. Quy mô trường, lớp và tình hình chuẩn bị tổ chức cho trẻ làm quen với tiếng Anh**

Trường Mầm non An Bình A có 27 lớp với tổng số 678 trẻ; trong đó có 621 trẻ mẫu giáo và 57 trẻ nhà trẻ.

Nhà trường dự kiến tổ chức hoạt động ngoại khóa cho trẻ mẫu giáo làm quen với tiếng Anh thông qua hình thức liên kết với Công ty TNHH Giáo dục Kiến Tạo Anh Việt, bắt đầu từ đầu tháng 11/2026. Đến thời điểm lập báo cáo, có **191 trẻ mẫu giáo đăng ký tham gia, chiếm 30,76% tổng số trẻ mẫu giáo toàn trường**. Đây là số trẻ đăng ký để chuẩn bị tổ chức hoạt động, chưa phải số trẻ đã tham gia làm quen với tiếng Anh.

**Phần đánh giá chung điều chỉnh thành:**

Việc có 191 trẻ mẫu giáo đăng ký tham gia là cơ sở để nhà trường phối hợp với đơn vị liên kết chuẩn bị nhân sự, học liệu, bố trí địa điểm và thời gian tổ chức hoạt động từ đầu tháng 11/2026. Do hoạt động chưa triển khai, nhà trường chưa có cơ sở đánh giá kết quả thực hiện. Lộ trình tiếp theo cần căn cứ điều kiện tổ chức thực tế, nhu cầu đăng ký và kết quả triển khai để xác định quy mô phù hợp.

**Đối với Phụ lục I:** Cột “Hiện trạng 9/2026” phải ghi số thực tế tại tháng 9. **Nếu thời điểm đó trường chưa tổ chức cho trẻ làm quen tiếng Anh**, ghi **0** ở dòng “Tổng số cơ sở đã cho trẻ làm quen tiếng Anh” và “Tổng số trẻ em đã tham gia làm quen tiếng Anh”; bổ sung ghi chú:

*“Đến thời điểm lập báo cáo, có 191/621 trẻ mẫu giáo đăng ký tham gia hoạt động làm quen với tiếng Anh. Nhà trường dự kiến phối hợp với Công ty TNHH Giáo dục Kiến Tạo Anh Việt tổ chức từ đầu tháng 11/2026; số trẻ đăng ký chưa tính vào số trẻ đã tham gia tại thời điểm tháng 9/2026.”*

---

USER

hoàn chỉnh lại giúp mình theo nghị định 30 về văn bản

---

ASSISTANT

Tôi sẽ chỉnh lại file Word theo thể thức Nghị định 30, thống nhất 191 trẻ là số đăng ký, hoạt động dự kiến bắt đầu đầu tháng 11/2026; đồng thời sửa phần đánh giá và phụ lục để không nhầm với số trẻ đã tham gia tại tháng 9/2026.

---

ASSISTANT

Tôi đang kiểm tra bản Word đã chỉnh lại, gồm đoạn căn cứ điều kiện thực tế và toàn bộ nội dung liên quan đến thời điểm tổ chức tháng 11/2026. Tôi sẽ gửi cô bản đầy đủ ngay sau khi kiểm tra xong.

---

ASSISTANT

Đã hoàn chỉnh lại báo cáo và **3 phụ lục theo thể thức Nghị định 30**, bổ sung căn cứ điều kiện thực tế; thống nhất **191 trẻ đăng ký, dự kiến tổ chức từ đầu tháng 11/2026**, không ghi thành kết quả đã thực hiện.

[Bao_cao_LQTA_Mam_non_An_Binh_A.docx](sandbox:/workspace/scratch/907369391f1d/output/Bao_cao_LQTA_Mam_non_An_Binh_A.docx)

Các thông tin chưa được cung cấp vẫn để **[…]** để cô bổ sung trước khi ký ban hành.

---

USER

bạn viết tốt tuy nhiên giáo viên trường không trức tiếp giảng dạy. giáo viên chính giảng dạy là từ công ty liên kết. do đó mục 2 nhỏ của phần I cần điều chỉnh lại cho hợp lý và phù hợp hơn

---

ASSISTANT

**2. Đội ngũ tổ chức hoạt động cho trẻ làm quen với tiếng Anh**

Giáo viên trực tiếp giảng dạy do **Công ty TNHH Giáo dục Kiến Tạo Anh Việt** bố trí theo nội dung liên kết với nhà trường. Số lượng giáo viên dự kiến tham gia giảng dạy: […] người. Nhà trường phối hợp với công ty rà soát hồ sơ, trình độ chuyên môn, năng lực tiếng Anh và khả năng tổ chức hoạt động phù hợp với trẻ mẫu giáo trước khi triển khai.

**Giáo viên của trường không trực tiếp giảng dạy tiếng Anh**, thực hiện phối hợp quản lý trẻ, hỗ trợ duy trì nền nếp, bảo đảm an toàn và trao đổi với giáo viên của công ty về đặc điểm, nhu cầu của trẻ trong quá trình tham gia hoạt động.

Ban Giám hiệu phụ trách quản lý, theo dõi việc thực hiện nội dung liên kết; phối hợp sắp xếp thời gian, địa điểm, kiểm tra công tác chuẩn bị và giám sát chất lượng tổ chức hoạt động. Những vấn đề phát sinh được trao đổi với đơn vị liên kết để kịp thời điều chỉnh, bảo đảm phù hợp với điều kiện nhà trường và đặc điểm lứa tuổi mẫu giáo.

Nhu cầu đào tạo, bồi dưỡng năng lực tiếng Anh cho cán bộ quản lý, giáo viên của trường được rà soát riêng nhằm phục vụ công tác quản lý, phối hợp và chuẩn bị nguồn lực thực hiện Đề án theo lộ trình; không tính giáo viên của công ty vào đội ngũ giáo viên của nhà trường.

---

USER

dựa vào bộ hồ sơ này bạn viết giúp mình nội dung 3 của phần I nhé

---

ASSISTANT

Tôi sẽ đọc hồ sơ của công ty để viết lại mục 3 về học liệu, cơ sở vật chất, thiết bị và công nghệ, phân biệt rõ nội dung công ty cung cấp với điều kiện nhà trường cần bố trí.

---

ASSISTANT

**3. Học liệu, cơ sở vật chất, thiết bị và ứng dụng công nghệ**

**a) Về học liệu**

Nhà trường dự kiến phối hợp với Công ty TNHH Giáo dục Kiến Tạo Anh Việt sử dụng tài liệu thuộc danh mục được phép triển khai tại Quyết định số 3775/QĐ-SGDĐT ngày 30/9/2026 của Sở Giáo dục và Đào tạo tỉnh Đồng Tháp, gồm bộ *My Little Fun* và *Happy Hearts*, với sách học và sách hoạt động tương ứng các cấp độ 1, 2, 3. Việc lựa chọn tài liệu cụ thể được thống nhất với đơn vị liên kết, phù hợp độ tuổi và nội dung tổ chức cho trẻ làm quen với tiếng Anh.

Theo khung chương trình của công ty, học liệu hỗ trợ gồm sách điện tử, tệp âm thanh, thẻ từ vựng và tranh ảnh theo tình huống. Các học liệu được sử dụng để tổ chức hoạt động nghe, nói, ca hát, trò chơi và tương tác, tạo cơ hội cho trẻ tiếp cận tiếng Anh một cách tự nhiên, phù hợp đặc điểm lứa tuổi mẫu giáo. *[Source: Ho so nang luc LQTA - K2627 (1).pdf]*

**b) Về cơ sở vật chất, thiết bị**

Để chuẩn bị tổ chức hoạt động từ đầu tháng 11/2026, nhà trường dự kiến bố trí phòng học, khu vực tổ chức phù hợp với số trẻ đăng ký; phối hợp với công ty rà soát điều kiện sử dụng thiết bị, bảo đảm an toàn và thuận tiện trong quản lý trẻ.

Theo kế hoạch của đơn vị liên kết, công ty có phương án đầu tư, cho mượn màn hình tương tác thông minh kèm chân di động chuyên dụng và chịu trách nhiệm bảo trì, bảo dưỡng thiết bị; tại những điểm trường có sẵn ti vi màn hình lớn, hai bên phối hợp tận dụng để phục vụ hoạt động. Chủng loại, số lượng thiết bị và phương án bố trí tại Trường Mầm non An Bình A sẽ được thống nhất cụ thể trước khi triển khai, làm cơ sở theo dõi, quản lý và sử dụng. *[Source: Ho so nang luc LQTA - K2627 (1).pdf]*

**c) Về ứng dụng công nghệ và phối hợp quản lý**

Nhà trường dự kiến phối hợp khai thác học liệu điện tử và thiết bị trình chiếu, tương tác do công ty bố trí để hỗ trợ giáo viên của công ty tổ chức hoạt động. Việc sử dụng công nghệ gắn với nội dung làm quen tiếng Anh, kết hợp các hoạt động trực tiếp giữa giáo viên và trẻ.

Theo phương án phối hợp của công ty, thông tin về lịch tổ chức, sĩ số, nhân sự giảng dạy và tình hình thực hiện được trao đổi qua nhóm liên lạc trực tuyến giữa cán bộ quản lý nhà trường, giáo viên phụ trách lớp và cán bộ phụ trách của công ty. Nhà trường phối hợp theo dõi, kiểm tra và thống nhất cách cập nhật thông tin nhằm phục vụ quản lý, bảo đảm an toàn và kịp thời xử lý những vấn đề phát sinh khi hoạt động được triển khai. *[Source: Ho so nang luc LQTA - K2627 (1).pdf]*

---

USER

Những khó khăn trong công tác chuẩn bị và nguyên nhân qua rà soát: […]. bạn viết nội dung này giúp mình nhé

---

ASSISTANT

Việc chuẩn bị tổ chức hoạt động làm quen với tiếng Anh cần có sự phối hợp chặt chẽ giữa nhà trường và đơn vị liên kết trong bố trí giáo viên, thống nhất lịch giảng dạy, chuẩn bị học liệu và thiết bị. Do giáo viên trực tiếp giảng dạy thuộc công ty, nhà trường cần thống nhất phương án bố trí, thay thế giáo viên khi phát sinh thay đổi để bảo đảm hoạt động được duy trì ổn định; đồng thời sắp xếp thời gian phù hợp với chế độ sinh hoạt của trẻ và điều kiện tổ chức tại trường.

Bên cạnh đó, hoạt động dự kiến bắt đầu từ đầu tháng 11/2026 nên số liệu hiện có mới phản ánh nhu cầu đăng ký, chưa phản ánh số trẻ tham gia thực tế và khả năng duy trì. Vì vậy, việc xác định quy mô mở rộng và nhu cầu đầu tư theo lộ trình cần tiếp tục được rà soát, điều chỉnh trên cơ sở kết quả triển khai.

---

USER

diễn giải lại nội dung này giúp mình

---

ASSISTANT

Tôi sẽ xem nội dung trong ảnh để diễn đạt lại cho rõ ràng, phù hợp với báo cáo của trường.

---

ASSISTANT

**3.2. Về cơ sở vật chất, thiết bị**

Để chuẩn bị tổ chức hoạt động làm quen với tiếng Anh từ đầu tháng 11/2026, nhà trường dự kiến bố trí phòng học, khu vực tổ chức phù hợp với số trẻ đăng ký; phối hợp với công ty rà soát điều kiện lắp đặt, sử dụng thiết bị, bảo đảm an toàn và thuận tiện trong việc tổ chức hoạt động, quản lý trẻ.

Theo phương án của đơn vị liên kết, mỗi điểm trường/phân hiệu có từ 100 trẻ đăng ký tham gia trở lên được công ty đầu tư, lắp đặt 01 bộ thiết bị phục vụ hoạt động làm quen với tiếng Anh. Nhà trường phối hợp với công ty đối chiếu số trẻ đăng ký tại từng điểm trường để xác định nơi đáp ứng điều kiện và thống nhất phương án bố trí thiết bị. Việc lắp đặt, bàn giao phải hoàn thành trước ngày bắt đầu chương trình; có biên bản bàn giao kèm phiếu định danh từng bộ thiết bị để làm căn cứ quản lý, sử dụng.

---

USER

Những khó khăn trong công tác chuẩn bị và nguyên nhân bạn viết theo thực tế để mang tính thuyết phục hơn

---

ASSISTANT

**3. Những khó khăn trong công tác chuẩn bị và nguyên nhân**

Việc bố trí thời gian tổ chức hoạt động làm quen với tiếng Anh cần được cân đối với chế độ sinh hoạt, chăm sóc và giáo dục trẻ tại trường. Giáo viên trực tiếp giảng dạy do Công ty TNHH Giáo dục Kiến Tạo Anh Việt bố trí nên nhà trường cần phối hợp với công ty thống nhất lịch dạy, phân công giáo viên và phương án thay thế khi có thay đổi. Khó khăn chủ yếu là phải bảo đảm sự phù hợp giữa lịch công tác của giáo viên công ty với thời gian sinh hoạt và điều kiện tổ chức thực tế của từng nhóm, lớp.

Về thiết bị phục vụ hoạt động, theo phương án của công ty, mỗi điểm trường/phân hiệu có từ 100 trẻ đăng ký trở lên mới được đầu tư, lắp đặt 01 bộ thiết bị. Với tổng số 191 trẻ đăng ký toàn trường, việc bố trí thiết bị còn phụ thuộc vào số trẻ đăng ký tại từng điểm trường. Vì vậy, nhà trường cần phối hợp với công ty rà soát số lượng cụ thể, thống nhất phương án phục vụ đối với điểm trường chưa đủ điều kiện; đồng thời kiểm tra vị trí lắp đặt, việc bàn giao và yêu cầu an toàn trước khi đưa vào sử dụng.

Bên cạnh đó, hoạt động dự kiến bắt đầu từ đầu tháng 11/2026 nên tại thời điểm báo cáo, 191 trẻ mới là số trẻ đăng ký, chưa có số liệu tham gia thực tế để đánh giá mức độ duy trì và hiệu quả tổ chức. Đây là khó khăn trong việc xác định quy mô và xây dựng lộ trình mở rộng hoạt động. Nhà trường cần tiếp tục theo dõi tình hình tham gia, khả năng đáp ứng của đơn vị liên kết và ý kiến của cha mẹ trẻ sau khi triển khai để có cơ sở điều chỉnh kế hoạch phù hợp.

---

USER

phần đề xuất, kiến nghị thấy có quy mô quá không?

---

ASSISTANT

Đúng rồi, **phần đề xuất, kiến nghị nên giới hạn ở những việc nhà trường cần được hướng dẫn, hỗ trợ để triển khai**, phù hợp với thực tế hiện nay là đang chuẩn bị tổ chức cho 191 trẻ đăng ký. Nếu đề xuất đầu tư diện rộng, bổ sung biên chế giáo viên tiếng Anh hoặc cơ chế chính sách lớn thì chưa sát nhu cầu trước mắt của trường.

Mình đề nghị viết gọn như sau:

**III. ĐỀ XUẤT, KIẾN NGHỊ**

Đề nghị Phòng Văn hóa – Xã hội phường An Bình quan tâm hướng dẫn nhà trường trong quá trình triển khai hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh, nhất là công tác phối hợp với đơn vị liên kết, theo dõi chất lượng và tổng hợp số liệu báo cáo.

Đề nghị cấp quản lý giáo dục tạo điều kiện để cán bộ quản lý, giáo viên được tham gia các buổi hướng dẫn chuyên môn về quản lý, phối hợp tổ chức hoạt động làm quen với tiếng Anh cho trẻ mẫu giáo, phù hợp với nhiệm vụ được phân công tại trường.

---

USER

Trên đây là báo cáo thực trạng và dự kiến lộ trình thực hiện các mục tiêu Đề án cho trẻ em mẫu giáo làm quen với tiếng Anh của Trường Mầm non An Bình A. Kính gửi Phòng Văn hóa – Xã hội phường An Bình tổng hợp, tham mưu UBND phường theo yêu cầu./. đoạn kết có thể viết lại cho suông hơn nhe

---

ASSISTANT

Trên đây là báo cáo thực trạng và dự kiến lộ trình thực hiện các mục tiêu Đề án cho trẻ em mẫu giáo làm quen với tiếng Anh của Trường Mầm non An Bình A. Nhà trường kính báo cáo Phòng Văn hóa – Xã hội phường An Bình để tổng hợp, tham mưu UBND phường báo cáo theo yêu cầu./.

---

USER

dựa vào hình  và Số lớp có trẻ tham gia: 7 ; thời lượng tổ chức: […]; chương trình, tài liệu đang sử dụng: […]. hoàn chỉnh giúp mình nội dung này

---

ASSISTANT

Mình sẽ xem hình để bổ sung thời lượng và tài liệu, đồng thời diễn đạt phù hợp với thời điểm dự kiến bắt đầu tổ chức.

---

ASSISTANT

Số lớp có trẻ đăng ký tham gia: **07 lớp**, với **191 trẻ mẫu giáo**. Hoạt động dự kiến bắt đầu từ đầu tháng 11/2026, với thời lượng **02 hoạt động/tuần, 08 hoạt động/tháng, mỗi hoạt động 30 phút**, thực hiện trong 35 tuần thực học. Chương trình được tổ chức theo hình thức ngoại khóa cho trẻ mẫu giáo làm quen với tiếng Anh, sử dụng tài liệu **My Little Fun – Nhà xuất bản Giáo dục Việt Nam**; giáo viên của Công ty TNHH Giáo dục Kiến Tạo Anh Việt trực tiếp giảng dạy.

---

USER

bạn giúp mình hoàn chỉnh các mục cần báo trong các sheet này

---

ASSISTANT

Mình sẽ đọc các sheet trong hình, đối chiếu với số liệu đã chốt của trường và xác định những ô còn cần bổ sung để điền đúng nội dung báo cáo.

---

ASSISTANT

Mình đã đối chiếu 3 sheet. **Cần phân biệt số liệu thực trạng tháng 9/2026 với kế hoạch tổ chức từ tháng 11/2026**: 191 trẻ thuộc 07 lớp là số đăng ký cho đợt triển khai sắp tới, chưa đưa vào mục “trẻ đã tham gia” tại tháng 9.

Dưới đây là nội dung điền theo từng phụ lục. Những số liệu chưa có căn cứ mình ghi rõ phần cần rà soát để cô bổ sung, tránh báo cáo sai thực tế.

**1. Sheet Phụ lục I – Lộ trình thực hiện các mục tiêu Đề án**

| Mục | Nội dung | Cách điền cột “Hiện trạng 9/2026” |
|---|---|---|
| I.1 | Số cơ sở giáo dục mầm non vùng thuận lợi | Điền **01** nếu trường thuộc nhóm vùng thuận lợi theo phân loại của địa phương; khi đó I.2 điền **0**. |
| I.2 | Số cơ sở giáo dục mầm non các khu vực còn lại | Điền **01** nếu trường thuộc nhóm này; khi đó I.1 điền **0**. Không điền 01 ở cả hai dòng. |
| I.3 | Tổng số cơ sở đã cho trẻ làm quen tiếng Anh | Điền **0 nếu tháng 9/2026 trường chưa tổ chức**. Việc dự kiến triển khai tháng 11 chưa tính vào hiện trạng tháng 9. |
| I.4 | Tổng số trẻ em mẫu giáo | **621 trẻ**, nếu đây cũng là số trẻ tại thời điểm tháng 9/2026; nếu có biến động phải dùng số chốt tháng 9. Không dùng tổng số 678 trẻ vì có cả trẻ nhà trẻ. |
| I.5 | Tổng số trẻ em đã tham gia làm quen tiếng Anh | Điền **0 nếu tháng 9/2026 chưa có trẻ tham gia**. Không điền 191 trẻ đăng ký tháng 11 vào dòng này. |
| II.1 | Số cơ sở bảo đảm điều kiện cho trẻ em làm quen với tiếng Anh | Điền theo kết quả rà soát điều kiện tại tháng 9/2026. Chưa tổ chức không đồng nghĩa với chưa đủ điều kiện; cần đối chiếu hồ sơ, đội ngũ, học liệu, cơ sở vật chất. |
| II.2 | Tỷ lệ | Nếu tính trên 01 cơ sở: đủ điều kiện là **100%**; chưa đủ điều kiện là **0%**. Chỉ chốt sau rà soát. |
| III.1–2 | Số cơ sở và tỷ lệ đạt Mức độ 1 | Điền theo kết quả đối chiếu tiêu chí. Không tự xác định đạt mức độ chỉ vì đã ký liên kết hoặc có trẻ đăng ký. |
| IV.1–2 | Số cơ sở và tỷ lệ đạt Mức độ 2 | Tương tự, phải có kết quả rà soát theo tiêu chí tương ứng. |
| V.1–2 | Số cơ sở và tỷ lệ đạt Mức độ 3 | Tương tự, phải có kết quả rà soát theo tiêu chí tương ứng. |

**Lưu ý về số cơ sở:** Báo cáo của một trường không lấy **27 lớp** hoặc **07 lớp đăng ký** làm số cơ sở. Trường hợp có nhiều điểm trường, cần thống nhất với bộ phận tổng hợp cách tính theo biểu mẫu.

Đối với các cột **2030, 2035, 2040, 2045**, có thể xây dựng định hướng như sau trước khi chốt số:

| Nội dung | Đến 2030 | Đến 2035 | Đến 2040 | Đến 2045 |
|---|---|---|---|---|
| Cơ sở tổ chức cho trẻ làm quen tiếng Anh | Dự kiến 01 cơ sở | Duy trì 01 cơ sở | Duy trì 01 cơ sở | Duy trì 01 cơ sở |
| Cơ sở bảo đảm điều kiện | Phấn đấu 01 cơ sở, tương ứng 100% | Duy trì và bổ sung điều kiện | Duy trì, nâng cao chất lượng | Duy trì bền vững |
| Tổng số trẻ mẫu giáo | Theo dự báo tuyển sinh | Theo dự báo tuyển sinh | Theo dự báo tuyển sinh | Theo dự báo tuyển sinh |
| Số trẻ tham gia | Xác định từ nhu cầu đăng ký và khả năng tổ chức | Điều chỉnh theo kết quả giai đoạn trước | Điều chỉnh theo quy mô và điều kiện thực tế | Điều chỉnh theo quy mô và điều kiện thực tế |
| Các mức độ 1, 2, 3 | Chốt mục tiêu sau khi đối chiếu tiêu chí và lộ trình được hướng dẫn | Tương tự | Tương tự | Tương tự |

Đây là **định hướng để xác định số liệu**, chưa thay thế các chỉ tiêu số phải nhập vào biểu. Chưa nên tự đặt trường đạt Mức độ 1 vào năm 2030, Mức độ 2 vào năm 2035… khi chưa đối chiếu tiêu chí.

Có thể bổ sung ghi chú dưới phụ lục:

> Tại thời điểm lập báo cáo, nhà trường có 191 trẻ mẫu giáo thuộc 07 lớp đăng ký tham gia hoạt động làm quen với tiếng Anh, dự kiến tổ chức từ đầu tháng 11/2026 thông qua liên kết với Công ty TNHH Giáo dục Kiến Tạo Anh Việt. Số liệu này chưa tính vào số trẻ đã tham gia tại thời điểm tháng 9/2026.

**2. Sheet Phụ lục II – Rà soát điều kiện và xác định nhu cầu đầu tư**

Ở cột **“Hiện trạng 9/2026”**, cần nhập số lượng thực tế có tại tháng 9. Nội dung dưới đây dùng để hoàn chỉnh các cột **“Yêu cầu theo lộ trình”, “Nhu cầu bổ sung”, “Giai đoạn thực hiện” và “Ghi chú”**.

| Mục | Nội dung rà soát | Nội dung đề xuất điền |
|---|---|---|
| **I** | **ĐỘI NGŨ** | |
| 1 | Giáo viên đủ điều kiện tổ chức hoạt động bằng tiếng Anh/song ngữ | Rà soát số giáo viên của trường đáp ứng điều kiện theo yêu cầu của biểu mẫu. Ghi chú: “Giáo viên trực tiếp giảng dạy hoạt động làm quen với tiếng Anh do Công ty TNHH Giáo dục Kiến Tạo Anh Việt bố trí; giáo viên của trường phối hợp quản lý, hỗ trợ trẻ”. Số giáo viên công ty ghi riêng nếu cơ quan tổng hợp yêu cầu. |
| 2 | Giáo viên cần đào tạo năng lực tiếng Anh | Xác định số giáo viên có nhu cầu đào tạo trên cơ sở trình độ hiện có, nguyện vọng và nhiệm vụ dự kiến. Không lấy toàn bộ giáo viên của trường làm nhu cầu đào tạo khi chưa khảo sát. |
| 3 | Giáo viên cần bồi dưỡng năng lực tiếng Anh | Rà soát số giáo viên cần cập nhật, nâng cao năng lực tiếng Anh phục vụ nhiệm vụ. Phân biệt với nhóm cần đào tạo ở dòng trên. |
| 4 | Cán bộ quản lý cần đào tạo năng lực tiếng Anh | Xác định số người qua rà soát trình độ và nhu cầu thực tế; bố trí tham gia theo kế hoạch của cấp quản lý. |
| 5 | Cán bộ quản lý cần bồi dưỡng năng lực tiếng Anh | Xác định số người cần bồi dưỡng nâng cao năng lực tiếng Anh. Nhu cầu tập huấn quản lý hoạt động liên kết cần nêu riêng trong ghi chú, không đồng nhất với bồi dưỡng năng lực tiếng Anh. |
| **II** | **HỌC LIỆU, TÀI NGUYÊN SỐ** | |
| 1 | Học liệu tiếng Anh/song ngữ | Dự kiến sử dụng tài liệu **My Little Fun – Nhà xuất bản Giáo dục Việt Nam**, phù hợp độ tuổi và kế hoạch tổ chức. Số bộ cần bổ sung xác định theo số nhóm học, số trẻ và cách sử dụng tài liệu được thống nhất với công ty. |
| 2 | Tài nguyên số, tài liệu tham khảo | Phối hợp với công ty chuẩn bị học liệu điện tử, tệp âm thanh, hình ảnh và tài liệu hỗ trợ phù hợp với trẻ mẫu giáo. Xác định số bộ/gói thực tế được cung cấp, không tính mỗi tệp riêng lẻ thành một bộ. |
| 3 | Nội dung, tài nguyên phục vụ xây dựng môi trường sử dụng tiếng Anh | Bổ sung tranh ảnh, thẻ từ và nội dung nghe, nhìn gắn với chủ đề gần gũi với trẻ; khai thác trong các hoạt động đã thống nhất với đơn vị liên kết. |
| **III** | **CƠ SỞ VẬT CHẤT, THIẾT BỊ** | |
| 1 | Phòng/khu vực tổ chức hoạt động cần bổ sung, cải tạo | Ưu tiên sử dụng phòng học hiện có; rà soát không gian, ánh sáng, điện và vị trí bố trí thiết bị. Chỉ ghi số phòng cần bổ sung, cải tạo khi xác định có nhu cầu thực tế. **07 lớp có trẻ đăng ký không đồng nghĩa với cần cải tạo 07 phòng.** |
| 2 | Thiết bị phục vụ hoạt động tiếng Anh/song ngữ | Đối chiếu thiết bị hiện có với danh mục phục vụ hoạt động; xác định phần công ty cung cấp và phần trường cần bổ sung, tránh tính trùng. |
| 3 | Thiết bị nghe, nhìn, tương tác và thiết bị số | Theo phương án của công ty, điểm trường/phân hiệu có từ 100 trẻ đăng ký được lắp đặt 01 bộ thiết bị. Số bộ dự kiến tiếp nhận xác định theo số đăng ký tại từng điểm; không suy ra số bộ chỉ từ tổng 191 trẻ toàn trường. |
| 4 | Hạ tầng mạng, đường truyền | Rà soát khả năng kết nối tại khu vực tổ chức hoạt động; tận dụng đường truyền hiện có, chỉ đề xuất nâng cấp khi chưa đáp ứng nhu cầu sử dụng. |
| **IV** | **NỀN TẢNG, CÔNG NGHỆ** | |
| 1 | Nền tảng công nghệ, hệ thống số hỗ trợ hoạt động giáo dục | Ưu tiên khai thác công cụ và tài nguyên công ty cung cấp, phù hợp thiết bị hiện có. Chưa đề xuất mua nền tảng riêng khi chưa xác định nhu cầu. |
| 2 | Công cụ hỗ trợ phối hợp với cha mẹ trẻ em | Dự kiến sử dụng kênh liên lạc hiện có của lớp để thông tin lịch hoạt động, tình hình tham gia và tiếp nhận phản hồi của cha mẹ trẻ. Kiểm tra hiện trạng trước khi ghi số lượng công cụ đang sử dụng. |
| 3 | Ứng dụng công nghệ, AI phù hợp | Trước mắt ưu tiên học liệu nghe, nhìn và tương tác phù hợp độ tuổi; nhu cầu bổ sung ứng dụng AI xác định sau khi đánh giá tính cần thiết, điều kiện sử dụng và hiệu quả. Chưa lập khoản đầu tư riêng khi chưa có phương án cụ thể. |

**Cách điền ba cột còn lại:**

- **Nhu cầu bổ sung:** Ghi số lượng còn thiếu sau khi trừ nguồn lực hiện có và phần công ty cam kết cung cấp. Những hạng mục chưa rà soát ghi “Chưa xác định”, không mặc nhiên ghi 0.
- **Giai đoạn thực hiện:** Các điều kiện chuẩn bị triển khai ghi “2026–2030”; có thể ghi chú “Ưu tiên hoàn thành trước khi tổ chức tháng 11/2026” đối với hạng mục cần ngay. Các giai đoạn sau xác định theo nhu cầu duy trì, thay thế và mở rộng.
- **Dự kiến kinh phí:** Ghi theo số lượng và dự toán cụ thể. Thiết bị do công ty đầu tư vẫn cần làm rõ nguồn, giá trị nếu biểu yêu cầu tổng hợp; chưa có giá trị thì ghi “Chưa xác định giá trị hỗ trợ”.

**3. Sheet Phụ lục III – Tổng hợp nhu cầu kinh phí**

Hiện chưa có số lượng thiết bị cần mua, đơn giá, chi phí đào tạo hoặc dự toán được xác nhận nên **chưa đủ cơ sở điền số tiền cho từng giai đoạn**. Có thể hoàn chỉnh nội dung và ghi chú như sau:

| TT | Nội dung | Căn cứ xác định kinh phí | Nội dung ghi chú đề xuất |
|---|---|---|---|
| 1 | Đào tạo, bồi dưỡng đội ngũ | Số người thực tế có nhu cầu và kế hoạch đào tạo, bồi dưỡng | Xác định theo kết quả rà soát đội ngũ và kế hoạch của cấp quản lý; chưa có dự toán cụ thể. |
| 2 | Học liệu, tài liệu, tài nguyên số | Số bộ/gói cần bổ sung, đơn giá và phạm vi công ty cung cấp | Ưu tiên học liệu phục vụ 191 trẻ đăng ký; làm rõ phần đã bao gồm trong dịch vụ liên kết để tránh tính trùng. |
| 3 | Đầu tư, cải tạo cơ sở vật chất | Danh mục phòng/khu vực thực sự cần cải tạo và dự toán | Ưu tiên sử dụng cơ sở vật chất hiện có; chỉ đề xuất kinh phí đối với hạng mục cần thiết qua rà soát. |
| 4 | Mua sắm thiết bị | Danh mục còn thiếu sau khi tính thiết bị hiện có và thiết bị công ty hỗ trợ | Công ty dự kiến đầu tư thiết bị theo điều kiện số trẻ đăng ký tại từng điểm trường; giá trị hỗ trợ xác định theo hồ sơ bàn giao hoặc thông tin do công ty cung cấp. |
| 5 | Hạ tầng, nền tảng và công nghệ số | Nhu cầu nâng cấp mạng, mua quyền sử dụng hoặc bổ sung công cụ thực tế | Tận dụng hạ tầng và công cụ hiện có; chỉ lập dự toán bổ sung khi có nhu cầu cụ thể. |
| 6 | Các nhiệm vụ khác phục vụ thực hiện Đề án | Nhiệm vụ cụ thể ngoài các nhóm trên | Chỉ tổng hợp khi xác định được nhiệm vụ và căn cứ chi; không dự trù khoản chung chưa rõ nội dung. |

Với các cột tiền, cần thống nhất:

- **“0”** nghĩa là đã xác định không có nhu cầu kinh phí ở khoản đó.
- **“Chưa xác định”** nghĩa là còn thiếu căn cứ lập dự toán.
- **Tổng kinh phí** phải bằng tổng của bốn giai đoạn, đồng thời bằng tổng hai nhóm nguồn kinh phí.
- Không tự chia tỷ lệ ngân sách và xã hội hóa khi chưa xác định nguồn bảo đảm.

Cô bổ sung giúp mình **số trẻ đăng ký tại từng điểm trường; số giáo viên, cán bộ quản lý cần đào tạo/bồi dưỡng; số phòng và thiết bị hiện có; đồng thời xác nhận tháng 9 trường đã tổ chức LQTA hay chưa**. Đây là những số liệu cần thiết để chốt các ô số, thay cho phần “chưa xác định” trong ba sheet.

---

USER

dựa vào vb này bạn xác định lại 3 phụ lục dùm mình

---

ASSISTANT

Mình sẽ đối chiếu hai văn bản với ba phụ lục, nhất là các mốc lộ trình và Mức độ 1, 2, 3, để xác định phần áp dụng cho trường và phần cần địa phương tổng hợp.

---

ASSISTANT

Sau khi đối chiếu **Quyết định số 2371/QĐ-TTg ngày 27/10/2025** và **Quyết định số 3454/QĐ-BGDĐT ngày 17/12/2025**, mình xác định lại như sau: **ba phụ lục cần thể hiện cả hiện trạng và nhu cầu chuẩn bị lâu dài của trường; không chỉ thống kê hoạt động ngoại khóa tiếng Anh sắp tổ chức.** Tuy nhiên, các chỉ tiêu cấp quốc gia không được chuyển nguyên thành tỷ lệ của một trường.

**1. Phụ lục I – Lộ trình thực hiện các mục tiêu Đề án**

**Các mốc chính thức đối với giáo dục mầm non**

Theo mục II.2.a của Đề án ban hành kèm Quyết định 2371, các mục tiêu được xác định như sau: *[Source: 2371_QĐ Phê duyệt Đề án Đưa tiếng Anh thành ngôn ngữ thứ hai trong trường học giai đoạn 2025 - 2035, tầm nhìn đến năm 2045(1).pdf]*

| Nội dung | Đến năm 2030 | Đến năm 2035 | Đến năm 2040 | Đến năm 2045 |
|---|---|---|---|---|
| Cơ sở mầm non bảo đảm điều kiện cho trẻ làm quen với tiếng Anh | 100% cơ sở tại các thành phố, đô thị vùng thuận lợi | Ít nhất 80% cơ sở cả nước; 100% cơ sở vùng thuận lợi | 90% cơ sở cả nước | 100% cơ sở cả nước |
| Cơ sở đạt Mức độ 1 | Ít nhất 10% | Ít nhất 20% | Ít nhất 30% | Ít nhất 50% |
| Cơ sở đạt Mức độ 2 | Không nêu chỉ tiêu riêng cho mầm non ở giai đoạn này | 10% | 15% | 20% |
| Cơ sở đạt Mức độ 3 | Không nêu chỉ tiêu riêng cho mầm non ở giai đoạn này | Không nêu chỉ tiêu riêng cho mầm non ở giai đoạn này | 5% | 10% |

**Đây là tỷ lệ số cơ sở giáo dục, không phải tỷ lệ trẻ tham gia.** Vì vậy, không lấy 10%, 20%, 30%, 50% nhân với 621 trẻ để điền số trẻ theo lộ trình.

**Áp dụng vào phụ lục của Trường Mầm non An Bình A**

| Nhóm nội dung | Xác định lại cách báo cáo của trường |
|---|---|
| **I.1 và I.2. Phân loại cơ sở theo địa bàn** | Báo cáo trường là **01 cơ sở**, xếp vào một trong hai nhóm theo phân loại của địa phương. Không tự xác định là vùng thuận lợi chỉ vì địa chỉ thuộc phường. |
| **I.3. Cơ sở đã cho trẻ làm quen tiếng Anh** | Cột tháng 9/2026 ghi theo hoạt động thực tế tại tháng 9. Nếu chưa tổ chức thì ghi **0**. Các mốc tương lai có thể dự kiến **01 cơ sở** duy trì tổ chức. |
| **I.4. Tổng số trẻ mẫu giáo** | Ghi **621 trẻ** nếu đúng số chốt tháng 9/2026. Các mốc tương lai căn cứ dự báo quy mô tuyển sinh; hai quyết định không quy định số trẻ cho từng trường. |
| **I.5. Trẻ đã tham gia làm quen tiếng Anh** | Không đưa **191 trẻ đăng ký học từ tháng 11/2026** vào số đã tham gia tháng 9. Số trẻ dự kiến ở các mốc tương lai phải căn cứ nhu cầu, quy mô trẻ và khả năng tổ chức. |
| **II. Cơ sở bảo đảm điều kiện** | Hiện trạng phải căn cứ kết quả rà soát. Về lộ trình, có thể đề xuất **đến năm 2030 có 01 cơ sở bảo đảm điều kiện, đạt 100%; duy trì đến năm 2045**. Đây là mục tiêu đề xuất của trường, cần gắn với điều kiện và kế hoạch thực hiện. |
| **III–V. Cơ sở đạt Mức độ 1, 2, 3** | Chưa đủ căn cứ xác định trường đang đạt mức nào chỉ từ hai quyết định và hồ sơ tổ chức ngoại khóa. Các mốc phấn đấu cần đối chiếu tiêu chí cụ thể và định hướng của địa phương trước khi chốt. |

**Về Mức độ 1, 2, 3:** Quyết định 2371 nêu các nhóm tiêu chí đánh giá như môi trường ngôn ngữ, chương trình, học liệu, công nghệ, cơ sở vật chất và đội ngũ. Quyết định 3454 giao các đơn vị thuộc Bộ thực hiện nhiệm vụ xây dựng tiêu chí, quy định đánh giá và mô hình triển khai trong năm 2026. **Hai văn bản được gửi chưa cung cấp bộ tiêu chí chi tiết để tự xác nhận trường đạt từng mức độ.** Điều này cũng không có nghĩa là có thể kết luận hiện nay chưa có văn bản hướng dẫn khác. *[Source: 3454_QD ban hành Kế hoạch(1).pdf]*

Do đó, ở phần thuyết minh kèm phụ lục có thể ghi:

> Nhà trường dự kiến đến năm 2030 bảo đảm các điều kiện tổ chức cho trẻ mẫu giáo làm quen với tiếng Anh và tiếp tục duy trì, nâng cao chất lượng trong các giai đoạn tiếp theo. Chỉ tiêu phấn đấu đạt Mức độ 1, Mức độ 2, Mức độ 3 được cụ thể hóa trên cơ sở tiêu chí đánh giá và hướng dẫn triển khai của cơ quan quản lý giáo dục.

Không nên tự điền **0%** vào các mức độ chỉ vì chưa có kết quả rà soát; “chưa xác định” và “không đạt” là hai tình trạng khác nhau.

**2. Phụ lục II – Rà soát điều kiện và xác định nhu cầu đầu tư**

Điểm cần điều chỉnh so với cách hướng dẫn trước là: **giáo viên công ty trực tiếp giảng dạy không làm mất đi nhu cầu rà soát, đào tạo, bồi dưỡng đội ngũ của trường trong lộ trình dài hạn.**

Quyết định 2371 có nhiệm vụ phát triển đội ngũ, bồi dưỡng năng lực tiếng Anh cho cán bộ quản lý, phát triển học liệu và tăng cường điều kiện cơ sở vật chất, công nghệ. Vì vậy, phụ lục này cần rà soát đủ bốn nhóm theo mẫu. *[Source: 2371_QĐ Phê duyệt Đề án Đưa tiếng Anh thành ngôn ngữ thứ hai trong trường học giai đoạn 2025 - 2035, tầm nhìn đến năm 2045(1).pdf]*

| Dòng trong phụ lục | Nội dung xác định cho trường |
|---|---|
| **I.1. Giáo viên đủ điều kiện tổ chức hoạt động bằng tiếng Anh/song ngữ** | Kiểm tra hồ sơ năng lực của giáo viên trường và ghi số người đáp ứng điều kiện theo yêu cầu biểu mẫu. Ghi riêng trong phần chú thích số giáo viên công ty được bố trí giảng dạy, tránh nhầm với đội ngũ của trường. |
| **I.2. Giáo viên cần đào tạo năng lực tiếng Anh** | Rà soát số giáo viên cần đào tạo để chuẩn bị đội ngũ theo lộ trình; lựa chọn theo nhu cầu, khả năng và nhiệm vụ dự kiến. Không mặc nhiên ghi 0 vì đã liên kết công ty. |
| **I.3. Giáo viên cần bồi dưỡng năng lực tiếng Anh** | Xác định số giáo viên đã có nền tảng tiếng Anh nhưng cần bổ sung, nâng cao năng lực. Phân biệt nội dung đào tạo và bồi dưỡng để tránh tính trùng nhu cầu. |
| **I.4. Cán bộ quản lý cần đào tạo năng lực tiếng Anh** | Ghi số người thực tế có nhu cầu sau rà soát trình độ. Không tự lấy toàn bộ số cán bộ quản lý làm nhu cầu đào tạo. |
| **I.5. Cán bộ quản lý cần bồi dưỡng năng lực tiếng Anh** | Ghi số người cần bồi dưỡng nâng cao năng lực tiếng Anh; nội dung tập huấn quản lý hoạt động liên kết nêu riêng nếu có. |
| **II.1. Học liệu tiếng Anh/song ngữ** | Trước mắt chuẩn bị tài liệu **My Little Fun** cho hoạt động dự kiến triển khai. Xác định số bộ cần dùng, số đã có và số công ty cung cấp trước khi tính nhu cầu bổ sung. |
| **II.2. Tài nguyên số, tài liệu tham khảo** | Rà soát học liệu điện tử, âm thanh, hình ảnh, tài liệu hỗ trợ; ưu tiên khai thác nguồn được cung cấp hợp pháp và phù hợp lứa tuổi. |
| **II.3. Nội dung, tài nguyên xây dựng môi trường sử dụng tiếng Anh** | Xác định nhu cầu tranh ảnh, thẻ từ, bài hát, trò chơi và tài nguyên phục vụ trẻ trải nghiệm, làm quen với tiếng Anh. Không đồng nhất với việc trang trí chữ tiếng Anh trong lớp. |
| **III.1. Phòng/khu vực cần bổ sung, cải tạo** | Rà soát khu vực dự kiến tổ chức tại từng điểm trường; chỉ thống kê số phòng/khu vực thực sự cần bổ sung, cải tạo. Không lấy 07 lớp đăng ký làm số phòng cần đầu tư. |
| **III.2. Thiết bị phục vụ hoạt động tiếng Anh/song ngữ** | Lập danh mục thiết bị cần thiết; đối chiếu thiết bị hiện có và phần công ty cung cấp để xác định phần còn thiếu. |
| **III.3. Thiết bị nghe, nhìn, tương tác và thiết bị số** | Xác định số bộ theo từng điểm trường. Phần công ty dự kiến lắp đặt phải ghi là nguồn dự kiến, chưa đưa vào hiện trạng tháng 9 nếu chưa tiếp nhận. |
| **III.4. Hạ tầng mạng, đường truyền** | Kiểm tra khả năng sử dụng tại nơi tổ chức; xác định nhu cầu nâng cấp thực tế, ưu tiên hạ tầng hiện có. |
| **IV.1. Nền tảng công nghệ, hệ thống số** | Xác định công cụ phục vụ khai thác học liệu và hỗ trợ tổ chức hoạt động; chưa cần đề xuất mua hệ thống riêng nếu công cụ hiện có đáp ứng. |
| **IV.2. Công cụ phối hợp với cha mẹ trẻ** | Tận dụng kênh liên lạc của trường, lớp; xác định nhu cầu bổ sung nếu công cụ hiện có chưa đáp ứng. |
| **IV.3. Ứng dụng công nghệ, AI phù hợp** | Rà soát khả năng ứng dụng để hỗ trợ giáo viên chuẩn bị, lựa chọn học liệu và tổ chức hoạt động. Hai quyết định không ấn định mỗi trường phải mua một phần mềm AI riêng. |

**Cách xác định các cột của Phụ lục II:**

| Cột | Nội dung cần ghi |
|---|---|
| **Hiện trạng 9/2026** | Số người, số bộ, số phòng hoặc hệ thống thực tế tại tháng 9/2026. |
| **Yêu cầu theo lộ trình** | Số lượng và điều kiện trường dự kiến cần đạt để thực hiện mục tiêu đã lựa chọn ở Phụ lục I. |
| **Nhu cầu bổ sung** | Phần còn thiếu so với yêu cầu; làm rõ nguồn trường tự bảo đảm, nguồn công ty cung cấp và phần đề xuất hỗ trợ. |
| **Giai đoạn thực hiện** | Ưu tiên điều kiện ban đầu trong 2026–2030; các giai đoạn sau dành cho duy trì, bồi dưỡng, thay thế và nâng cấp theo nhu cầu. |
| **Dự kiến kinh phí** | Tính theo khối lượng, đơn giá và phương án cụ thể; không lấy một mức tiền chung từ hai quyết định. |
| **Ghi chú** | Nêu nguồn cung cấp, hình thức liên kết, phần đã có và các nội dung còn cần xác định. |

Có thể ghi chú chung:

> Giáo viên trực tiếp tổ chức hoạt động làm quen với tiếng Anh do đơn vị liên kết bố trí. Nhà trường đồng thời rà soát năng lực tiếng Anh và nhu cầu đào tạo, bồi dưỡng của cán bộ quản lý, giáo viên để chuẩn bị điều kiện thực hiện Đề án theo lộ trình.

**3. Phụ lục III – Tổng hợp nhu cầu kinh phí thực hiện lộ trình**

Quyết định 2371 xác định nguồn thực hiện Đề án gồm ngân sách nhà nước, nguồn đầu tư và tài trợ, nguồn thu hợp pháp của cơ sở giáo dục và các nguồn hợp pháp khác; đồng thời cho phép lồng ghép với các chương trình, kế hoạch có liên quan đã được phê duyệt. **Văn bản không quy định một mức kinh phí cố định cho mỗi trường hoặc mỗi trẻ.** *[Source: 2371_QĐ Phê duyệt Đề án Đưa tiếng Anh thành ngôn ngữ thứ hai trong trường học giai đoạn 2025 - 2035, tầm nhìn đến năm 2045(1).pdf]*

Vì vậy, Phụ lục III phải được tổng hợp từ nhu cầu đã xác định ở Phụ lục II:

| Nội dung Phụ lục III | Lấy từ Phụ lục II | Cách xác định phù hợp với trường |
|---|---|---|
| **1. Đào tạo, bồi dưỡng đội ngũ** | Nhóm I | Số người, nội dung, thời gian và chi phí dự kiến của từng đợt đào tạo, bồi dưỡng. Phân rõ phần do trường, cấp quản lý hoặc nguồn khác bảo đảm. |
| **2. Học liệu, tài liệu, tài nguyên số** | Nhóm II | Số bộ/gói cần bổ sung và đơn giá. Không tính lại phần đã bao gồm trong dịch vụ của công ty. |
| **3. Đầu tư, cải tạo cơ sở vật chất** | Nhóm III, dòng 1 | Chỉ tính hạng mục thực tế cần cải tạo, bổ sung để tổ chức hoạt động. |
| **4. Mua sắm thiết bị** | Nhóm III, dòng 2–3 | Tính phần cần mua mới, thay thế; phân biệt thiết bị được tặng, được cho mượn và thiết bị công ty tự sử dụng phục vụ hợp đồng. Không mặc nhiên coi tất cả là tài sản được tài trợ cho trường. |
| **5. Hạ tầng, nền tảng và công nghệ số** | Nhóm III, dòng 4 và nhóm IV | Tính chi phí nâng cấp, bổ sung cần thiết; tránh cộng trùng đường truyền, nền tảng đang được chi từ nhiệm vụ khác. |
| **6. Các nhiệm vụ khác** | Nhiệm vụ cụ thể chưa nằm trong năm nhóm trên | Có thể gồm truyền thông, kiểm tra, đánh giá, sơ kết nếu trường xác định có nhu cầu và căn cứ dự toán; không lập khoản chung chưa rõ việc. |

**Đối với số tiền trong các giai đoạn:**

- Giai đoạn **2026–2030**: ưu tiên nhu cầu chuẩn bị, tổ chức ban đầu và bồi dưỡng đội ngũ.
- Các giai đoạn **2031–2035, 2036–2040, 2041–2045**: dự kiến theo nhu cầu duy trì, nâng cấp, thay thế và mục tiêu mở rộng; không sao chép cùng một mức tiền cho cả bốn giai đoạn.
- Cột **ngân sách nhà nước** phản ánh nhu cầu dự kiến đề xuất từ ngân sách, chưa có nghĩa là đã được cấp.
- Cột **xã hội hóa/nguồn hợp pháp khác** cần nêu rõ nguồn dự kiến và cơ sở xác định.
- Chưa có dự toán thì ghi rõ **“Chưa xác định”** trong bản rà soát; không điền **0** để thay cho thông tin còn thiếu.

Có thể bổ sung phần thuyết minh:

> Nhu cầu kinh phí được xác định trên cơ sở kết quả rà soát đội ngũ, học liệu, cơ sở vật chất và thiết bị; ưu tiên sử dụng hiệu quả điều kiện hiện có, kết hợp nguồn lực của đơn vị liên kết. Nhà trường tiếp tục cụ thể hóa khối lượng, dự toán và nguồn bảo đảm theo từng giai đoạn, tránh trùng lặp với các khoản đã được bố trí hoặc đã bao gồm trong nội dung liên kết.

**Như vậy, hai văn bản giúp chốt được mục tiêu và cách xây dựng ba phụ lục, nhưng chưa đủ để chốt số giáo viên cần đào tạo, số thiết bị thiếu, số tiền đầu tư hoặc mức độ trường đạt được.** Phần cần điều chỉnh rõ nhất là: bổ sung đúng các mốc mục tiêu mầm non ở Phụ lục I; rà soát cả nhu cầu phát triển đội ngũ lâu dài ở Phụ lục II; và lập Phụ lục III từ nhu cầu thực tế, không quy toàn bộ kinh phí về hoạt động ngoại khóa hiện tại.

---

USER

bạn làm thành file tương tự mình gửi và có số liệu để dễ cập nhật. Lưu ý trường mình dạng liên kết

---

ASSISTANT

Mình sẽ làm file Excel gồm 3 phụ lục theo mẫu, điền số liệu đã có và đánh dấu các ô cần cập nhật. Phần đội ngũ, thiết bị và kinh phí sẽ thể hiện rõ trường tổ chức theo hình thức liên kết, giáo viên công ty trực tiếp giảng dạy.

---

ASSISTANT

File sẽ tách rõ số liệu đã có với số liệu dự kiến. Mình sẽ thêm phương án dự kiến số trẻ theo lộ trình để cô dễ điều chỉnh; các ô mức độ đạt được, giáo viên công ty và chi phí chưa xác định sẽ để trống có đánh dấu, tránh hiểu nhầm là số liệu đã chốt.

---

ASSISTANT

Ba phụ lục đã có ô nhập liệu và công thức tính tỷ lệ, nhu cầu bổ sung, kinh phí tổng hợp. Mình đang kiểm tra công thức và bố cục; phần kinh phí sẽ chỉ hiện khi đủ dữ liệu, còn 191 trẻ được ghi rõ là số đăng ký cho tháng 11.

---

ASSISTANT

Mình đã tạo file Excel **3 phụ lục theo mẫu**, phù hợp hình thức **liên kết, giáo viên công ty trực tiếp giảng dạy**.

- Điền số liệu trường đã cung cấp.
- Bổ sung số liệu dự kiến, ghi rõ là **gợi ý để điều chỉnh**.
- Ô vàng để cập nhật; ô xanh có công thức.
- Kinh phí và mức độ chưa đủ căn cứ được để trống.

[Tải file Excel 3 phụ lục](sandbox:/workspace/scratch/907369391f1d/outputs/lqta/Phu_luc_LQTA_An_Binh_A_lien_ket.xlsx)

---

USER

mục này không có nhu cầu  bạn giúp mình viết đoạn này neh

---

ASSISTANT

Mình sẽ xem mục trong hình để viết đoạn xác nhận không có nhu cầu cho phù hợp với hình thức liên kết của trường.

---

ASSISTANT

**2. Dự kiến kinh phí**

Tại thời điểm báo cáo, nhà trường chưa có nhu cầu đề xuất kinh phí bổ sung để thực hiện Đề án. Hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh dự kiến được tổ chức theo hình thức liên kết với Công ty TNHH Giáo dục Kiến Tạo Anh Việt; giáo viên trực tiếp giảng dạy do công ty bố trí, các điều kiện phục vụ hoạt động được thực hiện theo nội dung thỏa thuận liên kết và tận dụng cơ sở vật chất hiện có của trường.

Trong quá trình triển khai, nhà trường tiếp tục rà soát các điều kiện thực tế; trường hợp phát sinh nhu cầu kinh phí ngoài phạm vi liên kết, nhà trường sẽ tổng hợp, báo cáo và đề xuất cấp có thẩm quyền xem xét, bảo đảm phù hợp với lộ trình thực hiện Đề án.

---

USER

dựa vào nội dung này trong văn bản của bộ bạn xác định lại giúp mình nội dung cần điền trong phụ lục 1,2, 3 vaa2 báo cáo

---

ASSISTANT

Mình sẽ đọc phần văn bản cô đánh dấu, rồi đối chiếu lại các nội dung cần điền ở ba phụ lục và báo cáo, nhất là phần áp dụng cho trường tổ chức theo hình thức liên kết.

---

ASSISTANT

Dựa vào đoạn cô gửi, **cần điều chỉnh ba phụ lục theo mục tiêu “bảo đảm điều kiện cho trẻ làm quen với tiếng Anh”, phù hợp với hình thức liên kết của trường**. Không mặc nhiên chuyển thành yêu cầu trường phải có giáo viên tiếng Anh riêng, tự mua thiết bị hoặc đề xuất thêm kinh phí.

Đoạn văn bản xác định **tỷ lệ cơ sở giáo dục mầm non bảo đảm điều kiện và đạt các mức độ**, không quy định tỷ lệ trẻ phải tham gia tại từng trường. Vì vậy, các tỷ lệ trẻ **40%, 60%, 80%, 90%**, cùng gợi ý bồi dưỡng **07 giáo viên, 01 cán bộ quản lý** mình đưa trong file trước **không phải chỉ tiêu của Bộ**. Khi trường chưa xác định những nhu cầu này, cần bỏ khỏi số liệu dự kiến chính thức. *[Source: image(20261026-031315).png]*

**1. Nội dung cần điền trong Phụ lục I**

Đối với trường liên kết, cần phân biệt rõ: **có tổ chức cho trẻ làm quen tiếng Anh**, **bảo đảm điều kiện tổ chức** và **đạt Mức độ 1, 2, 3** là các nội dung khác nhau.

| Nội dung trong phụ lục | Hiện trạng tháng 9/2026 | Dự kiến theo lộ trình |
|---|---|---|
| Số cơ sở giáo dục mầm non vùng thuận lợi/các khu vực còn lại | Trường được tính **01 cơ sở**, điền vào một nhóm theo phân loại của địa phương. | Dự kiến duy trì 01 cơ sở nếu không thay đổi tổ chức. |
| Tổng số cơ sở đã cho trẻ làm quen tiếng Anh | **0 nếu tháng 9 chưa tổ chức**. | Có thể đề xuất **01 cơ sở** tại các mốc 2030, 2035, 2040, 2045, thông qua duy trì hoạt động liên kết. |
| Tổng số trẻ mẫu giáo | **621 trẻ**, sau khi đối chiếu số chốt tháng 9. | Xác định theo dự báo tuyển sinh; không mặc nhiên giữ nguyên 621 trẻ đến năm 2045. |
| Tổng số trẻ đã tham gia làm quen tiếng Anh | **0 nếu tháng 9 chưa tổ chức**. | Xác định theo nhu cầu đăng ký và khả năng tổ chức. Không lấy tỷ lệ cơ sở trong Đề án nhân với số trẻ của trường. |
| Số cơ sở bảo đảm điều kiện | Ghi theo kết quả rà soát điều kiện thực tế tại tháng 9. | Đề xuất **01 cơ sở, tương ứng 100%**, bảo đảm điều kiện vào năm 2030 và duy trì ở các mốc tiếp theo. |
| Số cơ sở, tỷ lệ đạt Mức độ 1 | Chưa tự xác nhận chỉ dựa trên việc liên kết công ty. | Chỉ chốt chỉ tiêu khi đối chiếu tiêu chí và định hướng của cấp quản lý. |
| Số cơ sở, tỷ lệ đạt Mức độ 2, 3 | Tương tự. | Không tự đặt trường phải đạt Mức độ 2 vào năm 2035 hoặc Mức độ 3 vào năm 2045. |

**191 trẻ thuộc 07 lớp** đưa vào ghi chú và phần báo cáo công tác chuẩn bị, vì đây là số đăng ký cho hoạt động dự kiến bắt đầu tháng 11/2026:

> Tại thời điểm báo cáo, nhà trường có 191 trẻ mẫu giáo thuộc 07 lớp đăng ký tham gia hoạt động làm quen với tiếng Anh, dự kiến tổ chức từ đầu tháng 11/2026 theo hình thức liên kết. Số liệu đăng ký này chưa tính vào số trẻ đã tham gia tại thời điểm tháng 9/2026.

Mục tiêu **100% cơ sở bảo đảm điều kiện** không đồng nghĩa với **100% trẻ phải đăng ký học ngoại khóa**; trường cũng không tự điền 10% hoặc 20% vào tỷ lệ đạt mức độ của riêng một cơ sở.

**2. Nội dung cần điền trong Phụ lục II**

Phụ lục II vẫn phải phản ánh điều kiện thực tế, dù trường **không đề xuất kinh phí bổ sung**. Không có nhu cầu kinh phí không có nghĩa là tất cả số liệu hiện trạng đều bằng 0.

| Nhóm nội dung | Cách xác định phù hợp với hình thức liên kết |
|---|---|
| **Giáo viên đủ điều kiện tổ chức hoạt động** | Rà soát giáo viên của trường theo yêu cầu biểu mẫu. Ghi chú riêng: giáo viên trực tiếp giảng dạy do công ty bố trí, số lượng theo danh sách phân công. Không lấy 07 lớp làm 07 giáo viên tiếng Anh. |
| **Giáo viên, cán bộ quản lý cần đào tạo/bồi dưỡng** | Bỏ các số 07 và 01 do mình gợi ý trước. Nếu trường xác nhận qua rà soát chưa có nhu cầu thì ghi **0** ở cột nhu cầu tương ứng; nếu chưa khảo sát thì chưa chốt số. |
| **Học liệu, tài nguyên số** | Ghi số bộ/gói thực tế đã có tại tháng 9. Phần công ty dự kiến cung cấp để triển khai tháng 11 ghi ở yêu cầu, phương án bảo đảm và ghi chú; không tính thành hiện trạng đã có. |
| **Phòng/khu vực tổ chức** | Ghi theo rà soát thực tế. Nếu sử dụng phòng hiện có và không cần cải tạo thì nhu cầu bổ sung, cải tạo ghi **0**. |
| **Thiết bị phục vụ hoạt động** | Ghi thiết bị hiện có và phần công ty bảo đảm riêng biệt. Số bộ công ty cung cấp căn cứ thỏa thuận, điều kiện tại từng điểm trường; chưa xác định thì không tự điền. |
| **Hạ tầng mạng, nền tảng, công cụ phối hợp** | Nếu sử dụng nguồn lực hiện có, đáp ứng yêu cầu và không cần bổ sung thì ghi **0** ở cột nhu cầu bổ sung. |
| **Ứng dụng công nghệ, AI** | Nếu chưa có nhu cầu bổ sung hoặc đầu tư riêng thì ghi **0** ở cột nhu cầu; không bắt buộc đưa ra một khoản mua phần mềm. |
| **Dự kiến kinh phí** | Đối với phần trường xác nhận không phát sinh nhu cầu kinh phí bổ sung, ghi **0 triệu đồng**, kèm ghi chú rõ phạm vi. |

**Riêng phần công ty cung cấp:** nếu trường còn thiếu thiết bị nhưng công ty sẽ bố trí thì vẫn cần thể hiện số lượng cần được bảo đảm và nguồn cung cấp. Không ghi nhu cầu thiết bị bằng 0 chỉ vì trường không phải tự mua.

Ghi chú chung phù hợp để đưa vào Phụ lục II:

> Nhà trường tổ chức hoạt động làm quen với tiếng Anh theo hình thức liên kết; giáo viên trực tiếp giảng dạy do công ty bố trí. Học liệu, thiết bị và các điều kiện phục vụ hoạt động được bảo đảm theo thỏa thuận liên kết, kết hợp sử dụng cơ sở vật chất hiện có. Tại thời điểm báo cáo, nhà trường chưa đề xuất kinh phí bổ sung ngoài phạm vi liên kết.

**3. Nội dung cần điền trong Phụ lục III**

Vì cô đã xác nhận **không có nhu cầu đề xuất kinh phí bổ sung**, có thể ghi **0 triệu đồng** đối với phần kinh phí bổ sung nhà trường đề xuất tại sáu nhóm:

| Nội dung | Kinh phí bổ sung đề xuất tại thời điểm báo cáo |
|---|---:|
| Đào tạo, bồi dưỡng đội ngũ | 0 |
| Học liệu, tài liệu, tài nguyên số | 0 |
| Đầu tư, cải tạo cơ sở vật chất | 0 |
| Mua sắm thiết bị | 0 |
| Hạ tầng, nền tảng và công nghệ số | 0 |
| Các nhiệm vụ khác | 0 |
| **Tổng cộng** | **0** |

**Cần ghi chú rõ:** số 0 này là **không đề xuất kinh phí bổ sung**, không phải hoạt động liên kết không có chi phí.

> Số liệu tại phụ lục phản ánh nhu cầu kinh phí bổ sung ngoài phạm vi liên kết do nhà trường đề xuất tại thời điểm báo cáo. Nhà trường chưa đề xuất kinh phí bổ sung; hoạt động được tổ chức theo thỏa thuận liên kết và sử dụng cơ sở vật chất hiện có. Nhu cầu phát sinh được rà soát, cập nhật theo từng giai đoạn.

Do tên biểu là **“Tổng hợp nhu cầu kinh phí thực hiện lộ trình Đề án”**, nếu cơ quan tổng hợp yêu cầu tính cả nguồn kinh phí phục vụ hoạt động liên kết thì phải bổ sung phần đó theo hợp đồng và kế hoạch thực hiện. **Không dùng bảng toàn số 0 để thể hiện tổng nguồn lực khi vẫn có chi phí liên kết.**

**4. Nội dung điều chỉnh trong báo cáo**

**Về đội ngũ**

> Giáo viên trực tiếp tổ chức hoạt động làm quen với tiếng Anh do Công ty TNHH Giáo dục Kiến Tạo Anh Việt bố trí theo thỏa thuận liên kết. Giáo viên của trường phối hợp quản lý, hỗ trợ trẻ và bảo đảm nền nếp, an toàn trong quá trình tổ chức. Nhà trường kiểm tra hồ sơ giáo viên do công ty phân công, thống nhất lịch hoạt động và theo dõi chất lượng thực hiện.

**Về dự kiến lộ trình**

> Giai đoạn đến năm 2030, nhà trường tập trung bảo đảm các điều kiện tổ chức cho trẻ mẫu giáo làm quen với tiếng Anh theo hình thức liên kết, phù hợp với nhu cầu đăng ký và điều kiện thực tế. Các giai đoạn tiếp theo tiếp tục duy trì, nâng cao chất lượng tổ chức; rà soát quy mô tham gia, đội ngũ của đơn vị liên kết, học liệu, thiết bị và công tác phối hợp để điều chỉnh kế hoạch phù hợp.
>
> Việc xác định mục tiêu phấn đấu đạt Mức độ 1, Mức độ 2, Mức độ 3 được thực hiện trên cơ sở tiêu chí đánh giá, hướng dẫn của cơ quan quản lý giáo dục và kết quả rà soát điều kiện của nhà trường.

**Về dự kiến kinh phí**

> Tại thời điểm báo cáo, nhà trường chưa có nhu cầu đề xuất kinh phí bổ sung ngoài phạm vi liên kết để thực hiện Đề án. Hoạt động làm quen với tiếng Anh được tổ chức theo thỏa thuận với Công ty TNHH Giáo dục Kiến Tạo Anh Việt, kết hợp sử dụng cơ sở vật chất hiện có. Trong quá trình triển khai, nhà trường tiếp tục rà soát, cập nhật nhu cầu và đề xuất kinh phí khi phát sinh nhiệm vụ cần thiết.

Như vậy, **file trước cần bỏ các số liệu gợi ý chưa được trường lựa chọn**, giữ số liệu thực tế, thể hiện nguồn lực do công ty bảo đảm và ghi rõ **chưa đề xuất kinh phí bổ sung ngoài phạm vi liên kết**.

---

USER

hoàn chỉnh 3 file dùm mình nhe

---

ASSISTANT

Mình sẽ hoàn chỉnh thành **3 file Excel riêng cho Phụ lục I, II và III** theo mẫu cô gửi. Mình sẽ bỏ các số liệu gợi ý chưa được trường xác nhận, ghi rõ hình thức liên kết và phần chưa có nhu cầu đề xuất kinh phí bổ sung.

---

ASSISTANT

Ba file đã được cập nhật và kiểm tra công thức. Phụ lục III ghi **0 triệu đồng kinh phí bổ sung đề xuất**, có chú thích phân biệt với chi phí hoạt động liên kết. Những số lượng chưa có căn cứ chốt được đánh dấu **“CXĐ”** để cô bổ sung trước khi gửi.

---

ASSISTANT

Mình đã cập nhật **3 file Excel riêng**, phù hợp hình thức liên kết của trường:

1. [Phụ lục I – Lộ trình thực hiện](sandbox:/workspace/scratch/907369391f1d/outputs/lqta_final/Phu_luc_I_Lo_trinh_LQTA.xlsx)
2. [Phụ lục II – Điều kiện và nhu cầu đầu tư](sandbox:/workspace/scratch/907369391f1d/outputs/lqta_final/Phu_luc_II_Dieu_kien_lien_ket.xlsx)
3. [Phụ lục III – Kinh phí bổ sung](sandbox:/workspace/scratch/907369391f1d/outputs/lqta_final/Phu_luc_III_Kinh_phi_bo_sung.xlsx)

Đã bỏ các số liệu gợi ý chưa xác nhận. **“CXĐ” là nội dung cần bổ sung trước khi gửi**; kinh phí bổ sung đề xuất ghi **0 triệu đồng**, phân biệt rõ với chi phí liên kết.

---

USER

bạn phân tích giúp tôi 3 mức độ của đề àn này

---

USER

cấp học mầm non nhe

---

ASSISTANT

Mình sẽ kiểm tra phần nói về ba mức độ và thẩm quyền hướng dẫn tiêu chí trong Quyết định 2371, để giải thích rõ trường liên kết cần hiểu và báo cáo thế nào.

---

ASSISTANT

Đúng rồi cô, mình phân tích **riêng đối với cấp học mầm non**.

**Điểm cần làm rõ trước:** Quyết định 2371/QĐ-TTg có đặt mục tiêu cơ sở mầm non đạt **Mức độ 1, Mức độ 2, Mức độ 3**, nhưng **chưa quy định cụ thể trong văn bản này mỗi mức phải đáp ứng những tiêu chí, chỉ số nào**. Vì vậy, không thể tự diễn giải “có tổ chức ngoại khóa là Mức độ 1”, “giáo viên trường trực tiếp dạy là Mức độ 2” hoặc “có giáo viên nước ngoài là Mức độ 3”. *[Source: 2371_QĐ Phê duyệt Đề án Đưa tiếng Anh thành ngôn ngữ thứ hai trong trường học giai đoạn 2025 - 2035, tầm nhìn đến năm 2045(2).pdf]*

**1. Ba mức độ đánh giá điều gì?**

Tại chú thích ở **trang 2**, Quyết định nêu các mức độ dùng để đánh giá **cơ sở giáo dục** trong việc đưa tiếng Anh thành ngôn ngữ thứ hai, dựa trên các nhóm tiêu chuẩn, tiêu chí. Đây **không phải ba mức trình độ tiếng Anh của trẻ**, cũng không phải mức độ trường đạt chuẩn quốc gia.

Đối với mầm non, có thể rà soát thực tế theo các nhóm sau. Các ví dụ trong bảng là cách liên hệ với hoạt động của trường, **không phải bộ tiêu chí công nhận mức độ**:

| Nhóm tiêu chí được văn bản đề cập | Liên hệ với trường mầm non |
|---|---|
| Môi trường ngôn ngữ và truyền thông | Trẻ có cơ hội nghe, trải nghiệm, làm quen với tiếng Anh phù hợp lứa tuổi; cha mẹ trẻ hiểu mục đích và cách tổ chức. |
| Chương trình giáo dục và hoạt động dạy học | Nội dung, hình thức tổ chức phù hợp với trẻ mẫu giáo; có kế hoạch và theo dõi chất lượng thực hiện. |
| Học liệu, tài liệu | Có tài liệu, tranh ảnh, bài hát, trò chơi và học liệu phù hợp để tổ chức hoạt động. |
| Chuyển đổi số, ứng dụng AI và cơ sở vật chất | Điều kiện phòng học, thiết bị và công cụ hỗ trợ đáp ứng hoạt động thực tế. Không suy ra rằng mỗi trường phải mua phần mềm AI riêng. |
| Đội ngũ cán bộ quản lý, nhà giáo và người học | Năng lực quản lý, năng lực người trực tiếp giảng dạy, sự phối hợp của giáo viên lớp và tình hình tham gia của trẻ. |
| Hợp tác quốc tế; nghiên cứu khoa học và công nghệ | Thực hiện theo tiêu chí cụ thể phù hợp cấp học khi có hướng dẫn; không tự coi đây là yêu cầu mọi trường mầm non phải có đối tác nước ngoài. |

Quyết định giao Bộ Giáo dục và Đào tạo ban hành quy định, hướng dẫn cụ thể về các mức độ phù hợp từng cấp học tại **mục V.1.d, trang 11**. *[Source: 2371_QĐ Phê duyệt Đề án Đưa tiếng Anh thành ngôn ngữ thứ hai trong trường học giai đoạn 2025 - 2035, tầm nhìn đến năm 2045(2).pdf]*

**2. Mục tiêu ba mức độ đối với mầm non theo từng giai đoạn**

| Mốc thời gian | Mức độ 1 | Mức độ 2 | Mức độ 3 |
|---|---:|---:|---:|
| **Đến năm 2030** | Ít nhất 10% cơ sở mầm non | Chưa nêu chỉ tiêu riêng | Chưa nêu chỉ tiêu riêng |
| **Đến năm 2035** | Ít nhất 20% cơ sở mầm non cả nước | 10% | Chưa nêu chỉ tiêu riêng |
| **Đến năm 2040** | Ít nhất 30% cơ sở mầm non cả nước | 15% | 5% |
| **Đến năm 2045** | Ít nhất 50% cơ sở mầm non cả nước | 20% | 10% |

Đây là **mục tiêu về tỷ lệ cơ sở**, không phải tỷ lệ trẻ trong một trường. “Chưa nêu chỉ tiêu riêng” cũng không có nghĩa là văn bản cấm cơ sở phấn đấu đạt mức đó sớm hơn. *[Source: 2371_QĐ Phê duyệt Đề án Đưa tiếng Anh thành ngôn ngữ thứ hai trong trường học giai đoạn 2025 - 2035, tầm nhìn đến năm 2045(2).pdf]*

**3. “Bảo đảm điều kiện cho trẻ làm quen tiếng Anh” khác với “đạt Mức độ 1” thế nào?**

Hai nội dung này được Quyết định trình bày thành **hai mục tiêu riêng**. Ví dụ, đến năm 2030:

- **100% cơ sở mầm non tại các thành phố, đô thị vùng thuận lợi** bảo đảm điều kiện tổ chức cho trẻ làm quen với tiếng Anh.
- **Ít nhất 10% cơ sở mầm non** đạt Mức độ 1.

Như vậy, **bảo đảm điều kiện tổ chức làm quen với tiếng Anh chưa đồng nghĩa với đạt Mức độ 1**. Việc xác định mức độ còn phải đối chiếu các tiêu chuẩn, tiêu chí đánh giá cơ sở giáo dục. *[Source: 2371_QĐ Phê duyệt Đề án Đưa tiếng Anh thành ngôn ngữ thứ hai trong trường học giai đoạn 2025 - 2035, tầm nhìn đến năm 2045(2).pdf]*

Với mầm non, mục tiêu chung của Đề án là giúp trẻ **trải nghiệm, làm quen với tiếng Anh**, hướng tới phát triển năng lực giao tiếp và chuẩn bị cho việc học tiếng Anh ở phổ thông. Không nên lấy yêu cầu dạy các môn học bằng tiếng Anh của cấp phổ thông để áp nguyên cho trường mầm non.

**4. Áp dụng với Trường Mầm non An Bình A**

Trường có **191 trẻ thuộc 07 lớp đăng ký**, dự kiến tổ chức từ tháng 11/2026; giáo viên công ty trực tiếp giảng dạy. Những thông tin này phản ánh **quy mô đăng ký và phương án tổ chức**, chưa đủ để kết luận trường đạt Mức độ 1.

Cũng không thể kết luận trường không đạt mức độ chỉ vì giáo viên giảng dạy thuộc công ty. **Hình thức liên kết là cách bố trí nguồn lực; mức độ đạt được phải căn cứ tiêu chí và kết quả thực hiện.**

Trong báo cáo, cô có thể viết:

> Nhà trường dự kiến tổ chức cho trẻ mẫu giáo làm quen với tiếng Anh theo hình thức liên kết, tập trung bảo đảm điều kiện về giáo viên trực tiếp giảng dạy, học liệu, cơ sở vật chất và công tác quản lý hoạt động. Đối với Mức độ 1, Mức độ 2, Mức độ 3 của Đề án, nhà trường chưa có đủ căn cứ xác định mức độ đạt được; sẽ rà soát, đối chiếu theo tiêu chí và hướng dẫn của cơ quan quản lý giáo dục để báo cáo, xây dựng lộ trình phù hợp.

**Vì vậy, hiện chưa nên ghi trường “đạt Mức độ 1” trong Phụ lục I chỉ từ việc có hoạt động liên kết.** Đồng thời, không ghi “không đạt” khi chưa có căn cứ đánh giá; cần phân biệt rõ **chưa xác định mức độ** với **đã đánh giá nhưng không đạt**.

---

USER

vậy báo thế nào cho ổn

---

ASSISTANT

Theo mình, **trường nên báo rõ thực trạng tổ chức liên kết, đề xuất lộ trình bảo đảm điều kiện và ghi “chưa xác định” đối với mức độ đạt được**. Cách này phản ánh đúng tình hình, đồng thời vẫn đáp ứng yêu cầu báo cáo.

**1. Trong phần thực trạng, viết:**

> Trường Mầm non An Bình A có 27 lớp với tổng số 678 trẻ, trong đó có 621 trẻ mẫu giáo. Tại thời điểm báo cáo, có 191 trẻ mẫu giáo thuộc 07 lớp đăng ký tham gia hoạt động làm quen với tiếng Anh, dự kiến tổ chức từ đầu tháng 11/2026 theo hình thức liên kết với Công ty TNHH Giáo dục Kiến Tạo Anh Việt. Giáo viên trực tiếp giảng dạy do công ty bố trí; nhà trường phối hợp quản lý, chuẩn bị điều kiện tổ chức và theo dõi chất lượng thực hiện.
>
> Đối với việc xác định cơ sở đạt Mức độ 1, Mức độ 2, Mức độ 3 theo Đề án, nhà trường chưa đủ căn cứ xác định mức độ đạt được; sẽ tiếp tục rà soát, đối chiếu theo tiêu chí và hướng dẫn của cơ quan quản lý giáo dục.

**2. Trong phần dự kiến lộ trình, viết:**

> Giai đoạn đến năm 2030, nhà trường phấn đấu bảo đảm các điều kiện tổ chức cho trẻ mẫu giáo làm quen với tiếng Anh theo hình thức liên kết, phù hợp với nhu cầu đăng ký và điều kiện thực tế. Tập trung bảo đảm giáo viên trực tiếp giảng dạy, học liệu, thiết bị, địa điểm tổ chức và công tác phối hợp quản lý.
>
> Các giai đoạn tiếp theo tiếp tục duy trì, nâng cao chất lượng hoạt động; điều chỉnh quy mô tổ chức theo số trẻ, nhu cầu của cha mẹ trẻ và khả năng đáp ứng của nhà trường, đơn vị liên kết. Mục tiêu phấn đấu đạt các mức độ của Đề án được cụ thể hóa trên cơ sở tiêu chí và hướng dẫn của cấp có thẩm quyền.

**3. Trong ba phụ lục, thống nhất như sau:**

| Nội dung | Cách ghi |
|---|---|
| **Phụ lục I: số trẻ đã tham gia tháng 9/2026** | Ghi **0 nếu tháng 9 chưa tổ chức**. Đưa 191 trẻ đăng ký tháng 11 vào ghi chú. |
| **Phụ lục I: cơ sở bảo đảm điều kiện theo lộ trình** | Dự kiến đến năm 2030: **01 cơ sở, tỷ lệ 100%**; duy trì ở các mốc tiếp theo. Ghi rõ đây là mục tiêu phấn đấu. |
| **Phụ lục I: hiện trạng và chỉ tiêu các Mức độ 1, 2, 3** | Ghi **“Chưa xác định”**, kèm giải thích: “Cụ thể hóa sau khi đối chiếu tiêu chí và hướng dẫn của cơ quan quản lý”. Không tự ghi đạt hoặc không đạt. |
| **Phụ lục II: đội ngũ, học liệu, thiết bị** | Ghi số lượng thực tế đã rà soát; nêu rõ phần công ty bố trí, cung cấp. Chưa có số lượng thì ghi “Chưa xác định”, không tự điền 0. |
| **Phụ lục III: kinh phí** | Nêu rõ **chưa đề xuất kinh phí bổ sung ngoài phạm vi liên kết**. Không diễn đạt thành toàn bộ hoạt động không có kinh phí. |

**4. Phần kiến nghị nên bổ sung đúng vướng mắc đang gặp:**

> Đề nghị Phòng Văn hóa – Xã hội phường An Bình hướng dẫn việc xác định, thống kê cơ sở bảo đảm điều kiện và các mức độ thực hiện Đề án đối với trường tổ chức hoạt động làm quen với tiếng Anh theo hình thức liên kết, làm cơ sở để nhà trường hoàn thiện số liệu và xây dựng lộ trình phù hợp.

**Một điểm mình cần chỉnh lại trong hướng dẫn trước:** Phụ lục III có tên là *tổng hợp nhu cầu kinh phí thực hiện Đề án*, nên **không nên gửi bảng toàn số 0 mà thiếu giải thích phạm vi**. Cô nên giữ câu “Chưa đề xuất kinh phí bổ sung ngoài phạm vi liên kết”; nếu đơn vị tổng hợp yêu cầu cả chi phí liên kết thì bổ sung theo hợp đồng, không tự ước tính.

---

