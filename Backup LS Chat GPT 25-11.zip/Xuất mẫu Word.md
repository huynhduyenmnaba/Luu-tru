USER

bạn xuất dùm mình mẫu 02 đến mẫu 06 sang file word nhé

---

ASSISTANT

Mình sẽ tách nguyên 5 mẫu (Mẫu 02 đến Mẫu 06) từ phụ lục tài liệu bạn gửi sang một file Word có thể chỉnh sửa, giữ nội dung và bố cục văn bản hành chính sát bản gốc.

---

ASSISTANT

Mình đã xác định đủ **5 mẫu từ trang 13 đến trang 20** trong tài liệu *Hướng dẫn kiểm tra nội bộ năm học 2025–2026* của Sở Giáo dục và Đào tạo Đồng Tháp:

- **Mẫu 02:** Quyết định thành lập Ban kiểm tra nội bộ.
- **Mẫu 03:** Kế hoạch tiến hành kiểm tra.
- **Mẫu 04:** Biên bản kiểm tra.
- **Mẫu 05:** Báo cáo kết quả kiểm tra.
- **Mẫu 06:** Thông báo kết quả kiểm tra.

Hiện mình chưa tạo được tệp `.docx` đính kèm trực tiếp trong phiên này. Mình đã chuyển nội dung 5 mẫu sang bản có thể sao chép, chỉnh sửa dưới đây. Bạn có thể sao chép toàn bộ vào Microsoft Word và lưu thành một tệp `.docx`.

> **writing · document**
>
> # MẪU SỐ 02
>
> | ……………………….. | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |---|---|
> | **TÊN ĐƠN VỊ** | **Độc lập - Tự do - Hạnh phúc** |
> | Số: ……/QĐ-…… | ………, ngày … tháng … năm 20… |
>
> ## QUYẾT ĐỊNH
> **Về việc thành lập Ban kiểm tra nội bộ năm học ……………**
>
> **THẨM QUYỀN BAN HÀNH**
>
> *(HIỆU TRƯỞNG TRƯỜNG …… hoặc GIÁM ĐỐC ……)*
>
> Căn cứ (quyết định thành lập, qui định chức năng, nhiệm vụ, quyền hạn của đơn …);
>
> Căn cứ (Các văn bản pháp lý liên quan trực tiếp đến vấn đề giải quyết trong nội dung quyết định).
>
> Xét đề nghị của …………………………………;
>
> **QUYẾT ĐỊNH:**
>
> **Điều 1.** Thành lập Ban kiểm tra nội bộ năm học …………, gồm các ông (bà) có tên sau đây:
>
> 1. …………………………………… Chức vụ ……………, Trưởng ban;
> 2. …………………………………… Chức vụ ……………, Phó Trưởng ban;
> 3. …………………………………… Chức vụ ……………, Thành viên;
>
> ………………………………………………………………………
>
> **Điều 2.** Ban kiểm tra nội bộ có nhiệm vụ …………………………………
>
> **Điều 3.** Quyết định này có hiệu lực kể từ ngày ký.
>
> **Điều 4.** Các ông (bà) có tên tại Điều 1 và các bộ phận, tổ chức, cá nhân là đối tượng kiểm tra chịu trách nhiệm thi hành Quyết định này./.
>
> | **Nơi nhận:** | **THỦ TRƯỞNG ĐƠN VỊ** |
> |---|---|
> | - Nơi điều 4; | *(Ký tên, đóng dấu)* |
> | - Sở Giáo dục và Đào tạo “để báo cáo”; | |
> | - Phòng TCCB Sở GDĐT “để báo cáo”; | |
> | - Lưu: VT. | |
>
> ---
>
> # MẪU SỐ 03
>
> | **TÊN ĐƠN VỊ** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |---|---|
> | Đoàn kiểm tra theo | **Độc lập - Tự do - Hạnh phúc** |
> | Quyết định số ………… | ……………, ngày … tháng … năm … |
>
> ## KẾ HOẠCH TIẾN HÀNH KIỂM TRA
>
> Thực hiện Quyết định kiểm tra số …… ngày …/…/…… của … (Chức danh của người ra quyết định kiểm tra) về việc ………………………………… (tên cuộc kiểm tra), Tổ kiểm tra lập kế hoạch tiến hành kiểm tra như sau:
>
> **I. MỤC ĐÍCH YÊU CẦU**
>
> **1. Mục đích**
>
> ………………………………………………………………………………
>
> **2. Yêu cầu**
>
> ………………………………………………………………………………
>
> **II. NỘI DUNG KIỂM TRA**
>
> 1. Nội dung kiểm tra: ………………………………………………………
> 2. Đối tượng kiểm tra: ……………………………………………………
> 3. Thời kỳ kiểm tra: ………………………………………………………
> 4. Thời hạn kiểm tra: ………………………………………………………
>
> **III. TỔ CHỨC THỰC HIỆN**
>
> 1. Tiến độ thực hiện: ……………………………………………………
> 2. Chế độ thông tin báo cáo: ……………………………………………
> 3. Thành viên tiến hành kiểm tra: ………………………………………
> 4. Điều kiện vật chất đảm bảo thực hiện cuộc kiểm tra: ………………
> 5. Những vấn đề khác (nếu có): …………………………………………
>
> | **Nơi nhận:** | **T/M TỔ (NGƯỜI) KIỂM TRA** |
> |---|---|
> | - Chức danh người ra QĐ kiểm tra; | *(Ký, ghi rõ họ và tên)* |
> | - ………………………… | |
> | - Lưu: ĐKTr,… | |
>
> **PHÊ DUYỆT CỦA NGƯỜI RA QUYẾT ĐỊNH KIỂM TRA**
>
> ………………………………………………………………………………
>
> ---
>
> # MẪU SỐ 04
>
> | **TÊN ĐƠN VỊ** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |---|---|
> | Đoàn kiểm tra theo | **Độc lập - Tự do - Hạnh phúc** |
> | Quyết định số ………… | ……………, ngày … tháng … năm … |
>
> ## BIÊN BẢN KIỂM TRA
> **Về việc ……………………… (ghi rõ nội dung kiểm tra)**
>
> Căn cứ Quyết định số ………/QĐ-… ngày …………… của Hiệu trưởng (Giám đốc) Trường ……… về việc ………………………………; từ ngày … đến ngày …, Tổ kiểm tra đã thu thập thông tin, tài liệu, minh chứng và kiểm tra trực tiếp tại …………… về việc …………………………………………
>
> Sau đây là kết quả kiểm tra:
>
> **I. Thành phần làm việc**
>
> **1. Tổ (người) kiểm tra:**
>
> - Ông/bà ………………………… Chức danh …………………;
> - Ông/bà ………………………… Chức danh …………………;
> - Ông/bà ………………………… Chức danh …………………;
>
> **2. Đã tiến hành kiểm tra đối với:** …………………………, gồm:
>
> - Ông/bà ………………………… Chức danh …………………;
> - Ông/bà ………………………… Chức danh …………………;
> - Ông/bà ………………………… Chức danh …………………;
>
> **3. Người chứng kiến (nếu có):**
>
> ………………………………………………………………………………
>
> **II. Nội dung kiểm tra**
>
> 1. Nội dung ………………………………………………………………
> 2. Nội dung ………………………………………………………………
>
> **III. Đánh giá chung của tổ (người) kiểm tra:**
>
> **1. Ưu điểm:**
>
> ………………………………………………………………………………
>
> **2. Tồn tại:**
>
> ………………………………………………………………………………
>
> **3. Nguyên nhân:**
>
> ………………………………………………………………………………
>
> **IV. Kiến nghị của tổ (người) kiểm tra:**
>
> *(Đối với cá nhân, tổ chuyên môn, nhà trường, cấp trên)*
>
> ………………………………………………………………………………
>
> **V. Ý kiến của bộ phận (người) được kiểm tra:**
>
> ………………………………………………………………………………
>
> Việc kiểm tra kết thúc vào lúc … giờ … ngày … tháng … năm … và được lập thành biên bản. Biên bản gồm … trang.
>
> Biên bản này đã được đọc lại cho những người có tên nêu trên cùng nghe và đồng ý ký xác nhận; biên bản được lập thành … bản có giá trị như nhau, mỗi bên giữ 01 bản./.
>
> | **Người được kiểm tra** | **Tổ kiểm tra** | **Người ghi biên bản** |
> |---|---|---|
> | *(Ký, ghi rõ họ và tên)* | *(Ký, ghi rõ họ và tên)* | *(Ký và ghi rõ họ tên)* |
>
> ---
>
> # MẪU SỐ 05
>
> | **TÊN ĐƠN VỊ** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |---|---|
> | Đoàn kiểm tra theo | **Độc lập - Tự do - Hạnh phúc** |
> | Quyết định số ………… | ……………, ngày … tháng … năm … |
>
> ## BÁO CÁO
> **Kết quả kiểm tra ………………… (tên cuộc kiểm tra)**
>
> Thực hiện Quyết định kiểm tra số …… ngày …/…/…… của … (Chức danh của người ra quyết định kiểm tra) về …………………………… Tổ kiểm tra (người) đã tiến hành kiểm tra tại ……………………… (bộ phận, cá nhân là đối tượng kiểm tra).
>
> Quá trình kiểm tra, Tổ kiểm tra (người) đã làm việc với … (bộ phận, cá nhân có liên quan đã được xác minh để làm rõ nội dung kiểm tra) từ ngày … đến ngày … và tiến hành kiểm tra, xác minh trực tiếp các nội dung kiểm tra.
>
> Sau đây là kết quả kiểm tra:
>
> **1. Khái quát chung**
>
> *(Khái quát đặc điểm tình hình của bộ phận hoặc trình độ đào tạo, tình hình hoạt động của người được kiểm tra có liên quan đến nội dung kiểm tra).*
>
> ………………………………………………………………………………
>
> **2. Kết quả kiểm tra, xác minh**
>
> *(Các nội dung đã tiến hành kiểm tra: mô tả kết quả kiểm tra, nếu có sai phạm cần nêu nội dung sai phạm, hậu quả, thiệt hại gây ra; bộ phận, tổ chức, cá nhân liên quan trực tiếp, gián tiếp đến sai phạm; đánh giá, nhận xét về việc sai phạm của các đối tượng có liên quan).*
>
> ………………………………………………………………………………
>
> **3. Kết luận về những nội dung đã tiến hành kiểm tra**
>
> *(Kết luận về kết quả đạt được, hạn chế, sai phạm (nếu có) của đối tượng kiểm tra, trong đó cần nêu rõ trách nhiệm của nhà trường, tổ chuyên môn…, cá nhân có vi phạm. Trong trường hợp có hành vi tham nhũng thì phải nêu rõ trách nhiệm của người đứng đầu đơn vị, bộ phận để xảy ra hành vi tham nhũng theo mức độ vi phạm).*
>
> ………………………………………………………………………………
>
> **4. Các biện pháp xử lý theo thẩm quyền đã áp dụng (nếu có)**
>
> *(Các biện pháp đã áp dụng trong khi tiến hành kiểm tra như: tạm đình chỉ hành vi vi phạm, kiểm kê tài sản, niêm phong tài liệu).*
>
> ………………………………………………………………………………
>
> **5. Những ý kiến còn khác nhau giữa các thành viên Tổ kiểm tra (nếu có)**
>
> ………………………………………………………………………………
>
> **6. Kiến nghị và biện pháp xử lý**
>
> Kiến nghị nhân rộng những ưu điểm, khắc phục những hạn chế; kiến nghị với cơ quan có thẩm quyền sửa đổi, bổ sung, ban hành quy định cho phù hợp với yêu cầu quản lý hoặc hủy bỏ quy định trái pháp luật phát hiện qua kiểm tra (nếu có), nêu rõ thời hạn để đối tượng kiểm tra, bộ phận, tổ chuyên môn, cá nhân có liên quan phải thực hiện.
>
> Trên đây là Báo cáo kết quả kiểm tra về … (Tên cuộc kiểm tra), Tổ kiểm tra (người) xin ý kiến chỉ đạo của Hiệu trưởng (Giám đốc)./.
>
> | **Nơi nhận:** | **T/M TỔ (NGƯỜI) KIỂM TRA BÁO CÁO** |
> |---|---|
> | - Hiệu trưởng (Giám đốc) “để báo cáo”; | *(Ký và ghi rõ họ và tên)* |
> | - …………………………; | |
> | - Lưu: VT. | |
>
> ---
>
> # MẪU SỐ 06
>
> | ………………………… | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |---|---|
> | **TÊN ĐƠN VỊ** | **Độc lập - Tự do - Hạnh phúc** |
> | Số: ………/TB-…… | ………, ngày … tháng … năm … |
>
> ## THÔNG BÁO
> **Kết quả kiểm tra ………………… (tên cuộc kiểm tra)**
>
> Thực hiện Quyết định kiểm tra số … ngày …/…/… của … (Chức danh của người ra quyết định kiểm tra) về … (tên cuộc kiểm tra) từ ngày …/…/… đến ngày …/…/… Tổ (người) kiểm tra đã tiến hành kiểm tra tại … (bộ phận, tổ chức, cá nhân là đối tượng kiểm tra).
>
> Xét báo cáo kết quả kiểm tra … ngày …/…/… của Tổ (người) kiểm tra, ý kiến giải trình của bộ phận, tổ chức, cá nhân là đối tượng kiểm tra (nếu có).
>
> (Chức danh của người ra quyết định kiểm tra) Thông báo kết quả kiểm tra như sau:
>
> **1. Khái quát chung**
>
> *(Khái quát đặc điểm tình hình tổ chức, hoạt động có liên quan đến nội dung kiểm tra của bộ phận, tổ chức, cá nhân là đối tượng kiểm tra).*
>
> ………………………………………………………………………………
>
> **2. Kết quả kiểm tra, xác minh**
>
> *(Người ra quyết định)… (Nêu kết quả kiểm tra, xác minh thực tế tình hình hoạt động của bộ phận, tổ chức, cá nhân là đối tượng kiểm tra theo mục đích, yêu cầu, nội dung, nhiệm vụ mà kế hoạch tiến hành kiểm tra đặt ra).*
>
> *(Người ra quyết định)… Nhận xét về việc thực hiện nhiệm vụ được giao của bộ phận, tổ chức, cá nhân là đối tượng kiểm tra; xác định rõ ưu điểm (mặt làm được, làm đúng), nhược điểm (tồn tại thiếu sót, sai phạm – nếu có).*
>
> **3. Kết luận**
>
> *(Người ra quyết định) (Kết luận về những nội dung được kiểm tra, những việc đã làm đúng, làm tốt và có hiệu quả, chỉ ra những vấn đề còn tồn tại, thiếu sót, khuyết điểm sai phạm, thực hiện chưa đúng chính sách, pháp luật, xác định rõ trách nhiệm tập thể, cá nhân về từng hành vi vi phạm; hậu quả, thiệt hại do hành vi vi phạm gây ra (nếu có). Trong trường hợp có hành vi tham nhũng thì nêu rõ trách nhiệm của người đứng đầu cơ quan, tổ chức để xảy ra hành vi tham nhũng theo các mức độ vi phạm).*
>
> **4. Các biện pháp xử lý theo thẩm quyền đã áp dụng (nếu có)**
>
> *(Các biện pháp xử lý của người ra quyết định kiểm tra, Tổ (người) kiểm tra hoặc tổ chức có thẩm quyền đã áp dụng trong quá trình tiến hành kiểm tra).*
>
> **5. Kiến nghị và biện pháp xử lý**
>
> Kiến nghị nhân rộng những ưu điểm, khắc phục những hạn chế; kiến nghị với cơ quan có thẩm quyền sửa đổi, bổ sung, ban hành quy định cho phù hợp với yêu cầu quản lý hoặc hủy bỏ quy định trái pháp luật phát hiện qua kiểm tra (nếu có), nêu rõ thời hạn để đối tượng kiểm tra, bộ phận, tổ chức, cá nhân có liên quan phải thực hiện./.
>
> **(Chức danh của người ra quyết định kiểm tra)**
>
> *(Ký, ghi rõ họ tên và đóng dấu)*
>
> **Nơi nhận:**
>
> - Phòng Tổ chức cán bộ Sở GDĐT “để báo cáo”;
> - Bộ phận, tổ chức, cá nhân là đối tượng kiểm tra “để thực hiện”;
> - Tổ chức, cá nhân có liên quan “để thực hiện”;
> - Lưu: …

**Lưu ý:** Nội dung được chuyển từ bản PDF, có chuẩn hóa nhẹ dấu cách và bố cục để dễ chỉnh sửa. Riêng dòng căn cứ thứ nhất ở Mẫu 02 bị thiếu phần cuối trong nội dung PDF trích xuất, nên cần đối chiếu trước khi ban hành. Khi đưa vào Word, bạn nên dùng phông Times New Roman, cỡ 13–14, khổ A4 và ngắt trang giữa các mẫu.

---

ASSISTANT

Hiện mình chưa tạo được tệp `.docx` đính kèm trực tiếp trong phiên này. Mình đã chuyển nội dung 5 mẫu sang bản có thể sao chép, chỉnh sửa dưới đây. Bạn có thể sao chép toàn bộ vào Microsoft Word và lưu thành một tệp `.docx`.

<WritingBlock id="68314" variant="document"># MẪU SỐ 02

| ……………………….. | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
|---|---|
| **TÊN ĐƠN VỊ** | **Độc lập - Tự do - Hạnh phúc** |
| Số: ……/QĐ-…… | ………, ngày … tháng … năm 20… |

## QUYẾT ĐỊNH
**Về việc thành lập Ban kiểm tra nội bộ năm học ……………**

**THẨM QUYỀN BAN HÀNH**

*(HIỆU TRƯỞNG TRƯỜNG …… hoặc GIÁM ĐỐC ……)*

Căn cứ (quyết định thành lập, qui định chức năng, nhiệm vụ, quyền hạn của đơn …);

Căn cứ (Các văn bản pháp lý liên quan trực tiếp đến vấn đề giải quyết trong nội dung quyết định).

Xét đề nghị của …………………………………;

**QUYẾT ĐỊNH:**

**Điều 1.** Thành lập Ban kiểm tra nội bộ năm học …………, gồm các ông (bà) có tên sau đây:

1. …………………………………… Chức vụ ……………, Trưởng ban;
2. …………………………………… Chức vụ ……………, Phó Trưởng ban;
3. …………………………………… Chức vụ ……………, Thành viên;
   
………………………………………………………………………

**Điều 2.** Ban kiểm tra nội bộ có nhiệm vụ …………………………………

**Điều 3.** Quyết định này có hiệu lực kể từ ngày ký.

**Điều 4.** Các ông (bà) có tên tại Điều 1 và các bộ phận, tổ chức, cá nhân là đối tượng kiểm tra chịu trách nhiệm thi hành Quyết định này./.

| **Nơi nhận:** | **THỦ TRƯỞNG ĐƠN VỊ** |
|---|---|
| - Nơi điều 4; | *(Ký tên, đóng dấu)* |
| - Sở Giáo dục và Đào tạo “để báo cáo”; | |
| - Phòng TCCB Sở GDĐT “để báo cáo”; | |
| - Lưu: VT. | |

---

# MẪU SỐ 03

| **TÊN ĐƠN VỊ** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
|---|---|
| Đoàn kiểm tra theo | **Độc lập - Tự do - Hạnh phúc** |
| Quyết định số ………… | ……………, ngày … tháng … năm … |

## KẾ HOẠCH TIẾN HÀNH KIỂM TRA

Thực hiện Quyết định kiểm tra số …… ngày …/…/…… của … (Chức danh của người ra quyết định kiểm tra) về việc ………………………………… (tên cuộc kiểm tra), Tổ kiểm tra lập kế hoạch tiến hành kiểm tra như sau:

**I. MỤC ĐÍCH YÊU CẦU**

**1. Mục đích**

………………………………………………………………………………

**2. Yêu cầu**

………………………………………………………………………………

**II. NỘI DUNG KIỂM TRA**

1. Nội dung kiểm tra: ………………………………………………………
2. Đối tượng kiểm tra: ……………………………………………………
3. Thời kỳ kiểm tra: ………………………………………………………
4. Thời hạn kiểm tra: ………………………………………………………

**III. TỔ CHỨC THỰC HIỆN**

1. Tiến độ thực hiện: ……………………………………………………
2. Chế độ thông tin báo cáo: ……………………………………………
3. Thành viên tiến hành kiểm tra: ………………………………………
4. Điều kiện vật chất đảm bảo thực hiện cuộc kiểm tra: ………………
5. Những vấn đề khác (nếu có): …………………………………………

| **Nơi nhận:** | **T/M TỔ (NGƯỜI) KIỂM TRA** |
|---|---|
| - Chức danh người ra QĐ kiểm tra; | *(Ký, ghi rõ họ và tên)* |
| - ………………………… | |
| - Lưu: ĐKTr,… | |

**PHÊ DUYỆT CỦA NGƯỜI RA QUYẾT ĐỊNH KIỂM TRA**

………………………………………………………………………………

---

# MẪU SỐ 04

| **TÊN ĐƠN VỊ** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
|---|---|
| Đoàn kiểm tra theo | **Độc lập - Tự do - Hạnh phúc** |
| Quyết định số ………… | ……………, ngày … tháng … năm … |

## BIÊN BẢN KIỂM TRA
**Về việc ……………………… (ghi rõ nội dung kiểm tra)**

Căn cứ Quyết định số ………/QĐ-… ngày …………… của Hiệu trưởng (Giám đốc) Trường ……… về việc ………………………………; từ ngày … đến ngày …, Tổ kiểm tra đã thu thập thông tin, tài liệu, minh chứng và kiểm tra trực tiếp tại …………… về việc …………………………………………

Sau đây là kết quả kiểm tra:

**I. Thành phần làm việc**

**1. Tổ (người) kiểm tra:**

- Ông/bà ………………………… Chức danh …………………;
- Ông/bà ………………………… Chức danh …………………;
- Ông/bà ………………………… Chức danh …………………;

**2. Đã tiến hành kiểm tra đối với:** …………………………, gồm:

- Ông/bà ………………………… Chức danh …………………;
- Ông/bà ………………………… Chức danh …………………;
- Ông/bà ………………………… Chức danh …………………;

**3. Người chứng kiến (nếu có):**

………………………………………………………………………………

**II. Nội dung kiểm tra**

1. Nội dung ………………………………………………………………
2. Nội dung ………………………………………………………………

**III. Đánh giá chung của tổ (người) kiểm tra:**

**1. Ưu điểm:**

………………………………………………………………………………

**2. Tồn tại:**

………………………………………………………………………………

**3. Nguyên nhân:**

………………………………………………………………………………

**IV. Kiến nghị của tổ (người) kiểm tra:**

*(Đối với cá nhân, tổ chuyên môn, nhà trường, cấp trên)*

………………………………………………………………………………

**V. Ý kiến của bộ phận (người) được kiểm tra:**

………………………………………………………………………………

Việc kiểm tra kết thúc vào lúc … giờ … ngày … tháng … năm … và được lập thành biên bản. Biên bản gồm … trang.

Biên bản này đã được đọc lại cho những người có tên nêu trên cùng nghe và đồng ý ký xác nhận; biên bản được lập thành … bản có giá trị như nhau, mỗi bên giữ 01 bản./.

| **Người được kiểm tra** | **Tổ kiểm tra** | **Người ghi biên bản** |
|---|---|---|
| *(Ký, ghi rõ họ và tên)* | *(Ký, ghi rõ họ và tên)* | *(Ký và ghi rõ họ tên)* |

---

# MẪU SỐ 05

| **TÊN ĐƠN VỊ** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
|---|---|
| Đoàn kiểm tra theo | **Độc lập - Tự do - Hạnh phúc** |
| Quyết định số ………… | ……………, ngày … tháng … năm … |

## BÁO CÁO
**Kết quả kiểm tra ………………… (tên cuộc kiểm tra)**

Thực hiện Quyết định kiểm tra số …… ngày …/…/…… của … (Chức danh của người ra quyết định kiểm tra) về …………………………… Tổ kiểm tra (người) đã tiến hành kiểm tra tại ……………………… (bộ phận, cá nhân là đối tượng kiểm tra).

Quá trình kiểm tra, Tổ kiểm tra (người) đã làm việc với … (bộ phận, cá nhân có liên quan đã được xác minh để làm rõ nội dung kiểm tra) từ ngày … đến ngày … và tiến hành kiểm tra, xác minh trực tiếp các nội dung kiểm tra.

Sau đây là kết quả kiểm tra:

**1. Khái quát chung**

*(Khái quát đặc điểm tình hình của bộ phận hoặc trình độ đào tạo, tình hình hoạt động của người được kiểm tra có liên quan đến nội dung kiểm tra).*

………………………………………………………………………………

**2. Kết quả kiểm tra, xác minh**

*(Các nội dung đã tiến hành kiểm tra: mô tả kết quả kiểm tra, nếu có sai phạm cần nêu nội dung sai phạm, hậu quả, thiệt hại gây ra; bộ phận, tổ chức, cá nhân liên quan trực tiếp, gián tiếp đến sai phạm; đánh giá, nhận xét về việc sai phạm của các đối tượng có liên quan).*

………………………………………………………………………………

**3. Kết luận về những nội dung đã tiến hành kiểm tra**

*(Kết luận về kết quả đạt được, hạn chế, sai phạm (nếu có) của đối tượng kiểm tra, trong đó cần nêu rõ trách nhiệm của nhà trường, tổ chuyên môn…, cá nhân có vi phạm. Trong trường hợp có hành vi tham nhũng thì phải nêu rõ trách nhiệm của người đứng đầu đơn vị, bộ phận để xảy ra hành vi tham nhũng theo mức độ vi phạm).*

………………………………………………………………………………

**4. Các biện pháp xử lý theo thẩm quyền đã áp dụng (nếu có)**

*(Các biện pháp đã áp dụng trong khi tiến hành kiểm tra như: tạm đình chỉ hành vi vi phạm, kiểm kê tài sản, niêm phong tài liệu).*

………………………………………………………………………………

**5. Những ý kiến còn khác nhau giữa các thành viên Tổ kiểm tra (nếu có)**

………………………………………………………………………………

**6. Kiến nghị và biện pháp xử lý**

Kiến nghị nhân rộng những ưu điểm, khắc phục những hạn chế; kiến nghị với cơ quan có thẩm quyền sửa đổi, bổ sung, ban hành quy định cho phù hợp với yêu cầu quản lý hoặc hủy bỏ quy định trái pháp luật phát hiện qua kiểm tra (nếu có), nêu rõ thời hạn để đối tượng kiểm tra, bộ phận, tổ chuyên môn, cá nhân có liên quan phải thực hiện.

Trên đây là Báo cáo kết quả kiểm tra về … (Tên cuộc kiểm tra), Tổ kiểm tra (người) xin ý kiến chỉ đạo của Hiệu trưởng (Giám đốc)./.

| **Nơi nhận:** | **T/M TỔ (NGƯỜI) KIỂM TRA BÁO CÁO** |
|---|---|
| - Hiệu trưởng (Giám đốc) “để báo cáo”; | *(Ký và ghi rõ họ và tên)* |
| - …………………………; | |
| - Lưu: VT. | |

---

# MẪU SỐ 06

| ………………………… | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
|---|---|
| **TÊN ĐƠN VỊ** | **Độc lập - Tự do - Hạnh phúc** |
| Số: ………/TB-…… | ………, ngày … tháng … năm … |

## THÔNG BÁO
**Kết quả kiểm tra ………………… (tên cuộc kiểm tra)**

Thực hiện Quyết định kiểm tra số … ngày …/…/… của … (Chức danh của người ra quyết định kiểm tra) về … (tên cuộc kiểm tra) từ ngày …/…/… đến ngày …/…/… Tổ (người) kiểm tra đã tiến hành kiểm tra tại … (bộ phận, tổ chức, cá nhân là đối tượng kiểm tra).

Xét báo cáo kết quả kiểm tra … ngày …/…/… của Tổ (người) kiểm tra, ý kiến giải trình của bộ phận, tổ chức, cá nhân là đối tượng kiểm tra (nếu có).

(Chức danh của người ra quyết định kiểm tra) Thông báo kết quả kiểm tra như sau:

**1. Khái quát chung**

*(Khái quát đặc điểm tình hình tổ chức, hoạt động có liên quan đến nội dung kiểm tra của bộ phận, tổ chức, cá nhân là đối tượng kiểm tra).*

………………………………………………………………………………

**2. Kết quả kiểm tra, xác minh**

*(Người ra quyết định)… (Nêu kết quả kiểm tra, xác minh thực tế tình hình hoạt động của bộ phận, tổ chức, cá nhân là đối tượng kiểm tra theo mục đích, yêu cầu, nội dung, nhiệm vụ mà kế hoạch tiến hành kiểm tra đặt ra).*

*(Người ra quyết định)… Nhận xét về việc thực hiện nhiệm vụ được giao của bộ phận, tổ chức, cá nhân là đối tượng kiểm tra; xác định rõ ưu điểm (mặt làm được, làm đúng), nhược điểm (tồn tại thiếu sót, sai phạm – nếu có).*

**3. Kết luận**

*(Người ra quyết định) (Kết luận về những nội dung được kiểm tra, những việc đã làm đúng, làm tốt và có hiệu quả, chỉ ra những vấn đề còn tồn tại, thiếu sót, khuyết điểm sai phạm, thực hiện chưa đúng chính sách, pháp luật, xác định rõ trách nhiệm tập thể, cá nhân về từng hành vi vi phạm; hậu quả, thiệt hại do hành vi vi phạm gây ra (nếu có). Trong trường hợp có hành vi tham nhũng thì nêu rõ trách nhiệm của người đứng đầu cơ quan, tổ chức để xảy ra hành vi tham nhũng theo các mức độ vi phạm).*

**4. Các biện pháp xử lý theo thẩm quyền đã áp dụng (nếu có)**

*(Các biện pháp xử lý của người ra quyết định kiểm tra, Tổ (người) kiểm tra hoặc tổ chức có thẩm quyền đã áp dụng trong quá trình tiến hành kiểm tra).*

**5. Kiến nghị và biện pháp xử lý**

Kiến nghị nhân rộng những ưu điểm, khắc phục những hạn chế; kiến nghị với cơ quan có thẩm quyền sửa đổi, bổ sung, ban hành quy định cho phù hợp với yêu cầu quản lý hoặc hủy bỏ quy định trái pháp luật phát hiện qua kiểm tra (nếu có), nêu rõ thời hạn để đối tượng kiểm tra, bộ phận, tổ chức, cá nhân có liên quan phải thực hiện./.

**(Chức danh của người ra quyết định kiểm tra)**

*(Ký, ghi rõ họ tên và đóng dấu)*

**Nơi nhận:**

- Phòng Tổ chức cán bộ Sở GDĐT “để báo cáo”;
- Bộ phận, tổ chức, cá nhân là đối tượng kiểm tra “để thực hiện”;
- Tổ chức, cá nhân có liên quan “để thực hiện”;
- Lưu: …</WritingBlock>

**Lưu ý:** Nội dung được chuyển từ bản PDF, có chuẩn hóa nhẹ dấu cách và bố cục để dễ chỉnh sửa. Riêng dòng căn cứ thứ nhất ở Mẫu 02 bị thiếu phần cuối trong nội dung PDF trích xuất, nên cần đối chiếu trước khi ban hành. Khi đưa vào Word, bạn nên dùng phông Times New Roman, cỡ 13–14, khổ A4 và ngắt trang giữa các mẫu.

---

