USER

đây là quyết định thành lập ban chỉ đạo công tác truyền thông. Tuy nhiên do công tác chuyển đổi số gắn liền với truyền thông. Do đó mình cần 1 quyết định có đủ 2 nội dung. Thành phần ban chi93 đạo không thay đổi. Bạn hãy giúp tôi hoàn thành nhé

---

ASSISTANT

Tôi sẽ chỉnh sửa quyết định thành **Quyết định thành lập Ban Chỉ đạo công tác truyền thông và chuyển đổi số năm học 2026–2027**, giữ nguyên 13 thành viên trong danh sách. Tôi cũng sẽ rà soát sự thống nhất về số quyết định, năm học và bổ sung nhiệm vụ chuyển đổi số cho từng vị trí, rồi trình bày thành file Word để cô có thể sử dụng.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đã rà soát quyết định và danh sách Ban Chỉ đạo của Trường Mầm non An Bình. Phương án phù hợp là **thành lập một Ban Chỉ đạo chung về công tác truyền thông và chuyển đổi số năm học 2026–2027**, không cần thành lập hai ban riêng biệt.

Bản điều chỉnh sẽ bảo đảm:

- **Giữ nguyên 13 thành viên**, chức vụ và vị trí trong Ban Chỉ đạo.
- Giữ những nhiệm vụ truyền thông đã phân công, bổ sung nhiệm vụ chuyển đổi số tương ứng với từng người.
- Làm rõ trách nhiệm chỉ đạo, ứng dụng công nghệ số, quản lý dữ liệu, xây dựng học liệu số và bảo đảm an toàn thông tin.
- Thống nhất nội dung quyết định với danh sách và phân công nhiệm vụ đính kèm.

Tôi cũng phát hiện một số điểm cần chỉnh trong bản gốc: số quyết định ở phần đầu là **75/QĐ-MNAB**, nhưng phụ lục ghi **77/QĐ-MNAB**; phụ lục ghi năm học 2025–2026 thay vì 2026–2027; tên trường ở dòng chức danh người ra quyết định còn thiếu chữ “An”.

Dưới đây là bản dự thảo hoàn chỉnh, đã bổ sung các căn cứ và nội dung quản lý phù hợp.

> **writing · document**
>
> | **UBND PHƯỜNG AN BÌNH** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |:---:|:---:|
> | **TRƯỜNG MẦM NON AN BÌNH** | **Độc lập - Tự do - Hạnh phúc** |
> | Số: 75/QĐ-MNAB | *Phường An Bình, ngày 01 tháng 10 năm 2026* |
>
> # QUYẾT ĐỊNH
> **Về việc thành lập Ban Chỉ đạo công tác truyền thông và chuyển đổi số năm học 2026–2027**
>
> **HIỆU TRƯỞNG TRƯỜNG MẦM NON AN BÌNH**
>
> Căn cứ Điều lệ Trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo, được sửa đổi, bổ sung bởi Thông tư số 51/2026/TT-BGDĐT ngày 30 tháng 6 năm 2026;
>
> Căn cứ Quyết định số 131/QĐ-TTg ngày 25 tháng 01 năm 2022 của Thủ tướng Chính phủ phê duyệt Đề án “Tăng cường ứng dụng công nghệ thông tin và chuyển đổi số trong giáo dục và đào tạo giai đoạn 2022–2025, định hướng đến năm 2030”;
>
> Căn cứ Kế hoạch số 129/KH-MNAB ngày 11 tháng 9 năm 2026 của Trường Mầm non An Bình về thực hiện nhiệm vụ năm học 2026–2027;
>
> Căn cứ Kế hoạch số 200/KH-MNAB ngày 30 tháng 9 năm 2026 của Trường Mầm non An Bình về thực hiện công tác truyền thông năm học 2026–2027;
>
> Căn cứ yêu cầu triển khai công tác truyền thông và chuyển đổi số trong hoạt động quản lý, chăm sóc, nuôi dưỡng và giáo dục trẻ của nhà trường;
>
> Theo đề nghị của Phó Hiệu trưởng phụ trách chuyên môn.
>
> **QUYẾT ĐỊNH:**
>
> **Điều 1.** Thành lập Ban Chỉ đạo công tác truyền thông và chuyển đổi số Trường Mầm non An Bình năm học 2026–2027 gồm 13 (mười ba) thành viên, có tên trong danh sách và bảng phân công nhiệm vụ kèm theo Quyết định này.
>
> **Điều 2. Nhiệm vụ của Ban Chỉ đạo**
>
> Ban Chỉ đạo có trách nhiệm tham mưu, tổ chức triển khai, hướng dẫn, kiểm tra và đánh giá việc thực hiện công tác truyền thông và chuyển đổi số của nhà trường, tập trung vào các nhiệm vụ sau:
>
> 1. **Về công tác truyền thông**
>
> - Tổ chức triển khai thực hiện kế hoạch truyền thông năm học 2026–2027; tuyên truyền các chủ trương, chính sách, quy định của ngành giáo dục và những nội dung liên quan đến hoạt động của nhà trường.
> - Thực hiện truyền thông về công tác chăm sóc, nuôi dưỡng, giáo dục trẻ; các hoạt động chuyên môn, ngày lễ, hội, sự kiện, phong trào thi đua và những hoạt động nổi bật của nhà trường.
> - Phối hợp với các tổ chuyên môn, tổ văn phòng và giáo viên xây dựng tin, bài, hình ảnh, video, phóng sự và các sản phẩm truyền thông phù hợp để đăng tải trên website, kênh YouTube, trang Facebook và các kênh thông tin chính thức của nhà trường.
> - Tăng cường phối hợp, cung cấp thông tin và tiếp nhận phản hồi từ cha mẹ trẻ; góp phần xây dựng hình ảnh nhà trường tích cực, thân thiện, minh bạch và tạo sự đồng thuận trong cộng đồng.
> - Kiểm tra, rà soát và phê duyệt nội dung truyền thông theo phân cấp; bảo đảm thông tin chính xác, phù hợp, kịp thời và tuân thủ các quy định liên quan.
>
> 2. **Về công tác chuyển đổi số**
>
> - Tham mưu xây dựng và tổ chức thực hiện các nội dung chuyển đổi số phù hợp với nhiệm vụ năm học và điều kiện thực tế của nhà trường.
> - Đẩy mạnh ứng dụng công nghệ thông tin, nền tảng và công cụ số trong quản lý, điều hành, thực hiện nhiệm vụ chuyên môn, quản lý hồ sơ và trao đổi thông tin.
> - Hướng dẫn cán bộ, giáo viên, nhân viên khai thác, sử dụng hiệu quả các phần mềm, hệ thống quản lý và nền tảng số đang được triển khai tại nhà trường; thực hiện cập nhật, quản lý dữ liệu đúng quy định.
> - Khuyến khích xây dựng, khai thác và sử dụng học liệu số, hình ảnh, video và các sản phẩm giáo dục điện tử phù hợp với đặc điểm phát triển của trẻ mầm non, góp phần nâng cao chất lượng tổ chức hoạt động giáo dục.
> - Từng bước thực hiện số hóa, sắp xếp và lưu trữ hồ sơ, tài liệu, sản phẩm truyền thông và minh chứng hoạt động theo hướng khoa học, thuận tiện cho việc khai thác, sử dụng.
> - Tăng cường ứng dụng công nghệ số trong trao đổi thông tin, phối hợp giữa nhà trường, giáo viên và cha mẹ trẻ.
> - Thực hiện các biện pháp bảo đảm an toàn thông tin, bảo vệ dữ liệu cá nhân, đặc biệt là thông tin và hình ảnh của trẻ; sử dụng, chia sẻ dữ liệu đúng mục đích, đúng thẩm quyền và theo quy định hiện hành.
>
> 3. **Về kiểm tra, đánh giá và báo cáo**
>
> - Theo dõi, kiểm tra, đôn đốc việc thực hiện nhiệm vụ truyền thông và chuyển đổi số của các tổ, bộ phận và cá nhân được phân công.
> - Kịp thời phát hiện khó khăn, hạn chế; tham mưu giải pháp khắc phục, nâng cao hiệu quả thực hiện.
> - Tổ chức đánh giá kết quả thực hiện theo từng học kỳ và cuối năm học; tổng hợp hồ sơ, minh chứng, báo cáo theo yêu cầu của Hiệu trưởng và cơ quan quản lý cấp trên.
>
> **Điều 3. Tổ chức hoạt động**
>
> 1. Ban Chỉ đạo làm việc theo chế độ kiêm nhiệm. Trưởng ban chịu trách nhiệm chỉ đạo chung; các Phó Trưởng ban và Ủy viên thực hiện nhiệm vụ theo phân công, bảo đảm phối hợp chặt chẽ, thống nhất trong quá trình triển khai.
>
> 2. Các thành viên chủ động lồng ghép nhiệm vụ truyền thông và chuyển đổi số vào hoạt động chuyên môn, nhiệm vụ quản lý và công việc được giao; chịu trách nhiệm về chất lượng, tiến độ và kết quả thực hiện trong phạm vi phụ trách.
>
> 3. Ban Chỉ đạo tổ chức họp triển khai nhiệm vụ đầu năm học, sơ kết học kỳ I, tổng kết cuối năm học và họp đột xuất khi cần thiết theo yêu cầu của Trưởng ban.
>
> 4. Thời gian hoạt động của Ban Chỉ đạo bắt đầu từ ngày Quyết định có hiệu lực đến khi hoàn thành việc tổng kết công tác truyền thông và chuyển đổi số năm học 2026–2027.
>
> **Điều 4.** Quyết định này có hiệu lực kể từ ngày ký. Các Phó Hiệu trưởng, tổ Văn phòng, các tổ Chuyên môn và các ông (bà) có tên tại Điều 1 chịu trách nhiệm thi hành Quyết định này./.
>
> | **Nơi nhận:** | **HIỆU TRƯỞNG** |
> |---|:---:|
> | - Như Điều 4; | |
> | - Lưu: VT, (Duyên). | **Huỳnh Hồng Loan** |
>
> ---
>
> # DANH SÁCH VÀ PHÂN CÔNG NHIỆM VỤ BAN CHỈ ĐẠO CÔNG TÁC TRUYỀN THÔNG VÀ CHUYỂN ĐỔI SỐ NĂM HỌC 2026–2027
>
> *(Ban hành kèm theo Quyết định số 75/QĐ-MNAB ngày 01 tháng 10 năm 2026 của Hiệu trưởng Trường Mầm non An Bình)*
>
> | TT | Họ và tên | Chức vụ | Nhiệm vụ trong Ban | Phần việc phụ trách |
> |---|---|---|---|---|
> | 1 | **Huỳnh Hồng Loan** | Hiệu trưởng | Trưởng ban | **Truyền thông:** Chỉ đạo chung toàn bộ hoạt động; phê duyệt nội dung truyền thông theo thẩm quyền; kiểm tra, đánh giá kết quả và chỉ đạo giải quyết các vấn đề phát sinh. **Chuyển đổi số:** Chỉ đạo xây dựng và triển khai nhiệm vụ chuyển đổi số; định hướng ứng dụng công nghệ số trong quản lý, điều hành và hoạt động giáo dục; kiểm tra, đánh giá hiệu quả thực hiện và quyết định các giải pháp nâng cao chất lượng chuyển đổi số của nhà trường. |
> | 2 | **Nguyễn Thị Huỳnh Duyên** | Phó Hiệu trưởng | Phó Trưởng ban | **Truyền thông:** Tham mưu triển khai kế hoạch; điều phối, đôn đốc tiến độ; tổng hợp, kiểm tra chất lượng tin, bài, hình ảnh, video. Duyệt nội dung trên website, kênh YouTube, trang Facebook của trường trong phạm vi được Trưởng ban phân công; trình Trưởng ban những nội dung vượt thẩm quyền; tổng hợp, báo cáo kết quả thực hiện. **Chuyển đổi số:** Tham mưu và điều phối chung việc triển khai nhiệm vụ chuyển đổi số; theo dõi ứng dụng công nghệ thông tin trong hoạt động chuyên môn, quản lý hồ sơ, dữ liệu và xây dựng học liệu số; hướng dẫn, đôn đốc các tổ, bộ phận thực hiện; tổng hợp kết quả, khó khăn và đề xuất giải pháp. |
> | 3 | **Nguyễn Thị Ngọc Phượng** | Phó Hiệu trưởng | Phó Trưởng ban | **Truyền thông:** Chỉ đạo công tác truyền thông tại điểm An Bình; kiểm tra, duyệt nội dung và chịu trách nhiệm về tính chính xác, phù hợp, chất lượng của tin, bài, hình ảnh, video trước khi chuyển bộ phận phụ trách chung để đăng tải; bảo đảm số lượng và tiến độ theo kế hoạch. **Chuyển đổi số:** Chỉ đạo, kiểm tra việc ứng dụng công nghệ thông tin và các công cụ số trong hoạt động chăm sóc, nuôi dưỡng, giáo dục tại điểm trường phụ trách; đôn đốc cập nhật dữ liệu, thực hiện hồ sơ điện tử và khai thác học liệu số theo quy định; theo dõi kết quả thực hiện và báo cáo theo yêu cầu. |
> | 4 | **Hồ Thanh Trúc** | Phó Hiệu trưởng | Phó Trưởng ban | **Truyền thông:** Chỉ đạo công tác truyền thông tại điểm An Lộc; kiểm tra, duyệt nội dung và chịu trách nhiệm về tính chính xác, phù hợp, chất lượng của tin, bài, hình ảnh, video trước khi chuyển bộ phận phụ trách chung để đăng tải; bảo đảm số lượng và tiến độ theo kế hoạch. **Chuyển đổi số:** Chỉ đạo triển khai ứng dụng công nghệ thông tin trong công tác quản lý, chăm sóc, nuôi dưỡng và giáo dục trẻ tại điểm An Lộc; theo dõi việc cập nhật dữ liệu, sử dụng học liệu số, lưu trữ hồ sơ và minh chứng điện tử; kịp thời hỗ trợ, đề xuất giải pháp khắc phục khó khăn trong quá trình thực hiện. |
> | 5 | **Nguyễn Thị Ngọc Phí** | Tổ trưởng chuyên môn | Ủy viên | **Truyền thông:** Triển khai nhiệm vụ trong tổ phụ trách; lựa chọn hoạt động tiêu biểu, kiểm tra và gửi tin, bài, hình ảnh; theo dõi nội dung tuyên truyền tại các lớp thuộc tổ 25–36 tháng. **Chuyển đổi số:** Hướng dẫn giáo viên trong tổ ứng dụng công nghệ thông tin phù hợp trong xây dựng kế hoạch, quản lý hồ sơ, lưu trữ tư liệu và thiết kế học liệu điện tử; lựa chọn, chia sẻ các hình ảnh, video, học liệu số phù hợp với trẻ 25–36 tháng; đôn đốc cập nhật thông tin, dữ liệu theo yêu cầu. |
> | 6 | **Nguyễn Thị Nhàn** | Tổ trưởng chuyên môn | Ủy viên | **Truyền thông:** Triển khai nhiệm vụ trong tổ; lựa chọn hoạt động tiêu biểu, kiểm tra và gửi tin, bài, hình ảnh; hướng dẫn giáo viên thực hiện nội dung truyền thông theo kế hoạch; tổng hợp tư liệu và phản hồi của cha mẹ trẻ tại các lớp thuộc tổ Mầm. **Chuyển đổi số:** Hướng dẫn giáo viên trong tổ ứng dụng công nghệ số trong xây dựng kế hoạch, tổ chức hoạt động giáo dục và quản lý hồ sơ; khuyến khích thiết kế, khai thác học liệu số phù hợp với trẻ; tổng hợp và lưu trữ minh chứng điện tử, chia sẻ kinh nghiệm ứng dụng công nghệ trong tổ. |
> | 7 | **Cao Thị Ngọc Nga** | Tổ trưởng chuyên môn | Ủy viên | **Truyền thông:** Triển khai nhiệm vụ trong tổ phụ trách; lựa chọn hoạt động tiêu biểu, kiểm tra và gửi tin, bài, hình ảnh; theo dõi việc cập nhật nội dung tuyên truyền tại các lớp; cung cấp tin, bài về hoạt động chăm sóc, giáo dục và phối hợp với gia đình. **Chuyển đổi số:** Đôn đốc giáo viên sử dụng công cụ số trong hoạt động chuyên môn, xây dựng tư liệu và học liệu điện tử; kiểm tra việc cập nhật, lưu trữ hồ sơ và minh chứng số; hướng dẫn khai thác công nghệ số trong phối hợp, trao đổi thông tin với cha mẹ trẻ. |
> | 8 | **Trần Thị Huỳnh Như** | Tổ trưởng chuyên môn | Ủy viên | **Truyền thông:** Tổ chức thực hiện các nội dung truyền thông trong tổ; lựa chọn hoạt động tiêu biểu, kiểm tra và gửi tin, bài, hình ảnh; giới thiệu các cách làm hiệu quả, tổng hợp kết quả thực hiện và báo cáo theo yêu cầu. **Chuyển đổi số:** Hướng dẫn, khuyến khích giáo viên trong tổ ứng dụng công nghệ số vào hoạt động giáo dục; khai thác, xây dựng và chia sẻ học liệu điện tử; theo dõi chất lượng hồ sơ, tư liệu và minh chứng số; lựa chọn các sản phẩm, cách làm hiệu quả để chia sẻ, nhân rộng trong tổ chuyên môn. |
> | 9 | **Bùi Huỳnh Ngọc Tân** | Tổ trưởng Văn phòng | Ủy viên | **Truyền thông:** Phối hợp với cô Nguyễn Huỳnh Kim Khánh ghi hình, cắt, ghép, biên tập video và phóng sự về các hoạt động của nhà trường. Phụ trách xử lý hình ảnh, lựa chọn, chỉnh sửa bố cục, ánh sáng, màu sắc, bảo đảm hình ảnh rõ nét, chân thực; cung cấp tư liệu cho tin, bài và các sản phẩm truyền thông; trình duyệt sản phẩm trước khi sử dụng. **Chuyển đổi số:** Phối hợp hỗ trợ kỹ thuật đối với các công cụ, thiết bị và sản phẩm số phục vụ truyền thông; tham gia sắp xếp, số hóa, lưu trữ và sao lưu kho tư liệu hình ảnh, video của nhà trường; hỗ trợ các bộ phận khai thác, sử dụng công cụ số trong phạm vi nhiệm vụ được giao; chú trọng bảo đảm an toàn dữ liệu. |
> | 10 | **Nguyễn Huỳnh Kim Khánh** | Giáo viên | Ủy viên | **Truyền thông:** Phối hợp với Bùi Huỳnh Ngọc Tân xây dựng video, phóng sự về hoạt động của nhà trường; thực hiện cắt, ghép, biên tập video, bổ sung âm thanh và phụ đề phù hợp; trực tiếp thực hiện các sản phẩm truyền thông bằng video tại điểm An Bình A; trình duyệt sản phẩm trước khi đăng tải. **Chuyển đổi số:** Khai thác các công cụ, phần mềm phù hợp để thiết kế video, sản phẩm truyền thông và tư liệu giáo dục số; phối hợp hỗ trợ giáo viên thực hiện các sản phẩm hình ảnh, video phục vụ hoạt động chuyên môn; sắp xếp, lưu trữ sản phẩm số theo hướng dẫn của bộ phận phụ trách. |
> | 11 | **Nguyễn Thị Thanh Nhãn** | Giáo viên | Ủy viên | **Truyền thông:** Làm đầu mối thu thập thông tin, hình ảnh về các hoạt động tại điểm An Bình; viết tin, bài; phối hợp với Nguyễn Huỳnh Kim Khánh và Bùi Huỳnh Ngọc Tân ghi hình, xây dựng video, phóng sự; gửi sản phẩm cho Phó Hiệu trưởng phụ trách kiểm tra, duyệt nội dung; bảo đảm chất lượng, số lượng và tiến độ theo kế hoạch. **Chuyển đổi số:** Phối hợp thu thập, sắp xếp và lưu trữ tư liệu điện tử tại điểm trường; ứng dụng công nghệ số để biên soạn nội dung, cung cấp minh chứng hoạt động; hỗ trợ chia sẻ thông tin, học liệu số và thực hiện các nhiệm vụ chuyển đổi số theo phân công. |
> | 12 | **Nguyễn Thị Bích Quyền** | Giáo viên | Ủy viên | **Truyền thông:** Làm đầu mối thu thập thông tin, hình ảnh về các hoạt động tại điểm An Lộc; viết tin, bài; phối hợp với Nguyễn Huỳnh Kim Khánh và Bùi Huỳnh Ngọc Tân ghi hình, xây dựng video, phóng sự; gửi sản phẩm cho Phó Hiệu trưởng phụ trách kiểm tra, duyệt nội dung; bảo đảm chất lượng, số lượng và tiến độ theo kế hoạch. **Chuyển đổi số:** Phối hợp thu thập, quản lý và lưu trữ tư liệu điện tử tại điểm An Lộc; ứng dụng công cụ số để xây dựng nội dung truyền thông, cung cấp minh chứng hoạt động; hỗ trợ giáo viên chia sẻ tư liệu, học liệu số và thực hiện các nhiệm vụ chuyển đổi số được phân công. |
> | 13 | **Trần Kim Chi** | Nhân viên văn thư | Ủy viên | **Truyền thông:** Phối hợp chuẩn bị các điều kiện phục vụ công tác truyền thông; tập hợp, lưu trữ hồ sơ, tin, bài, hình ảnh và minh chứng thực hiện. **Chuyển đổi số:** Thực hiện số hóa, quản lý và lưu trữ văn bản, hồ sơ, tài liệu điện tử thuộc phạm vi công việc; phối hợp cập nhật, sắp xếp hồ sơ và minh chứng số của Ban Chỉ đạo; bảo đảm việc lưu trữ, khai thác, chia sẻ văn bản, dữ liệu đúng quy định; hỗ trợ tổng hợp tài liệu phục vụ kiểm tra và báo cáo. |
>
> **Danh sách này có 13 (mười ba) thành viên.**
>
> **Yêu cầu chung đối với các thành viên Ban Chỉ đạo:** Chủ động thực hiện nhiệm vụ được phân công; phối hợp, chia sẻ thông tin và hỗ trợ lẫn nhau trong quá trình triển khai. Các nội dung truyền thông phải được kiểm tra, phê duyệt trước khi đăng tải theo phân cấp. Việc ứng dụng công nghệ số phải thiết thực, phù hợp điều kiện nhà trường; bảo đảm an toàn thông tin, bảo vệ dữ liệu cá nhân và quyền riêng tư của trẻ em theo quy định.

## ⚠️ Lưu ý trước khi ban hành

Có hai điểm cần kiểm tra:

**1. Số và ngày quyết định.** Tôi đang giữ nguyên số **75/QĐ-MNAB, ngày 01/10/2026** để cô dễ đối chiếu bản gốc. Nếu quyết định này đã được ký, phát hành thì cần sử dụng số và ngày mới; đồng thời bổ sung vào Điều 4 nội dung thay thế Quyết định số 75/QĐ-MNAB. Không nên sửa trực tiếp quyết định đã ban hành.

**2. Căn cứ pháp lý.** Tôi đã bổ sung quy định hiện hành về Điều lệ trường mầm non, trong đó Thông tư 51/2026/TT-BGDĐT có hiệu lực từ ngày 15/8/2026, và Quyết định 131/QĐ-TTg về chuyển đổi số giáo dục đến năm 2030. [Thông tư số 51/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Sửa đổi, bổ sung một số điều của Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy chế tố chức, hoạt động nhóm trẻ độc lập, lớp mẫu giáo độc lập, lớp mầm non độc lập loại hình dân lập và tư thục ban hành kèm theo Thông tư số 49/2021/TT\-BGDĐT ngày 31 tháng 12 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy định tiêu chuẩn, quy trình biên soạn, chỉnh sửa Chương trình giáo dục mầm non, tổ chức và hoạt động của Hội đồng quốc gia thẩm định chương trình giáo dục mầm non ban hành kèm theo Thông tư số 49/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo](<https://chinhphu.vn/?docid=218796&pageid=27160>); [Quyết định số 131/QĐ\-TTg của Thủ tướng Chính phủ: Phê duyệt Đề án "Tăng cường ứng dụng công nghệ thông tin và chuyển đổi số trong giáo dục và đào tạo giai đoạn 2022 \- 2025, định hướng đến năm 2030"](<https://vanban.chinhphu.vn/default.aspx?docid=205236&pageid=27160>) Khi triển khai, nhà trường cũng cần chú ý Luật Bảo vệ dữ liệu cá nhân số 91/2025/QH15, có hiệu lực từ ngày 01/01/2026, nhất là việc sử dụng thông tin, hình ảnh trẻ trên các kênh truyền thông. [Luật số 91/2025/QH15 của Quốc hội: Luật Bảo vệ dữ liệu cá nhân](<https://chinhphu.vn/?classid=1&docid=214590&pageid=27160&typegroupid=3>); [Từ hôm nay, Luật Bảo vệ dữ liệu cá nhân chính thức có hiệu lực thi hành](<https://www.bocongan.gov.vn/bai-viet/luat-bao-ve-du-lieu-ca-nhan-chinh-thuc-co-hieu-luc-thi-hanh-tu-ngay-01-01-2026-1767186124>)

**Về chuyên môn quản lý:** Tôi đề xuất giữ mô hình một Ban Chỉ đạo chung như bản trên. Mỗi thành viên thực hiện hai nhóm nhiệm vụ nhưng vẫn gắn với địa bàn, tổ chuyên môn và phần việc đã phụ trách. Cách này tránh chồng chéo, không làm tăng đầu mối quản lý và giúp nhà trường có cơ sở kiểm tra, đánh giá đồng thời cả công tác truyền thông và chuyển đổi số trong năm học 2026–2027.

---

USER

Cô Duyên phụ trách chính mảng truyền thông toàn trường, cô Trúc phụ trách chính mảng chuyển đổi số toàn trường. bạn giúp tôi viết lại phần việc phụ trách nhé

---

ASSISTANT

Để phân định rõ trách nhiệm giữa hai Phó Hiệu trưởng, tôi đề xuất điều chỉnh phần việc phụ trách theo hướng: **Cô Nguyễn Thị Huỳnh Duyên là đầu mối chỉ đạo, điều phối công tác truyền thông toàn trường; cô Hồ Thanh Trúc là đầu mối chỉ đạo, điều phối công tác chuyển đổi số toàn trường.** Hai đồng chí phối hợp thực hiện những nhiệm vụ có liên quan, tránh chồng chéo trách nhiệm.

Dưới đây là nội dung có thể đưa trực tiếp vào cột **“Phần việc phụ trách”** trong danh sách Ban Chỉ đạo.

> **writing · document**
>
> ### 2. Nguyễn Thị Huỳnh Duyên – Phó Hiệu trưởng – Phó Trưởng ban
>
> **Phụ trách chính công tác truyền thông toàn trường.** Tham mưu Trưởng ban xây dựng, triển khai và tổ chức thực hiện kế hoạch truyền thông năm học; trực tiếp điều phối, hướng dẫn, đôn đốc công tác truyền thông tại các điểm trường, tổ chuyên môn và các bộ phận. Chỉ đạo xây dựng, thu thập, biên tập và kiểm tra chất lượng tin, bài, hình ảnh, video, phóng sự; bảo đảm nội dung chính xác, phù hợp, kịp thời và đúng định hướng. Kiểm duyệt nội dung trước khi đăng tải trên website, kênh YouTube, trang Facebook và các kênh thông tin chính thức của nhà trường theo phạm vi được Trưởng ban phân công; trình Trưởng ban phê duyệt những nội dung vượt thẩm quyền. Theo dõi tiến độ, kiểm tra, đánh giá hiệu quả truyền thông; tổng hợp kết quả, tham mưu giải pháp nâng cao chất lượng và thực hiện báo cáo theo quy định. Phối hợp với bộ phận phụ trách chuyển đổi số trong việc khai thác, sử dụng các nền tảng và công cụ số phục vụ công tác truyền thông.
>
> ### 4. Hồ Thanh Trúc – Phó Hiệu trưởng – Phó Trưởng ban
>
> **Phụ trách chính công tác chuyển đổi số toàn trường.** Tham mưu Trưởng ban xây dựng, triển khai và tổ chức thực hiện kế hoạch chuyển đổi số; trực tiếp chỉ đạo, hướng dẫn, đôn đốc các điểm trường, tổ chuyên môn và các bộ phận ứng dụng công nghệ thông tin, chuyển đổi số trong hoạt động quản lý, điều hành, chăm sóc, nuôi dưỡng và giáo dục trẻ. Chỉ đạo, theo dõi việc sử dụng các phần mềm quản lý, cập nhật dữ liệu, thực hiện hồ sơ điện tử, số hóa tài liệu và khai thác học liệu số; hướng dẫn cán bộ, giáo viên, nhân viên sử dụng hiệu quả các nền tảng, công cụ số phù hợp với nhiệm vụ được giao. Phối hợp triển khai các biện pháp bảo đảm an toàn thông tin, bảo vệ dữ liệu cá nhân và quản lý, khai thác dữ liệu đúng quy định. Kiểm tra, đánh giá kết quả thực hiện chuyển đổi số tại các tổ, bộ phận; kịp thời tham mưu giải pháp khắc phục khó khăn, nâng cao hiệu quả ứng dụng công nghệ số; tổng hợp, báo cáo kết quả thực hiện theo quy định. Phối hợp với bộ phận phụ trách truyền thông trong việc ứng dụng nền tảng số, quản lý và lưu trữ sản phẩm truyền thông của nhà trường.

### 💡 Đề xuất thêm về phân công quản lý

Để Quyết định thể hiện rõ cơ chế điều hành, tôi đề xuất bổ sung vào **Điều 3. Tổ chức hoạt động** nội dung:

> Phân công bà Nguyễn Thị Huỳnh Duyên – Phó Trưởng ban trực tiếp phụ trách, điều phối công tác truyền thông toàn trường; bà Hồ Thanh Trúc – Phó Trưởng ban trực tiếp phụ trách, điều phối công tác chuyển đổi số toàn trường. Các Phó Trưởng ban chịu trách nhiệm tham mưu, tổ chức triển khai, kiểm tra, đôn đốc và báo cáo kết quả thực hiện trong lĩnh vực được phân công; đồng thời phối hợp chặt chẽ để bảo đảm tính thống nhất, hiệu quả trong hoạt động của Ban Chỉ đạo.

**Một điểm cần lưu ý:** Trong quyết định cũ, cô Trúc phụ trách truyền thông tại điểm An Lộc. Khi chuyển sang phụ trách chính chuyển đổi số toàn trường, nên giao cô Nguyễn Thị Bích Quyền tiếp tục làm đầu mối cung cấp tin, bài tại điểm An Lộc, dưới sự điều phối chung của cô Duyên. Cô Trúc vẫn có thể phối hợp hỗ trợ tại điểm trường nhưng không cần đảm nhiệm vai trò chỉ đạo truyền thông riêng, nhằm tránh chồng chéo trong phân công.

Như vậy, nhà trường vẫn giữ nguyên 13 thành viên nhưng có sự phân công **rõ người phụ trách chính, rõ phạm vi trách nhiệm và rõ đầu mối báo cáo** đối với từng lĩnh vực.

---

