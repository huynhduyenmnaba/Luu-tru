USER

[@Chuyên gia Giáo dục mầm non](plugin://gpt-10d60647f7dfc69465055636721f7c6c@openai-curated-remote) với vai trò hiệu trưởng bạn giúp tôi hoàn thành quyết định trong ảnh. bổ sung dùm mình thời gian làm việc. phần ghi chú có thể điền phần việc để các thành viên nắm và thực hiện

---

ASSISTANT

Tôi sẽ dùng hướng dẫn của Chuyên gia Giáo dục mầm non để hoàn thiện quyết định theo ảnh, bổ sung thời gian làm việc và phần việc cụ thể cho từng thành viên.

---

ASSISTANT

Tôi đã chỉnh thống nhất tên **Trường Mầm non An Bình A**, năm học **2026–2027** và bổ sung thời gian hoạt động của Ban chỉ đạo. Cột “Ghi chú” có thể đổi thành **“Phần việc được phân công”** để các thành viên dễ theo dõi, thực hiện.

Phần căn cứ nên sử dụng Điều lệ trường mầm non và kế hoạch truyền thông của trường; căn cứ về các khoản thu trong ảnh chưa phù hợp trực tiếp với nội dung quyết định này. Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020 là văn bản ban hành Điều lệ trường mầm non. https://vbpl.vn/bogiaoducdaotao/Pages/vbpq-thuoctinh.aspx?ItemID=147475
https://vbpl.vn/bogiaoducdaotao/Pages/vbpq-thuoctinh.aspx?ItemID=147475&utm_source=chatgpt.com

Dưới đây là bản đề xuất hoàn chỉnh. Phần phân công giữa các Phó Hiệu trưởng cần thống nhất với lĩnh vực thực tế đang phụ trách.

---

**UBND PHƯỜNG AN BÌNH**  
**TRƯỜNG MẦM NON AN BÌNH A**  
Số: 77/QĐ-MNABA

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
**Độc lập – Tự do – Hạnh phúc**

*An Bình, ngày 01 tháng 10 năm 2026*

**QUYẾT ĐỊNH**  
**Về việc thành lập Ban chỉ đạo công tác truyền thông  
năm học 2026–2027**

**HIỆU TRƯỞNG TRƯỜNG MẦM NON AN BÌNH A**

*Căn cứ Thông tư số 52/2020/TT-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Điều lệ trường mầm non;*

*Căn cứ Kế hoạch số 200/KH-MNABA ngày 30 tháng 9 năm 2026 của Trường Mầm non An Bình A về thực hiện công tác truyền thông năm học 2026–2027;*

*Theo đề nghị của Phó Hiệu trưởng phụ trách chuyên môn.*

**QUYẾT ĐỊNH:**

**Điều 1.** Thành lập Ban chỉ đạo công tác truyền thông năm học 2026–2027 của Trường Mầm non An Bình A gồm 11 thành viên có tên trong danh sách kèm theo Quyết định này.

**Điều 2.** Ban chỉ đạo có nhiệm vụ:

1. Tổ chức triển khai Kế hoạch công tác truyền thông năm học 2026–2027 của nhà trường; phân công nhiệm vụ, hướng dẫn các tổ chuyên môn, tổ văn phòng và các nhóm, lớp thực hiện phù hợp với điều kiện thực tế.

2. Chỉ đạo xây dựng, kiểm tra và phê duyệt nội dung truyền thông về hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ; các hoạt động, ngày lễ, hội và nội dung phối hợp giữa nhà trường, gia đình, cộng đồng theo kế hoạch. Bảo đảm thông tin chính xác, dễ hiểu, thiết thực và phù hợp với đối tượng tiếp nhận.

3. Tổ chức truyền thông thông qua các kênh của nhà trường, bảng tuyên truyền, các cuộc họp cha mẹ trẻ và hoạt động trao đổi tại nhóm, lớp; tiếp nhận ý kiến phản hồi, kịp thời báo cáo và tham mưu giải quyết những vấn đề thuộc phạm vi phụ trách.

4. Theo dõi, kiểm tra tiến độ thực hiện; tổng hợp kết quả, lưu trữ tư liệu và đánh giá công tác truyền thông của nhà trường.

**Thời gian làm việc:** Ban chỉ đạo làm việc theo chế độ kiêm nhiệm, bắt đầu từ ngày Quyết định có hiệu lực đến khi hoàn thành việc tổng kết công tác truyền thông năm học 2026–2027. Các thành viên thực hiện nhiệm vụ thường xuyên theo kế hoạch tháng và nhiệm vụ được phân công. Ban chỉ đạo họp triển khai nhiệm vụ đầu năm học, sơ kết học kỳ I, tổng kết cuối năm học và họp đột xuất khi Trưởng ban yêu cầu.

**Điều 3.** Quyết định này có hiệu lực kể từ ngày ký.

Các tổ chuyên môn, tổ văn phòng, các bộ phận có liên quan và các ông, bà có tên tại Điều 1 chịu trách nhiệm thi hành Quyết định này./.

**Nơi nhận:**

- Như Điều 3;
- Lưu: VT.

**HIỆU TRƯỞNG**

**Huỳnh Hồng Loan**

---

**DANH SÁCH BAN CHỈ ĐẠO CÔNG TÁC TRUYỀN THÔNG  
NĂM HỌC 2026–2027**

*(Kèm theo Quyết định số 77/QĐ-MNABA ngày 01 tháng 10 năm 2026 của Hiệu trưởng Trường Mầm non An Bình A)*

| TT | Họ và tên | Chức vụ | Nhiệm vụ trong Ban | Phần việc được phân công |
|---|---|---|---|---|
| 1 | Huỳnh Hồng Loan | Hiệu trưởng | Trưởng ban | Chỉ đạo chung; phê duyệt nội dung truyền thông; kiểm tra, đánh giá kết quả và chỉ đạo giải quyết các vấn đề phát sinh. |
| 2 | Nguyễn Thị Huỳnh Duyên | Phó Hiệu trưởng | Phó Trưởng ban | Tham mưu triển khai kế hoạch; điều phối tiến độ; tổng hợp tin, bài, kiểm tra nội dung trước khi trình Trưởng ban; tổng hợp báo cáo kết quả. |
| 3 | Hồ Thanh Trúc | Phó Hiệu trưởng | Phó Trưởng ban | Phụ trách nội dung truyền thông về hoạt động giáo dục trẻ, chuyên đề, ngày lễ, hội; hướng dẫn các tổ chuyên môn cung cấp tin, bài và hình ảnh. |
| 4 | Nguyễn Thị Ngọc Phượng | Phó Hiệu trưởng | Phó Trưởng ban | Phụ trách nội dung truyền thông về nuôi dưỡng, chăm sóc, sức khỏe, vệ sinh và an toàn cho trẻ; hướng dẫn nội dung phối hợp với cha mẹ trẻ. |
| 5 | Phạm Minh Quang | Tổ trưởng văn phòng | Ủy viên | Phối hợp chuẩn bị điều kiện phục vụ truyền thông; tập hợp, lưu trữ hồ sơ, tin, bài, hình ảnh và minh chứng thực hiện. |
| 6 | Nguyễn Thị Ngọc Phi | Tổ trưởng chuyên môn | Ủy viên | Triển khai nhiệm vụ trong tổ phụ trách; lựa chọn hoạt động tiêu biểu, kiểm tra và gửi tin, bài, hình ảnh; theo dõi bảng tuyên truyền của các lớp trong tổ. |
| 7 | Nguyễn Thị Nhàn | Tổ trưởng chuyên môn | Ủy viên | Hướng dẫn giáo viên trong tổ thực hiện nội dung truyền thông theo kế hoạch; tổng hợp tư liệu và phản hồi của cha mẹ trẻ tại các lớp thuộc tổ. |
| 8 | Cao Thị Ngọc Nga | Tổ trưởng chuyên môn | Ủy viên | Theo dõi việc cập nhật nội dung tuyên truyền tại các lớp trong tổ; cung cấp tin, bài về hoạt động chăm sóc, giáo dục và phối hợp với gia đình. |
| 9 | Trần Thị Huỳnh Như | Tổ trưởng chuyên môn | Ủy viên | Tổ chức thực hiện các nội dung truyền thông trong tổ; lựa chọn cách làm hiệu quả để giới thiệu; tổng hợp kết quả thực hiện và báo cáo theo yêu cầu. |
| 10 | Nguyễn Huỳnh Kim Khánh | Giáo viên | Ủy viên | Phối hợp viết tin, bài, lựa chọn hình ảnh, thiết kế nội dung tuyên truyền; hỗ trợ cập nhật các kênh truyền thông sau khi nội dung được phê duyệt. |
| 11 | Bùi Huỳnh Ngọc Tân | Nhân viên | Ủy viên | Hỗ trợ chuẩn bị phương tiện, ghi hình, chụp ảnh các hoạt động theo phân công; chuyển tư liệu cho bộ phận tổng hợp và phối hợp lưu trữ. |

*Danh sách gồm 11 (mười một) thành viên.*

**Lưu ý về thời gian:** Dòng “8 giờ 00 ngày 07/04/2026 đến khi hoàn thành nhiệm vụ” trong ảnh chưa thống nhất với ngày ký và phạm vi hoạt động cả năm học. Với Ban chỉ đạo truyền thông, nên dùng thời gian hoạt động tại Điều 2 như trên; giờ làm việc cụ thể của từng hoạt động được bố trí trong kế hoạch triển khai.

---

USER

Khánh và tân giỏi công nghệ cắt ghép edit video bạn giúp tôi mô tả phần việc của 2 bạn  (phối hợp làm video, phóng sự cho trường; riêng Khánh làm thêm cho điểm An Bình A. Tân giỏi xử lý ảnh

---

ASSISTANT

Bạn có thể thay phần việc của **Khánh và Tân** trong bảng phân công như sau:

| Họ và tên | Phần việc được phân công |
|---|---|
| **Nguyễn Huỳnh Kim Khánh** | Phối hợp với ông Bùi Huỳnh Ngọc Tân xây dựng video, phóng sự về các hoạt động của nhà trường; thực hiện cắt, ghép, biên tập video, bổ sung âm thanh và phụ đề phù hợp với nội dung truyền thông. Trực tiếp thực hiện các sản phẩm truyền thông bằng video tại điểm An Bình A; trình duyệt sản phẩm trước khi đăng tải. |
| **Bùi Huỳnh Ngọc Tân** | Phối hợp với bà Nguyễn Huỳnh Kim Khánh ghi hình, cắt, ghép, biên tập video và phóng sự về các hoạt động của nhà trường. Phụ trách xử lý hình ảnh: lựa chọn, cắt chỉnh bố cục, điều chỉnh ánh sáng, màu sắc, bảo đảm hình ảnh rõ nét, chân thực; cung cấp tư liệu cho tin, bài và các sản phẩm truyền thông; trình duyệt sản phẩm trước khi sử dụng. |

---

USER

|     |
| ------------------ |

    Duyên (phụ trách chinh1m Tham mưu triển khai kế hoạch; điều phối tiến độ; tổng hợp tin, bài,   kiểm tra nội dung trước khi trình Trưởng ban; tổng hợp báo cáo kết quả. Tin   bài, hình ảnh, vedeo đảm bảo chất và lượng. duyệt tin bài web, video youtube, face book, trường

---

ASSISTANT

**Nguyễn Thị Huỳnh Duyên – Phó Trưởng ban, phụ trách chính:** Tham mưu triển khai kế hoạch; điều phối, đôn đốc tiến độ thực hiện; tổng hợp, kiểm tra tin, bài, hình ảnh và video, bảo đảm chất lượng, số lượng theo kế hoạch. Duyệt nội dung trong phạm vi được Trưởng ban phân công trước khi đăng tải trên website, kênh YouTube và trang Facebook của trường; trình Trưởng ban những nội dung vượt thẩm quyền; tổng hợp, báo cáo kết quả thực hiện.

---

USER

cô Phượng, Trúc phụ trách 2 điểm nên bổ sung nội dung duyệt nội dung và chịu trách nhiệm về, tin , bài, viedo  điểm mình phụ trách

---

ASSISTANT

Bạn bổ sung phần việc của cô Trúc và cô Phượng như sau:

| Họ và tên | Phần việc được phân công |
|---|---|
| **Hồ Thanh Trúc** | Chỉ đạo thực hiện công tác truyền thông tại điểm trường được phân công phụ trách; kiểm tra, duyệt nội dung và chịu trách nhiệm về tính chính xác, phù hợp, chất lượng của tin, bài, hình ảnh, video thuộc điểm trường trước khi chuyển bộ phận phụ trách chung để đăng tải; bảo đảm số lượng và tiến độ theo kế hoạch. |
| **Nguyễn Thị Ngọc Phượng** | Chỉ đạo thực hiện công tác truyền thông tại điểm trường được phân công phụ trách; kiểm tra, duyệt nội dung và chịu trách nhiệm về tính chính xác, phù hợp, chất lượng của tin, bài, hình ảnh, video thuộc điểm trường trước khi chuyển bộ phận phụ trách chung để đăng tải; bảo đảm số lượng và tiến độ theo kế hoạch. |

---

USER

sếp yêu cầu thêm 2 giáo viên nữa của điểm An Bình và An Lộc vào quyết định. bạn giúp tôi phân công nhiệm vụ cho 2 gv này nhé

---

ASSISTANT

Bạn có thể bổ sung nhiệm vụ cho **02 giáo viên – Ủy viên Ban chỉ đạo** như sau:

| Thành viên | Phần việc được phân công |
|---|---|
| **Giáo viên điểm An Bình** | Làm đầu mối thu thập thông tin, hình ảnh về các hoạt động tại điểm An Bình; viết tin, bài; phối hợp với cô Khánh và ông Tân ghi hình, xây dựng video, phóng sự. Gửi sản phẩm cho Phó Hiệu trưởng phụ trách kiểm tra, duyệt nội dung; bảo đảm chất lượng, số lượng và tiến độ theo kế hoạch. |
| **Giáo viên điểm An Lộc** | Làm đầu mối thu thập thông tin, hình ảnh về các hoạt động tại điểm An Lộc; viết tin, bài; phối hợp với cô Khánh và ông Tân ghi hình, xây dựng video, phóng sự. Gửi sản phẩm cho Phó Hiệu trưởng phụ trách kiểm tra, duyệt nội dung; bảo đảm chất lượng, số lượng và tiến độ theo kế hoạch. |

Đồng thời, điều chỉnh số lượng thành viên tại **Điều 1** và cuối danh sách từ **11 thành viên** thành **13 thành viên**.

---

