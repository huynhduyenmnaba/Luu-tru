USER

[@Hiệu trưởng xử lý tình huống hội nghị](plugin://hieu-truong-hoi-nghi@openai-curated-remote) Dựa vào quy chế đính kèm, giúp tôi giải đáp ý kiến này tại hội nghị, ngắn gọn và có căn cứ.

---

ASSISTANT

Tôi sẽ dùng kỹ năng Hiệu trưởng xử lý tình huống hội nghị để đối chiếu ý kiến với các quy chế cô gửi.

---

ASSISTANT

Cô gửi giúp tôi **nội dung ý kiến cần giải đáp**, hoặc cho biết **phần và số câu trong “Bản tổng hợp ý kiến”** nhé. Tệp có nhiều ý kiến nên tôi cần xác định đúng câu để trả lời ngắn gọn, có thể phát biểu ngay tại hội nghị và dẫn đúng điều, mục của quy chế đính kèm.

---

USER

bạn hãy dựa vào các nộ dung quy chế đã gửi kèm, bạn hãy giải trình lặp luận chặt chẽ, lo gic thuyết phục và phù hợp thực tiễn

---

ASSISTANT

Tôi sẽ giải trình lần lượt các ý kiến trong bản tổng hợp, đối chiếu với quy chế đính kèm để làm rõ nội dung đã quy định, nội dung cần tiếp thu và hướng thực hiện phù hợp tại trường.

---

ASSISTANT

Bản quy chế đã điều chỉnh có một số nội dung chưa được cập nhật vào bản trả lời góp ý: quyền sửa báo cáo, chế độ nghỉ và ứng xử của cán bộ quản lý đã được làm rõ. Đặc biệt, Điều 10 quy chế đánh giá phân biệt yêu cầu “30% nhiệm vụ vượt mức” của nhà trường với đánh giá từng viên chức; lời giải trình cần sửa để tránh áp dụng nhầm.

---

ASSISTANT

Dưới đây là nội dung giải trình theo **27 ý kiến trong bản tổng hợp**, đối chiếu với các bản quy chế cô gửi. Những nội dung đã được bổ sung vào bản điều chỉnh được nêu rõ để tránh trả lời chung chung là “sẽ tiếp thu”.

**I. Ý kiến về Quy chế chuyên môn**

| Ý kiến | Nội dung giải trình đề xuất tại hội nghị |
|---|---|
| **1. Thay đổi giáo viên phụ trách nhóm, lớp qua từng năm học** | Nhà trường ghi nhận mục đích giúp giáo viên phát triển năng lực ở nhiều độ tuổi. Tuy nhiên, Quy chế chuyên môn đã định hướng khuyến khích giáo viên phụ trách ổn định một khối để hiểu sâu chương trình và đặc điểm phát triển của trẻ. **Ổn định khối lớp không đồng nghĩa với lặp lại cách dạy**; giáo viên vẫn phải điều chỉnh kế hoạch theo khả năng, nhu cầu của từng nhóm trẻ. Vì vậy, nhà trường không thực hiện luân chuyển đồng loạt hằng năm mà xem xét năng lực, nguyện vọng, yêu cầu đội ngũ và tình hình từng điểm trường; đồng thời tạo cơ hội học hỏi các độ tuổi qua dự giờ, sinh hoạt chuyên môn. |
| **2. Sửa lỗi chính tả, diễn đạt** | Nhà trường tiếp thu, giao bộ phận chuyên môn rà soát các vị trí được góp ý và toàn bộ văn bản trước khi trình ký. Nội dung chỉnh sửa phải bảo đảm rõ nghĩa, thống nhất thuật ngữ; nếu sửa làm thay đổi yêu cầu hoặc trách nhiệm thực hiện thì phải thông tin lại để đội ngũ nắm rõ. |
| **3. Thống nhất hồ sơ, hạn chế trùng lặp, sử dụng hồ sơ điện tử** | **Mục 4.3 Quy chế chuyên môn** đã xác định hồ sơ của giáo viên và cho phép sử dụng hồ sơ điện tử hợp pháp thay hồ sơ giấy tương ứng. Nhà trường thống nhất hướng dẫn chung về danh mục, nơi lưu và cách kiểm tra; không yêu cầu đồng thời hai hình thức chỉ để thuận tiện cho người kiểm tra. Khi cần minh chứng cho nhiệm vụ cụ thể, ưu tiên khai thác dữ liệu đã có, phân công đúng bộ phận phụ trách; không biến mỗi yêu cầu minh chứng thành một loại sổ mới của giáo viên. |
| **4. Bổ sung thời gian dự kiến tổ chức hội thi của trẻ** | Nhà trường tiếp thu nhu cầu được biết sớm để chủ động chuẩn bị. Quy chế quy định nguyên tắc, trách nhiệm; lịch hội thi nên cụ thể trong kế hoạch năm học và kế hoạch chuyên môn để thuận tiện điều chỉnh. Bộ phận chuyên môn cần thông tin mốc dự kiến, yêu cầu và đầu mối phụ trách; khi thay đổi phải thông báo kịp thời. Việc chuẩn bị hội thi phải phù hợp khả năng của trẻ, không làm xáo trộn hoạt động chăm sóc, giáo dục thường ngày. |

**II. Ý kiến về Quy chế đánh giá, xếp loại chất lượng viên chức**

**Điểm cần sửa ngay trong bản trả lời:** Câu II.1 đang gắn điều kiện “minh chứng vượt chỉ tiêu 30%” với từng viên chức, trong khi **khoản 4 Điều 10 bản quy chế đính kèm đã phân biệt đây là yêu cầu đối với đánh giá nhà trường**. Quy định về ít nhất 30% nhiệm vụ vượt mức cũng được nêu trong tiêu chí đánh giá đơn vị sự nghiệp công lập; không nên chuyển thành điều kiện chung cho từng giáo viên. https://xaydungchinhsach.chinhphu.vn/nghi-dinh-233-2026-nd-cp-ve-danh-gia-xep-loai-chat-luong-voi-don-vi-su-nghiep-cong-lap-va-vien-chuc-119260701171015913.htm
https://xaydungchinhsach.chinhphu.vn/nghi-dinh-233-2026-nd-cp-ve-danh-gia-xep-loai-chat-luong-voi-don-vi-su-nghiep-cong-lap-va-vien-chuc-119260701171015913.htm?utm_source=chatgpt.com

| Ý kiến | Nội dung giải trình đề xuất tại hội nghị |
|---|---|
| **1. Nhiều người đạt từ 90 điểm, vượt tỷ lệ được xếp loại xuất sắc** | Theo **Điều 3, Điều 4 và Điều 10**, đạt từ 90 điểm là căn cứ xem xét, không có nghĩa tất cả đều đương nhiên được xếp loại xuất sắc. Nhà trường phải đối chiếu điều kiện, tỷ lệ và xem xét trong từng nhóm có nhiệm vụ tương đồng. Đề xuất bổ sung nguyên tắc xét chọn: kiểm tra tính chính xác của điểm và minh chứng, xem xét điểm từ cao xuống thấp; nếu bằng điểm thì đối chiếu chất lượng, hiệu quả và đóng góp thực tế theo tiêu chí được công khai trước. Không tự hạ điểm để khớp tỷ lệ. Tỷ lệ 25% chỉ được xem xét khi đáp ứng điều kiện quy định, không phải mức mặc nhiên áp dụng. |
| **2. Làm rõ sai sót nhẹ, vi phạm nghiêm trọng về an toàn trẻ** | Nhà trường tiếp thu vì tiêu chí chưa rõ sẽ dẫn đến cách hiểu khác nhau. Theo **Điều 2, Điều 10 Quy chế đánh giá và Điều 16 Quy tắc ứng xử**, phải xác minh hành vi, nguyên nhân, nhiệm vụ được giao, mức độ nguy cơ, hậu quả và cách xử lý trước khi đánh giá. Không thể chỉ căn cứ việc trẻ bị tai nạn để mặc nhiên kết luận giáo viên có lỗi; cũng không thể coi việc bỏ giám sát là nhẹ chỉ vì chưa xảy ra hậu quả. Nhà trường cần bổ sung mô tả, tình huống minh họa cho từng mức trong phụ lục, giữ nguyên cơ cấu điểm và bảo đảm người liên quan được giải trình. |
| **3. KPI hằng tháng gây áp lực; có tiêu chí không phát sinh; đề nghị tổng hợp quý** | **Điều 10** đã quy định không tạo hồ sơ hình thức để chấm điểm; **Điều 11** quy định theo dõi theo tháng và có thể tổng hợp theo quý khi cần thiết. Vì vậy, nhà trường tiếp thu theo hướng sử dụng hồ sơ công việc sẵn có, đánh giá theo nhiệm vụ và tiến độ thực tế. Nhiệm vụ chưa đến hạn hoặc chưa được giao không thể mặc nhiên coi là chưa hoàn thành; cách xử lý tiêu chí không phát sinh phải được hướng dẫn thống nhất trước khi chấm. Đề nghị chuyển kỳ đánh giá cần được xem xét, quy định rõ, tránh vừa chấm tháng vừa làm lại toàn bộ hồ sơ theo quý. Các vị trí được phản ánh lệch điểm sẽ được đối chiếu và sửa nếu có sai sót. |
| **4. Được biết lý do mất điểm, trao đổi và đề nghị xem xét lại** | Nội dung này đã thể hiện tại **Điều 20 khoản 3, Điều 21 khoản 4 và Điều 22**. Khi xác định một tiêu chí chưa đạt, người đánh giá phải chỉ rõ yêu cầu, kết quả thực tế và minh chứng; giáo viên được trao đổi, bổ sung thông tin và kiến nghị. Nhà trường sẽ thống nhất cách phản hồi trong quá trình thực hiện, tránh chỉ thông báo một tổng điểm mà không giải thích. Tiếp nhận giải trình là bước kiểm tra độ chính xác của đánh giá, không phải biểu hiện chống đối của người được đánh giá. |
| **5. Sai sót của lớp thì trừ cả hai giáo viên hay từng người?** | Căn cứ **Điều 2 và Điều 10**, đánh giá thực hiện đối với từng cá nhân theo nhiệm vụ và trách nhiệm thực tế. Làm cùng lớp không có nghĩa mọi sai sót đều chia đều trách nhiệm. Nếu thuộc phần việc của một người thì xem xét người đó; nếu cả hai cùng có trách nhiệm thì xác định phần trách nhiệm của từng người. Trường hợp phân công chưa rõ, nhà trường phải làm rõ cả trách nhiệm quản lý, không lấy sự thiếu rõ ràng trong phân công làm căn cứ quy lỗi đồng loạt. |
| **6. Sửa “hàng tháng” thành “hằng tháng”, rà soát điểm** | Nhà trường tiếp thu, thống nhất dùng “hằng tháng” đối với hoạt động lặp lại theo tháng. Đồng thời rà soát điểm thành phần, điểm tối đa và cách diễn đạt các mức đạt, bảo đảm cộng đúng, dễ hiểu và thống nhất giữa quy chế với phụ lục. Bản hoàn chỉnh cần được phổ biến trước khi áp dụng. |
| **7. Giáo viên còn chưa rõ, hoang mang về quy chế** | Nhà trường ghi nhận băn khoăn này và có trách nhiệm hướng dẫn để đội ngũ thực hiện được. Căn cứ **Điều 10, Điều 11 và Điều 20**, bộ phận phụ trách cần minh họa cách chấm bằng tình huống thực tế: hoàn thành nhiệm vụ đúng hạn, sản phẩm phải chỉnh sửa, nghỉ hợp lệ, nhiệm vụ đột xuất. Giáo viên chỉ cần sử dụng minh chứng phù hợp, không phải chuẩn bị một bộ hồ sơ riêng cho từng tiêu chí. Nội dung còn nhiều cách hiểu phải được giải thích và thống nhất chung giữa các tổ, các điểm trường. |

Tỷ lệ xếp loại xuất sắc phải xác định theo quy định dành cho viên chức và nhóm nhiệm vụ tương đồng; “Hoàn thành xuất sắc nhiệm vụ” là **mức xếp loại chất lượng**, không nên gọi là “danh hiệu”. https://xaydungchinhsach.chinhphu.vn/cac-muc-xep-loai-chat-luong-vien-chuc-119260701155446369.htm
https://xaydungchinhsach.chinhphu.vn/cac-muc-xep-loai-chat-luong-vien-chuc-119260701155446369.htm?utm_source=chatgpt.com

**III. Ý kiến về Quy chế làm việc**

| Ý kiến | Nội dung giải trình đề xuất tại hội nghị |
|---|---|
| **1. Một năm được nghỉ bao nhiêu ngày?** | **Điều 13 bản đã điều chỉnh** đã phân biệt giáo viên, cán bộ quản lý và nhân viên, người lao động. Đối với giáo viên mầm non, thời gian nghỉ hè là 08 tuần, bao gồm nghỉ phép hằng năm; không cộng mặc nhiên thêm 12 ngày phép. Nhân viên, người lao động được xác định ngày nghỉ theo chế độ áp dụng, thời gian làm việc và điều kiện cụ thể. Không thể quy định một số ngày chung cho mọi vị trí; nghỉ hè, nghỉ việc riêng, ốm đau, thai sản cũng không gộp thành một hạn mức để đánh giá chuyên cần. |
| **2. Nghỉ việc riêng bao nhiêu ngày, có hưởng lương không?** | **Điều 13 đã bổ sung các trường hợp cụ thể**: bản thân kết hôn nghỉ 03 ngày; con kết hôn nghỉ 01 ngày; thân nhân thuộc diện quy định qua đời nghỉ 03 ngày hưởng nguyên lương. Một số sự kiện khác được nghỉ 01 ngày không hưởng lương và phải thông báo; nhu cầu nghỉ thêm hoặc ngoài các trường hợp này được giải quyết theo chế độ phù hợp hoặc thỏa thuận. Số ngày gắn với từng sự kiện, không phải tổng số ngày được nghỉ trong năm. Nhà trường bố trí người thay thế, không buộc giáo viên tự thuê hoặc tự trả tiền người dạy thay. |
| **3. Báo cáo, kế hoạch sai có được sửa hay bị đánh giá không hoàn thành?** | **Khoản 4 Điều 14 và khoản 3 Điều 18 đã quy định rõ việc chỉnh sửa**. Người kiểm tra phải chỉ rõ lỗi, yêu cầu và thời hạn; người thực hiện có trách nhiệm hoàn thiện, gửi lại. Một lần thiếu sót không tự động dẫn đến xếp loại không hoàn thành nhiệm vụ. Tuy nhiên, được sửa không có nghĩa mọi thiếu sót đều không ảnh hưởng đánh giá: phải xem mức độ, tiến độ, hậu quả, nguyên nhân và kết quả khắc phục. Cần phân biệt chất lượng một sản phẩm với kết quả một nhiệm vụ và mức xếp loại cả năm. |

Thời gian nghỉ hè 08 tuần được quy định tại Điều 17 Nghị định 93/2026/NĐ-CP; nghỉ việc riêng thực hiện theo Điều 115 Bộ luật Lao động. https://xaydungchinhsach.chinhphu.vn/chinh-phu-quy-dinh-thoi-gian-nghi-he-cua-nha-giao-119260404074041813.htm
https://xaydungchinhsach.chinhphu.vn/chinh-phu-quy-dinh-thoi-gian-nghi-he-cua-nha-giao-119260404074041813.htm?utm_source=chatgpt.com
https://xaydungchinhsach.chinhphu.vn/quy-dinh-ve-nghi-viec-rieng-nghi-khong-huong-luong-voi-nguoi-lao-dong-119230408231155425.htm
https://xaydungchinhsach.chinhphu.vn/quy-dinh-ve-nghi-viec-rieng-nghi-khong-huong-luong-voi-nguoi-lao-dong-119230408231155425.htm?utm_source=chatgpt.com

**Lưu ý chỉnh văn bản:** Điều 13 bản gửi hiện có **hai khoản cùng đánh số 4**. Cần đánh lại thứ tự và tách rõ trường hợp chỉ phải thông báo với trường hợp cần thỏa thuận, tránh hiểu tất cả ngày nghỉ việc riêng đều phải chờ phê duyệt.

**IV. Ý kiến về Quy chế chi tiêu nội bộ**

| Ý kiến | Nội dung giải trình đề xuất tại hội nghị |
|---|---|
| **1. Sửa năm ban hành Luật Ngân sách nhà nước** | Nhà trường tiếp thu, chỉnh căn cứ thành **Luật Ngân sách nhà nước số 89/2025/QH15 ngày 25/6/2025**; đồng thời giao kế toán rà soát tính chính xác, hiệu lực và phạm vi áp dụng của các căn cứ tài chính trước khi trình ký. Đây là chỉnh lý căn cứ pháp lý, không phải quyết định thay đổi mức chi. |
| **2. Làm rõ đối tượng hưởng các khoản chi** | Ý kiến này cần tiếp thu vì **Điều 11, Điều 12, Điều 15 và Điều 28** đang quy định nhiều khoản chi khác nhau. Không thể dùng chung một câu “chỉ người trong biên chế được hưởng” cho toàn bộ tiền thưởng, phúc lợi và thu nhập tăng thêm. Riêng khoản 2 Điều 15 đã có phúc lợi cho người lao động hợp đồng. Kế toán cần lập rõ từng khoản: nguồn chi, đối tượng, điều kiện và mức hưởng; đối chiếu hợp đồng và quy định tương ứng để thống nhất giữa các điều, không bỏ sót hoặc mở rộng đối tượng thiếu căn cứ. |
| **3. Làm rõ tiêu chí và quy trình tạm chi thu nhập tăng thêm theo quý** | **Điều 29** quy định căn cứ tài chính để xem xét tạm chi, còn **Điều 28** xác định phân phối thu nhập tăng thêm theo kết quả đánh giá năm. Vì vậy, cần phân biệt **khả năng có nguồn để chi** với **căn cứ phân phối cho từng người**. Tạm chi là khoản chi trước, phải đối chiếu khi xác định kết quả cuối năm; không nên trả lời đơn giản rằng “không xét tiêu chí trong quý” rồi bỏ trống cách xác định người và số tiền nhận. Nhà trường cần bổ sung phương án cụ thể về đối tượng, cách tính tạm chi, phê duyệt, công khai và xử lý chênh lệch theo chế độ tài chính áp dụng. |
| **4. Khoản vệ sinh lớp học 17.000 đồng/trẻ/tháng dùng làm gì?** | **Điểm 1.2 khoản 1 Điều 14** có khoản phục vụ vệ sinh lớp học, nhưng chưa mô tả rõ khối lượng công việc và cách tổ chức thực hiện. Theo bản tổng hợp, trường dự kiến thuê người nhưng chưa ký được hợp đồng. Vì vậy, cần trả lời rõ việc nào thuộc chăm sóc, vệ sinh thường xuyên của giáo viên và việc nào dự kiến giao người phục vụ. Nhà trường sẽ làm rõ phương án, người thực hiện và hồ sơ thanh toán; nếu chưa tổ chức được dịch vụ thì phải rà soát khoản thu, chi tương ứng, không thể chỉ thông báo “chưa thuê được người” mà để phụ huynh, giáo viên không rõ kinh phí được xử lý thế nào. |
| **5. Công khai tài chính, bảo đảm chế độ và hỗ trợ người khó khăn** | Nhà trường thống nhất thực hiện đầy đủ chế độ của từng đối tượng, sử dụng kinh phí đúng mục đích và công khai cả quá trình thực hiện theo **Điều 30 Quy chế chi tiêu nội bộ**. Việc đưa dự thảo ra góp ý là một bước công khai, chưa thay thế công khai dự toán, quyết toán và kết quả thực hiện. Đối với hỗ trợ khó khăn, nhà trường tiếp thu để rà soát nguồn hợp pháp, điều kiện và tiêu chí hỗ trợ; khi đủ căn cứ sẽ cụ thể hóa trong quy chế. Việc động viên người có thành tích cần thực hiện theo tiêu chí khen thưởng rõ ràng, tránh quyết định theo cảm tính. |

Ngày ban hành Luật Ngân sách nhà nước nêu trên đã được đối chiếu với nguồn Chính phủ. https://www2.en.baochinhphu.vn/du-an-luat-ngan-sach-nha-nuoc-hop-nhat-102260915172516643.htm
https://www2.en.baochinhphu.vn/du-an-luat-ngan-sach-nha-nuoc-hop-nhat-102260915172516643.htm?utm_source=chatgpt.com **Đối tượng hưởng từng khoản tiền vẫn cần kiểm tra hồ sơ hợp đồng và nguồn kinh phí thực tế**, nên chưa đủ căn cứ để giữ kết luận trong bản tổng hợp rằng mọi lao động hợp đồng đều không được hưởng tiền thưởng.

**V. Ý kiến về Quy tắc ứng xử**

| Ý kiến | Nội dung giải trình đề xuất tại hội nghị |
|---|---|
| **1. Bổ sung quy tắc ứng xử của Phó Hiệu trưởng** | Nội dung này **đã được tiếp thu tại Điều 4**, yêu cầu Phó Hiệu trưởng thực hiện chuẩn mực tại Điều 3 phù hợp nhiệm vụ được giao. Trách nhiệm tôn trọng, lắng nghe, phân công rõ và góp ý có căn cứ áp dụng đối với cả Hiệu trưởng và Phó Hiệu trưởng. Quản lý cần nghiêm túc về yêu cầu công việc nhưng không được xúc phạm, hạ thấp hoặc quy trách nhiệm khi chưa xác minh. Nhà trường cần phổ biến và thực hiện thống nhất tại các điểm trường. |
| **2. Giao việc rõ ràng, góp ý cụ thể, tránh gây áp lực** | **Điều 3, Điều 4 Quy tắc ứng xử và khoản 2 Điều 3 Quy chế làm việc** đã xác định yêu cầu phân công rõ trách nhiệm. Khi giao việc cần làm rõ người chủ trì, người phối hợp, sản phẩm và thời hạn; khi yêu cầu sửa phải chỉ rõ nội dung chưa đạt và hướng hoàn thiện. Góp ý nhiều lần chỉ phù hợp khi công việc còn hạn chế cụ thể, không thay đổi yêu cầu tùy tiện hoặc nhận xét chung chung khiến người thực hiện không biết sửa thế nào. |
| **3. Lắng nghe nguyện vọng, không gây bất lợi cho người góp ý** | **Khoản 2 Điều 3, Điều 4 và Điều 22** đã thể hiện trách nhiệm lắng nghe, tiếp nhận và bảo vệ thông tin người phản ánh. Nhà trường ghi nhận ý kiến khác biệt trên tinh thần xây dựng; đánh giá công việc phải dựa vào nhiệm vụ và kết quả, không dựa vào việc cá nhân có góp ý hay không. Nội dung chưa thể chấp thuận cần được giải thích rõ lý do, thẩm quyền và điều kiện thực hiện, không chỉ dừng ở lời ghi nhận. |
| **4. Hạn chế nhắn tin ngoài giờ làm việc** | **Khoản 3 Điều 14 đã quy định cụ thể**: thông báo thông thường ngoài giờ được tiếp nhận vào thời gian làm việc tiếp theo; không mặc nhiên yêu cầu trực tuyến liên tục. Với tình huống khẩn cấp, người phụ trách liên hệ trực tiếp qua điện thoại hoặc kênh đã thống nhất. Nhà trường cần phân biệt rõ việc gấp thực sự với công việc có thể chủ động sắp xếp, tránh biến mọi thông báo thành yêu cầu phản hồi ngay. |
| **5. Giáo viên có được ghi âm, quay video khi cần thiết không?** | Theo **khoản 3 Điều 6, khoản 5 Điều 14 và Điều 15**, Quy tắc không đặt lệnh cấm tuyệt đối đối với việc lưu giữ, cung cấp chứng cứ hợp pháp. Tuy nhiên, ghi nhận để cung cấp người có trách nhiệm khác với đăng công khai lên mạng. Mỗi trường hợp phải xem mục đích, nội dung, phạm vi sử dụng và yêu cầu bảo vệ thông tin, nhất là hình ảnh của trẻ. Khi có vụ việc, cần giữ nguyên tài liệu, chuyển đúng người có thẩm quyền; không cắt ghép hoặc phát tán gây hiểu sai. |
| **6. Chuyển quy định ứng xử của trẻ thành nội dung giáo dục; bổ sung báo cáo vụ việc nghiêm trọng** | Bản điều chỉnh **đã bố trí Chương VI, Điều 13 về hướng dẫn trẻ ứng xử** và **Điều 16 về xử lý vụ việc**. Trẻ mầm non đang hình thành hành vi nên trách nhiệm thuộc người lớn trong việc làm gương, hướng dẫn và hỗ trợ phù hợp độ tuổi; không áp dụng cách quy trách nhiệm như với viên chức. Với nguy cơ bạo lực, xâm hại, mất an toàn, phải ưu tiên bảo vệ trẻ và thông báo theo tính chất vụ việc, không chờ giải quyết xong nội bộ mới thực hiện việc cần thiết. |
| **7. Bổ sung ngày ban hành Luật Nhà giáo** | Nhà trường tiếp thu, thống nhất ghi **Luật Nhà giáo số 73/2025/QH15 ngày 16/6/2025**. Đồng thời rà soát phần căn cứ và ngày tháng giữa quyết định với quy tắc kèm theo để bảo đảm thống nhất trước khi ban hành. |
| **8. Xây dựng môi trường thân thiện, đoàn kết, phối hợp tốt** | Nhà trường thống nhất và cụ thể hóa bằng việc thực hiện **Điều 3, Điều 4, Điều 6 và Điều 8**: lãnh đạo giao việc rõ, giáo viên hỗ trợ đồng nghiệp, các bộ phận phối hợp và trao đổi đúng mực với phụ huynh. Đoàn kết không có nghĩa né tránh góp ý; ý kiến khác biệt cần được trao đổi có căn cứ và giải quyết công bằng. Chất lượng môi trường làm việc phải thể hiện trong cách xử lý công việc hằng ngày, không chỉ qua khẩu hiệu hoặc cam kết. |

Thông tin về số hiệu và ngày ban hành Luật Nhà giáo đã được đối chiếu với văn bản công bố chính thức. https://chinhphu.vn/?classid=1&docid=214559&orggroupid=1&pageid=27160
https://chinhphu.vn/?classid=1&docid=214559&orggroupid=1&pageid=27160&utm_source=chatgpt.com

---

USER

Giáo viên đi làm việc theo ca, việc học ngoại khóa và cách xử lý. lý do lớp chỉ có 1 cô

---

ASSISTANT

Tôi sẽ đối chiếu quy định về ca làm việc, quản lý trẻ và hoạt động ngoại khóa để làm rõ cách bố trí khi lớp chỉ có một giáo viên.

---

ASSISTANT

Cô có thể giải trình tại hội nghị như sau:

“Nhà trường ghi nhận khó khăn khi giáo viên làm việc theo ca, tại thời điểm tổ chức ngoại khóa lớp chỉ còn một cô. **Điều 12 Quy chế làm việc** yêu cầu bố trí ca, phân công nhân sự rõ ràng và bảo đảm an toàn cho trẻ; Quy chế chuyên môn cũng yêu cầu bảo đảm an toàn trong hoạt động ngoại khóa. Vì vậy, việc tổ chức ngoại khóa phải gắn với phương án quản lý cả trẻ tham gia và trẻ không tham gia.

**Nếu lớp chỉ có một giáo viên, không thể yêu cầu cô vừa đưa trẻ đi học ngoại khóa vừa quản lý số trẻ còn lại tại lớp.** Phó Hiệu trưởng phụ trách cần phối hợp với đơn vị liên kết, rà soát lịch học và ca làm việc để tham mưu bố trí thời điểm phù hợp hoặc người hỗ trợ được phân công rõ ràng. Việc giao, nhận trẻ phải kiểm đếm, bàn giao trực tiếp và xác định người chịu trách nhiệm trong từng thời điểm.

Khi chưa có người tiếp nhận hoặc hỗ trợ, giáo viên tiếp tục quản lý trẻ tại lớp, báo ngay người phụ trách để xử lý; không để trẻ tự đi hoặc rời lớp khi chưa có người quản lý thay. Nếu chưa bảo đảm nhân sự, nhà trường cần điều chỉnh buổi ngoại khóa. **Đây là vấn đề tổ chức, phối hợp của nhà trường, không thể giao giáo viên tự xoay xở hoặc mặc nhiên yêu cầu cô đã hết ca ở lại.**”

**Hướng xử lý cụ thể:** Phó Hiệu trưởng phụ trách lập phương án xác định rõ **người đưa trẻ – người tiếp nhận, quản lý tại lớp ngoại khóa – người quản lý trẻ còn lại – người bàn giao trẻ trở về**, trình Hiệu trưởng thống nhất cùng lịch ca trước khi thực hiện.

---

USER

hàng tháng khám sức khỏe định kỳ theo chỉ định bác sĩ. trường hợp này có bị trừ điểm hay không?

---

ASSISTANT

**Không mặc nhiên trừ điểm vì giáo viên đi khám sức khỏe hằng tháng theo chỉ định của bác sĩ**, nếu việc nghỉ được thông báo, giải quyết đúng quy định và có giấy tờ phù hợp.

Cô có thể giải đáp tại hội nghị:

“Căn cứ **khoản 5 Điều 11 Quy chế đánh giá, xếp loại viên chức**, nghỉ hợp lệ không mặc nhiên bị trừ điểm KPI chỉ vì số ngày nghỉ. Vì vậy, trường hợp giáo viên tái khám hằng tháng theo chỉ định của bác sĩ, thực hiện đúng thủ tục và cung cấp giấy tờ phù hợp thì không lấy việc đi khám làm căn cứ trừ điểm.

Giáo viên cần chủ động báo lịch khám để nhà trường bố trí người thay thế, bàn giao công việc trong khả năng thực hiện. Theo **Điều 10 của Quy chế**, nhiệm vụ đã được điều chỉnh, chuyển giao hợp lệ trong thời gian nghỉ không tính là nhiệm vụ chưa hoàn thành của người nghỉ. Việc đánh giá căn cứ vào kết quả thực hiện những nhiệm vụ còn thuộc trách nhiệm của giáo viên; nếu có thiếu sót thì xem xét cụ thể, không quy đổi mỗi lần đi khám thành một mức điểm trừ.”

---

USER

KPI chưa có nội dung điểm phog trào thi đua, các phog trào ngoài chuyên môn, cách đánh giá và cộng điểm như thế nào

---

USER

KPI quy định mức điểm, minh chứng (biên bản kiểm tra) cụ thể nội dung này

---

ASSISTANT

Tôi sẽ đối chiếu các tiêu chí và phụ lục KPI để làm rõ cách chấm điểm phong trào, cùng nội dung cần ghi trong biên bản kiểm tra.

---

ASSISTANT

**KPI phải chấm theo mức điểm đã quy định; biên bản kiểm tra là căn cứ xác định mức đạt, không phải cứ có biên bản là trừ điểm.** Với nội dung cô hỏi, có thể làm rõ như sau:

**1. Điểm tham gia phong trào, hoạt động ngoài chuyên môn**

Phụ lục KPI giáo viên hiện có **mục B1.4: “Thực hiện nhiệm vụ khác… và nhiệm vụ chung”, tối đa 3 điểm**, nhưng chưa gọi rõ tên các hoạt động phong trào. Đề xuất bổ sung hoạt động phong trào được nhà trường phân công vào mục này, **giữ nguyên 3 điểm**, không tự đặt thêm điểm thưởng ngoài thang điểm.

| Tỷ lệ hoàn thành nhiệm vụ thuộc B1.4 | Điểm theo phụ lục hiện tại |
|---|---:|
| Hoàn thành 100% | 3 |
| Từ 90% đến dưới 100% | 2 |
| Từ 70% đến dưới 90% | 1 |
| Dưới 70% | 0 |

Điểm này tính **chung cho các nhiệm vụ thuộc B1.4**, không phải mỗi phong trào được cộng 3 điểm. Việc tham gia cần có phân công, yêu cầu và kết quả cụ thể; không lấy số lần tham gia để so sánh khi cơ hội và nhiệm vụ của mỗi người khác nhau. Thành tích đạt giải có thể được xem xét khen thưởng theo quy định tương ứng, không tự động quy đổi thành điểm cộng KPI.

**2. Biên bản kiểm tra cần ghi gì để làm minh chứng chấm điểm?**

Đề xuất thống nhất các nội dung sau:

| Nội dung cần ghi | Yêu cầu cụ thể |
|---|---|
| **Nhiệm vụ, tiêu chí được kiểm tra** | Ghi rõ công việc được giao, thời hạn và mã tiêu chí KPI liên quan. |
| **Kết quả thực tế** | Nêu phần hoàn thành, phần chưa đạt; số lượng, thời điểm, sản phẩm hoặc tài liệu đối chiếu. Tránh chỉ ghi “chưa tốt”, “thiếu trách nhiệm”. |
| **Trách nhiệm cá nhân** | Xác định phần việc của người được kiểm tra; không quy lỗi chung cho cả lớp khi chưa làm rõ. |
| **Ý kiến giải trình** | Ghi nguyên nhân, điều kiện thực hiện và ý kiến của giáo viên, kể cả nội dung chưa thống nhất. |
| **Yêu cầu khắc phục** | Chỉ rõ nội dung cần sửa, thời hạn và kết quả kiểm tra lại nếu có. |
| **Đối chiếu mức điểm** | Nêu kết quả phù hợp mức nào trong phụ lục; người có trách nhiệm đánh giá xem xét, không tự đặt thêm mức trừ. |

Theo **Điều 10 Quy chế đánh giá**, có thể sử dụng kế hoạch, bảng phân công, sản phẩm, kết quả kiểm tra và tài liệu sẵn có; **không bắt buộc mỗi tiêu chí phải lập một biên bản riêng**.

**Lời giải đáp ngắn tại hội nghị:**

“Nhà trường tiếp thu việc làm rõ điểm phong trào và minh chứng đánh giá. Đề xuất ghi cụ thể các hoạt động phong trào được phân công vào mục nhiệm vụ chung B1.4, giữ nguyên mức tối đa 3 điểm; không cộng điểm riêng cho từng lần tham gia. Khi kiểm tra, biên bản phải thể hiện công việc, kết quả, hạn chế, trách nhiệm và ý kiến giải trình để đối chiếu đúng mức điểm. Biên bản là minh chứng ghi nhận thực tế, không đồng nghĩa với vi phạm; việc chấm điểm phải dựa vào tiêu chí đã công khai, không dựa vào nhận xét cảm tính.”

---

