ASSISTANT

Căn cứ nội dung bản nhận xét, đánh giá 03 năm gần nhất đối với đồng chí **Nguyễn Thị Huỳnh Duyên** của Đảng ủy Trường Mầm non An Bình, tôi dự thảo hai nội dung nhận xét theo đúng hai mục trong hình đính kèm.

Nội dung được viết ngắn gọn, trang trọng, thể hiện sự thống nhất trong đánh giá nhưng có phân biệt giữa nhận xét của chi bộ và nhận xét của đảng ủy.

### 1. Nhận xét, đánh giá của chi bộ

> **writing · standard**
>
> Đồng chí Nguyễn Thị Huỳnh Duyên có lập trường tư tưởng chính trị vững vàng, phẩm chất đạo đức tốt, lối sống giản dị, gương mẫu; chấp hành nghiêm nguyên tắc tổ chức, kỷ luật của Đảng, có tinh thần trách nhiệm và đoàn kết nội bộ. Trong thực hiện nhiệm vụ, đồng chí năng động, chủ động tham mưu, tổ chức thực hiện tốt công tác chuyên môn và công tác xây dựng Đảng, đạt nhiều kết quả tích cực. Tuy nhiên, việc sắp xếp công việc và kiểm tra, giám sát tiến độ thực hiện nhiệm vụ có lúc chưa kịp thời. Đồng chí có năng lực, uy tín và triển vọng phát triển tốt.

### 2. Nhận xét, đánh giá của đảng ủy, chi ủy cơ sở

> **writing · standard**
>
> Đảng ủy thống nhất với nhận xét, đánh giá của chi bộ. Đồng chí Nguyễn Thị Huỳnh Duyên có bản lĩnh chính trị vững vàng, đạo đức, lối sống tốt, ý thức tổ chức kỷ luật cao; có năng lực quản lý, điều hành và tinh thần trách nhiệm trong thực hiện nhiệm vụ. Trên cương vị Phó Hiệu trưởng và Phó Bí thư Chi bộ, đồng chí đã phát huy tốt vai trò, trách nhiệm, góp phần tích cực vào kết quả thực hiện nhiệm vụ chính trị của nhà trường và công tác xây dựng Đảng. Đồng chí có tinh thần cầu thị, khả năng phát triển và đáp ứng yêu cầu nhiệm vụ được giao.

### Lưu ý trước khi ký xác nhận

- **Về thẩm quyền:** Hai nội dung trên là dự thảo tham khảo. Chi bộ và đảng ủy cần thảo luận, thống nhất nội dung thuộc thẩm quyền trước khi người có trách nhiệm ký xác nhận.
- **Về kết quả xếp loại:** Tài liệu đính kèm ghi đồng chí hoàn thành xuất sắc nhiệm vụ năm 2026. Vì năm 2026 chưa kết thúc, cần kiểm tra lại đây là kết quả đánh giá chính thức hay thông tin dự kiến, tránh sử dụng kết quả chưa được công nhận.

**Đề xuất:** Sử dụng hai đoạn trên để điền vào biểu mẫu. Nội dung nhận xét của chi bộ thể hiện tương đối đầy đủ ưu điểm và hạn chế; nhận xét của đảng ủy mang tính khái quát, nhấn mạnh năng lực, kết quả công tác và triển vọng phát triển của đồng chí.

---

USER

Dựa vào file gởi đính kèm bạn đọc và tìm hiểu nội dung để viết 2 đánh giá nhận xét theo hình gởi kèm

---

