USER

Nguyên nhân táo bón

---

ASSISTANT

Tôi sẽ đối chiếu các nguyên nhân thường gặp và lưu ý riêng cho trẻ mầm non.

---

ASSISTANT

---

ASSISTANT

**Táo bón thường do ăn ít chất xơ, uống chưa đủ nước hoặc nhịn đi ngoài.** Một số yếu tố khác có thể góp phần là ít vận động, thay đổi nếp sinh hoạt, dùng viên sắt hoặc một số thuốc giảm đau. Đôi khi, táo bón liên quan đến bệnh lý như suy giáp. https://www.niddk.nih.gov/health-information/digestive-diseases/constipation-children/symptoms-causes
https://www.niddk.nih.gov/health-information/digestive-diseases/constipation-children/symptoms-causes?utm_source=chatgpt.com
https://www.niddk.nih.gov/health-information/digestive-diseases/constipation/symptoms-causes
https://www.niddk.nih.gov/health-information/digestive-diseases/constipation/symptoms-causes?utm_source=chatgpt.com

**Ở trẻ mầm non, nhịn đi ngoài là nguyên nhân thường gặp nhất.** Trẻ có thể mải chơi, ngại dùng nhà vệ sinh ở trường hoặc sợ đau vì lần trước đi phân cứng. Càng nhịn, phân càng khô cứng, lần sau đi càng đau và trẻ lại càng muốn nhịn. https://www.niddk.nih.gov/health-information/digestive-diseases/constipation-children/symptoms-causes
https://www.niddk.nih.gov/health-information/digestive-diseases/constipation-children/symptoms-causes?utm_source=chatgpt.com

Nếu trẻ bị táo bón **kéo dài hơn 2 tuần**, nên đưa trẻ đi khám. Nếu có **đau bụng liên tục, nôn, bụng chướng hoặc phân có máu**, nên đưa trẻ đi khám ngay. https://www.niddk.nih.gov/health-information/digestive-diseases/constipation-children/symptoms-causes
https://www.niddk.nih.gov/health-information/digestive-diseases/constipation-children/symptoms-causes?utm_source=chatgpt.com

---

