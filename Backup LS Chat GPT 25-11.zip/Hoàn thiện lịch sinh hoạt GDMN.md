USER

Với vai trò hiệu trưởng bạn giúp tôi đối chiếu lịch đã sắp và quy định của chương trình GDMN và hoàn thành lịch sinh hoạt theo nội dung hình ảnh chụp đính kèm (lịch sinh hoạt theo chương trình giáo dục mầm non)

---

ASSISTANT

Tôi sẽ đối chiếu ba lịch trong file Word với khung thời lượng của hai hình Chương trình GDMN, kiểm tra các điểm chưa khớp và chỉnh thành lịch có giờ bắt đầu – kết thúc rõ ràng. Tôi cũng sẽ tách riêng lịch mẫu giáo bán trú và lịch học 2 buổi/ngày không bán trú để tránh áp dụng nhầm khung thời gian.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 RÀ SOÁT, ĐỐI CHIẾU VÀ HOÀN THIỆN LỊCH SINH HOẠT CÁC NHÓM, LỚP MẦM NON

Tôi đã đối chiếu nội dung trong file **“Lịch sinh hoạt.docx”** với hai bảng chế độ sinh hoạt theo Chương trình Giáo dục mầm non mà cô gửi.

### 🎯 Kết quả rà soát

| Nhóm, lớp | Kết quả đối chiếu | Hướng điều chỉnh |
|--------|--------|--------|
| Nhà trẻ 24–36 tháng | Phù hợp về thời lượng các hoạt động | Giữ nguyên khung giờ, chuẩn hóa tên hoạt động và độ tuổi |
| Mẫu giáo bán trú | Một số hoạt động chưa đúng khung thời lượng; đặc biệt giờ ngủ trưa | Sắp xếp lại lịch từ 7h00 đến 17h00, bảo đảm đủ 9 hoạt động |
| Mẫu giáo học 2 buổi/ngày, không bán trú | Cần phân biệt với chế độ sinh hoạt cả ngày có ăn, ngủ tại trường | Hoàn thiện lịch sáng và chiều riêng, giữ thời gian đón, trả trẻ của trường |

**Điểm cần sửa quan trọng nhất:** Trong lịch mẫu giáo bán trú hiện tại, thời gian ngủ từ 11h30 đến 13h40 thực tế chỉ có **130 phút**, không phải 140 phút như đã ghi. Khung trong Chương trình GDMN là 140–150 phút.

### 📖 Căn cứ chuyên môn

Việc rà soát dựa trên Chương trình GDMN ban hành kèm Thông tư 17/2009/TT-BGDĐT, được sửa đổi, bổ sung bởi Thông tư 28/2016/TT-BGDĐT và Thông tư 51/2020/TT-BGDĐT, hợp nhất tại Văn bản 01/VBHN-BGDĐT ngày 13/4/2021. [Văn bản hợp nhất số 01/VBHN\-BGDĐT hợp nhất Thông tư ban hành Chương trình Giáo dục mầm non\.](<https://congbao.chinhphu.vn/van-ban/van-ban-hop-nhat-so-01-vbhn-bgddt-33656/35646.htm>); [Văn bản hợp nhất 01/VBHN\-BGDĐT năm 2021 hợp nhất Thông tư về Chương trình Giáo dục mầm non do Bộ Giáo dục và Đào tạo ban hành](<https://m.thuvienphapluat.vn/van-ban/giao-duc/Van-ban-hop-nhat-01-VBHN-BGDDT-2021-Thong-tu-Chuong-trinh-Giao-duc-mam-non-472930.aspx>); [Thông tư số 51/2020/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Sửa đổi, bổ sung một số nội dung của Chương trình Giáo dục mầm non ban hành kèm theo Thông tư số 17/2009/TT\-BGDĐT ngày 25 tháng 7 năm 2009 của Bộ trưởng Bộ Giáo dục và Đào tạo, đã được sửa đổi, bổ sung bởi Thông tư số 28/2016/TT\-BGDĐT ngày 30 tháng 12 năm 2016 của Bộ trưởng Bộ Giáo dục và Đào tạo](<https://chinhphu.vn/default.aspx?docid=203048&pageid=27160>)

Lưu ý đối với năm học 2026–2027: Bộ GDĐT đang triển khai thí điểm Chương trình GDMN mới tại 510 cơ sở. Bản lịch dưới đây áp dụng theo khung chương trình trong hình cô gửi; nếu nhà trường thuộc diện thí điểm thì cần đối chiếu thêm chương trình thí điểm được phê duyệt. [Hướng dẫn triển khai thí điểm Chương trình giáo dục mầm non mới năm học 2026\-2027](<https://xaydungchinhsach.chinhphu.vn/huong-dan-trien-khai-thi-diem-chuong-trinh-giao-duc-mam-non-moi-nam-hoc-2026-2027-119260514172250795.htm>); [Công văn 2595/BGDĐT\-GDMN 2026 thí điểm Chương trình giáo dục mầm non mới 2026 2027](<https://thuvienphapluat.vn/cong-van/Giao-duc/Cong-van-2595-BGDDT-GDMN-2026-thi-diem-Chuong-trinh-giao-duc-mam-non-moi-2026-2027-705392.aspx>)

## 📋 Nội dung lịch sinh hoạt đã hoàn thiện

Dưới đây là ba bảng lịch đã được điều chỉnh, có đầy đủ thời gian bắt đầu, kết thúc, thời lượng và ghi chú tổ chức. Nội dung có thể đưa vào văn bản của nhà trường để thống nhất thực hiện.

> **writing · document**
>
> # LỊCH SINH HOẠT HẰNG NGÀY CÁC NHÓM, LỚP
>
> ## I. LỊCH SINH HOẠT NHÓM TRẺ 24–36 THÁNG TUỔI
>
> **Chế độ:** Ăn 2 bữa chính, 1 bữa phụ; ngủ 1 giấc trưa.
>
> | TT | Thời gian | Thời lượng | Hoạt động | Ghi chú |
> |---|---|---|---|---|
> | 1 | 7h00–8h00 | 60 phút | Đón trẻ | Đón trẻ, trò chuyện, kiểm tra tình trạng sức khỏe, chơi theo ý thích |
> | 2 | 8h00–10h00 | 120 phút | Chơi – Tập | Chơi tự do, chơi – tập có chủ định, vận động, vệ sinh, uống nước |
> | 3 | 10h00–11h00 | 60 phút | Ăn bữa chính thứ nhất | Vệ sinh trước khi ăn; tổ chức ăn và vệ sinh sau ăn |
> | 4 | 11h00–13h30 | 150 phút | Ngủ trưa | Tổ chức cho trẻ ngủ một giấc; quan sát và bảo đảm an toàn trong giờ ngủ |
> | 5 | 13h30–14h00 | 30 phút | Ăn bữa phụ | Trẻ thức dậy, vệ sinh cá nhân, ăn bữa phụ theo thực đơn |
> | 6 | 14h00–15h00 | 60 phút | Chơi – Tập | Chơi, tập vận động, hoạt động theo nhu cầu và khả năng của trẻ |
> | 7 | 15h00–16h00 | 60 phút | Ăn bữa chính thứ hai | Vệ sinh trước khi ăn, tổ chức ăn, vệ sinh sau ăn |
> | 8 | 16h00–17h00 | 60 phút | Chơi và trả trẻ | Chơi nhẹ nhàng, vệ sinh, nêu gương, trao đổi với phụ huynh và trả trẻ |
>
> **Tổng thời gian tại trường: 600 phút (10 giờ).**
>
> **Ghi chú:** Chế độ sinh hoạt bảo đảm 2 bữa chính, 1 bữa phụ và 1 giấc ngủ trưa. Nội dung các hoạt động chơi – tập được tổ chức linh hoạt, phù hợp đặc điểm phát triển của trẻ.
>
> ---
>
> ## II. LỊCH SINH HOẠT LỚP MẪU GIÁO (BÁN TRÚ)
>
> **Đối tượng:** Trẻ mẫu giáo 3–6 tuổi.
>
> **Chế độ:** Ăn 1 bữa chính, 1 bữa phụ; ngủ 1 giấc trưa.
>
> | TT | Thời gian | Thời lượng | Hoạt động | Ghi chú |
> |---|---|---|---|---|
> | 1 | 7h00–8h30 | 90 phút | Đón trẻ, chơi, thể dục sáng | Đón trẻ, trò chuyện, chơi, thể dục sáng, điểm danh, chuẩn bị hoạt động |
> | 2 | 8h30–9h00 | 30 phút | Hoạt động học | Tổ chức hoạt động học phù hợp với từng độ tuổi |
> | 3 | 9h00–9h40 | 40 phút | Chơi, hoạt động ở các góc | Trẻ lựa chọn góc chơi, trải nghiệm, thực hành kỹ năng |
> | 4 | 9h40–10h20 | 40 phút | Chơi ngoài trời | Quan sát, khám phá thiên nhiên, trò chơi vận động, chơi tự do |
> | 5 | 10h20–11h30 | 70 phút | Ăn bữa chính | Vệ sinh trước ăn, tổ chức ăn trưa, vệ sinh sau ăn và chuẩn bị ngủ |
> | 6 | 11h30–14h00 | 150 phút | Ngủ trưa | Tổ chức ngủ trưa, theo dõi và chăm sóc trẻ trong giờ ngủ |
> | 7 | 14h00–14h30 | 30 phút | Ăn bữa phụ | Trẻ thức dậy, vệ sinh cá nhân, ăn bữa phụ |
> | 8 | 14h30–15h50 | 80 phút | Chơi, hoạt động theo ý thích | Hoạt động chiều, chơi tự chọn, trải nghiệm, củng cố kỹ năng |
> | 9 | 15h50–17h00 | 70 phút | Trẻ chuẩn bị ra về và trả trẻ | Vệ sinh, nêu gương, chơi nhẹ nhàng, chuẩn bị đồ dùng, trả trẻ và trao đổi với phụ huynh |
>
> **Tổng thời gian tại trường: 600 phút (10 giờ).**
>
> **Ghi chú:** Thời lượng các hoạt động nằm trong khoảng thời gian nêu tại Chương trình GDMN. Việc tổ chức hoạt động học, vui chơi, vệ sinh, ăn và ngủ được điều chỉnh phù hợp với từng độ tuổi, nhu cầu của trẻ và điều kiện thực tế.
>
> ---
>
> ## III. LỊCH SINH HOẠT LỚP MẪU GIÁO HỌC 2 BUỔI/NGÀY (KHÔNG BÁN TRÚ)
>
> **Thời gian học:** Buổi sáng từ 7h00 đến 10h30; buổi chiều từ 14h00 đến 17h00.
>
> ### 1. Buổi sáng
>
> | TT | Thời gian | Thời lượng | Hoạt động | Ghi chú |
> |---|---|---|---|---|
> | 1 | 7h00–8h20 | 80 phút | Đón trẻ, chơi, thể dục sáng | Đón trẻ, trò chuyện, chơi, thể dục sáng, điểm danh |
> | 2 | 8h20–8h50 | 30 phút | Hoạt động học | Tổ chức hoạt động học phù hợp với độ tuổi |
> | 3 | 8h50–9h30 | 40 phút | Chơi, hoạt động ở các góc | Chơi theo nhóm, phát triển kỹ năng |
> | 4 | 9h30–10h00 | 30 phút | Chơi ngoài trời | Quan sát, trải nghiệm, vận động và chơi tự do |
> | 5 | 10h00–10h30 | 30 phút | Vệ sinh, chuẩn bị ra về và trả trẻ | Vệ sinh cá nhân, kiểm tra đồ dùng, trao đổi với phụ huynh |
>
> **Tổng thời gian buổi sáng: 210 phút (3 giờ 30 phút).**
>
> ### 2. Buổi chiều
>
> | TT | Thời gian | Thời lượng | Hoạt động | Ghi chú |
> |---|---|---|---|---|
> | 6 | 14h00–14h20 | 20 phút | Đón trẻ buổi chiều | Đón trẻ, trò chuyện, kiểm tra tình trạng sức khỏe |
> | 7 | 14h20–15h40 | 80 phút | Chơi, hoạt động theo ý thích | Hoạt động chiều, trải nghiệm, vui chơi theo nhu cầu của trẻ |
> | 8 | 15h40–16h30 | 50 phút | Vệ sinh, nêu gương, chơi nhẹ nhàng | Củng cố nền nếp, kỹ năng tự phục vụ, chuẩn bị ra về |
> | 9 | 16h30–17h00 | 30 phút | Trả trẻ | Trả trẻ, trao đổi với phụ huynh về tình hình trong ngày |
>
> **Tổng thời gian buổi chiều: 180 phút (3 giờ).**
>
> **Tổng thời gian học tại trường trong ngày: 390 phút (6 giờ 30 phút).**
>
> **Quy định thời gian đón, trả trẻ:**
>
> - Đón trẻ buổi sáng: 7h00; kết thúc trả trẻ buổi sáng: 10h30.
> - Đón trẻ buổi chiều: 14h00; trả trẻ buổi chiều từ 16h30 đến 17h00.
> - Từ 10h30 đến 14h00, trẻ về gia đình ăn trưa, nghỉ trưa và được chăm sóc theo chế độ phù hợp với độ tuổi.
>
> **Ghi chú:** Lịch này dành cho lớp học 2 buổi/ngày không tổ chức bán trú. Thời lượng được sắp xếp phù hợp với thời gian trẻ có mặt tại trường, không áp dụng nguyên khung chế độ sinh hoạt 10 giờ của lớp bán trú.

## 🔍 Những nội dung hiệu trưởng cần lưu ý khi phê duyệt

**1. Đối với nhóm trẻ 24–36 tháng**

Có thể giữ nguyên các mốc giờ trong lịch ban đầu. Cần đổi tên nhóm tuổi theo cách gọi của Chương trình GDMN; thay nội dung “Uống sữa” bằng “Ăn bữa phụ”, trong đó sữa có thể là một phần của thực đơn.

---

**2. Đối với lớp mẫu giáo bán trú**

Lịch mới bảo đảm đầy đủ 9 hoạt động với tổng thời lượng 600 phút; khắc phục sai lệch giờ ngủ trưa. Thời gian ăn chính 70 phút đã tính cả các thao tác vệ sinh và chuẩn bị cần thiết. Khi triển khai, giáo viên phải tổ chức chuyển tiếp hợp lý, không cắt giảm thời gian nghỉ ngơi cần thiết của trẻ.

---

**3. Đối với lớp mẫu giáo không bán trú**

Nhà trường phải có sự phối hợp chặt chẽ với phụ huynh trong việc tổ chức ăn và ngủ tại nhà. Không nên dùng lịch này để đối chiếu máy móc với khung thời lượng dành cho một ngày sinh hoạt đầy đủ tại trường.

---

**4. Về quản lý đội ngũ và tổ chức thực hiện**

Lịch hoạt động của trẻ từ 7h00 đến 17h00 không đồng nghĩa một giáo viên phải làm việc liên tục 10 giờ. Hiệu trưởng cần phân công đón, trả trẻ, trực trưa và bố trí nhân sự phù hợp với Thông tư 11/2026/TT-BGDĐT về chế độ làm việc của giáo viên mầm non. [Bộ Giáo Dục và Đào Tạo](<https://vbpl.moj.gov.vn/bogiaoducdaotao/Pages/vbpq-toanvan.aspx?ItemID=187963&dvid=317>); [TOÀN VĂN: Thông tư 11/2026/TT\-BGDĐT quy định chế độ làm việc với giáo viên mầm non](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-11-2026-tt-bgddt-quy-dinh-che-do-lam-viec-voi-giao-vien-mam-non-119260305102619461.htm>)

### ✅ Kết luận và đề xuất

Với vai trò hiệu trưởng, tôi đề xuất nhà trường **sử dụng ba bảng đã hoàn thiện làm dự thảo lịch sinh hoạt chung**, sau đó tổ chức lấy ý kiến các tổ chuyên môn và thống nhất giờ thực hiện trước khi phê duyệt.

Đặc biệt, lịch mẫu giáo bán trú nên được triển khai có sự linh hoạt về cách tổ chức hoạt động theo độ tuổi 3–4, 4–5 và 5–6 tuổi. Khung 30 phút hoạt động học không có nghĩa tất cả trẻ đều phải ngồi học liên tục 30 phút.

Khi đưa vào hồ sơ chính thức, nhà trường cần kiểm tra thêm giờ cung cấp suất ăn, điều kiện tổ chức ngủ, thời tiết và thời gian đón trả trẻ thực tế để lịch vừa bám sát chương trình, vừa khả thi và bảo đảm quyền lợi của trẻ.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

ASSISTANT

---

USER

dựa vào lịch sinh hoạt và 2 văn bản đính kèm. bạn hya4 giúp tôi dự trù kinh phí và phương án trả thừa giờ theo nội dung văn bản yêu cầu

---

ASSISTANT

Tôi sẽ lấy lịch sinh hoạt năm học 2026–2027 làm cơ sở xác định thời gian giáo viên trực tiếp phụ trách trẻ, rồi áp dụng hướng dẫn tại Công văn 4172 của Sở GDĐT Đồng Tháp và Công văn 6347 của UBND phường An Bình. Phần dự toán sẽ tách rõ **giờ trông trẻ buổi trưa được quy đổi**, **giờ dạy vượt định mức thực tế** và **nguồn kinh phí chi trả**, để tránh tính trùng hoặc dự toán vượt căn cứ.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 PHƯƠNG ÁN DỰ TRÙ KINH PHÍ VÀ CHI TRẢ TIỀN LƯƠNG DẠY THÊM GIỜ NĂM HỌC 2026–2027

**Đơn vị: Trường Mầm non An Bình – Phường An Bình, tỉnh Đồng Tháp**

Sau khi đối chiếu lịch sinh hoạt năm học 2026–2027 với Công văn số 4172/SGDĐT-GDMN ngày 21/10/2026 của Sở GDĐT Đồng Tháp và Công văn số 6347/VP-VX ngày 23/10/2026 của Văn phòng HĐND và UBND phường An Bình, tôi đề xuất nhà trường xây dựng phương án theo hướng:

**Quy đổi giờ trông trẻ buổi trưa trước, xác định giờ dạy vượt định mức sau, rồi mới tính tiền và lập dự toán kinh phí.**

Đây là điểm rất quan trọng để bảo đảm quyền lợi giáo viên nhưng không tính thừa kinh phí khi quyết toán.

## 1. Các quy định cần áp dụng

| Nội dung | Quy định áp dụng |
|--------|--------|
| Thời gian làm việc | 40 giờ/tuần, bao gồm giờ dạy và những công việc nghề nghiệp khác |
| Định mức giáo viên dạy 2 buổi/ngày | 5 giờ 30 phút/ngày |
| Định mức giáo viên dạy 1 buổi/ngày | 4 giờ/ngày |
| Trông trẻ buổi trưa | Mỗi giáo viên được phân công được quy đổi không quá 2 giờ dạy/buổi |
| Thẩm quyền quy đổi | Hiệu trưởng quyết định bằng văn bản, sau khi thông qua cuộc họp tập thể giáo viên |
| Tiền lương dạy thêm giờ | Bằng 150% tiền lương của 1 giờ dạy theo công thức tại Thông tư 21/2025/TT-BGDĐT |
| Giới hạn thanh toán | Thông thường không quá 200 giờ dạy thêm/giáo viên/năm học, đồng thời tuân thủ giới hạn toàn trường |
| Nguồn kinh phí | Nguồn tài chính hợp pháp của đơn vị sự nghiệp công lập theo cơ chế tự chủ tài chính |

Các nội dung trên được hướng dẫn trong Công văn 4172 và phù hợp với Thông tư 11/2026/TT-BGDĐT, Thông tư 21/2025/TT-BGDĐT. [Bộ Giáo Dục và Đào Tạo](<https://vbpl.moj.gov.vn/bogiaoducdaotao/Pages/vbpq-toanvan.aspx?ItemID=187963&dvid=317>); [Thông tư 21/2025/TT\-BGDĐT quy định chế độ trả tiền lương dạy thêm giờ với nhà giáo trong các cơ sở giáo dục công lập](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-21-2025-tt-bgddt-quy-dinh-che-do-tra-tien-luong-day-them-gio-voi-nha-giao-trong-cac-co-so-giao-duc-cong-lap-119250923202359853.htm>)

## 2. Đối chiếu lịch sinh hoạt với việc tính thừa giờ

| Đối tượng | Thời gian sinh hoạt | Thời gian ngủ trưa | Định hướng tính giờ |
|--------|--------|--------|--------|
| Nhà trẻ 24–36 tháng | 7h00–17h00 | 11h00–13h30 (150 phút) | Được xem xét quy đổi giờ trông trẻ buổi trưa |
| Mẫu giáo bán trú | 7h00–17h00 | 11h30–14h00 (150 phút) | Được xem xét quy đổi giờ trông trẻ buổi trưa |
| Mẫu giáo 2 buổi/ngày không bán trú | 7h00–11h00 và 14h00–17h00 | Trẻ nghỉ tại nhà | Không phát sinh giờ quy đổi trông trẻ buổi trưa tại trường |

**Hai điểm cần phân biệt:**

- Giáo viên được phân công trực 150 phút giờ ngủ trưa không đương nhiên được thanh toán 150 phút thừa giờ. Mức quy đổi tối đa là 120 phút (2 giờ dạy) mỗi buổi; số giờ được duyệt còn phụ thuộc số trẻ, thời gian thực tế và phân công.
- Thời gian đón, trả trẻ thuộc thời gian làm việc của giáo viên nhưng **không nằm trong định mức giờ dạy** theo Điều 3 Thông tư 11/2026/TT-BGDĐT. Vì vậy, không thể lấy 10 giờ trẻ ở trường trừ 5 giờ 30 phút để xác định 4 giờ 30 phút thừa giờ cho mỗi giáo viên. [TOÀN VĂN: Thông tư 11/2026/TT\-BGDĐT quy định chế độ làm việc với giáo viên mầm non](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-11-2026-tt-bgddt-quy-dinh-che-do-lam-viec-voi-giao-vien-mam-non-119260305102619461.htm>); [Hướng dẫn cách quy đổi hoạt động chuyên môn ra giờ dạy](<https://xaydungchinhsach.chinhphu.vn/huong-dan-cach-quy-doi-hoat-dong-chuyen-mon-ra-gio-day-119260305114921557.htm>)

**Lưu ý về lịch 2 buổi/ngày không bán trú**

Trong bản Word mới, buổi sáng ghi 7h00–11h00, buổi chiều 14h00–17h00, tổng thực tế là **7 giờ/ngày (420 phút)**. Tuy nhiên, cuối bảng lại ghi 390 phút và trả trẻ buổi sáng lúc 10h30. Ngoài ra, khoảng 15h40–16h30 là 50 phút nhưng ghi 30 phút.

Nhà trường cần thống nhất, sửa những sai lệch này trước khi dùng lịch làm chứng từ xác định giờ làm việc và giờ dạy.

## 3. Dự trù kinh phí năm học 2026–2027

### 3.1. Công thức tính kinh phí

Đối với giáo viên dạy 2 buổi/ngày, làm việc đủ 35 tuần dạy trẻ trong năm học, định mức thông thường là:

\[
5,5\times5\times35=962,5\text{ giờ/năm học}
\]

Số giờ dạy thêm được xác định bằng tổng giờ dạy thực tế, giờ quy đổi và các giờ được tính theo quy định, sau khi trừ định mức năm học đã điều chỉnh (nếu thuộc diện được giảm định mức).

Theo Điều 5 Thông tư 21/2025/TT-BGDĐT:

\[
\text{Lương 1 giờ dạy}
=\frac{\text{Tổng lương 12 tháng}}{\text{Định mức năm}}
\times\frac{35}{52}
\]

\[
\text{Lương 1 giờ dạy thêm}
=\text{Lương 1 giờ dạy}\times150\%
\]

[Thông tư 21/2025/TT\-BGDĐT quy định chế độ trả tiền lương dạy thêm giờ với nhà giáo trong các cơ sở giáo dục công lập](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-21-2025-tt-bgddt-quy-dinh-che-do-tra-tien-luong-day-them-gio-voi-nha-giao-trong-cac-co-so-giao-duc-cong-lap-119250923202359853.htm>); [QUY ĐỊNH MỚI về chế độ làm việc giáo viên mầm non](<https://xaydungchinhsach.chinhphu.vn/che-do-lam-viec-giao-vien-mam-non-quy-dinh-moi-ve-thoi-gian-nghi-hang-nam-dinh-muc-gio-day-119260305110931247.htm>)

### 3.2. Bảng dự toán minh họa

Vì hồ sơ chưa có số lớp bán trú, số giáo viên được phân công trông trẻ buổi trưa, bảng lương và số ngày trực của từng người, tôi lập một **phương án minh họa có thể thay đổi số liệu**, chưa phải số kinh phí thực tế của Trường Mầm non An Bình.

Giả định một giáo viên có tiền lương bình quân tính theo chế độ dạy thêm giờ là 9.000.000 đồng/tháng, dạy thực tế 4,5 giờ/ngày (không bao gồm đón, trả và trực trưa), làm đủ 175 ngày; không có giờ giảm định mức và không có các giờ quy đổi khác.

| Mức quy đổi trưa | Giờ vượt định mức/năm | Kinh phí 1 giáo viên/năm |
|--------|--------|--------|
| 1 giờ/buổi | 0 giờ | 0 đồng |
| 1,5 giờ/buổi | 87,5 giờ | 9.912.587 đồng |
| 2 giờ/buổi | 175 giờ | 19.825.175 đồng |

Các mức quy đổi là kịch bản để lập dự toán, không phải mức ấn định cho giáo viên. Số giờ được thanh toán thực tế còn phải đối chiếu định mức và giới hạn toàn trường theo Thông tư 21/2025/TT-BGDĐT.

### 3.3. Công cụ tính dự trù theo số liệu của trường

Có thể thay đổi các thông số dưới đây để ước tính nhu cầu kinh phí, trước khi kiểm tra trần giờ dạy thêm của toàn trường.

Số giáo viên cùng giả định

[Giá trị đầu vào không khả dụng]

Lương bình quân tháng (đồng)

[Giá trị đầu vào không khả dụng]

Giờ dạy thực tế bình quân/ngày

[Giá trị đầu vào không khả dụng]

Số buổi trực trưa/giáo viên/năm

[Giá trị đầu vào không khả dụng]

Giờ quy đổi mỗi buổi trực trưa

[Giá trị đầu vào không khả dụng]

Giờ giảm định mức/năm

[Giá trị đầu vào không khả dụng]

Giờ được tính thêm hoặc quy đổi khác/năm

[Giá trị đầu vào không khả dụng]

**Cách sử dụng:** Ô số giáo viên dành cho nhóm có giả định giống nhau; nếu hệ số lương, số buổi trực hoặc mức giảm định mức khác nhau, phải tính riêng từng giáo viên rồi cộng lại. Kết quả mới là dự toán ban đầu, không phải số tiền được tự động phê duyệt.

## 4. Phương án tổ chức và chi trả đề xuất trình nhà trường

Tôi đề xuất **phương án phân công giáo viên lệch ca, ghi nhận giờ dạy thực tế và quy đổi giờ trực trưa theo quyết định của hiệu trưởng**. Cách này vừa bảo đảm có người chăm sóc trẻ trong suốt ngày học, vừa giúp nhà trường kiểm soát kinh phí phát sinh.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**
>
> **TRƯỜNG MẦM NON AN BÌNH**
>
> Số: …/PA-MNAB
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**
>
> **Độc lập – Tự do – Hạnh phúc**
>
> *An Bình, ngày … tháng … năm 2026*
>
> # PHƯƠNG ÁN
> ## Phân công giáo viên, quy đổi giờ trông trẻ buổi trưa và dự toán kinh phí chi trả tiền lương dạy thêm giờ năm học 2026–2027
>
> ### I. CĂN CỨ XÂY DỰNG PHƯƠNG ÁN
>
> Căn cứ Thông tư số 11/2026/TT-BGDĐT ngày 04/3/2026 của Bộ Giáo dục và Đào tạo quy định chế độ làm việc đối với giáo viên mầm non;
>
> Căn cứ Thông tư số 21/2025/TT-BGDĐT ngày 23/9/2025 của Bộ Giáo dục và Đào tạo quy định chế độ trả tiền lương dạy thêm giờ đối với nhà giáo trong các cơ sở giáo dục công lập;
>
> Căn cứ Quyết định số 105/2026/QĐ-UBND ngày 11/9/2026 của UBND tỉnh Đồng Tháp quy định các khoản thu, mức thu và cơ chế quản lý thu, chi đối với các dịch vụ phục vụ hoạt động giáo dục, đào tạo trong cơ sở giáo dục công lập;
>
> Căn cứ Công văn số 4172/SGDĐT-GDMN ngày 21/10/2026 của Sở Giáo dục và Đào tạo Đồng Tháp;
>
> Thực hiện Công văn số 6347/VP-VX ngày 23/10/2026 của Văn phòng HĐND và UBND phường An Bình;
>
> Căn cứ tình hình tổ chức các nhóm, lớp, đội ngũ giáo viên và kế hoạch chăm sóc, nuôi dưỡng, giáo dục trẻ năm học 2026–2027.
>
> Trường Mầm non An Bình xây dựng phương án thực hiện như sau:
>
> ### II. MỤC ĐÍCH, YÊU CẦU
>
> 1. Bố trí giáo viên phù hợp chế độ sinh hoạt của trẻ, bảo đảm an toàn tuyệt đối trong hoạt động chăm sóc, nuôi dưỡng và giáo dục.
> 2. Thực hiện đúng chế độ làm việc 40 giờ/tuần và định mức giờ dạy đối với giáo viên mầm non.
> 3. Bảo đảm việc quy đổi giờ trông trẻ buổi trưa công khai, minh bạch, công bằng, có căn cứ thực tế.
> 4. Xác định đúng số giờ dạy thêm phát sinh, xây dựng dự toán kinh phí phù hợp khả năng tài chính của nhà trường.
> 5. Không tính trùng giờ dạy, giờ quy đổi hoặc các nhiệm vụ đã được thanh toán theo chế độ khác.
>
> ### III. TÌNH HÌNH THỰC TẾ CỦA NHÀ TRƯỜNG
>
> Các nội dung cần tổng hợp trước khi phê duyệt:
>
> | Nội dung | Số lượng |
> |---|---|
> | Tổng số nhóm, lớp | … |
> | Số nhóm nhà trẻ bán trú | … |
> | Số lớp mẫu giáo bán trú | … |
> | Số lớp mẫu giáo không bán trú | … |
> | Tổng số giáo viên thuộc diện tính chế độ | … |
> | Số giáo viên trực tiếp tham gia trông trẻ buổi trưa | … |
> | Số trẻ đăng ký ở lại bán trú | … |
> | Số ngày tổ chức dạy trẻ dự kiến trong năm học | … |
> | Nguồn tài chính dự kiến cân đối | … đồng |
>
> ### IV. PHƯƠNG ÁN BỐ TRÍ GIÁO VIÊN
>
> **1. Đối với nhóm nhà trẻ bán trú**
>
> Thời gian sinh hoạt của trẻ từ 7h00 đến 17h00, trong đó trẻ ngủ trưa từ 11h00 đến 13h30.
>
> Giáo viên được phân công thực hiện nhiệm vụ chăm sóc, nuôi dưỡng và giáo dục trẻ theo thời gian biểu. Việc bố trí giáo viên trông trẻ buổi trưa phải bảo đảm có người trực tiếp quan sát, theo dõi, xử lý kịp thời các tình huống phát sinh.
>
> **2. Đối với lớp mẫu giáo bán trú**
>
> Thời gian sinh hoạt từ 7h00 đến 17h00, trong đó thời gian ngủ trưa từ 11h30 đến 14h00.
>
> Nhà trường chủ động bố trí giáo viên lệch ca, luân phiên đón trẻ, trả trẻ và trông trẻ buổi trưa. Ví dụ nghiên cứu phương án một giáo viên phụ trách ca 7h00–15h00 và giáo viên còn lại phụ trách ca 9h00–17h00, có bố trí nghỉ phù hợp và bảo đảm trẻ luôn được giám sát.
>
> Việc phân công một hoặc nhiều giáo viên trực trưa căn cứ số trẻ thực tế, yêu cầu bảo đảm an toàn, điều kiện cơ sở vật chất và đội ngũ hiện có.
>
> **3. Đối với lớp mẫu giáo không bán trú**
>
> Tổ chức đón, trả trẻ theo lịch học 2 buổi/ngày được nhà trường phê duyệt.
>
> Không thực hiện quy đổi giờ trông trẻ buổi trưa đối với thời gian trẻ nghỉ tại gia đình. Trường hợp giáo viên phát sinh giờ dạy thêm do các nhiệm vụ khác phải có phân công và chứng từ riêng.
>
> ### V. PHƯƠNG ÁN QUY ĐỔI GIỜ TRÔNG TRẺ BUỔI TRƯA
>
> **1. Nguyên tắc**
>
> Giáo viên được phân công trực tiếp trông trẻ buổi trưa được xem xét quy đổi thời gian thực hiện nhiệm vụ thành giờ dạy, tối đa 02 giờ dạy/buổi/giáo viên.
>
> Số giờ quy đổi cụ thể phải phù hợp với số lượng trẻ ở lại bán trú, thời gian thực hiện nhiệm vụ và yêu cầu tổ chức chăm sóc trẻ.
>
> Không thực hiện quy đổi đồng loạt 02 giờ cho tất cả giáo viên nếu chưa có căn cứ phân công và thực hiện nhiệm vụ thực tế.
>
> **2. Phương án quy đổi đề xuất**
>
> Nhà trường tổ chức họp tập thể giáo viên để thảo luận, thống nhất nguyên tắc. Trên cơ sở đó, hiệu trưởng quyết định bằng văn bản mức quy đổi áp dụng cho từng hình thức phân công.
>
> Khi lập dự toán có thể tính toán các kịch bản 01 giờ, 01 giờ 30 phút và 02 giờ/buổi. Đây chỉ là các kịch bản kinh phí; mức áp dụng chính thức do hiệu trưởng quyết định theo quy định.
>
> **3. Hồ sơ xác nhận**
>
> - Quyết định phân công giáo viên trông trẻ buổi trưa.
> - Biên bản họp tập thể giáo viên về việc quy đổi.
> - Quyết định của hiệu trưởng về mức giờ quy đổi.
> - Danh sách và số trẻ thực tế ở lại bán trú.
> - Bảng theo dõi, xác nhận việc thực hiện nhiệm vụ hằng ngày.
>
> ### VI. XÁC ĐỊNH GIỜ DẠY THÊM VÀ DỰ TOÁN KINH PHÍ
>
> **1. Xác định định mức**
>
> Đối với giáo viên làm việc đủ năm học, dạy 2 buổi/ngày:
>
> Định mức năm học thông thường = 5,5 giờ/ngày × 5 ngày/tuần × 35 tuần = 962,5 giờ.
>
> Giáo viên thuộc diện giảm định mức, được tính đủ định mức hoặc có thời gian công tác không đủ năm học phải được xác định riêng theo quy định.
>
> **2. Xác định số giờ dạy thêm**
>
> Số giờ dạy thêm trước khi áp dụng giới hạn thanh toán được xác định bằng:
>
> Tổng giờ giảng dạy thực tế trong năm học + giờ quy đổi trông trẻ buổi trưa + các giờ được quy đổi hoặc tính thêm hợp pháp khác + giờ được tính dạy đủ (nếu có) – định mức giờ dạy phải thực hiện trong năm học.
>
> Chỉ xác định kinh phí thanh toán sau khi kiểm tra số giờ dạy thêm của từng giáo viên và tổng số giờ dạy thêm tối đa của toàn trường.
>
> **3. Dự toán minh họa**
>
> Giả định có 10 giáo viên có mức lương bình quân làm căn cứ là 9.000.000 đồng/tháng, mỗi giáo viên thực dạy 4,5 giờ/ngày trong 175 ngày, được quy đổi 1,5 giờ cho mỗi buổi trực trưa, không có chế độ giảm định mức và các giờ quy đổi khác:
>
> | Chỉ tiêu | Dự toán minh họa |
> |---|---:|
> | Số giáo viên | 10 người |
> | Giờ vượt định mức/giáo viên | 87,5 giờ |
> | Tổng giờ vượt định mức của 10 giáo viên | 875 giờ |
> | Tiền lương 1 giờ dạy thêm bình quân | 113.287 đồng |
> | Tổng nhu cầu kinh phí ước tính | 99.125.874 đồng |
>
> **Số kinh phí 99.125.874 đồng chỉ là giả định để tham khảo**, chưa phải kinh phí đề nghị phê duyệt hoặc thanh toán thực tế.
>
> Dự toán chính thức được lập căn cứ bảng lương, bảng phân công, giờ quy đổi, chế độ giảm định mức và số giờ dạy thêm đủ điều kiện thanh toán của từng giáo viên.
>
> **4. Nguyên tắc khống chế kinh phí**
>
> Số giờ thanh toán của mỗi giáo viên không vượt giới hạn theo Thông tư 21/2025/TT-BGDĐT, trừ trường hợp ngoại lệ được xử lý theo đúng quy định.
>
> Tổng giờ thanh toán của nhà trường phải phù hợp mức tối đa xác định theo Điều 4 Thông tư 21/2025/TT-BGDĐT.
>
> ### VII. NGUỒN KINH PHÍ VÀ PHƯƠNG THỨC CHI TRẢ
>
> **1. Nguồn kinh phí**
>
> Kinh phí chi trả tiền lương dạy thêm giờ được bố trí từ nguồn tài chính hợp pháp của nhà trường theo cơ chế tự chủ tài chính áp dụng đối với đơn vị sự nghiệp công lập.
>
> Nhà trường giao bộ phận kế toán rà soát dự toán đã giao, nguồn tài chính được phép sử dụng, khả năng cân đối và các khoản thu, chi liên quan.
>
> Các khoản thu, chi dịch vụ bán trú theo Quyết định 105/2026/QĐ-UBND phải được hạch toán và quản lý đúng mục đích; không chi trùng cho cùng một nhiệm vụ đã được thanh toán theo chế độ khác.
>
> **2. Phương thức chi trả**
>
> Thực hiện đối chiếu giờ dạy thực tế, giờ quy đổi và chế độ giảm định mức theo từng tháng; tổng hợp theo học kỳ, quyết toán theo năm học.
>
> Tiền lương dạy thêm giờ được xác định và thanh toán sau khi kết thúc năm học. Trường hợp nhà trường thực hiện tạm ứng theo tháng hoặc học kỳ phải bảo đảm điều kiện, chứng từ và quyết toán theo quy định.
>
> **3. Công khai tài chính**
>
> Việc lập dự toán, sử dụng nguồn kinh phí, thanh toán và quyết toán bảo đảm công khai, minh bạch, đúng đối tượng, đúng chế độ; chịu sự kiểm tra, giám sát theo quy định.
>
> ### VIII. TỔ CHỨC THỰC HIỆN
>
> **1. Hiệu trưởng**
>
> Chỉ đạo rà soát lịch sinh hoạt, bố trí nhân sự, tổ chức họp tập thể giáo viên, ban hành quyết định về mức quy đổi và phương án phân công; phê duyệt số giờ đủ điều kiện theo thẩm quyền.
>
> **2. Phó hiệu trưởng phụ trách chuyên môn**
>
> Phối hợp các tổ chuyên môn xây dựng lịch phân công cụ thể theo từng lớp, kiểm tra hồ sơ thực hiện và tổng hợp giờ dạy, giờ trông trẻ buổi trưa.
>
> **3. Bộ phận kế toán**
>
> Đối chiếu bảng lương, xác định đơn giá tiền lương dạy thêm giờ của từng giáo viên; tổng hợp dự toán toàn trường, kiểm tra nguồn kinh phí và thực hiện thủ tục thanh toán, quyết toán.
>
> **4. Tổ trưởng chuyên môn và giáo viên**
>
> Thực hiện đúng phân công; ghi nhận chính xác thời gian giảng dạy, trông trẻ buổi trưa; phối hợp cung cấp chứng từ và xác nhận số liệu.
>
> ### IX. KIẾN NGHỊ
>
> Trường Mầm non An Bình đề nghị UBND phường An Bình và cơ quan chuyên môn có liên quan xem xét, hướng dẫn những vấn đề phát sinh về nguồn kinh phí và việc tổ chức thực hiện chế độ dạy thêm giờ trong điều kiện thực tế của nhà trường.
>
> Trường cam kết triển khai đúng quy định, bảo đảm quyền lợi giáo viên, sử dụng kinh phí tiết kiệm, hiệu quả, công khai và đúng mục đích.
>
> **Nơi nhận:**
>
> - UBND phường An Bình (báo cáo);
> - Phòng Văn hóa – Xã hội (phối hợp);
> - Các bộ phận liên quan;
> - Lưu: VT, hồ sơ tài chính.
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên và đóng dấu)*

## 5. Hồ sơ hiệu trưởng cần hoàn thiện trước khi chi trả

Tôi lưu ý thêm: Quyết định 105/2026/QĐ-UBND có quy định mức thu dịch vụ bán trú khác nhau theo địa bàn, quy mô lớp và hình thức tổ chức nấu ăn. Việc dùng nguồn thu này phải được dự toán, hạch toán đúng mục đích và không chi trả trùng một nhiệm vụ. [Quyết định 105/2026/QĐ\-UBND khoản thu chi đối với các dịch vụ phục vụ hoạt động giáo dục Đồng Tháp](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Quyet-dinh-105-2026-QD-UBND-khoan-thu-chi-doi-voi-cac-dich-vu-phuc-vu-hoat-dong-giao-duc-Dong-Thap-724669.aspx?tab=3>); [Thông tư 21/2025/TT\-BGDĐT quy định chế độ trả tiền lương dạy thêm giờ với nhà giáo trong các cơ sở giáo dục công lập](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-21-2025-tt-bgddt-quy-dinh-che-do-tra-tien-luong-day-them-gio-voi-nha-giao-trong-cac-co-so-giao-duc-cong-lap-119250923202359853.htm>)

**Tiến độ chuẩn bị hồ sơ** /7

## ✅ Kết luận và số liệu cần bổ sung

Phương án trên có thể dùng làm dự thảo trình lãnh đạo nhà trường. Tuy nhiên, **chưa thể kết luận số kinh phí thực tế phải chi** vì hồ sơ hiện có mới cung cấp lịch sinh hoạt và căn cứ pháp lý, chưa có dữ liệu nhân sự và tiền lương.

Để tính chính xác cho Trường Mầm non An Bình, cần bổ sung bốn nhóm thông tin: số lớp bán trú và không bán trú; số giáo viên ở từng lớp và số trẻ ở lại trưa; bảng lương làm căn cứ tính dạy thêm giờ của giáo viên; bảng phân công, số buổi trực trưa và các trường hợp được giảm định mức.

Từ những dữ liệu đó mới lập được **bảng dự toán chi tiết từng giáo viên, tổng hợp kinh phí toàn trường và phương án cân đối nguồn chi** có đủ cơ sở để trình phê duyệt.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

## 4. Phương án tổ chức và chi trả đề xuất trình nhà trường

Tôi đề xuất **phương án phân công giáo viên lệch ca, ghi nhận giờ dạy thực tế và quy đổi giờ trực trưa theo quyết định của hiệu trưởng**. Cách này vừa bảo đảm có người chăm sóc trẻ trong suốt ngày học, vừa giúp nhà trường kiểm soát kinh phí phát sinh.

<WritingBlock id="75382" variant="document">**UBND PHƯỜNG AN BÌNH**

**TRƯỜNG MẦM NON AN BÌNH**

Số: …/PA-MNAB

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**

**Độc lập – Tự do – Hạnh phúc**

*An Bình, ngày … tháng … năm 2026*

# PHƯƠNG ÁN
## Phân công giáo viên, quy đổi giờ trông trẻ buổi trưa và dự toán kinh phí chi trả tiền lương dạy thêm giờ năm học 2026–2027

### I. CĂN CỨ XÂY DỰNG PHƯƠNG ÁN

Căn cứ Thông tư số 11/2026/TT-BGDĐT ngày 04/3/2026 của Bộ Giáo dục và Đào tạo quy định chế độ làm việc đối với giáo viên mầm non;

Căn cứ Thông tư số 21/2025/TT-BGDĐT ngày 23/9/2025 của Bộ Giáo dục và Đào tạo quy định chế độ trả tiền lương dạy thêm giờ đối với nhà giáo trong các cơ sở giáo dục công lập;

Căn cứ Quyết định số 105/2026/QĐ-UBND ngày 11/9/2026 của UBND tỉnh Đồng Tháp quy định các khoản thu, mức thu và cơ chế quản lý thu, chi đối với các dịch vụ phục vụ hoạt động giáo dục, đào tạo trong cơ sở giáo dục công lập;

Căn cứ Công văn số 4172/SGDĐT-GDMN ngày 21/10/2026 của Sở Giáo dục và Đào tạo Đồng Tháp;

Thực hiện Công văn số 6347/VP-VX ngày 23/10/2026 của Văn phòng HĐND và UBND phường An Bình;

Căn cứ tình hình tổ chức các nhóm, lớp, đội ngũ giáo viên và kế hoạch chăm sóc, nuôi dưỡng, giáo dục trẻ năm học 2026–2027.

Trường Mầm non An Bình xây dựng phương án thực hiện như sau:

### II. MỤC ĐÍCH, YÊU CẦU

1. Bố trí giáo viên phù hợp chế độ sinh hoạt của trẻ, bảo đảm an toàn tuyệt đối trong hoạt động chăm sóc, nuôi dưỡng và giáo dục.
2. Thực hiện đúng chế độ làm việc 40 giờ/tuần và định mức giờ dạy đối với giáo viên mầm non.
3. Bảo đảm việc quy đổi giờ trông trẻ buổi trưa công khai, minh bạch, công bằng, có căn cứ thực tế.
4. Xác định đúng số giờ dạy thêm phát sinh, xây dựng dự toán kinh phí phù hợp khả năng tài chính của nhà trường.
5. Không tính trùng giờ dạy, giờ quy đổi hoặc các nhiệm vụ đã được thanh toán theo chế độ khác.

### III. TÌNH HÌNH THỰC TẾ CỦA NHÀ TRƯỜNG

Các nội dung cần tổng hợp trước khi phê duyệt:

| Nội dung | Số lượng |
|---|---|
| Tổng số nhóm, lớp | … |
| Số nhóm nhà trẻ bán trú | … |
| Số lớp mẫu giáo bán trú | … |
| Số lớp mẫu giáo không bán trú | … |
| Tổng số giáo viên thuộc diện tính chế độ | … |
| Số giáo viên trực tiếp tham gia trông trẻ buổi trưa | … |
| Số trẻ đăng ký ở lại bán trú | … |
| Số ngày tổ chức dạy trẻ dự kiến trong năm học | … |
| Nguồn tài chính dự kiến cân đối | … đồng |

### IV. PHƯƠNG ÁN BỐ TRÍ GIÁO VIÊN

**1. Đối với nhóm nhà trẻ bán trú**

Thời gian sinh hoạt của trẻ từ 7h00 đến 17h00, trong đó trẻ ngủ trưa từ 11h00 đến 13h30.

Giáo viên được phân công thực hiện nhiệm vụ chăm sóc, nuôi dưỡng và giáo dục trẻ theo thời gian biểu. Việc bố trí giáo viên trông trẻ buổi trưa phải bảo đảm có người trực tiếp quan sát, theo dõi, xử lý kịp thời các tình huống phát sinh.

**2. Đối với lớp mẫu giáo bán trú**

Thời gian sinh hoạt từ 7h00 đến 17h00, trong đó thời gian ngủ trưa từ 11h30 đến 14h00.

Nhà trường chủ động bố trí giáo viên lệch ca, luân phiên đón trẻ, trả trẻ và trông trẻ buổi trưa. Ví dụ nghiên cứu phương án một giáo viên phụ trách ca 7h00–15h00 và giáo viên còn lại phụ trách ca 9h00–17h00, có bố trí nghỉ phù hợp và bảo đảm trẻ luôn được giám sát.

Việc phân công một hoặc nhiều giáo viên trực trưa căn cứ số trẻ thực tế, yêu cầu bảo đảm an toàn, điều kiện cơ sở vật chất và đội ngũ hiện có.

**3. Đối với lớp mẫu giáo không bán trú**

Tổ chức đón, trả trẻ theo lịch học 2 buổi/ngày được nhà trường phê duyệt.

Không thực hiện quy đổi giờ trông trẻ buổi trưa đối với thời gian trẻ nghỉ tại gia đình. Trường hợp giáo viên phát sinh giờ dạy thêm do các nhiệm vụ khác phải có phân công và chứng từ riêng.

### V. PHƯƠNG ÁN QUY ĐỔI GIỜ TRÔNG TRẺ BUỔI TRƯA

**1. Nguyên tắc**

Giáo viên được phân công trực tiếp trông trẻ buổi trưa được xem xét quy đổi thời gian thực hiện nhiệm vụ thành giờ dạy, tối đa 02 giờ dạy/buổi/giáo viên.

Số giờ quy đổi cụ thể phải phù hợp với số lượng trẻ ở lại bán trú, thời gian thực hiện nhiệm vụ và yêu cầu tổ chức chăm sóc trẻ.

Không thực hiện quy đổi đồng loạt 02 giờ cho tất cả giáo viên nếu chưa có căn cứ phân công và thực hiện nhiệm vụ thực tế.

**2. Phương án quy đổi đề xuất**

Nhà trường tổ chức họp tập thể giáo viên để thảo luận, thống nhất nguyên tắc. Trên cơ sở đó, hiệu trưởng quyết định bằng văn bản mức quy đổi áp dụng cho từng hình thức phân công.

Khi lập dự toán có thể tính toán các kịch bản 01 giờ, 01 giờ 30 phút và 02 giờ/buổi. Đây chỉ là các kịch bản kinh phí; mức áp dụng chính thức do hiệu trưởng quyết định theo quy định.

**3. Hồ sơ xác nhận**

- Quyết định phân công giáo viên trông trẻ buổi trưa.
- Biên bản họp tập thể giáo viên về việc quy đổi.
- Quyết định của hiệu trưởng về mức giờ quy đổi.
- Danh sách và số trẻ thực tế ở lại bán trú.
- Bảng theo dõi, xác nhận việc thực hiện nhiệm vụ hằng ngày.

### VI. XÁC ĐỊNH GIỜ DẠY THÊM VÀ DỰ TOÁN KINH PHÍ

**1. Xác định định mức**

Đối với giáo viên làm việc đủ năm học, dạy 2 buổi/ngày:

Định mức năm học thông thường = 5,5 giờ/ngày × 5 ngày/tuần × 35 tuần = 962,5 giờ.

Giáo viên thuộc diện giảm định mức, được tính đủ định mức hoặc có thời gian công tác không đủ năm học phải được xác định riêng theo quy định.

**2. Xác định số giờ dạy thêm**

Số giờ dạy thêm trước khi áp dụng giới hạn thanh toán được xác định bằng:

Tổng giờ giảng dạy thực tế trong năm học + giờ quy đổi trông trẻ buổi trưa + các giờ được quy đổi hoặc tính thêm hợp pháp khác + giờ được tính dạy đủ (nếu có) – định mức giờ dạy phải thực hiện trong năm học.

Chỉ xác định kinh phí thanh toán sau khi kiểm tra số giờ dạy thêm của từng giáo viên và tổng số giờ dạy thêm tối đa của toàn trường.

**3. Dự toán minh họa**

Giả định có 10 giáo viên có mức lương bình quân làm căn cứ là 9.000.000 đồng/tháng, mỗi giáo viên thực dạy 4,5 giờ/ngày trong 175 ngày, được quy đổi 1,5 giờ cho mỗi buổi trực trưa, không có chế độ giảm định mức và các giờ quy đổi khác:

| Chỉ tiêu | Dự toán minh họa |
|---|---:|
| Số giáo viên | 10 người |
| Giờ vượt định mức/giáo viên | 87,5 giờ |
| Tổng giờ vượt định mức của 10 giáo viên | 875 giờ |
| Tiền lương 1 giờ dạy thêm bình quân | 113.287 đồng |
| Tổng nhu cầu kinh phí ước tính | 99.125.874 đồng |

**Số kinh phí 99.125.874 đồng chỉ là giả định để tham khảo**, chưa phải kinh phí đề nghị phê duyệt hoặc thanh toán thực tế.

Dự toán chính thức được lập căn cứ bảng lương, bảng phân công, giờ quy đổi, chế độ giảm định mức và số giờ dạy thêm đủ điều kiện thanh toán của từng giáo viên.

**4. Nguyên tắc khống chế kinh phí**

Số giờ thanh toán của mỗi giáo viên không vượt giới hạn theo Thông tư 21/2025/TT-BGDĐT, trừ trường hợp ngoại lệ được xử lý theo đúng quy định.

Tổng giờ thanh toán của nhà trường phải phù hợp mức tối đa xác định theo Điều 4 Thông tư 21/2025/TT-BGDĐT.

### VII. NGUỒN KINH PHÍ VÀ PHƯƠNG THỨC CHI TRẢ

**1. Nguồn kinh phí**

Kinh phí chi trả tiền lương dạy thêm giờ được bố trí từ nguồn tài chính hợp pháp của nhà trường theo cơ chế tự chủ tài chính áp dụng đối với đơn vị sự nghiệp công lập.

Nhà trường giao bộ phận kế toán rà soát dự toán đã giao, nguồn tài chính được phép sử dụng, khả năng cân đối và các khoản thu, chi liên quan.

Các khoản thu, chi dịch vụ bán trú theo Quyết định 105/2026/QĐ-UBND phải được hạch toán và quản lý đúng mục đích; không chi trùng cho cùng một nhiệm vụ đã được thanh toán theo chế độ khác.

**2. Phương thức chi trả**

Thực hiện đối chiếu giờ dạy thực tế, giờ quy đổi và chế độ giảm định mức theo từng tháng; tổng hợp theo học kỳ, quyết toán theo năm học.

Tiền lương dạy thêm giờ được xác định và thanh toán sau khi kết thúc năm học. Trường hợp nhà trường thực hiện tạm ứng theo tháng hoặc học kỳ phải bảo đảm điều kiện, chứng từ và quyết toán theo quy định.

**3. Công khai tài chính**

Việc lập dự toán, sử dụng nguồn kinh phí, thanh toán và quyết toán bảo đảm công khai, minh bạch, đúng đối tượng, đúng chế độ; chịu sự kiểm tra, giám sát theo quy định.

### VIII. TỔ CHỨC THỰC HIỆN

**1. Hiệu trưởng**

Chỉ đạo rà soát lịch sinh hoạt, bố trí nhân sự, tổ chức họp tập thể giáo viên, ban hành quyết định về mức quy đổi và phương án phân công; phê duyệt số giờ đủ điều kiện theo thẩm quyền.

**2. Phó hiệu trưởng phụ trách chuyên môn**

Phối hợp các tổ chuyên môn xây dựng lịch phân công cụ thể theo từng lớp, kiểm tra hồ sơ thực hiện và tổng hợp giờ dạy, giờ trông trẻ buổi trưa.

**3. Bộ phận kế toán**

Đối chiếu bảng lương, xác định đơn giá tiền lương dạy thêm giờ của từng giáo viên; tổng hợp dự toán toàn trường, kiểm tra nguồn kinh phí và thực hiện thủ tục thanh toán, quyết toán.

**4. Tổ trưởng chuyên môn và giáo viên**

Thực hiện đúng phân công; ghi nhận chính xác thời gian giảng dạy, trông trẻ buổi trưa; phối hợp cung cấp chứng từ và xác nhận số liệu.

### IX. KIẾN NGHỊ

Trường Mầm non An Bình đề nghị UBND phường An Bình và cơ quan chuyên môn có liên quan xem xét, hướng dẫn những vấn đề phát sinh về nguồn kinh phí và việc tổ chức thực hiện chế độ dạy thêm giờ trong điều kiện thực tế của nhà trường.

Trường cam kết triển khai đúng quy định, bảo đảm quyền lợi giáo viên, sử dụng kinh phí tiết kiệm, hiệu quả, công khai và đúng mục đích.

**Nơi nhận:**

- UBND phường An Bình (báo cáo);
- Phòng Văn hóa – Xã hội (phối hợp);
- Các bộ phận liên quan;
- Lưu: VT, hồ sơ tài chính.

**HIỆU TRƯỞNG**

*(Ký, ghi rõ họ tên và đóng dấu)*</WritingBlock>

## 5. Hồ sơ hiệu trưởng cần hoàn thiện trước khi chi trả

Tôi lưu ý thêm: Quyết định 105/2026/QĐ-UBND có quy định mức thu dịch vụ bán trú khác nhau theo địa bàn, quy mô lớp và hình thức tổ chức nấu ăn. Việc dùng nguồn thu này phải được dự toán, hạch toán đúng mục đích và không chi trả trùng một nhiệm vụ. [Source unavailable: turn449417search1]; [Source unavailable: turn592735search0]

{@body const checklist=[["a","Rà soát, thống nhất lại lịch sinh hoạt 2026–2027"],["b","Thống kê số lớp, số trẻ bán trú và giáo viên từng lớp"],["c","Họp tập thể giáo viên thống nhất phương án quy đổi giờ trực trưa"],["d","Ban hành quyết định phân công và mức quy đổi"],["e","Lập bảng đối chiếu giờ dạy, giờ quy đổi, giờ giảm định mức từng giáo viên"],["f","Kế toán lập dự toán và xác định nguồn kinh phí"],["g","Tổng hợp thanh toán, quyết toán và công khai theo quy định"]]}
{@body const [done,setDone]=DIL.useState([])}
<box border radius="xl" padding={3} gap={2}>
  <row align="center" justify="between">
    **Tiến độ chuẩn bị hồ sơ**
    <text color="secondary" tabularNums size="sm">{done.length}/7</text>
  </row>
  <box background="surface-tertiary" height="6px" radius="full" clip>
    <box background="surface-inverted" width={`${done.length/7*100}%`} height="100%" radius="full"/>
  </box>
  {#each checklist as c}
    <checkbox key={c[0]} checked={done.includes(c[0])} onChange={v=>setDone(old=>v?[...old,c[0]]:old.filter(x=>x!==c[0]))}>{c[1]}</checkbox>
  {/each}
</box>

## ✅ Kết luận và số liệu cần bổ sung

Phương án trên có thể dùng làm dự thảo trình lãnh đạo nhà trường. Tuy nhiên, **chưa thể kết luận số kinh phí thực tế phải chi** vì hồ sơ hiện có mới cung cấp lịch sinh hoạt và căn cứ pháp lý, chưa có dữ liệu nhân sự và tiền lương.

Để tính chính xác cho Trường Mầm non An Bình, cần bổ sung bốn nhóm thông tin: số lớp bán trú và không bán trú; số giáo viên ở từng lớp và số trẻ ở lại trưa; bảng lương làm căn cứ tính dạy thêm giờ của giáo viên; bảng phân công, số buổi trực trưa và các trường hợp được giảm định mức.

Từ những dữ liệu đó mới lập được **bảng dự toán chi tiết từng giáo viên, tổng hợp kinh phí toàn trường và phương án cân đối nguồn chi** có đủ cơ sở để trình phê duyệt.

---

