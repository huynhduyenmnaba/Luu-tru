USER

với vai trò hiệu trưởng trường mầm non có hơn 20 năm kinh nghiệm dự vào quy chế , bạn hãy giúp tôi thiết kế bảng KPI cho giáo viên đánh giá hàng tháng (cụ thể dễ hiểu và áp dụng) đáp ứng cụ thể từng phần việc của giáo viên mầm non,  đảm bảo đúng thang điểm 30 ( phẩm chất chính trị) 70 (nhiêm vụ)

---

ASSISTANT

Tôi sẽ đọc quy chế cô gửi để thiết kế bảng KPI theo hai phần rõ ràng: tiêu chí chung 30 điểm và kết quả thực hiện nhiệm vụ 70 điểm, với từng việc cụ thể và cách chấm dễ áp dụng. Tôi sẽ dùng kỹ năng bảng tính để làm mẫu Excel tự cộng điểm cho giáo viên.

---

ASSISTANT

Quy chế quy định phần 30 điểm gồm cả phẩm chất, đạo đức, kỷ luật, trách nhiệm, tác phong và tinh thần đổi mới. Phần nhiệm vụ 70 điểm chia thành 20 điểm khối lượng, 30 điểm chất lượng, 10 điểm tiến độ và 10 điểm chuyên môn, phối hợp, đổi mới.

Tôi sẽ giữ đúng cơ cấu này, ghi sẵn ba mức điểm ở từng dòng để giáo viên chọn, đồng thời tách rõ “thái độ thực hiện” và “kết quả công việc” để tránh chấm trùng.

---

ASSISTANT

Bảng đã được cụ thể hóa thành 32 phần việc, gồm đón trả trẻ, ăn ngủ và vệ sinh, an toàn, hoạt động giáo dục, đánh giá trẻ, hồ sơ, phối hợp phụ huynh và sinh hoạt chuyên môn.

Mỗi dòng có sẵn ba mức điểm và gợi ý minh chứng. Tôi cũng bổ sung cách xử lý việc không phát sinh, nghỉ có phép và nhiệm vụ thay đổi để giáo viên không bị mất điểm do những việc không được giao.

---

ASSISTANT

Tôi đã kiểm tra tổng điểm: phần A đúng 30, phần B đúng 70; công thức cộng điểm và ví dụ chấm thử cho kết quả đúng. File có hai trang: phiếu KPI và hướng dẫn chấm.

Tôi cũng thấy quy chế gốc còn sót tên “Trường Mầm non Thường Lạc” và ký hiệu “QĐ-MNTL” ở một số chỗ. Tôi đã ghi chú để cô rà lại trước khi ban hành.

---

ASSISTANT

Cô tải bảng KPI đã hoàn thành tại đây:

[KPI_giao_vien_hang_thang_An_Binh.xlsx](sandbox:/workspace/scratch/d8d60dce47cc/outputs/kpi-giao-vien/KPI_giao_vien_hang_thang_An_Binh.xlsx)

Bảng gồm **32 phần việc cụ thể**, giữ đúng cơ cấu điểm trong quy chế:

| Phần đánh giá | Nội dung | Điểm |
|---|---|---:|
| **A. Tiêu chí chung** | **Tổng phần A** | **30** |
| A1 | Phẩm chất chính trị, đạo đức nghề nghiệp, ý thức kỷ luật | 15 |
| A2 | Trách nhiệm, đoàn kết, phối hợp | 7 |
| A3 | Tác phong, lề lối làm việc | 4 |
| A4 | Đổi mới, sáng tạo, tự học, chuyển đổi số | 4 |
| **B. Kết quả thực hiện nhiệm vụ** | **Tổng phần B** | **70** |
| B1 | Số lượng, khối lượng nhiệm vụ | 20 |
| B2 | Chất lượng chăm sóc, nuôi dưỡng, giáo dục | 30 |
| B3 | Tiến độ thực hiện nhiệm vụ | 10 |
| B4 | Chuyên môn, phối hợp và đổi mới | 10 |
| | **Tổng cộng** | **100** |

**Cách chấm được thiết kế đơn giản:** giáo viên chọn điểm tại ô màu vàng; Excel tự cộng riêng hai phần và tổng điểm. Ví dụ, tiêu chí tối đa 5 điểm có ba lựa chọn: **5 – 2,5 – 0**, kèm diễn giải và gợi ý minh chứng ngay từng dòng.

File có cột giáo viên tự chấm, người rà soát, phần nhận xét và trang hướng dẫn xử lý việc không phát sinh, nghỉ có phép, tránh chấm trùng.

**Lưu ý:** cách chấm ba mức là đề xuất để nhà trường thống nhất trước khi áp dụng. Quy chế gốc còn sót tên “Trường Mầm non Thường Lạc” và ký hiệu “QĐ-MNTL”; cô cần chỉnh thống nhất trước khi ban hành.

---

