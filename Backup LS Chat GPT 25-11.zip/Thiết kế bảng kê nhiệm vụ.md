USER

mình gửi bạn mẫu bảng kê nhiệm vụ để bạn tham khảo. Dựa vào báo cáo tháng bạn có thể thiết kế giúp mình bảng kê nhiệm vụ tương ứng phù hợp thực tiễn đơn vị nhé

---

ASSISTANT

Mình sẽ dựa vào phần phương hướng tháng 11 trong báo cáo của Trường Mầm non An Bình A, giữ bố cục 3 cột của mẫu bảng kê và cụ thể hóa thành các nhiệm vụ có thể theo dõi, thực hiện. Mình cũng sẽ rà soát những chỗ chưa thống nhất về thời gian trong báo cáo để tránh đưa sai vào bảng.

---

ASSISTANT

Mình đã đối chiếu hai tài liệu và chọn xây dựng **Bảng kê nhiệm vụ tháng 11/2025 của Trường Mầm non An Bình A**, căn cứ vào phần phương hướng tháng 11 trong báo cáo, đồng thời bổ sung những nhiệm vụ quản lý thường xuyên phù hợp với thực tế nhà trường.

Bảng được thiết kế theo đúng mẫu bạn gửi, gồm 3 cột: **STT – Nội dung nhiệm vụ thực hiện – Ghi chú**. Nội dung tập trung vào vai trò chỉ đạo, điều hành và kiểm tra của Hiệu trưởng, thay vì chỉ liệt kê công việc của từng giáo viên.

Lưu ý: Tiêu đề và ngày tháng ở đầu báo cáo có điểm chưa thống nhất với phần nội dung tháng 10 và phương hướng tháng 11. Mình lấy phần phương hướng và kết luận báo cáo làm căn cứ xác định tháng lập bảng.

> **writing · document**
>
> | **UBND PHƯỜNG AN BÌNH** | **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM** |
> |:---|:---|
> | **TRƯỜNG MẦM NON AN BÌNH A** | **Độc lập – Tự do – Hạnh phúc** |
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 11/2025
>
> **Năm học 2025–2026**
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 11/2025; phân công, chỉ đạo các tổ chuyên môn và bộ phận thực hiện nhiệm vụ theo kế hoạch của nhà trường. | Tuần 1 |
> | 2 | Rà soát, chỉ đạo điều chỉnh mục tiêu, nội dung trong kế hoạch giáo dục của nhà trường, tổ chuyên môn và giáo viên theo Chương trình Giáo dục mầm non hiện hành, phù hợp với điều kiện thực tế và độ tuổi của trẻ. | Tuần 1–2 |
> | 3 | Kiểm tra, thăm lớp, nắm tình hình tổ chức các hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ; hướng dẫn giáo viên khắc phục những nội dung, hoạt động chưa phù hợp với khả năng của trẻ. | Trong tháng |
> | 4 | Chỉ đạo giáo viên vận dụng phương pháp giáo dục STEAM, giáo dục lấy trẻ làm trung tâm; lồng ghép giáo dục quyền trẻ em, kỹ năng sống, phòng cháy chữa cháy và xây dựng trường học hạnh phúc trong các hoạt động giáo dục. | Trong tháng |
> | 5 | Tổ chức sinh hoạt chuyên môn cấp trường; tham dự sinh hoạt chuyên môn của các tổ theo kế hoạch, trao đổi giải pháp nâng cao chất lượng tổ chức các hoạt động giáo dục. | Theo kế hoạch |
> | 6 | Chỉ đạo xây dựng kế hoạch và tổ chức các hoạt động chào mừng Ngày Nhà giáo Việt Nam 20/11 phù hợp với trẻ mầm non, bảo đảm thiết thực, tiết kiệm và an toàn. | Trước và trong ngày 20/11 |
> | 7 | Tham mưu UBND phường An Bình về công tác phổ cập giáo dục mầm non; rà soát, hoàn thiện các biểu mẫu, hồ sơ phổ cập theo hướng dẫn của ngành. | Theo tiến độ |
> | 8 | Phối hợp với 4 khóm trên địa bàn rà soát, đối chiếu thông tin trẻ trong độ tuổi; cập nhật tình hình trẻ ra lớp, trẻ khuyết tật và hoàn thiện dữ liệu phục vụ công tác phổ cập giáo dục. | Trong tháng |
> | 9 | Chỉ đạo giáo viên phối hợp với cha mẹ trẻ, các khóm tiếp tục vận động trẻ trong độ tuổi nhà trẻ và mẫu giáo ra lớp; duy trì kết quả huy động trẻ 5 tuổi. | Thường xuyên |
> | 10 | Kiểm tra, đối chiếu số lượng trẻ tại các điểm trường, nhóm lớp; rà soát biến động tăng, giảm và bảo đảm tính chính xác, thống nhất của số liệu báo cáo. | Tuần 1 và cuối tháng |
> | 11 | Rà soát danh sách trẻ tham gia sổ liên lạc điện tử; chỉ đạo giáo viên cập nhật, gửi thông tin kết quả học tập và các hoạt động của trẻ đến cha mẹ trẻ qua phần mềm VNEDU. | Trong tháng |
> | 12 | Chỉ đạo cập nhật, rà soát thông tin đội ngũ, học sinh trên cơ sở dữ liệu ngành và hệ thống EMIS; thực hiện các báo cáo theo yêu cầu, đúng thời gian quy định. | Theo thông báo |
> | 13 | Kiểm tra công tác chăm sóc, nuôi dưỡng, bảo đảm an toàn thực phẩm, vệ sinh trường lớp; chỉ đạo thực hiện các biện pháp phòng, chống dịch bệnh và bảo đảm an toàn cho trẻ. | Thường xuyên |
> | 14 | Chỉ đạo công tác tuyên truyền phòng, chống bệnh sốt xuất huyết; phối hợp với Chi đoàn và cha mẹ trẻ duy trì vệ sinh môi trường, phòng ngừa dịch bệnh trong trường học. | Trong tháng |
> | 15 | Kiểm tra, rà soát cơ sở vật chất, trang thiết bị, đồ dùng, đồ chơi tại các điểm trường; theo dõi việc sử dụng khu kỹ năng và các hạng mục đã sửa chữa, kịp thời đề xuất bổ sung, khắc phục. | Tuần 2–3 |
> | 16 | Phối hợp và giám sát việc tổ chức các hoạt động ngoại khóa với các trung tâm ngoại ngữ, aerobic, QME; bảo đảm nội dung phù hợp với lứa tuổi và điều kiện thực tế của nhà trường. | Theo lịch tổ chức |
> | 17 | Phối hợp với Chi đoàn thực hiện các hoạt động hỗ trợ trẻ có hoàn cảnh khó khăn, duy trì mô hình “Ước mơ xanh” và các hoạt động chăm lo cho trẻ. | Theo kế hoạch |
> | 18 | Chỉ đạo thực hiện các thủ tục bảo hiểm xã hội đối với trường hợp nghỉ chế độ ốm đau; báo tăng mức đóng bảo hiểm do nâng lương thường xuyên và giải quyết các chế độ cho viên chức, người lao động theo quy định. | Theo phát sinh |
> | 19 | Chỉ đạo thực hiện công tác tài chính, chi trả tiền lương, các khoản phụ cấp, thanh toán chi thường xuyên; kiểm tra hồ sơ văn thư, lưu trữ và thực hiện các báo cáo hành chính theo quy định. | Trong tháng |
> | 20 | Rà soát, tổng hợp kết quả thực hiện nhiệm vụ tháng 11; kiểm tra tính đầy đủ, chính xác của số liệu báo cáo, đánh giá những hạn chế và xây dựng phương hướng thực hiện nhiệm vụ tháng 12/2025. | Cuối tháng |
>
> | | **HIỆU TRƯỞNG** |
> |---|:---:|
> | | *(Ký, ghi rõ họ tên)* |
> | | **Huỳnh Hồng Loan** |

## 💡 Một số điểm mình đã điều chỉnh cho sát thực tế

Mình đã chủ động bổ sung nội dung kiểm tra công tác nuôi dưỡng, bảo đảm an toàn cho trẻ, cơ sở vật chất, tài chính và giám sát hoạt động ngoại khóa. Đây là những nhiệm vụ quản lý thường xuyên, được gợi ý thêm từ thực tiễn hoạt động và kết quả tháng trước, không phải tất cả đều được nêu trực tiếp trong phương hướng tháng 11 của báo cáo.

Đặc biệt, do báo cáo thể hiện nhà trường còn thiếu nhân sự, các nhiệm vụ được viết theo hướng **Hiệu trưởng chỉ đạo, kiểm tra, đôn đốc và phối hợp thực hiện**, tránh dàn trải quá nhiều hoạt động mới.

Cột **Ghi chú** thể hiện thời gian dự kiến, cần đối chiếu lịch công tác thực tế trước khi ban hành.

Bảng kê này có thể sử dụng làm cơ sở theo dõi nhiệm vụ tháng của Hiệu trưởng, đồng thời thuận tiện đối chiếu với báo cáo kết quả thực hiện cuối tháng.

---

USER

xuất file word giúp mình

---

ASSISTANT

Mình đã chuẩn bị nội dung **Bảng kê nhiệm vụ tháng 11/2025 – Trường Mầm non An Bình A** theo mẫu bạn gửi, gồm 20 nhiệm vụ.

Hiện tại mình chưa thể tạo và đính kèm trực tiếp tệp Word (.docx) trong phiên này.

Bạn có thể sử dụng bảng kê ở tin nhắn trước: chọn **Sao chép**, dán vào Microsoft Word và lưu dưới tên `Bang_ke_nhiem_vu_thang_11_2025.docx`.

Mình xin lỗi vì chưa thể cung cấp tệp Word để bạn tải trực tiếp.

---

USER

bạn thực hiện tương tự với các tháng còn lại nhé

---

ASSISTANT

Mình đã nhận đủ 7 báo cáo mới. Mình sẽ lập bảng kê riêng cho các tháng 01, 02, 03, 04, 05, 07 và 08/2026, giữ mẫu 3 cột như trước. Mỗi bảng sẽ bám sát phần phương hướng của tháng tương ứng, đồng thời cụ thể hóa những việc cần chỉ đạo, kiểm tra và báo cáo của Hiệu trưởng.

---

ASSISTANT

# BẢNG KÊ NHIỆM VỤ CÁC THÁNG NĂM 2026

Trường Mầm non An Bình A – Năm học 2025–2026 và chuẩn bị năm học 2026–2027

Mình đã đối chiếu phần phương hướng, kết quả hoạt động và những hạn chế cần khắc phục trong các báo cáo bạn gửi.

Mình xây dựng **7 bảng kê riêng biệt**, giữ đúng kết cấu mẫu đã thống nhất. Các nhiệm vụ được diễn đạt theo vai trò quản lý của Hiệu trưởng; cột ghi chú là thời gian thực hiện gợi ý, có thể điều chỉnh theo lịch thực tế.

## 1. Bảng kê nhiệm vụ tháng 01/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 01/2026
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 01/2026; chỉ đạo các tổ chuyên môn nghiên cứu văn bản hướng dẫn, thực hiện kế hoạch giáo dục và những nhiệm vụ được phân công. | Đầu tháng |
> | 2 | Chỉ đạo các tổ chuyên môn rà soát mục tiêu, nội dung giáo dục, điều chỉnh việc phân bổ mục tiêu trong chủ đề; nâng cao chất lượng soạn giảng và tổ chức hoạt động phù hợp độ tuổi. | Trong tháng |
> | 3 | Rà soát kết quả thực hiện nhiệm vụ học kỳ I, đối chiếu số liệu huy động trẻ, chất lượng chăm sóc và giáo dục; chỉ đạo hoàn thành báo cáo sơ kết học kỳ I năm học 2025–2026. | Theo kế hoạch |
> | 4 | Tham mưu UBND phường, chỉ đạo rà soát và hoàn thiện hồ sơ, biểu mẫu, minh chứng phổ cập giáo dục mầm non; chuẩn bị phục vụ công tác kiểm tra của Sở Giáo dục và Đào tạo. | Trước lịch kiểm tra |
> | 5 | Phối hợp với các bộ phận liên quan chuẩn bị, tiếp đoàn kiểm tra công tác phổ cập; tiếp thu ý kiến và chỉ đạo bổ sung, hoàn thiện hồ sơ sau kiểm tra. | Theo lịch của đoàn |
> | 6 | Thông báo lịch nghỉ Tết Dương lịch 2026; phân công trực và kiểm tra công tác bảo vệ tài sản, an ninh, an toàn trường học trong thời gian nghỉ. | Đầu tháng |
> | 7 | Tổng hợp danh sách đăng ký tham gia các hoạt động Mừng Đảng – Mừng Xuân năm 2026 do địa phương tổ chức; phân công nhân sự tham gia theo kế hoạch. | Theo thông báo |
> | 8 | Xây dựng kế hoạch, chuẩn bị các điều kiện tổ chức Hội chợ Xuân 2026 gây quỹ hỗ trợ trẻ có hoàn cảnh khó khăn đang học tại trường. | Theo kế hoạch |
> | 9 | Dự sinh hoạt chuyên môn của các tổ; chỉ đạo đổi mới nội dung sinh hoạt, tập trung giải quyết những hạn chế về soạn giảng và tổ chức hoạt động giáo dục. | Theo lịch SHCM |
> | 10 | Kiểm tra, hướng dẫn thực hiện công tác chăm sóc, nuôi dưỡng; tăng cường phòng, chống dịch bệnh, vệ sinh an toàn thực phẩm và bảo đảm an toàn cho trẻ. | Thường xuyên |
> | 11 | Chỉ đạo cập nhật, đối chiếu số liệu trẻ, thông tin nhân sự trên cơ sở dữ liệu ngành; kiểm tra việc cập nhật và sử dụng sổ liên lạc điện tử VNEDU. | Trong tháng |
> | 12 | Phối hợp, giám sát tổ chức các hoạt động ngoại khóa tiếng Anh, aerobic và toán tư duy theo kế hoạch, bảo đảm phù hợp lứa tuổi. | Theo lịch tổ chức |
> | 13 | Kiểm tra thực trạng cơ sở vật chất, đồ dùng, đồ chơi, các khu trải nghiệm; chỉ đạo bảo quản, sử dụng an toàn và hiệu quả. | Trong tháng |
> | 14 | Chỉ đạo thực hiện công tác hành chính, văn thư, tiếp nhận, xử lý văn bản và lưu trữ hồ sơ đúng quy định. | Thường xuyên |
> | 15 | Chỉ đạo công tác tài chính – kế toán, chi trả các chế độ cho viên chức, người lao động; rà soát chứng từ, hoàn thiện hồ sơ quyết toán năm 2025 theo quy định. | Trong tháng |
> | 16 | Phối hợp Chi đoàn thực hiện các hoạt động chăm lo trẻ có hoàn cảnh khó khăn, xây dựng cảnh quan môi trường xanh – sạch – đẹp. | Trong tháng |
> | 17 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 01; hoàn thành báo cáo và xây dựng phương hướng hoạt động tháng 02/2026. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

## 2. Bảng kê nhiệm vụ tháng 02/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 02/2026
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ tháng 02/2026; chỉ đạo các tổ chuyên môn thực hiện chương trình, kế hoạch giáo dục và duy trì nền nếp chăm sóc, nuôi dưỡng trẻ trước và sau Tết. | Trong tháng |
> | 2 | Phối hợp tham gia chuỗi hoạt động Mừng Đảng – Mừng Xuân Bính Ngọ 2026 do UBND phường tổ chức; phân công viên chức, người lao động tham gia các hoạt động theo kế hoạch. | Theo lịch địa phương |
> | 3 | Chỉ đạo tổ chức Hội chợ Xuân 2026 gây quỹ hỗ trợ trẻ em có hoàn cảnh khó khăn đang học tại trường; phối hợp các bộ phận quản lý, tổng hợp và công khai kết quả hoạt động. | Theo kế hoạch |
> | 4 | Thông báo lịch nghỉ Tết Nguyên đán Bính Ngọ 2026; phân công trực, kiểm tra công tác bảo vệ tài sản, phòng cháy chữa cháy và an ninh, an toàn trường học. | Trước kỳ nghỉ |
> | 5 | Kiểm tra công tác vệ sinh trường lớp, khuôn viên, bếp ăn, nguồn nước và các điều kiện đón trẻ trở lại trường sau kỳ nghỉ Tết. | Trước và sau Tết |
> | 6 | Chỉ đạo rà soát tình hình chuyên cần, phối hợp cha mẹ trẻ tuyên truyền việc đưa trẻ đến lớp đầy đủ; quan tâm nâng tỷ lệ trẻ tham gia hoạt động buổi chiều tại điểm An Lợi. | Sau Tết |
> | 7 | Kiểm tra kế hoạch giáo dục, nội dung soạn giảng; hướng dẫn giáo viên xác định mục tiêu, yêu cầu và tổ chức hoạt động phù hợp đặc điểm phát triển của trẻ. | Trong tháng |
> | 8 | Chỉ đạo, hỗ trợ giáo viên tăng cường ứng dụng công nghệ thông tin, sử dụng học liệu trực quan và vận dụng phương pháp STEAM phù hợp trong hoạt động giáo dục. | Trong tháng |
> | 9 | Dự sinh hoạt chuyên môn của các tổ, trao đổi kinh nghiệm và hướng dẫn khắc phục những hạn chế trong tổ chức hoạt động giáo dục. | Theo lịch SHCM |
> | 10 | Rà soát số lượng trẻ ra lớp, biến động tăng giảm; duy trì kết quả huy động trẻ 5 tuổi và cập nhật dữ liệu phục vụ công tác phổ cập giáo dục. | Trong tháng |
> | 11 | Chỉ đạo cập nhật dữ liệu nhân sự, trẻ em trên cơ sở dữ liệu ngành và thông tin liên lạc với cha mẹ trẻ qua phần mềm VNEDU. | Trong tháng |
> | 12 | Phối hợp giám sát hoạt động các lớp ngoại khóa; kiểm tra điều kiện tổ chức, sự phù hợp của nội dung và bảo đảm an toàn cho trẻ. | Theo kế hoạch |
> | 13 | Chỉ đạo công tác y tế học đường, phòng, chống dịch bệnh, bảo đảm vệ sinh an toàn thực phẩm và phòng ngừa tai nạn thương tích trước, trong và sau Tết. | Thường xuyên |
> | 14 | Kiểm tra cơ sở vật chất, đồ dùng, đồ chơi và khu vui chơi; kịp thời chỉ đạo sửa chữa, khắc phục những hạng mục không bảo đảm an toàn. | Trong tháng |
> | 15 | Chỉ đạo thực hiện công tác hành chính, văn thư, lưu trữ và báo cáo theo quy định; rà soát tình hình nhân sự, các nhiệm vụ được giao. | Thường xuyên |
> | 16 | Chỉ đạo công tác tài chính – kế toán, thanh toán tiền lương, phụ cấp, chế độ chính sách; kiểm tra, đối chiếu chứng từ và thực hiện chi tiêu đúng quy định. | Trong tháng |
> | 17 | Phối hợp Chi đoàn tổ chức hoạt động chăm lo trẻ khó khăn, duy trì mô hình “Ước mơ xanh” và thực hiện tuyên truyền bảo vệ môi trường, tiết kiệm. | Trong tháng |
> | 18 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 02; hoàn thành báo cáo và xây dựng phương hướng tháng 03/2026. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

## 3. Bảng kê nhiệm vụ tháng 03/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 03/2026
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 03/2026; chỉ đạo các tổ chuyên môn nghiên cứu, thực hiện văn bản chuyên môn và tổ chức chương trình giáo dục đúng kế hoạch. | Đầu tháng |
> | 2 | Chỉ đạo rà soát, điều chỉnh kế hoạch giáo dục, bảo đảm mục tiêu, nội dung và hoạt động phù hợp độ tuổi; tiếp tục vận dụng STEAM và giáo dục lấy trẻ làm trung tâm. | Trong tháng |
> | 3 | Triển khai công tác chuẩn bị, tham gia Hội thi Giáo viên dạy giỏi theo kế hoạch được phê duyệt; kiểm tra hồ sơ, điều kiện dự thi và hỗ trợ chuyên môn cho giáo viên. | Theo lịch hội thi |
> | 4 | Chỉ đạo xây dựng kế hoạch, lựa chọn nội dung và chuẩn bị các điều kiện tổ chức hội thi dành cho trẻ phù hợp đặc điểm lứa tuổi và điều kiện nhà trường. | Theo kế hoạch |
> | 5 | Phối hợp tổ chức các hoạt động chào mừng Ngày Quốc tế Phụ nữ 08/3; động viên đội ngũ tham gia các phong trào, hội thi do địa phương phát động. | Dịp 08/3 |
> | 6 | Phối hợp Chi đoàn tổ chức hoạt động hưởng ứng kỷ niệm Ngày thành lập Đoàn Thanh niên Cộng sản Hồ Chí Minh 26/3, lồng ghép giáo dục phù hợp lứa tuổi. | Dịp 26/3 |
> | 7 | Chỉ đạo giáo viên phối hợp cha mẹ trẻ duy trì tỷ lệ chuyên cần, tăng cường tuyên truyền lợi ích của việc tham gia các hoạt động giáo dục tại trường. | Thường xuyên |
> | 8 | Dự sinh hoạt chuyên môn của các tổ; kiểm tra chất lượng soạn giảng, hỗ trợ giáo viên đổi mới phương pháp và nâng cao hiệu quả tổ chức hoạt động. | Theo lịch SHCM |
> | 9 | Kiểm tra, hướng dẫn nâng cao chất lượng công tác truyền thông; lựa chọn nội dung, hình ảnh rõ nét, phù hợp thực tế chăm sóc và giáo dục trẻ tại nhà trường. | Trong tháng |
> | 10 | Rà soát số liệu huy động trẻ trong học kỳ II, cập nhật biến động tăng giảm và thực hiện báo cáo theo hướng dẫn của cơ quan quản lý. | Trong tháng |
> | 11 | Chỉ đạo cập nhật dữ liệu ngành, hồ sơ nhân sự, dữ liệu trẻ em và thông tin trên phần mềm VNEDU bảo đảm chính xác, kịp thời. | Trong tháng |
> | 12 | Phối hợp, giám sát các lớp ngoại khóa tiếng Anh, aerobic, toán tư duy; theo dõi chất lượng và bảo đảm an toàn trong hoạt động. | Theo lịch |
> | 13 | Kiểm tra công tác chăm sóc, nuôi dưỡng, y tế học đường; tăng cường phòng chống dịch bệnh, vệ sinh an toàn thực phẩm và phòng tránh tai nạn thương tích. | Thường xuyên |
> | 14 | Kiểm tra, rà soát cơ sở vật chất, thiết bị, đồ dùng đồ chơi và môi trường giáo dục tại các điểm trường; chỉ đạo khắc phục những hạn chế phát sinh. | Trong tháng |
> | 15 | Phối hợp Chi đoàn chăm sóc cây xanh, cảnh quan, hỗ trợ trẻ khó khăn và tham gia các hoạt động tình nguyện tại địa phương theo kế hoạch. | Trong tháng |
> | 16 | Chỉ đạo công tác hành chính, văn thư, lưu trữ; tiếp nhận, xử lý văn bản, rà soát thông tin và hoàn thành các báo cáo theo quy định. | Thường xuyên |
> | 17 | Chỉ đạo thực hiện công tác tài chính – kế toán; thanh toán tiền lương, phụ cấp, chế độ và đối chiếu chứng từ; lập các báo cáo tài chính theo yêu cầu. | Trong tháng |
> | 18 | Đánh giá kết quả thực hiện nhiệm vụ tháng 03, tổng hợp những hạn chế cần khắc phục và xây dựng phương hướng tháng 04/2026. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

## 4. Bảng kê nhiệm vụ tháng 04/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 04/2026
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 04/2026; chỉ đạo các tổ chuyên môn thực hiện chương trình, kế hoạch giáo dục và các nhiệm vụ theo văn bản hướng dẫn của ngành. | Đầu tháng |
> | 2 | Chỉ đạo xây dựng kế hoạch, tổ chức Hội thi “Bé khéo tay” cấp cơ sở năm học 2025–2026; bảo đảm nội dung phù hợp lứa tuổi, an toàn và phát huy khả năng sáng tạo của trẻ. | Theo kế hoạch |
> | 3 | Phối hợp đơn vị QME tổ chức Hội thi “Rung chuông vàng” cho trẻ tham gia học toán tư duy; theo dõi, đánh giá công tác tổ chức và kết quả hoạt động. | Theo lịch hội thi |
> | 4 | Tổ chức các hoạt động hưởng ứng Ngày Sách và Văn hóa đọc Việt Nam năm 2026; tạo môi trường đọc thân thiện, khuyến khích trẻ làm quen với sách. | Dịp 21/4 |
> | 5 | Chỉ đạo tổ chức hoạt động giáo dục phù hợp chào mừng kỷ niệm Ngày Giải phóng miền Nam, thống nhất đất nước 30/4; lồng ghép giáo dục tình yêu quê hương, đất nước. | Dịp 30/4 |
> | 6 | Kiểm tra việc thực hiện kế hoạch giáo dục, mục tiêu, nội dung và phương pháp tổ chức hoạt động; chỉ đạo vận dụng STEAM, giáo dục lấy trẻ làm trung tâm phù hợp thực tế. | Trong tháng |
> | 7 | Dự sinh hoạt chuyên môn của các tổ; chỉ đạo trao đổi, chia sẻ kinh nghiệm và nâng cao chất lượng chăm sóc, giáo dục trẻ. | Theo lịch SHCM |
> | 8 | Kiểm tra tiến độ cải tạo khuôn viên, trang trí môi trường giáo dục và tổ chức cho trẻ tham gia hoạt động tại các khu vui chơi, trải nghiệm. | Trong tháng |
> | 9 | Chỉ đạo nâng cao chất lượng truyền thông nhà trường; hướng dẫn lựa chọn nội dung, hình ảnh hoạt động giáo dục có chất lượng, phản ánh đúng thực tế. | Trong tháng |
> | 10 | Rà soát kết quả huy động trẻ, duy trì tỷ lệ chuyên cần; cập nhật số liệu phục vụ báo cáo học kỳ II và tổng kết năm học 2025–2026. | Trong tháng |
> | 11 | Chỉ đạo cập nhật dữ liệu nhân sự, trẻ em trên cơ sở dữ liệu ngành và sổ liên lạc điện tử VNEDU; kiểm tra việc cung cấp thông tin đến cha mẹ trẻ. | Trong tháng |
> | 12 | Phối hợp, giám sát hoạt động các lớp ngoại khóa; bảo đảm thực hiện đúng nội dung đã thống nhất và an toàn cho trẻ. | Theo lịch |
> | 13 | Kiểm tra công tác chăm sóc, nuôi dưỡng, vệ sinh an toàn thực phẩm, phòng chống dịch bệnh và các điều kiện bảo đảm an toàn tại các điểm trường. | Thường xuyên |
> | 14 | Rà soát cơ sở vật chất, đồ dùng đồ chơi, trang thiết bị; chuẩn bị nội dung kiểm kê và đánh giá nhu cầu sửa chữa, bổ sung phục vụ năm học tiếp theo. | Trong tháng |
> | 15 | Phối hợp Chi đoàn thực hiện chăm sóc cây xanh, trang trí cảnh quan, vệ sinh môi trường và các hoạt động hỗ trợ trẻ có hoàn cảnh khó khăn. | Trong tháng |
> | 16 | Chỉ đạo thực hiện công tác hành chính, văn thư, lưu trữ; rà soát hồ sơ, văn bản và các báo cáo định kỳ, đột xuất theo yêu cầu. | Thường xuyên |
> | 17 | Chỉ đạo công tác tài chính – kế toán, chi trả chế độ chính sách, thanh quyết toán các khoản chi và kiểm tra tính đầy đủ của chứng từ theo quy định. | Trong tháng |
> | 18 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 04; xây dựng phương hướng tháng 05, tập trung chuẩn bị các hoạt động kết thúc năm học. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

## 5. Bảng kê nhiệm vụ tháng 05/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 05/2026
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 05/2026; chỉ đạo các tổ chuyên môn hoàn thành chương trình, kế hoạch giáo dục năm học 2025–2026 đúng tiến độ. | Đầu tháng |
> | 2 | Chỉ đạo xây dựng kế hoạch, phối hợp với trường tiểu học tổ chức cho trẻ mẫu giáo 5 tuổi tham quan, làm quen môi trường học tập ở bậc tiểu học. | Theo kế hoạch |
> | 3 | Kiểm tra công tác chuẩn bị, phân công giáo viên quản lý trẻ và bảo đảm an toàn trong hoạt động tham quan trường tiểu học. | Trước và trong hoạt động |
> | 4 | Phối hợp trung tâm ngoại ngữ chuẩn bị, tổ chức chương trình ngoại khóa tiếng Anh cho trẻ theo kế hoạch của nhà trường. | Dự kiến 08/5 |
> | 5 | Chỉ đạo giáo viên hoàn thành nội dung giáo dục các độ tuổi; rà soát việc thực hiện mục tiêu, đánh giá sự phát triển của trẻ và tổng hợp kết quả cuối năm học. | Trong tháng |
> | 6 | Chỉ đạo xây dựng chương trình văn nghệ, phân công luyện tập và chuẩn bị các điều kiện tổ chức lễ ra trường cho trẻ mẫu giáo 5 tuổi. | Theo kế hoạch |
> | 7 | Chuẩn bị nội dung, chương trình và tổ chức tổng kết năm học 2025–2026 bảo đảm trang trọng, thiết thực, phù hợp với điều kiện nhà trường. | Cuối năm học |
> | 8 | Rà soát số liệu huy động trẻ, kết quả thực hiện nhiệm vụ chăm sóc, nuôi dưỡng và giáo dục; tổng hợp thông tin phục vụ báo cáo tổng kết năm học. | Trong tháng |
> | 9 | Chỉ đạo cập nhật, hoàn thiện dữ liệu trẻ, nhân sự trên cơ sở dữ liệu ngành; rà soát số liệu phổ cập giáo dục mầm non theo hướng dẫn. | Trong tháng |
> | 10 | Kiểm tra việc cập nhật thông tin, đánh giá kết quả giáo dục trẻ và trao đổi với cha mẹ trẻ qua sổ liên lạc điện tử VNEDU. | Trong tháng |
> | 11 | Chỉ đạo các tổ chuyên môn đánh giá kết quả thực hiện chương trình giáo dục, tổng hợp những thuận lợi, khó khăn và đề xuất giải pháp cho năm học tiếp theo. | Cuối tháng |
> | 12 | Kiểm tra, rà soát hồ sơ chuyên môn, việc thực hiện nhiệm vụ của các bộ phận; chuẩn bị tài liệu phục vụ công tác tổng kết, đánh giá cuối năm. | Trong tháng |
> | 13 | Chỉ đạo rà soát, kiểm kê cơ sở vật chất, đồ dùng đồ chơi, tài sản, trang thiết bị; tổng hợp nhu cầu sửa chữa, bổ sung phục vụ năm học 2026–2027. | Cuối tháng |
> | 14 | Kiểm tra công tác y tế học đường, vệ sinh an toàn thực phẩm, phòng chống dịch bệnh; tuyên truyền phòng tránh tai nạn thương tích cho trẻ trong thời gian nghỉ hè. | Thường xuyên |
> | 15 | Phối hợp Chi đoàn, cha mẹ trẻ thực hiện công tác vệ sinh, chăm sóc cảnh quan và hỗ trợ trẻ có hoàn cảnh khó khăn trong các hoạt động cuối năm học. | Trong tháng |
> | 16 | Chỉ đạo công tác hành chính, văn thư, lưu trữ; hoàn thiện hồ sơ, sổ sách và báo cáo theo quy định. | Trong tháng |
> | 17 | Chỉ đạo thực hiện công tác tài chính – kế toán, thanh toán lương, phụ cấp, chế độ; rà soát chứng từ và các khoản chi phục vụ hoạt động tổng kết năm học theo quy định. | Trong tháng |
> | 18 | Tổng hợp kết quả thực hiện nhiệm vụ tháng 05, hoàn thiện báo cáo tổng kết năm học 2025–2026 và đề xuất các nhiệm vụ chuẩn bị năm học mới. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

## 6. Bảng kê nhiệm vụ tháng 07/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 07/2026
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ tháng 07/2026; chỉ đạo các bộ phận nghiên cứu văn bản hướng dẫn và chuẩn bị những điều kiện cần thiết cho năm học 2026–2027. | Đầu tháng |
> | 2 | Chỉ đạo các tổ chuyên môn xây dựng kế hoạch tập huấn, bồi dưỡng chuyên môn cho giáo viên; rà soát những nội dung cần điều chỉnh trong việc thực hiện chương trình giáo dục. | Trong tháng |
> | 3 | Rà soát đội ngũ cán bộ quản lý, giáo viên, nhân viên; dự kiến phân công giảng dạy tại các nhóm lớp và điểm trường phù hợp tình hình nhân sự thực tế. | Trong tháng |
> | 4 | Chỉ đạo rà soát số liệu trẻ trong độ tuổi trên địa bàn, đối chiếu với kết quả điều tra và tình hình huy động trẻ năm học trước để chuẩn bị công tác tuyển sinh. | Trong tháng |
> | 5 | Phối hợp với các khóm, khu phố thực hiện điều tra, bổ sung thông tin trẻ trong độ tuổi; cập nhật các trường hợp chuyển đến, chuyển đi phục vụ công tác phổ cập giáo dục. | Trong tháng |
> | 6 | Xây dựng phương án huy động trẻ ra lớp năm học 2026–2027, chú trọng trẻ nhà trẻ, trẻ mẫu giáo và bảo đảm huy động trẻ 5 tuổi theo chỉ tiêu. | Trong tháng |
> | 7 | Chỉ đạo chuẩn bị nội dung, thông tin và các điều kiện phục vụ công tác tuyển sinh năm học 2026–2027 theo kế hoạch được phê duyệt. | Theo kế hoạch |
> | 8 | Kiểm tra, chỉ đạo cải tạo các khu vui chơi ngoài trời, khu trải nghiệm, cổng chào và cảnh quan trường học chuẩn bị đón trẻ vào năm học mới. | Trong tháng |
> | 9 | Rà soát thực trạng cơ sở vật chất, thiết bị, đồ dùng đồ chơi; xây dựng danh mục sửa chữa, bổ sung và bố trí sử dụng phù hợp với số lượng nhóm lớp dự kiến. | Trong tháng |
> | 10 | Chỉ đạo vệ sinh trường lớp, chăm sóc cây xanh, cải tạo môi trường giáo dục, bảo đảm cảnh quan xanh – sạch – đẹp và an toàn. | Trong tháng |
> | 11 | Chỉ đạo công tác y tế học đường, phòng chống dịch bệnh; tăng cường tuyên truyền phòng tránh tai nạn thương tích, bạo lực và xâm hại trẻ em. | Thường xuyên |
> | 12 | Phối hợp với cha mẹ trẻ tuyên truyền, vận động đưa trẻ tham gia khám sức khỏe theo kế hoạch; quan tâm khắc phục hạn chế về tỷ lệ tham gia khám sức khỏe. | Theo lịch khám |
> | 13 | Chỉ đạo rà soát, cập nhật thông tin nhân sự, dữ liệu trẻ em và hồ sơ quản lý trên các phần mềm theo yêu cầu của ngành. | Trong tháng |
> | 14 | Phối hợp Chi đoàn chăm sóc cảnh quan trường học, trang trí các góc chơi, khu trải nghiệm và tham gia các hoạt động tình nguyện tại địa phương. | Trong tháng |
> | 15 | Chỉ đạo thực hiện công tác hành chính, văn thư, lưu trữ; tiếp nhận, xử lý văn bản, hoàn thiện hồ sơ phục vụ chuẩn bị năm học mới. | Thường xuyên |
> | 16 | Chỉ đạo công tác tài chính – kế toán; chi trả lương, phụ cấp, chế độ chính sách; kiểm tra, đối chiếu chứng từ và thực hiện các khoản chi đúng quy định. | Trong tháng |
> | 17 | Kiểm tra tiến độ thực hiện các nhiệm vụ chuẩn bị năm học mới của các tổ chuyên môn, bộ phận; kịp thời chỉ đạo giải quyết khó khăn, vướng mắc. | Cuối tháng |
> | 18 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 07; hoàn thành báo cáo và xây dựng phương hướng tháng 08/2026. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

## 7. Bảng kê nhiệm vụ tháng 08/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 08/2026
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai các nhiệm vụ chuẩn bị năm học 2026–2027; chỉ đạo tổ chuyên môn nghiên cứu, thực hiện văn bản hướng dẫn và tham gia các hoạt động bồi dưỡng chuyên môn theo kế hoạch. | Đầu tháng |
> | 2 | Chỉ đạo xây dựng, rà soát kế hoạch giáo dục năm học 2026–2027; lựa chọn mục tiêu, nội dung phù hợp chương trình, điều kiện thực tế và đặc điểm của trẻ. | Trong tháng |
> | 3 | Tổ chức phân công giảng dạy, bố trí giáo viên phụ trách các nhóm lớp và điểm trường; rà soát tình hình đội ngũ, bảo đảm phù hợp với số trẻ và điều kiện nhân sự. | Trước khi đón trẻ |
> | 4 | Chỉ đạo các tổ chuyên môn chuẩn bị nội dung sinh hoạt chuyên môn, bồi dưỡng giáo viên, thống nhất những yêu cầu cơ bản trong thực hiện chương trình giáo dục năm học mới. | Trong tháng |
> | 5 | Phối hợp trưởng các khóm, khu phố rà soát số liệu trẻ trong độ tuổi, cập nhật những trường hợp chuyển đi, chuyển đến và các biến động dân cư trên địa bàn. | Trong tháng |
> | 6 | Chỉ đạo thực hiện điều tra bổ sung đối tượng phổ cập giáo dục mầm non; kiểm tra, đối chiếu thông tin trẻ, hoàn thiện hồ sơ, số liệu theo hướng dẫn. | Trong tháng |
> | 7 | Chỉ đạo triển khai công tác tuyển sinh, huy động trẻ ra lớp theo chỉ tiêu năm học 2026–2027; phối hợp gia đình và địa phương vận động trẻ 5 tuổi đến trường đầy đủ. | Theo kế hoạch |
> | 8 | Rà soát, thống kê kết quả huy động trẻ ở các độ tuổi, kiểm tra số lượng trẻ dự kiến tại từng nhóm lớp và cập nhật dữ liệu phục vụ báo cáo đầu năm học. | Trong tháng |
> | 9 | Chỉ đạo cập nhật thông tin nhân sự, trẻ em trên cơ sở dữ liệu ngành; chuẩn bị hồ sơ quản lý, danh sách nhóm lớp và các biểu mẫu phục vụ năm học mới. | Trong tháng |
> | 10 | Kiểm tra, đôn đốc hoàn thành việc cải tạo khu vui chơi ngoài trời, khu trải nghiệm, cổng chào và các hạng mục trang trí chuẩn bị đón trẻ. | Trong tháng |
> | 11 | Chỉ đạo vệ sinh trường lớp, chăm sóc cây xanh, chỉnh trang môi trường giáo dục; bố trí các góc chơi, đồ dùng đồ chơi phù hợp độ tuổi và điều kiện thực tế. | Trước khi đón trẻ |
> | 12 | Kiểm tra cơ sở vật chất, bàn ghế, trang thiết bị, đồ dùng đồ chơi tại các điểm trường; rà soát các nguy cơ mất an toàn và chỉ đạo khắc phục trước khi đón trẻ. | Trong tháng |
> | 13 | Tăng cường công tác y tế học đường, vệ sinh môi trường, phòng chống dịch bệnh; tuyên truyền phòng tránh tai nạn thương tích, bạo lực và xâm hại trẻ em. | Thường xuyên |
> | 14 | Chỉ đạo các nhóm lớp chuẩn bị điều kiện đón trẻ, xây dựng nền nếp sinh hoạt đầu năm; phối hợp cha mẹ trẻ hướng dẫn trẻ thích nghi với môi trường học tập. | Theo lịch đón trẻ |
> | 15 | Phối hợp Chi đoàn tổ chức vệ sinh môi trường, trang trí khuôn viên, hỗ trợ công tác chuẩn bị năm học mới và duy trì các hoạt động chăm lo trẻ khó khăn. | Trong tháng |
> | 16 | Chỉ đạo công tác hành chính, văn thư, lưu trữ; hoàn thiện các loại hồ sơ, kế hoạch, văn bản và báo cáo phục vụ năm học mới. | Trong tháng |
> | 17 | Chỉ đạo công tác tài chính – kế toán, thực hiện chi trả chế độ chính sách; kiểm tra, đối chiếu chứng từ và chuẩn bị các điều kiện tài chính phục vụ hoạt động đầu năm học. | Trong tháng |
> | 18 | Kiểm tra toàn diện công tác chuẩn bị năm học mới tại các điểm trường, nhóm lớp; kịp thời chỉ đạo giải quyết những khó khăn về nhân sự, cơ sở vật chất và các điều kiện đón trẻ. | Cuối tháng |
> | 19 | Chỉ đạo hoàn thiện số liệu huy động trẻ, dự kiến số nhóm lớp, phân công nhân sự và các nhiệm vụ trọng tâm phục vụ triển khai năm học 2026–2027. | Cuối tháng |
> | 20 | Tổng hợp, đánh giá kết quả nhiệm vụ tháng 08; hoàn thành báo cáo và chuẩn bị triển khai nhiệm vụ trọng tâm tháng 09/2026. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

---

## ✅ Tổng hợp các bảng kê đã xây dựng

| Tháng | Số nhiệm vụ |
|--------|--------|
| 01/2026 | 17 |
| 02/2026 | 18 |
| 03/2026 | 18 |
| 04/2026 | 18 |
| 05/2026 | 18 |
| 07/2026 | 18 |
| 08/2026 | 20 |
| **Tổng cộng** | **127** |

Mình đã hoàn thành nội dung của cả 7 tháng theo các báo cáo bạn cung cấp. Những nhiệm vụ như kiểm tra chất lượng chăm sóc, an toàn trường học, giám sát cơ sở vật chất và báo cáo cuối tháng được bổ sung theo hướng quản lý thực tiễn, không phải tất cả đều xuất hiện nguyên văn trong phương hướng của từng báo cáo.

**Hai lưu ý trước khi sử dụng chính thức:** Báo cáo có điểm chưa thống nhất về cấp tổ chức Hội thi Giáo viên dạy giỏi tháng 03 và có dẫn chiếu Nghị định 98/2026 trong phần nhiệm vụ tháng 07–08. Mình đã diễn đạt theo hướng không khẳng định những thông tin cần đối chiếu này. Ngoài ra, chưa có báo cáo làm căn cứ trực tiếp để lập bảng kê tháng 06/2026.

Hiện mình chưa thể đính kèm trực tiếp các tệp `.docx` trong phiên này. Các bảng trên đã được trình bày để bạn có thể sao chép riêng từng tháng sang Word, lưu thành 7 văn bản, căn chỉnh khổ A4, phông Times New Roman và bổ sung ngày, tháng ký ban hành theo thực tế.

---

USER

---

ASSISTANT

Mình đã nhận được **Báo cáo kết quả hoạt động tháng 9 và phương hướng tháng 10/2025** của Trường Mầm non An Bình A.

Mình tiếp tục xây dựng **Bảng kê nhiệm vụ tháng 10/2025**, theo đúng mẫu 3 cột đã thống nhất. Nội dung b

---

USER

bạn có thể tạo ggiup1 tôi tháng 12 không?

---

ASSISTANT

Mình đã dựa vào **Báo cáo kết quả hoạt động tháng 12/2025 và phương hướng tháng 01/2026** của Trường Mầm non An Bình A để xây dựng bảng kê nhiệm vụ tháng 12/2025.

Bảng gồm **20 nhiệm vụ**, giữ đúng mẫu 3 cột bạn đã gửi, tập trung vào công tác chỉ đạo, quản lý và điều hành của Hiệu trưởng, phù hợp với hoạt động thực tế của nhà trường.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 12/2025
>
> **Năm học 2025–2026**
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 12/2025; chỉ đạo các tổ chuyên môn, bộ phận thực hiện chương trình, kế hoạch giáo dục và các nhiệm vụ theo hướng dẫn của ngành. | Đầu tháng |
> | 2 | Rà soát mục tiêu, nội dung trong kế hoạch giáo dục của nhà trường, tổ chuyên môn và giáo viên; chỉ đạo điều chỉnh những nội dung chưa phù hợp với độ tuổi, khả năng của trẻ và điều kiện thực tế. | Tuần 1–2 |
> | 3 | Kiểm tra việc xây dựng kế hoạch, soạn giảng và tổ chức các hoạt động giáo dục theo chủ đề ngành nghề, hiện tượng tự nhiên; hướng dẫn giáo viên vận dụng phương pháp STEAM và giáo dục lấy trẻ làm trung tâm. | Trong tháng |
> | 4 | Dự sinh hoạt chuyên môn của các tổ; chỉ đạo nâng cao chất lượng sinh hoạt chuyên môn, tập trung tháo gỡ khó khăn trong việc lựa chọn nội dung, phân bổ mục tiêu giáo dục và tổ chức hoạt động cho trẻ. | Theo kế hoạch |
> | 5 | Kiểm tra, thăm lớp, dự giờ nhằm nắm tình hình thực hiện chương trình giáo dục; tư vấn, hỗ trợ giáo viên đổi mới phương pháp và nâng cao chất lượng tổ chức các hoạt động. | Trong tháng |
> | 6 | Chỉ đạo xây dựng kế hoạch và tổ chức chương trình “Chiến sĩ tí hon”, hoạt động xem phim tư liệu, trò chuyện, giáo dục truyền thống nhân kỷ niệm 81 năm Ngày thành lập Quân đội nhân dân Việt Nam 22/12. | Dịp 22/12 |
> | 7 | Tham mưu UBND phường An Bình về công tác phổ cập giáo dục mầm non; chỉ đạo rà soát, bổ sung hồ sơ, biểu mẫu và minh chứng theo hướng dẫn của ngành. | Trong tháng |
> | 8 | Phối hợp thực hiện công tác tự kiểm tra hồ sơ phổ cập giáo dục tại địa phương; đối chiếu số liệu trẻ trong độ tuổi, chuẩn bị các điều kiện phục vụ công tác kiểm tra của cấp trên. | Theo kế hoạch |
> | 9 | Chỉ đạo rà soát, cập nhật số liệu huy động trẻ tại các điểm trường; phối hợp địa phương và cha mẹ trẻ vận động trẻ ra lớp, duy trì kết quả huy động trẻ mẫu giáo 5 tuổi. | Trong tháng |
> | 10 | Kiểm tra việc cập nhật thông tin trẻ trên cơ sở dữ liệu ngành; rà soát danh sách trẻ tham gia sổ liên lạc điện tử và chỉ đạo giáo viên gửi thông tin kết quả học tập của trẻ qua phần mềm VNEDU. | Trong tháng |
> | 11 | Phối hợp với các trung tâm ngoại ngữ, aerobic, QME tổ chức hoạt động ngoại khóa; kiểm tra nội dung, điều kiện tổ chức và việc bảo đảm an toàn cho trẻ. | Theo lịch |
> | 12 | Chỉ đạo công tác chăm sóc, nuôi dưỡng, vệ sinh an toàn thực phẩm, y tế học đường; tăng cường phòng chống dịch bệnh, phòng tránh tai nạn thương tích và bảo đảm an toàn cho trẻ. | Thường xuyên |
> | 13 | Kiểm tra, rà soát cơ sở vật chất, đồ dùng, đồ chơi tại các nhóm lớp; theo dõi việc sửa chữa nhà kho, trang bị và sử dụng đồ dùng, đồ chơi tại khu kỹ năng. | Trong tháng |
> | 14 | Chỉ đạo kiểm kê đồ dùng, thiết bị giáo dục, cập nhật các biểu mẫu thống kê cơ sở vật chất phục vụ công tác quản lý và phổ cập giáo dục mầm non. | Trong tháng |
> | 15 | Chỉ đạo cập nhật hồ sơ nhân sự, thông tin trẻ em trên cơ sở dữ liệu ngành; kiểm tra, tổng hợp và thực hiện các báo cáo theo đúng thời gian quy định. | Trong tháng |
> | 16 | Chỉ đạo thực hiện công tác tài chính – kế toán; chi trả tiền lương, phụ cấp, các chế độ chính sách; kiểm tra, đối chiếu chứng từ và thanh quyết toán các khoản chi theo quy định. | Trong tháng |
> | 17 | Chỉ đạo công tác hành chính, văn thư, tiếp nhận, xử lý văn bản và lưu trữ hồ sơ; rà soát các nội dung công việc, chuẩn bị số liệu phục vụ báo cáo cuối năm. | Thường xuyên |
> | 18 | Phối hợp với Chi đoàn thực hiện trang trí, cải tạo cảnh quan trường học, bổ sung góc chơi; tổ chức các hoạt động phát thanh măng non và tuyên truyền giáo dục trẻ. | Trong tháng |
> | 19 | Phối hợp Chi đoàn và các tổ chức liên quan thực hiện mô hình “Ước mơ xanh”, tham gia các hoạt động tình nguyện, vận động hỗ trợ trẻ em có hoàn cảnh khó khăn; tuyên truyền thực hành tiết kiệm, chống lãng phí. | Trong tháng |
> | 20 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 12/2025; rà soát những tồn tại, hạn chế trong công tác chuyên môn và xây dựng phương hướng, nhiệm vụ tháng 01/2026. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

### 💡 Lưu ý khi sử dụng

Bảng kê được xây dựng từ những công việc thực tế thể hiện trong báo cáo tháng 12, đồng thời cụ thể hóa nhiệm vụ chỉ đạo của Hiệu trưởng. Mình đặc biệt chú trọng 3 nội dung: **chuẩn bị kiểm tra phổ cập giáo dục, nâng cao chất lượng sinh hoạt chuyên môn và tổ chức hoạt động giáo dục ngày 22/12**.

Thời gian trong cột *Ghi chú* là đề xuất, cần đối chiếu lịch công tác tháng 12 của đơn vị trước khi sử dụng chính thức.

Bạn có thể sao chép bảng này sang Word, trình bày khổ A4, phông Times New Roman, giữ nguyên 3 cột theo mẫu.

---

USER

---

ASSISTANT

Mình đã nhận được **Báo cáo kết quả hoạt động tháng 9 và phương hướng tháng 10/2025** của Trường Mầm non An Bình A.

Mình tiếp tục xây dựng **Bảng kê nhiệm vụ tháng 10/2025** theo đúng mẫu các tháng trước, gồm 3 cột: STT – Nội dung nhiệm vụ thực hiện – Ghi chú.

Bảng kê dưới đây bám sát phương hướng tháng 10, đồng thời cụ thể hóa một số công việc quản lý thường xuyên phù hợp với thực tiễn nhà trường.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 10/2025
>
> **Năm học 2025–2026**
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 10/2025; chỉ đạo các tổ chuyên môn, bộ phận thực hiện chương trình, kế hoạch giáo dục và các nhiệm vụ theo hướng dẫn của ngành. | Đầu tháng |
> | 2 | Chỉ đạo chuẩn bị và tổ chức hoạt động “Vui hội trăng rằm” cho trẻ; phối hợp với các bộ phận tổ chức các hoạt động vui chơi, trải nghiệm phù hợp lứa tuổi, bảo đảm an toàn, tiết kiệm. | Ngày 03/10 |
> | 3 | Phối hợp với Chi đoàn, cha mẹ trẻ và các tổ chức liên quan thực hiện hoạt động chăm lo, hỗ trợ trẻ có hoàn cảnh khó khăn nhân dịp Tết Trung thu. | Dịp Trung thu |
> | 4 | Tham mưu, xây dựng và triển khai các văn bản chỉ đạo thực hiện nhiệm vụ chuyên môn trong tháng; phân công, đôn đốc các tổ chuyên môn thực hiện theo kế hoạch. | Trong tháng |
> | 5 | Rà soát mục tiêu, nội dung kế hoạch giáo dục của nhà trường, tổ chuyên môn và giáo viên theo Chương trình Giáo dục mầm non hiện hành; chỉ đạo điều chỉnh những nội dung chưa phù hợp độ tuổi và khả năng của trẻ. | Trong tháng |
> | 6 | Kiểm tra, thăm lớp, dự giờ nhằm nắm tình hình thực hiện chương trình giáo dục; hướng dẫn giáo viên khắc phục việc tổ chức hoạt động chưa đáp ứng mục tiêu, yêu cầu giáo dục. | Trong tháng |
> | 7 | Chỉ đạo giáo viên vận dụng phương pháp STEAM, giáo dục lấy trẻ làm trung tâm; lồng ghép giáo dục quyền trẻ em, kỹ năng sống, phòng cháy chữa cháy và xây dựng trường học hạnh phúc trong các hoạt động giáo dục. | Thường xuyên |
> | 8 | Dự sinh hoạt chuyên môn của các tổ theo kế hoạch; chỉ đạo trao đổi, chia sẻ kinh nghiệm về lựa chọn nội dung, phương pháp và hình thức tổ chức hoạt động giáo dục phù hợp với trẻ. | Theo lịch SHCM |
> | 9 | Kiểm tra, đối chiếu số liệu trẻ đầu năm học tại các điểm trường, nhóm lớp; rà soát tình hình trẻ ra lớp, biến động tăng giảm và tính chính xác của các biểu mẫu thống kê. | Trong tháng |
> | 10 | Phối hợp với các khóm trên địa bàn rà soát, cập nhật thông tin trẻ trong độ tuổi; chỉ đạo tuyên truyền, vận động trẻ ra lớp theo chỉ tiêu huy động năm học 2025–2026. | Trong tháng |
> | 11 | Thực hiện bàn giao số liệu trẻ thuộc khóm An Lộc cho Trường Mầm non An Bình B theo chỉ đạo về công tác tuyển sinh của UBND phường; bảo đảm số liệu đầy đủ, thống nhất. | Theo chỉ đạo |
> | 12 | Chỉ đạo rà soát, cập nhật hồ sơ, biểu mẫu phổ cập giáo dục mầm non; đối chiếu thông tin trẻ 5 tuổi, hoàn thiện số liệu phục vụ công tác phổ cập theo quy định. | Trong tháng |
> | 13 | Kiểm tra việc tổng hợp, xử lý và báo cáo số liệu của các bộ phận; hướng dẫn sử dụng Excel, lọc dữ liệu và cập nhật thông tin trên phần mềm nhằm hạn chế sai sót, bảo đảm tiến độ báo cáo. | Trong tháng |
> | 14 | Rà soát danh sách trẻ tham gia sổ liên lạc điện tử; chỉ đạo giáo viên cập nhật, gửi thông tin kết quả học tập và các hoạt động của trẻ đến cha mẹ trẻ qua phần mềm VNEDU. | Trong tháng |
> | 15 | Chỉ đạo lồng ghép các hoạt động giáo dục chào mừng Ngày Phụ nữ Việt Nam 20/10; phối hợp tổ chức các hoạt động phù hợp với điều kiện nhà trường. | Dịp 20/10 |
> | 16 | Kiểm tra công tác chăm sóc, nuôi dưỡng, vệ sinh an toàn thực phẩm, y tế học đường; tăng cường tuyên truyền phòng chống bệnh sốt xuất huyết và bảo đảm an toàn cho trẻ. | Thường xuyên |
> | 17 | Kiểm tra cơ sở vật chất, đồ dùng, đồ chơi tại các điểm trường; theo dõi việc sửa chữa nhà kho, bổ sung trang thiết bị và sử dụng khu kỹ năng phục vụ hoạt động giáo dục. | Trong tháng |
> | 18 | Phối hợp với các trung tâm ngoại ngữ, aerobic, QME tổ chức hoạt động ngoại khóa; kiểm tra nội dung, điều kiện tổ chức và bảo đảm an toàn cho trẻ. | Theo lịch |
> | 19 | Chỉ đạo thực hiện công tác hành chính, văn thư, lưu trữ; cập nhật dữ liệu nhân sự, trẻ em; theo dõi công tác tài chính, chế độ chính sách và thực hiện các báo cáo theo quy định. | Trong tháng |
> | 20 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 10/2025; rà soát những hạn chế, đề xuất giải pháp khắc phục và xây dựng phương hướng thực hiện nhiệm vụ tháng 11/2025. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

### Một số điểm cần lưu ý

Bảng kê đã thể hiện những nhiệm vụ đặc thù của tháng 10, đặc biệt là **tổ chức Trung thu, bàn giao số liệu trẻ khóm An Lộc, khắc phục sai sót khi tổng hợp dữ liệu và rà soát kế hoạch giáo dục**.

Các nhiệm vụ về tài chính, y tế, cơ sở vật chất và giám sát ngoại khóa là nội dung quản lý thường xuyên được đề xuất bổ sung, không phải toàn bộ đều được ghi trong phần phương hướng của báo cáo.

Cột ghi chú sử dụng thời gian dự kiến đối với các nhiệm vụ chưa có lịch cụ thể. Bạn có thể điều chỉnh theo lịch công tác thực tế trước khi ký ban hành.

---

USER

---

ASSISTANT

Mình đã nhận được **Báo cáo kết quả hoạt động tháng 06 và phương hướng tháng 07/2026** của Trường Mầm non An Bình A.

Do bảng kê tháng 07 đã được xây dựng trước đó, mình sẽ bổ sung **Bảng kê nhiệm vụ tháng 06/2026** còn thiếu trong bộ hồ sơ. Nội dung được chuyển từ phần kết quả hoạt động tháng 06 thành các nhiệm vụ quản lý tương ứng, giữ đúng mẫu 3 cột như bạn yêu cầu.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH A**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 06/2026
>
> **Năm học 2025–2026**
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai các nhiệm vụ trọng tâm tháng 06/2026; chỉ đạo các tổ chuyên môn, bộ phận hoàn thiện hồ sơ, báo cáo tổng kết năm học 2025–2026 và chuẩn bị nhiệm vụ năm học mới. | Đầu tháng |
> | 2 | Rà soát, chỉ đạo hoàn thiện công tác đánh giá, xếp loại chất lượng viên chức và đánh giá giáo viên theo chuẩn nghề nghiệp; tổng hợp, lưu trữ hồ sơ theo quy định. | Trong tháng |
> | 3 | Chỉ đạo các tổ chuyên môn rà soát kết quả thực hiện Chương trình Giáo dục mầm non năm học 2025–2026; xác định những nội dung cần điều chỉnh, bổ sung trong kế hoạch giáo dục năm học 2026–2027. | Trong tháng |
> | 4 | Chỉ đạo rà soát mục tiêu giáo dục, nội dung tích hợp quyền trẻ em, giáo dục STEAM, giáo dục lấy trẻ làm trung tâm, kỹ năng phòng tránh tai nạn và xây dựng trường học hạnh phúc để chuẩn bị kế hoạch năm học mới. | Trong tháng |
> | 5 | Kiểm tra, rà soát số liệu huy động trẻ trong năm học 2025–2026; tổng hợp tình hình trẻ nhà trẻ, mẫu giáo và trẻ 5 tuổi phục vụ công tác báo cáo cuối năm. | Trong tháng |
> | 6 | Phối hợp với các khóm trên địa bàn rà soát danh sách trẻ trong độ tuổi, chuẩn bị điều tra phổ cập giáo dục mầm non và xây dựng phương án huy động trẻ ra lớp năm học 2026–2027. | Trong tháng |
> | 7 | Chỉ đạo cập nhật, đối chiếu số liệu trẻ, thông tin nhân sự trên cơ sở dữ liệu ngành; hoàn thiện các biểu mẫu, báo cáo tổng kết theo yêu cầu của cơ quan quản lý giáo dục. | Trong tháng |
> | 8 | Rà soát nhu cầu tuyển sinh, dự kiến số lượng trẻ và số nhóm lớp năm học 2026–2027 để chuẩn bị phương án bố trí đội ngũ, cơ sở vật chất phù hợp. | Trong tháng |
> | 9 | Kiểm tra, tổng hợp tình hình đội ngũ cán bộ quản lý, giáo viên, nhân viên; rà soát nhu cầu nhân sự phục vụ công tác phân công nhiệm vụ năm học mới. | Trong tháng |
> | 10 | Chỉ đạo phối hợp với cha mẹ trẻ thực hiện công tác khám sức khỏe; rà soát số lượng trẻ chưa tham gia và tuyên truyền, vận động đưa trẻ đến điểm khám theo lịch. | Theo lịch khám |
> | 11 | Tăng cường chỉ đạo công tác y tế học đường, vệ sinh môi trường, phòng chống dịch bệnh; tuyên truyền phòng tránh tai nạn thương tích, đuối nước và bảo đảm an toàn cho trẻ trong thời gian nghỉ hè. | Thường xuyên |
> | 12 | Chỉ đạo kiểm kê tài sản, trang thiết bị, đồ dùng, đồ chơi tại các điểm trường; đối chiếu số liệu, cập nhật các biểu mẫu quản lý cơ sở vật chất theo quy định. | Trong tháng |
> | 13 | Rà soát, đánh giá thực trạng cơ sở vật chất, khu vui chơi, khu trải nghiệm và các hạng mục cần sửa chữa; đề xuất trang bị, bổ sung đồ dùng phục vụ năm học 2026–2027. | Trong tháng |
> | 14 | Phối hợp với Chi đoàn thực hiện vệ sinh, cải tạo cảnh quan, chăm sóc bồn hoa, cây xanh, trang trí các góc chơi và chuẩn bị môi trường giáo dục cho năm học mới. | Trong tháng |
> | 15 | Phối hợp với Chi đoàn và các tổ chức liên quan thực hiện hoạt động tình nguyện, thăm hỏi, hỗ trợ trẻ em và gia đình có hoàn cảnh khó khăn tại địa phương. | Theo kế hoạch |
> | 16 | Chỉ đạo thực hiện công tác hành chính, văn thư, lưu trữ; tiếp nhận, xử lý văn bản, rà soát hồ sơ quản lý và thực hiện các báo cáo định kỳ, đột xuất theo quy định. | Thường xuyên |
> | 17 | Chỉ đạo thực hiện công tác tài chính – kế toán; chi trả tiền lương, phụ cấp, các chế độ chính sách; kiểm tra, đối chiếu chứng từ và thanh quyết toán các khoản chi theo quy định. | Trong tháng |
> | 18 | Kiểm tra việc quản lý, sử dụng tài sản, công cụ dụng cụ, kinh phí hoạt động; chỉ đạo thực hiện công khai tài chính theo quy định. | Trong tháng |
> | 19 | Rà soát kết quả thực hiện nhiệm vụ của các tổ chuyên môn, bộ phận; đánh giá những thuận lợi, khó khăn và đề xuất các giải pháp nâng cao hiệu quả hoạt động trong năm học mới. | Cuối tháng |
> | 20 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 06/2026; hoàn thành báo cáo và xây dựng phương hướng tháng 07, tập trung chuẩn bị các điều kiện cho năm học 2026–2027. | Cuối tháng |
>
> **HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Huỳnh Hồng Loan**

### 💡 Lưu ý về nội dung

Bảng kê tháng 06 được xây dựng từ **kết quả công việc đã báo cáo**, không phải từ một kế hoạch tháng 06 được cung cấp riêng. Vì vậy, các nhiệm vụ và thời gian thực hiện mang tính tổng hợp, đối chiếu; bạn nên rà soát với lịch công tác thực tế trước khi đưa vào hồ sơ chính thức.

Những nhiệm vụ nổi bật của tháng 06 là đánh giá viên chức, chuẩn nghề nghiệp; hoàn thiện báo cáo tổng kết; điều tra trẻ trong độ tuổi; kiểm kê cơ sở vật chất và chuẩn bị năm học 2026–2027.

Như vậy, mình đã bổ sung bảng kê tháng 06 để cùng với những tháng trước hình thành bộ bảng kê nhiệm vụ của nhà trường.

---

USER

viết giúp tôi tháng 9, 10 năm 26

---

ASSISTANT

Mình sẽ lập 2 bảng kê riêng cho tháng 9 và tháng 10/2026 theo mẫu 3 cột trước đây. Mình sẽ sử dụng tên **Trường Mầm non An Bình** sau sáp nhập, bám sát công việc tại 3 điểm trường và phân biệt số nhân sự được báo cáo ở từng tháng để tránh dùng nhầm thông tin của năm học trước.

---

ASSISTANT

# BẢNG KÊ NHIỆM VỤ THÁNG 9 VÀ THÁNG 10/2026

Trường Mầm non An Bình – Năm học 2026–2027

Mình đã đối chiếu hai báo cáo tháng 9 và tháng 10/2026. Đây là giai đoạn nhà trường hoạt động sau sáp nhập, quản lý 3 điểm trường **An Bình, An Lộc và An Bình A**. Vì vậy, bảng kê sẽ chú trọng cả công tác quản lý đội ngũ, chuyên môn, bán trú, tài chính và tài sản sau sáp nhập.

## 1. Bảng kê nhiệm vụ tháng 9/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 9/2026
>
> **Năm học 2026–2027**
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 9/2026; chỉ đạo các tổ chuyên môn và bộ phận ổn định tổ chức, nền nếp hoạt động sau sáp nhập, thực hiện nhiệm vụ năm học 2026–2027 tại 03 điểm trường. | Đầu tháng |
> | 2 | Rà soát, phân công, bố trí nhiệm vụ cho 84 cán bộ quản lý, giáo viên, nhân viên; bảo đảm phù hợp vị trí việc làm, năng lực chuyên môn và tình hình thực tế tại các điểm trường. | Trong tháng |
> | 3 | Chỉ đạo chuẩn bị và tổ chức Lễ khai giảng năm học 2026–2027; phối hợp các bộ phận và Chi đoàn thực hiện trang trí, văn nghệ, vệ sinh khuôn viên, tạo môi trường an toàn, thân thiện đón trẻ. | Đầu tháng |
> | 4 | Chỉ đạo các tổ chuyên môn triển khai chương trình, kế hoạch giáo dục; kiểm tra việc xây dựng kế hoạch, soạn giảng, trang trí lớp học theo chủ đề, bảo đảm phù hợp độ tuổi và điều kiện thực tế. | Trong tháng |
> | 5 | Rà soát mục tiêu, nội dung giáo dục; chỉ đạo lồng ghép giáo dục quyền trẻ em, STEAM, phòng chống cháy nổ, kỹ năng sống, xây dựng trường học hạnh phúc và giáo dục lấy trẻ làm trung tâm. | Trong tháng |
> | 6 | Dự sinh hoạt chuyên môn của các tổ; hướng dẫn, hỗ trợ giáo viên thực hiện chương trình, đổi mới phương pháp và tổ chức các hoạt động học thông qua chơi, trải nghiệm, khám phá. | Theo kế hoạch |
> | 7 | Chỉ đạo tổ chức cân đo, theo dõi sự phát triển thể chất và chấm biểu đồ tăng trưởng của trẻ quý I; kiểm tra việc cập nhật hồ sơ theo dõi sức khỏe. | Trong tháng |
> | 8 | Chỉ đạo tổ chức công tác bán trú tại 03 điểm trường với bình quân 350 suất ăn/ngày; kiểm tra việc xây dựng thực đơn, cân đối khẩu phần và bảo đảm chế độ dinh dưỡng phù hợp độ tuổi. | Thường xuyên |
> | 9 | Kiểm tra quy trình giao nhận thực phẩm, kiểm thực 3 bước, lưu mẫu thức ăn hằng ngày; giám sát nguồn gốc, chất lượng và số lượng thực phẩm phục vụ bán trú. | Thường xuyên |
> | 10 | Kiểm tra điều kiện vệ sinh bếp ăn, quy trình sơ chế, chế biến, chia ăn và tổ chức giờ ăn, ngủ; chỉ đạo thực hiện các biện pháp bảo đảm an toàn cho trẻ tại 03 điểm trường. | Thường xuyên |
> | 11 | Chỉ đạo công tác y tế học đường, vệ sinh môi trường, phòng chống dịch bệnh; phối hợp Chi đoàn tuyên truyền phòng chống bệnh sốt xuất huyết và các bệnh thường gặp ở trẻ. | Trong tháng |
> | 12 | Phối hợp với các trung tâm ngoại ngữ, aerobic, QME tổ chức hoạt động ngoại khóa; kiểm tra nội dung và các điều kiện bảo đảm an toàn cho trẻ. | Theo lịch tổ chức |
> | 13 | Rà soát, đối chiếu số liệu huy động trẻ đầu năm học; theo dõi tình hình trẻ nhà trẻ, mẫu giáo 3–5 tuổi và trẻ 5 tuổi; phối hợp địa phương vận động trẻ ra lớp theo chỉ tiêu. | Trong tháng |
> | 14 | Chỉ đạo thực hiện công tác phổ cập giáo dục mầm non, rà soát danh sách trẻ 5 tuổi đang học tại các cơ sở khác; cập nhật hồ sơ, biểu mẫu và số liệu phổ cập theo hướng dẫn. | Trong tháng |
> | 15 | Kiểm tra việc cập nhật thông tin nhân sự, học sinh trên cơ sở dữ liệu ngành; rà soát danh sách trẻ tham gia sổ liên lạc điện tử và cập nhật thông tin trên phần mềm VNEDU. | Trong tháng |
> | 16 | Rà soát dự toán ngân sách của các đơn vị trước sáp nhập; phối hợp tổng hợp, điều chỉnh, phân bổ dự toán và xác định các khoản kinh phí còn dư, chưa sử dụng, cần chuyển nguồn. | Trong tháng |
> | 17 | Chỉ đạo kiểm kê, đối chiếu, chốt số liệu kế toán tại thời điểm sáp nhập; tiếp nhận, bàn giao sổ sách, chứng từ, báo cáo tài chính và dữ liệu kế toán, bảo đảm kinh phí hoạt động của đơn vị. | Trong tháng |
> | 18 | Chỉ đạo rà soát, tiếp nhận và đối chiếu hồ sơ bàn giao tài sản của các đơn vị trước sáp nhập; kiểm tra hiện trạng phòng học, công trình, đồ dùng, đồ chơi và trang thiết bị tại 03 điểm trường. | Trong tháng |
> | 19 | Triển khai công tác rà soát cơ sở vật chất theo Kế hoạch số 16/KH-MNAB ngày 26/8/2026; thực hiện quản lý, sử dụng tài sản theo Kế hoạch số 163/KH-MNAB ngày 21/9/2026, phân công trách nhiệm quản lý và bảo quản tài sản. | Trong tháng |
> | 20 | Kiểm tra, hướng dẫn các bộ phận khắc phục hạn chế trong cập nhật số liệu phổ cập và lập báo cáo; hỗ trợ sử dụng Excel, lọc dữ liệu, đối chiếu thông tin nhằm nâng cao độ chính xác và bảo đảm tiến độ. | Trong tháng |
> | 21 | Tổng hợp kết quả thực hiện nhiệm vụ tháng 9/2026, rà soát số liệu và những hạn chế cần khắc phục; hoàn thành báo cáo và xây dựng phương hướng hoạt động tháng 10/2026. | Cuối tháng |
>
> **PHÓ HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Nguyễn Thị Huỳnh Duyên**

## 2. Bảng kê nhiệm vụ tháng 10/2026

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> # BẢNG KÊ NHIỆM VỤ THÁNG 10/2026
>
> **Năm học 2026–2027**
>
> | STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
> |:---:|---|---|
> | 1 | Triển khai nhiệm vụ trọng tâm tháng 10/2026; rà soát, bố trí và phân công nhiệm vụ cho 83 cán bộ quản lý, giáo viên, nhân viên, bảo đảm phù hợp vị trí việc làm và điều kiện hoạt động tại 03 điểm trường. | Đầu tháng |
> | 2 | Tăng cường kiểm tra việc chấp hành giờ giấc làm việc, kỷ luật, kỷ cương hành chính và thực hiện nhiệm vụ được giao; chỉ đạo nâng cao tinh thần trách nhiệm, hiệu quả phối hợp giữa các bộ phận, các điểm trường. | Trong tháng |
> | 3 | Chỉ đạo duy trì tổ chức bán trú tại 03 điểm trường với bình quân 350 suất ăn/ngày; kiểm tra việc xây dựng thực đơn, cân đối khẩu phần và bảo đảm nhu cầu dinh dưỡng phù hợp từng độ tuổi. | Thường xuyên |
> | 4 | Kiểm tra, giám sát quy trình giao nhận thực phẩm, kiểm thực 3 bước, lưu mẫu thức ăn hằng ngày; kiểm soát nguồn gốc, chất lượng và số lượng thực phẩm nhập vào các bếp ăn. | Thường xuyên |
> | 5 | Kiểm tra quy trình sơ chế, chế biến, chia ăn, vệ sinh dụng cụ và môi trường ăn uống tại các bếp; kịp thời chỉ đạo khắc phục những hạn chế, bảo đảm an toàn thực phẩm. | Trong tháng |
> | 6 | Chỉ đạo giáo viên, nhân viên thực hiện tốt chế độ sinh hoạt, chăm sóc giờ ăn, ngủ và vệ sinh cá nhân; phòng tránh nguy cơ hóc, sặc thức ăn và bảo đảm an toàn cho trẻ trong các hoạt động. | Thường xuyên |
> | 7 | Chỉ đạo công tác y tế học đường, theo dõi sức khỏe trẻ; tăng cường vệ sinh, khử khuẩn đồ dùng, đồ chơi và phòng chống bệnh tay chân miệng, sốt xuất huyết, các bệnh thường gặp. | Trong tháng |
> | 8 | Chỉ đạo các tổ chuyên môn thực hiện chương trình, kế hoạch giáo dục theo tiến độ; rà soát mục tiêu, nội dung, phương pháp và hình thức tổ chức hoạt động phù hợp với độ tuổi, khả năng của trẻ. | Trong tháng |
> | 9 | Kiểm tra, hướng dẫn giáo viên đổi mới phương pháp giáo dục theo quan điểm lấy trẻ làm trung tâm; tăng cường hoạt động học thông qua chơi, trải nghiệm, khám phá và rèn kỹ năng sống. | Trong tháng |
> | 10 | Chỉ đạo vận dụng phù hợp giáo dục STEM, giáo dục cảm xúc, bảo vệ môi trường; hỗ trợ giáo viên ứng dụng công nghệ thông tin và trí tuệ nhân tạo (AI) trong xây dựng kế hoạch, thiết kế hoạt động giáo dục. | Trong tháng |
> | 11 | Kiểm tra hồ sơ, kế hoạch, giáo án của giáo viên; hướng dẫn khắc phục lỗi viết tắt, thiếu ngày dạy, lỗi chính tả, hình thức trình bày và sự chưa thống nhất giữa mục tiêu, nội dung hoạt động. | Trong tháng |
> | 12 | Tổ chức thăm lớp, dự giờ, kiểm tra việc thực hiện chương trình; chú trọng hỗ trợ giáo viên ổn định nền nếp đối với trẻ mới nhập học, trẻ đi học muộn, giúp trẻ mạnh dạn và tích cực tham gia hoạt động. | Trong tháng |
> | 13 | Dự sinh hoạt chuyên môn của các tổ; chỉ đạo tăng cường trao đổi, chia sẻ kinh nghiệm bằng hình thức trực tiếp kết hợp trực tuyến nhằm bảo đảm sự thống nhất chuyên môn giữa 03 điểm trường. | Theo lịch SHCM |
> | 14 | Rà soát, hoàn thiện quy chế chuyên môn, quy chế đánh giá viên chức; phối hợp chuẩn bị nội dung, hồ sơ và các điều kiện tổ chức Hội nghị viên chức, người lao động theo kế hoạch của nhà trường. | Cuối tháng |
> | 15 | Phối hợp chuẩn bị, tổ chức hoạt động họp mặt và các hoạt động chào mừng Ngày Phụ nữ Việt Nam 20/10; chỉ đạo lồng ghép nội dung giáo dục phù hợp trong hoạt động của trẻ. | Theo lịch tổ chức |
> | 16 | Kiểm tra số liệu trẻ tại các điểm trường, rà soát biến động tăng giảm, cập nhật danh sách trẻ trong độ tuổi; chỉ đạo hoàn thiện hồ sơ phổ cập giáo dục mầm non và thực hiện báo cáo đúng quy định. | Trong tháng |
> | 17 | Chỉ đạo cập nhật thông tin nhân sự, trẻ em trên cơ sở dữ liệu ngành; rà soát danh sách tham gia sổ liên lạc điện tử, thực hiện gửi thông tin kết quả học tập của trẻ qua phần mềm VNEDU. | Trong tháng |
> | 18 | Chỉ đạo thực hiện công tác tài chính – kế toán; kiểm tra việc chi trả lương, tiền công, phụ cấp, các khoản đóng góp, kinh phí hoạt động và các khoản chi từ tiền gửi, bán trú, chăm sóc sức khỏe ban đầu theo quy định. | Trong tháng |
> | 19 | Kiểm tra công tác quản lý, sử dụng và bảo quản tài sản sau sáp nhập tại các lớp, phòng chức năng, bếp ăn, sân chơi và các điểm trường theo Kế hoạch số 163/KH-MNAB ngày 21/9/2026. | Trong tháng |
> | 20 | Chỉ đạo rà soát, phân loại tài sản hư hỏng, hết thời hạn hoặc không còn nhu cầu sử dụng; đề xuất điều chuyển, sửa chữa, mua sắm các hạng mục cần thiết, ưu tiên hệ thống điện, nước, nhà vệ sinh, phòng học và thiết bị bảo đảm an toàn cho trẻ. | Trong tháng |
> | 21 | Phối hợp Chi đoàn thực hiện công tác tuyên truyền phòng chống dịch bệnh qua chương trình phát thanh măng non; tham gia các phong trào do Phường đoàn phát động, duy trì môi trường xanh – sạch – đẹp. | Trong tháng |
> | 22 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 10/2026; rà soát các hạn chế trong công tác chuyên môn, chăm sóc nuôi dưỡng và quản lý tài sản; hoàn thành báo cáo, xây dựng phương hướng tháng 11/2026. | Cuối tháng |
>
> **PHÓ HIỆU TRƯỞNG**
>
> *(Ký, ghi rõ họ tên)*
>
> **Nguyễn Thị Huỳnh Duyên**

## Một số lưu ý trước khi sử dụng

Hai bảng kê đã được xây dựng phù hợp với tình hình nhà trường sau sáp nhập, đặc biệt là:

- **Nhân sự:** Tháng 9 ghi nhận 84 người, tháng 10 ghi nhận 83 người theo từng báo cáo.
- **Bán trú:** Phục vụ bình quân 350 suất ăn/ngày tại 3 điểm trường, có nhiệm vụ kiểm tra an toàn thực phẩm và chất lượng chăm sóc trẻ.
- **Cơ sở vật chất:** Chú trọng tiếp nhận, kiểm kê, bảo quản và xử lý tài sản sau sáp nhập.
- **Chuyên môn:** Tăng cường sự thống nhất giữa các điểm trường, kiểm tra hồ sơ giáo viên và nâng cao chất lượng sinh hoạt chuyên môn.

Bảng kê tháng 9 được tổng hợp từ **kết quả đã thực hiện** trong báo cáo tháng 9. Bảng kê tháng 10 kết hợp **phương hướng tháng 10** và **kết quả thực hiện tháng 10**. Thời gian ở cột ghi chú là thời gian gợi ý khi chưa có lịch chính thức.

Riêng hoạt động chào mừng Ngày Phụ nữ Việt Nam, báo cáo có nhắc cả ngày 10/10 và 20/10; mình để thời gian theo lịch tổ chức để bạn đối chiếu trước khi sử dụng. Phần người ký được lấy theo người ký báo cáo đã cung cấp và có thể điều chỉnh theo phân công thực tế.

**Kết quả:** Đã hoàn thành 43 nhiệm vụ, gồm 21 nhiệm vụ tháng 9 và 22 nhiệm vụ tháng 10/2026, theo cùng biểu mẫu với các tháng trước.

---

ASSISTANT

## 2. Bảng kê nhiệm vụ tháng 10/2026

<WritingBlock id="92652" variant="document">**UBND PHƯỜNG AN BÌNH**  
**TRƯỜNG MẦM NON AN BÌNH**

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
**Độc lập – Tự do – Hạnh phúc**

# BẢNG KÊ NHIỆM VỤ THÁNG 10/2026

**Năm học 2026–2027**

| STT | NỘI DUNG NHIỆM VỤ THỰC HIỆN | GHI CHÚ |
|:---:|---|---|
| 1 | Triển khai nhiệm vụ trọng tâm tháng 10/2026; rà soát, bố trí và phân công nhiệm vụ cho 83 cán bộ quản lý, giáo viên, nhân viên, bảo đảm phù hợp vị trí việc làm và điều kiện hoạt động tại 03 điểm trường. | Đầu tháng |
| 2 | Tăng cường kiểm tra việc chấp hành giờ giấc làm việc, kỷ luật, kỷ cương hành chính và thực hiện nhiệm vụ được giao; chỉ đạo nâng cao tinh thần trách nhiệm, hiệu quả phối hợp giữa các bộ phận, các điểm trường. | Trong tháng |
| 3 | Chỉ đạo duy trì tổ chức bán trú tại 03 điểm trường với bình quân 350 suất ăn/ngày; kiểm tra việc xây dựng thực đơn, cân đối khẩu phần và bảo đảm nhu cầu dinh dưỡng phù hợp từng độ tuổi. | Thường xuyên |
| 4 | Kiểm tra, giám sát quy trình giao nhận thực phẩm, kiểm thực 3 bước, lưu mẫu thức ăn hằng ngày; kiểm soát nguồn gốc, chất lượng và số lượng thực phẩm nhập vào các bếp ăn. | Thường xuyên |
| 5 | Kiểm tra quy trình sơ chế, chế biến, chia ăn, vệ sinh dụng cụ và môi trường ăn uống tại các bếp; kịp thời chỉ đạo khắc phục những hạn chế, bảo đảm an toàn thực phẩm. | Trong tháng |
| 6 | Chỉ đạo giáo viên, nhân viên thực hiện tốt chế độ sinh hoạt, chăm sóc giờ ăn, ngủ và vệ sinh cá nhân; phòng tránh nguy cơ hóc, sặc thức ăn và bảo đảm an toàn cho trẻ trong các hoạt động. | Thường xuyên |
| 7 | Chỉ đạo công tác y tế học đường, theo dõi sức khỏe trẻ; tăng cường vệ sinh, khử khuẩn đồ dùng, đồ chơi và phòng chống bệnh tay chân miệng, sốt xuất huyết, các bệnh thường gặp. | Trong tháng |
| 8 | Chỉ đạo các tổ chuyên môn thực hiện chương trình, kế hoạch giáo dục theo tiến độ; rà soát mục tiêu, nội dung, phương pháp và hình thức tổ chức hoạt động phù hợp với độ tuổi, khả năng của trẻ. | Trong tháng |
| 9 | Kiểm tra, hướng dẫn giáo viên đổi mới phương pháp giáo dục theo quan điểm lấy trẻ làm trung tâm; tăng cường hoạt động học thông qua chơi, trải nghiệm, khám phá và rèn kỹ năng sống. | Trong tháng |
| 10 | Chỉ đạo vận dụng phù hợp giáo dục STEM, giáo dục cảm xúc, bảo vệ môi trường; hỗ trợ giáo viên ứng dụng công nghệ thông tin và trí tuệ nhân tạo (AI) trong xây dựng kế hoạch, thiết kế hoạt động giáo dục. | Trong tháng |
| 11 | Kiểm tra hồ sơ, kế hoạch, giáo án của giáo viên; hướng dẫn khắc phục lỗi viết tắt, thiếu ngày dạy, lỗi chính tả, hình thức trình bày và sự chưa thống nhất giữa mục tiêu, nội dung hoạt động. | Trong tháng |
| 12 | Tổ chức thăm lớp, dự giờ, kiểm tra việc thực hiện chương trình; chú trọng hỗ trợ giáo viên ổn định nền nếp đối với trẻ mới nhập học, trẻ đi học muộn, giúp trẻ mạnh dạn và tích cực tham gia hoạt động. | Trong tháng |
| 13 | Dự sinh hoạt chuyên môn của các tổ; chỉ đạo tăng cường trao đổi, chia sẻ kinh nghiệm bằng hình thức trực tiếp kết hợp trực tuyến nhằm bảo đảm sự thống nhất chuyên môn giữa 03 điểm trường. | Theo lịch SHCM |
| 14 | Rà soát, hoàn thiện quy chế chuyên môn, quy chế đánh giá viên chức; phối hợp chuẩn bị nội dung, hồ sơ và các điều kiện tổ chức Hội nghị viên chức, người lao động theo kế hoạch của nhà trường. | Cuối tháng |
| 15 | Phối hợp chuẩn bị, tổ chức hoạt động họp mặt và các hoạt động chào mừng Ngày Phụ nữ Việt Nam 20/10; chỉ đạo lồng ghép nội dung giáo dục phù hợp trong hoạt động của trẻ. | Theo lịch tổ chức |
| 16 | Kiểm tra số liệu trẻ tại các điểm trường, rà soát biến động tăng giảm, cập nhật danh sách trẻ trong độ tuổi; chỉ đạo hoàn thiện hồ sơ phổ cập giáo dục mầm non và thực hiện báo cáo đúng quy định. | Trong tháng |
| 17 | Chỉ đạo cập nhật thông tin nhân sự, trẻ em trên cơ sở dữ liệu ngành; rà soát danh sách tham gia sổ liên lạc điện tử, thực hiện gửi thông tin kết quả học tập của trẻ qua phần mềm VNEDU. | Trong tháng |
| 18 | Chỉ đạo thực hiện công tác tài chính – kế toán; kiểm tra việc chi trả lương, tiền công, phụ cấp, các khoản đóng góp, kinh phí hoạt động và các khoản chi từ tiền gửi, bán trú, chăm sóc sức khỏe ban đầu theo quy định. | Trong tháng |
| 19 | Kiểm tra công tác quản lý, sử dụng và bảo quản tài sản sau sáp nhập tại các lớp, phòng chức năng, bếp ăn, sân chơi và các điểm trường theo Kế hoạch số 163/KH-MNAB ngày 21/9/2026. | Trong tháng |
| 20 | Chỉ đạo rà soát, phân loại tài sản hư hỏng, hết thời hạn hoặc không còn nhu cầu sử dụng; đề xuất điều chuyển, sửa chữa, mua sắm các hạng mục cần thiết, ưu tiên hệ thống điện, nước, nhà vệ sinh, phòng học và thiết bị bảo đảm an toàn cho trẻ. | Trong tháng |
| 21 | Phối hợp Chi đoàn thực hiện công tác tuyên truyền phòng chống dịch bệnh qua chương trình phát thanh măng non; tham gia các phong trào do Phường đoàn phát động, duy trì môi trường xanh – sạch – đẹp. | Trong tháng |
| 22 | Tổng hợp, đánh giá kết quả thực hiện nhiệm vụ tháng 10/2026; rà soát các hạn chế trong công tác chuyên môn, chăm sóc nuôi dưỡng và quản lý tài sản; hoàn thành báo cáo, xây dựng phương hướng tháng 11/2026. | Cuối tháng |

**PHÓ HIỆU TRƯỞNG**

*(Ký, ghi rõ họ tên)*

**Nguyễn Thị Huỳnh Duyên**</WritingBlock>

## Một số lưu ý trước khi sử dụng

Hai bảng kê đã được xây dựng phù hợp với tình hình nhà trường sau sáp nhập, đặc biệt là:

- **Nhân sự:** Tháng 9 ghi nhận 84 người, tháng 10 ghi nhận 83 người theo từng báo cáo.
- **Bán trú:** Phục vụ bình quân 350 suất ăn/ngày tại 3 điểm trường, có nhiệm vụ kiểm tra an toàn thực phẩm và chất lượng chăm sóc trẻ.
- **Cơ sở vật chất:** Chú trọng tiếp nhận, kiểm kê, bảo quản và xử lý tài sản sau sáp nhập.
- **Chuyên môn:** Tăng cường sự thống nhất giữa các điểm trường, kiểm tra hồ sơ giáo viên và nâng cao chất lượng sinh hoạt chuyên môn.

Bảng kê tháng 9 được tổng hợp từ **kết quả đã thực hiện** trong báo cáo tháng 9. Bảng kê tháng 10 kết hợp **phương hướng tháng 10** và **kết quả thực hiện tháng 10**. Thời gian ở cột ghi chú là thời gian gợi ý khi chưa có lịch chính thức.

Riêng hoạt động chào mừng Ngày Phụ nữ Việt Nam, báo cáo có nhắc cả ngày 10/10 và 20/10; mình để thời gian theo lịch tổ chức để bạn đối chiếu trước khi sử dụng. Phần người ký được lấy theo người ký báo cáo đã cung cấp và có thể điều chỉnh theo phân công thực tế.

**Kết quả:** Đã hoàn thành 43 nhiệm vụ, gồm 21 nhiệm vụ tháng 9 và 22 nhiệm vụ tháng 10/2026, theo cùng biểu mẫu với các tháng trước.

---

