USER

[@Plugin Creator](plugin://plugin_connector_1p_e1a10c53223481918a42f1510ec46c1e) giúp tôi tạo một plugin chuyên gia viết kế hoạch, thông báo, báo cáo, hướng dẫn với vai trò hiệu trưởng trường mầm non hơn 20 năm kinh nghiệm quản lý, am hiểu chuyên ngành giáo dục mầm non ( các văn bản, nghị quyết, thông tư.....). Lập luận chặt chẽ,logic gắn liền thực tiễn, dễ hiểu không hàn lâm sáo rỗng, có hàm lượng trí tuệ trong nghiên cứu. trình bày chuẩn nghị định 30.

---

ASSISTANT

Tôi sẽ dùng Plugin Creator để tạo plugin chuyên soạn văn bản cho hiệu trưởng trường mầm non, chú trọng bám sát căn cứ, phân công rõ trách nhiệm và trình bày theo Nghị định 30.

---

ASSISTANT

Tôi đang đưa vào plugin quy trình đọc kỹ văn bản gốc, chuyển yêu cầu cấp trên thành việc làm cụ thể tại trường và kiểm tra sự thống nhất giữa mục tiêu, nhiệm vụ, giải pháp, phân công. Plugin cũng sẽ phải kiểm chứng căn cứ pháp lý, không tự đặt số liệu, chỉ tiêu hoặc số hiệu văn bản khi chưa có nguồn.

---

ASSISTANT

Đã tạo plugin [**Chuyên gia văn bản Hiệu trưởng mầm non**](https://chatgpt.com/plugins/Plugin_4c1db5c984a88191b93f2a87e9da3de8).

Plugin được thiết lập để:

- Soạn **kế hoạch, thông báo, báo cáo, hướng dẫn** theo góc nhìn hiệu trưởng có hơn 20 năm kinh nghiệm quản lý.
- Lập luận chặt chẽ, logic, dễ hiểu; phân tích có chiều sâu, gắn thực tiễn mầm non.
- Bám sát văn bản đính kèm; kiểm chứng căn cứ pháp lý, không tự đặt số liệu hoặc chỉ tiêu.
- Phân công rõ trách nhiệm, tiến độ và kết quả cần đạt.
- Trình bày văn bản hành chính theo **Nghị định 30/2020/NĐ-CP**, đối chiếu quy định hiện hành khi sử dụng.

Cô mở liên kết trên để thêm plugin và sử dụng.

---

