USER

giaó viên trường mượn tiền phụ huynh đã nhiều lần xử lý nhưng tái phạm. gần đây nhất tiếp tục vi phạm thu tiền phụ huynh trái quy định.  đã bảo viết kiểm điểm tường trình để nộp và cam kết không tái phạm. Tuy nhiên đến nay vẫn chưa gửi. Hôm nay phụ huynh đến cung cấp thông tin, tin nhắn cô mượn 2tr hơn 1 năm nhưng vẫn chưa hoàn trả. (chỉ trả 1tr) phụ huynh là mẹ đơn thân nhờ trường hỗ trợ giúp. Với vai trò hiệu trưởng bạn giúp tôi xử lý vấn đề này

---

ASSISTANT

Tôi sẽ tách vụ việc thành hai phần: khoản vay cá nhân giữa giáo viên và phụ huynh, và các vi phạm trong thực hiện nhiệm vụ của giáo viên. Tôi sẽ kiểm tra căn cứ pháp lý hiện hành, sau đó đề xuất quy trình xử lý cụ thể để nhà trường vừa hỗ trợ phụ huynh, vừa xử lý nghiêm việc tái phạm và không chấp hành yêu cầu của hiệu trưởng.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Với vai trò Hiệu trưởng, tôi đánh giá đây là **vụ việc cần xử lý nghiêm túc, có hồ sơ và kết luận rõ ràng**, không nên tiếp tục dừng lại ở việc nhắc nhở giáo viên viết kiểm điểm, cam kết rồi cho qua như những lần trước.

Điều đáng quan tâm không chỉ là số tiền giáo viên còn nợ phụ huynh, mà là **giáo viên đã nhiều lần bị xử lý, tiếp tục có hành vi thu tiền phụ huynh trái quy định, đồng thời chưa thực hiện yêu cầu giải trình của nhà trường**. Những vấn đề này ảnh hưởng trực tiếp đến uy tín, kỷ cương của nhà trường và niềm tin của cha mẹ trẻ.

Tôi đề xuất Hiệu trưởng xử lý theo nguyên tắc:

**Bảo vệ quyền lợi chính đáng của phụ huynh – Xác minh khách quan – Xử lý trách nhiệm giáo viên đúng quy định – Không để tiếp tục tái diễn.**

## I. Nhận diện 3 vấn đề cần giải quyết

| Nội dung | Hướng xử lý của Hiệu trưởng |
|--------|--------|
| **1. Giáo viên mượn tiền phụ huynh hơn một năm chưa trả đủ** | Xác minh khoản vay, số tiền đã trả, số tiền còn nợ; hỗ trợ phụ huynh làm việc trực tiếp với giáo viên để yêu cầu thực hiện nghĩa vụ trả nợ. |
| **2. Giáo viên tiếp tục thu tiền phụ huynh trái quy định** | Xác minh hành vi, số tiền, mục đích thu, người nhận và xử lý trách nhiệm theo quy định của đơn vị và pháp luật. |
| **3. Giáo viên không nộp kiểm điểm, tường trình, cam kết theo yêu cầu** | Xác lập việc không chấp hành yêu cầu quản lý, xem xét cùng các hành vi vi phạm đã được xác minh. Không tiếp tục chỉ nhắc nhở bằng lời nói. |

Cần phân biệt rõ: **nợ tiền là quan hệ dân sự giữa giáo viên và phụ huynh; nhưng việc lợi dụng quan hệ giáo viên – phụ huynh, thu tiền trái quy định hoặc vi phạm quy tắc ứng xử là vấn đề thuộc trách nhiệm quản lý của nhà trường.** Không được tự động coi việc chậm trả nợ là hành vi chiếm đoạt tài sản khi chưa có đủ căn cứ.

## II. Căn cứ pháp lý cần áp dụng năm 2026

Đối với trường mầm non công lập, các văn bản hiện hành cần chú ý gồm:

1. **Luật Nhà giáo số 73/2025/QH15**, hiệu lực từ ngày 01/01/2026: Điều 10 quy định về đạo đức nhà giáo; Điều 11 quy định những việc nhà giáo không được làm, trong đó có việc lợi dụng chức danh và hoạt động nghề nghiệp để thực hiện hành vi vi phạm pháp luật. [Luật Nhà giáo số 73/2025/QH15 năm 2025: Toàn văn, mới nhất mới nhất](<https://thuvienphapluat.vn/van-ban/Giao-duc/Luat-Nha-giao-2025-so-73-2025-QH15-621345.aspx?tab=4>)
2. **Thông tư số 03/2026/TT-BGDĐT**, hiệu lực từ ngày 30/01/2026: quy định quy tắc ứng xử của nhà giáo, trong đó yêu cầu không vụ lợi, không ép buộc cha mẹ trẻ tham gia các hoạt động trái quy định. [TOÀN VĂN: Thông tư 03/2026/TT\-BGDĐT quy định quy tắc ứng xử của nhà giáo](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-03-2026-tt-bgddt-quy-dinh-quy-tac-ung-xu-cua-nha-giao-119260205093856491.htm>)
3. **Luật Viên chức số 129/2025/QH15**, hiệu lực từ ngày 01/7/2026: quy định nghĩa vụ chấp hành nội quy, quy chế và các hình thức kỷ luật viên chức. [Toàn văn: LUẬT VIÊN CHỨC](<https://xaydungchinhsach.chinhphu.vn/toan-van-luat-vien-chuc-so-129-2025-qh15-119260107101503932.htm>)
4. **Nghị định số 234/2026/NĐ-CP**, hiệu lực từ ngày 01/7/2026: quy định trình tự, thẩm quyền và hình thức xử lý kỷ luật viên chức, thay thế Nghị định 112/2020/NĐ-CP. [Nghị định số 234/2026/NĐ\-CP về xử lý kỷ luật viên chức](<https://xaydungchinhsach.chinhphu.vn/nghi-dinh-so-234-2026-nd-cp-ve-xu-ly-ky-luat-vien-chuc-119260630132541048.htm>)
5. **Điều 463 và Điều 466 Bộ luật Dân sự năm 2015**: quy định về hợp đồng vay tài sản và nghĩa vụ trả nợ của bên vay. [Tòa án nhân dân tối cao](<https://vbpl.moj.gov.vn/toaannhandantoicao/Pages/vbpq-toanvan.aspx?ItemID=95942&Keyword=91%2F2015%2FQH13>)

Đặc biệt, theo Nghị định 234/2026/NĐ-CP, khi xem xét kỷ luật phải đánh giá cả tính chất, mức độ, hậu quả, tình tiết tăng nặng, giảm nhẹ, thái độ tiếp thu và kết quả khắc phục vi phạm. Do đó, **việc giáo viên tiếp tục vi phạm và không hợp tác giải trình là những tình tiết nhà trường cần ghi nhận, xác minh đầy đủ**, thay vì chỉ xử lý riêng khoản tiền 1 triệu đồng còn nợ. [Quy định mới về kỷ luật viên chức](<https://sav.gov.vn/vi/bai-viet/quy-dinh-moi-ve-ky-luat-vien-chuc>)

## III. Quy trình xử lý cụ thể tôi đề xuất

**Bước 1. Ngay hôm nay, ngày 06/11/2026: Tiếp nhận và hỗ trợ phụ huynh**

Hiệu trưởng hoặc Phó Hiệu trưởng được phân công trực tiếp tiếp phụ huynh trong không gian riêng, có người ghi biên bản. Lắng nghe với thái độ tôn trọng, đặc biệt quan tâm hoàn cảnh mẹ đơn thân đang gặp khó khăn.

Biên bản cần ghi rõ thời điểm vay, số tiền 2 triệu đồng, số tiền đã trả 1 triệu đồng, số còn nợ theo phản ánh, các lần yêu cầu trả nợ và những tin nhắn liên quan. Đề nghị phụ huynh cung cấp bản sao tin nhắn, chứng từ chuyển khoản nếu có; lưu giữ chứng cứ có sự đồng ý của phụ huynh.

**Không yêu cầu phụ huynh đối chất ngay với giáo viên** khi chưa xác minh; đồng thời bảo đảm trẻ không bị phân biệt đối xử vì việc phản ánh của mẹ.

---

**Bước 2. Trong ngày 06/11: Làm việc riêng với giáo viên**

Mời giáo viên làm việc có lập biên bản, yêu cầu giải trình ba vấn đề: khoản vay phụ huynh; hành vi thu tiền trái quy định gần đây; việc chưa nộp bản kiểm điểm, tường trình và cam kết theo yêu cầu trước đó.

Ban hành yêu cầu giải trình bằng văn bản, giao nhận có ký xác nhận hoặc hình thức có thể chứng minh đã nhận. Có thể ấn định thời hạn nội bộ đến ngày làm việc kế tiếp để giáo viên cung cấp thông tin, nhưng không được dùng thời hạn này thay cho các mốc thủ tục kỷ luật pháp luật quy định.

**Nếu giáo viên vẫn không nộp giải trình, phải lập hồ sơ ghi nhận và tiếp tục xử lý**, không chờ vô thời hạn.

---

**Bước 3. Hỗ trợ phụ huynh giải quyết khoản vay**

Sau khi xác minh, nếu giáo viên thừa nhận số tiền còn nợ, yêu cầu giáo viên chủ động làm việc với phụ huynh để thống nhất ngày trả và phương thức trả cụ thể. Nên khuyến khích thanh toán dứt điểm sớm, nhất là khi khoản vay đã kéo dài hơn một năm.

Nếu phụ huynh đồng ý, nhà trường có thể chứng kiến việc hai bên lập văn bản xác nhận công nợ và thỏa thuận trả nợ. Giáo viên chuyển tiền trực tiếp cho phụ huynh, có chứng từ xác nhận.

Nhà trường hỗ trợ giải quyết, **không đứng ra nhận nợ thay giáo viên, không tự ý trừ lương hoặc sử dụng kinh phí nhà trường để trả nợ**. Trường hợp hai bên không thống nhất, hướng dẫn phụ huynh yêu cầu giải quyết tranh chấp dân sự theo pháp luật.

---

**Bước 4. Rà soát toàn bộ vi phạm và tiến hành quy trình xem xét kỷ luật**

Tổng hợp hồ sơ những lần vi phạm trước, xác định lần nào chỉ nhắc nhở, lần nào có văn bản xử lý và lần nào đã có quyết định kỷ luật chính thức.

Kiểm tra chứng cứ của việc thu tiền trái quy định, số tiền có liên quan, việc quản lý sử dụng tiền, hậu quả phát sinh; đồng thời làm rõ giáo viên có lợi dụng quan hệ với phụ huynh để vay tiền hay không.

Khi có căn cứ xác định hành vi vi phạm đến mức phải xử lý kỷ luật, thực hiện quy trình theo Nghị định 234/2026/NĐ-CP, không chỉ họp nội bộ Ban giám hiệu rồi tự quyết định mức xử lý. [quydinh\.vn](<https://quydinh.vn/van-ban/nghi-dinh-234-2026-nd-cp-ve-xu-ly-ky-luat-vien-chuc-397840>)

---

**Bước 5. Kết luận và theo dõi sau xử lý**

Có văn bản kết luận những nội dung đã xác minh, trách nhiệm của giáo viên, biện pháp khắc phục và hướng xử lý.

Thông tin riêng cho phụ huynh về việc nhà trường đã tiếp nhận, hỗ trợ và xử lý trong phạm vi thẩm quyền. Chỉ cung cấp thông tin cá nhân, hồ sơ kỷ luật ở mức được phép.

Giao Phó Hiệu trưởng theo dõi việc chấp hành quy định thu tiền và việc phối hợp giải quyết phản ánh; ngăn ngừa giáo viên gây sức ép với phụ huynh hoặc làm ảnh hưởng đến trẻ.

## IV. Riêng việc giáo viên không chịu viết kiểm điểm: Không cần tiếp tục chờ

Đây là điểm rất quan trọng trong trường hợp này.

**Khoản 3 Điều 4 Nghị định 234/2026/NĐ-CP** xác định việc đã được cơ quan, đơn vị yêu cầu kiểm điểm nhưng không thực hiện, không sửa chữa khuyết điểm có thể là tình tiết tăng nặng mức kỷ luật. Đồng thời, theo khoản 3 Điều 14, nếu viên chức có mặt tại cuộc họp nhưng không có bản kiểm điểm, cuộc họp vẫn được tiến hành; trường hợp vắng mặt theo thông báo triệu tập lần thứ hai, cuộc họp cũng có thể tiếp tục theo quy định. [quydinh\.vn](<https://quydinh.vn/van-ban/nghi-dinh-234-2026-nd-cp-ve-xu-ly-ky-luat-vien-chuc-397840>); [quydinh\.vn](<https://quydinh.vn/van-ban/nghi-dinh-234-2026-nd-cp-ve-xu-ly-ky-luat-vien-chuc-397840>)

Như vậy, nếu trước đây Hiệu trưởng đã yêu cầu nhưng giáo viên không thực hiện, cần xác minh và lưu bằng chứng về việc đã giao nhiệm vụ, thời hạn, phương thức thông báo. Nếu mới chỉ nhắc bằng lời nói, nên chính thức hóa ngay bằng văn bản.

Không nên đặt thêm điều kiện rằng giáo viên phải nộp cam kết thì nhà trường mới được xử lý vụ việc.

## V. Hiệu trưởng nên xem xét hình thức xử lý nào?

Với các tình tiết đã nêu, tôi đề nghị **không tiếp tục giải quyết vụ việc chỉ bằng hình thức nhắc nhở, rút kinh nghiệm**. Cần tiến hành xác minh và xem xét trách nhiệm kỷ luật nếu hành vi vi phạm đã đủ căn cứ.

Tuy nhiên, phải phân biệt hai trường hợp:

- Nếu những lần trước chỉ nhắc nhở, yêu cầu kiểm điểm, chưa có quyết định kỷ luật chính thức thì không mặc nhiên xác định giáo viên đã *tái phạm* theo nghĩa pháp lý.
- Nếu giáo viên đã bị kỷ luật chính thức và tiếp tục thực hiện hành vi đã bị kỷ luật trong thời hạn 12 tháng theo quy định, phải xem xét quy định về tái phạm và mức kỷ luật tương ứng. [Quy định mới về kỷ luật viên chức](<https://sav.gov.vn/vi/bai-viet/quy-dinh-moi-ve-ky-luat-vien-chuc>); [quydinh\.vn](<https://quydinh.vn/van-ban/nghi-dinh-234-2026-nd-cp-ve-xu-ly-ky-luat-vien-chuc-397840>)

Đối với giáo viên là viên chức, tùy hành vi và hậu quả đã được chứng minh, có thể xem xét các mức khiển trách, cảnh cáo hoặc mức cao hơn khi đáp ứng đúng điều kiện pháp luật. Không nên ấn định hình thức kỷ luật trước khi hoàn thành quy trình.

Trong thời gian xác minh, nên giao bộ phận khác trực tiếp hướng dẫn phụ huynh về các khoản thu của trường, không để giáo viên liên quan tiếp tục tự thu hoặc nhận tiền qua tài khoản cá nhân. Việc thay đổi phân công chuyên môn, nếu cần, phải đúng thẩm quyền và bảo đảm hoạt động chăm sóc trẻ.

Nếu phát hiện dấu hiệu gian dối để vay tiền, chiếm đoạt, đe dọa phụ huynh hoặc có nhiều người bị ảnh hưởng, cần chuyển thông tin cho cơ quan có thẩm quyền xem xét theo pháp luật.

## VI. Nội dung chỉ đạo giáo viên có thể sử dụng ngay

> **writing · document**
>
> **THÔNG BÁO**  
> **Về việc yêu cầu giải trình và phối hợp xác minh thông tin phản ánh**
>
> Kính gửi: Ông/Bà ................................ – Giáo viên Trường ....................................
>
> Qua công tác quản lý và thông tin phản ánh từ phụ huynh, nhà trường đang xem xét các nội dung liên quan đến việc thực hiện quy định thu tiền, quan hệ tài chính với phụ huynh và trách nhiệm chấp hành yêu cầu của Ban giám hiệu.
>
> Để có cơ sở xác minh, đánh giá khách quan và giải quyết vụ việc, Hiệu trưởng yêu cầu:
>
> 1. Báo cáo, giải trình đầy đủ việc thu tiền phụ huynh không đúng quy định đã được nhà trường yêu cầu kiểm điểm trước đây.
> 2. Giải trình nội dung phụ huynh phản ánh về khoản vay 2.000.000 đồng, đã hoàn trả 1.000.000 đồng, số tiền còn lại và việc thực hiện nghĩa vụ trả nợ; cung cấp các thông tin, chứng từ liên quan nếu có.
> 3. Giải trình lý do chưa thực hiện yêu cầu nộp bản kiểm điểm, tường trình và cam kết của nhà trường.
> 4. Chủ động phối hợp xác minh, không gây sức ép đối với phụ huynh, bảo đảm quyền lợi của trẻ và nghiêm túc chấp hành các quy định của nhà trường.
>
> **Thời hạn nộp văn bản giải trình:** Trước 16 giờ 00 phút ngày 09/11/2026.
>
> Trường hợp không thực hiện hoặc không có lý do chính đáng, nhà trường sẽ ghi nhận việc không chấp hành và tiếp tục xem xét, xử lý theo quy định của pháp luật, trên cơ sở hồ sơ, tài liệu đã xác minh.
>
> Yêu cầu giáo viên nghiêm túc thực hiện.
>
> **HIỆU TRƯỞNG**

Thời hạn 09/11/2026 là mốc quản lý nội bộ được đề xuất, không phải thời hạn giải trình bắt buộc do pháp luật ấn định.

## VII. Cách Hiệu trưởng trao đổi với phụ huynh hôm nay

Tôi đề xuất nói với phụ huynh bằng thái độ chia sẻ nhưng rõ trách nhiệm:

> Nhà trường rất chia sẻ với hoàn cảnh và những khó khăn của chị. Cảm ơn chị đã tin tưởng đến phản ánh trực tiếp với Ban giám hiệu.
>
> Đối với khoản tiền cô giáo đã mượn, đây là trách nhiệm cá nhân của giáo viên. Tuy nhiên, vì sự việc liên quan đến mối quan hệ giữa giáo viên và phụ huynh của trường, nhà trường sẽ tiếp nhận thông tin, làm việc với giáo viên và hỗ trợ chị trong việc yêu cầu giải quyết khoản nợ.
>
> Đồng thời, nhà trường sẽ xem xét trách nhiệm của giáo viên đối với những nội dung vi phạm quy định đã được phản ánh. Nhà trường cam kết xử lý khách quan, đúng quy định và bảo đảm việc này không ảnh hưởng đến quá trình chăm sóc, giáo dục con của chị.

**Kết luận đề xuất:** Trong hôm nay, Hiệu trưởng nên hoàn thành biên bản tiếp nhận phụ huynh, mời giáo viên làm việc, ban hành văn bản yêu cầu giải trình và phân công người theo dõi. Sau đó, trên cơ sở hồ sơ các lần vi phạm trước cùng kết quả xác minh mới, chính thức xem xét quy trình kỷ luật nếu đủ căn cứ.

Điều quan trọng nhất là lần này phải **có kết luận, có trách nhiệm và có biện pháp kiểm soát sau xử lý**, chứ không tiếp tục để giáo viên viết cam kết rồi vụ việc lại tái diễn.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

## V. Hiệu trưởng nên xem xét hình thức xử lý nào?

Với các tình tiết đã nêu, tôi đề nghị **không tiếp tục giải quyết vụ việc chỉ bằng hình thức nhắc nhở, rút kinh nghiệm**. Cần tiến hành xác minh và xem xét trách nhiệm kỷ luật nếu hành vi vi phạm đã đủ căn cứ.

Tuy nhiên, phải phân biệt hai trường hợp:

- Nếu những lần trước chỉ nhắc nhở, yêu cầu kiểm điểm, chưa có quyết định kỷ luật chính thức thì không mặc nhiên xác định giáo viên đã *tái phạm* theo nghĩa pháp lý.
- Nếu giáo viên đã bị kỷ luật chính thức và tiếp tục thực hiện hành vi đã bị kỷ luật trong thời hạn 12 tháng theo quy định, phải xem xét quy định về tái phạm và mức kỷ luật tương ứng. [Source unavailable: turn254693view1]; [Source unavailable: turn751896view2]

Đối với giáo viên là viên chức, tùy hành vi và hậu quả đã được chứng minh, có thể xem xét các mức khiển trách, cảnh cáo hoặc mức cao hơn khi đáp ứng đúng điều kiện pháp luật. Không nên ấn định hình thức kỷ luật trước khi hoàn thành quy trình.

Trong thời gian xác minh, nên giao bộ phận khác trực tiếp hướng dẫn phụ huynh về các khoản thu của trường, không để giáo viên liên quan tiếp tục tự thu hoặc nhận tiền qua tài khoản cá nhân. Việc thay đổi phân công chuyên môn, nếu cần, phải đúng thẩm quyền và bảo đảm hoạt động chăm sóc trẻ.

Nếu phát hiện dấu hiệu gian dối để vay tiền, chiếm đoạt, đe dọa phụ huynh hoặc có nhiều người bị ảnh hưởng, cần chuyển thông tin cho cơ quan có thẩm quyền xem xét theo pháp luật.

## VI. Nội dung chỉ đạo giáo viên có thể sử dụng ngay

<WritingBlock id="58312" variant="document">**THÔNG BÁO**  
**Về việc yêu cầu giải trình và phối hợp xác minh thông tin phản ánh**

Kính gửi: Ông/Bà ................................ – Giáo viên Trường ....................................

Qua công tác quản lý và thông tin phản ánh từ phụ huynh, nhà trường đang xem xét các nội dung liên quan đến việc thực hiện quy định thu tiền, quan hệ tài chính với phụ huynh và trách nhiệm chấp hành yêu cầu của Ban giám hiệu.

Để có cơ sở xác minh, đánh giá khách quan và giải quyết vụ việc, Hiệu trưởng yêu cầu:

1. Báo cáo, giải trình đầy đủ việc thu tiền phụ huynh không đúng quy định đã được nhà trường yêu cầu kiểm điểm trước đây.
2. Giải trình nội dung phụ huynh phản ánh về khoản vay 2.000.000 đồng, đã hoàn trả 1.000.000 đồng, số tiền còn lại và việc thực hiện nghĩa vụ trả nợ; cung cấp các thông tin, chứng từ liên quan nếu có.
3. Giải trình lý do chưa thực hiện yêu cầu nộp bản kiểm điểm, tường trình và cam kết của nhà trường.
4. Chủ động phối hợp xác minh, không gây sức ép đối với phụ huynh, bảo đảm quyền lợi của trẻ và nghiêm túc chấp hành các quy định của nhà trường.

**Thời hạn nộp văn bản giải trình:** Trước 16 giờ 00 phút ngày 09/11/2026.

Trường hợp không thực hiện hoặc không có lý do chính đáng, nhà trường sẽ ghi nhận việc không chấp hành và tiếp tục xem xét, xử lý theo quy định của pháp luật, trên cơ sở hồ sơ, tài liệu đã xác minh.

Yêu cầu giáo viên nghiêm túc thực hiện.

**HIỆU TRƯỞNG**</WritingBlock>

<caption>Thời hạn 09/11/2026 là mốc quản lý nội bộ được đề xuất, không phải thời hạn giải trình bắt buộc do pháp luật ấn định.</caption>

## VII. Cách Hiệu trưởng trao đổi với phụ huynh hôm nay

Tôi đề xuất nói với phụ huynh bằng thái độ chia sẻ nhưng rõ trách nhiệm:

> Nhà trường rất chia sẻ với hoàn cảnh và những khó khăn của chị. Cảm ơn chị đã tin tưởng đến phản ánh trực tiếp với Ban giám hiệu.
>
> Đối với khoản tiền cô giáo đã mượn, đây là trách nhiệm cá nhân của giáo viên. Tuy nhiên, vì sự việc liên quan đến mối quan hệ giữa giáo viên và phụ huynh của trường, nhà trường sẽ tiếp nhận thông tin, làm việc với giáo viên và hỗ trợ chị trong việc yêu cầu giải quyết khoản nợ.
>
> Đồng thời, nhà trường sẽ xem xét trách nhiệm của giáo viên đối với những nội dung vi phạm quy định đã được phản ánh. Nhà trường cam kết xử lý khách quan, đúng quy định và bảo đảm việc này không ảnh hưởng đến quá trình chăm sóc, giáo dục con của chị.

**Kết luận đề xuất:** Trong hôm nay, Hiệu trưởng nên hoàn thành biên bản tiếp nhận phụ huynh, mời giáo viên làm việc, ban hành văn bản yêu cầu giải trình và phân công người theo dõi. Sau đó, trên cơ sở hồ sơ các lần vi phạm trước cùng kết quả xác minh mới, chính thức xem xét quy trình kỷ luật nếu đủ căn cứ.

Điều quan trọng nhất là lần này phải **có kết luận, có trách nhiệm và có biện pháp kiểm soát sau xử lý**, chứ không tiếp tục để giáo viên viết cam kết rồi vụ việc lại tái diễn.

---

