USER

rà giúp các nợi dung này có phù hợp với kế hoạch không và có đúng không

---

ASSISTANT

Mình sẽ xem nội dung trong ảnh và đối chiếu với kế hoạch để rà tính phù hợp, cách diễn đạt và những chỗ cần điều chỉnh.

---

ASSISTANT

Ảnh bạn gửi là phần căn cứ pháp lý, có nội dung về làm quen tiếng Anh và các khoản thu. Mình sẽ kiểm tra số hiệu, điều khoản và mức độ liên quan của từng văn bản; đồng thời dùng kỹ năng Personal Context để xác định kế hoạch bạn đang nhắc đến.

---

ASSISTANT

Mình đã thấy một lỗi rõ: căn cứ về các khoản thu của Đồng Tháp phải ghi **Quyết định số 105/2026/QĐ-UBND ngày 11/9/2026**, thay cho “105/QĐ-UBND ngày 11/1/2026” trong ảnh. Nhóm căn cứ về tài sản công cũng cần rà lại hiệu lực và chỉ giữ khi phù hợp với cách nhà trường tổ chức hoạt động.

---

ASSISTANT

Mình đã rà phần căn cứ trong ảnh. **Nếu đây là kế hoạch tổ chức cho trẻ mẫu giáo làm quen với tiếng Anh của Trường Mầm non An Bình thì các căn cứ nhìn chung có liên quan, nhưng chưa thể giữ nguyên: có lỗi số hiệu, ngày ban hành và một số nội dung diễn giải chưa chính xác.** Mình mới có phần căn cứ, nên chưa thể kết luận mức độ phù hợp với toàn bộ kế hoạch.

| Nội dung trong ảnh | Kết quả rà soát | Hướng điều chỉnh |
|---|---|---|
| **Luật Giáo dục năm 2019, Điều 16** | Điều 16 đúng là quy định về **“Xã hội hóa sự nghiệp giáo dục”**. Tuy nhiên, câu diễn giải “đầu tư, đóng góp trí tuệ, công sức, tài sản…” trong ảnh không phải nguyên văn điều này. | Giữ căn cứ Luật Giáo dục nhưng bỏ phần diễn giải, hoặc ghi đúng tên Điều 16. https://hethongphapluat.com/luat-giao-duc-2019/chuong-1
https://hethongphapluat.com/luat-giao-duc-2019/chuong-1?utm_source=chatgpt.com |
| **Luật Quản lý, sử dụng tài sản công năm 2017; Luật số 56/2024/QH15** | Có liên quan nếu kế hoạch có sử dụng phòng học, thiết bị và tài sản của trường để phối hợp tổ chức hoạt động. | Chỉ giữ khi kế hoạch có nội dung quản lý, sử dụng tài sản công; cần đối chiếu các sửa đổi đang áp dụng trước khi chốt văn bản. |
| **Nghị định 60/2021/NĐ-CP; Nghị định 111/2025/NĐ-CP** | Ghi đúng số hiệu, ngày ban hành và quan hệ sửa đổi. Đây là căn cứ về **cơ chế tự chủ tài chính**, phù hợp khi kế hoạch có nội dung thu, chi và quản lý kinh phí. | Có thể giữ, nhưng không dùng riêng các nghị định này để kết luận trường được phép thu một mức tiền cụ thể. https://vanban.chinhphu.vn/?docid=213722&pageid=27160
https://vanban.chinhphu.vn/?docid=213722&pageid=27160&utm_source=chatgpt.com |
| **Thông tư 11/2025/TT-BTC ngày 19/3/2025** | Đúng số hiệu và ngày ban hành. Tuy nhiên, đây là thông tư sửa đổi hướng dẫn về **quản lý, sử dụng tài sản công**; phần trong ngoặc về “lựa chọn đối tác liên doanh, liên kết… tham chiếu để bảo đảm công khai, cạnh tranh” chưa được chứng minh là nội dung phù hợp để dẫn ở đây. | **Bỏ phần diễn giải trong ngoặc.** Chưa nên giữ thông tư này làm căn cứ chính khi chưa đối chiếu hiệu lực và trường hợp áp dụng. https://vanban.chinhphu.vn/?classid=0&docid=213189&pageid=27160
https://vanban.chinhphu.vn/?classid=0&docid=213189&pageid=27160&utm_source=chatgpt.com |
| **Các điều khoản của Nghị định 186/2025/NĐ-CP** | Nghị định có thật, ban hành ngày 01/7/2025. **Điểm a khoản 2 Điều 49** có liên quan đến việc liên kết giảng dạy cho người học của đơn vị theo chức năng, nhiệm vụ được giao. Tuy nhiên, việc dẫn thêm Điều 50 cần xác định hoạt động có thuộc trường hợp khai thác tài sản công hay không. | Có thể giữ căn cứ này, nhưng **không mặc nhiên coi phối hợp tổ chức tiếng Anh là cho thuê hoặc liên doanh, liên kết tài sản công**. Cần đối chiếu cách tổ chức, hợp đồng và việc sử dụng tài sản thực tế. https://hethongphapluat.com/nghi-dinh-186-2025-nd-cp-huong-dan-luat-quan-ly-su-dung-tai-san-cong/dieu-49
https://hethongphapluat.com/nghi-dinh-186-2025-nd-cp-huong-dan-luat-quan-ly-su-dung-tai-san-cong/dieu-49?utm_source=chatgpt.com
https://vanban.chinhphu.vn/?classid=1&docid=214493&pageid=27160
https://vanban.chinhphu.vn/?classid=1&docid=214493&pageid=27160&utm_source=chatgpt.com |
| **Thông tư 50/2020/TT-BGDĐT ngày 31/12/2020** | **Đúng và phù hợp trực tiếp** với kế hoạch cho trẻ mẫu giáo làm quen tiếng Anh. | Giữ nguyên số hiệu, ngày ban hành và tên chương trình. Căn cứ này áp dụng cho **trẻ em mẫu giáo**; không dùng để suy rộng sang trẻ nhà trẻ. https://moet.gov.vn/content/vanban/Lists/VBDH/Attachments/3625/466qdbgddtsigned.pdf
https://moet.gov.vn/content/vanban/Lists/VBDH/Attachments/3625/466qdbgddtsigned.pdf?utm_source=chatgpt.com |
| **Công văn 4749/BGDĐT-GDMN ngày 23/9/2022** | **Đúng và phù hợp trực tiếp**: hướng dẫn triển khai chương trình làm quen tiếng Anh ở nơi có đủ điều kiện. | Giữ. Đây là căn cứ quan trọng về điều kiện tổ chức hoạt động. https://thuvienphapluat.vn/cong-van/Giao-duc/Cong-van-4749-BGDDT-GDMN-2022-lam-quen-tieng-Anh-danh-cho-tre-mau-giao-563994.aspx
https://thuvienphapluat.vn/cong-van/Giao-duc/Cong-van-4749-BGDDT-GDMN-2022-lam-quen-tieng-Anh-danh-cho-tre-mau-giao-563994.aspx?utm_source=chatgpt.com |
| **Quyết định 105/QĐ-UBND ngày 11/1/2026 của UBND tỉnh Đồng Tháp** | **Sai số hiệu và ngày ban hành** so với văn bản quy định các khoản thu được công bố. | Sửa thành **Quyết định số 105/2026/QĐ-UBND ngày 11 tháng 9 năm 2026**. Văn bản có hiệu lực từ ngày 21/9/2026. https://congbao.dongthap.gov.vn/?id=328592&year=2026
https://congbao.dongthap.gov.vn/?id=328592&year=2026&utm_source=chatgpt.com |
| **Công văn 595/SGDĐT-GDMN và 675/SGDĐT-GDPT năm 2025** | Mình chưa tìm được bản gốc để xác nhận số hiệu, ngày ban hành và phạm vi áp dụng. Việc gộp hai văn bản dưới một nội dung chung khiến người đọc khó biết từng văn bản hướng dẫn gì. | **Tách thành hai dòng**, ghi đúng trích yếu từng văn bản. Với kế hoạch năm học 2026–2027, cần kiểm tra chúng còn áp dụng hay đã có hướng dẫn mới. |

**Ba chỗ nên sửa ngay trong bản của bạn:**

1. Dòng đầu nên viết gọn:  
   *“Căn cứ Luật Giáo dục số 43/2019/QH14 ngày 14 tháng 6 năm 2019 và các văn bản sửa đổi, bổ sung có liên quan;”*

2. Bỏ phần diễn giải trong ngoặc sau Thông tư 11/2025/TT-BTC.

3. Sửa căn cứ về các khoản thu thành:  
   *“Căn cứ Quyết định số 105/2026/QĐ-UBND ngày 11 tháng 9 năm 2026 của Ủy ban nhân dân tỉnh Đồng Tháp ban hành Quy định các khoản thu, mức thu và cơ chế quản lý thu, chi đối với các dịch vụ phục vụ hoạt động giáo dục, đào tạo trong cơ sở giáo dục công lập trên địa bàn tỉnh Đồng Tháp;”*

**Về bố cục, nên ưu tiên căn cứ chuyên môn tiếng Anh và căn cứ thu, chi; nhóm tài sản công chỉ dẫn những quy định thực sự áp dụng.** Bạn gửi thêm bản kế hoạch và hai công văn của Sở, mình sẽ đối chiếu để chốt cụ thể căn cứ nào giữ, căn cứ nào bỏ.

---

USER

phân nội dung này thành 2 phần mục đích và yêu cầu

---

ASSISTANT

Mình sẽ đọc hai ảnh và sắp xếp lại thành hai phần **Mục đích** và **Yêu cầu**, giữ sát nội dung bạn gửi.

---

ASSISTANT

Mình tách thành hai phần dưới đây, giữ sát nội dung gốc và chỉnh câu chữ cho mạch lạc:

> **writing · standard**
>
> **I. MỤC ĐÍCH, YÊU CẦU**
>
> **1. Mục đích**
>
> - Thực hiện chủ trương xã hội hóa giáo dục, huy động nguồn lực bên ngoài kết hợp khai thác hiệu quả tài sản công của nhà trường để tổ chức các hoạt động giáo dục ngoài giờ chính khóa theo nhu cầu tự nguyện của cha mẹ trẻ, góp phần nâng cao chất lượng chăm sóc, giáo dục trẻ.
>
> - Lựa chọn đối tác đáp ứng yêu cầu chuyên môn thông qua quá trình công khai, minh bạch, công bằng; bảo đảm hiệu quả sử dụng tài sản công và phòng ngừa xung đột lợi ích trong quá trình lựa chọn.
>
> **2. Yêu cầu**
>
> - Việc lựa chọn đối tác phải bảo đảm cạnh tranh, công bằng, minh bạch, không phân biệt đối xử. Tiêu chí đánh giá phải xuất phát từ yêu cầu chuyên môn, có thể đo lường, không nêu tên sản phẩm, nhãn hiệu, nguồn gốc xuất xứ hoặc đặt ra điều kiện nhằm ưu tiên một tổ chức, cá nhân cụ thể.
>
> - Thông tin mời tham gia phải được đăng tải công khai trên Cổng thông tin điện tử về tài sản công quốc gia (taisancong.vn), website và bảng tin của nhà trường; bảo đảm mọi đơn vị đủ điều kiện đều được tiếp cận thông tin và nộp hồ sơ.
>
> - Bảo toàn tài sản công, không làm thay đổi công năng sử dụng, không ảnh hưởng đến việc thực hiện Chương trình giáo dục mầm non. Phần nguồn thu của nhà trường phải bảo đảm bù đắp chi phí khấu hao, hao mòn, điện, nước, vệ sinh và chi phí quản lý, giám sát.
>
> - Bảo đảm nguyên tắc tự nguyện: cha mẹ trẻ được cung cấp đầy đủ thông tin và có quyền đăng ký hoặc không đăng ký cho trẻ tham gia. Trẻ không đăng ký vẫn được chăm sóc, giáo dục bình thường, không bị phân biệt đối xử.
>
> - Bảo đảm phòng ngừa xung đột lợi ích: người tham gia xây dựng kế hoạch, tiêu chí, thẩm định và đánh giá không được có quan hệ về lợi ích với đơn vị dự tuyển. Tổ chức, cá nhân tư vấn xây dựng kế hoạch không được tham gia dự tuyển hoặc tư vấn cho đơn vị dự tuyển trong cùng quá trình lựa chọn.

---

USER

giúp tôi hoàn thành 2 nội dung tô đỏ

---

ASSISTANT

Mình sẽ xem hai nội dung tô đỏ và viết hoàn chỉnh cho phù hợp với phần kế hoạch bạn đang soạn.

---

ASSISTANT

Mình viết lại **mục 2 và mục 4** như sau. Mức **15%** được giữ theo dự kiến của bạn; cần có bảng dự toán chi phí làm cơ sở trước khi chốt.

> **writing · standard**
>
> **2. Tỷ lệ trích nộp cho nhà trường**
>
> Đối tác thực hiện trích nộp cho nhà trường 15% tổng số tiền thực thu từ hoạt động theo hợp đồng, sau khi đối soát các khoản miễn, giảm và hoàn trả cho cha mẹ trẻ. Tỷ lệ này được xác định trên cơ sở dự toán chi phí sử dụng tài sản công, điện, nước, vệ sinh, quản lý, giám sát và các nghĩa vụ tài chính có liên quan theo quy định. Tỷ lệ trích nộp, căn cứ tính và phương thức thanh toán được công khai trong thông báo mời tham gia, kèm theo bảng dự toán chi phí và được quy định cụ thể trong hợp đồng.
>
> **4. Phương thức thu, chuyển nộp và hạch toán**
>
> Đối tác trực tiếp thu tiền từ cha mẹ trẻ và thực hiện lập hóa đơn, chứng từ theo quy định, phù hợp với nội dung cung cấp dịch vụ và phương thức thu được xác định trong hợp đồng. Định kỳ hằng tháng, đối tác phối hợp với nhà trường đối soát số trẻ tham gia, các khoản miễn, giảm, hoàn trả, tổng số tiền thực thu và số tiền phải trích nộp cho nhà trường.
>
> Khoản trích nộp được chuyển vào tài khoản của nhà trường theo thời hạn quy định trong hợp đồng. Kế toán nhà trường kiểm tra bảng đối soát, chứng từ chuyển tiền; thực hiện lập hóa đơn, chứng từ đối với phần thu của nhà trường theo quy định; hạch toán đầy đủ và công khai việc thu, chi. Hợp đồng phải quy định rõ trách nhiệm của mỗi bên trong việc thu tiền, lập hóa đơn, chuyển nộp, đối soát và xử lý chênh lệch phát sinh.

Ở mục 4, mình dùng cách viết **“lập hóa đơn, chứng từ theo quy định”**, vì trách nhiệm xuất hóa đơn phải phù hợp với bên cung cấp dịch vụ và cách thu tiền thực tế, không chỉ căn cứ vào tỷ lệ phân chia. https://xaydungchinhsach.chinhphu.vn/nghi-dinh-70-2025-nd-cp-sua-doi-bo-sung-quy-dinh-ve-hoa-don-chung-tu-11925032321512617.htm
https://xaydungchinhsach.chinhphu.vn/nghi-dinh-70-2025-nd-cp-sua-doi-bo-sung-quy-dinh-ve-hoa-don-chung-tu-11925032321512617.htm?utm_source=chatgpt.com

---

USER

viết lại mục 5 giúp mình

---

ASSISTANT

> **writing · standard**
>
> **5. Nội dung hợp đồng**
>
> Hợp đồng phải quy định rõ tỷ lệ phân chia nguồn thu, căn cứ tính, thời hạn chuyển nộp và kỳ đối soát; trách nhiệm của mỗi bên trong việc thu tiền, lập hóa đơn, chứng từ và cung cấp hồ sơ phục vụ kiểm tra. Nhà trường được kiểm tra sổ sách, chứng từ liên quan đến hoạt động theo hợp đồng. Đồng thời, hợp đồng phải xác định cụ thể trách nhiệm, biện pháp xử lý khi một bên vi phạm và việc hoàn trả tiền cho cha mẹ trẻ tương ứng với số buổi chưa thực hiện khi trẻ nghỉ giữa chừng hoặc đối tác không tổ chức đủ số buổi đã cam kết.

---

USER

bạn có thể viết lại nội dung này giúp tôi

---

ASSISTANT

Mình sẽ đọc hai ảnh và viết lại cho rõ ý, chặt chẽ, thống nhất với cách trình bày của kế hoạch.

---

ASSISTANT

> **writing · standard**
>
> **VII. TỔ CHỨC THỰC HIỆN**
>
> **1. Ban Giám hiệu**
>
> Chỉ đạo, tổ chức thực hiện kế hoạch; bảo đảm quá trình lựa chọn đối tác công khai, minh bạch và đúng quy trình. Hiệu trưởng ban hành thông báo mời tham gia, quyết định thành lập Tổ đánh giá hồ sơ, xem xét phê duyệt kết quả lựa chọn theo thẩm quyền và ký kết hợp đồng với đối tác được lựa chọn. Phân công bộ phận phụ trách tổng hợp, lưu trữ đầy đủ hồ sơ của quá trình lựa chọn và triển khai thực hiện hợp đồng.
>
> **2. Tổ đánh giá hồ sơ**
>
> Tổ đánh giá hồ sơ gồm đại diện Ban Giám hiệu, Công đoàn, Ban Thanh tra nhân dân, Ban đại diện cha mẹ trẻ và người có chuyên môn phù hợp khi cần thiết.
>
> Tổ có trách nhiệm kiểm tra hồ sơ, đánh giá theo các tiêu chí đã công bố, tổng hợp kết quả và đề xuất đối tác đáp ứng yêu cầu để trình Hiệu trưởng xem xét. Các thành viên ký cam kết không có xung đột lợi ích; thực hiện chấm điểm độc lập, khách quan, ghi rõ căn cứ và nhận xét đối với từng tiêu chí. Thành viên có quan hệ lợi ích với đơn vị dự tuyển phải báo cáo và không tham gia đánh giá hồ sơ của đơn vị đó. Kết quả đánh giá được lập thành biên bản và lưu cùng hồ sơ lựa chọn.
>
> **3. Tổ chức, cá nhân tư vấn xây dựng kế hoạch**
>
> Thực hiện tư vấn theo nội dung được giao; các ý kiến tư vấn phải được ghi nhận bằng văn bản. Tổ chức, cá nhân tư vấn xây dựng kế hoạch không được tham gia dự tuyển, tư vấn cho đơn vị dự tuyển hoặc tham gia chấm điểm trong cùng quá trình lựa chọn đối tác.
>
> **4. Giáo viên chủ nhiệm, nhân viên**
>
> Sau khi nhà trường ký kết hợp đồng, phổ biến đầy đủ, chính xác và khách quan đến cha mẹ trẻ về nội dung hoạt động, thời gian tổ chức, mức thu, chính sách miễn, giảm và quyền lợi của trẻ khi tham gia.
>
> Việc đăng ký phải dựa trên sự tự nguyện của cha mẹ trẻ; không vận động mang tính ép buộc hoặc gây áp lực. Phối hợp theo dõi trẻ tham gia, kịp thời phản ánh những vấn đề phát sinh với Ban Giám hiệu; bảo đảm trẻ không đăng ký vẫn được chăm sóc, giáo dục bình thường và không bị phân biệt đối xử.
>
> **5. Kiểm tra, giám sát việc thực hiện hợp đồng**
>
> Ban Giám hiệu tổ chức kiểm tra định kỳ việc thực hiện nội dung, số buổi hoạt động, chất lượng và các điều kiện bảo đảm an toàn cho trẻ; kịp thời yêu cầu đối tác khắc phục những hạn chế, xử lý vi phạm theo hợp đồng.
>
> Kế toán phối hợp với đối tác kiểm tra hóa đơn, chứng từ, đối soát số tiền thực thu và khoản trích nộp cho nhà trường theo hợp đồng. Cuối mỗi học kỳ, nhà trường tổng hợp, công khai kết quả thực hiện và thông tin đến Ban đại diện cha mẹ trẻ.
>
> Trên đây là Kế hoạch lựa chọn đối tác liên kết tổ chức hoạt động giáo dục ngoài giờ chính khóa, sử dụng tài sản công phục vụ chức năng, nhiệm vụ của Trường Mầm non An Bình năm học 2026–2027. Các bộ phận, cá nhân được phân công có trách nhiệm triển khai thực hiện; kịp thời báo cáo Hiệu trưởng những khó khăn, vướng mắc để xem xét, giải quyết./.

---

USER

câu kết có thể thay thế bằng nghiêm túc thực hiện

---

ASSISTANT

> **writing · standard**
>
> Trên đây là Kế hoạch lựa chọn đối tác liên kết tổ chức hoạt động giáo dục ngoài giờ chính khóa, sử dụng tài sản công phục vụ chức năng, nhiệm vụ của Trường Mầm non An Bình năm học 2026–2027. Đề nghị các bộ phận, cá nhân có liên quan nghiêm túc thực hiện./.

---

