USER

Mình cần ban hành quyết định quy chế chuyên môn.bạn điều chỉnh hướng dẫn  để đính kèm quyết định nhé

---

ASSISTANT

Mình sẽ đối chiếu dự thảo Quyết định với phần Hướng dẫn bạn gửi, rồi chỉnh lại tên văn bản, phần mở đầu và cách trình bày để dùng làm phụ lục ban hành kèm Quyết định. Mình cũng sẽ kiểm tra xem đã có đủ nội dung Hướng dẫn để chuyển thành Quy chế hoàn chỉnh chưa.

---

ASSISTANT

---

ASSISTANT

Mình sẽ điều chỉnh theo hướng **ban hành Quy chế chuyên môn năm học 2026–2027 kèm theo Quyết định của Hiệu trưởng Trường Mầm non An Bình**, thay vì sử dụng văn bản có hình thức “Hướng dẫn thực hiện quy chế chuyên môn” như trước.

Về thể thức, cần thống nhất thành hai phần: **Quyết định ban hành Quy chế chuyên môn** và **Quy chế chuyên môn ban hành kèm theo Quyết định**. Nội dung hướng dẫn hiện có sẽ được giữ lại về chuyên môn, đồng thời chỉnh cách diễn đạt để thể hiện rõ yêu cầu thực hiện, trách nhiệm và tính thống nhất trong toàn trường.

Mình đã phát hiện hai chi tiết pháp lý cần sửa trong dự thảo Quyết định bạn gửi:

- Văn bản hợp nhất Điều lệ trường mầm non có ký hiệu đúng là **09/2026/VBHN-TT-BGDĐT**, ngày 23/7/2026. [Văn bản hợp nhất số 09/2026/VBHN\-TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Ban hành Điều lệ Trường mầm non](<https://vanban.chinhphu.vn/?classid=0&docid=219018&pageid=27160>)
- Thông tư **28/2026/TT-BGDĐT** về Chuẩn nghề nghiệp giáo viên mầm non ban hành ngày **09/4/2026**, không phải ngày 29/4/2026. [Thông tư số 28/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Quy định Chuẩn nghề nghiệp giáo viên mầm non](<https://vanban.chinhphu.vn/?docid=217730&pageid=27160>)

## 1. Dự thảo Quyết định sau khi chỉnh sửa

Mình giữ các căn cứ kế hoạch của Trường Mầm non An Bình, đồng thời điều chỉnh căn cứ pháp lý và nội dung các điều cho thống nhất. Đối với Điều lệ trường mầm non, nên viện dẫn Thông tư 52/2020/TT-BGDĐT và Thông tư sửa đổi 51/2026/TT-BGDĐT. [Thông tư số 52/2020/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Ban hành Điều lệ Trường mầm non](<https://vanban.chinhphu.vn/?docid=203047&pageid=27160>); [Thông tư số 51/2026/TT\-BGDĐT sửa đổi, bổ sung một số điều của Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy chế tổ chức, hoạt động nhóm trẻ độc lập, lớp mẫu giáo độc lập, lớp mầm non độc lập loại hình dân lập và tư thục ban hành kèm theo Thông tư số 49/2021/TT\-BGDĐT ngày 31 tháng 12 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy định tiêu chuẩn, quy trình biên soạn, chỉnh sửa Chương trình giáo dục mầm non, tổ chức và hoạt động của Hội đồng quốc gia thẩm định Chương trình giáo dục mầm non ban hành kèm theo Thông tư số 49/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo\.](<https://congbao.chinhphu.vn/van-ban/thong-tu-so-51-2026-tt-bgddt-470009.htm>)

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập - Tự do - Hạnh phúc**
>
> Số: …/QĐ-MNAB
>
> *An Bình, ngày … tháng … năm 2026*
>
> **QUYẾT ĐỊNH**  
> **Ban hành Quy chế chuyên môn năm học 2026–2027**
>
> **HIỆU TRƯỞNG TRƯỜNG MẦM NON AN BÌNH**
>
> Căn cứ Luật Giáo dục số 43/2019/QH14 ngày 14 tháng 6 năm 2019 và các văn bản sửa đổi, bổ sung có liên quan;
>
> Căn cứ Luật Nhà giáo số 73/2025/QH15 ngày 16 tháng 6 năm 2025;
>
> Căn cứ Thông tư số 52/2020/TT-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Điều lệ trường mầm non, được sửa đổi, bổ sung bởi Thông tư số 51/2026/TT-BGDĐT ngày 30 tháng 6 năm 2026;
>
> Căn cứ Thông tư số 28/2026/TT-BGDĐT ngày 09 tháng 4 năm 2026 của Bộ trưởng Bộ Giáo dục và Đào tạo quy định Chuẩn nghề nghiệp giáo viên mầm non;
>
> Căn cứ Kế hoạch số 38/KH-MNAB ngày 03 tháng 9 năm 2026 của Trường Mầm non An Bình về thời gian năm học 2026–2027;
>
> Căn cứ Kế hoạch số 39/KH-MNAB ngày 03 tháng 9 năm 2026 của Trường Mầm non An Bình về thực hiện kế hoạch giáo dục năm học 2026–2027;
>
> Căn cứ Kế hoạch số 129/KH-MNAB ngày 11 tháng 9 năm 2026 của Trường Mầm non An Bình về thực hiện nhiệm vụ năm học 2026–2027;
>
> Xét đề nghị của Phó Hiệu trưởng phụ trách công tác chuyên môn,
>
> **QUYẾT ĐỊNH:**
>
> **Điều 1.** Ban hành kèm theo Quyết định này Quy chế chuyên môn của Trường Mầm non An Bình năm học 2026–2027.
>
> **Điều 2.** Quy chế chuyên môn là căn cứ để nhà trường tổ chức, quản lý, chỉ đạo và kiểm tra việc thực hiện nhiệm vụ chăm sóc, nuôi dưỡng và giáo dục trẻ; đồng thời là một trong những căn cứ để đánh giá việc thực hiện nhiệm vụ chuyên môn của cán bộ quản lý, giáo viên, nhân viên và người lao động theo quy định hiện hành.
>
> **Điều 3.** Quyết định này có hiệu lực kể từ ngày ký và được áp dụng trong năm học 2026–2027.
>
> **Điều 4.** Các Phó Hiệu trưởng, tổ trưởng, tổ phó chuyên môn, giáo viên, nhân viên và người lao động thuộc Trường Mầm non An Bình chịu trách nhiệm thi hành Quyết định này./.
>
> **Nơi nhận:**  
> - Như Điều 4;
> - Lưu: VT, CM.
>
> **HIỆU TRƯỞNG**
>
> **Huỳnh Hồng Loan**

## 2. Phần đầu của Quy chế đính kèm Quyết định

Đây là cách mình đề nghị chuyển phần đầu của Hướng dẫn số 178/MNAB mà bạn chụp thành văn bản Quy chế. Giữ nguyên mục đầu tiên về chăm sóc, nuôi dưỡng để thuận tiện ghép với các nội dung chuyên môn phía sau.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **QUY CHẾ CHUYÊN MÔN**  
> **Năm học 2026–2027**
>
> *(Ban hành kèm theo Quyết định số …/QĐ-MNAB ngày … tháng … năm 2026 của Hiệu trưởng Trường Mầm non An Bình)*
>
> Quy chế này quy định các yêu cầu về tổ chức, quản lý và thực hiện nhiệm vụ chuyên môn trong công tác chăm sóc, nuôi dưỡng và giáo dục trẻ tại Trường Mầm non An Bình năm học 2026–2027.
>
> Quy chế được áp dụng đối với cán bộ quản lý, tổ trưởng, tổ phó chuyên môn, giáo viên, nhân viên và người lao động có liên quan đến hoạt động chăm sóc, nuôi dưỡng và giáo dục trẻ trong nhà trường.
>
> Các tổ chuyên môn, bộ phận và cá nhân có trách nhiệm thực hiện nghiêm túc những nội dung quy định tại Quy chế này theo chức trách, nhiệm vụ được phân công; bảo đảm chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ và sự thống nhất trong hoạt động chuyên môn của nhà trường.
>
> **I. CÔNG TÁC CHĂM SÓC, NUÔI DƯỠNG**

Phần này sẽ được nối tiếp bằng các quy định chi tiết từ Hướng dẫn hiện có. Khi chuyển đổi, cần bỏ phần “Số: 178/MNAB”, “V/v Hướng dẫn thực hiện...” và “Kính gửi”; đồng thời rà soát cách diễn đạt, trách nhiệm thực hiện và bổ sung phần tổ chức thực hiện nếu văn bản cũ chưa có.

## 3. Phần nội dung mình cần bạn gửi thêm

**Hiện mình mới nhận được bản Word dự thảo Quyết định gồm 2 trang và ảnh chụp phần mở đầu của Hướng dẫn số 178/MNAB ngày 22/9/2026.** Chưa có toàn văn Hướng dẫn nên mình chưa thể chỉnh trọn vẹn phần Quy chế đính kèm mà vẫn bảo đảm giữ đúng các nội dung nhà trường đã xây dựng.

Bạn gửi giúp mình **file Word đầy đủ của Hướng dẫn số 178/MNAB** nhé.

Mình sẽ bám sát toàn bộ nội dung gốc, chuyển thành **Quy chế chuyên môn năm học 2026–2027**, chuẩn hóa thể thức, thống nhất với Quyết định và rà soát các quy định không còn phù hợp. Đặc biệt, cần kiểm tra việc áp dụng Công văn số 683/SGDĐT-GDMN năm 2025 trong năm học mới trước khi ban hành chính thức.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

USER

**4. Thực hiện hồ sơ sổ sách đối với CBQL và giáo viên** 
(Thực hiện theo quy định chung của ngành học) add nd ss theo tt52 vào. bạn giúp tôi thực hiện nội dung 4 này theo dạng phụ lục đính kèm

---

ASSISTANT

Mình sẽ soạn riêng **Phụ lục hồ sơ, sổ sách của cán bộ quản lý và giáo viên** để đặt sau Quy chế chuyên môn năm học 2026–2027. Mình sẽ đối chiếu danh mục trong Thông tư 52 với các quy định sửa đổi, đồng thời phân biệt hồ sơ bắt buộc với biểu mẫu nhà trường sử dụng để quản lý, tránh yêu cầu giáo viên làm thêm sổ sách không cần thiết.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Đã đối chiếu Điều 21 của Điều lệ trường mầm non theo văn bản hợp nhất năm 2026: có **6 nhóm hồ sơ cấp trường, 2 loại hồ sơ cấp tổ và 3 loại hồ sơ của giáo viên**. Mình sẽ đưa đúng danh mục này vào phụ lục; phần hướng dẫn cách lập, cập nhật và phân công quản lý sẽ ghi rõ là hướng dẫn triển khai của nhà trường, không phải danh mục sổ bắt buộc mới.

---

ASSISTANT

Mình đã rà soát nội dung tại **Mục II.4 – Thực hiện hồ sơ, sổ sách đối với cán bộ quản lý và giáo viên** trong Quy chế chuyên môn năm học 2026–2027 của Trường Mầm non An Bình.

Mình đề xuất giữ Mục 4 trong Quy chế dưới dạng quy định chung, đồng thời ban hành **Phụ lục 01 – Danh mục và hướng dẫn thực hiện hồ sơ, sổ sách** để cán bộ quản lý, tổ chuyên môn và giáo viên dễ thực hiện, kiểm tra.

Cơ sở xây dựng là Điều 21 Thông tư số 52/2020/TT-BGDĐT, được đối chiếu với Văn bản hợp nhất số 09/2026/VBHN-TT-BGDĐT ngày 23/7/2026. Điều này quy định 6 nhóm hồ sơ nhà trường, 2 loại hồ sơ cấp tổ và 3 loại hồ sơ giáo viên; đồng thời cho phép sử dụng hồ sơ điện tử theo lộ trình và điều kiện quy định. [Source unavailable: turn658941search0]; [Source unavailable: turn566158view3]

## 1. Nội dung thay thế Mục II.4 trong Quy chế

> **writing · document**
>
> **4. Thực hiện hồ sơ, sổ sách đối với cán bộ quản lý và giáo viên**
>
> Việc xây dựng, quản lý, sử dụng và lưu trữ hồ sơ, sổ sách phục vụ hoạt động nuôi dưỡng, chăm sóc và giáo dục trẻ được thực hiện theo Điều 21 Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo và các văn bản sửa đổi, bổ sung hiện hành.
>
> Cán bộ quản lý, tổ chuyên môn, tổ văn phòng và giáo viên thực hiện đúng danh mục hồ sơ theo quy định; bảo đảm tính chính xác, đầy đủ, khoa học, cập nhật kịp thời và phù hợp với nhiệm vụ được phân công. Tăng cường ứng dụng công nghệ thông tin, từng bước sử dụng hồ sơ điện tử theo hướng dẫn của cơ quan quản lý giáo dục có thẩm quyền.
>
> Nhà trường thống nhất thực hiện danh mục, nội dung quản lý, trách nhiệm thực hiện và hình thức lưu trữ hồ sơ, sổ sách theo **Phụ lục 01 – Danh mục và hướng dẫn thực hiện hồ sơ, sổ sách chuyên môn năm học 2026–2027** đính kèm Quy chế này.
>
> Không yêu cầu giáo viên lập thêm các loại sổ sách chuyên môn ngoài quy định, trừ trường hợp có quy định riêng của cơ quan có thẩm quyền; hạn chế việc ghi chép trùng lặp, hình thức, tạo điều kiện để giáo viên tập trung nâng cao chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ.

## 2. Phụ lục 01 đính kèm Quy chế chuyên môn

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **PHỤ LỤC 01**
>
> **DANH MỤC VÀ HƯỚNG DẪN THỰC HIỆN HỒ SƠ, SỔ SÁCH CHUYÊN MÔN**  
> **Năm học 2026–2027**
>
> *(Kèm theo Quy chế chuyên môn năm học 2026–2027 ban hành kèm theo Quyết định số …/QĐ-MNAB ngày … tháng … năm 2026 của Hiệu trưởng Trường Mầm non An Bình)*
>
> ### I. QUY ĐỊNH CHUNG
>
> **1. Căn cứ thực hiện**
>
> Thực hiện theo Điều 21 Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo, được sửa đổi, bổ sung bởi Thông tư số 51/2026/TT-BGDĐT ngày 30 tháng 6 năm 2026.
>
> **2. Mục đích, yêu cầu**
>
> - Thống nhất danh mục hồ sơ, sổ sách phục vụ công tác quản lý và tổ chức hoạt động nuôi dưỡng, chăm sóc, giáo dục trẻ trong toàn trường.
> - Xác định rõ trách nhiệm quản lý, cập nhật, sử dụng và lưu trữ hồ sơ của các bộ phận, cá nhân.
> - Bảo đảm hồ sơ được thực hiện đầy đủ, chính xác, có tính ứng dụng thực tế, phục vụ hiệu quả công tác quản lý và kiểm tra chuyên môn.
> - Đẩy mạnh ứng dụng công nghệ thông tin, giảm áp lực hồ sơ, sổ sách, tránh ghi chép trùng lặp và hình thức.
>
> ### II. DANH MỤC HỒ SƠ, SỔ SÁCH
>
> **1. Hồ sơ quản lý của nhà trường**
>
> Theo khoản 1 Điều 21 Điều lệ trường mầm non, hồ sơ quản lý hoạt động nuôi dưỡng, chăm sóc, giáo dục đối với nhà trường gồm 06 nhóm sau:
>
> | STT | Danh mục hồ sơ | Hướng dẫn quản lý, thực hiện |
> |---|---|---|
> | 1 | Hồ sơ quản lý trẻ em | Quản lý thông tin, danh sách trẻ, tình hình huy động, tiếp nhận và biến động trẻ trong năm học; cập nhật dữ liệu theo quy định. |
> | 2 | Hồ sơ quản lý cán bộ, giáo viên, nhân viên | Quản lý thông tin nhân sự, phân công nhiệm vụ, quá trình công tác và các hồ sơ liên quan theo quy định. |
> | 3 | Kế hoạch phát triển nhà trường và kế hoạch nuôi dưỡng, chăm sóc, giáo dục theo năm học | Xây dựng, tổ chức thực hiện, theo dõi và đánh giá kết quả thực hiện các kế hoạch theo nhiệm vụ năm học. |
> | 4 | Hồ sơ phổ cập giáo dục | Thực hiện điều tra, cập nhật dữ liệu, thống kê và báo cáo công tác phổ cập giáo dục theo quy định. |
> | 5 | Hồ sơ quản lý tài sản, tài chính | Quản lý, theo dõi tài sản, trang thiết bị, các nguồn kinh phí và hoạt động thu, chi theo quy định hiện hành. |
> | 6 | Hồ sơ quản lý các văn bản | Quản lý, lưu trữ văn bản đến, văn bản đi, quyết định, kế hoạch, báo cáo và các văn bản có liên quan đến hoạt động nhà trường. |
>
> **Trách nhiệm thực hiện:**
>
> - Hiệu trưởng chịu trách nhiệm chung về công tác quản lý hồ sơ của nhà trường; chỉ đạo xây dựng, phê duyệt và tổ chức thực hiện các kế hoạch thuộc thẩm quyền.
> - Các Phó Hiệu trưởng chịu trách nhiệm quản lý, theo dõi và kiểm tra hồ sơ thuộc lĩnh vực được phân công.
> - Tổ trưởng văn phòng, nhân viên và các cá nhân được phân công có trách nhiệm cập nhật, quản lý và lưu trữ hồ sơ theo nhiệm vụ.
>
> **2. Hồ sơ của tổ chuyên môn, tổ văn phòng**
>
> Theo khoản 2 Điều 21 Điều lệ trường mầm non, thực hiện 02 loại hồ sơ sau:
>
> | STT | Danh mục hồ sơ | Hướng dẫn thực hiện |
> |---|---|---|
> | 1 | Kế hoạch hoạt động | Xây dựng kế hoạch hoạt động của tổ theo năm học, tháng và nhiệm vụ được giao; xác định nội dung công việc, thời gian thực hiện và giải pháp tổ chức thực hiện. |
> | 2 | Sổ ghi chép nội dung sinh hoạt chuyên môn của tổ | Ghi nhận nội dung sinh hoạt, ý kiến trao đổi, thảo luận, kết luận, thống nhất chuyên môn và nhiệm vụ triển khai sau sinh hoạt; đối với tổ văn phòng thực hiện phù hợp với chức năng, nhiệm vụ của tổ. |
>
> **Trách nhiệm thực hiện:**
>
> - Tổ trưởng chịu trách nhiệm xây dựng, tổ chức thực hiện và quản lý hồ sơ của tổ.
> - Tổ phó phối hợp thực hiện theo sự phân công của tổ trưởng.
> - Các thành viên tham gia xây dựng kế hoạch, sinh hoạt chuyên môn và thực hiện nhiệm vụ theo nội dung đã thống nhất.
> - Phó Hiệu trưởng phụ trách hướng dẫn, kiểm tra, hỗ trợ và đánh giá việc thực hiện hồ sơ của các tổ theo phân công.
>
> **3. Hồ sơ, sổ sách của giáo viên**
>
> Theo khoản 3 Điều 21 Điều lệ trường mầm non, giáo viên thực hiện 03 loại hồ sơ sau:
>
> | STT | Danh mục hồ sơ | Hướng dẫn thực hiện |
> |---|---|---|
> | 1 | Kế hoạch nuôi dưỡng, chăm sóc, giáo dục của nhóm trẻ, lớp mẫu giáo | Xây dựng kế hoạch phù hợp Chương trình giáo dục mầm non, kế hoạch giáo dục nhà trường và tình hình thực tế của nhóm/lớp. Nội dung kế hoạch theo tháng, tuần và việc tổ chức hoạt động hằng ngày được thực hiện theo hướng dẫn chuyên môn thống nhất của nhà trường. |
> | 2 | Sổ theo dõi trẻ em | Theo dõi, cập nhật thông tin trẻ, tình hình đến lớp và các nội dung theo dõi cần thiết phục vụ việc chăm sóc, nuôi dưỡng, giáo dục và đánh giá sự phát triển của trẻ theo quy định. |
> | 3 | Sổ theo dõi tài sản, thiết bị, đồ chơi của nhóm trẻ, lớp mẫu giáo | Theo dõi số lượng, tình trạng sử dụng, biến động, hư hỏng và việc bàn giao tài sản, thiết bị, đồ dùng, đồ chơi được trang bị tại nhóm/lớp. |
>
> **Trách nhiệm thực hiện:**
>
> - Giáo viên chịu trách nhiệm xây dựng, thực hiện và cập nhật hồ sơ chuyên môn theo nhiệm vụ được phân công.
> - Đối với nhóm/lớp có từ hai giáo viên trở lên, nhà trường phân công giáo viên phụ trách từng nội dung, bảo đảm hồ sơ được quản lý thống nhất, không ghi chép trùng lặp.
> - Giáo viên thường xuyên rà soát, điều chỉnh kế hoạch nuôi dưỡng, chăm sóc, giáo dục phù hợp với khả năng, nhu cầu và sự phát triển của trẻ.
> - Thực hiện bàn giao, lưu trữ hồ sơ và tài sản nhóm/lớp theo phân công và quy định của nhà trường.
>
> ### III. QUY ĐỊNH VỀ QUẢN LÝ, SỬ DỤNG VÀ LƯU TRỮ HỒ SƠ
>
> **1. Về xây dựng và cập nhật hồ sơ**
>
> Hồ sơ phải phản ánh trung thực quá trình quản lý, tổ chức thực hiện nhiệm vụ chuyên môn; nội dung rõ ràng, chính xác, khoa học, phù hợp với điều kiện thực tế của nhà trường, tổ chuyên môn và nhóm/lớp.
>
> Việc cập nhật hồ sơ được thực hiện kịp thời theo nội dung công việc phát sinh và yêu cầu chuyên môn; không thực hiện ghi chép mang tính đối phó hoặc hình thức.
>
> **2. Về hình thức thực hiện**
>
> Khuyến khích ứng dụng công nghệ thông tin trong xây dựng, cập nhật, quản lý và lưu trữ hồ sơ.
>
> Hồ sơ điện tử được sử dụng thay thế hồ sơ giấy theo lộ trình phù hợp với điều kiện thực tế, khả năng thực hiện của giáo viên, bảo đảm tính hợp pháp và tuân thủ quy định, hướng dẫn của cơ quan quản lý giáo dục có thẩm quyền.
>
> Không yêu cầu in ấn trùng lặp đối với hồ sơ điện tử đã đáp ứng đầy đủ điều kiện pháp lý để sử dụng thay thế hồ sơ giấy, trừ trường hợp pháp luật có quy định riêng.
>
> **3. Về quản lý và lưu trữ hồ sơ**
>
> Hồ sơ được quản lý theo từng cấp: nhà trường, tổ chuyên môn, tổ văn phòng và nhóm/lớp; bảo đảm thuận tiện cho việc khai thác, sử dụng, kiểm tra và bàn giao.
>
> Việc lưu trữ, bảo quản hồ sơ phải bảo đảm an toàn, bảo mật thông tin của trẻ em, cán bộ quản lý, giáo viên và nhân viên; thực hiện thời hạn lưu trữ theo quy định pháp luật có liên quan.
>
> **4. Về kiểm tra, đánh giá hồ sơ chuyên môn**
>
> - Ban Giám hiệu tổ chức kiểm tra việc thực hiện hồ sơ chuyên môn theo kế hoạch kiểm tra nội bộ và yêu cầu quản lý của nhà trường.
> - Nội dung kiểm tra tập trung vào tính đầy đủ, chính xác, phù hợp, kịp thời và hiệu quả sử dụng hồ sơ trong hoạt động chuyên môn.
> - Kết quả kiểm tra được sử dụng để hướng dẫn, hỗ trợ, điều chỉnh và nâng cao chất lượng thực hiện nhiệm vụ.
> - Không lấy hình thức trình bày, số lượng trang viết hoặc số lượng hồ sơ ngoài quy định làm căn cứ duy nhất để đánh giá năng lực chuyên môn của giáo viên.
>
> ### IV. TỔ CHỨC THỰC HIỆN
>
> **1. Hiệu trưởng**
>
> Chỉ đạo thống nhất việc thực hiện danh mục hồ sơ, sổ sách trong toàn trường; phân công trách nhiệm quản lý, tổ chức kiểm tra và kịp thời điều chỉnh những nội dung chưa phù hợp theo quy định.
>
> **2. Phó Hiệu trưởng**
>
> Hướng dẫn các tổ chuyên môn, giáo viên thực hiện hồ sơ theo đúng quy định; theo dõi, kiểm tra và hỗ trợ việc thực hiện; chú trọng chất lượng thực tế, hạn chế áp lực hành chính đối với giáo viên.
>
> **3. Tổ trưởng chuyên môn, tổ trưởng văn phòng**
>
> Triển khai thực hiện đến các thành viên trong tổ; hướng dẫn, kiểm tra và phản ánh kịp thời những khó khăn, vướng mắc để Ban Giám hiệu xem xét giải quyết.
>
> **4. Giáo viên**
>
> Thực hiện đầy đủ các hồ sơ thuộc trách nhiệm của giáo viên theo quy định; sử dụng hồ sơ phục vụ trực tiếp việc chăm sóc, nuôi dưỡng, giáo dục và theo dõi sự phát triển của trẻ.
>
> **5. Quy định chung**
>
> Danh mục tại Phụ lục này là căn cứ thống nhất để tổ chức thực hiện hồ sơ, sổ sách chuyên môn trong năm học 2026–2027. Các biểu mẫu và hướng dẫn chi tiết do nhà trường thống nhất áp dụng phải phù hợp với quy định hiện hành, không làm phát sinh hồ sơ bắt buộc ngoài quy định.
>
> Trong quá trình thực hiện, nếu có văn bản mới của cơ quan có thẩm quyền hoặc có khó khăn, vướng mắc, các bộ phận báo cáo Hiệu trưởng để xem xét, điều chỉnh phù hợp.
>
> **Phụ lục này là bộ phận kèm theo Quy chế chuyên môn năm học 2026–2027 của Trường Mầm non An Bình.**

## 3. Lưu ý trước khi ban hành

Phụ lục trên phân biệt rõ **danh mục theo Điều lệ trường mầm non** với **hướng dẫn tổ chức thực hiện của Trường Mầm non An Bình**. Đây là điểm quan trọng để tránh phát sinh thêm hồ sơ bắt buộc đối với giáo viên.

Ngoài ra, khi rà soát file Quy chế bạn gửi, mình nhận thấy phần III về báo cáo sơ kết học kỳ I đang ghi hạn nộp **20/01/2026 và 25/01/2026**. Vì văn bản áp dụng năm học 2026–2027, bạn cần sửa thành **20/01/2027 và 25/01/2027** nếu giữ nguyên các mốc ngày này.

**Đề xuất:** Sử dụng Phụ lục 01 trên làm tài liệu chính thức kèm Quy chế, giúp nhà trường thống nhất danh mục hồ sơ, phân công trách nhiệm rõ ràng và giảm áp lực ghi chép cho giáo viên.

---

USER

dựa vào tt 52 (đei6ù 20) bạn hãy giúp tôi xếp các loại hồ sơ sổ sách liệt kê  theo các mục của thông tư 52

---

ASSISTANT

Mình sẽ giữ đầy đủ các loại hồ sơ trong 5 ảnh bạn gửi, nhưng sắp xếp lại theo đúng các nhóm hồ sơ của Điều lệ trường mầm non. Mình cũng sẽ kiểm tra lại số điều trong Thông tư 52 và các sửa đổi hiện hành, để phụ lục không nhầm giữa **danh mục hồ sơ bắt buộc** và **tài liệu minh chứng, hồ sơ nghiệp vụ được lưu trong từng nhóm**.

---

ASSISTANT

---

ASSISTANT

## PHỤ LỤC – DANH MỤC HỒ SƠ, TÀI LIỆU NĂM HỌC 2026–2027

Mình đề xuất sắp xếp lại toàn bộ hồ sơ, sổ sách trong 5 ảnh bạn gửi theo đúng cơ cấu của Điều lệ trường mầm non, để Trường Mầm non An Bình có thể sử dụng làm phụ lục đính kèm Quy chế chuyên môn.

**Lưu ý về căn cứ pháp lý:** Nội dung quy định danh mục hồ sơ, sổ sách nằm tại **Điều 21**, không phải Điều 20 của Thông tư 52/2020/TT-BGDĐT. Điều 20 quy định việc đánh giá kết quả nuôi dưỡng, chăm sóc sức khỏe và giáo dục trẻ. Quy định tại Điều 21 tiếp tục được thể hiện trong Văn bản hợp nhất số 09/2026/VBHN-TT-BGDĐT ngày 23/7/2026. [Văn bản hợp nhất số 09/2026/VBHN\-TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Ban hành Điều lệ Trường mầm non](<https://chinhphu.vn/?docid=219018&pageid=27160>); [Văn bản hợp nhất 09/2026/VBHN\-TT\-BGDĐT Thông tư Điều lệ trường mầm non \| Cổng Luật Việt](<https://congluatviet.vn/van-ban/van-ban-hop-nhat-09-2026-vbhn-tt-bgddt-thong-tu-dieu-le-truong-mam-non-09-2026-vbhn-tt-bgddt>); [Thông tư 52/2020/TT\-BGDĐT – Ban hành Điều lệ \| LawPlayer](<https://lawplayer.com/vn/act/vn-vbpl-147475>)

Theo Điều 21, cần chia thành các nhóm chính:

| Đối tượng | Số nhóm hồ sơ theo Điều 21 |
|--------|--------|
| Nhà trường | 6 nhóm |
| Tổ chuyên môn, tổ văn phòng | 2 loại |
| Giáo viên | 3 loại |

Các hồ sơ chi tiết trong ảnh sẽ được sắp xếp vào 11 nhóm, loại nêu trên. Một số tài liệu như hồ sơ y tế, bán trú, hội đồng trường, thi đua, lao động tiền lương được đặt trong nhóm hồ sơ liên quan hoặc ghi rõ là hồ sơ nghiệp vụ quản lý bổ trợ, **không coi là loại sổ chuyên môn bắt buộc mới theo Điều 21**.

Dưới đây là bản sắp xếp lại theo đúng tên các nhóm hồ sơ tại Điều 21. Mình giữ các tài liệu bạn đã liệt kê và chuyển về nhóm tương ứng, đồng thời phân biệt hồ sơ cấp trường, cấp tổ và của giáo viên.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> **PHỤ LỤC 01**  
> **DANH MỤC HỒ SƠ, TÀI LIỆU**  
> **Năm học 2026–2027**
>
> *(Kèm theo Quy chế chuyên môn năm học 2026–2027 của Trường Mầm non An Bình)*
>
> *Căn cứ phân loại: Điều 21 Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020, được cập nhật theo các quy định sửa đổi, bổ sung hiện hành.*
>
> ## I. ĐỐI VỚI NHÀ TRƯỜNG
>
> ### 1. Hồ sơ quản lý trẻ em
>
> **1.1. Hồ sơ tuyển sinh, tiếp nhận và quản lý trẻ**
>
> - Sổ đăng bộ trẻ em (lập nhiều năm/quyển).
> - Hồ sơ trẻ em: bản sao giấy khai sinh, đơn xin nhập học, bản sao bảo hiểm y tế, thông tin tiêm chủng và các giấy tờ liên quan (lưu theo từng nhóm/lớp, độ tuổi).
> - Danh sách trẻ theo nhóm/lớp.
> - Hồ sơ Hội đồng tuyển sinh.
> - Hồ sơ quản lý trẻ khuyết tật học hòa nhập.
>
> **1.2. Hồ sơ theo dõi sức khỏe và sự phát triển của trẻ**
>
> - Hồ sơ theo dõi sức khỏe trẻ em toàn trường; phân loại tình trạng sức khỏe và các bệnh lý cần quan tâm để phối hợp tổ chức khám chuyên khoa (nếu có).
> - Sổ theo dõi sức khỏe từng trẻ (bằng giấy hoặc trên hệ thống quản lý hợp pháp).
> - Sổ tổng hợp theo dõi sức khỏe trẻ em toàn trường.
> - Hồ sơ tổng hợp kết quả đánh giá sự phát triển của trẻ cuối năm học.
>
> ### 2. Hồ sơ quản lý cán bộ, giáo viên, nhân viên
>
> **2.1. Hồ sơ tổ chức, quản lý và sử dụng đội ngũ**
>
> - Hồ sơ cá nhân của viên chức theo quy định về quản lý hồ sơ viên chức.
> - Sổ đăng bộ cán bộ, giáo viên, nhân viên.
> - Hồ sơ quy hoạch, bổ nhiệm cán bộ quản lý.
> - Hồ sơ bổ nhiệm tổ trưởng, tổ phó và phân công nhiệm vụ cán bộ, giáo viên, nhân viên.
> - Kế hoạch đào tạo, bồi dưỡng đội ngũ cán bộ quản lý, giáo viên, nhân viên.
> - Kế hoạch giao biên chế và các văn bản có liên quan.
>
> **2.2. Hồ sơ đánh giá, bồi dưỡng đội ngũ**
>
> - Hồ sơ đánh giá theo Chuẩn hiệu trưởng, phó hiệu trưởng.
> - Hồ sơ đánh giá theo Chuẩn nghề nghiệp giáo viên mầm non.
> - Hồ sơ đánh giá và bồi dưỡng chuyên môn, nghiệp vụ của đội ngũ theo quy định.
>
> **2.3. Hồ sơ lao động, tiền lương và chế độ chính sách**
>
> - Kế hoạch, báo cáo công tác lao động, tiền lương hằng quý, hằng năm.
> - Hồ sơ hợp đồng lao động.
> - Hồ sơ bảo hiểm xã hội.
> - Hồ sơ nâng lương hằng năm.
> - Hồ sơ thâm niên hằng năm.
> - Hồ sơ Hội đồng xét nâng lương.
> - Hồ sơ theo dõi sức khỏe cán bộ, giáo viên, nhân viên trong nhà trường.
> - Hồ sơ sức khỏe nhân viên nấu ăn.
>
> ### 3. Kế hoạch phát triển nhà trường và kế hoạch nuôi dưỡng, chăm sóc, giáo dục theo năm học
>
> **3.1. Hồ sơ kế hoạch phát triển nhà trường**
>
> - Kế hoạch chiến lược phát triển nhà trường.
> - Kế hoạch thực hiện nhiệm vụ năm học.
> - Kế hoạch nuôi dưỡng, chăm sóc, giáo dục năm học.
> - Sổ kế hoạch hoặc tập hồ sơ kế hoạch quản lý, chỉ đạo của nhà trường.
>
> **3.2. Hồ sơ quản lý, chỉ đạo chuyên môn**
>
> - Kế hoạch phát triển Chương trình giáo dục mầm non của nhà trường.
> - Hồ sơ kiểm tra nội bộ trường học.
> - Hồ sơ bồi dưỡng thường xuyên cấp trường.
> - Hồ sơ tổ chức các chuyên đề chuyên môn.
> - Hồ sơ tổ chức ngày hội, ngày lễ, tham quan, học tập và các hoạt động giáo dục khác (nếu tổ chức).
> - Hồ sơ Hội đồng tự đánh giá.
> - Hồ sơ Hội đồng sáng kiến, nghiên cứu khoa học sư phạm ứng dụng.
> - Hồ sơ tổ chức hội thi giáo viên dạy giỏi, cấp dưỡng giỏi (nếu có).
> - Sổ dự giờ của cán bộ quản lý.
> - Sổ hoặc bảng tổng hợp theo dõi chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ.
>
> **3.3. Hồ sơ quản lý công tác bán trú**
>
> - Kế hoạch công tác bán trú.
> - Quyết định thành lập Ban chỉ đạo công tác bán trú, kèm bảng phân công nhiệm vụ.
> - Bảng phân công nhiệm vụ nhân viên nấu ăn.
> - Sổ thực đơn.
> - Hợp đồng mua bán, cung ứng thực phẩm.
> - Sổ thiết lập dưỡng chất, tính khẩu phần dinh dưỡng cho trẻ.
> - Hồ sơ xét nghiệm chất lượng nguồn nước.
> - Bản cam kết bảo đảm điều kiện cơ sở vật chất và an toàn thực phẩm.
> - Sổ giao nhận thực phẩm giữa đơn vị cung ứng và nhà trường.
> - Sổ kiểm thực ba bước và sổ lưu mẫu thức ăn.
> - Sổ xuất, nhập kho thực phẩm.
> - Sổ tổng hợp báo ăn.
> - Sổ tính ăn hằng ngày.
>
> *Các hồ sơ về thu, thanh toán tiền ăn, sổ quỹ tiền mặt và chứng từ quyết toán được xếp tại mục 5 – Hồ sơ quản lý tài sản, tài chính.*
>
> **3.4. Hồ sơ quản lý công tác y tế trường học**
>
> - Các văn bản chỉ đạo về công tác y tế trường học.
> - Quyết định thành lập Ban chăm sóc sức khỏe học sinh.
> - Kế hoạch hoạt động y tế trường học.
> - Hợp đồng chăm sóc, kiểm tra sức khỏe ban đầu cho trẻ (nếu có).
> - Kế hoạch tuyên truyền chăm sóc sức khỏe, phòng chống dịch bệnh.
> - Kế hoạch phòng, chống tai nạn thương tích cho trẻ.
> - Sổ theo dõi cấp phát thuốc y tế.
> - Biên bản kiểm tra y tế trường học.
> - Hồ sơ tuyên truyền, phòng chống dịch bệnh.
> - Hồ sơ tổ chức các hoạt động chăm sóc và bảo vệ sức khỏe trẻ theo kế hoạch.
>
> *Hồ sơ sức khỏe cá nhân của trẻ được quản lý tại mục 1; hồ sơ sức khỏe nhân viên được quản lý tại mục 2.*
>
> ### 4. Hồ sơ phổ cập giáo dục
>
> - Hồ sơ phổ cập giáo dục mầm non cho trẻ em 5 tuổi.
> - Hồ sơ phổ cập giáo dục mầm non cho trẻ em từ 3 đến 5 tuổi theo lộ trình và hướng dẫn triển khai của cấp có thẩm quyền.
> - Các biểu mẫu điều tra, thống kê, tổng hợp số liệu, cập nhật dữ liệu và minh chứng phục vụ công tác phổ cập giáo dục theo quy định.
>
> ### 5. Hồ sơ quản lý tài sản, tài chính
>
> **5.1. Hồ sơ quản lý cơ sở vật chất**
>
> - Quyết định giao đất.
> - Biên bản bàn giao cơ sở vật chất giữa nhà trường với các cơ quan, đơn vị hoặc địa phương.
> - Giấy chứng nhận quyền sử dụng đất và tài sản gắn liền với đất của nhà trường.
> - Sơ đồ tổng thể nhà trường.
> - Hồ sơ thiết kế, xây dựng trường.
>
> **5.2. Hồ sơ quản lý tài sản**
>
> - Sổ theo dõi tài sản, thiết bị, đồ dùng, đồ chơi của nhà trường.
> - Sổ theo dõi hoặc biên bản giao nhận tài sản, thiết bị, đồ dùng, đồ chơi giữa nhà trường với giáo viên phụ trách nhóm/lớp.
> - Biên bản kiểm kê tài sản, thanh lý tài sản hằng năm.
> - Kế hoạch thay thế, sửa chữa, bổ sung, nâng cấp thiết bị, đồ dùng, đồ chơi hằng năm.
> - Hồ sơ lựa chọn đồ chơi, học liệu sử dụng trong cơ sở giáo dục mầm non theo quy định.
>
> **5.3. Hồ sơ quản lý tài chính**
>
> - Hệ thống văn bản quy định hiện hành về quản lý tài chính có liên quan đến hoạt động thu, chi của nhà trường.
> - Quy chế chi tiêu nội bộ.
> - Dự toán tài chính hằng năm.
> - Chứng từ thu, chi và quyết toán tài chính.
> - Báo cáo tài chính, báo cáo quyết toán; báo cáo kết quả kiểm tra, thanh tra, kiểm toán của cơ quan có thẩm quyền (nếu có).
> - Biên bản, nghị quyết Hội nghị viên chức và người lao động có nội dung công khai tài chính.
>
> **5.4. Hồ sơ tài chính phục vụ công tác bán trú**
>
> - Sổ theo dõi thu và thanh toán tiền ăn.
> - Sổ quỹ tiền mặt.
> - Chứng từ thu, chi và quyết toán tiền ăn.
> - Các hồ sơ, chứng từ tài chính bán trú liên quan theo quy định.
>
> ### 6. Hồ sơ quản lý các văn bản
>
> **6.1. Hồ sơ văn thư, lưu trữ**
>
> - Sổ theo dõi công văn đi, đến.
> - Hồ sơ, cặp lưu trữ văn bản đi, đến.
> - Sổ theo dõi văn bản nội bộ.
> - Quyết định thành lập trường và các văn bản pháp lý về tổ chức, hoạt động của nhà trường.
>
> **6.2. Hồ sơ tổ chức, quản lý và điều hành nhà trường**
>
> - Sổ biên bản họp Hội đồng sư phạm nhà trường.
> - Hồ sơ Hội đồng Thi đua - Khen thưởng, kỷ luật.
> - Hồ sơ thực hiện quy chế dân chủ.
> - Hồ sơ tổ chức Hội nghị viên chức và người lao động.
> - Hồ sơ Ban đại diện cha mẹ trẻ.
> - Hồ sơ phổ biến, giáo dục pháp luật.
> - Hồ sơ bảo đảm an ninh, trật tự.
> - Hồ sơ phòng cháy, chữa cháy.
> - Các quyết định, quy chế, quy định và văn bản chỉ đạo, điều hành khác của nhà trường.
>
> ## II. ĐỐI VỚI TỔ CHUYÊN MÔN, TỔ VĂN PHÒNG
>
> ### 1. Kế hoạch hoạt động
>
> **1.1. Đối với tổ chuyên môn**
>
> - Kế hoạch hoạt động của tổ chuyên môn theo năm học, tháng, tuần.
> - Hồ sơ, tài liệu triển khai các chuyên đề của tổ.
> - Tài liệu theo dõi, tổng hợp chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ của tổ.
> - Hồ sơ, tài liệu bồi dưỡng thường xuyên liên quan đến hoạt động của tổ.
> - Hồ sơ lưu các văn bản, tài liệu liên quan đến hoạt động của tổ hằng năm.
>
> **1.2. Đối với tổ văn phòng**
>
> - Kế hoạch hoạt động của tổ văn phòng theo năm học, tháng, tuần.
> - Hồ sơ lưu các văn bản, tài liệu liên quan đến hoạt động của tổ hằng năm.
>
> *Các tài liệu chi tiết nêu trên là nội dung thực hiện hoặc minh chứng thuộc kế hoạch hoạt động của tổ, không phải những loại sổ bắt buộc riêng được Điều 21 liệt kê.*
>
> ### 2. Sổ ghi chép nội dung sinh hoạt chuyên môn của tổ
>
> **2.1. Đối với tổ chuyên môn**
>
> - Sổ ghi chép nội dung sinh hoạt chuyên môn của tổ (có thể thể hiện dưới hình thức biên bản sinh hoạt tổ).
>
> **2.2. Đối với tổ văn phòng**
>
> - Sổ ghi chép nội dung sinh hoạt của tổ văn phòng, phù hợp với chức năng và nhiệm vụ được giao.
>
> ## III. ĐỐI VỚI GIÁO VIÊN
>
> ### 1. Kế hoạch nuôi dưỡng, chăm sóc, giáo dục của nhóm trẻ, lớp mẫu giáo
>
> - Kế hoạch nuôi dưỡng, chăm sóc, giáo dục trẻ của nhóm/lớp.
> - Kế hoạch giáo dục theo năm học, tháng, tuần và kế hoạch tổ chức các hoạt động theo hướng dẫn chuyên môn của nhà trường.
>
> Các nội dung kế hoạch được tổ chức, tích hợp khoa học, phù hợp Chương trình giáo dục mầm non và điều kiện thực tế của nhóm/lớp.
>
> ### 2. Sổ theo dõi trẻ em
>
> - Sổ theo dõi trẻ đến nhóm, lớp mầm non.
> - Nội dung theo dõi, đánh giá sự phát triển của trẻ cuối giai đoạn, cuối độ tuổi theo Chương trình giáo dục mầm non.
> - Thông tin và kết quả theo dõi khác cần thiết phục vụ hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> Các nội dung này được tích hợp, quản lý thống nhất trong hồ sơ theo dõi trẻ em; không mặc nhiên yêu cầu lập thêm từng loại sổ riêng.
>
> ### 3. Sổ theo dõi tài sản, thiết bị, đồ chơi của nhóm trẻ, lớp mẫu giáo
>
> - Sổ theo dõi tài sản, thiết bị, đồ dùng, đồ chơi của nhóm/lớp.
> - Nội dung theo dõi việc tiếp nhận, sử dụng, bảo quản, biến động và bàn giao tài sản, thiết bị, đồ dùng, đồ chơi của nhóm/lớp.
>
> ## IV. HỒ SƠ, TÀI LIỆU CẦN QUẢN LÝ RIÊNG HOẶC LƯU THEO NHU CẦU THỰC TẾ
>
> Các hồ sơ, tài liệu dưới đây có trong danh mục ban đầu của nhà trường nhưng không được Điều 21 quy định thành những nhóm hồ sơ chuyên môn bắt buộc riêng.
>
> **1. Hồ sơ tổ chức Đảng, đoàn thể**
>
> - Hồ sơ Chi bộ.
> - Hồ sơ Chi đoàn.
>
> Các hồ sơ này được quản lý theo quy định của tổ chức Đảng, đoàn thể có liên quan.
>
> **2. Hồ sơ Hội đồng trường đã hình thành trước đây**
>
> - Quyết định thành lập Hội đồng trường.
> - Nghị quyết, kế hoạch và các văn bản hoạt động của Hội đồng trường.
> - Biên bản kiểm tra, giám sát của Hội đồng trường.
> - Sổ biên bản họp Hội đồng trường.
>
> Đối với Trường Mầm non An Bình là trường công lập, những hồ sơ đã hình thành trước khi quy định về Hội đồng trường công lập bị bãi bỏ được lưu trữ theo quy định; không xem là bộ hồ sơ Hội đồng trường phải lập mới trong năm học 2026–2027.
>
> **3. Tài liệu, học phẩm và sản phẩm học tập của trẻ**
>
> - Sổ Bé ngoan, sổ Bé ngoan điện tử, sổ liên lạc điện tử (nếu sử dụng).
> - Các loại vở, học phẩm dành cho trẻ như: Bé tập tạo hình, Bé làm quen với toán, Bé làm quen với chữ viết; vở, tài liệu phục vụ hoạt động làm quen với tiếng Anh (nếu có và được sử dụng đúng quy định).
> - Hồ sơ hoặc tập lưu sản phẩm hoạt động của trẻ.
>
> Đây là tài liệu, học phẩm hoặc minh chứng phục vụ hoạt động giáo dục và phối hợp với gia đình, không phải các loại sổ bắt buộc bổ sung đối với giáo viên theo Điều 21.
>
> **4. Tài liệu ghi chép, bồi dưỡng của giáo viên**
>
> - Sổ ghi chép nội dung họp Hội đồng, sinh hoạt chuyên môn, bồi dưỡng thường xuyên.
> - Sổ dự giờ của giáo viên.
>
> Giáo viên được sử dụng hình thức ghi chép, lưu tài liệu phù hợp để phục vụ công việc và bồi dưỡng chuyên môn. Không quy định các tài liệu này thành sổ chuyên môn bắt buộc độc lập chỉ căn cứ vào Điều 21.
>
> ## V. QUY ĐỊNH THỰC HIỆN
>
> 1. Danh mục hồ sơ tại các mục I, II, III được phân nhóm theo Điều 21 Điều lệ trường mầm non. Các hồ sơ, sổ sách chi tiết trong từng nhóm là tài liệu phục vụ quản lý, triển khai nhiệm vụ của nhà trường theo chức năng và quy định chuyên ngành có liên quan.
>
> 2. Cán bộ quản lý, tổ chuyên môn, tổ văn phòng, giáo viên và nhân viên thực hiện, quản lý, cập nhật hồ sơ theo nhiệm vụ được phân công; bảo đảm chính xác, đầy đủ, khoa học và phù hợp thực tế.
>
> 3. Việc sử dụng hồ sơ điện tử thay thế hồ sơ giấy được thực hiện theo lộ trình, điều kiện và hướng dẫn của cơ quan quản lý giáo dục có thẩm quyền, bảo đảm tính hợp pháp, an toàn và bảo mật thông tin.
>
> 4. Nhà trường không yêu cầu giáo viên lập thêm hồ sơ, sổ sách chuyên môn ngoài danh mục quy định chỉ nhằm phục vụ kiểm tra hình thức; hạn chế trùng lặp trong ghi chép và lưu trữ.
>
> 5. Các hồ sơ nghiệp vụ về tài chính, kế toán, y tế trường học, an toàn thực phẩm, văn thư, lưu trữ, lao động và các lĩnh vực chuyên ngành khác tiếp tục thực hiện theo quy định pháp luật tương ứng.
>
> 6. Trong quá trình thực hiện, nếu có thay đổi về quy định hoặc hướng dẫn của cơ quan có thẩm quyền, nhà trường tiến hành rà soát, cập nhật danh mục và hướng dẫn thực hiện cho phù hợp.

## 3. Những điều chỉnh quan trọng so với danh mục cũ

- **Hồ sơ phổ cập giáo dục:** Tách khỏi hồ sơ quản lý trẻ em để thành nhóm riêng theo điểm d khoản 1 Điều 21.
- **Hồ sơ bán trú:** Phân theo tính chất công việc. Hồ sơ thực đơn, dinh dưỡng, kiểm thực thuộc quản lý hoạt động nuôi dưỡng; chứng từ thu, chi tiền ăn thuộc quản lý tài chính.
- **Hồ sơ y tế:** Hồ sơ sức khỏe trẻ thuộc quản lý trẻ em; hồ sơ sức khỏe nhân viên thuộc quản lý nhân sự; kế hoạch và hoạt động y tế thuộc quản lý chăm sóc, nuôi dưỡng.
- **Hồ sơ giáo viên:** Chỉ xác định 3 loại theo Điều 21, không biến sổ dự giờ, sổ ghi chép họp, sổ bồi dưỡng thành các loại hồ sơ chuyên môn bắt buộc độc lập.
- **Hồ sơ Hội đồng trường:** Điều lệ sửa đổi năm 2026 xác định Hội đồng trường đối với trường dân lập, tư thục; quy định về Hội đồng trường công lập đã bị bãi bỏ. [Thông tư số 51/2026/TT\-BGDĐT sửa đổi, bổ sung một số điều của Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy chế tổ chức, hoạt động nhóm trẻ độc lập, lớp mẫu giáo độc lập, lớp mầm non độc lập loại hình dân lập và tư thục ban hành kèm theo Thông tư số 49/2021/TT\-BGDĐT ngày 31 tháng 12 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tạo; quy định tiêu chuẩn, quy trình biên soạn, chỉnh sửa Chương trình giáo dục mầm non, tổ chức và hoạt động của Hội đồng quốc gia thẩm định Chương trình giáo dục mầm non ban hành kèm theo Thông tư số 49/2020/TT\-BGDĐT ngày 31 tháng 12 năm 2020 của Bộ trưởng Bộ Giáo dục và Đào tạo\.](<https://congbao.chinhphu.vn/van-ban/thong-tu-so-51-2026-tt-bgddt-470009.htm>); [Văn bản hợp nhất 09/2026/VBHN\-TT\-BGDĐT Thông tư Điều lệ trường mầm non \| Cổng Luật Việt](<https://congluatviet.vn/van-ban/van-ban-hop-nhat-09-2026-vbhn-tt-bgddt-thong-tu-dieu-le-truong-mam-non-09-2026-vbhn-tt-bgddt>)

**Khuyến nghị để ban hành:** Bạn có thể sử dụng nội dung trên làm **Phụ lục 01** của Quy chế chuyên môn. Khi hoàn thiện, nên giao Phó Hiệu trưởng phụ trách chuyên môn đối chiếu với hồ sơ thực tế của các bộ phận, nhất là bán trú, y tế và tài chính, để thống nhất nơi lưu trữ và người chịu trách nhiệm, tránh một tài liệu bị yêu cầu lập nhiều lần.

---

ASSISTANT

---

ASSISTANT

Có một điểm cần xử lý trong danh mục cũ: **hồ sơ Hội đồng trường**. Theo Điều lệ đã sửa đổi năm 2026, quy định về Hội đồng trường công lập đã được bãi bỏ. Vì vậy, với Trường Mầm non An Bình, mình sẽ đưa hồ sơ Hội đồng trường đã có vào diện lưu trữ lịch sử, thay vì tiếp tục liệt kê như một bộ hồ sơ phải lập trong năm học 2026–2027. Các hồ sơ bán trú, y tế và tài chính vẫn được giữ đầy đủ, nhưng đặt vào nhóm quản lý phù hợp.

---

ASSISTANT

Dưới đây là bản sắp xếp lại theo đúng tên các nhóm hồ sơ tại Điều 21. Mình giữ các tài liệu bạn đã liệt kê và chuyển về nhóm tương ứng, đồng thời phân biệt hồ sơ cấp trường, cấp tổ và của giáo viên.

<WritingBlock id="83924" variant="document">**UBND PHƯỜNG AN BÌNH**  
**TRƯỜNG MẦM NON AN BÌNH**

**PHỤ LỤC 01**  
**DANH MỤC HỒ SƠ, TÀI LIỆU**  
**Năm học 2026–2027**

*(Kèm theo Quy chế chuyên môn năm học 2026–2027 của Trường Mầm non An Bình)*

*Căn cứ phân loại: Điều 21 Điều lệ trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT ngày 31/12/2020, được cập nhật theo các quy định sửa đổi, bổ sung hiện hành.*

## I. ĐỐI VỚI NHÀ TRƯỜNG

### 1. Hồ sơ quản lý trẻ em

**1.1. Hồ sơ tuyển sinh, tiếp nhận và quản lý trẻ**

- Sổ đăng bộ trẻ em (lập nhiều năm/quyển).
- Hồ sơ trẻ em: bản sao giấy khai sinh, đơn xin nhập học, bản sao bảo hiểm y tế, thông tin tiêm chủng và các giấy tờ liên quan (lưu theo từng nhóm/lớp, độ tuổi).
- Danh sách trẻ theo nhóm/lớp.
- Hồ sơ Hội đồng tuyển sinh.
- Hồ sơ quản lý trẻ khuyết tật học hòa nhập.

**1.2. Hồ sơ theo dõi sức khỏe và sự phát triển của trẻ**

- Hồ sơ theo dõi sức khỏe trẻ em toàn trường; phân loại tình trạng sức khỏe và các bệnh lý cần quan tâm để phối hợp tổ chức khám chuyên khoa (nếu có).
- Sổ theo dõi sức khỏe từng trẻ (bằng giấy hoặc trên hệ thống quản lý hợp pháp).
- Sổ tổng hợp theo dõi sức khỏe trẻ em toàn trường.
- Hồ sơ tổng hợp kết quả đánh giá sự phát triển của trẻ cuối năm học.

### 2. Hồ sơ quản lý cán bộ, giáo viên, nhân viên

**2.1. Hồ sơ tổ chức, quản lý và sử dụng đội ngũ**

- Hồ sơ cá nhân của viên chức theo quy định về quản lý hồ sơ viên chức.
- Sổ đăng bộ cán bộ, giáo viên, nhân viên.
- Hồ sơ quy hoạch, bổ nhiệm cán bộ quản lý.
- Hồ sơ bổ nhiệm tổ trưởng, tổ phó và phân công nhiệm vụ cán bộ, giáo viên, nhân viên.
- Kế hoạch đào tạo, bồi dưỡng đội ngũ cán bộ quản lý, giáo viên, nhân viên.
- Kế hoạch giao biên chế và các văn bản có liên quan.

**2.2. Hồ sơ đánh giá, bồi dưỡng đội ngũ**

- Hồ sơ đánh giá theo Chuẩn hiệu trưởng, phó hiệu trưởng.
- Hồ sơ đánh giá theo Chuẩn nghề nghiệp giáo viên mầm non.
- Hồ sơ đánh giá và bồi dưỡng chuyên môn, nghiệp vụ của đội ngũ theo quy định.

**2.3. Hồ sơ lao động, tiền lương và chế độ chính sách**

- Kế hoạch, báo cáo công tác lao động, tiền lương hằng quý, hằng năm.
- Hồ sơ hợp đồng lao động.
- Hồ sơ bảo hiểm xã hội.
- Hồ sơ nâng lương hằng năm.
- Hồ sơ thâm niên hằng năm.
- Hồ sơ Hội đồng xét nâng lương.
- Hồ sơ theo dõi sức khỏe cán bộ, giáo viên, nhân viên trong nhà trường.
- Hồ sơ sức khỏe nhân viên nấu ăn.

### 3. Kế hoạch phát triển nhà trường và kế hoạch nuôi dưỡng, chăm sóc, giáo dục theo năm học

**3.1. Hồ sơ kế hoạch phát triển nhà trường**

- Kế hoạch chiến lược phát triển nhà trường.
- Kế hoạch thực hiện nhiệm vụ năm học.
- Kế hoạch nuôi dưỡng, chăm sóc, giáo dục năm học.
- Sổ kế hoạch hoặc tập hồ sơ kế hoạch quản lý, chỉ đạo của nhà trường.

**3.2. Hồ sơ quản lý, chỉ đạo chuyên môn**

- Kế hoạch phát triển Chương trình giáo dục mầm non của nhà trường.
- Hồ sơ kiểm tra nội bộ trường học.
- Hồ sơ bồi dưỡng thường xuyên cấp trường.
- Hồ sơ tổ chức các chuyên đề chuyên môn.
- Hồ sơ tổ chức ngày hội, ngày lễ, tham quan, học tập và các hoạt động giáo dục khác (nếu tổ chức).
- Hồ sơ Hội đồng tự đánh giá.
- Hồ sơ Hội đồng sáng kiến, nghiên cứu khoa học sư phạm ứng dụng.
- Hồ sơ tổ chức hội thi giáo viên dạy giỏi, cấp dưỡng giỏi (nếu có).
- Sổ dự giờ của cán bộ quản lý.
- Sổ hoặc bảng tổng hợp theo dõi chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ.

**3.3. Hồ sơ quản lý công tác bán trú**

- Kế hoạch công tác bán trú.
- Quyết định thành lập Ban chỉ đạo công tác bán trú, kèm bảng phân công nhiệm vụ.
- Bảng phân công nhiệm vụ nhân viên nấu ăn.
- Sổ thực đơn.
- Hợp đồng mua bán, cung ứng thực phẩm.
- Sổ thiết lập dưỡng chất, tính khẩu phần dinh dưỡng cho trẻ.
- Hồ sơ xét nghiệm chất lượng nguồn nước.
- Bản cam kết bảo đảm điều kiện cơ sở vật chất và an toàn thực phẩm.
- Sổ giao nhận thực phẩm giữa đơn vị cung ứng và nhà trường.
- Sổ kiểm thực ba bước và sổ lưu mẫu thức ăn.
- Sổ xuất, nhập kho thực phẩm.
- Sổ tổng hợp báo ăn.
- Sổ tính ăn hằng ngày.

*Các hồ sơ về thu, thanh toán tiền ăn, sổ quỹ tiền mặt và chứng từ quyết toán được xếp tại mục 5 – Hồ sơ quản lý tài sản, tài chính.*

**3.4. Hồ sơ quản lý công tác y tế trường học**

- Các văn bản chỉ đạo về công tác y tế trường học.
- Quyết định thành lập Ban chăm sóc sức khỏe học sinh.
- Kế hoạch hoạt động y tế trường học.
- Hợp đồng chăm sóc, kiểm tra sức khỏe ban đầu cho trẻ (nếu có).
- Kế hoạch tuyên truyền chăm sóc sức khỏe, phòng chống dịch bệnh.
- Kế hoạch phòng, chống tai nạn thương tích cho trẻ.
- Sổ theo dõi cấp phát thuốc y tế.
- Biên bản kiểm tra y tế trường học.
- Hồ sơ tuyên truyền, phòng chống dịch bệnh.
- Hồ sơ tổ chức các hoạt động chăm sóc và bảo vệ sức khỏe trẻ theo kế hoạch.

*Hồ sơ sức khỏe cá nhân của trẻ được quản lý tại mục 1; hồ sơ sức khỏe nhân viên được quản lý tại mục 2.*

### 4. Hồ sơ phổ cập giáo dục

- Hồ sơ phổ cập giáo dục mầm non cho trẻ em 5 tuổi.
- Hồ sơ phổ cập giáo dục mầm non cho trẻ em từ 3 đến 5 tuổi theo lộ trình và hướng dẫn triển khai của cấp có thẩm quyền.
- Các biểu mẫu điều tra, thống kê, tổng hợp số liệu, cập nhật dữ liệu và minh chứng phục vụ công tác phổ cập giáo dục theo quy định.

### 5. Hồ sơ quản lý tài sản, tài chính

**5.1. Hồ sơ quản lý cơ sở vật chất**

- Quyết định giao đất.
- Biên bản bàn giao cơ sở vật chất giữa nhà trường với các cơ quan, đơn vị hoặc địa phương.
- Giấy chứng nhận quyền sử dụng đất và tài sản gắn liền với đất của nhà trường.
- Sơ đồ tổng thể nhà trường.
- Hồ sơ thiết kế, xây dựng trường.

**5.2. Hồ sơ quản lý tài sản**

- Sổ theo dõi tài sản, thiết bị, đồ dùng, đồ chơi của nhà trường.
- Sổ theo dõi hoặc biên bản giao nhận tài sản, thiết bị, đồ dùng, đồ chơi giữa nhà trường với giáo viên phụ trách nhóm/lớp.
- Biên bản kiểm kê tài sản, thanh lý tài sản hằng năm.
- Kế hoạch thay thế, sửa chữa, bổ sung, nâng cấp thiết bị, đồ dùng, đồ chơi hằng năm.
- Hồ sơ lựa chọn đồ chơi, học liệu sử dụng trong cơ sở giáo dục mầm non theo quy định.

**5.3. Hồ sơ quản lý tài chính**

- Hệ thống văn bản quy định hiện hành về quản lý tài chính có liên quan đến hoạt động thu, chi của nhà trường.
- Quy chế chi tiêu nội bộ.
- Dự toán tài chính hằng năm.
- Chứng từ thu, chi và quyết toán tài chính.
- Báo cáo tài chính, báo cáo quyết toán; báo cáo kết quả kiểm tra, thanh tra, kiểm toán của cơ quan có thẩm quyền (nếu có).
- Biên bản, nghị quyết Hội nghị viên chức và người lao động có nội dung công khai tài chính.

**5.4. Hồ sơ tài chính phục vụ công tác bán trú**

- Sổ theo dõi thu và thanh toán tiền ăn.
- Sổ quỹ tiền mặt.
- Chứng từ thu, chi và quyết toán tiền ăn.
- Các hồ sơ, chứng từ tài chính bán trú liên quan theo quy định.

### 6. Hồ sơ quản lý các văn bản

**6.1. Hồ sơ văn thư, lưu trữ**

- Sổ theo dõi công văn đi, đến.
- Hồ sơ, cặp lưu trữ văn bản đi, đến.
- Sổ theo dõi văn bản nội bộ.
- Quyết định thành lập trường và các văn bản pháp lý về tổ chức, hoạt động của nhà trường.

**6.2. Hồ sơ tổ chức, quản lý và điều hành nhà trường**

- Sổ biên bản họp Hội đồng sư phạm nhà trường.
- Hồ sơ Hội đồng Thi đua - Khen thưởng, kỷ luật.
- Hồ sơ thực hiện quy chế dân chủ.
- Hồ sơ tổ chức Hội nghị viên chức và người lao động.
- Hồ sơ Ban đại diện cha mẹ trẻ.
- Hồ sơ phổ biến, giáo dục pháp luật.
- Hồ sơ bảo đảm an ninh, trật tự.
- Hồ sơ phòng cháy, chữa cháy.
- Các quyết định, quy chế, quy định và văn bản chỉ đạo, điều hành khác của nhà trường.

## II. ĐỐI VỚI TỔ CHUYÊN MÔN, TỔ VĂN PHÒNG

### 1. Kế hoạch hoạt động

**1.1. Đối với tổ chuyên môn**

- Kế hoạch hoạt động của tổ chuyên môn theo năm học, tháng, tuần.
- Hồ sơ, tài liệu triển khai các chuyên đề của tổ.
- Tài liệu theo dõi, tổng hợp chất lượng nuôi dưỡng, chăm sóc, giáo dục trẻ của tổ.
- Hồ sơ, tài liệu bồi dưỡng thường xuyên liên quan đến hoạt động của tổ.
- Hồ sơ lưu các văn bản, tài liệu liên quan đến hoạt động của tổ hằng năm.

**1.2. Đối với tổ văn phòng**

- Kế hoạch hoạt động của tổ văn phòng theo năm học, tháng, tuần.
- Hồ sơ lưu các văn bản, tài liệu liên quan đến hoạt động của tổ hằng năm.

*Các tài liệu chi tiết nêu trên là nội dung thực hiện hoặc minh chứng thuộc kế hoạch hoạt động của tổ, không phải những loại sổ bắt buộc riêng được Điều 21 liệt kê.*

### 2. Sổ ghi chép nội dung sinh hoạt chuyên môn của tổ

**2.1. Đối với tổ chuyên môn**

- Sổ ghi chép nội dung sinh hoạt chuyên môn của tổ (có thể thể hiện dưới hình thức biên bản sinh hoạt tổ).

**2.2. Đối với tổ văn phòng**

- Sổ ghi chép nội dung sinh hoạt của tổ văn phòng, phù hợp với chức năng và nhiệm vụ được giao.

## III. ĐỐI VỚI GIÁO VIÊN

### 1. Kế hoạch nuôi dưỡng, chăm sóc, giáo dục của nhóm trẻ, lớp mẫu giáo

- Kế hoạch nuôi dưỡng, chăm sóc, giáo dục trẻ của nhóm/lớp.
- Kế hoạch giáo dục theo năm học, tháng, tuần và kế hoạch tổ chức các hoạt động theo hướng dẫn chuyên môn của nhà trường.

Các nội dung kế hoạch được tổ chức, tích hợp khoa học, phù hợp Chương trình giáo dục mầm non và điều kiện thực tế của nhóm/lớp.

### 2. Sổ theo dõi trẻ em

- Sổ theo dõi trẻ đến nhóm, lớp mầm non.
- Nội dung theo dõi, đánh giá sự phát triển của trẻ cuối giai đoạn, cuối độ tuổi theo Chương trình giáo dục mầm non.
- Thông tin và kết quả theo dõi khác cần thiết phục vụ hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ.

Các nội dung này được tích hợp, quản lý thống nhất trong hồ sơ theo dõi trẻ em; không mặc nhiên yêu cầu lập thêm từng loại sổ riêng.

### 3. Sổ theo dõi tài sản, thiết bị, đồ chơi của nhóm trẻ, lớp mẫu giáo

- Sổ theo dõi tài sản, thiết bị, đồ dùng, đồ chơi của nhóm/lớp.
- Nội dung theo dõi việc tiếp nhận, sử dụng, bảo quản, biến động và bàn giao tài sản, thiết bị, đồ dùng, đồ chơi của nhóm/lớp.

## IV. HỒ SƠ, TÀI LIỆU CẦN QUẢN LÝ RIÊNG HOẶC LƯU THEO NHU CẦU THỰC TẾ

Các hồ sơ, tài liệu dưới đây có trong danh mục ban đầu của nhà trường nhưng không được Điều 21 quy định thành những nhóm hồ sơ chuyên môn bắt buộc riêng.

**1. Hồ sơ tổ chức Đảng, đoàn thể**

- Hồ sơ Chi bộ.
- Hồ sơ Chi đoàn.

Các hồ sơ này được quản lý theo quy định của tổ chức Đảng, đoàn thể có liên quan.

**2. Hồ sơ Hội đồng trường đã hình thành trước đây**

- Quyết định thành lập Hội đồng trường.
- Nghị quyết, kế hoạch và các văn bản hoạt động của Hội đồng trường.
- Biên bản kiểm tra, giám sát của Hội đồng trường.
- Sổ biên bản họp Hội đồng trường.

Đối với Trường Mầm non An Bình là trường công lập, những hồ sơ đã hình thành trước khi quy định về Hội đồng trường công lập bị bãi bỏ được lưu trữ theo quy định; không xem là bộ hồ sơ Hội đồng trường phải lập mới trong năm học 2026–2027.

**3. Tài liệu, học phẩm và sản phẩm học tập của trẻ**

- Sổ Bé ngoan, sổ Bé ngoan điện tử, sổ liên lạc điện tử (nếu sử dụng).
- Các loại vở, học phẩm dành cho trẻ như: Bé tập tạo hình, Bé làm quen với toán, Bé làm quen với chữ viết; vở, tài liệu phục vụ hoạt động làm quen với tiếng Anh (nếu có và được sử dụng đúng quy định).
- Hồ sơ hoặc tập lưu sản phẩm hoạt động của trẻ.

Đây là tài liệu, học phẩm hoặc minh chứng phục vụ hoạt động giáo dục và phối hợp với gia đình, không phải các loại sổ bắt buộc bổ sung đối với giáo viên theo Điều 21.

**4. Tài liệu ghi chép, bồi dưỡng của giáo viên**

- Sổ ghi chép nội dung họp Hội đồng, sinh hoạt chuyên môn, bồi dưỡng thường xuyên.
- Sổ dự giờ của giáo viên.

Giáo viên được sử dụng hình thức ghi chép, lưu tài liệu phù hợp để phục vụ công việc và bồi dưỡng chuyên môn. Không quy định các tài liệu này thành sổ chuyên môn bắt buộc độc lập chỉ căn cứ vào Điều 21.

## V. QUY ĐỊNH THỰC HIỆN

1. Danh mục hồ sơ tại các mục I, II, III được phân nhóm theo Điều 21 Điều lệ trường mầm non. Các hồ sơ, sổ sách chi tiết trong từng nhóm là tài liệu phục vụ quản lý, triển khai nhiệm vụ của nhà trường theo chức năng và quy định chuyên ngành có liên quan.

2. Cán bộ quản lý, tổ chuyên môn, tổ văn phòng, giáo viên và nhân viên thực hiện, quản lý, cập nhật hồ sơ theo nhiệm vụ được phân công; bảo đảm chính xác, đầy đủ, khoa học và phù hợp thực tế.

3. Việc sử dụng hồ sơ điện tử thay thế hồ sơ giấy được thực hiện theo lộ trình, điều kiện và hướng dẫn của cơ quan quản lý giáo dục có thẩm quyền, bảo đảm tính hợp pháp, an toàn và bảo mật thông tin.

4. Nhà trường không yêu cầu giáo viên lập thêm hồ sơ, sổ sách chuyên môn ngoài danh mục quy định chỉ nhằm phục vụ kiểm tra hình thức; hạn chế trùng lặp trong ghi chép và lưu trữ.

5. Các hồ sơ nghiệp vụ về tài chính, kế toán, y tế trường học, an toàn thực phẩm, văn thư, lưu trữ, lao động và các lĩnh vực chuyên ngành khác tiếp tục thực hiện theo quy định pháp luật tương ứng.

6. Trong quá trình thực hiện, nếu có thay đổi về quy định hoặc hướng dẫn của cơ quan có thẩm quyền, nhà trường tiến hành rà soát, cập nhật danh mục và hướng dẫn thực hiện cho phù hợp.</WritingBlock>

## 3. Những điều chỉnh quan trọng so với danh mục cũ

- **Hồ sơ phổ cập giáo dục:** Tách khỏi hồ sơ quản lý trẻ em để thành nhóm riêng theo điểm d khoản 1 Điều 21.
- **Hồ sơ bán trú:** Phân theo tính chất công việc. Hồ sơ thực đơn, dinh dưỡng, kiểm thực thuộc quản lý hoạt động nuôi dưỡng; chứng từ thu, chi tiền ăn thuộc quản lý tài chính.
- **Hồ sơ y tế:** Hồ sơ sức khỏe trẻ thuộc quản lý trẻ em; hồ sơ sức khỏe nhân viên thuộc quản lý nhân sự; kế hoạch và hoạt động y tế thuộc quản lý chăm sóc, nuôi dưỡng.
- **Hồ sơ giáo viên:** Chỉ xác định 3 loại theo Điều 21, không biến sổ dự giờ, sổ ghi chép họp, sổ bồi dưỡng thành các loại hồ sơ chuyên môn bắt buộc độc lập.
- **Hồ sơ Hội đồng trường:** Điều lệ sửa đổi năm 2026 xác định Hội đồng trường đối với trường dân lập, tư thục; quy định về Hội đồng trường công lập đã bị bãi bỏ. [Source unavailable: turn368977search4]; [Source unavailable: turn180821view3]

**Khuyến nghị để ban hành:** Bạn có thể sử dụng nội dung trên làm **Phụ lục 01** của Quy chế chuyên môn. Khi hoàn thiện, nên giao Phó Hiệu trưởng phụ trách chuyên môn đối chiếu với hồ sơ thực tế của các bộ phận, nhất là bán trú, y tế và tài chính, để thống nhất nơi lưu trữ và người chịu trách nhiệm, tránh một tài liệu bị yêu cầu lập nhiều lần.

---

