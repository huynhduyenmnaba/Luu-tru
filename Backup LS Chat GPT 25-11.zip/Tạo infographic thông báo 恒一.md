USER

[@Chuyên gia thiết kế bảng biểu](plugin://gpt-d75fc9bf5c59295645b8fc906e41023b@openai-curated-remote) dựa vào thư ngỏ này bạn giúp tôi tạo bảng inrafic để thông báo phụ huynh việc ọc ngoại khóa tiếng anh . hình ảnh đẹp, tươi sáng, bắt mắt thu hút người xem

---

ASSISTANT

Tôi sẽ dùng hướng dẫn của plugin Chuyên gia thiết kế bảng biểu để thiết kế infographic thông báo học tiếng Anh ngoại khóa, bám sát thư ngỏ và trình bày tươi sáng, dễ đọc cho phụ huynh.

---

ASSISTANT

Thư ngỏ có một điểm chưa thống nhất: học phí tiêu chuẩn niêm yết 120.000 đồng, giảm 20.000 đồng nhưng mức thực nộp lại ghi 950.000 đồng/tháng/trẻ. Tôi sẽ ghi rõ mức này cần xác nhận trên infographic để tránh thông báo sai cho phụ huynh; các thông tin còn lại giữ theo thư ngỏ.

---

ASSISTANT

---

ASSISTANT

Đã tạo infographic tươi sáng, có hình cô giáo và các bé, chia rõ chương trình học, cách tổ chức, học phí và quyền lợi.

**Lưu ý trước khi gửi phụ huynh:** cần xác nhận lại học phí thực nộp của chương trình tiêu chuẩn vì thư ngỏ ghi số tiền chưa thống nhất.

---

USER

học phí: 95.000 đồng/tháng.  Hỗ trợ:  Cận nghèo: Giảm 50%, Hộ nghèo: Giảm100%; Trẻ Mồ côi: Giảm: 100%. Hình bên cạnh là minh họa cách sắp xếp hình và bố cục cho đẹp dễ thương

---

ASSISTANT

Tôi sẽ cập nhật học phí **95.000 đồng/tháng**, thêm mức giảm cho trẻ thuộc hộ cận nghèo, hộ nghèo và trẻ mồ côi, đồng thời chỉnh bố cục cho dễ thương, thoáng và dễ đọc.

---

ASSISTANT

Tôi đã bố trí thành bốn ô thông tin theo phong cách ảnh mẫu, với học phí và mức giảm được làm nổi bật để phụ huynh dễ nhận biết.

---

ASSISTANT

---

ASSISTANT

Đã chỉnh bố cục tươi sáng, dễ thương theo ảnh mẫu và cập nhật:

- **Học phí: 95.000 đồng/tháng/trẻ.**
- Hộ cận nghèo: **giảm 50%**.
- Hộ nghèo và trẻ mồ côi: **giảm 100%**.

---

USER

add tên Công ty TNHH Giáo dục Kiến tạo Anh Việt. Thời lượng Thời lượng: Thực hiện 08 hoạt động/tháng (02 hoạt động/tuần) bò phần tổ chức lớp học ra'

---

ASSISTANT

Tôi sẽ bỏ mục “Tổ chức lớp học”, chỉ giữ thời lượng **08 hoạt động/tháng (02 hoạt động/tuần)** và làm rõ tên **Công ty TNHH Giáo dục Kiến tạo Anh Việt** trên infographic.

---

ASSISTANT

---

ASSISTANT

Đã bổ sung tên **Công ty TNHH Giáo dục Kiến tạo Anh Việt**, chỉnh thời lượng thành **08 hoạt động/tháng (02 hoạt động/tuần)** và bỏ mục **Tổ chức lớp học**. Học phí và chính sách hỗ trợ được giữ nguyên.

---

USER

bỏ dòng chữ này

---

ASSISTANT

Tôi sẽ xem dòng chữ chị đánh dấu và xóa khỏi infographic.

---

ASSISTANT

---

ASSISTANT

Đã bỏ dòng tên công ty ở phía trên theo ảnh chị gửi.

---

USER

chỉnh lại thời gian 30 phút

---

ASSISTANT

Tôi sẽ chỉnh thời lượng thành **30 phút/hoạt động** trên infographic.

---

ASSISTANT

---

ASSISTANT

Đã chỉnh thành **30 phút/hoạt động**.

---

USER

chỉnh số tiền lại 100.000 nhé

---

ASSISTANT

Tôi sẽ chỉnh học phí thành **100.000 đồng/tháng/trẻ**.

---

ASSISTANT

---

ASSISTANT

Đã chỉnh học phí thành **100.000 đồng/tháng/trẻ**.

---

