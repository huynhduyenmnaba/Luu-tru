USER

với vai trò hiệu trưởng bạn giúp tôi cụ thể các mức điểm ở phần KPI nhân viên (tương tự giáo viên) để hoàn chỉnh cách tính

---

ASSISTANT

Tôi sẽ giữ nguyên cơ cấu 30 điểm tiêu chí chung và 70 điểm theo vị trí trong dự thảo, rồi bổ sung mức điểm cụ thể cho cả 7 nhóm nhân viên. Tôi cũng sẽ thống nhất cách tính tỷ lệ hoàn thành, cách xử lý sai sót và những trường hợp trong tháng không phát sinh nhiệm vụ, để các tổ có thể chấm điểm theo cùng một nguyên tắc.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 HOÀN THIỆN THANG ĐIỂM KPI NHÂN VIÊN – TRƯỜNG MẦM NON AN BÌNH

Áp dụng cho năm học 2026–2027

Tôi đã rà soát Phụ lục II trong dự thảo Quy chế đánh giá, xếp loại chất lượng viên chức của Trường Mầm non An Bình.

**Phần A – Tiêu chí chung (30 điểm)** đã có các mức điểm cụ thể. Tuy nhiên, **phần B – KPI theo vị trí nhân viên (70 điểm)** mới xác định tiêu chí và điểm tối đa, chưa có quy định mức điểm tương ứng với kết quả thực hiện.

Để hoàn thiện, tôi đề xuất bổ sung mức chấm chi tiết cho cả 7 vị trí: cấp dưỡng, y tế, kế toán, văn thư, thủ quỹ, bảo vệ và phục vụ – vệ sinh.

## 🎯 1. Thống nhất nguyên tắc chấm điểm

Giữ nguyên cơ cấu điểm của nhà trường:

| Nhóm tiêu chí | Điểm tối đa |
|--------|--------|
| A. Tiêu chí chung | 30 |
| B1. Số lượng, khối lượng công việc | 20 |
| B2. Chất lượng, hiệu quả công việc | 30 |
| B3. Tiến độ thực hiện | 10 |
| B4. Phối hợp, phục vụ, cải tiến | 10 |
| **Tổng cộng** | **100** |

Mỗi tiêu chí được chia thành **4 mức điểm rõ ràng**, tương tự bảng KPI giáo viên, bảo đảm dễ tự đánh giá, dễ kiểm tra và có căn cứ xác định điểm.

| Điểm tối đa | Mức 1 | Mức 2 | Mức 3 | Mức 4 |
|--------|--------|--------|--------|--------|
| 12 điểm | 12 | 9 | 5 | 0 |
| 10 điểm | 10 | 8 | 4 | 0 |
| 8 điểm | 8 | 6 | 3 | 0 |
| 6 điểm | 6 | 4 | 2 | 0 |
| 4 điểm | 4 | 3 | 1 | 0 |

Đối với khối lượng công việc, có thể quy đổi theo tỷ lệ hoàn thành 100%; từ 90% đến dưới 100%; từ 70% đến dưới 90%; dưới 70%. Đối với chất lượng, an toàn và tiến độ, cần đánh giá thêm tính chất, mức độ, hậu quả của sai sót, không chỉ dựa vào tỷ lệ.

Đây là **thang điểm chi tiết do nhà trường đề xuất**, không phải mức điểm cố định được Nghị định số 233/2026/NĐ-CP quy định cho từng nhiệm vụ. Nghị định giao việc xác định điểm từng tiêu chí theo quy chế đánh giá do người đứng đầu đơn vị ban hành. [Các mức xếp loại chất lượng viên chức](<https://xaydungchinhsach.chinhphu.vn/cac-muc-xep-loai-chat-luong-vien-chuc-119260701155446369.htm>)

## 📋 2. Nội dung cụ thể bổ sung vào Phụ lục II

Dưới đây là **63 nội dung chấm điểm đề xuất** để điền trực tiếp vào cột “Quy định mức điểm” trong các bảng KPI nhân viên của nhà trường. Các mã tiêu chí, nhiệm vụ và điểm tối đa được giữ theo bản dự thảo.

> **writing · document**
>
> # BỔ SUNG QUY ĐỊNH MỨC ĐIỂM KPI ĐỐI VỚI NHÂN VIÊN
> **Trường Mầm non An Bình – Năm học 2026–2027**
>
> ## 1. NHÂN VIÊN NUÔI DƯỠNG, CẤP DƯỠNG – 70 ĐIỂM
>
> ### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B1.1 – 12 điểm** | **12 điểm:** Thực hiện 100% ca chế biến, bữa ăn và công đoạn được phân công. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% nhiệm vụ tiếp nhận, sơ chế, chia suất, thu dọn được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> ### B2. Chất lượng, hiệu quả công việc (30 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B2.1 – 12 điểm** | **12 điểm:** Thực hiện đúng quy trình vệ sinh, an toàn thực phẩm, không có sai sót. **9 điểm:** Có 1 sai sót nhẹ, chưa gây mất an toàn, khắc phục ngay. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về an toàn thực phẩm được xác minh. |
> | **B2.2 – 10 điểm** | **10 điểm:** Chế biến đúng thực đơn, định lượng, chia suất, kiểm thực, lưu mẫu theo trách nhiệm; không sai sót. **8 điểm:** Có 1 sai sót nhẹ được khắc phục trước khi phục vụ. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng ảnh hưởng an toàn bữa ăn được xác minh. |
> | **B2.3 – 8 điểm** | **8 điểm:** Vệ sinh, khử khuẩn, bảo quản thực phẩm, dụng cụ và thu gom rác đúng quy trình. **6 điểm:** Có 1 sai sót nhẹ, sửa ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh. |
>
> ### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B3.1 – 6 điểm** | **6 điểm:** 100% bữa ăn được chế biến, hoàn thành và bàn giao đúng giờ. **4 điểm:** Có 1 lần chậm nhẹ, được khắc phục, không ảnh hưởng giờ ăn của trẻ. **2 điểm:** Có 2 lần chậm nhẹ hoặc 1 lần chậm ảnh hưởng lịch ăn nhưng chưa gây hậu quả nghiêm trọng. **0 điểm:** Từ 3 lần chậm hoặc có sai sót chủ quan nghiêm trọng làm ảnh hưởng việc tổ chức bữa ăn. |
> | **B3.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung kiểm thực, lưu mẫu, giao nhận, ghi chép đúng thời hạn. **3 điểm:** Có 1 lần chậm ghi chép hành chính không quá 1 ngày, không ảnh hưởng quy trình bắt buộc. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày đối với hồ sơ thông thường. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện yêu cầu kiểm thực, lưu mẫu bắt buộc. |
>
> ### B4. Phối hợp, phục vụ và cải tiến (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% công việc phối hợp với giáo viên, y tế và tổ bếp. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện nhiệm vụ phối hợp hợp lệ không có lý do chính đáng. |
> | **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung cải tiến, tiết kiệm, giảm hao hụt, bảo quản tài sản theo phân công và có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ hợp lệ được giao. |
>
> **Tổng B1 + B2 + B3 + B4: 70 điểm.**
>
> ---
>
> ## 2. NHÂN VIÊN Y TẾ – 70 ĐIỂM
>
> ### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B1.1 – 12 điểm** | **12 điểm:** Hoàn thành 100% hoạt động theo dõi sức khỏe, cân đo, quản lý hồ sơ sức khỏe, chăm sóc ban đầu theo kế hoạch. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% nhiệm vụ truyền thông, kiểm tra vệ sinh, phòng chống dịch và tham mưu y tế được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> ### B2. Chất lượng, hiệu quả công việc (30 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B2.1 – 12 điểm** | **12 điểm:** Thực hiện đúng quy trình sơ cứu, chăm sóc ban đầu, ghi nhận và chuyển tuyến đúng thẩm quyền; không sai sót. **9 điểm:** Có 1 sai sót nhẹ về ghi chép hoặc thủ tục, không ảnh hưởng an toàn, khắc phục ngay. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về chuyên môn, an toàn sức khỏe được xác minh. |
> | **B2.2 – 10 điểm** | **10 điểm:** Theo dõi, phát hiện, báo cáo kịp thời dấu hiệu bất thường và nguy cơ dịch bệnh; thực hiện đầy đủ biện pháp phòng ngừa. **8 điểm:** Có 1 thiếu sót nhẹ trong theo dõi thường xuyên, khắc phục ngay. **4 điểm:** Có 2 thiếu sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc bỏ sót nguy cơ nghiêm trọng thuộc trách nhiệm được xác minh. |
> | **B2.3 – 8 điểm** | **8 điểm:** Quản lý thuốc, vật tư, hạn sử dụng và hồ sơ y tế đúng quy định. **6 điểm:** Có 1 sai sót nhẹ về ghi chép, sắp xếp, sửa ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về quản lý thuốc, vật tư hay bảo mật thông tin được xác minh. |
>
> ### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B3.1 – 6 điểm** | **6 điểm:** Tiếp nhận, báo cáo và xử lý 100% tình huống sức khỏe, an toàn khẩn cấp đúng thời điểm, quy trình; nếu không phát sinh tình huống, đáp ứng đầy đủ yêu cầu kiểm tra sẵn sàng ứng phó. **4 điểm:** Có 1 lần chậm báo cáo nội bộ không khẩn cấp, chưa gây ảnh hưởng, khắc phục ngay. **2 điểm:** Có 2 lần chậm báo cáo nội bộ không khẩn cấp. **0 điểm:** Có vi phạm nghiêm trọng về thời gian xử lý tình huống khẩn cấp được xác minh hoặc từ 3 lần chậm thuộc trách nhiệm. |
> | **B3.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% báo cáo, tổng hợp thông tin sức khỏe đúng hạn. **3 điểm:** Có 1 lần chậm không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện báo cáo bắt buộc. |
>
> ### B4. Phối hợp, phục vụ và cải tiến (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% yêu cầu phối hợp với giáo viên, cha mẹ trẻ, cấp dưỡng và cơ sở y tế; trao đổi đúng thẩm quyền. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc từ chối nhiệm vụ phối hợp hợp lệ không có lý do chính đáng. |
> | **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung hướng dẫn, tư vấn, truyền thông sức khỏe được giao, có sản phẩm và ghi nhận kết quả. **3 điểm:** Hoàn thành 100% nhưng chưa có minh chứng đánh giá hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ được giao. |
>
> **Tổng B1 + B2 + B3 + B4: 70 điểm.**
>
> ---
>
> ## 3. NHÂN VIÊN KẾ TOÁN – 70 ĐIỂM
>
> ### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B1.1 – 12 điểm** | **12 điểm:** Tiếp nhận, kiểm tra, xử lý 100% chứng từ, nghiệp vụ kế toán phát sinh hợp lệ thuộc trách nhiệm. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% bảng tổng hợp, báo cáo thu chi, dự toán, quyết toán, số liệu phải thực hiện trong tháng. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> ### B2. Chất lượng, hiệu quả công việc (30 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B2.1 – 12 điểm** | **12 điểm:** Hạch toán, kiểm tra chứng từ chính xác, hợp pháp, không sai sót. **9 điểm:** Có 1 sai sót kỹ thuật nhẹ, khắc phục trước khi hoàn tất nghiệp vụ. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về tài chính, kế toán được xác minh. |
> | **B2.2 – 10 điểm** | **10 điểm:** Đối chiếu đầy đủ, chính xác số liệu thu chi, công nợ, tạm ứng với các bộ phận. **8 điểm:** Có 1 sai lệch nhỏ, phát hiện và điều chỉnh đúng hạn. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc sai lệch nghiêm trọng chưa được xử lý do nguyên nhân chủ quan. |
> | **B2.3 – 8 điểm** | **8 điểm:** Lưu trữ, bảo mật, công khai và giải trình hồ sơ tài chính đúng quy định. **6 điểm:** Có 1 sai sót nhẹ về sắp xếp, lưu trữ, khắc phục ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về lưu trữ, bảo mật, công khai tài chính được xác minh. |
>
> ### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B3.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% chứng từ, báo cáo, mốc công việc tài chính đúng hạn. **4 điểm:** Có 1 lần chậm không quá 1 ngày đối với công việc nội bộ, không ảnh hưởng thời hạn pháp luật. **2 điểm:** Có 2 lần chậm nhẹ hoặc 1 lần chậm quá 1 ngày đối với công việc nội bộ. **0 điểm:** Từ 3 lần chậm hoặc vi phạm thời hạn bắt buộc gây hậu quả thuộc trách nhiệm được xác minh. |
> | **B3.2 – 4 điểm** | **4 điểm:** Tiếp nhận, giải quyết hoặc phản hồi 100% đề nghị thanh toán, điều chỉnh chứng từ hợp lệ đúng hạn. **3 điểm:** Có 1 lần chậm nhẹ không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc cố ý trì hoãn xử lý hồ sơ hợp lệ không có lý do chính đáng. |
>
> ### B4. Phối hợp, phục vụ và cải tiến (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% công việc hướng dẫn, phối hợp hoàn thiện hồ sơ tài chính của các bộ phận. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện trách nhiệm phối hợp hợp lệ. |
> | **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung cải tiến, số hóa hồ sơ, kiểm soát chi phí, tiết kiệm nguồn lực theo kế hoạch, có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ hợp lệ. |
>
> **Tổng B1 + B2 + B3 + B4: 70 điểm.**
>
> ---
>
> ## 4. NHÂN VIÊN VĂN THƯ – 70 ĐIỂM
>
> ### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B1.1 – 12 điểm** | **12 điểm:** Tiếp nhận, đăng ký, phân phối, theo dõi xử lý 100% văn bản đến, đi thuộc trách nhiệm. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% nhiệm vụ soạn thảo, phát hành, lập hồ sơ, sắp xếp, số hóa tài liệu được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> ### B2. Chất lượng, hiệu quả công việc (30 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B2.1 – 12 điểm** | **12 điểm:** Kiểm tra văn bản đúng thể thức, số hiệu, nội dung thông tin, nơi nhận và bảo mật; không sai sót. **9 điểm:** Có 1 sai sót nhẹ, phát hiện và sửa trước khi phát hành. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có sai sót nghiêm trọng về phát hành, bảo mật văn bản được xác minh. |
> | **B2.2 – 10 điểm** | **10 điểm:** Quản lý con dấu, chữ ký số, hệ thống văn bản điện tử đúng quy trình, thẩm quyền. **8 điểm:** Có 1 sai sót kỹ thuật nhẹ, khắc phục ngay, không gây hậu quả. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về sử dụng con dấu, chữ ký số, bảo mật được xác minh. |
> | **B2.3 – 8 điểm** | **8 điểm:** Hồ sơ, tài liệu được sắp xếp, lưu trữ đầy đủ, khoa học, tra cứu được theo yêu cầu. **6 điểm:** Có 1 sai sót nhẹ về sắp xếp hoặc phân loại, khắc phục ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc làm mất, thất lạc tài liệu quan trọng do lỗi chủ quan được xác minh. |
>
> ### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B3.1 – 6 điểm** | **6 điểm:** Chuyển 100% văn bản, thông tin chỉ đạo đúng thời hạn, ưu tiên xử lý văn bản khẩn theo quy định. **4 điểm:** Có 1 lần chuyển chậm văn bản thông thường, không gây ảnh hưởng, khắc phục ngay. **2 điểm:** Có 2 lần chậm đối với văn bản thông thường. **0 điểm:** Từ 3 lần chậm hoặc có vi phạm nghiêm trọng về thời hạn xử lý văn bản khẩn được xác minh. |
> | **B3.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% việc phát hành, nộp lưu, bàn giao hồ sơ đúng hạn. **3 điểm:** Có 1 lần chậm không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện nhiệm vụ bàn giao, lưu trữ bắt buộc. |
>
> ### B4. Phối hợp, phục vụ và cải tiến (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ phối hợp cung cấp văn bản, mẫu biểu và xử lý thủ tục hành chính. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện trách nhiệm phối hợp hợp lệ. |
> | **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung cải tiến quản lý văn bản, số hóa, tra cứu dữ liệu hoặc quy trình hành chính, có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ được giao. |
>
> **Tổng B1 + B2 + B3 + B4: 70 điểm.**
>
> ---
>
> ## 5. NHÂN VIÊN THỦ QUỸ – 70 ĐIỂM
>
> ### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B1.1 – 12 điểm** | **12 điểm:** Thực hiện 100% nghiệp vụ thu, chi tiền mặt hợp lệ thuộc thẩm quyền, phân công. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2 – 8 điểm** | **8 điểm:** Cập nhật 100% nghiệp vụ vào sổ quỹ, thực hiện kiểm đếm, bàn giao theo quy định. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> ### B2. Chất lượng, hiệu quả công việc (30 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B2.1 – 12 điểm** | **12 điểm:** Số tiền thực tế khớp sổ quỹ và chứng từ; bảo quản tiền, tài sản an toàn. **9 điểm:** Có 1 sai sót ghi chép nhẹ, đối chiếu và điều chỉnh kịp thời, không thất thoát. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có chênh lệch, thất thoát nghiêm trọng thuộc trách nhiệm được xác minh. |
> | **B2.2 – 10 điểm** | **10 điểm:** Kiểm tra đầy đủ điều kiện chứng từ, giao nhận, ký nhận đúng quy định. **8 điểm:** Có 1 sai sót thủ tục nhẹ, khắc phục trước khi thực hiện giao dịch. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc thực hiện thu, chi trái quy định nghiêm trọng được xác minh. |
> | **B2.3 – 8 điểm** | **8 điểm:** Bảo mật thông tin, lưu chứng từ, đối chiếu với kế toán đúng quy trình. **6 điểm:** Có 1 sai sót nhẹ về lưu trữ, ghi chép, khắc phục ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về bảo mật, chứng từ, đối chiếu quỹ được xác minh. |
>
> ### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B3.1 – 6 điểm** | **6 điểm:** Thực hiện 100% giao dịch hợp lệ đúng thời hạn được giao. **4 điểm:** Có 1 lần chậm nhẹ không quá 1 ngày, không ảnh hưởng quyền lợi và thời hạn bắt buộc. **2 điểm:** Có 2 lần chậm nhẹ hoặc 1 lần chậm quá 1 ngày đối với giao dịch thông thường. **0 điểm:** Từ 3 lần chậm hoặc vi phạm nghiêm trọng thời hạn giao dịch thuộc trách nhiệm được xác minh. |
> | **B3.2 – 4 điểm** | **4 điểm:** Hoàn tất 100% sổ quỹ, báo cáo, bàn giao, đối chiếu tiền mặt đúng hạn. **3 điểm:** Có 1 lần chậm không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện nhiệm vụ bàn giao, đối chiếu bắt buộc. |
>
> ### B4. Phối hợp, phục vụ và cải tiến (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ phối hợp với kế toán, ban giám hiệu và bộ phận liên quan. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện nhiệm vụ phối hợp hợp lệ. |
> | **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung kiểm soát, đối chiếu, báo cáo chênh lệch nếu có và cải tiến quản lý tiền mặt, chứng từ theo kế hoạch, có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không thực hiện nhiệm vụ hợp lệ được giao. |
>
> **Tổng B1 + B2 + B3 + B4: 70 điểm.**
>
> ---
>
> ## 6. NHÂN VIÊN BẢO VỆ – 70 ĐIỂM
>
> ### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B1.1 – 12 điểm** | **12 điểm:** Thực hiện 100% ca trực theo lịch phân công hợp lệ. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% lượt kiểm tra cổng, kiểm soát ra vào, tuần tra, kiểm tra tài sản theo lịch. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> ### B2. Chất lượng, hiệu quả công việc (30 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B2.1 – 12 điểm** | **12 điểm:** Thực hiện đúng quy trình kiểm soát cổng, phối hợp đón trả trẻ, phòng ngừa người lạ vào trường; không sai sót. **9 điểm:** Có 1 sai sót thủ tục nhẹ, chưa gây nguy cơ an toàn, khắc phục ngay. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về an ninh, an toàn được xác minh. |
> | **B2.2 – 10 điểm** | **10 điểm:** Thực hiện đầy đủ, đúng quy trình kiểm tra phòng cháy, chữa cháy, lối thoát hiểm và báo cáo nguy cơ. **8 điểm:** Có 1 thiếu sót nhẹ trong kiểm tra thường xuyên, khắc phục ngay. **4 điểm:** Có 2 thiếu sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc bỏ qua nguy cơ nghiêm trọng thuộc trách nhiệm được xác minh. |
> | **B2.3 – 8 điểm** | **8 điểm:** Kiểm tra khóa cửa, điện, nước, tài sản, khuôn viên đầy đủ theo trách nhiệm. **6 điểm:** Có 1 thiếu sót nhẹ, khắc phục ngay. **3 điểm:** Có 2 thiếu sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc vi phạm nghiêm trọng gây nguy cơ mất an toàn, tài sản được xác minh. |
>
> ### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B3.1 – 6 điểm** | **6 điểm:** Phát hiện, báo cáo, phối hợp xử lý 100% nguy cơ, sự việc về an ninh, an toàn đúng thời điểm; nếu không có sự việc, bảo đảm đầy đủ yêu cầu kiểm tra, phòng ngừa. **4 điểm:** Có 1 lần chậm báo cáo sự việc không khẩn cấp, chưa gây ảnh hưởng. **2 điểm:** Có 2 lần chậm báo cáo sự việc không khẩn cấp. **0 điểm:** Từ 3 lần chậm hoặc có vi phạm nghiêm trọng trong báo cáo, xử lý tình huống khẩn cấp được xác minh. |
> | **B3.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% việc kiểm tra cuối ca, ghi sổ, bàn giao đúng thời gian. **3 điểm:** Có 1 lần chậm nhẹ, khắc phục ngay. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá thời hạn yêu cầu. **0 điểm:** Từ 3 lần chậm hoặc không bàn giao gây nguy cơ mất an toàn được xác minh. |
>
> ### B4. Phối hợp, phục vụ và cải tiến (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ phối hợp với ban giám hiệu, giáo viên, nhân viên và bộ phận liên quan. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện nhiệm vụ phối hợp hợp lệ. |
> | **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung phòng ngừa nguy cơ, cải thiện an ninh, quản lý tài sản được giao, có minh chứng kết quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ hợp lệ. |
>
> **Tổng B1 + B2 + B3 + B4: 70 điểm.**
>
> ---
>
> ## 7. NHÂN VIÊN PHỤC VỤ, VỆ SINH – 70 ĐIỂM
>
> ### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B1.1 – 12 điểm** | **12 điểm:** Vệ sinh hoàn thành 100% khu vực, ca và hạng mục được phân công. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% nhiệm vụ thu gom rác, bổ sung vật tư, vệ sinh dụng cụ, phục vụ được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> ### B2. Chất lượng, hiệu quả công việc (30 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B2.1 – 12 điểm** | **12 điểm:** Các khu vực được phân công sạch sẽ, không có rác, nước đọng hoặc tình trạng mất vệ sinh do không thực hiện nhiệm vụ. **9 điểm:** Có 1 sai sót nhẹ, khắc phục trước khi ảnh hưởng hoạt động của trẻ. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về vệ sinh, an toàn được xác minh. |
> | **B2.2 – 10 điểm** | **10 điểm:** Sử dụng dụng cụ, hóa chất đúng hướng dẫn, bảo đảm an toàn tuyệt đối trong phạm vi trách nhiệm. **8 điểm:** Có 1 sai sót thủ tục nhẹ, chưa gây nguy cơ cho trẻ, khắc phục ngay. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về sử dụng, bảo quản hóa chất, dụng cụ nguy hiểm được xác minh. |
> | **B2.3 – 8 điểm** | **8 điểm:** Phân loại, thu gom rác đúng quy trình; phòng ngừa lây nhiễm chéo, trơn trượt và nguy cơ mất vệ sinh. **6 điểm:** Có 1 sai sót nhẹ, sửa ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có nguy cơ nghiêm trọng do không thực hiện trách nhiệm được xác minh. |
>
> ### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B3.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ vệ sinh đúng thời điểm, không ảnh hưởng hoạt động của trẻ. **4 điểm:** Có 1 lần chậm nhẹ, được khắc phục trước khi trẻ sử dụng khu vực. **2 điểm:** Có 2 lần chậm nhẹ, chưa gây nguy cơ nghiêm trọng. **0 điểm:** Từ 3 lần chậm hoặc chậm thực hiện làm phát sinh nguy cơ mất an toàn được xác minh. |
> | **B3.2 – 4 điểm** | **4 điểm:** Tiếp nhận, phản hồi, xử lý 100% nhiệm vụ vệ sinh phát sinh trong thời hạn được giao hợp lý. **3 điểm:** Có 1 lần chậm nhẹ, khắc phục ngay. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá thời hạn yêu cầu. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện nhiệm vụ hợp lệ gây ảnh hưởng nghiêm trọng. |
>
> ### B4. Phối hợp, phục vụ và cải tiến (10 điểm)
>
> | Mã | Quy định mức điểm |
> |---|---|
> | **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ phối hợp với giáo viên, bảo vệ và bộ phận liên quan trong vệ sinh, chuẩn bị môi trường, khắc phục sự cố. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện trách nhiệm phối hợp hợp lệ. |
> | **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung tiết kiệm vật tư, bảo quản dụng cụ, phòng ngừa mất an toàn theo kế hoạch, có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ hợp lệ. |
>
> **Tổng B1 + B2 + B3 + B4: 70 điểm.**
>
> ---
>
> ## 8. QUY ƯỚC CHẤM ĐIỂM VÀ TÍNH KẾT QUẢ
>
> **8.1. Xác định tỷ lệ hoàn thành công việc**
>
> Tỷ lệ hoàn thành (%) = (Số công việc hoàn thành đạt yêu cầu / Tổng số công việc được giao hợp lệ, đến hạn trong kỳ) × 100%.
>
> Chỉ tính các nhiệm vụ thuộc trách nhiệm thực hiện của nhân viên sau khi đã điều chỉnh hợp lệ. Công việc chưa đạt yêu cầu chất lượng không được tính là hoàn thành đạt yêu cầu. Đơn vị tính công việc phải được thống nhất từ đầu kỳ để tránh tính trùng.
>
> **8.2. Xác định điểm từng tiêu chí**
>
> Căn cứ tỷ lệ hoàn thành, số lần sai sót, tính chất vi phạm, thời hạn thực hiện và minh chứng để xác định một mức điểm tương ứng trong bảng. Không tự ý cho điểm ngoài các mức đã quy định.
>
> **8.3. Quy ước sai sót**
>
> Sai sót nhẹ là sai sót chưa gây hậu quả nghiêm trọng về an toàn, tài sản, quyền lợi, tính hợp pháp hoặc bảo mật; có thể khắc phục và đã được khắc phục theo yêu cầu.
>
> Vi phạm nghiêm trọng phải được xác định trên cơ sở tài liệu, kiểm tra hoặc kết luận có thẩm quyền phù hợp. Không chỉ căn cứ phản ánh chưa xác minh để chấm 0 điểm.
>
> Một sai sót không bị tính lặp nhiều lần cho cùng một nội dung đánh giá. Trường hợp gây ra các hậu quả độc lập thuộc những tiêu chí khác nhau phải có minh chứng riêng.
>
> **8.4. Nhiệm vụ không phát sinh trong tháng**
>
> Trường hợp không phát sinh nhiệm vụ đột xuất, sự cố sức khỏe, chênh lệch tiền quỹ hoặc nhiệm vụ đặc thù khác, người phụ trách đánh giá các hoạt động thường xuyên về chuẩn bị, kiểm tra, phòng ngừa và duy trì trạng thái sẵn sàng đã được giao.
>
> Nếu một tiêu chí thực sự không áp dụng trong kỳ và không thể xác định nhiệm vụ tương đương, phải ghi rõ lý do, được người có thẩm quyền xác nhận; không tự động cho 0 điểm hoặc điểm tối đa. Việc quy đổi điểm trong nhóm phải được thống nhất trước khi áp dụng.
>
> **8.5. Cách tính điểm KPI tháng**
>
> Điểm KPI tháng = Điểm A + Điểm B1 + Điểm B2 + Điểm B3 + Điểm B4.
>
> Trong đó:
>
> - A: Tối đa 30 điểm.
> - B1: B1.1 + B1.2, tối đa 20 điểm.
> - B2: B2.1 + B2.2 + B2.3, tối đa 30 điểm.
> - B3: B3.1 + B3.2, tối đa 10 điểm.
> - B4: B4.1 + B4.2, tối đa 10 điểm.
>
> **Tổng điểm tối đa: 100 điểm.**
>
> Kết quả KPI tháng là căn cứ theo dõi mức độ hoàn thành công việc; việc xếp loại chất lượng viên chức chính thức thực hiện theo quy định pháp luật và quy chế của nhà trường.

## 🔍 3. Ví dụ minh họa cách tính điểm

Giả sử một nhân viên cấp dưỡng có kết quả trong tháng như sau:

| Nhóm | Điểm chấm | Điểm tối đa |
|--------|--------|--------|
| A. Tiêu chí chung | 27 | 30 |
| B1. Khối lượng công việc | 18 | 20 |
| B2. Chất lượng công việc | 25 | 30 |
| B3. Tiến độ | 9 | 10 |
| B4. Phối hợp, cải tiến | 9 | 10 |
| **Tổng** | **88** | **100** |

KẾT QUẢ KPI THÁNG MINH HỌA

# 88/100

Mức tương ứng: Hoàn thành tốt nhiệm vụ

Đây là mức đối chiếu điểm theo tháng, chưa phải quyết định xếp loại viên chức cuối năm.

## ⚠️ 4. Những nội dung cần chỉnh để Quy chế chặt chẽ hơn

Qua rà soát, tôi đề nghị nhà trường chỉnh thêm ba nội dung trước khi ban hành.

**Thứ nhất, sửa mức điểm A1.2 ở cả bảng giáo viên và nhân viên.** Hiện quy định “2–3 vi phạm nhẹ” được 2 điểm nhưng “từ 3 sai sót” lại được 0 điểm, khiến trường hợp có đúng 3 sai sót bị trùng hai mức chấm. Nên thống nhất: 2 điểm khi có đúng 2 vi phạm nhẹ; 0 điểm khi có từ 3 vi phạm nhẹ hoặc vi phạm nghiêm trọng được xác minh.

**Thứ hai, hoàn chỉnh quy định xử lý tiêu chí không phát sinh nhiệm vụ.** Đặc biệt đối với y tế, bảo vệ và thủ quỹ, tháng không xảy ra sự cố không đồng nghĩa với không hoàn thành công việc. Nên đánh giá nhiệm vụ thường xuyên và trạng thái sẵn sàng. Với tiêu chí thực sự không áp dụng, có thể đề xuất quy đổi điểm trong cùng nhóm theo công thức:

\[
\text{Điểm nhóm quy đổi}=
\frac{\text{Tổng điểm đạt của tiêu chí áp dụng}}
{\text{Tổng điểm tối đa của tiêu chí áp dụng}}
\times\text{Điểm tối đa của nhóm}
\]

Cách quy đổi này cần được nhà trường thống nhất, ghi rõ trong Quy chế và áp dụng đồng nhất, không tùy nghi từng cá nhân.

**Thứ ba, chỉnh các tiêu đề bị trùng ở cuối Phụ lục II.** Phần “8. C. TIÊU CHÍ KẾT QUẢ THỰC HIỆN NHIỆM VỤ – NHÂN VIÊN 70 ĐIỂM” hiện chỉ lặp lại bảng tổng hợp đã có trong Điều 8. Có thể đổi thành “BẢNG TỔNG HỢP CƠ CẤU ĐIỂM KPI NHÂN VIÊN”. Đồng thời sửa “D. E. QUY ƯỚC THEO DÕI ĐỊNH KỲ” thành “III. QUY ƯỚC THEO DÕI, ĐÁNH GIÁ ĐỊNH KỲ”.

## ✅ 5. Kết luận và đề xuất của Hiệu trưởng

Với phần bổ sung này, hệ thống KPI của nhà trường đã có thể xác định điểm cụ thể cho từng vị trí nhân viên trên cùng thang 100 điểm, đồng thời chú trọng các yêu cầu đặc thù về an toàn trẻ, vệ sinh thực phẩm, tài chính và bảo mật thông tin.

Trước khi đưa vào thực hiện chính thức, nên cho tổ văn phòng và đại diện từng vị trí việc làm thử chấm trên một tháng công tác thực tế; đối chiếu những tiêu chí khó có minh chứng hoặc không phát sinh nhiệm vụ để hoàn thiện quy định. Việc này giúp bảo đảm công bằng giữa nhân viên có khối lượng, tính chất công việc khác nhau.

**Điểm quan trọng nhất:** KPI phải phản ánh đúng mức độ hoàn thành công việc, không chỉ là bảng trừ điểm sai sót. Điểm theo dõi hằng tháng là căn cứ đánh giá; việc xếp loại cuối năm, nhất là mức hoàn thành xuất sắc, còn phải đáp ứng các điều kiện và tỷ lệ theo Nghị định số 233/2026/NĐ-CP. [Các mức xếp loại chất lượng viên chức](<https://xaydungchinhsach.chinhphu.vn/cac-muc-xep-loai-chat-luong-vien-chuc-119260701155446369.htm>)

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

Tôi đã xác định được các mức điểm thống nhất cho từng loại tiêu chí. Với những vị trí liên quan trực tiếp đến an toàn của trẻ, thực phẩm, thuốc, tiền quỹ và văn bản mật, tôi sẽ quy định rõ trường hợp sai sót nghiêm trọng thay vì chỉ chấm theo số lần vi phạm.

---

ASSISTANT

## 📋 2. Nội dung cụ thể bổ sung vào Phụ lục II

Dưới đây là **63 nội dung chấm điểm đề xuất** để điền trực tiếp vào cột “Quy định mức điểm” trong các bảng KPI nhân viên của nhà trường. Các mã tiêu chí, nhiệm vụ và điểm tối đa được giữ theo bản dự thảo.

<WritingBlock id="48317" variant="document"># BỔ SUNG QUY ĐỊNH MỨC ĐIỂM KPI ĐỐI VỚI NHÂN VIÊN
**Trường Mầm non An Bình – Năm học 2026–2027**

## 1. NHÂN VIÊN NUÔI DƯỠNG, CẤP DƯỠNG – 70 ĐIỂM

### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B1.1 – 12 điểm** | **12 điểm:** Thực hiện 100% ca chế biến, bữa ăn và công đoạn được phân công. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
| **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% nhiệm vụ tiếp nhận, sơ chế, chia suất, thu dọn được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |

### B2. Chất lượng, hiệu quả công việc (30 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B2.1 – 12 điểm** | **12 điểm:** Thực hiện đúng quy trình vệ sinh, an toàn thực phẩm, không có sai sót. **9 điểm:** Có 1 sai sót nhẹ, chưa gây mất an toàn, khắc phục ngay. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về an toàn thực phẩm được xác minh. |
| **B2.2 – 10 điểm** | **10 điểm:** Chế biến đúng thực đơn, định lượng, chia suất, kiểm thực, lưu mẫu theo trách nhiệm; không sai sót. **8 điểm:** Có 1 sai sót nhẹ được khắc phục trước khi phục vụ. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng ảnh hưởng an toàn bữa ăn được xác minh. |
| **B2.3 – 8 điểm** | **8 điểm:** Vệ sinh, khử khuẩn, bảo quản thực phẩm, dụng cụ và thu gom rác đúng quy trình. **6 điểm:** Có 1 sai sót nhẹ, sửa ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng được xác minh. |

### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B3.1 – 6 điểm** | **6 điểm:** 100% bữa ăn được chế biến, hoàn thành và bàn giao đúng giờ. **4 điểm:** Có 1 lần chậm nhẹ, được khắc phục, không ảnh hưởng giờ ăn của trẻ. **2 điểm:** Có 2 lần chậm nhẹ hoặc 1 lần chậm ảnh hưởng lịch ăn nhưng chưa gây hậu quả nghiêm trọng. **0 điểm:** Từ 3 lần chậm hoặc có sai sót chủ quan nghiêm trọng làm ảnh hưởng việc tổ chức bữa ăn. |
| **B3.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung kiểm thực, lưu mẫu, giao nhận, ghi chép đúng thời hạn. **3 điểm:** Có 1 lần chậm ghi chép hành chính không quá 1 ngày, không ảnh hưởng quy trình bắt buộc. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày đối với hồ sơ thông thường. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện yêu cầu kiểm thực, lưu mẫu bắt buộc. |

### B4. Phối hợp, phục vụ và cải tiến (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% công việc phối hợp với giáo viên, y tế và tổ bếp. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện nhiệm vụ phối hợp hợp lệ không có lý do chính đáng. |
| **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung cải tiến, tiết kiệm, giảm hao hụt, bảo quản tài sản theo phân công và có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ hợp lệ được giao. |

**Tổng B1 + B2 + B3 + B4: 70 điểm.**

---

## 2. NHÂN VIÊN Y TẾ – 70 ĐIỂM

### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B1.1 – 12 điểm** | **12 điểm:** Hoàn thành 100% hoạt động theo dõi sức khỏe, cân đo, quản lý hồ sơ sức khỏe, chăm sóc ban đầu theo kế hoạch. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
| **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% nhiệm vụ truyền thông, kiểm tra vệ sinh, phòng chống dịch và tham mưu y tế được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |

### B2. Chất lượng, hiệu quả công việc (30 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B2.1 – 12 điểm** | **12 điểm:** Thực hiện đúng quy trình sơ cứu, chăm sóc ban đầu, ghi nhận và chuyển tuyến đúng thẩm quyền; không sai sót. **9 điểm:** Có 1 sai sót nhẹ về ghi chép hoặc thủ tục, không ảnh hưởng an toàn, khắc phục ngay. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về chuyên môn, an toàn sức khỏe được xác minh. |
| **B2.2 – 10 điểm** | **10 điểm:** Theo dõi, phát hiện, báo cáo kịp thời dấu hiệu bất thường và nguy cơ dịch bệnh; thực hiện đầy đủ biện pháp phòng ngừa. **8 điểm:** Có 1 thiếu sót nhẹ trong theo dõi thường xuyên, khắc phục ngay. **4 điểm:** Có 2 thiếu sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc bỏ sót nguy cơ nghiêm trọng thuộc trách nhiệm được xác minh. |
| **B2.3 – 8 điểm** | **8 điểm:** Quản lý thuốc, vật tư, hạn sử dụng và hồ sơ y tế đúng quy định. **6 điểm:** Có 1 sai sót nhẹ về ghi chép, sắp xếp, sửa ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về quản lý thuốc, vật tư hay bảo mật thông tin được xác minh. |

### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B3.1 – 6 điểm** | **6 điểm:** Tiếp nhận, báo cáo và xử lý 100% tình huống sức khỏe, an toàn khẩn cấp đúng thời điểm, quy trình; nếu không phát sinh tình huống, đáp ứng đầy đủ yêu cầu kiểm tra sẵn sàng ứng phó. **4 điểm:** Có 1 lần chậm báo cáo nội bộ không khẩn cấp, chưa gây ảnh hưởng, khắc phục ngay. **2 điểm:** Có 2 lần chậm báo cáo nội bộ không khẩn cấp. **0 điểm:** Có vi phạm nghiêm trọng về thời gian xử lý tình huống khẩn cấp được xác minh hoặc từ 3 lần chậm thuộc trách nhiệm. |
| **B3.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% báo cáo, tổng hợp thông tin sức khỏe đúng hạn. **3 điểm:** Có 1 lần chậm không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện báo cáo bắt buộc. |

### B4. Phối hợp, phục vụ và cải tiến (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% yêu cầu phối hợp với giáo viên, cha mẹ trẻ, cấp dưỡng và cơ sở y tế; trao đổi đúng thẩm quyền. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc từ chối nhiệm vụ phối hợp hợp lệ không có lý do chính đáng. |
| **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung hướng dẫn, tư vấn, truyền thông sức khỏe được giao, có sản phẩm và ghi nhận kết quả. **3 điểm:** Hoàn thành 100% nhưng chưa có minh chứng đánh giá hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ được giao. |

**Tổng B1 + B2 + B3 + B4: 70 điểm.**

---

## 3. NHÂN VIÊN KẾ TOÁN – 70 ĐIỂM

### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B1.1 – 12 điểm** | **12 điểm:** Tiếp nhận, kiểm tra, xử lý 100% chứng từ, nghiệp vụ kế toán phát sinh hợp lệ thuộc trách nhiệm. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
| **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% bảng tổng hợp, báo cáo thu chi, dự toán, quyết toán, số liệu phải thực hiện trong tháng. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |

### B2. Chất lượng, hiệu quả công việc (30 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B2.1 – 12 điểm** | **12 điểm:** Hạch toán, kiểm tra chứng từ chính xác, hợp pháp, không sai sót. **9 điểm:** Có 1 sai sót kỹ thuật nhẹ, khắc phục trước khi hoàn tất nghiệp vụ. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về tài chính, kế toán được xác minh. |
| **B2.2 – 10 điểm** | **10 điểm:** Đối chiếu đầy đủ, chính xác số liệu thu chi, công nợ, tạm ứng với các bộ phận. **8 điểm:** Có 1 sai lệch nhỏ, phát hiện và điều chỉnh đúng hạn. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc sai lệch nghiêm trọng chưa được xử lý do nguyên nhân chủ quan. |
| **B2.3 – 8 điểm** | **8 điểm:** Lưu trữ, bảo mật, công khai và giải trình hồ sơ tài chính đúng quy định. **6 điểm:** Có 1 sai sót nhẹ về sắp xếp, lưu trữ, khắc phục ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về lưu trữ, bảo mật, công khai tài chính được xác minh. |

### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B3.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% chứng từ, báo cáo, mốc công việc tài chính đúng hạn. **4 điểm:** Có 1 lần chậm không quá 1 ngày đối với công việc nội bộ, không ảnh hưởng thời hạn pháp luật. **2 điểm:** Có 2 lần chậm nhẹ hoặc 1 lần chậm quá 1 ngày đối với công việc nội bộ. **0 điểm:** Từ 3 lần chậm hoặc vi phạm thời hạn bắt buộc gây hậu quả thuộc trách nhiệm được xác minh. |
| **B3.2 – 4 điểm** | **4 điểm:** Tiếp nhận, giải quyết hoặc phản hồi 100% đề nghị thanh toán, điều chỉnh chứng từ hợp lệ đúng hạn. **3 điểm:** Có 1 lần chậm nhẹ không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc cố ý trì hoãn xử lý hồ sơ hợp lệ không có lý do chính đáng. |

### B4. Phối hợp, phục vụ và cải tiến (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% công việc hướng dẫn, phối hợp hoàn thiện hồ sơ tài chính của các bộ phận. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện trách nhiệm phối hợp hợp lệ. |
| **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung cải tiến, số hóa hồ sơ, kiểm soát chi phí, tiết kiệm nguồn lực theo kế hoạch, có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ hợp lệ. |

**Tổng B1 + B2 + B3 + B4: 70 điểm.**

---

## 4. NHÂN VIÊN VĂN THƯ – 70 ĐIỂM

### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B1.1 – 12 điểm** | **12 điểm:** Tiếp nhận, đăng ký, phân phối, theo dõi xử lý 100% văn bản đến, đi thuộc trách nhiệm. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
| **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% nhiệm vụ soạn thảo, phát hành, lập hồ sơ, sắp xếp, số hóa tài liệu được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |

### B2. Chất lượng, hiệu quả công việc (30 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B2.1 – 12 điểm** | **12 điểm:** Kiểm tra văn bản đúng thể thức, số hiệu, nội dung thông tin, nơi nhận và bảo mật; không sai sót. **9 điểm:** Có 1 sai sót nhẹ, phát hiện và sửa trước khi phát hành. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có sai sót nghiêm trọng về phát hành, bảo mật văn bản được xác minh. |
| **B2.2 – 10 điểm** | **10 điểm:** Quản lý con dấu, chữ ký số, hệ thống văn bản điện tử đúng quy trình, thẩm quyền. **8 điểm:** Có 1 sai sót kỹ thuật nhẹ, khắc phục ngay, không gây hậu quả. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về sử dụng con dấu, chữ ký số, bảo mật được xác minh. |
| **B2.3 – 8 điểm** | **8 điểm:** Hồ sơ, tài liệu được sắp xếp, lưu trữ đầy đủ, khoa học, tra cứu được theo yêu cầu. **6 điểm:** Có 1 sai sót nhẹ về sắp xếp hoặc phân loại, khắc phục ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc làm mất, thất lạc tài liệu quan trọng do lỗi chủ quan được xác minh. |

### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B3.1 – 6 điểm** | **6 điểm:** Chuyển 100% văn bản, thông tin chỉ đạo đúng thời hạn, ưu tiên xử lý văn bản khẩn theo quy định. **4 điểm:** Có 1 lần chuyển chậm văn bản thông thường, không gây ảnh hưởng, khắc phục ngay. **2 điểm:** Có 2 lần chậm đối với văn bản thông thường. **0 điểm:** Từ 3 lần chậm hoặc có vi phạm nghiêm trọng về thời hạn xử lý văn bản khẩn được xác minh. |
| **B3.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% việc phát hành, nộp lưu, bàn giao hồ sơ đúng hạn. **3 điểm:** Có 1 lần chậm không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện nhiệm vụ bàn giao, lưu trữ bắt buộc. |

### B4. Phối hợp, phục vụ và cải tiến (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ phối hợp cung cấp văn bản, mẫu biểu và xử lý thủ tục hành chính. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện trách nhiệm phối hợp hợp lệ. |
| **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung cải tiến quản lý văn bản, số hóa, tra cứu dữ liệu hoặc quy trình hành chính, có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ được giao. |

**Tổng B1 + B2 + B3 + B4: 70 điểm.**

---

## 5. NHÂN VIÊN THỦ QUỸ – 70 ĐIỂM

### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B1.1 – 12 điểm** | **12 điểm:** Thực hiện 100% nghiệp vụ thu, chi tiền mặt hợp lệ thuộc thẩm quyền, phân công. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
| **B1.2 – 8 điểm** | **8 điểm:** Cập nhật 100% nghiệp vụ vào sổ quỹ, thực hiện kiểm đếm, bàn giao theo quy định. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |

### B2. Chất lượng, hiệu quả công việc (30 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B2.1 – 12 điểm** | **12 điểm:** Số tiền thực tế khớp sổ quỹ và chứng từ; bảo quản tiền, tài sản an toàn. **9 điểm:** Có 1 sai sót ghi chép nhẹ, đối chiếu và điều chỉnh kịp thời, không thất thoát. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có chênh lệch, thất thoát nghiêm trọng thuộc trách nhiệm được xác minh. |
| **B2.2 – 10 điểm** | **10 điểm:** Kiểm tra đầy đủ điều kiện chứng từ, giao nhận, ký nhận đúng quy định. **8 điểm:** Có 1 sai sót thủ tục nhẹ, khắc phục trước khi thực hiện giao dịch. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc thực hiện thu, chi trái quy định nghiêm trọng được xác minh. |
| **B2.3 – 8 điểm** | **8 điểm:** Bảo mật thông tin, lưu chứng từ, đối chiếu với kế toán đúng quy trình. **6 điểm:** Có 1 sai sót nhẹ về lưu trữ, ghi chép, khắc phục ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về bảo mật, chứng từ, đối chiếu quỹ được xác minh. |

### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B3.1 – 6 điểm** | **6 điểm:** Thực hiện 100% giao dịch hợp lệ đúng thời hạn được giao. **4 điểm:** Có 1 lần chậm nhẹ không quá 1 ngày, không ảnh hưởng quyền lợi và thời hạn bắt buộc. **2 điểm:** Có 2 lần chậm nhẹ hoặc 1 lần chậm quá 1 ngày đối với giao dịch thông thường. **0 điểm:** Từ 3 lần chậm hoặc vi phạm nghiêm trọng thời hạn giao dịch thuộc trách nhiệm được xác minh. |
| **B3.2 – 4 điểm** | **4 điểm:** Hoàn tất 100% sổ quỹ, báo cáo, bàn giao, đối chiếu tiền mặt đúng hạn. **3 điểm:** Có 1 lần chậm không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện nhiệm vụ bàn giao, đối chiếu bắt buộc. |

### B4. Phối hợp, phục vụ và cải tiến (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ phối hợp với kế toán, ban giám hiệu và bộ phận liên quan. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện nhiệm vụ phối hợp hợp lệ. |
| **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung kiểm soát, đối chiếu, báo cáo chênh lệch nếu có và cải tiến quản lý tiền mặt, chứng từ theo kế hoạch, có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không thực hiện nhiệm vụ hợp lệ được giao. |

**Tổng B1 + B2 + B3 + B4: 70 điểm.**

---

## 6. NHÂN VIÊN BẢO VỆ – 70 ĐIỂM

### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B1.1 – 12 điểm** | **12 điểm:** Thực hiện 100% ca trực theo lịch phân công hợp lệ. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
| **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% lượt kiểm tra cổng, kiểm soát ra vào, tuần tra, kiểm tra tài sản theo lịch. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |

### B2. Chất lượng, hiệu quả công việc (30 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B2.1 – 12 điểm** | **12 điểm:** Thực hiện đúng quy trình kiểm soát cổng, phối hợp đón trả trẻ, phòng ngừa người lạ vào trường; không sai sót. **9 điểm:** Có 1 sai sót thủ tục nhẹ, chưa gây nguy cơ an toàn, khắc phục ngay. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về an ninh, an toàn được xác minh. |
| **B2.2 – 10 điểm** | **10 điểm:** Thực hiện đầy đủ, đúng quy trình kiểm tra phòng cháy, chữa cháy, lối thoát hiểm và báo cáo nguy cơ. **8 điểm:** Có 1 thiếu sót nhẹ trong kiểm tra thường xuyên, khắc phục ngay. **4 điểm:** Có 2 thiếu sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc bỏ qua nguy cơ nghiêm trọng thuộc trách nhiệm được xác minh. |
| **B2.3 – 8 điểm** | **8 điểm:** Kiểm tra khóa cửa, điện, nước, tài sản, khuôn viên đầy đủ theo trách nhiệm. **6 điểm:** Có 1 thiếu sót nhẹ, khắc phục ngay. **3 điểm:** Có 2 thiếu sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc vi phạm nghiêm trọng gây nguy cơ mất an toàn, tài sản được xác minh. |

### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B3.1 – 6 điểm** | **6 điểm:** Phát hiện, báo cáo, phối hợp xử lý 100% nguy cơ, sự việc về an ninh, an toàn đúng thời điểm; nếu không có sự việc, bảo đảm đầy đủ yêu cầu kiểm tra, phòng ngừa. **4 điểm:** Có 1 lần chậm báo cáo sự việc không khẩn cấp, chưa gây ảnh hưởng. **2 điểm:** Có 2 lần chậm báo cáo sự việc không khẩn cấp. **0 điểm:** Từ 3 lần chậm hoặc có vi phạm nghiêm trọng trong báo cáo, xử lý tình huống khẩn cấp được xác minh. |
| **B3.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% việc kiểm tra cuối ca, ghi sổ, bàn giao đúng thời gian. **3 điểm:** Có 1 lần chậm nhẹ, khắc phục ngay. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá thời hạn yêu cầu. **0 điểm:** Từ 3 lần chậm hoặc không bàn giao gây nguy cơ mất an toàn được xác minh. |

### B4. Phối hợp, phục vụ và cải tiến (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ phối hợp với ban giám hiệu, giáo viên, nhân viên và bộ phận liên quan. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện nhiệm vụ phối hợp hợp lệ. |
| **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung phòng ngừa nguy cơ, cải thiện an ninh, quản lý tài sản được giao, có minh chứng kết quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ hợp lệ. |

**Tổng B1 + B2 + B3 + B4: 70 điểm.**

---

## 7. NHÂN VIÊN PHỤC VỤ, VỆ SINH – 70 ĐIỂM

### B1. Số lượng, khối lượng nhiệm vụ (20 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B1.1 – 12 điểm** | **12 điểm:** Vệ sinh hoàn thành 100% khu vực, ca và hạng mục được phân công. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
| **B1.2 – 8 điểm** | **8 điểm:** Hoàn thành 100% nhiệm vụ thu gom rác, bổ sung vật tư, vệ sinh dụng cụ, phục vụ được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |

### B2. Chất lượng, hiệu quả công việc (30 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B2.1 – 12 điểm** | **12 điểm:** Các khu vực được phân công sạch sẽ, không có rác, nước đọng hoặc tình trạng mất vệ sinh do không thực hiện nhiệm vụ. **9 điểm:** Có 1 sai sót nhẹ, khắc phục trước khi ảnh hưởng hoạt động của trẻ. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về vệ sinh, an toàn được xác minh. |
| **B2.2 – 10 điểm** | **10 điểm:** Sử dụng dụng cụ, hóa chất đúng hướng dẫn, bảo đảm an toàn tuyệt đối trong phạm vi trách nhiệm. **8 điểm:** Có 1 sai sót thủ tục nhẹ, chưa gây nguy cơ cho trẻ, khắc phục ngay. **4 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về sử dụng, bảo quản hóa chất, dụng cụ nguy hiểm được xác minh. |
| **B2.3 – 8 điểm** | **8 điểm:** Phân loại, thu gom rác đúng quy trình; phòng ngừa lây nhiễm chéo, trơn trượt và nguy cơ mất vệ sinh. **6 điểm:** Có 1 sai sót nhẹ, sửa ngay. **3 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có nguy cơ nghiêm trọng do không thực hiện trách nhiệm được xác minh. |

### B3. Tiến độ thực hiện nhiệm vụ (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B3.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ vệ sinh đúng thời điểm, không ảnh hưởng hoạt động của trẻ. **4 điểm:** Có 1 lần chậm nhẹ, được khắc phục trước khi trẻ sử dụng khu vực. **2 điểm:** Có 2 lần chậm nhẹ, chưa gây nguy cơ nghiêm trọng. **0 điểm:** Từ 3 lần chậm hoặc chậm thực hiện làm phát sinh nguy cơ mất an toàn được xác minh. |
| **B3.2 – 4 điểm** | **4 điểm:** Tiếp nhận, phản hồi, xử lý 100% nhiệm vụ vệ sinh phát sinh trong thời hạn được giao hợp lý. **3 điểm:** Có 1 lần chậm nhẹ, khắc phục ngay. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm quá thời hạn yêu cầu. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện nhiệm vụ hợp lệ gây ảnh hưởng nghiêm trọng. |

### B4. Phối hợp, phục vụ và cải tiến (10 điểm)

| Mã | Quy định mức điểm |
|---|---|
| **B4.1 – 6 điểm** | **6 điểm:** Hoàn thành 100% nhiệm vụ phối hợp với giáo viên, bảo vệ và bộ phận liên quan trong vệ sinh, chuẩn bị môi trường, khắc phục sự cố. **4 điểm:** Từ 90% đến dưới 100%. **2 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc không thực hiện trách nhiệm phối hợp hợp lệ. |
| **B4.2 – 4 điểm** | **4 điểm:** Hoàn thành 100% nội dung tiết kiệm vật tư, bảo quản dụng cụ, phòng ngừa mất an toàn theo kế hoạch, có minh chứng hiệu quả. **3 điểm:** Hoàn thành 100% nhưng chưa đánh giá được hiệu quả. **1 điểm:** Hoàn thành từ 70% đến dưới 100%. **0 điểm:** Dưới 70% hoặc không triển khai nhiệm vụ hợp lệ. |

**Tổng B1 + B2 + B3 + B4: 70 điểm.**

---

## 8. QUY ƯỚC CHẤM ĐIỂM VÀ TÍNH KẾT QUẢ

**8.1. Xác định tỷ lệ hoàn thành công việc**

Tỷ lệ hoàn thành (%) = (Số công việc hoàn thành đạt yêu cầu / Tổng số công việc được giao hợp lệ, đến hạn trong kỳ) × 100%.

Chỉ tính các nhiệm vụ thuộc trách nhiệm thực hiện của nhân viên sau khi đã điều chỉnh hợp lệ. Công việc chưa đạt yêu cầu chất lượng không được tính là hoàn thành đạt yêu cầu. Đơn vị tính công việc phải được thống nhất từ đầu kỳ để tránh tính trùng.

**8.2. Xác định điểm từng tiêu chí**

Căn cứ tỷ lệ hoàn thành, số lần sai sót, tính chất vi phạm, thời hạn thực hiện và minh chứng để xác định một mức điểm tương ứng trong bảng. Không tự ý cho điểm ngoài các mức đã quy định.

**8.3. Quy ước sai sót**

Sai sót nhẹ là sai sót chưa gây hậu quả nghiêm trọng về an toàn, tài sản, quyền lợi, tính hợp pháp hoặc bảo mật; có thể khắc phục và đã được khắc phục theo yêu cầu.

Vi phạm nghiêm trọng phải được xác định trên cơ sở tài liệu, kiểm tra hoặc kết luận có thẩm quyền phù hợp. Không chỉ căn cứ phản ánh chưa xác minh để chấm 0 điểm.

Một sai sót không bị tính lặp nhiều lần cho cùng một nội dung đánh giá. Trường hợp gây ra các hậu quả độc lập thuộc những tiêu chí khác nhau phải có minh chứng riêng.

**8.4. Nhiệm vụ không phát sinh trong tháng**

Trường hợp không phát sinh nhiệm vụ đột xuất, sự cố sức khỏe, chênh lệch tiền quỹ hoặc nhiệm vụ đặc thù khác, người phụ trách đánh giá các hoạt động thường xuyên về chuẩn bị, kiểm tra, phòng ngừa và duy trì trạng thái sẵn sàng đã được giao.

Nếu một tiêu chí thực sự không áp dụng trong kỳ và không thể xác định nhiệm vụ tương đương, phải ghi rõ lý do, được người có thẩm quyền xác nhận; không tự động cho 0 điểm hoặc điểm tối đa. Việc quy đổi điểm trong nhóm phải được thống nhất trước khi áp dụng.

**8.5. Cách tính điểm KPI tháng**

Điểm KPI tháng = Điểm A + Điểm B1 + Điểm B2 + Điểm B3 + Điểm B4.

Trong đó:

- A: Tối đa 30 điểm.
- B1: B1.1 + B1.2, tối đa 20 điểm.
- B2: B2.1 + B2.2 + B2.3, tối đa 30 điểm.
- B3: B3.1 + B3.2, tối đa 10 điểm.
- B4: B4.1 + B4.2, tối đa 10 điểm.

**Tổng điểm tối đa: 100 điểm.**

Kết quả KPI tháng là căn cứ theo dõi mức độ hoàn thành công việc; việc xếp loại chất lượng viên chức chính thức thực hiện theo quy định pháp luật và quy chế của nhà trường.

</WritingBlock>

## 🔍 3. Ví dụ minh họa cách tính điểm

Giả sử một nhân viên cấp dưỡng có kết quả trong tháng như sau:

| Nhóm | Điểm chấm | Điểm tối đa |
|---|---:|---:|
| A. Tiêu chí chung | 27 | 30 |
| B1. Khối lượng công việc | 18 | 20 |
| B2. Chất lượng công việc | 25 | 30 |
| B3. Tiến độ | 9 | 10 |
| B4. Phối hợp, cải tiến | 9 | 10 |
| **Tổng** | **88** | **100** |

<box border radius="lg" padding={3} gap={2}>
  <text color="secondary" weight="medium" size="xs">KẾT QUẢ KPI THÁNG MINH HỌA</text>
  <row align="end" justify="between">
    <title size="2xl" color="default" tabularNums>88/100</title>
    <text weight="medium">Mức tương ứng: Hoàn thành tốt nhiệm vụ</text>
  </row>
  <box background="surface-tertiary" radius="full" height="10px" clip>
    <box background="rgba(19,130,110,0.85)" width="88%" height="100%" radius="full"/>
  </box>
  <caption>Đây là mức đối chiếu điểm theo tháng, chưa phải quyết định xếp loại viên chức cuối năm.</caption>
</box>

## ⚠️ 4. Những nội dung cần chỉnh để Quy chế chặt chẽ hơn

Qua rà soát, tôi đề nghị nhà trường chỉnh thêm ba nội dung trước khi ban hành.

**Thứ nhất, sửa mức điểm A1.2 ở cả bảng giáo viên và nhân viên.** Hiện quy định “2–3 vi phạm nhẹ” được 2 điểm nhưng “từ 3 sai sót” lại được 0 điểm, khiến trường hợp có đúng 3 sai sót bị trùng hai mức chấm. Nên thống nhất: 2 điểm khi có đúng 2 vi phạm nhẹ; 0 điểm khi có từ 3 vi phạm nhẹ hoặc vi phạm nghiêm trọng được xác minh.

**Thứ hai, hoàn chỉnh quy định xử lý tiêu chí không phát sinh nhiệm vụ.** Đặc biệt đối với y tế, bảo vệ và thủ quỹ, tháng không xảy ra sự cố không đồng nghĩa với không hoàn thành công việc. Nên đánh giá nhiệm vụ thường xuyên và trạng thái sẵn sàng. Với tiêu chí thực sự không áp dụng, có thể đề xuất quy đổi điểm trong cùng nhóm theo công thức:

\[
\text{Điểm nhóm quy đổi}=
\frac{\text{Tổng điểm đạt của tiêu chí áp dụng}}
{\text{Tổng điểm tối đa của tiêu chí áp dụng}}
\times\text{Điểm tối đa của nhóm}
\]

Cách quy đổi này cần được nhà trường thống nhất, ghi rõ trong Quy chế và áp dụng đồng nhất, không tùy nghi từng cá nhân.

**Thứ ba, chỉnh các tiêu đề bị trùng ở cuối Phụ lục II.** Phần “8. C. TIÊU CHÍ KẾT QUẢ THỰC HIỆN NHIỆM VỤ – NHÂN VIÊN 70 ĐIỂM” hiện chỉ lặp lại bảng tổng hợp đã có trong Điều 8. Có thể đổi thành “BẢNG TỔNG HỢP CƠ CẤU ĐIỂM KPI NHÂN VIÊN”. Đồng thời sửa “D. E. QUY ƯỚC THEO DÕI ĐỊNH KỲ” thành “III. QUY ƯỚC THEO DÕI, ĐÁNH GIÁ ĐỊNH KỲ”.

## ✅ 5. Kết luận và đề xuất của Hiệu trưởng

Với phần bổ sung này, hệ thống KPI của nhà trường đã có thể xác định điểm cụ thể cho từng vị trí nhân viên trên cùng thang 100 điểm, đồng thời chú trọng các yêu cầu đặc thù về an toàn trẻ, vệ sinh thực phẩm, tài chính và bảo mật thông tin.

Trước khi đưa vào thực hiện chính thức, nên cho tổ văn phòng và đại diện từng vị trí việc làm thử chấm trên một tháng công tác thực tế; đối chiếu những tiêu chí khó có minh chứng hoặc không phát sinh nhiệm vụ để hoàn thiện quy định. Việc này giúp bảo đảm công bằng giữa nhân viên có khối lượng, tính chất công việc khác nhau.

**Điểm quan trọng nhất:** KPI phải phản ánh đúng mức độ hoàn thành công việc, không chỉ là bảng trừ điểm sai sót. Điểm theo dõi hằng tháng là căn cứ đánh giá; việc xếp loại cuối năm, nhất là mức hoàn thành xuất sắc, còn phải đáp ứng các điều kiện và tỷ lệ theo Nghị định số 233/2026/NĐ-CP. <Cite ref="turn826794search5"/>

---

USER

dùng từ mức sẽ khó hiểu. bạn có thể cụ thể như nội dung của giáo viên không

---

ASSISTANT

Tôi hiểu ý: thay vì ghi “mức 1, mức 2”, từng tiêu chí phải viết rõ như bảng giáo viên, chẳng hạn “12 điểm: Hoàn thành 100%”, “9 điểm: Từ 90% đến dưới 100%”… Tôi sẽ trình bày trực tiếp theo từng mã B1.1 đến B4.2, giữ nguyên điểm tối đa và nội dung công việc của từng vị trí trong dự thảo.

---

ASSISTANT

Đúng như vậy. Để nhân viên dễ tự chấm, tổ trưởng dễ kiểm tra và Ban Giám hiệu dễ thống nhất điểm, **mỗi tiêu chí cần ghi trực tiếp: “12 điểm:…; 9 điểm:…; 5 điểm:…; 0 điểm:…”**, giống Phụ lục I của giáo viên, chứ không chỉ quy định các mức điểm chung.

Tôi cụ thể hóa dưới đây theo đúng **9 tiêu chí B1.1 đến B4.2 của từng vị trí** trong dự thảo. Nhà trường giữ nguyên cột minh chứng đã xây dựng và bổ sung các nội dung sau vào cột **“Quy định điểm”**.

> **writing · document**
>
> # BỔ SUNG CÁCH CHẤM ĐIỂM KPI NHÂN VIÊN HẰNG THÁNG
>
> ## II. KPI THEO TỪNG VỊ TRÍ NHÂN VIÊN – 70 ĐIỂM
>
> ### 1. Nhân viên nuôi dưỡng, cấp dưỡng (70 điểm)
>
> **B1. Số lượng, khối lượng nhiệm vụ (20 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B1.1.** Thực hiện ca chế biến, bữa ăn và công đoạn được phân công | 12 | **12 điểm:** Thực hiện 100% ca, bữa ăn và công đoạn được giao. **9 điểm:** Hoàn thành từ 90% đến dưới 100%. **5 điểm:** Hoàn thành từ 70% đến dưới 90%. **0 điểm:** Hoàn thành dưới 70%. |
> | **B1.2.** Tiếp nhận thực phẩm, sơ chế, chia suất, thu dọn | 8 | **8 điểm:** Hoàn thành 100% đầu việc được phân công. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **B2. Chất lượng, hiệu quả thực hiện (30 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B2.1.** Thực hiện quy trình an toàn thực phẩm, vệ sinh cá nhân, bảo hộ, phòng ngừa nhiễm chéo | 12 | **12 điểm:** Thực hiện đúng tất cả quy trình, không có sai sót. **9 điểm:** Có 1 sai sót nhẹ không gây nguy cơ mất an toàn thực phẩm, được khắc phục ngay. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có 1 vi phạm nghiêm trọng về an toàn thực phẩm được xác minh. |
> | **B2.2.** Thực đơn, định lượng, chia suất, kiểm thực và lưu mẫu thức ăn | 10 | **10 điểm:** Thực hiện đúng, đầy đủ, chính xác, không sai sót. **8 điểm:** Có 1 sai sót nhẹ về kiểm đếm hoặc ghi chép, được khắc phục kịp thời, không ảnh hưởng bữa ăn. **4 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về chế biến, định lượng, kiểm thực, lưu mẫu được xác minh. |
> | **B2.3.** Vệ sinh dụng cụ, bảo quản thực phẩm, khu vực bếp và thu gom rác | 8 | **8 điểm:** Thực hiện đúng toàn bộ yêu cầu, không sai sót. **6 điểm:** Có 1 sai sót vệ sinh nhẹ, khắc phục ngay. **3 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng gây nguy cơ mất vệ sinh, an toàn thực phẩm được xác minh. |
>
> **B3. Tiến độ thực hiện (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B3.1.** Hoàn thành, bàn giao suất ăn đúng giờ | 6 | **6 điểm:** 100% bữa ăn được hoàn thành, bàn giao đúng giờ. **4 điểm:** Có 1 lần chậm không quá 5 phút do nguyên nhân chủ quan, chưa ảnh hưởng giờ ăn của trẻ. **2 điểm:** Có 2 lần chậm không quá 5 phút hoặc 1 lần chậm trên 5 phút nhưng chưa ảnh hưởng giờ ăn. **0 điểm:** Từ 3 lần chậm hoặc có lần chậm làm ảnh hưởng hoạt động ăn của trẻ do lỗi thuộc trách nhiệm cá nhân. |
> | **B3.2.** Ghi nhận kiểm thực, lưu mẫu, giao nhận và hoàn tất hồ sơ | 4 | **4 điểm:** Thực hiện đầy đủ, đúng thời điểm và quy trình. **3 điểm:** Có 1 lần chậm hoàn tất ghi chép hành chính, nhưng việc kiểm thực, lưu mẫu vẫn đúng quy định. **1 điểm:** Có 2 lần chậm ghi chép hành chính. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện kiểm thực, lưu mẫu bắt buộc đúng quy định. |
>
> **B4. Phối hợp, phục vụ, cải tiến (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B4.1.** Phối hợp giáo viên, y tế và tổ bếp | 6 | **6 điểm:** Hoàn thành đầy đủ công việc phối hợp, không phải nhắc nhở. **4 điểm:** Có 1 lần chưa chủ động phối hợp, phải nhắc. **2 điểm:** Có 2 lần phải nhắc. **0 điểm:** Từ 3 lần phải nhắc hoặc không thực hiện nhiệm vụ phối hợp hợp lệ mà không có lý do chính đáng. |
> | **B4.2.** Tiết kiệm nguyên liệu, giảm hao hụt, bảo quản tài sản | 4 | **4 điểm:** Hoàn thành 100% nội dung được giao, có kết quả hoặc ghi nhận thực tế. **3 điểm:** Hoàn thành từ 90% đến dưới 100%. **1 điểm:** Hoàn thành từ 70% đến dưới 90%. **0 điểm:** Hoàn thành dưới 70% nhiệm vụ được giao. |
>
> **Tổng B1 + B2 + B3 + B4: 70 điểm.**
>
> ---
>
> ### 2. Nhân viên y tế (70 điểm)
>
> **B1. Số lượng, khối lượng nhiệm vụ (20 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B1.1.** Theo dõi sức khỏe, cân đo, quản lý hồ sơ và chăm sóc sức khỏe ban đầu | 12 | **12 điểm:** Hoàn thành 100% hoạt động và hồ sơ đến hạn theo kế hoạch. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2.** Truyền thông, vệ sinh, phòng chống dịch bệnh, tham mưu y tế | 8 | **8 điểm:** Thực hiện đầy đủ 100% nhiệm vụ được phân công. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **B2. Chất lượng, hiệu quả thực hiện (30 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B2.1.** Sơ cứu, chăm sóc sức khỏe ban đầu, ghi nhận, chuyển tuyến đúng thẩm quyền | 12 | **12 điểm:** Thực hiện đúng quy trình đối với các trường hợp phát sinh; hồ sơ đầy đủ, không sai sót. **9 điểm:** Có 1 sai sót nhẹ về ghi chép, được sửa ngay, không ảnh hưởng xử lý sức khỏe. **5 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về sơ cứu, xử lý, chuyển tuyến hoặc vượt phạm vi chuyên môn được xác minh. |
> | **B2.2.** Phát hiện, theo dõi dấu hiệu sức khỏe bất thường, nguy cơ dịch bệnh | 10 | **10 điểm:** Theo dõi, phát hiện, thông tin và hướng dẫn phối hợp đầy đủ, chính xác, kịp thời. **8 điểm:** Có 1 sai sót nhẹ trong cập nhật thông tin theo dõi, đã khắc phục. **4 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc bỏ sót, không báo cáo nguy cơ nghiêm trọng thuộc trách nhiệm được xác minh. |
> | **B2.3.** Quản lý tủ thuốc, vật tư y tế, hạn sử dụng và hồ sơ sức khỏe | 8 | **8 điểm:** Quản lý đầy đủ, chính xác, an toàn, không sai sót. **6 điểm:** Có 1 sai sót nhẹ về sắp xếp, ghi chép hoặc kiểm kê, khắc phục trước khi sử dụng. **3 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc để xảy ra vi phạm nghiêm trọng về sử dụng thuốc, bảo quản vật tư hoặc bảo mật thông tin được xác minh. |
>
> **B3. Tiến độ thực hiện (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B3.1.** Tiếp nhận, xử lý, báo cáo tình huống sức khỏe, an toàn khẩn cấp | 6 | **6 điểm:** Tiếp nhận, xử lý, báo cáo 100% tình huống phát sinh đúng thời điểm và quy trình; nếu không phát sinh thì bảo đảm việc theo dõi và sẵn sàng xử lý. **4 điểm:** Có 1 lần chậm cập nhật hồ sơ sau xử lý nhưng việc sơ cứu, báo cáo khẩn cấp vẫn kịp thời. **2 điểm:** Có 2 lần chậm cập nhật hồ sơ sau xử lý. **0 điểm:** Từ 3 lần chậm cập nhật hoặc có 1 tình huống khẩn cấp không được tiếp nhận, xử lý, báo cáo kịp thời do lỗi thuộc trách nhiệm. |
> | **B3.2.** Hoàn thành báo cáo y tế, tổng hợp sức khỏe đúng hạn | 4 | **4 điểm:** 100% báo cáo, hồ sơ đúng thời hạn. **3 điểm:** Có 1 báo cáo nội bộ chậm không quá 1 ngày, không ảnh hưởng thời hạn bắt buộc. **1 điểm:** Có 2 báo cáo nội bộ chậm hoặc 1 báo cáo chậm trên 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện báo cáo bắt buộc theo quy định. |
>
> **B4. Phối hợp, phục vụ, cải tiến (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B4.1.** Phối hợp giáo viên, phụ huynh, cấp dưỡng, cơ sở y tế | 6 | **6 điểm:** Thực hiện đầy đủ, kịp thời mọi nhiệm vụ phối hợp thuộc trách nhiệm. **4 điểm:** Có 1 lần phối hợp chưa kịp thời, phải nhắc nhở. **2 điểm:** Có 2 lần phải nhắc. **0 điểm:** Từ 3 lần phải nhắc hoặc không thực hiện nhiệm vụ phối hợp hợp lệ, gây ảnh hưởng công việc. |
> | **B4.2.** Tuyên truyền, tư vấn, hướng dẫn chăm sóc sức khỏe, phòng bệnh | 4 | **4 điểm:** Hoàn thành 100% nội dung được giao, thông tin chính xác, phù hợp. **3 điểm:** Hoàn thành từ 90% đến dưới 100%. **1 điểm:** Hoàn thành từ 70% đến dưới 90%. **0 điểm:** Dưới 70% hoặc cung cấp thông tin sai nghiêm trọng, gây nguy cơ ảnh hưởng sức khỏe được xác minh. |
>
> **Tổng: 70 điểm.**
>
> ---
>
> ### 3. Nhân viên kế toán (70 điểm)
>
> **B1. Số lượng, khối lượng nhiệm vụ (20 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B1.1.** Tiếp nhận, kiểm tra, xử lý chứng từ và nghiệp vụ kế toán hợp lệ | 12 | **12 điểm:** Xử lý 100% chứng từ, nghiệp vụ thuộc trách nhiệm đến hạn. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2.** Lập báo cáo tài chính, thu chi, dự toán, quyết toán theo kỳ | 8 | **8 điểm:** Hoàn thành 100% báo cáo, bảng tổng hợp và nhiệm vụ đến hạn. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **B2. Chất lượng, hiệu quả thực hiện (30 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B2.1.** Hạch toán, kiểm tra chứng từ, bảo đảm số liệu chính xác, hợp pháp | 12 | **12 điểm:** Hạch toán, kiểm tra đầy đủ, chính xác, không sai sót. **9 điểm:** Có 1 sai sót kỹ thuật nhẹ, tự phát hiện hoặc được phát hiện và sửa trước khi hoàn tất nghiệp vụ. **5 điểm:** Có 2 sai sót nhẹ, đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có sai phạm nghiêm trọng về chứng từ, hạch toán, số liệu được xác minh. |
> | **B2.2.** Đối chiếu thu, chi, công nợ, tạm ứng với các bộ phận liên quan | 10 | **10 điểm:** Đối chiếu đầy đủ, chính xác, không có chênh lệch chưa được giải trình. **8 điểm:** Có 1 sai sót số liệu nhẹ được phát hiện, điều chỉnh kịp thời. **4 điểm:** Có 2 sai sót nhẹ đã được xử lý. **0 điểm:** Từ 3 sai sót hoặc để chênh lệch nghiêm trọng không được xử lý do lỗi thuộc trách nhiệm. |
> | **B2.3.** Lưu trữ hồ sơ, bảo mật, công khai và giải trình tài chính | 8 | **8 điểm:** Thực hiện đầy đủ, đúng quy định, hồ sơ khoa học, dễ tra cứu. **6 điểm:** Có 1 thiếu sót nhẹ trong sắp xếp, lưu trữ hoặc trình bày, khắc phục ngay. **3 điểm:** Có 2 thiếu sót nhẹ đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc vi phạm nghiêm trọng về bảo mật, công khai, lưu trữ được xác minh. |
>
> **B3. Tiến độ thực hiện (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B3.1.** Hoàn thành chứng từ, báo cáo, các mốc tài chính đúng hạn | 6 | **6 điểm:** Hoàn thành 100% đúng thời hạn. **4 điểm:** Có 1 công việc chậm thời hạn nội bộ không quá 1 ngày, không vi phạm thời hạn pháp luật. **2 điểm:** Có 2 công việc chậm hoặc 1 công việc chậm trên 1 ngày. **0 điểm:** Từ 3 công việc chậm hoặc không đáp ứng thời hạn bắt buộc theo quy định do lỗi thuộc trách nhiệm. |
> | **B3.2.** Tiếp nhận, phản hồi, xử lý đề nghị thanh toán, điều chỉnh chứng từ hợp lệ | 4 | **4 điểm:** 100% yêu cầu được tiếp nhận, xử lý hoặc phản hồi đúng hạn. **3 điểm:** Có 1 yêu cầu chậm không quá 1 ngày. **1 điểm:** Có 2 yêu cầu chậm hoặc 1 yêu cầu chậm trên 1 ngày. **0 điểm:** Từ 3 yêu cầu chậm hoặc không xử lý, phản hồi nhiệm vụ bắt buộc. |
>
> **B4. Phối hợp, phục vụ, cải tiến (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B4.1.** Hướng dẫn, phối hợp hoàn thiện hồ sơ tài chính | 6 | **6 điểm:** Thực hiện đầy đủ, chính xác, chủ động, không phải nhắc. **4 điểm:** Có 1 lần chậm phối hợp, phải nhắc. **2 điểm:** Có 2 lần phải nhắc. **0 điểm:** Từ 3 lần phải nhắc hoặc không phối hợp thực hiện nhiệm vụ hợp lệ. |
> | **B4.2.** Số hóa dữ liệu, cải tiến nghiệp vụ, kiểm soát chi phí, tiết kiệm nguồn lực | 4 | **4 điểm:** Hoàn thành 100% nội dung được giao, có sản phẩm hoặc kết quả ghi nhận. **3 điểm:** Từ 90% đến dưới 100%. **1 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **Tổng: 70 điểm.**
>
> ---
>
> ### 4. Nhân viên văn thư (70 điểm)
>
> **B1. Số lượng, khối lượng nhiệm vụ (20 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B1.1.** Tiếp nhận, đăng ký, phân phối, theo dõi văn bản đến và đi | 12 | **12 điểm:** Hoàn thành 100% văn bản, đầu việc thuộc trách nhiệm. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2.** Soạn thảo, phát hành, lập hồ sơ, sắp xếp và số hóa tài liệu | 8 | **8 điểm:** Hoàn thành 100% nhiệm vụ được phân công. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **B2. Chất lượng, hiệu quả thực hiện (30 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B2.1.** Kiểm tra thể thức, số hiệu, nơi nhận, thông tin và bảo mật văn bản | 12 | **12 điểm:** 100% văn bản thuộc trách nhiệm được kiểm tra chính xác, đúng thể thức, không sai sót. **9 điểm:** Có 1 sai sót kỹ thuật nhẹ, được khắc phục trước khi phát hành. **5 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng về phát hành, thông tin, nơi nhận, bảo mật được xác minh. |
> | **B2.2.** Quản lý con dấu, chữ ký số, hệ thống văn bản điện tử | 10 | **10 điểm:** Quản lý, sử dụng đúng quy trình, đúng thẩm quyền, không sai sót. **8 điểm:** Có 1 thiếu sót nhẹ về ghi nhận, cập nhật nhật ký quản lý, khắc phục ngay. **4 điểm:** Có 2 thiếu sót nhẹ đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc có hành vi sử dụng con dấu, chữ ký số trái thẩm quyền, sai quy định được xác minh. |
> | **B2.3.** Lập hồ sơ, sắp xếp, lưu trữ, tra cứu tài liệu | 8 | **8 điểm:** Hồ sơ đầy đủ, khoa học, đúng quy định, dễ tra cứu. **6 điểm:** Có 1 thiếu sót nhẹ về sắp xếp hoặc lập danh mục, đã khắc phục. **3 điểm:** Có 2 thiếu sót nhẹ đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc mất, thất lạc hồ sơ do lỗi thuộc trách nhiệm được xác minh. |
>
> **B3. Tiến độ thực hiện (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B3.1.** Chuyển văn bản, thông tin chỉ đạo đúng thời hạn | 6 | **6 điểm:** Chuyển 100% văn bản đúng thời hạn, văn bản khẩn được xử lý đúng quy định. **4 điểm:** Có 1 văn bản thông thường chuyển chậm so với thời hạn nội bộ, không ảnh hưởng tiến độ xử lý. **2 điểm:** Có 2 văn bản thông thường chuyển chậm. **0 điểm:** Từ 3 văn bản chuyển chậm hoặc có văn bản khẩn không được chuyển kịp thời do lỗi thuộc trách nhiệm. |
> | **B3.2.** Phát hành, nộp lưu và bàn giao hồ sơ đúng tiến độ | 4 | **4 điểm:** 100% nhiệm vụ hoàn thành đúng hạn. **3 điểm:** Có 1 lần chậm không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm trên 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện nhiệm vụ bắt buộc. |
>
> **B4. Phối hợp, phục vụ, cải tiến (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B4.1.** Phối hợp cung cấp văn bản, mẫu biểu, xử lý thủ tục hành chính | 6 | **6 điểm:** Hoàn thành đầy đủ các yêu cầu hợp lệ, phối hợp chủ động. **4 điểm:** Có 1 lần phải nhắc nhở. **2 điểm:** Có 2 lần phải nhắc. **0 điểm:** Từ 3 lần phải nhắc hoặc không thực hiện nhiệm vụ phối hợp hợp lệ. |
> | **B4.2.** Cải tiến quản lý văn bản, lưu trữ số và tra cứu dữ liệu | 4 | **4 điểm:** Hoàn thành 100% công việc cải tiến hoặc duy trì giải pháp được giao, có sản phẩm, kết quả. **3 điểm:** Từ 90% đến dưới 100%. **1 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **Tổng: 70 điểm.**
>
> ---
>
> ### 5. Nhân viên thủ quỹ (70 điểm)
>
> **B1. Số lượng, khối lượng nhiệm vụ (20 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B1.1.** Thực hiện nghiệp vụ thu, chi tiền mặt hợp lệ | 12 | **12 điểm:** Hoàn thành 100% nghiệp vụ thu, chi hợp lệ đến hạn thuộc trách nhiệm. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2.** Cập nhật sổ quỹ, kiểm đếm, bàn giao tiền và chứng từ | 8 | **8 điểm:** Hoàn thành đầy đủ 100% nhiệm vụ được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **B2. Chất lượng, hiệu quả thực hiện (30 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B2.1.** Bảo đảm tiền thực tế khớp sổ quỹ, chứng từ; bảo quản tiền, tài sản | 12 | **12 điểm:** Quỹ tiền mặt khớp sổ sách, chứng từ, được bảo quản an toàn, không sai sót. **9 điểm:** Có 1 sai sót ghi chép nhẹ được điều chỉnh trước khi chốt đối chiếu, không phát sinh thiếu quỹ. **5 điểm:** Có 2 sai sót ghi chép nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có sai phạm nghiêm trọng về quản lý tiền, tài sản được xác minh. |
> | **B2.2.** Kiểm tra chứng từ, giao nhận, ký nhận đúng quy định | 10 | **10 điểm:** Thực hiện đúng, đầy đủ, chính xác, không sai sót. **8 điểm:** Có 1 thiếu sót kỹ thuật nhẹ, khắc phục trước khi thực hiện giao dịch. **4 điểm:** Có 2 thiếu sót nhẹ đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc thực hiện giao dịch trái quy định được xác minh. |
> | **B2.3.** Bảo mật, lưu chứng từ, đối chiếu quỹ với kế toán | 8 | **8 điểm:** Thực hiện đầy đủ, chính xác, đúng quy trình, không sai sót. **6 điểm:** Có 1 sai sót nhẹ về lưu trữ hoặc ghi chép, đã khắc phục. **3 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng về bảo mật, lưu trữ, đối chiếu quỹ được xác minh. |
>
> **B3. Tiến độ thực hiện (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B3.1.** Thực hiện giao dịch hợp lệ đúng thời hạn | 6 | **6 điểm:** 100% giao dịch hợp lệ được thực hiện đúng hạn. **4 điểm:** Có 1 giao dịch chậm theo thời hạn nội bộ không quá 1 ngày, không ảnh hưởng thời hạn bắt buộc. **2 điểm:** Có 2 giao dịch chậm hoặc 1 giao dịch chậm trên 1 ngày. **0 điểm:** Từ 3 giao dịch chậm hoặc không thực hiện giao dịch bắt buộc do lỗi thuộc trách nhiệm. |
> | **B3.2.** Hoàn tất sổ quỹ, báo cáo, bàn giao và đối chiếu | 4 | **4 điểm:** 100% công việc đúng thời hạn. **3 điểm:** Có 1 lần chậm không quá 1 ngày. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm trên 1 ngày. **0 điểm:** Từ 3 lần chậm hoặc không thực hiện nhiệm vụ bắt buộc. |
>
> **B4. Phối hợp, phục vụ, cải tiến (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B4.1.** Phối hợp kế toán, Ban Giám hiệu và các bộ phận | 6 | **6 điểm:** Phối hợp đầy đủ, chính xác, chủ động. **4 điểm:** Có 1 lần chưa phối hợp kịp thời, phải nhắc. **2 điểm:** Có 2 lần phải nhắc. **0 điểm:** Từ 3 lần phải nhắc hoặc không thực hiện nhiệm vụ phối hợp hợp lệ. |
> | **B4.2.** Kiểm soát chênh lệch, cải tiến quản lý tiền mặt và chứng từ | 4 | **4 điểm:** Hoàn thành 100% nhiệm vụ được giao, có kết quả hoặc minh chứng thực hiện. **3 điểm:** Từ 90% đến dưới 100%. **1 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **Tổng: 70 điểm.**
>
> ---
>
> ### 6. Nhân viên bảo vệ (70 điểm)
>
> **B1. Số lượng, khối lượng nhiệm vụ (20 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B1.1.** Thực hiện các ca trực được phân công | 12 | **12 điểm:** Thực hiện đầy đủ 100% ca trực hợp lệ được phân công. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2.** Kiểm soát cổng, tuần tra, kiểm tra khu vực và tài sản | 8 | **8 điểm:** Hoàn thành 100% lượt kiểm tra, tuần tra theo phân công. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **B2. Chất lượng, hiệu quả thực hiện (30 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B2.1.** Kiểm soát cổng, người ra vào, phối hợp đón trả trẻ | 12 | **12 điểm:** Thực hiện đúng quy trình trong tất cả ca trực, không sai sót. **9 điểm:** Có 1 thiếu sót nhẹ về ghi nhận, kiểm tra thông tin, khắc phục ngay, chưa gây nguy cơ mất an toàn. **5 điểm:** Có 2 thiếu sót nhẹ đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc để xảy ra vi phạm nghiêm trọng trong kiểm soát cổng, người ra vào, đón trả trẻ thuộc trách nhiệm được xác minh. |
> | **B2.2.** Kiểm tra phòng cháy, chữa cháy, lối thoát hiểm, báo nguy cơ | 10 | **10 điểm:** Kiểm tra đầy đủ, đúng quy trình, kịp thời báo cáo nguy cơ, không sai sót. **8 điểm:** Có 1 sai sót nhẹ về ghi nhận kiểm tra, đã khắc phục. **4 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc không kiểm tra, báo cáo nguy cơ nghiêm trọng thuộc trách nhiệm được xác minh. |
> | **B2.3.** Kiểm tra khóa cửa, điện, nước, tài sản và khuôn viên | 8 | **8 điểm:** Thực hiện đầy đủ, không để sai sót thuộc trách nhiệm. **6 điểm:** Có 1 thiếu sót nhẹ, phát hiện và khắc phục kịp thời. **3 điểm:** Có 2 thiếu sót nhẹ đã khắc phục. **0 điểm:** Từ 3 thiếu sót hoặc có vi phạm nghiêm trọng gây nguy cơ mất an toàn, mất tài sản được xác minh. |
>
> **B3. Tiến độ thực hiện (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B3.1.** Phát hiện, báo cáo, phối hợp xử lý nguy cơ an ninh, an toàn | 6 | **6 điểm:** 100% tình huống phát sinh được báo cáo, xử lý đúng thời điểm; nếu không phát sinh thì thực hiện đầy đủ việc kiểm tra, sẵn sàng ứng phó. **4 điểm:** Có 1 lần chậm báo cáo sự việc không khẩn cấp, chưa ảnh hưởng an toàn. **2 điểm:** Có 2 lần chậm báo cáo sự việc không khẩn cấp. **0 điểm:** Từ 3 lần chậm hoặc không báo cáo, xử lý kịp thời nguy cơ nghiêm trọng thuộc trách nhiệm. |
> | **B3.2.** Kiểm tra cuối ca, bàn giao, hoàn thành mốc công việc | 4 | **4 điểm:** Hoàn thành đầy đủ, đúng giờ tất cả ca trực. **3 điểm:** Có 1 lần bàn giao hoặc ghi sổ chậm không quá 15 phút, không làm gián đoạn nhiệm vụ. **1 điểm:** Có 2 lần chậm hoặc 1 lần chậm trên 15 phút. **0 điểm:** Từ 3 lần chậm hoặc tự ý bỏ ca, không bàn giao theo quy định. |
>
> **B4. Phối hợp, phục vụ, cải tiến (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B4.1.** Phối hợp Ban Giám hiệu, giáo viên, nhân viên và bộ phận liên quan | 6 | **6 điểm:** Phối hợp đầy đủ, chủ động, không phải nhắc. **4 điểm:** Có 1 lần phối hợp chưa kịp thời, phải nhắc. **2 điểm:** Có 2 lần phải nhắc. **0 điểm:** Từ 3 lần phải nhắc hoặc không thực hiện nhiệm vụ phối hợp hợp lệ. |
> | **B4.2.** Phòng ngừa nguy cơ, cải thiện an ninh, bảo vệ tài sản | 4 | **4 điểm:** Hoàn thành 100% công việc phòng ngừa, khắc phục, cải tiến được giao, có kết quả. **3 điểm:** Từ 90% đến dưới 100%. **1 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **Tổng: 70 điểm.**
>
> ---
>
> ### 7. Nhân viên phục vụ, vệ sinh (70 điểm)
>
> **B1. Số lượng, khối lượng nhiệm vụ (20 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B1.1.** Vệ sinh khu vực, ca và hạng mục được giao | 12 | **12 điểm:** Hoàn thành 100% khu vực, lượt và hạng mục vệ sinh. **9 điểm:** Từ 90% đến dưới 100%. **5 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
> | **B1.2.** Thu gom rác, bổ sung vật tư, vệ sinh dụng cụ, phục vụ theo phân công | 8 | **8 điểm:** Hoàn thành 100% nhiệm vụ được giao. **6 điểm:** Từ 90% đến dưới 100%. **3 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **B2. Chất lượng, hiệu quả thực hiện (30 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B2.1.** Bảo đảm khu vực sạch sẽ, không rác tồn đọng, nước đọng, mất vệ sinh | 12 | **12 điểm:** Tất cả khu vực được giao đạt yêu cầu vệ sinh, không sai sót. **9 điểm:** Có 1 vị trí chưa đạt vệ sinh, được khắc phục ngay trước khi ảnh hưởng hoạt động của trẻ. **5 điểm:** Có 2 vị trí hoặc 2 lượt kiểm tra phát hiện sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc để xảy ra tình trạng mất vệ sinh nghiêm trọng thuộc trách nhiệm được xác minh. |
> | **B2.2.** Sử dụng dụng cụ, hóa chất vệ sinh đúng hướng dẫn, bảo đảm an toàn | 10 | **10 điểm:** Sử dụng, bảo quản đúng, không sai sót; trẻ không tiếp cận vật dụng nguy hiểm. **8 điểm:** Có 1 sai sót nhẹ về sắp xếp, ghi nhãn, được khắc phục trước khi sử dụng, không gây nguy cơ cho trẻ. **4 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc vi phạm nghiêm trọng khiến trẻ có nguy cơ tiếp xúc hóa chất, dụng cụ nguy hiểm được xác minh. |
> | **B2.3.** Phân loại, thu gom rác, phòng ngừa lây nhiễm chéo, trơn trượt | 8 | **8 điểm:** Thực hiện đúng quy trình, không sai sót. **6 điểm:** Có 1 sai sót nhẹ, khắc phục ngay. **3 điểm:** Có 2 sai sót nhẹ đã khắc phục. **0 điểm:** Từ 3 sai sót hoặc có vi phạm nghiêm trọng gây nguy cơ lây nhiễm, trơn trượt được xác minh. |
>
> **B3. Tiến độ thực hiện (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B3.1.** Hoàn thành vệ sinh trước các thời điểm yêu cầu | 6 | **6 điểm:** Hoàn thành 100% khu vực đúng thời gian, không ảnh hưởng hoạt động của trẻ. **4 điểm:** Có 1 lần chậm không quá 10 phút, chưa ảnh hưởng hoạt động. **2 điểm:** Có 2 lần chậm không quá 10 phút hoặc 1 lần chậm trên 10 phút nhưng chưa ảnh hưởng hoạt động. **0 điểm:** Từ 3 lần chậm hoặc chậm trễ gây ảnh hưởng hoạt động chăm sóc, giáo dục trẻ do lỗi thuộc trách nhiệm. |
> | **B3.2.** Phản hồi, xử lý công việc vệ sinh phát sinh | 4 | **4 điểm:** Tiếp nhận và xử lý 100% nhiệm vụ phát sinh đúng thời hạn được giao. **3 điểm:** Có 1 nhiệm vụ thông thường xử lý chậm, đã khắc phục, không gây ảnh hưởng. **1 điểm:** Có 2 nhiệm vụ thông thường xử lý chậm. **0 điểm:** Từ 3 nhiệm vụ chậm hoặc không xử lý kịp thời tình huống vệ sinh, an toàn khẩn cấp thuộc trách nhiệm. |
>
> **B4. Phối hợp, phục vụ, cải tiến (10 điểm)**
>
> | Mã số | Điểm tối đa | Quy định điểm |
> |---|---:|---|
> | **B4.1.** Phối hợp giáo viên, bảo vệ và bộ phận liên quan | 6 | **6 điểm:** Phối hợp đầy đủ, đúng yêu cầu, không phải nhắc. **4 điểm:** Có 1 lần phải nhắc nhở. **2 điểm:** Có 2 lần phải nhắc. **0 điểm:** Từ 3 lần phải nhắc hoặc không thực hiện công việc phối hợp hợp lệ. |
> | **B4.2.** Tiết kiệm vật tư, bảo quản dụng cụ, phòng ngừa điểm mất an toàn | 4 | **4 điểm:** Hoàn thành 100% nhiệm vụ được giao, có kết quả thực tế. **3 điểm:** Từ 90% đến dưới 100%. **1 điểm:** Từ 70% đến dưới 90%. **0 điểm:** Dưới 70%. |
>
> **Tổng: 70 điểm.**
>
> ---
>
> ## III. HƯỚNG DẪN CÁCH TÍNH VÀ CHẤM ĐIỂM THỐNG NHẤT
>
> **1. Cách tính tỷ lệ hoàn thành nhiệm vụ**
>
> Tỷ lệ hoàn thành (%) = (Số đầu việc hoàn thành đạt yêu cầu / Tổng số đầu việc được giao hợp lệ đến hạn) × 100%.
>
> Ví dụ: Nhân viên cấp dưỡng được giao 25 đầu việc theo lịch và phân công trong tháng; hoàn thành đạt yêu cầu 24 đầu việc.
>
> Tỷ lệ = 24/25 × 100 = 96%.
>
> Đối chiếu tiêu chí B1.1: Được **9/12 điểm**.
>
> **2. Xác định sai sót nhẹ**
>
> Sai sót nhẹ là thiếu sót về thao tác phụ, ghi chép, sắp xếp, cập nhật thông tin hoặc thực hiện công việc chưa đầy đủ, có thể khắc phục ngay; chưa gây hậu quả và không thuộc hành vi vi phạm nghiêm trọng về an toàn, tài chính, bảo mật hoặc quy định pháp luật.
>
> **3. Nguyên tắc xác định sai sót**
>
> Chỉ tính những sai sót đã được kiểm tra, ghi nhận hoặc xác minh, thuộc trách nhiệm cá nhân. Không sử dụng phản ánh chưa xác minh làm căn cứ trừ điểm. Một sai sót không được tính thành nhiều lần trong cùng một tiêu chí.
>
> **4. Trường hợp không phát sinh nhiệm vụ**
>
> Đối với nhiệm vụ đột xuất như xử lý trẻ bị tai nạn, sự cố an ninh, báo cáo nguy cơ hoặc công việc phát sinh khác, nếu trong tháng không xảy ra sự việc thì không xem đó là nhiệm vụ chưa hoàn thành. Nhân viên được chấm điểm căn cứ vào việc thực hiện nhiệm vụ thường xuyên, chuẩn bị điều kiện, kiểm tra phòng ngừa và khả năng sẵn sàng thực hiện trách nhiệm.
>
> **5. Điều chỉnh nhiệm vụ hợp lệ**
>
> Không tính vào số công việc chưa hoàn thành đối với nhiệm vụ đã được cấp có thẩm quyền điều chỉnh, hủy bỏ, chuyển giao do nghỉ chế độ hợp lệ hoặc do nguyên nhân khách quan được xác nhận. Các công việc được giao bổ sung phải xác định rõ thời hạn và yêu cầu hoàn thành.
>
> **6. Đối với nhiệm vụ cải tiến**
>
> Không bắt buộc mỗi nhân viên phải xây dựng một sáng kiến mới hằng tháng. Có thể đánh giá việc thực hiện, duy trì hiệu quả các biện pháp cải tiến, tiết kiệm, số hóa, sắp xếp hoặc phòng ngừa nguy cơ đã được đưa vào kế hoạch và giao nhiệm vụ.
>
> **7. Xử lý vi phạm nghiêm trọng**
>
> Việc chấm 0 điểm ở một tiêu chí không thay thế quy trình xem xét, xác minh, xử lý vi phạm và xếp loại chất lượng viên chức theo quy định pháp luật. Những hành vi vi phạm nghiêm trọng cần được xem xét độc lập về tính chất, mức độ, hậu quả và trách nhiệm.

## 💡 Đề xuất của Hiệu trưởng trước khi ban hành

Bảng trên đã cụ thể hóa đầy đủ **63 tiêu chí chấm điểm thuộc 7 vị trí nhân viên**, với tổng điểm tối đa mỗi vị trí là 70 điểm, phù hợp cơ cấu trong dự thảo.

Tôi đề nghị nhà trường lưu ý thêm ba vấn đề:

- **Thống nhất cách chấm:** Với tiêu chí khối lượng dùng tỷ lệ hoàn thành; với tiêu chí chất lượng dùng số lần sai sót và mức độ ảnh hưởng; với tiêu chí tiến độ dùng thời hạn cụ thể. Các ngưỡng 5, 10 hoặc 15 phút là đề xuất quản lý nội bộ, cần thống nhất với lịch hoạt động thực tế trước khi áp dụng.
- **Rà soát Phụ lục II:** Ở tiêu chí A1.2 hiện có sự chồng lấn giữa “2–3 vi phạm nhẹ” và “từ 3 sai sót”. Nên sửa thành “2 vi phạm nhẹ” được 2 điểm; “từ 3 vi phạm nhẹ” được 0 điểm. Đồng thời bỏ bảng C ở cuối Phụ lục II nếu chỉ lặp lại cơ cấu 70 điểm.
- **Bảo đảm công bằng:** Nhân viên y tế, kế toán, văn thư có nhiều nhiệm vụ theo kỳ, còn cấp dưỡng, bảo vệ và vệ sinh có nhiều công việc hằng ngày. Khi giao nhiệm vụ đầu tháng phải xác định rõ số việc, yêu cầu chất lượng, thời hạn và trách nhiệm, để không chấm điểm theo cảm tính.

**Kết luận:** Với cách diễn đạt trực tiếp “12 điểm:…; 9 điểm:…; 5 điểm:…; 0 điểm:…”, nhân viên có thể tự đối chiếu kết quả thực hiện, tổ trưởng có cơ sở nhận xét và Ban Giám hiệu có căn cứ thống nhất điểm trước khi tổng hợp 100 điểm hằng tháng.

---

USER

trong quy chế này KPI giáo viên chưa thể hiện nội dung ngày nghỉ. để khắc phục việc này và bổ sung hợp  lý logic giữa các quy chế bạn xem và giúp mình bổ sung nội dung này vào mục KPI đảm bảo không thay đổi số d9ie63mva2 nội dung đã hoàn chỉnh

---

ASSISTANT

Tôi sẽ đối chiếu Phụ lục KPI giáo viên với phần giải trình về nghỉ phép, nghỉ hè, nghỉ việc riêng và nghỉ theo chế độ. Phương án phù hợp là giữ nguyên 100 điểm cùng toàn bộ tiêu chí đã hoàn chỉnh, chỉ bổ sung quy tắc ghi nhận ngày nghỉ và cách tính nhiệm vụ khi giáo viên vắng mặt hợp lệ.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 ĐỀ XUẤT BỔ SUNG QUY ĐỊNH VỀ NGÀY NGHỈ VÀO KPI GIÁO VIÊN

Trường Mầm non An Bình – Năm học 2026–2027

Tôi đã đối chiếu hai tài liệu bạn gửi: **Quy chế đánh giá, xếp loại chất lượng viên chức** và **Nội dung tiếp thu, trả lời ý kiến góp ý các quy chế tại Hội nghị viên chức**.

Theo góc độ quản lý nhà trường, tôi đề xuất **giữ nguyên toàn bộ 100 điểm KPI, các mã tiêu chí và mức điểm đã hoàn chỉnh**, chỉ bổ sung quy định về ngày nghỉ vào Phụ lục I.

### 🔍 1. Những điểm cần liên kết giữa hai quy chế

| Nội dung hiện có | Vấn đề cần bổ sung |
|--------|--------|
| **KPI A3.1 – 2 điểm:** Chấp hành giờ làm việc, giờ nhận lớp, bàn giao ca | Chưa quy định cách tính đối với giáo viên nghỉ có phép và nghỉ không phép. |
| **KPI B1 – 20 điểm:** Số lượng, khối lượng nhiệm vụ | Cần xác định cách tính công việc khi giáo viên nghỉ theo chế độ, có người dạy thay. |
| **KPI B3 – 10 điểm:** Tiến độ thực hiện nhiệm vụ | Cần phân biệt công việc chậm do nghỉ hợp lệ với công việc chậm do nguyên nhân chủ quan. |
| **Điều 13 dự thảo Quy chế làm việc** \(theo tài liệu giải trình) | Đã xác định quyền nghỉ và thủ tục giải quyết từng loại nghỉ; cần dẫn chiếu thống nhất khi chấm KPI. |
| **Điều 15 Quy chế đánh giá** | Đã quy định việc đánh giá theo thời gian công tác thực tế đối với các trường hợp đặc biệt. |

Điểm quan trọng là phải phân biệt **ngày nghỉ hợp pháp** với **việc tự ý nghỉ làm hoặc không thực hiện trách nhiệm được giao**.

Luật Viên chức số 129/2025/QH15 bảo đảm quyền nghỉ ngơi của viên chức; Thông tư 11/2026/TT-BGDĐT quy định riêng chế độ làm việc của giáo viên mầm non; Nghị định 233/2026/NĐ-CP quy định việc đánh giá trong các trường hợp nghỉ ốm, thai sản và một số trường hợp đặc biệt. [Toàn văn: LUẬT VIÊN CHỨC](<https://xaydungchinhsach.chinhphu.vn/toan-van-luat-vien-chuc-so-129-2025-qh15-119260107101503932.htm>); [TOÀN VĂN: Thông tư 11/2026/TT\-BGDĐT quy định chế độ làm việc với giáo viên mầm non](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-11-2026-tt-bgddt-quy-dinh-che-do-lam-viec-voi-giao-vien-mam-non-119260305102619461.htm>); [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/bo-may-hanh-chinh/nghi-dinh-233-2026-nd-cp-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx>)

Vì vậy, không nên quy định cứ nghỉ một ngày có phép là bị trừ một số điểm KPI cố định. Cách phù hợp hơn là **ghi nhận ngày nghỉ đúng chế độ, đánh giá ý thức chấp hành thời gian làm việc và tính kết quả thực hiện nhiệm vụ theo phân công thực tế đã được điều chỉnh**.

## 📋 2. Nội dung đề nghị bổ sung trực tiếp vào KPI giáo viên

**Vị trí chèn:** Cuối Phụ lục I, ngay sau bảng B4 (Tổng B4: 10 điểm), trước phần “Chú ý” và “Quy trình tổ chức đánh giá hằng tháng”.

Cách này không phải sửa bất kỳ dòng điểm nào trong bảng KPI hiện có.

> **writing · document**
>
> ### QUY ĐỊNH BỔ SUNG VỀ THEO DÕI NGÀY NGHỈ VÀ CHẤM ĐIỂM KPI GIÁO VIÊN HẰNG THÁNG
>
> **1. Nguyên tắc ghi nhận ngày nghỉ**
>
> Việc theo dõi ngày nghỉ của giáo viên được thực hiện theo quy định của pháp luật, Quy chế làm việc của nhà trường và lịch phân công nhiệm vụ; bảo đảm quyền nghỉ ngơi hợp pháp, đồng thời xác định rõ trách nhiệm chấp hành thời gian làm việc và kết quả thực hiện nhiệm vụ.
>
> Các trường hợp nghỉ hè, nghỉ lễ, tết; nghỉ việc riêng hưởng lương; nghỉ không hưởng lương theo quy định hoặc thỏa thuận hợp lệ; nghỉ ốm, thai sản, chăm con ốm và các trường hợp nghỉ theo chế độ khác được giải quyết đúng quy định thì không xem là vi phạm thời gian làm việc và không tự động trừ điểm KPI vì số ngày nghỉ.
>
> Thời gian giáo viên được cử đi công tác, hội họp, tập huấn, bồi dưỡng hoặc thực hiện nhiệm vụ khác theo phân công không tính là ngày nghỉ.
>
> Việc ghi nhận ngày nghỉ phải dựa trên lịch công tác, bảng chấm công, thông báo hoặc hồ sơ nghỉ theo quy định và kết quả xác nhận của người có thẩm quyền.
>
> **2. Cách áp dụng tiêu chí A3.1 – Chấp hành giờ làm việc, giờ nhận lớp, bàn giao ca và hoạt động bắt buộc (2 điểm)**
>
> Giữ nguyên điểm tối đa 2 điểm và các mức điểm đã quy định tại tiêu chí A3.1; bổ sung cách xác định việc nghỉ không phép như sau:
>
> - **2 điểm:** Chấp hành đúng thời gian làm việc, lịch nhận lớp, bàn giao ca; không đi muộn, về sớm trái quy định, không tự ý nghỉ làm. Trường hợp nghỉ hợp lệ theo quy định không bị trừ điểm.
> - **1 điểm:** Có 1 lần đi muộn, về sớm trái quy định hoặc tự ý nghỉ 1 buổi làm việc không có lý do chính đáng.
> - **0 điểm:** Có từ 2 lần vi phạm thời gian làm việc trở lên, bao gồm đi muộn, về sớm trái quy định hoặc tự ý nghỉ làm không có lý do chính đáng.
>
> Đối với lịch làm việc 2 buổi/ngày, mỗi buổi tự ý nghỉ không có lý do chính đáng được xác định là 1 lần vi phạm; tự ý nghỉ trọn 1 ngày làm việc được tính là 2 lần.
>
> Trường hợp nghỉ đột xuất do ốm đau, việc gia đình hoặc lý do chính đáng khác, giáo viên có trách nhiệm thông báo sớm nhất có thể và bổ sung hồ sơ hợp lệ khi cần thiết. Nhà trường xác minh, xem xét lý do trước khi xác định vi phạm; không mặc nhiên xem việc chưa báo trước là nghỉ không phép.
>
> **3. Cách tính KPI đối với giáo viên nghỉ hợp lệ**
>
> Đối với giáo viên nghỉ hợp lệ trong tháng, Ban Giám hiệu hoặc người được phân công có trách nhiệm điều chỉnh, phân công người thực hiện thay đối với nhiệm vụ chăm sóc, nuôi dưỡng, giáo dục trẻ và những nhiệm vụ đến hạn trong thời gian nghỉ.
>
> Việc đánh giá các tiêu chí B1 (số lượng, khối lượng nhiệm vụ), B3 (tiến độ hoàn thành nhiệm vụ) và các tiêu chí có liên quan được căn cứ vào nhiệm vụ thực tế thuộc trách nhiệm của giáo viên sau khi đã điều chỉnh hợp lệ.
>
> Những nhiệm vụ được phân công cho người khác thực hiện trong thời gian giáo viên nghỉ hợp lệ không tính là nhiệm vụ chưa hoàn thành của người nghỉ. Giáo viên vẫn chịu trách nhiệm về các nhiệm vụ đã thực hiện, các sản phẩm đến hạn và trách nhiệm bàn giao thuộc phạm vi được giao.
>
> Trường hợp nghỉ đột xuất không thể bàn giao trước, Ban Giám hiệu chủ động bố trí người thay thế, bảo đảm an toàn cho trẻ; không yêu cầu giáo viên tự thuê hoặc tự chi trả tiền cho người dạy thay.
>
> Đối với giáo viên đi khám, chữa bệnh đáp ứng đầy đủ điều kiện quy định tại khoản 3 Điều 11 Thông tư số 11/2026/TT-BGDĐT, việc tính giờ dạy theo định mức và trách nhiệm dạy bù thực hiện theo Thông tư này; kết quả KPI được xem xét trên cơ sở nhiệm vụ thực tế và phân công hợp lệ.
>
> **4. Cách tính KPI đối với trường hợp nghỉ không hợp lệ**
>
> Trường hợp giáo viên tự ý nghỉ làm không có lý do chính đáng, nghỉ vượt thời gian được giải quyết mà không có căn cứ hợp lệ hoặc không chấp hành thời gian làm việc theo quy định, nhà trường ghi nhận, xác minh và áp dụng tiêu chí A3.1.
>
> Đối với công việc đã được giao nhưng giáo viên không thực hiện do nguyên nhân chủ quan, kết quả được đánh giá theo các tiêu chí B1, B3 hoặc tiêu chí liên quan, căn cứ sản phẩm, tiến độ và trách nhiệm thực tế; không được tính là hoàn thành chỉ vì đã có người khác thực hiện thay.
>
> Không trừ thêm một số điểm cố định theo ngày nghỉ ngoài các tiêu chí KPI đã ban hành. Trường hợp vi phạm ảnh hưởng đến an toàn của trẻ hoặc thuộc trường hợp phải xử lý theo quy định pháp luật thì được xem xét riêng theo tính chất, mức độ và hậu quả.
>
> **5. Trường hợp nghỉ theo chế độ kéo dài**
>
> Đối với giáo viên nghỉ ốm, nghỉ thai sản hoặc nghỉ theo chế độ hợp pháp kéo dài, việc đánh giá căn cứ vào kết quả thực hiện nhiệm vụ trong thời gian thực tế công tác.
>
> Tháng giáo viên nghỉ trọn tháng theo chế độ, không phát sinh thời gian thực hiện nhiệm vụ thì ghi nhận tình trạng nghỉ theo chế độ, không tự động xác định 0 điểm hoặc 100 điểm KPI tháng.
>
> Trường hợp trong tháng có thời gian làm việc thực tế, việc theo dõi, đánh giá căn cứ nhiệm vụ được giao và minh chứng phù hợp. Nếu chưa đủ căn cứ đánh giá một tiêu chí, nhà trường ghi nhận và tổng hợp theo kỳ phù hợp, không tự ý quy đổi thành kết quả hoàn thành hoặc không hoàn thành.
>
> Kết quả đánh giá, xếp loại cuối năm thực hiện theo Điều 15 của Quy chế và các trường hợp đặc biệt quy định tại Nghị định số 233/2026/NĐ-CP.
>
> **6. Theo dõi ngày nghỉ và minh chứng đánh giá**
>
> Cùng với bảng chấm điểm KPI hằng tháng, tổ trưởng chuyên môn theo dõi, tổng hợp:
>
> - Số ngày làm việc theo lịch;
> - Số ngày thực tế thực hiện nhiệm vụ;
> - Số ngày nghỉ hợp lệ, phân theo loại nghỉ;
> - Số ngày hoặc buổi nghỉ không phép đã được xác minh;
> - Nhiệm vụ được điều chỉnh, phân công người thực hiện thay (nếu có).
>
> Sử dụng bảng chấm công, lịch phân công, hồ sơ nghỉ, sổ bàn giao, kế hoạch chuyên môn và các minh chứng hiện có. Không yêu cầu phát sinh hồ sơ trùng lặp chỉ để phục vụ chấm điểm.
>
> **7. Nguyên tắc áp dụng thống nhất**
>
> Quy định bổ sung này chỉ hướng dẫn cách xác định ngày nghỉ và trách nhiệm thực hiện nhiệm vụ khi chấm KPI; không làm thay đổi cơ cấu 30 điểm tiêu chí chung, 70 điểm kết quả thực hiện nhiệm vụ, tổng điểm 100 điểm và các tiêu chí đã ban hành.
>
> Việc giải quyết chế độ nghỉ thực hiện theo Quy chế làm việc và pháp luật hiện hành. Việc đánh giá, chấm điểm thực hiện theo Quy chế đánh giá, xếp loại chất lượng viên chức và Phụ lục I kèm theo.
>
> Trường hợp quy định pháp luật có nội dung khác thì thực hiện theo văn bản có hiệu lực pháp lý cao hơn.

## 💡 3. Ví dụ cách chấm để giáo viên dễ hiểu

Trường hợp 1: Nghỉ hợp lệ 2 ngày trong tháng

Giáo viên được giao 40 hoạt động, nghỉ hợp lệ 2 ngày. Ban Giám hiệu điều chỉnh 4 hoạt động cho giáo viên khác thực hiện. Giáo viên hoàn thành đủ 36 hoạt động còn thuộc trách nhiệm.

A3.1 – Chấp hành thời gian

# 2/2 điểm

B1.2 – Hoàn thành 36/36

# 8/8 điểm

Các tiêu chí chất lượng, tiến độ và phối hợp khác vẫn được chấm theo minh chứng thực tế; không mặc nhiên đạt tối đa toàn bộ KPI.

---

Trường hợp 2: Tự ý nghỉ 1 ngày làm việc gồm 2 buổi

Giáo viên không có lý do chính đáng, đã được xác minh. Theo quy ước bổ sung, hai buổi nghỉ không phép tương ứng hai lần vi phạm thời gian làm việc.

A3.1 – Chấp hành thời gian

# 0/2 điểm

B1, B3 và những tiêu chí khác chỉ bị ảnh hưởng nếu có công việc không hoàn thành, chậm tiến độ hoặc hậu quả được xác định theo tiêu chí tương ứng.

## ⚠️ 4. Lưu ý trước khi hoàn chỉnh Quy chế

Có hai điểm pháp lý cần giữ đúng khi áp dụng:

**Thứ nhất**, giáo viên mầm non có thời gian nghỉ hè 08 tuần, đã bao gồm nghỉ phép hằng năm theo Nghị định số 93/2026/NĐ-CP. Không được mặc nhiên cộng thêm 12 ngày phép năm ngoài thời gian này; các loại nghỉ việc riêng, nghỉ theo bảo hiểm xã hội được xem xét theo chế độ tương ứng. [QUY ĐỊNH MỚI: THỜI GIAN NGHỈ HÈ hằng năm của NHÀ GIÁO](<https://xaydungchinhsach.chinhphu.vn/chinh-phu-quy-dinh-thoi-gian-nghi-he-cua-nha-giao-119260404074041813.htm>); [TOÀN VĂN: Thông tư 11/2026/TT\-BGDĐT quy định chế độ làm việc với giáo viên mầm non](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-11-2026-tt-bgddt-quy-dinh-che-do-lam-viec-voi-giao-vien-mam-non-119260305102619461.htm>)

**Thứ hai**, trường hợp đi khám, chữa bệnh đáp ứng các điều kiện tại khoản 3 Điều 11 Thông tư 11/2026/TT-BGDĐT được tính đủ giờ dạy định mức của ngày đó và không phải dạy bù. Không nên dùng KPI để vô hiệu hóa quyền lợi này. [Tính định mức giờ dạy khi giáo viên nghỉ đi khám bệnh](<https://cms.baochinhphu.vn/tinh-dinh-muc-gio-day-khi-giao-vien-nghi-di-kham-benh-102260930144237386.htm>)

Tài liệu giải trình bạn gửi đã nêu nội dung Điều 13 của dự thảo Quy chế làm việc, nhưng chưa có toàn văn Quy chế làm việc để đối chiếu từng khoản. Vì vậy, khi trình ký cần kiểm tra lại số điều và nội dung dẫn chiếu nếu dự thảo đã được chỉnh sửa.

## ✅ Kết luận

Tôi đề xuất lựa chọn phương án **bổ sung một mục hướng dẫn vào cuối Phụ lục I** như trên. Đây là phương án ít làm xáo trộn văn bản nhất và giải quyết được cả ba yêu cầu: giáo viên nghỉ đúng chế độ không bị bất lợi; trường hợp tự ý nghỉ làm được phản ánh vào KPI; công việc chăm sóc, nuôi dưỡng, giáo dục trẻ luôn có người chịu trách nhiệm.

Đồng thời, **giữ nguyên thang điểm A3.1 là 2 điểm, B1 là 20 điểm, B3 là 10 điểm và tổng KPI là 100 điểm**, không cần xây dựng thêm tiêu chí hay phân bổ lại điểm.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

bạn làm rất tốt. bạn cụ thể các mục để minh có thể bổ sung vào quy chế nhé

---

ASSISTANT

Tôi sẽ chỉ rõ từng vị trí cần bổ sung trong Quy chế và Phụ lục I, kèm nguyên văn để bạn sao chép vào đúng chỗ. Tôi sẽ giữ nguyên tất cả mã tiêu chí, thang điểm và mức chấm đã hoàn chỉnh; phần mới chỉ làm rõ ngày nghỉ hợp lệ, nghỉ không phép và cách xác định nhiệm vụ thực tế để chấm KPI.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 HƯỚNG DẪN BỔ SUNG NỘI DUNG NGÀY NGHỈ VÀO QUY CHẾ KPI GIÁO VIÊN

**Trường Mầm non An Bình – Năm học 2026–2027**

Tôi đề xuất bổ sung tại **5 vị trí cụ thể** trong Quy chế đánh giá, xếp loại chất lượng viên chức và Phụ lục I. Các nội dung dưới đây được viết theo văn phong hành chính để bạn có thể sao chép trực tiếp vào dự thảo.

Đặc biệt, tôi giữ nguyên:

- Tổng điểm KPI **100 điểm**, gồm 30 điểm tiêu chí chung và 70 điểm thực hiện nhiệm vụ.
- Toàn bộ mã tiêu chí A1–A4, B1–B4, điểm tối đa và mức điểm đã hoàn chỉnh.
- Các điều khoản hiện có của Quy chế, chỉ thêm khoản mới hoặc phần ghi chú hướng dẫn.

## 1. Xác định chính xác vị trí bổ sung

| Vị trí trong dự thảo | Nội dung cần thêm |
|--------|--------|
| **Điều 10**, sau khoản 4 | Thêm khoản 5 về điều chỉnh nhiệm vụ khi viên chức nghỉ hợp lệ. |
| **Điều 11**, sau khoản 4 | Thêm khoản 5 về nguyên tắc ghi nhận ngày nghỉ khi đánh giá hằng tháng. |
| **Điều 15**, sau khoản 4 | Thêm khoản 5 về tháng nghỉ trọn theo chế độ và tổng hợp điểm. |
| **Phụ lục I**, sau dòng “Tổng A3 – 4 điểm” | Thêm ghi chú hướng dẫn chấm ngày nghỉ tại tiêu chí A3.1. |
| **Phụ lục I**, sau “Tổng B4 – 10 điểm” | Thêm hướng dẫn xác định nhiệm vụ, tỷ lệ hoàn thành và minh chứng khi giáo viên nghỉ. |

Tôi đã đối chiếu với Luật Viên chức số 129/2025/QH15, Nghị định số 233/2026/NĐ-CP và Thông tư số 11/2026/TT-BGDĐT. Những văn bản này là cơ sở để bảo đảm quyền nghỉ hợp pháp và đánh giá theo kết quả công tác thực tế. [Toàn văn: LUẬT VIÊN CHỨC](<https://xaydungchinhsach.chinhphu.vn/toan-van-luat-vien-chuc-so-129-2025-qh15-119260107101503932.htm>); [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/bo-may-hanh-chinh/nghi-dinh-233-2026-nd-cp-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx>); [TOÀN VĂN: Thông tư 11/2026/TT\-BGDĐT quy định chế độ làm việc với giáo viên mầm non](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-11-2026-tt-bgddt-quy-dinh-che-do-lam-viec-voi-giao-vien-mam-non-119260305102619461.htm>)

## 2. Nội dung cụ thể để đưa vào Quy chế

### Vị trí 1 – Điều 10. Giao nhiệm vụ và minh chứng đánh giá

**Chèn thêm khoản 5**, ngay sau khoản 4 hiện hành. Không thay đổi các khoản 1, 2, 3 và 4.

> **writing · standard**
>
> **5. Điều chỉnh nhiệm vụ đối với viên chức nghỉ hợp lệ**
>
> Trường hợp viên chức nghỉ theo chế độ, nghỉ việc riêng hoặc nghỉ vì lý do chính đáng theo quy định của pháp luật và Quy chế làm việc của nhà trường, Hiệu trưởng hoặc người được phân công có trách nhiệm xem xét, điều chỉnh nhiệm vụ, bố trí người thực hiện thay và xác định rõ trách nhiệm bàn giao, bảo đảm hoạt động chăm sóc, nuôi dưỡng, giáo dục trẻ và các hoạt động của nhà trường được thực hiện liên tục, an toàn.
>
> Những nhiệm vụ đã được điều chỉnh, chuyển giao hợp lệ trong thời gian viên chức nghỉ không tính là nhiệm vụ chưa hoàn thành của người nghỉ. Việc đánh giá căn cứ vào nhiệm vụ thực tế còn thuộc trách nhiệm của viên chức, kết quả thực hiện, chất lượng, tiến độ và các minh chứng có liên quan.
>
> Đối với trường hợp nghỉ đột xuất có lý do chính đáng, không thể thực hiện bàn giao trước, Ban Giám hiệu chủ động bố trí người thay thế, đồng thời ghi nhận, xác minh và hoàn thiện việc điều chỉnh nhiệm vụ theo quy định.

**Mục đích:** Bảo đảm khi giáo viên nghỉ hợp lệ thì công việc được phân công lại rõ ràng. Người nghỉ không bị đánh giá thiếu nhiệm vụ đã được chuyển giao, còn người thực hiện thay được ghi nhận kết quả đúng trách nhiệm.

### Vị trí 2 – Điều 11. Theo dõi, đánh giá hằng tháng hoặc hằng quý

**Chèn thêm khoản 5**, sau khoản 4.

> **writing · standard**
>
> **5. Theo dõi ngày nghỉ và đánh giá kết quả thực hiện nhiệm vụ**
>
> Việc theo dõi, đánh giá viên chức hằng tháng hoặc hằng quý phải phân biệt rõ thời gian làm việc thực tế, thời gian thực hiện nhiệm vụ theo phân công, thời gian nghỉ hợp lệ và thời gian vắng mặt không có lý do chính đáng.
>
> Các trường hợp nghỉ theo quy định của pháp luật, bao gồm nghỉ hè, nghỉ lễ, tết, nghỉ việc riêng, nghỉ không hưởng lương hợp lệ, nghỉ ốm đau, thai sản và các trường hợp nghỉ theo chế độ khác, không mặc nhiên bị trừ điểm KPI chỉ vì số ngày nghỉ.
>
> Thời gian viên chức được cử tham gia hội họp, công tác, tập huấn, bồi dưỡng hoặc thực hiện nhiệm vụ theo phân công của cấp có thẩm quyền không tính là thời gian nghỉ làm.
>
> Trường hợp viên chức tự ý nghỉ làm, không chấp hành thời gian làm việc hoặc vắng mặt không có lý do chính đáng thì được xem xét theo tiêu chí về ý thức kỷ luật, tác phong, lề lối làm việc và kết quả thực hiện nhiệm vụ tương ứng, trên cơ sở xác minh cụ thể.
>
> Việc chấm điểm thực hiện theo các tiêu chí, mức điểm đã quy định tại Quy chế và phụ lục kèm theo; không đặt thêm điểm trừ cố định theo số ngày nghỉ ngoài thang điểm đã ban hành.

**Mục đích:** Đây là khoản liên kết trực tiếp giữa chế độ nghỉ trong Quy chế làm việc và việc đánh giá KPI. Nó giúp tránh tình trạng giáo viên nghỉ ốm, nghỉ việc riêng đúng chế độ nhưng vẫn bị trừ điểm như nghỉ không phép.

### Vị trí 3 – Điều 15. Trường hợp đặc biệt

**Chèn thêm khoản 5**, sau khoản 4 hiện hành.

> **writing · standard**
>
> **5. Theo dõi, đánh giá đối với tháng nghỉ trọn theo chế độ**
>
> Trường hợp viên chức nghỉ trọn tháng theo chế độ hợp pháp, không phát sinh thời gian thực hiện nhiệm vụ và không có đủ căn cứ đánh giá kết quả công tác trong tháng, nhà trường ghi nhận tình trạng nghỉ theo chế độ, không tự động xác định 0 điểm hoặc 100 điểm KPI tháng đó.
>
> Trường hợp viên chức có thời gian làm việc thực tế trong tháng thì việc đánh giá căn cứ vào nhiệm vụ được giao, kết quả thực hiện và minh chứng phù hợp; không tính những nhiệm vụ đã được điều chỉnh, chuyển giao hợp lệ trong thời gian nghỉ vào số nhiệm vụ chưa hoàn thành.
>
> Đối với kỳ đánh giá chưa đủ minh chứng để chấm điểm theo tháng, người có trách nhiệm theo dõi tổng hợp kết quả theo quý hoặc kỳ phù hợp. Việc tổng hợp điểm, xếp loại chất lượng cuối năm căn cứ các kỳ có kết quả đánh giá hợp lệ, thời gian công tác thực tế và các trường hợp đặc biệt theo Nghị định số 233/2026/NĐ-CP.
>
> Không sử dụng thời gian nghỉ hợp lệ làm căn cứ duy nhất để hạ mức xếp loại chất lượng viên chức.

**Mục đích:** Giải quyết trường hợp giáo viên nghỉ thai sản, nghỉ ốm kéo dài hoặc nghỉ trọn tháng. Không chấm 0 vì không có mặt, cũng không tự động cho 100 điểm khi không có kết quả công tác để đánh giá.

### Vị trí 4 – Phụ lục I, tiêu chí A3.1 (2 điểm)

Đây là nội dung quan trọng nhất để giáo viên hiểu rõ cách tính điểm khi nghỉ làm.

**Vị trí chèn:** Ngay sau dòng **“Tổng A3 – 4 điểm”**, trước nhóm A4. Giữ nguyên bảng điểm A3.1 hiện tại, chỉ bổ sung ghi chú giải thích.

> **writing · standard**
>
> **Ghi chú bổ sung về cách chấm điểm tiêu chí A3.1 đối với ngày nghỉ của giáo viên**
>
> Việc xác định điểm tiêu chí A3.1 thực hiện theo các mức điểm đã quy định, đồng thời áp dụng thống nhất đối với trường hợp nghỉ làm như sau:
>
> **- 2 điểm:** Giáo viên chấp hành đúng thời gian làm việc, lịch nhận lớp, bàn giao ca; không đi muộn, về sớm trái quy định và không tự ý nghỉ làm. Giáo viên nghỉ hợp lệ theo quy định, không có vi phạm thời gian làm việc vẫn được xem xét đạt 2 điểm.
>
> **- 1 điểm:** Có 1 lần vi phạm thời gian làm việc đã được xác minh, bao gồm đi muộn, về sớm trái quy định hoặc tự ý nghỉ 1 buổi/ca làm việc được phân công mà không có lý do chính đáng.
>
> **- 0 điểm:** Có từ 2 lần vi phạm thời gian làm việc trở lên trong tháng, bao gồm đi muộn, về sớm trái quy định hoặc tự ý nghỉ làm không có lý do chính đáng.
>
> Đối với lịch làm việc được bố trí 2 buổi/ngày, mỗi buổi tự ý nghỉ không có lý do chính đáng được tính là 1 lần vi phạm; trường hợp tự ý nghỉ trọn cả 2 buổi được ghi nhận là 2 lần.
>
> Các trường hợp nghỉ theo chế độ, nghỉ việc riêng, nghỉ không hưởng lương hợp lệ, nghỉ ốm đau, thai sản và các trường hợp khác được giải quyết đúng quy định không tính là vi phạm tiêu chí A3.1.
>
> Trường hợp nghỉ đột xuất do ốm đau, hoàn cảnh gia đình hoặc lý do chính đáng, giáo viên phải thông báo sớm nhất có thể và bổ sung hồ sơ phù hợp khi cần thiết. Nhà trường xem xét lý do, hoàn cảnh thực tế trước khi xác định vi phạm; không tự động trừ điểm do không thể báo trước.
>
> **Minh chứng:** Bảng chấm công; lịch phân công nhiệm vụ; hồ sơ nghỉ theo chế độ; thông tin báo nghỉ; ghi nhận của tổ trưởng, Ban Giám hiệu; biên bản xác minh hoặc tài liệu liên quan.

### Vị trí 5 – Phụ lục I, hướng dẫn bổ sung sau nhóm B4

**Vị trí chèn:** Sau dòng **“Tổng B4 – 10 điểm”**, trước phần “Chú ý: Đây là các mức theo dõi kết quả KPI hằng tháng...”.

Đây là phần giúp giáo viên và tổ trưởng hiểu cách tính B1, B2, B3, B4 khi giáo viên nghỉ hợp lệ, mà không phải sửa các bảng điểm đã có.

> **writing · document**
>
> ### HƯỚNG DẪN BỔ SUNG VỀ NGÀY NGHỈ KHI CHẤM ĐIỂM KPI GIÁO VIÊN HẰNG THÁNG
>
> **1. Đối với nhóm B1 – Số lượng, khối lượng nhiệm vụ (20 điểm)**
>
> Tỷ lệ hoàn thành nhiệm vụ được xác định trên tổng số nhiệm vụ được giao hợp lệ, thuộc trách nhiệm thực hiện của giáo viên trong tháng, sau khi đã điều chỉnh nhiệm vụ do nghỉ theo chế độ hoặc lý do chính đáng.
>
> Nhiệm vụ được Ban Giám hiệu phân công cho người khác thực hiện trong thời gian giáo viên nghỉ hợp lệ không tính vào tổng số nhiệm vụ phải hoàn thành của giáo viên đó.
>
> Những nhiệm vụ giáo viên chưa hoàn thành do nguyên nhân chủ quan, không được điều chỉnh hoặc chuyển giao hợp lệ vẫn được tính vào kết quả thực hiện nhiệm vụ theo quy định.
>
> Cách tính:
>
> **Tỷ lệ hoàn thành (%) = Số nhiệm vụ hoàn thành đạt yêu cầu / Tổng số nhiệm vụ được giao hợp lệ còn thuộc trách nhiệm × 100%.**
>
> Mức điểm áp dụng theo từng tiêu chí B1.1, B1.2, B1.3 và B1.4 đã quy định, không thay đổi.
>
> **2. Đối với nhóm B2 – Chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ (30 điểm)**
>
> Việc đánh giá chất lượng căn cứ kết quả thực hiện nhiệm vụ thực tế, hồ sơ, sản phẩm và các minh chứng có liên quan trong thời gian giáo viên thực hiện nhiệm vụ.
>
> Đối với tiêu chí B2.3, nhà trường thực hiện quan sát hoạt động giáo dục theo số lượt và chỉ báo đã quy định. Trường hợp giáo viên nghỉ hợp lệ dẫn đến không đủ điều kiện thực hiện số lượt quan sát tối thiểu trong tháng, tổ chuyên môn báo cáo Ban Giám hiệu bố trí đánh giá vào thời gian làm việc phù hợp hoặc tổng hợp theo quý; không mặc nhiên chấm 0 điểm do nghỉ hợp lệ.
>
> Không sử dụng hoạt động do giáo viên khác thực hiện thay làm minh chứng chất lượng chuyên môn của người nghỉ.
>
> **3. Đối với nhóm B3 – Tiến độ hoàn thành nhiệm vụ (10 điểm)**
>
> Thời hạn thực hiện nhiệm vụ được xác định theo kế hoạch, lịch giao việc và các điều chỉnh hợp lệ đã được nhà trường xác nhận.
>
> Nhiệm vụ đến hạn trong thời gian giáo viên nghỉ hợp lệ, đã được điều chỉnh thời hạn hoặc phân công người khác thực hiện thì không tính là nhiệm vụ chậm tiến độ của giáo viên nghỉ.
>
> Trường hợp giáo viên không hoàn thành nhiệm vụ do nguyên nhân chủ quan trước thời gian nghỉ hoặc không thực hiện nhiệm vụ còn thuộc trách nhiệm thì đánh giá theo mức điểm tương ứng của tiêu chí B3.1, B3.2 hoặc B3.3.
>
> **4. Đối với nhóm B4 – Chuyên môn, phối hợp và đổi mới (10 điểm)**
>
> Việc đánh giá căn cứ nhiệm vụ chuyên môn, sinh hoạt chuyên môn, hoạt động phối hợp và trách nhiệm thực tế của giáo viên trong thời gian công tác.
>
> Các hoạt động tổ chức trong thời gian giáo viên nghỉ hợp lệ, không thuộc nhiệm vụ phải thực hiện sau khi đã điều chỉnh phân công, không tính là hoạt động giáo viên không tham gia hoặc không hoàn thành.
>
> Giáo viên vẫn có trách nhiệm phối hợp, bàn giao những thông tin cần thiết trước khi nghỉ nếu điều kiện cho phép; trường hợp nghỉ đột xuất, việc bàn giao được thực hiện phù hợp với hoàn cảnh thực tế.
>
> **5. Đối với trường hợp đi khám, chữa bệnh**
>
> Giáo viên đáp ứng đầy đủ điều kiện tại khoản 3 Điều 11 Thông tư số 11/2026/TT-BGDĐT được tính đủ định mức giờ dạy trong ngày và không phải dạy bù theo quy định.
>
> Việc đánh giá KPI đối với các nhiệm vụ khác vẫn căn cứ vào phân công thực tế và trách nhiệm đã được điều chỉnh hợp lệ.
>
> **6. Nguyên tắc chung**
>
> Việc bổ sung hướng dẫn ngày nghỉ không làm thay đổi tổng điểm KPI, nội dung các tiêu chí và các mức điểm đã quy định tại Phụ lục I.
>
> Không trừ điểm cố định theo số ngày nghỉ hợp lệ. Không đánh giá một nhiệm vụ chưa hoàn thành chỉ vì giáo viên nghỉ theo đúng chế độ và nhiệm vụ đó đã được chuyển giao hợp lệ.
>
> Kết quả chấm điểm phải có minh chứng, được giáo viên tự đánh giá, tổ chuyên môn nhận xét, Ban Giám hiệu xem xét và xác nhận theo quy trình của nhà trường.

Quy định riêng tại khoản 3 Điều 11 Thông tư 11/2026/TT-BGDĐT về giáo viên đi khám, chữa bệnh đã được đối chiếu để bổ sung vào mục 5 nêu trên. [
	Thông tư 11/2026/TT\-BGDĐT chế độ làm việc đối với giáo viên mầm non mới nhất
](<https://thuvienphapluat.vn/van-ban/Lao-dong-Tien-luong/Thong-tu-11-2026-TT-BGDDT-che-do-lam-viec-doi-voi-giao-vien-mam-non-696337.aspx?anchor=dieu_4>)

## 3. Ví dụ áp dụng khi chấm điểm

| Tình huống | Cách chấm KPI |
|--------|--------|
| Nghỉ việc riêng 1 ngày đúng chế độ, không có vi phạm khác | A3.1: 2/2 điểm |
| Nghỉ ốm 2 ngày có hồ sơ hợp lệ | Không trừ A3.1 vì ngày nghỉ; B1 và B3 tính theo nhiệm vụ thực tế |
| Tự ý nghỉ 1 buổi không có lý do chính đáng | A3.1: 1/2 điểm |
| Tự ý nghỉ cả ngày gồm 2 buổi được phân công | A3.1: 0/2 điểm theo quy ước bổ sung |
| Nghỉ thai sản trọn tháng, không có nhiệm vụ thực hiện | Ghi “Nghỉ chế độ – không chấm KPI tháng”; không mặc nhiên ghi 0 hoặc 100 điểm |

Các trường hợp trên giả định không có thêm sai sót hay vi phạm khác. Riêng việc quy ước một buổi nghỉ không phép là một lần vi phạm là **quy định nội bộ đề xuất**, cần được tập thể góp ý, thống nhất trước khi ban hành, không phải mức trừ điểm do pháp luật ấn định.

## ✅ 4. Kết luận và cách hoàn thiện

Sau khi bổ sung, Quy chế sẽ có sự liên kết như sau:

**Quy chế làm việc – Điều 13**

Xác định quyền nghỉ, loại nghỉ và thủ tục nghỉ

**Quy chế đánh giá – Điều 10, 11, 15**

Điều chỉnh nhiệm vụ, theo dõi ngày nghỉ và đánh giá kết quả

**Phụ lục I – A3.1 và hướng dẫn B1–B4**

Áp dụng các mức điểm KPI hiện có, có minh chứng

**Đề xuất cuối cùng:** Bạn chỉ cần chèn đúng 5 nội dung trên. Không phải đánh số lại các điều trong Quy chế, không thêm mã KPI mới và không điều chỉnh cơ cấu điểm.

Khi hoàn thiện bản ban hành, cần lưu ý **Điều 13 của Quy chế làm việc** hiện được dẫn từ tài liệu giải trình ý kiến góp ý; bạn nên đối chiếu lại với toàn văn Quy chế làm việc đã được chốt để bảo đảm dẫn chiếu chính xác.

Như vậy, nhà trường vừa bảo vệ quyền nghỉ hợp pháp của giáo viên, vừa quản lý được ngày nghỉ không phép và trách nhiệm thực hiện nhiệm vụ, bảo đảm tính công khai, công bằng trong đánh giá KPI hằng tháng.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

bạn làm tốt lằm tuy nhiên còn khá dài và khó hiểu, bạn có thể trình bày tương tự đảm bảo ý để câu văn trong quy chế không quá luộm thuộm

---

ASSISTANT

Tôi đề xuất **rút gọn từ 5 vị trí bổ sung xuống còn 3 vị trí**, diễn đạt ngắn gọn theo văn phong hành chính, tránh trùng lặp giữa các điều khoản.

Cách này vẫn bảo đảm quản lý ngày nghỉ, chấm điểm công bằng và **giữ nguyên toàn bộ thang điểm KPI 100 điểm đã hoàn chỉnh**.

## 📌 1. Bổ sung vào Điều 11 – Theo dõi, đánh giá hằng tháng hoặc hằng quý

**Vị trí:** Thêm khoản 5, ngay sau khoản 4.

> **writing · standard**
>
> **5.** Việc đánh giá viên chức có thời gian nghỉ hợp lệ thực hiện theo kết quả công tác và nhiệm vụ thực tế được giao. Các nhiệm vụ đã điều chỉnh, phân công người khác thực hiện trong thời gian nghỉ không tính là nhiệm vụ chưa hoàn thành của viên chức. Ngày nghỉ đúng chế độ không mặc nhiên bị trừ điểm KPI; trường hợp nghỉ không phép được xem xét theo tiêu chí tương ứng.
>
> Đối với viên chức nghỉ trọn tháng theo chế độ, không phát sinh nhiệm vụ để đánh giá thì ghi nhận “Nghỉ theo chế độ”, không chấm điểm KPI tháng; việc đánh giá cuối năm thực hiện theo Điều 15 của Quy chế.

## 📌 2. Bổ sung vào Phụ lục I – Tiêu chí A3.1 (2 điểm)

**Vị trí:** Ngay sau dòng “Tổng A3 – 4 điểm”, trước nhóm A4.

> **writing · standard**
>
> **Ghi chú cách chấm điểm tiêu chí A3.1:**
>
> Giáo viên nghỉ đúng chế độ, được giải quyết theo quy định không tính là vi phạm thời gian làm việc.
>
> Trường hợp tự ý nghỉ không có lý do chính đáng: nghỉ 01 buổi tính 01 lần vi phạm; nghỉ trọn ngày có 02 buổi làm việc tính 02 lần vi phạm. Áp dụng các mức 2 điểm, 1 điểm và 0 điểm đã quy định tại tiêu chí A3.1.
>
> Việc xác định vi phạm căn cứ bảng chấm công, lịch phân công và kết quả xác minh; trường hợp nghỉ đột xuất có lý do chính đáng được xem xét theo quy định.

## 📌 3. Bổ sung vào cuối Phụ lục I – Sau nhóm B4 (10 điểm)

**Vị trí:** Ngay sau dòng “Tổng B4 – 10 điểm”, trước phần “Chú ý”.

> **writing · standard**
>
> **Ghi chú về đánh giá KPI đối với giáo viên nghỉ hợp lệ:**
>
> Các tiêu chí B1, B2, B3 và B4 được đánh giá theo nhiệm vụ thực tế, kết quả thực hiện và minh chứng phù hợp. Nhiệm vụ đã được nhà trường điều chỉnh thời hạn hoặc phân công người thực hiện thay trong thời gian giáo viên nghỉ hợp lệ không tính là nhiệm vụ chưa hoàn thành.
>
> Trường hợp chưa đủ minh chứng đánh giá do nghỉ hợp lệ, nhà trường bố trí đánh giá bổ sung hoặc tổng hợp theo kỳ phù hợp. Việc bố trí giáo viên dạy thay thuộc trách nhiệm của nhà trường.
>
> Không trừ điểm cố định theo số ngày nghỉ hợp lệ và không thay đổi các mức điểm KPI đã quy định.

## ✅ Kết luận

Với phương án này, nhà trường chỉ cần:

- **Điều 11:** Bổ sung 01 khoản về nguyên tắc đánh giá khi nghỉ.
- **Phụ lục I – A3.1:** Bổ sung 01 ghi chú về nghỉ hợp lệ và nghỉ không phép.
- **Phụ lục I – Sau B4:** Bổ sung 01 ghi chú về cách tính nhiệm vụ khi nghỉ.

**Không cần sửa Điều 10, Điều 15; không thêm tiêu chí, không thay đổi số điểm và không phải chỉnh lại các bảng KPI đã hoàn chỉnh.**

Theo tôi, đây là cách trình bày phù hợp để đưa vào Quy chế chính thức: ngắn gọn, rõ trách nhiệm, thống nhất với Quy chế làm việc và thuận tiện khi giáo viên, tổ chuyên môn thực hiện chấm điểm hằng tháng.

---

USER

tương tự vời nhân viên bạn có thể bổ sung chung để không phải chỉnh từng mục nhân viên (vì số điểm tương đối giống nhau

---

ASSISTANT

Đối với nhân viên, tôi đề xuất **chỉ bổ sung một mục ghi chú chung ở cuối Phụ lục II**, áp dụng thống nhất cho cả 7 vị trí: cấp dưỡng, y tế, kế toán, văn thư, thủ quỹ, bảo vệ và phục vụ – vệ sinh.

Cách này không phải chỉnh sửa từng bảng KPI, đồng thời bảo đảm thống nhất với cách đánh giá giáo viên và Quy chế làm việc của nhà trường.

## 📌 Vị trí bổ sung

Tại **cuối Phụ lục II**, ngay sau dòng “Tổng cộng: 70 điểm” của nhân viên phục vụ, vệ sinh và trước phần “Lưu ý”.

## 📋 Nội dung đề xuất đưa vào Quy chế

> **writing · document**
>
> ### GHI CHÚ CHUNG VỀ NGÀY NGHỈ KHI CHẤM ĐIỂM KPI NHÂN VIÊN HẰNG THÁNG
>
> *Áp dụng thống nhất đối với tất cả vị trí nhân viên tại Phụ lục II.*
>
> **1. Đối với tiêu chí A3.1 – Chấp hành thời gian làm việc (2 điểm)**
>
> Nhân viên nghỉ phép hằng năm, nghỉ việc riêng, nghỉ ốm đau, thai sản, nghỉ không hưởng lương và các trường hợp nghỉ hợp lệ khác theo quy định không tính là vi phạm thời gian làm việc.
>
> Trường hợp tự ý nghỉ không có lý do chính đáng, mỗi ca hoặc buổi làm việc được phân công không thực hiện tính là 01 lần vi phạm. Áp dụng các mức 2 điểm, 1 điểm và 0 điểm đã quy định tại tiêu chí A3.1. Trường hợp nghỉ đột xuất có lý do chính đáng được xem xét theo quy định.
>
> **2. Đối với các tiêu chí B1, B2, B3 và B4 – Kết quả thực hiện nhiệm vụ (70 điểm)**
>
> Việc chấm điểm căn cứ nhiệm vụ thực tế được giao, kết quả thực hiện và minh chứng phù hợp. Công việc đã được điều chỉnh hoặc phân công người khác thực hiện trong thời gian nhân viên nghỉ hợp lệ không tính là nhiệm vụ chưa hoàn thành.
>
> Trường hợp nghỉ không phép làm ảnh hưởng số lượng, chất lượng hoặc tiến độ công việc thì đánh giá theo tiêu chí tương ứng.
>
> **3. Đối với trường hợp nghỉ theo chế độ kéo dài**
>
> Nhân viên nghỉ trọn tháng theo chế độ, không phát sinh nhiệm vụ để đánh giá thì ghi nhận “Nghỉ theo chế độ”, không chấm điểm KPI tháng. Việc đánh giá, xếp loại cuối năm thực hiện theo Điều 15 của Quy chế và quy định hiện hành.
>
> **4. Minh chứng và nguyên tắc áp dụng**
>
> Minh chứng gồm bảng chấm công, lịch phân công, hồ sơ nghỉ, sổ bàn giao và kết quả thực hiện nhiệm vụ.
>
> Việc chấm điểm không trừ điểm cố định theo số ngày nghỉ hợp lệ, không thay đổi nội dung, các mức điểm và tổng điểm KPI đã quy định.

## ✅ Lưu ý để thống nhất giữa các quy chế

Có hai điểm bạn cần chú ý khi áp dụng:

- **Điều 11, khoản 5 của Quy chế đánh giá:** Nếu đã bổ sung theo phương án trước, khoản này dùng chung cho cả giáo viên và nhân viên, không cần sửa thêm.
- **Tiêu chí A3.1:** Đối với nhân viên làm việc theo ca, một ca trực kéo dài được tính là một lần vi phạm nếu tự ý bỏ toàn bộ ca; không mặc nhiên chia thành hai lần như lịch làm việc hai buổi của giáo viên.

**Kết luận:** Chỉ cần thêm phần ghi chú chung này vào cuối Phụ lục II. Nhà trường vẫn giữ nguyên 30 điểm tiêu chí chung, 70 điểm kết quả thực hiện nhiệm vụ và tổng 100 điểm. Nội dung vừa đủ chặt chẽ để quản lý ngày nghỉ, vừa ngắn gọn, tránh lặp lại trong 7 bảng KPI nhân viên.

---

USER

bạn sắp xếp diễn đạy ý cho câu trả lời này logic chặt chẽ, dễ hiểu hơn

---

ASSISTANT

Tôi sẽ sắp xếp lại câu trả lời theo trình tự: điều kiện đạt từ 90 điểm, cách lựa chọn khi vượt tỷ lệ cho phép, rồi đến căn cứ ưu tiên và minh chứng. Tôi cũng sẽ kiểm tra cách dùng điều kiện “vượt 30% nhiệm vụ” để tránh đưa nhầm tiêu chí đánh giá nhà trường sang đánh giá từng viên chức.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đề xuất diễn đạt lại theo hướng **ngắn gọn, rõ nguyên tắc xét chọn, bảo đảm điểm KPI gắn với tỷ lệ hoàn thành vượt mức và đúng quy định pháp luật** như sau:

> **writing · standard**
>
> **Câu hỏi:** Trường hợp số viên chức đạt từ 90 điểm trở lên vượt tỷ lệ 20% hoặc 25% theo quy định thì Hội đồng đánh giá thực hiện xét chọn danh hiệu Hoàn thành xuất sắc nhiệm vụ như thế nào để bảo đảm công bằng?
>
> **Trả lời:**
>
> Nhà trường căn cứ kết quả đánh giá KPI hằng tháng để tổng hợp điểm đánh giá năm của từng viên chức. Những viên chức đạt từ 90 điểm trở lên được đưa vào diện xem xét xếp loại Hoàn thành xuất sắc nhiệm vụ.
>
> Trường hợp số viên chức đủ điều kiện vượt tỷ lệ quy định, Hội đồng đánh giá xem xét, đề xuất theo thứ tự điểm từ cao xuống thấp. Đối với những trường hợp có điểm bằng nhau, ưu tiên người có tỷ lệ nhiệm vụ hoàn thành vượt yêu cầu cao hơn, chất lượng và hiệu quả công việc nổi trội, có minh chứng cụ thể.
>
> **Việc xét chọn phải kết hợp giữa điểm KPI và tỷ lệ hoàn thành vượt mức nhiệm vụ**, bảo đảm khách quan, công bằng, công khai và không vượt quá tỷ lệ 20% hoặc 25% khi đủ điều kiện theo Nghị định số 233/2026/NĐ-CP. Kết quả xếp loại do người có thẩm quyền quyết định theo quy định.

### ⚠️ Một điểm cần điều chỉnh trong câu trả lời ban đầu

Theo Nghị định số 233/2026/NĐ-CP:

- **Đối với nhà trường:** Điều kiện có ít nhất 30% nhiệm vụ hoàn thành vượt mức yêu cầu áp dụng khi xét xếp loại đơn vị *Hoàn thành xuất sắc nhiệm vụ*.
- **Đối với từng viên chức:** Không bắt buộc phải có 30% nhiệm vụ vượt mức mới được xem xét xếp loại xuất sắc. Nhà trường có thể sử dụng tỷ lệ nhiệm vụ hoàn thành vượt yêu cầu, có minh chứng, làm **tiêu chí ưu tiên khi các cá nhân có điểm KPI bằng nhau**, nếu được quy định thống nhất trong quy chế.

Ngoài ra, tỷ lệ 20% được tính theo số viên chức xếp loại *Hoàn thành tốt nhiệm vụ* trong phạm vi quy định và từng nhóm có nhiệm vụ tương đồng; mức tối đa 25% chỉ áp dụng khi nhà trường đáp ứng điều kiện pháp luật. [Source unavailable: turn551563view0]; [Source unavailable: turn551563view1]

**Tôi đề xuất sử dụng câu trả lời trên trong văn bản giải trình tại Hội nghị viên chức**, đồng thời bổ sung nguyên tắc ưu tiên khi bằng điểm vào Quy chế đánh giá để bảo đảm thống nhất khi thực hiện.

---

USER

---

ASSISTANT

Tôi đề xuất trả lời ngắn gọn, rõ ràng, bảo đảm **đánh giá đúng trách nhiệm cá nhân, không trừ điểm đồng loạt**, đồng thời phù hợp với Quy chế KPI của Trường Mầm non An Bình.

> **writing · standard**
>
> **Câu hỏi:** Quy chế đánh giá, xếp loại viên chức: Khi có sai sót thì trừ điểm tất cả giáo viên cùng lớp hay chỉ trừ điểm giáo viên có sai sót?
>
> **Trả lời:**
>
> Việc đánh giá, chấm điểm KPI được thực hiện đối với từng giáo viên, căn cứ nhiệm vụ được phân công, kết quả thực hiện và minh chứng cụ thể.
>
> Đối với sai sót thuộc trách nhiệm cá nhân, chỉ xem xét trừ điểm giáo viên có sai sót theo tiêu chí tương ứng, không trừ điểm các giáo viên khác cùng lớp.
>
> Đối với nhiệm vụ chung của lớp, nếu có sai sót, nhà trường xem xét trách nhiệm của từng giáo viên dựa trên phân công, mức độ liên quan và kết quả thực hiện thực tế. Trường hợp cả hai giáo viên cùng có trách nhiệm đối với sai sót thì xem xét đánh giá từng người theo mức độ trách nhiệm.
>
> **Nguyên tắc chung:** Đánh giá đúng người, đúng trách nhiệm, có minh chứng; không trừ điểm đồng loạt hoặc quy trách nhiệm cho giáo viên khi chưa có căn cứ xác định.

### 💡 Đề xuất bổ sung vào Quy chế

Để tránh phát sinh thắc mắc khi triển khai, bạn có thể bổ sung một câu ngắn vào **Phụ lục I – KPI giáo viên**, tại phần ghi chú chung:

> **writing · standard**
>
> **Nguyên tắc xác định trách nhiệm khi chấm điểm:** Việc chấm điểm KPI thực hiện theo từng cá nhân. Đối với nhiệm vụ chung của lớp, trường hợp có sai sót phải xác định rõ trách nhiệm, mức độ liên quan của từng giáo viên trên cơ sở phân công và minh chứng; không trừ điểm đồng loạt khi chưa xác định trách nhiệm cụ thể.

**Tôi khuyến nghị sử dụng cách diễn đạt này**, vì vừa bảo đảm công bằng cho giáo viên cùng lớp, vừa xác định được trách nhiệm phối hợp và trách nhiệm cá nhân trong công tác chăm sóc, nuôi dưỡng, giáo dục trẻ.

---

USER

---

ASSISTANT

> **writing · standard**
>
> **Câu hỏi:** Quy chế đánh giá, xếp loại viên chức: Khi có sai sót thì trừ điểm các giáo viên cùng lớp hay chỉ trừ điểm cá nhân giáo viên có sai sót?
>
> **Trả lời:**
>
> KPI quy định cụ thể các tiêu chí, mức điểm tương ứng với kết quả thực hiện từng nhiệm vụ. Việc chấm điểm được thực hiện đối với từng cá nhân, căn cứ vào mức độ hoàn thành nhiệm vụ và minh chứng thực tế.
>
> Đối với nhiệm vụ chung của lớp, nếu xảy ra sai sót, nhà trường xem xét trách nhiệm của từng giáo viên theo phân công và mức độ liên quan để chấm điểm phù hợp. **Không trừ điểm đồng loạt các giáo viên cùng lớp khi chưa xác định rõ trách nhiệm.**
>
> Việc đánh giá phải bảo đảm khách quan, công bằng, đúng người, đúng trách nhiệm và đúng tiêu chí KPI đã quy định.

---

