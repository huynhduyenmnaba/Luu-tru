USER

PHT của bạn là người nhiệt huyết, có tinh thần trách nhiệm cao và luôn hoàn thành xuất sắc các nhiệm vụ. Luôn lắng nghe, hỗ trợ đồng nghiệp nhiệt tình ngay cả khi giáo viên chưa hoàn thành nhiệm vụ . Tuy nhiên vẫn bị các đồng nghiệp góp ý vào trong quy chế ứng xử  dành cho PHT rất khó nghe, (không nêu tên, không nói thắng) mượn cớ góp ý quy chế để nói (tạo áp lực, quát mắng, xúc phạm... đùn đấy trách nhiệm, nói xéo chuyện này qua chuyện khác. Trong cuộc họp nếu bạn là người PHT đó bạn sẽ nói gì

---

ASSISTANT

## 📌 Nếu tôi là Phó Hiệu trưởng trong tình huống này, tôi sẽ nói gì?

Ở vị trí Phó Hiệu trưởng (PHT), khi bản thân luôn tận tâm, trách nhiệm, sẵn sàng hỗ trợ giáo viên, kể cả những trường hợp chưa hoàn thành nhiệm vụ, nhưng lại phải nghe những lời góp ý nặng nề, mang tính ám chỉ trong cuộc họp, chắc chắn sẽ có cảm giác chạnh lòng và tổn thương.

Tuy nhiên, **tôi sẽ không im lặng hoàn toàn, cũng không phản ứng bằng sự bức xúc.** Tôi sẽ phát biểu với thái độ bình tĩnh, chân thành nhưng đủ bản lĩnh để bảo vệ sự công bằng, lòng tự trọng và trách nhiệm của người cán bộ quản lý.

### 🎤 Lời phát biểu tôi sẽ lựa chọn trong cuộc họp

> **writing · standard**
>
> Trước hết, tôi rất trân trọng những ý kiến đóng góp của các đồng chí đối với dự thảo Quy chế ứng xử của nhà trường. Tôi cho rằng việc xây dựng quy chế không chỉ để có một văn bản thực hiện mà quan trọng hơn là để mỗi cán bộ, giáo viên, nhân viên cùng nhìn nhận, điều chỉnh hành vi và xây dựng một môi trường làm việc đoàn kết, tôn trọng lẫn nhau.
>
> Đối với những nội dung góp ý liên quan đến trách nhiệm và cách ứng xử của Phó Hiệu trưởng như: gây áp lực, quát mắng, xúc phạm đồng nghiệp, đùn đẩy trách nhiệm hay có những lời nói thiếu tế nhị, tôi hoàn toàn đồng tình rằng đây là những hành vi không phù hợp, cần được phòng tránh trong môi trường sư phạm.
>
> Tuy nhiên, tôi cũng xin được chia sẻ một vài suy nghĩ từ góc độ người trực tiếp thực hiện nhiệm vụ quản lý.
>
> Trong công việc, tôi luôn quan niệm rằng trách nhiệm của người quản lý không chỉ là phân công, kiểm tra, đôn đốc mà còn phải đồng hành, hỗ trợ và tạo điều kiện để giáo viên hoàn thành tốt nhiệm vụ. Đó cũng là điều tôi luôn cố gắng thực hiện.
>
> Tôi không dám khẳng định bản thân mình hoàn hảo, cũng không cho rằng mọi lời nói, cách làm của mình lúc nào cũng phù hợp. Nếu trong quá trình làm việc, có lúc tôi trao đổi chưa khéo léo, nhắc nhở chưa thật sự tế nhị hoặc khiến đồng nghiệp cảm thấy áp lực, tôi sẵn sàng lắng nghe, nhìn nhận và điều chỉnh.
>
> **Nhưng tôi cũng mong các đồng chí hiểu rằng, giữa việc thực hiện trách nhiệm quản lý, nhắc nhở để công việc hoàn thành đúng yêu cầu với việc cố tình gây áp lực, quát mắng hay xúc phạm đồng nghiệp là hai vấn đề hoàn toàn khác nhau.**
>
> Người quản lý phải có trách nhiệm với công việc chung, nhưng mỗi cá nhân cũng cần có trách nhiệm với nhiệm vụ được giao. Sự hỗ trợ của người quản lý không thể thay thế hoàn toàn trách nhiệm của người thực hiện.
>
> Tôi rất mong rằng mọi ý kiến đóng góp, đặc biệt là những ý kiến liên quan đến thái độ, hành vi và phẩm chất của một cá nhân, cần xuất phát từ những sự việc cụ thể, được trao đổi thẳng thắn, khách quan và trên tinh thần xây dựng.
>
> **Bởi vì lời góp ý có thể giúp một người tốt hơn, nhưng nếu thiếu sự cụ thể và công bằng thì đôi khi lại vô tình làm tổn thương chính người đang cố gắng hết lòng vì công việc chung.**
>
> Tôi luôn sẵn sàng tiếp thu những điều mình chưa tốt, nhưng cũng mong những nỗ lực, trách nhiệm và thiện chí của mỗi người được nhìn nhận một cách công bằng.
>
> Cuối cùng, tôi mong rằng Quy chế ứng xử của nhà trường sẽ thực sự trở thành chuẩn mực chung cho tất cả chúng ta, từ cán bộ quản lý đến giáo viên, nhân viên; không chỉ quy định cách người quản lý ứng xử với giáo viên mà còn đề cao sự tôn trọng, trách nhiệm và tinh thần hợp tác hai chiều.
>
> **Tôi không mong được mọi người đồng tình trong tất cả mọi việc, nhưng tôi mong chúng ta có thể khác nhau về quan điểm mà vẫn dành cho nhau sự tôn trọng.**
>
> Xin cảm ơn các đồng chí!

### 💡 Điều tôi muốn thể hiện qua lời phát biểu này

Có ba thông điệp quan trọng:

- **Tôi sẵn sàng nhận góp ý, nhưng không đồng nghĩa với việc chấp nhận mọi nhận xét thiếu căn cứ.** Góp ý cần khách quan, cụ thể, hướng tới thay đổi tích cực.
- **Tôi luôn hỗ trợ giáo viên, nhưng không thể làm thay trách nhiệm của giáo viên.** Đôn đốc thực hiện nhiệm vụ đúng quy định không đồng nghĩa với gây áp lực hoặc xúc phạm.
- **Sự tôn trọng phải đến từ hai phía.** Người quản lý phải chuẩn mực trong ứng xử, đồng thời cũng xứng đáng được đồng nghiệp đối xử công bằng và tôn trọng.

### ⚠️ Một điều rất quan trọng

Nếu tôi là PHT đó, tôi sẽ không kể lại mình đã giúp giáo viên nào, hỗ trợ bao nhiêu lần hay đã phải làm thay những công việc gì. Bởi điều đó dễ khiến cuộc họp chuyển thành sự đối đầu giữa người quản lý và giáo viên.

Tôi sẽ phát biểu chậm rãi, điềm tĩnh, không nhắm vào bất kỳ cá nhân nào, nhưng nói thật rõ quan điểm của mình.

**Đặc biệt, tôi muốn hỏi bạn thêm một điều:** Bạn muốn lời phát biểu của PHT theo hướng **nhẹ nhàng, sâu sắc, khiến đồng nghiệp tự suy ngẫm và cảm thấy áy náy**, hay theo hướng **đanh thép, sắc sảo, có sức nặng của người quản lý, khiến những người góp ý thiếu thiện chí phải nhìn nhận lại cách ứng xử của mình**?

Hai cách nói sẽ rất khác nhau, nhất là trong một cuộc họp hội đồng sư phạm.

---

