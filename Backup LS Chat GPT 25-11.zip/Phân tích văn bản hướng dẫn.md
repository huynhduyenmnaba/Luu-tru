USER

bạn giúp tôi xem trường cần làm gì với văn bản hướng dẫn này

---

ASSISTANT

Tôi sẽ giúp cô phân tích văn bản hướng dẫn dưới góc độ **quản lý của Hiệu trưởng trường mầm non**, tập trung xác định **nhà trường cần làm những việc gì, ai thực hiện, thời hạn khi nào và cần chuẩn bị hồ sơ gì**.

Cô vui lòng **gửi file văn bản (PDF, Word hoặc ảnh chụp)** nhé. Hiện tôi chưa thấy văn bản đính kèm.

Sau khi đọc, tôi sẽ giúp cô làm rõ:

1. **Nội dung chỉ đạo:** Văn bản yêu cầu những gì? Nội dung nào liên quan trực tiếp đến trường mầm non?
2. **Nhiệm vụ của nhà trường:** Việc nào bắt buộc thực hiện, việc nào chỉ cần triển khai hoặc phổ biến?
3. **Cách tổ chức thực hiện:** Hiệu trưởng, Phó Hiệu trưởng, tổ chuyên môn, giáo viên và nhân viên cần làm gì?
4. **Hồ sơ cần chuẩn bị:** Có phải xây dựng kế hoạch, ban hành quyết định, tổ chức họp, lập báo cáo hoặc lưu minh chứng không?
5. **Thời hạn thực hiện:** Có mốc thời gian, yêu cầu gửi báo cáo hoặc đơn vị nhận báo cáo không?

Đặc biệt, tôi sẽ lập cho cô **bảng phân công công việc cụ thể, dễ triển khai**, đồng thời chỉ ra những nội dung nhà trường cần lưu ý để không thực hiện thiếu hoặc làm phát sinh hồ sơ không cần thiết.

**Cô gửi văn bản lên đây, tôi sẽ phân tích và đề xuất ngay các việc trường cần thực hiện.**

---

USER

---

ASSISTANT

Tôi đã nhận được bộ văn bản. Điểm quan trọng là trong hồ sơ có cả bản dự thảo và Quyết định số 3463/QĐ-UBND đã ban hành ngày 03/11/2026. Tôi sẽ căn cứ vào quyết định chính thức và phụ lục kèm theo để xác định người phải kê khai, các bước nhà trường cần làm và những nội dung cần xin hướng dẫn thêm.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 PHÂN TÍCH VĂN BẢN VÀ NHỮNG VIỆC TRƯỜNG MẦM NON CẦN THỰC HIỆN

Tôi đã nghiên cứu bộ văn bản cô gửi, đặc biệt là **Quyết định số 3463/QĐ-UBND ngày 03/11/2026 của Chủ tịch UBND tỉnh Đồng Tháp** về việc ban hành Danh mục người có nghĩa vụ kê khai tài sản, thu nhập hằng năm.

## 🎯 1. Kết luận quan trọng đối với trường mầm non

**Hiệu trưởng trường mầm non công lập thuộc UBND cấp xã là đối tượng phải kê khai tài sản, thu nhập hằng năm.**

Nội dung này được quy định tại mục 11, Phụ lục 2 của Quyết định số 3463/QĐ-UBND.

**Phó Hiệu trưởng, kế toán, thủ quỹ, tổ trưởng chuyên môn và giáo viên không được tự động xác định là phải kê khai hằng năm chỉ vì đang giữ các vị trí này.**

Cần rà soát thêm các căn cứ pháp lý và hướng dẫn của cơ quan quản lý đối với từng trường hợp.

Quyết định chính thức đã có hiệu lực kể từ ngày ký 03/11/2026, vì vậy **nhà trường không cần tiếp tục góp ý bản dự thảo** mà cần chuyển sang rà soát đối tượng và tổ chức thực hiện. [Chi tiết văn bản \- Cổng thông tin điện tử tỉnh Đồng Tháp](<https://www.dongthap.gov.vn/vi/web/cong-thong-tin-dtp/chi-tiet?id=11862609>); [Quyết định 3463/QĐ\-UBND 2026 danh mục người có nghĩa vụ kê khai tài sản thu nhập hằng năm Đồng Tháp](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Quyet-dinh-3463-QD-UBND-2026-danh-muc-nguoi-co-nghia-vu-ke-khai-tai-san-thu-nhap-hang-nam-Dong-Thap-731737.aspx>)

Đối với trường mầm non, tôi đề xuất tập trung vào ba việc: xác định đúng người kê khai, thực hiện bản kê khai đúng quy định và phối hợp cơ quan quản lý trong việc tiếp nhận, công khai, lưu hồ sơ.

## 📋 2. Bảng công việc nhà trường cần thực hiện

Dưới đây là bảng tôi đề xuất để nhà trường triển khai trong năm 2026.

| STT | Công việc cần thực hiện | Người thực hiện | Thời điểm |
|--------|--------|--------|--------|
| 1 | Tiếp nhận, lưu và triển khai Quyết định số 3463/QĐ-UBND | Hiệu trưởng, văn thư | Ngay |
| 2 | Rà soát các chức danh thuộc diện kê khai tài sản, thu nhập hằng năm | Hiệu trưởng phối hợp bộ phận tham mưu | Ngay |
| 3 | Xác nhận danh sách người phải kê khai với UBND xã/phường hoặc cơ quan được giao quản lý | Nhà trường phối hợp cơ quan quản lý | Theo hướng dẫn |
| 4 | Chuẩn bị và thực hiện bản kê khai tài sản, thu nhập năm 2026 theo mẫu hiện hành | Người có nghĩa vụ kê khai | Hoàn thành trước 31/12/2026 |
| 5 | Nộp bản kê khai, thực hiện giao nhận theo đúng đầu mối có thẩm quyền | Người kê khai và đơn vị được giao tiếp nhận | Theo hướng dẫn |
| 6 | Phối hợp tổ chức công khai bản kê khai đúng quy định | Cơ quan, đơn vị có trách nhiệm | Sau khi bàn giao bản kê khai |
| 7 | Lưu hồ sơ, sổ giao nhận và minh chứng thực hiện theo trách nhiệm được phân công | Văn thư hoặc bộ phận được giao | Sau khi hoàn thành |

Các nhiệm vụ lập danh sách, hướng dẫn, tiếp nhận, bàn giao bản kê khai được quy định tại Điều 37 và Điều 38 Luật Phòng, chống tham nhũng. [Văn bản hợp nhất 164/2026/VBHN\-LQ\-VPQH Luật Phòng chống tham nhũng](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Van-ban-hop-nhat-164-2026-VBHN-LQ-VPQH-Luat-Phong-chong-tham-nhung-728315.aspx?tab=1>); [Văn bản hợp nhất 164/2026/VBHN\-LQ\-VPQH Luật Phòng chống tham nhũng](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Van-ban-hop-nhat-164-2026-VBHN-LQ-VPQH-Luat-Phong-chong-tham-nhung-728315.aspx?tab=1>)

## 🔍 3. Những nội dung nhà trường cần chú ý

### A. Hiệu trưởng phải kê khai những gì?

Theo Nghị định số 164/2026/NĐ-CP, bản kê khai bao gồm tài sản, thu nhập thuộc diện phải kê khai của bản thân, vợ hoặc chồng và con chưa thành niên.

Một số nội dung quan trọng là quyền sử dụng đất, nhà ở, tài sản gắn liền với đất, tiền, kim khí quý, giấy tờ có giá, tài sản số và các tài sản, khoản nợ thuộc ngưỡng quy định. [Nghị định 164/2026/NĐ\-CP kiểm soát tài sản của người có chức vụ trong cơ quan đơn vị mới nhất](<https://thuvienphapluat.vn/van-ban/Lao-dong-Tien-luong/Nghi-dinh-164-2026-ND-CP-kiem-soat-tai-san-cua-nguoi-co-chuc-vu-trong-co-quan-don-vi-706259.aspx?anchor=dieu_1>); [Nghị định 164/2026/NĐ\-CP kiểm soát tài sản của người có chức vụ trong cơ quan đơn vị mới nhất](<https://thuvienphapluat.vn/van-ban/Lao-dong-Tien-luong/Nghi-dinh-164-2026-ND-CP-kiem-soat-tai-san-cua-nguoi-co-chuc-vu-trong-co-quan-don-vi-706259.aspx?anchor=dieu_1>)

Khi thực hiện bằng bản giấy, người kê khai cần:

- Sử dụng đúng mẫu theo Nghị định số 164/2026/NĐ-CP, lập 02 bản, ký từng trang và ký, ghi rõ họ tên ở trang cuối.
- Ghi đầy đủ các mục; nếu không có thì ghi “không có”, không tự ý bỏ mục hoặc thay đổi cấu trúc biểu mẫu.
- Kê khai đầy đủ, trung thực và giải trình biến động tài sản, thu nhập theo yêu cầu của mẫu.

### B. Phó Hiệu trưởng có phải kê khai không?

Đây là nội dung tôi đề nghị nhà trường đặc biệt lưu ý.

Phụ lục 2 của Quyết định số 3463/QĐ-UBND ghi rõ **Hiệu trưởng trường mầm non**, nhưng không liệt kê riêng chức danh Phó Hiệu trưởng trường mầm non.

Tuy nhiên, cần phân biệt nghĩa vụ **kê khai hằng năm** với kê khai lần đầu, kê khai bổ sung hoặc kê khai phục vụ công tác cán bộ. Phó Hiệu trưởng có thể phát sinh nghĩa vụ kê khai theo các quy định khác, tùy chức vụ và trường hợp cụ thể. [Văn bản hợp nhất 164/2026/VBHN\-LQ\-VPQH Luật Phòng chống tham nhũng](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Van-ban-hop-nhat-164-2026-VBHN-LQ-VPQH-Luat-Phong-chong-tham-nhung-728315.aspx?tab=1>); [Văn bản hợp nhất 164/2026/VBHN\-LQ\-VPQH Luật Phòng chống tham nhũng](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Van-ban-hop-nhat-164-2026-VBHN-LQ-VPQH-Luat-Phong-chong-tham-nhung-728315.aspx?tab=1>)

**Đề xuất:** Nhà trường nên đề nghị UBND xã/phường hoặc cơ quan quản lý xác nhận đối tượng kê khai năm 2026, tránh tự ý đưa toàn bộ Ban Giám hiệu vào danh sách hoặc bỏ sót người thuộc diện phải kê khai.

### C. Có phải tổ chức họp công khai bản kê khai không?

Có quy định về công khai bản kê khai, nhưng **nhà trường cần xác định đúng cơ quan chịu trách nhiệm và hình thức công khai**, nhất là đối với bản kê khai của Hiệu trưởng thuộc diện quản lý của UBND cấp xã.

Theo Điều 11 Nghị định số 164/2026/NĐ-CP, việc công khai được thực hiện theo hình thức phù hợp với đối tượng và đơn vị quản lý. Các mốc cần lưu ý gồm:

| Nội dung | Quy định |
|--------|--------|
| Thời hạn công khai | Chậm nhất 05 ngày làm việc kể từ ngày bàn giao bản kê khai cho cơ quan kiểm soát có thẩm quyền |
| Nếu niêm yết | Thời gian niêm yết 15 ngày, có lập biên bản |
| Nếu công khai tại cuộc họp | Có mặt tối thiểu 2/3 số người được triệu tập và lập biên bản |

[Nghị định 164/2026/NĐ\-CP kiểm soát tài sản của người có chức vụ trong cơ quan đơn vị mới nhất](<https://thuvienphapluat.vn/van-ban/Lao-dong-Tien-luong/Nghi-dinh-164-2026-ND-CP-kiem-soat-tai-san-cua-nguoi-co-chuc-vu-trong-co-quan-don-vi-706259.aspx?anchor=dieu_1>); [Nghị định 164/2026/NĐ\-CP kiểm soát tài sản của người có chức vụ trong cơ quan đơn vị mới nhất](<https://thuvienphapluat.vn/van-ban/Lao-dong-Tien-luong/Nghi-dinh-164-2026-ND-CP-kiem-soat-tai-san-cua-nguoi-co-chuc-vu-trong-co-quan-don-vi-706259.aspx?anchor=dieu_1>)

Nhà trường không nên tự đăng tải bản kê khai lên website, nhóm Zalo hoặc gửi rộng rãi khi chưa được xác định đúng phạm vi công khai.

## 💡 4. Nhà trường có cần ban hành kế hoạch hoặc báo cáo riêng không?

**Quyết định số 3463/QĐ-UBND không yêu cầu mỗi trường mầm non phải xây dựng một kế hoạch riêng hoặc nộp báo cáo riêng ngay sau khi nhận quyết định.**

Vì vậy, tôi đề xuất:

- Nếu chưa có văn bản triển khai của UBND xã/phường, nhà trường chủ động rà soát đối tượng và chuẩn bị kê khai, đồng thời xác nhận nơi tiếp nhận hồ sơ.
- Nếu UBND xã/phường ban hành văn bản yêu cầu lập danh sách, báo cáo hoặc tổ chức công khai, nhà trường thực hiện đúng nội dung, thời hạn và biểu mẫu được giao.
- Hồ sơ tại trường chỉ cần bảo đảm có văn bản chỉ đạo, tài liệu triển khai và các minh chứng thuộc trách nhiệm của trường; không nhất thiết phải ban hành thêm nhiều văn bản hành chính.

## ✅ 5. Kết luận và đề xuất của tôi

Đối với trường mầm non công lập thuộc UBND xã/phường tỉnh Đồng Tháp, việc cần ưu tiên ngay là **thực hiện kê khai tài sản, thu nhập hằng năm của Hiệu trưởng trước ngày 31/12/2026**, đồng thời rà soát các đối tượng khác và phối hợp với cơ quan quản lý để bảo đảm đúng quy trình.

Tôi muốn làm rõ thêm với cô một thông tin quan trọng:

**Trường của cô hiện là trường mầm non công lập trực thuộc UBND xã/phường phải không?**

Thông tin này sẽ giúp tôi xác định chính xác hơn việc **Hiệu trưởng nộp bản kê khai cho ai, nhà trường có phải lập danh sách riêng không và việc công khai thực hiện tại trường hay UBND xã/phường**.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

ASSISTANT

---

USER

**rường của cô hiện là trường mầm non công lập trực thuộc UBND**  phường

---

ASSISTANT

## 📌 Hướng dẫn thực hiện đối với trường mầm non công lập trực thuộc UBND phường

Như vậy, tôi xác định cụ thể cho trường cô như sau:

Căn cứ **Quyết định số 3463/QĐ-UBND ngày 03/11/2026 của Chủ tịch UBND tỉnh Đồng Tháp**, tại mục 11, Phụ lục 2:

**Hiệu trưởng trường mầm non công lập trực thuộc UBND phường thuộc diện phải kê khai tài sản, thu nhập hằng năm.**

Đây là nghĩa vụ kê khai của cá nhân Hiệu trưởng. Nhà trường có trách nhiệm phối hợp thực hiện theo hướng dẫn của cơ quan quản lý; không phải toàn bộ giáo viên, nhân viên đều bắt buộc kê khai hằng năm.

## 📋 Nhà trường cần thực hiện 5 công việc cụ thể

| Công việc | Cách thực hiện |
|--------|--------|
| **1. Rà soát đối tượng** | Xác định Hiệu trưởng thuộc diện kê khai hằng năm; rà soát Phó Hiệu trưởng và các chức danh khác theo quy định liên quan |
| **2. Xác định nơi nộp** | Liên hệ UBND phường để xác nhận bộ phận được giao tiếp nhận bản kê khai của Hiệu trưởng |
| **3. Thực hiện kê khai** | Hiệu trưởng kê khai theo mẫu ban hành kèm Nghị định 164/2026/NĐ-CP; nếu kê khai bằng giấy, lập 02 bản và ký từng trang |
| **4. Phối hợp công khai** | Thực hiện theo hình thức và phạm vi do cơ quan có thẩm quyền hướng dẫn; lập biên bản theo quy định |
| **5. Lưu minh chứng** | Lưu văn bản chỉ đạo, chứng từ giao nhận, biên bản công khai và hồ sơ thuộc trách nhiệm của trường |

Hạn cuối hoàn thành kê khai hằng năm là **trước ngày 31/12/2026**. [Văn bản hợp nhất 164/2026/VBHN\-LQ\-VPQH Luật Phòng chống tham nhũng](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Van-ban-hop-nhat-164-2026-VBHN-LQ-VPQH-Luat-Phong-chong-tham-nhung-728315.aspx?tab=7>); [Mẫu kê khai tài sản thu nhập và hướng dẫn điền từ 01/7/2026 \(Nghị định 164/2026\)](<https://thuvienphapluat.vn/chinh-sach-phap-luat-moi/vn/bieu-mau/113119/mau-ke-khai-tai-san-thu-nhap-va-huong-dan-dien-tu-01-7-2026-nghi-dinh-164-2026>)

## 🔍 Hiệu trưởng nộp bản kê khai cho ai?

Đây là nội dung cần phân biệt rõ.

Theo Điều 37, Điều 38 Luật Phòng, chống tham nhũng, người kê khai nộp bản kê khai cho cơ quan, tổ chức, đơn vị quản lý, sử dụng mình. Cơ quan tiếp nhận có trách nhiệm kiểm tra và bàn giao bản kê khai cho cơ quan kiểm soát tài sản, thu nhập có thẩm quyền. [Văn bản hợp nhất số 164/2026/VBHN\-LQ\-VPQH hợp nhất Luật Phòng, chống tham nhũng \| Cổng Luật Việt](<https://congluatviet.vn/van-ban/van-ban-hop-nhat-hop-nhat-luat-phong-chong-tham-nhung-164-2026-vbhn-lq-vpqh?at=2026-09-29>)

Vì trường trực thuộc UBND phường, **tôi đề xuất cô làm việc với UBND phường, thông qua Phòng Văn hóa - Xã hội hoặc bộ phận được phân công**, để xác nhận nơi nộp hồ sơ.

Quyết định số 3463/QĐ-UBND không quy định cụ thể phòng nào nhận bản kê khai của Hiệu trưởng. Vì vậy, chưa thể khẳng định phải nộp cho Phòng Văn hóa - Xã hội, Văn phòng HĐND và UBND hay bộ phận khác.

## ⚠️ Nhà trường có phải tổ chức họp công khai không?

Bản kê khai phải được công khai theo quy định. Tuy nhiên, nhà trường cần thống nhất với UBND phường về địa điểm và trách nhiệm tổ chức.

Nếu công khai tại cuộc họp, phải có ít nhất 2/3 số người được triệu tập và lập biên bản. Nếu niêm yết, thời gian là 15 ngày. [Điều 11 Nghị định 164/2026/NĐ\-CP: Việc công khai bản kê khai tại cơ quan, tổ chức, đơn vị](<https://vanban.org/van-ban/nghi-dinh-164-2026-nd-cp-kiem-soat-tai-san-thu-nhap-nguoi-chuc-vu-quyen-han/dieu-11>)

**Không nên tự tổ chức công khai bản kê khai của Hiệu trưởng khi chưa xác định rõ đầu mối và hình thức thực hiện.**

## ✅ Đề xuất thực hiện ngay

Với tình hình hiện nay, tôi khuyến nghị nhà trường chủ động liên hệ UBND phường để thống nhất ba nội dung: danh sách người kê khai năm 2026, nơi tiếp nhận bản kê khai và trách nhiệm công khai.

Nhà trường chưa cần ban hành một kế hoạch riêng chỉ để triển khai Quyết định số 3463/QĐ-UBND nếu UBND phường không yêu cầu.

Đặc biệt, **không tự động yêu cầu Phó Hiệu trưởng và kế toán kê khai hằng năm chỉ dựa vào chức danh** khi chưa xác định đủ căn cứ.

Cô có thể xem văn bản chính thức tại [Cổng thông tin điện tử tỉnh Đồng Tháp](<https://www.dongthap.gov.vn/chi-tiet?id=11862609>)\.

Tôi đề xuất bước tiếp theo là xây dựng một **bảng rà soát người có nghĩa vụ kê khai tài sản, thu nhập năm 2026** dành riêng cho trường mầm non, để cô sử dụng khi làm việc với UBND phường.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

## 📋 Nhà trường cần thực hiện 5 công việc cụ thể

| Công việc | Cách thực hiện |
|---|---|
| **1. Rà soát đối tượng** | Xác định Hiệu trưởng thuộc diện kê khai hằng năm; rà soát Phó Hiệu trưởng và các chức danh khác theo quy định liên quan |
| **2. Xác định nơi nộp** | Liên hệ UBND phường để xác nhận bộ phận được giao tiếp nhận bản kê khai của Hiệu trưởng |
| **3. Thực hiện kê khai** | Hiệu trưởng kê khai theo mẫu ban hành kèm Nghị định 164/2026/NĐ-CP; nếu kê khai bằng giấy, lập 02 bản và ký từng trang |
| **4. Phối hợp công khai** | Thực hiện theo hình thức và phạm vi do cơ quan có thẩm quyền hướng dẫn; lập biên bản theo quy định |
| **5. Lưu minh chứng** | Lưu văn bản chỉ đạo, chứng từ giao nhận, biên bản công khai và hồ sơ thuộc trách nhiệm của trường |

Hạn cuối hoàn thành kê khai hằng năm là **trước ngày 31/12/2026**. [Source unavailable: turn399512search2]; [Source unavailable: turn443305search4]

## 🔍 Hiệu trưởng nộp bản kê khai cho ai?

Đây là nội dung cần phân biệt rõ.

Theo Điều 37, Điều 38 Luật Phòng, chống tham nhũng, người kê khai nộp bản kê khai cho cơ quan, tổ chức, đơn vị quản lý, sử dụng mình. Cơ quan tiếp nhận có trách nhiệm kiểm tra và bàn giao bản kê khai cho cơ quan kiểm soát tài sản, thu nhập có thẩm quyền. <Cite ref="turn399512search6"/>

Vì trường trực thuộc UBND phường, **tôi đề xuất cô làm việc với UBND phường, thông qua Phòng Văn hóa - Xã hội hoặc bộ phận được phân công**, để xác nhận nơi nộp hồ sơ.

Quyết định số 3463/QĐ-UBND không quy định cụ thể phòng nào nhận bản kê khai của Hiệu trưởng. Vì vậy, chưa thể khẳng định phải nộp cho Phòng Văn hóa - Xã hội, Văn phòng HĐND và UBND hay bộ phận khác.

## ⚠️ Nhà trường có phải tổ chức họp công khai không?

Bản kê khai phải được công khai theo quy định. Tuy nhiên, nhà trường cần thống nhất với UBND phường về địa điểm và trách nhiệm tổ chức.

Nếu công khai tại cuộc họp, phải có ít nhất 2/3 số người được triệu tập và lập biên bản. Nếu niêm yết, thời gian là 15 ngày. <Cite ref="turn443305search1"/>

**Không nên tự tổ chức công khai bản kê khai của Hiệu trưởng khi chưa xác định rõ đầu mối và hình thức thực hiện.**

## ✅ Đề xuất thực hiện ngay

Với tình hình hiện nay, tôi khuyến nghị nhà trường chủ động liên hệ UBND phường để thống nhất ba nội dung: danh sách người kê khai năm 2026, nơi tiếp nhận bản kê khai và trách nhiệm công khai.

Nhà trường chưa cần ban hành một kế hoạch riêng chỉ để triển khai Quyết định số 3463/QĐ-UBND nếu UBND phường không yêu cầu.

Đặc biệt, **không tự động yêu cầu Phó Hiệu trưởng và kế toán kê khai hằng năm chỉ dựa vào chức danh** khi chưa xác định đủ căn cứ.

Cô có thể xem văn bản chính thức tại <Link url="https://www.dongthap.gov.vn/chi-tiet?id=11862609" title="Cổng thông tin điện tử tỉnh Đồng Tháp"/>.

Tôi đề xuất bước tiếp theo là xây dựng một **bảng rà soát người có nghĩa vụ kê khai tài sản, thu nhập năm 2026** dành riêng cho trường mầm non, để cô sử dụng khi làm việc với UBND phường.

---

