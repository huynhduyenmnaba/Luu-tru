USER

dựa vào hướng dẫn này bạn giúp tôi phân công cụ thể nhiệm vụ của 3 chi ủy để hoàn thành hồ sơ của chi bộ. Thời gian hoàn thành16h00 ngày 6/11. bạn đảm bảo tính chính xác nooi65 dung nhé

---

ASSISTANT

Tôi sẽ bám sát Kế hoạch số 122-KH/ĐU và phụ lục hồ sơ kèm theo để phân công cho 3 đồng chí chi ủy viên. Tôi cũng sẽ tách rõ hồ sơ phải chuẩn bị xong trước 16 giờ ngày 06/11 với những tài liệu chỉ có thể hoàn thiện sau hội nghị kiểm điểm, tránh yêu cầu lập hồ sơ khi chưa đủ căn cứ.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Tôi đã đối chiếu **Kế hoạch số 122-KH/ĐU ngày 16/10/2026 của Ban Thường vụ Đảng ủy phường An Bình**, đặc biệt là Mục II, III, IV, V và Phụ lục danh mục hồ sơ.

**Có 3 mốc thời gian cần phân biệt:**

- **16 giờ 00 ngày 06/11/2026:** Thời hạn nội bộ do đồng chí yêu cầu để 3 chi ủy viên hoàn thành hồ sơ chuẩn bị kiểm điểm, đánh giá, xếp loại năm 2026.
- **Chậm nhất ngày 09/11/2026:** Báo cáo thời gian tổ chức kiểm điểm về Ban Thường vụ Đảng ủy phường, qua Ban Xây dựng Đảng.
- **Chậm nhất ngày 13/11/2026:** Hoàn thành việc tổ chức kiểm điểm, đánh giá, xếp loại theo Kế hoạch 122.

Đặc biệt, **biên bản hội nghị, biên bản kiểm phiếu và kết quả kiểm điểm chính thức chỉ được hoàn thiện sau khi hội nghị thực sự diễn ra**. Vì vậy, tôi phân công theo hướng ngày 06/11 phải hoàn thành toàn bộ nội dung có thể chuẩn bị trước hội nghị; các tài liệu phát sinh sau hội nghị sẽ có người chịu trách nhiệm hoàn thiện tiếp.

Dưới đây là dự thảo phân công theo cơ cấu chi ủy gồm **Bí thư, Phó Bí thư và Chi ủy viên**, xác định rõ người phụ trách, nội dung, sản phẩm và thời gian bàn giao.

> **writing · document**
>
> **ĐẢNG BỘ [TÊN ĐẢNG BỘ CẤP TRÊN]**  
> **CHI BỘ [TÊN CHI BỘ]**  
> *  
> **ĐẢNG CỘNG SẢN VIỆT NAM**
>
> *Ngày 05 tháng 11 năm 2026*
>
> # PHÂN CÔNG NHIỆM VỤ
> **Chuẩn bị hồ sơ kiểm điểm, đánh giá, xếp loại chất lượng chi bộ, chi ủy và đảng viên năm 2026**
>
> Căn cứ Kế hoạch số 122-KH/ĐU, ngày 16/10/2026 của Ban Thường vụ Đảng ủy phường An Bình về tổ chức kiểm điểm và đánh giá, xếp loại chất lượng đối với tập thể, cá nhân trong hệ thống chính trị Phường năm 2026;
>
> Để bảo đảm công tác chuẩn bị hồ sơ đầy đủ, đúng nội dung, biểu mẫu, quy trình và thời gian quy định, Chi ủy phân công nhiệm vụ cụ thể cho 03 đồng chí như sau:
>
> ## I. PHÂN CÔNG NHIỆM VỤ
>
> ### 1. Đồng chí [Họ và tên] – Bí thư Chi bộ
>
> **Phụ trách chung; trực tiếp chịu trách nhiệm về nội dung báo cáo kiểm điểm tập thể và chất lượng toàn bộ hồ sơ.**
>
> **Nhiệm vụ cụ thể:**
>
> 1. Chủ trì xây dựng kế hoạch tổ chức kiểm điểm, đánh giá, xếp loại chất lượng năm 2026 của chi bộ; xác định đối tượng, nội dung, thời gian, địa điểm, thành phần và chương trình hội nghị kiểm điểm.
>
> 2. Trực tiếp chủ trì xây dựng **dự thảo Báo cáo kiểm điểm tập thể chi ủy theo Mẫu 01B**, tập trung vào:
>    - Kết quả lãnh đạo thực hiện nhiệm vụ chính trị năm 2026.
>    - Việc thực hiện nguyên tắc tổ chức và sinh hoạt Đảng; nguyên tắc tập trung dân chủ; chế độ làm việc của chi ủy.
>    - Công tác xây dựng Đảng, quản lý, giáo dục đảng viên; công tác kiểm tra, giám sát và thực hiện các nhiệm vụ được giao.
>    - Những hạn chế, khuyết điểm; nguyên nhân khách quan, chủ quan; trách nhiệm của tập thể, cá nhân có liên quan.
>    - Kết quả khắc phục hạn chế sau kiểm điểm kỳ trước (nếu có); phương hướng, biện pháp khắc phục trong thời gian tới.
>
> 3. Xây dựng bản tóm tắt ưu điểm, hạn chế của tập thể theo **Mẫu 3** trong Phụ lục Kế hoạch 122.
>
> 4. Chỉ đạo việc chuẩn bị nội dung tự đánh giá, đề xuất xếp loại chất lượng đối với chi bộ và chi ủy; rà soát sự phù hợp giữa kết quả thực hiện nhiệm vụ với mức xếp loại đề xuất.
>
> 5. Kiểm tra, cho ý kiến đối với toàn bộ hồ sơ do Phó Bí thư và Chi ủy viên chuẩn bị; chỉ đạo chỉnh sửa những nội dung chưa đầy đủ, thiếu minh chứng hoặc chưa đúng biểu mẫu.
>
> 6. Chỉ đạo gửi dự thảo báo cáo kiểm điểm để lấy ý kiến đúng thời gian quy định; báo cáo thời gian tổ chức hội nghị kiểm điểm với cấp ủy cấp trên qua đầu mối được hướng dẫn.
>
> **Sản phẩm phải hoàn thành:**
> - Kế hoạch tổ chức kiểm điểm, đánh giá, xếp loại năm 2026 của chi bộ.
> - Dự thảo Báo cáo kiểm điểm tập thể chi ủy – Mẫu 01B.
> - Bản tóm tắt ưu điểm, hạn chế tập thể – Mẫu 3.
> - Dự kiến chương trình, thời gian tổ chức hội nghị kiểm điểm.
> - Kết quả rà soát, thống nhất toàn bộ hồ sơ chuẩn bị của chi bộ.
>
> **Thời gian:** Hoàn thành dự thảo các nội dung chính trước 14 giờ 00; kiểm tra, thống nhất hồ sơ trước **16 giờ 00 ngày 06/11/2026**.
>
> ### 2. Đồng chí [Họ và tên] – Phó Bí thư Chi bộ
>
> **Phụ trách hồ sơ kiểm điểm cá nhân đảng viên và tổng hợp kết quả thực hiện nhiệm vụ của đảng viên.**
>
> **Nhiệm vụ cụ thể:**
>
> 1. Rà soát danh sách đảng viên của chi bộ, xác định chính xác số đảng viên thuộc diện kiểm điểm, đánh giá, xếp loại năm 2026; lập danh sách riêng các trường hợp không thuộc diện theo Kế hoạch 122.
>
> 2. Thông báo, hướng dẫn và đôn đốc từng đảng viên tự xây dựng bản kiểm điểm, tự đánh giá, xếp loại theo mẫu phù hợp với đối tượng; bảo đảm cá nhân tự kiểm điểm, tự chịu trách nhiệm về nội dung và ký xác nhận.
>
> 3. Tiếp nhận, kiểm tra bản kiểm điểm cá nhân; tập trung rà soát:
>    - Việc sử dụng đúng mẫu.
>    - Kết quả thực hiện chức trách, nhiệm vụ được giao.
>    - Ưu điểm, hạn chế, nguyên nhân và biện pháp khắc phục.
>    - Nội dung tự đánh giá, đề xuất mức xếp loại và minh chứng liên quan.
>    - Những thông tin, chữ ký, tài liệu còn thiếu.
>
> 4. Đối với đảng viên thuộc diện Ban Thường vụ Đảng ủy phường quản lý (nếu có), kiểm tra các thành phần hồ sơ quy định tại mục 2 Phụ lục Kế hoạch 122; phối hợp thu thập bản tự kiểm điểm Mẫu 02A, tóm tắt Mẫu 03, biểu đánh giá phù hợp và các giấy tờ, nhận xét liên quan theo từng trường hợp.
>
> 5. Đối với đảng viên đang sinh hoạt đảng tạm thời (nếu có), phối hợp lấy nhận xét bằng văn bản của chi bộ nơi sinh hoạt tạm thời để phục vụ đánh giá tại nơi sinh hoạt chính thức.
>
> 6. Tổng hợp tình hình thực hiện nhiệm vụ của đảng viên trong năm, những nội dung đã hoàn thành, chưa hoàn thành, hạn chế và vấn đề cần làm rõ trong hội nghị.
>
> 7. Lập bảng theo dõi tiến độ, xác định rõ hồ sơ đã nhận, hồ sơ cần bổ sung và người có trách nhiệm hoàn thiện.
>
> **Sản phẩm phải hoàn thành:**
> - Danh sách đảng viên thuộc diện và không thuộc diện kiểm điểm, đánh giá, xếp loại.
> - Bộ hồ sơ tự kiểm điểm cá nhân đã tiếp nhận, được rà soát theo từng đối tượng.
> - Bảng tổng hợp, theo dõi tình trạng hồ sơ đảng viên.
> - Danh mục tài liệu còn thiếu, cần bổ sung và các trường hợp đặc biệt cần xin ý kiến cấp trên.
>
> **Thời gian:** Hoàn thành rà soát đối tượng trước 10 giờ 00; tổng hợp, bàn giao kết quả và hồ sơ đã thu nhận trước **14 giờ 30 ngày 06/11/2026**.
>
> ### 3. Đồng chí [Họ và tên] – Chi ủy viên
>
> **Phụ trách số liệu, tài liệu minh chứng, biểu đánh giá, hồ sơ hội nghị và tổng hợp hành chính.**
>
> **Nhiệm vụ cụ thể:**
>
> 1. Rà soát, tổng hợp tài liệu, số liệu và kết quả công tác năm 2026 làm căn cứ xây dựng Báo cáo kiểm điểm tập thể, gồm:
>    - Kết quả thực hiện nghị quyết, chương trình, kế hoạch công tác của chi bộ.
>    - Kết quả thực hiện nhiệm vụ chính trị và các chỉ tiêu được giao.
>    - Công tác sinh hoạt chi bộ, sinh hoạt chuyên đề.
>    - Công tác quản lý đảng viên, phát triển đảng viên (nếu có).
>    - Công tác kiểm tra, giám sát; việc khắc phục hạn chế, khuyết điểm.
>    - Những thành tích, kết quả nổi bật có tài liệu xác nhận.
>
> 2. Chuẩn bị các biểu tự đánh giá, xếp loại đối với chi bộ, chi ủy theo đúng loại biểu áp dụng được cơ quan tham mưu của cấp ủy cấp trên hướng dẫn; đối chiếu số liệu với báo cáo kiểm điểm.
>
> 3. Soạn **dự thảo Tờ trình đề nghị đánh giá, xếp loại – Mẫu 10**, để hoàn thiện chính thức trên cơ sở kết quả hội nghị.
>
> 4. Lập danh mục, chuẩn bị và theo dõi việc bổ sung các tài liệu thuộc hồ sơ tập thể:
>    - Văn bản gợi ý kiểm điểm (nếu có).
>    - Bản nhận xét của đồng chí Ủy viên Ban Thường vụ Đảng ủy phụ trách giám sát thường xuyên – Mẫu 05.
>    - Bản sao văn bản công nhận thành tích, khen thưởng (nếu có).
>    - Các văn bản khác thuộc danh mục hồ sơ tập thể và thực tế áp dụng của chi bộ.
>
> 5. Chuẩn bị hồ sơ phục vụ hội nghị, gồm dự thảo chương trình hội nghị, danh sách đại biểu, mẫu biên bản hội nghị kiểm điểm, mẫu biên bản kiểm phiếu và các tài liệu phục vụ công tác đánh giá, xếp loại.
>
> 6. Sắp xếp hồ sơ thành từng nhóm: hồ sơ tập thể; hồ sơ cá nhân; hồ sơ hội nghị; tài liệu minh chứng. Lập bảng kiểm thành phần hồ sơ và bàn giao cho Bí thư Chi bộ.
>
> **Sản phẩm phải hoàn thành:**
> - Bảng tổng hợp kết quả thực hiện nhiệm vụ, số liệu và danh mục minh chứng năm 2026.
> - Các biểu tự đánh giá, xếp loại phù hợp, ở trạng thái dự thảo.
> - Dự thảo Tờ trình Mẫu 10.
> - Bộ biểu mẫu, tài liệu phục vụ hội nghị kiểm điểm.
> - Danh mục kiểm tra thành phần hồ sơ, phân biệt tài liệu đã có và tài liệu còn phải bổ sung sau hội nghị.
>
> **Thời gian:** Hoàn thành số liệu, minh chứng và dự thảo biểu mẫu trước 12 giờ 00; hoàn thành sắp xếp, bàn giao hồ sơ trước **15 giờ 00 ngày 06/11/2026**.
>
> ## II. TIẾN ĐỘ THỰC HIỆN
>
> | Thời gian | Nội dung, yêu cầu hoàn thành |
> |---|---|
> | Chiều 05/11/2026 | Bí thư triển khai phân công; các đồng chí tiếp nhận nhiệm vụ, rà soát tài liệu hiện có. |
> | Trước 10h00 ngày 06/11 | Phó Bí thư hoàn thành danh sách đối tượng kiểm điểm; Chi ủy viên tổng hợp số liệu, minh chứng. |
> | Trước 12h00 ngày 06/11 | Chi ủy viên hoàn thành dự thảo biểu đánh giá và các tài liệu được phân công. |
> | Trước 14h30 ngày 06/11 | Bí thư hoàn thành dự thảo báo cáo tập thể; Phó Bí thư bàn giao tình trạng hồ sơ cá nhân. |
> | Từ 14h30 đến 15h30 ngày 06/11 | Ba đồng chí chi ủy viên rà soát, đối chiếu nội dung, biểu mẫu, minh chứng; chỉnh sửa các nội dung cần thiết. |
> | **16h00 ngày 06/11** | **Bí thư tiếp nhận, kiểm tra lần cuối và chốt bộ hồ sơ chuẩn bị kiểm điểm của chi bộ.** |
>
> ## III. NHIỆM VỤ TIẾP TỤC SAU NGÀY 06/11/2026
>
> 1. **Bí thư Chi bộ:** Tổ chức hội nghị kiểm điểm đúng thời hạn, nguyên tắc, quy trình; lãnh đạo việc xem xét kết quả kiểm điểm, tự đánh giá, đề xuất xếp loại; kiểm tra, ký hoặc trình ký các văn bản theo thẩm quyền và gửi hồ sơ đúng tuyến.
>
> 2. **Phó Bí thư Chi bộ:** Tiếp tục đôn đốc hoàn thiện hồ sơ kiểm điểm cá nhân; tổng hợp kết quả đánh giá, đề xuất xếp loại đảng viên sau hội nghị; bổ sung các văn bản nhận xét và tài liệu liên quan.
>
> 3. **Chi ủy viên:** Thực hiện hoặc phối hợp ghi biên bản hội nghị, hoàn thiện biên bản kiểm phiếu theo kết quả thực tế; tổng hợp, sắp xếp, lập danh mục hồ sơ chính thức và chuẩn bị báo cáo kết quả kiểm điểm, đánh giá, xếp loại để trình Bí thư rà soát.
>
> ## IV. TỔ CHỨC THỰC HIỆN
>
> 1. Các đồng chí chi ủy viên chịu trách nhiệm trực tiếp về tính chính xác, đầy đủ, đúng quy định của nội dung được phân công.
>
> 2. Tài liệu, số liệu sử dụng trong báo cáo phải được kiểm tra, đối chiếu với hồ sơ thực tế; không tự xác định thành tích, kết quả hoặc mức xếp loại khi chưa đủ căn cứ.
>
> 3. Trường hợp thiếu tài liệu do đang chờ tổ chức, cá nhân có thẩm quyền cung cấp, đồng chí phụ trách phải báo cáo Bí thư, nêu rõ tên tài liệu, nguyên nhân và hướng xử lý; không lập thay tài liệu chưa phát sinh.
>
> 4. **Hạn cuối hoàn thành và bàn giao bộ hồ sơ chuẩn bị: 16 giờ 00, thứ Sáu, ngày 06 tháng 11 năm 2026.**
>
> 5. Bí thư Chi bộ chịu trách nhiệm chỉ đạo, kiểm tra, đôn đốc và xử lý những vấn đề phát sinh; bảo đảm chi bộ tổ chức kiểm điểm, đánh giá, xếp loại đúng tiến độ và hoàn thành hồ sơ chính thức theo Kế hoạch 122-KH/ĐU.
>
> Đề nghị các đồng chí chi ủy viên nghiêm túc triển khai thực hiện.
>
> **T/M CHI ỦY**  
> **BÍ THƯ**
>
> *(Ký, ghi rõ họ tên)*

## Lưu ý để bảo đảm hồ sơ đúng quy định

Tôi nhấn mạnh ba điểm khi đồng chí triển khai phân công:

**Thứ nhất, không nhầm lẫn hồ sơ tập thể với hồ sơ cá nhân.** Phụ lục Kế hoạch 122 quy định hồ sơ tập thể tại mục 1 và hồ sơ cá nhân thuộc diện Ban Thường vụ Đảng ủy quản lý tại mục 2. Không được mặc nhiên áp dụng toàn bộ danh mục hồ sơ cán bộ diện Ban Thường vụ quản lý cho tất cả đảng viên của chi bộ.

**Thứ hai, chưa đủ căn cứ để xác định chính xác từng Biểu 6, 7, 8, 9, 10, 11, 13 áp dụng cho đối tượng nào.** Kế hoạch 122 liệt kê các biểu nhưng không cung cấp nội dung từng biểu. Cần đối chiếu bộ mẫu của Ban Xây dựng Đảng, Quy định số 04-QĐ/ĐU và Hướng dẫn số 01-HD/BTCTU trước khi hoàn thiện chính thức.

**Thứ ba, phải gửi dự thảo báo cáo kiểm điểm trước hội nghị ít nhất 03 ngày làm việc**, theo Hướng dẫn số 43-HD/BTCTW. Vì vậy, phương án phù hợp là hoàn thành dự thảo ngày 06/11 và dự kiến tổ chức hội nghị ngày 12 hoặc 13/11, sau khi thống nhất với cấp ủy cấp trên. [Hướng dẫn 43\-HD/BTCTW về một số nội dung về kiểm điểm và đánh giá, xếp loại chất lượng tập thể, cá nhân trong hệ thống chính trị](<https://xaydungchinhsach.chinhphu.vn/huong-dan-43-hd-btctw-ve-kiem-diem-va-danh-gia-xep-loai-chat-luong-tap-the-ca-nhan-trong-he-thong-chinh-tri-119251114095902305.htm>); [Hướng dẫn số 43\-HD/BTCTW ngày 31/10/2025 của Ban Tổ chức Trung ương về một số nội dung về kiểm điểm \.\.\.](<https://tulieuvankien.dangcongsan.vn/he-thong-van-ban/van-ban-cua-dang/huong-dan-so-43-hd-btctw-ngay-31-10-2025-cua-ban-to-chuc-trung-uong-ve-mot-so-noi-dung-ve-kiem-diem-va-danh-gia-xep-loai.html>)

**Kết luận:** Cách phân công trên xác định một người chịu trách nhiệm chính cho từng nhóm sản phẩm, đồng thời giữ đúng vai trò chỉ đạo, kiểm tra của Bí thư. Đến 16 giờ ngày 06/11, chi bộ có thể chốt **bộ hồ sơ chuẩn bị trước hội nghị**; hồ sơ chính thức tiếp tục hoàn thiện theo kết quả thực tế và thời hạn Kế hoạch 122.

---

USER

lập thành bảng dùm mình

---

ASSISTANT

Dưới đây là **bảng phân công nhiệm vụ cụ thể cho 03 đồng chí chi ủy viên**, căn cứ Kế hoạch số 122-KH/ĐU ngày 16/10/2026 của Ban Thường vụ Đảng ủy phường An Bình. Bảng xác định rõ người phụ trách, công việc, sản phẩm bàn giao và thời hạn hoàn thành.

> **writing · document**
>
> **ĐẢNG BỘ [TÊN ĐẢNG BỘ]**  
> **CHI BỘ [TÊN CHI BỘ]**
>
> # BẢNG PHÂN CÔNG NHIỆM VỤ CHI ỦY
> **Chuẩn bị hồ sơ kiểm điểm, đánh giá, xếp loại chất lượng chi bộ, chi ủy và đảng viên năm 2026**
>
> *Căn cứ Kế hoạch số 122-KH/ĐU ngày 16/10/2026 của Ban Thường vụ Đảng ủy phường An Bình.*
>
> **Thời hạn hoàn thành hồ sơ chuẩn bị: 16 giờ 00, ngày 06/11/2026.**
>
> ## I. BẢNG PHÂN CÔNG CỤ THỂ
>
> | STT | Đồng chí phụ trách | Nội dung công việc cụ thể | Sản phẩm phải bàn giao | Thời gian hoàn thành |
> |---|---|---|---|---|
> | 1 | **Bí thư Chi bộ** | Xây dựng kế hoạch tổ chức kiểm điểm, đánh giá, xếp loại năm 2026; xác định đối tượng, thành phần, thời gian, nội dung hội nghị. | Kế hoạch tổ chức kiểm điểm của chi bộ. | Trước 10h00 ngày 06/11 |
> | 2 | **Bí thư Chi bộ** | Chủ trì xây dựng báo cáo kiểm điểm tập thể chi ủy; đánh giá kết quả lãnh đạo, ưu điểm, hạn chế, nguyên nhân, trách nhiệm và biện pháp khắc phục. | Dự thảo Báo cáo kiểm điểm tập thể **Mẫu 01B**. | Trước 14h00 ngày 06/11 |
> | 3 | **Bí thư Chi bộ** | Tổng hợp, khái quát ưu điểm, hạn chế của tập thể; chuẩn bị nội dung tự đánh giá, đề xuất xếp loại theo quy định. | Bản tóm tắt ưu điểm, hạn chế tập thể **Mẫu 3**. | Trước 14h00 ngày 06/11 |
> | 4 | **Phó Bí thư Chi bộ** | Rà soát tổng số đảng viên; phân loại đảng viên thuộc diện và không thuộc diện kiểm điểm, đánh giá, xếp loại; xác định các trường hợp đặc biệt. | Danh sách phân loại đảng viên, có ghi chú từng trường hợp. | Trước 10h00 ngày 06/11 |
> | 5 | **Phó Bí thư Chi bộ** | Hướng dẫn, đôn đốc đảng viên viết bản tự kiểm điểm; tiếp nhận và kiểm tra nội dung, biểu mẫu, chữ ký, minh chứng, mức tự đánh giá. | Hồ sơ tự kiểm điểm cá nhân đã tiếp nhận; bảng theo dõi hồ sơ còn thiếu. | Trước 14h30 ngày 06/11 |
> | 6 | **Phó Bí thư Chi bộ** | Rà soát hồ sơ riêng đối với đảng viên thuộc diện Ban Thường vụ Đảng ủy quản lý (nếu có), gồm bản kiểm điểm Mẫu 02A, tóm tắt Mẫu 03 và các tài liệu tương ứng tại Phụ lục Kế hoạch 122. | Danh mục hồ sơ cá nhân thuộc diện Ban Thường vụ quản lý và tình trạng hoàn thiện. | Trước 14h30 ngày 06/11 |
> | 7 | **Chi ủy viên** | Tổng hợp số liệu, minh chứng về thực hiện nghị quyết, nhiệm vụ chính trị, công tác xây dựng Đảng, sinh hoạt chi bộ, kiểm tra, giám sát, kết quả khắc phục hạn chế. | Bảng tổng hợp kết quả công tác năm 2026 và tài liệu minh chứng. | Trước 12h00 ngày 06/11 |
> | 8 | **Chi ủy viên** | Chuẩn bị biểu tự đánh giá, xếp loại tập thể theo biểu mẫu áp dụng; dự thảo Tờ trình đề nghị đánh giá, xếp loại. | Dự thảo biểu đánh giá phù hợp và **Tờ trình Mẫu 10**. | Trước 14h00 ngày 06/11 |
> | 9 | **Chi ủy viên** | Chuẩn bị chương trình hội nghị, mẫu biên bản kiểm điểm, mẫu biên bản kiểm phiếu; rà soát văn bản gợi ý kiểm điểm, nhận xét của cấp trên và thành tích được công nhận (nếu có). | Bộ tài liệu phục vụ hội nghị; danh mục hồ sơ, tài liệu đã có và còn thiếu. | Trước 15h00 ngày 06/11 |
> | 10 | **Cả 03 đồng chí** | Họp rà soát, đối chiếu toàn bộ hồ sơ; thống nhất số liệu, nội dung báo cáo, các biểu mẫu; kiểm tra những nội dung cần bổ sung trước hội nghị. | Bộ hồ sơ chuẩn bị kiểm điểm được rà soát, thống nhất. | Từ 15h00 đến 15h45 ngày 06/11 |
> | 11 | **Bí thư Chi bộ** | Kiểm tra lần cuối, kết luận các nội dung cần chỉnh sửa và tiếp nhận toàn bộ hồ sơ chuẩn bị. | Bộ hồ sơ chuẩn bị kiểm điểm năm 2026 của chi bộ. | **Chậm nhất 16h00 ngày 06/11** |
>
> ## II. PHÂN CÔNG HOÀN THIỆN HỒ SƠ SAU HỘI NGHỊ
>
> | STT | Người phụ trách | Nhiệm vụ | Sản phẩm |
> |---|---|---|---|
> | 1 | Bí thư Chi bộ | Chủ trì hội nghị kiểm điểm; chỉ đạo việc tự đánh giá, đề xuất xếp loại đúng quy trình; kiểm tra hồ sơ chính thức. | Báo cáo kiểm điểm, tờ trình và hồ sơ được hoàn thiện theo kết quả hội nghị. |
> | 2 | Phó Bí thư Chi bộ | Tổng hợp kết quả kiểm điểm, đánh giá, đề xuất xếp loại đảng viên; đôn đốc bổ sung hồ sơ còn thiếu. | Bảng tổng hợp kết quả và hồ sơ cá nhân hoàn chỉnh. |
> | 3 | Chi ủy viên | Ghi hoặc phối hợp ghi biên bản hội nghị; hoàn thiện biên bản kiểm phiếu theo thực tế; sắp xếp, lập danh mục hồ sơ gửi cấp trên. | Biên bản hội nghị, biên bản kiểm phiếu và bộ hồ sơ tổng hợp. |
>
> ## III. YÊU CẦU THỰC HIỆN
>
> 1. Từng đồng chí chịu trách nhiệm về tiến độ, chất lượng và tính chính xác của công việc được phân công; chủ động phối hợp, không để trùng lặp hoặc bỏ sót nhiệm vụ.
>
> 2. Nội dung báo cáo phải có số liệu, minh chứng thực tế; sử dụng đúng biểu mẫu tương ứng với từng đối tượng theo hướng dẫn của cấp ủy cấp trên.
>
> 3. Những tài liệu chỉ hình thành sau hội nghị như biên bản hội nghị, biên bản kiểm phiếu, kết quả đánh giá, xếp loại chính thức không được lập trước. Đến 16h00 ngày 06/11 phải hoàn thành việc chuẩn bị biểu mẫu và các nội dung dự thảo tương ứng.
>
> 4. Báo cáo thời gian tổ chức kiểm điểm về Ban Thường vụ Đảng ủy phường (qua Ban Xây dựng Đảng) **chậm nhất ngày 09/11/2026**; tổ chức kiểm điểm, đánh giá, xếp loại **hoàn thành chậm nhất ngày 13/11/2026**.
>
> 5. Hồ sơ thuộc diện phải gửi về Ban Xây dựng Đảng được hoàn thiện, gửi đúng đối tượng, thời hạn và quy trình tại Kế hoạch 122-KH/ĐU.
>
> **Yêu cầu 03 đồng chí chi ủy viên nghiêm túc thực hiện, bảo đảm hoàn thành toàn bộ hồ sơ có thể chuẩn bị trước hội nghị chậm nhất 16 giờ 00 ngày 06/11/2026.**
>
> **T/M CHI ỦY**  
> **BÍ THƯ**
>
> *(Ký, ghi rõ họ tên)*

**Lưu ý:** Tôi đã phân biệt rõ hồ sơ chuẩn bị trước hội nghị và hồ sơ hoàn thiện sau hội nghị để tránh sai quy trình. Riêng loại biểu tự đánh giá áp dụng cho từng đối tượng cần đối chiếu với bộ mẫu do Ban Xây dựng Đảng cung cấp, vì Kế hoạch 122 chỉ liệt kê các số biểu, chưa thể hiện toàn bộ nội dung biểu mẫu.

---

