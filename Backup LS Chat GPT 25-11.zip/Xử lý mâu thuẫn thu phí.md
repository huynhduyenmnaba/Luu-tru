USER

với vai trò CBQL bạn giúp tôi xử lý tình huống sau: PHT phụ trách công tác ngoại khóa có tạo các poster cụ thể các khoản thu, các tiết học của các môn Tiếng anh, vẽ, earobic, toán tư duy như hình và có  ban hành kế hoạch 172 kèm theo (có rõ các mục miễn giảm). Tuy nhiên có chỗ  lần cấn thế này. do cần ban hành thông báo 200 đến phụ huynh gấp nên dự trù khoản thu ngoại khóa ở mức chung. Chưa cụ thể các khoản miễn giảm (do các môn có  miễn giảm khác nhau). Công ty tiếng anh dự kiến giá 100.000 (do chưa được đấu thầu). Khi liên kết giá 95.000. Bộ phận thu chi nhà trường không đồng ý các mức thu, đề nghị PHT phải làm 1 văn bản có dấu để thực hiện thu. PHT đã trình bày sự việc với Hiệu trưởng, HT hướng dẫn căn cứ các nội dung miễn giảm của 172 và các hợp đồng của công ty mà thu không cần ban hành thêm văn bản khác.  Bạn thũ quỹ (phụ trách thu) kiên quyết không đồng ý và có ý làm khó PHT và hẹn nó chuyện riêng (bạn là người rất khó chịu trong giao tiếp ứng xử, nói chuyện không nhã nhặn, thường tỏ vẽ am hiểu văn bản để làm khó dễ đồng nghiệp) với tình huống này khi gặp mặt trao đổi PHT cần xử lý thế nào để ổn thỏa công việc, hạn chế sự mâu thuẫn) (bạn thủ quỹ có sự hiềm khích ngầm với PHT)

---

ASSISTANT

Tôi sẽ kiểm tra khả năng đọc các tệp đính kèm và vận dụng kỹ năng tư vấn giáo dục mầm non để đề xuất cách trao đổi giúp PHT giải quyết việc thu, đồng thời giữ cuộc nói chuyện đúng trọng tâm, hạn chế mâu thuẫn cá nhân.

---

ASSISTANT

Theo tôi, **PHT nên trao đổi với thái độ mềm mỏng nhưng có nguyên tắc: ghi nhận yêu cầu làm rõ căn cứ thu, cùng đối chiếu hồ sơ và đưa phần chưa thống nhất về đúng người có thẩm quyền quyết định.** Không nên biến cuộc gặp thành việc chứng minh ai hiểu văn bản hơn hoặc ai đang gây khó cho ai.

Sau khi đọc hai văn bản và xem các poster, tôi thấy **hồ sơ thực sự có điểm chưa thống nhất**, vì vậy cần xử lý cả nội dung công việc lẫn cách ứng xử.

**1. Nhìn nhận đúng vấn đề để PHT có cách trao đổi thuyết phục**

| Nội dung | Thể hiện trong tài liệu đã gửi | Điểm cần làm rõ |
|---|---|---|
| Giá tiếng Anh | Thông báo 200 và cả hai poster đều ghi 100.000 đồng/tháng | Mức 95.000 đồng là thông tin chị cung cấp về kết quả liên kết; chưa có hợp đồng gửi kèm để đối chiếu |
| Miễn, giảm | Thông báo 200 ghi chung tại nhóm ngoại khóa: giảm 50% cho hộ nghèo, người khuyết tật, mồ côi cả cha lẫn mẹ | Khác với chính sách từng môn trong Kế hoạch 172 và poster tiếng Anh |
| Nội dung Kế hoạch 172 | Có mức thu, miễn giảm cụ thể của Toán Finger, Aerobic và Vẽ | Có nhắc làm quen tiếng Anh ở phần mục đích nhưng **chưa có mục quy định riêng mức thu, miễn giảm tiếng Anh** |
| Số hoạt động tiếng Anh | Poster tổng hợp ghi 4 tiết/tháng; poster riêng ghi 8 hoạt động/tháng | Cần thống nhất với hợp đồng và chương trình thực hiện |

Ngoài ra, Kế hoạch 172 yêu cầu nhà trường lập danh sách, xác nhận các trường hợp miễn giảm và có ghi giới hạn tỷ lệ hưởng chính sách đối với Toán Finger và Mỹ thuật sáng tạo. Vì vậy, bộ phận thu cần được cung cấp danh sách cụ thể, không chỉ thông tin chung về chính sách.

**Như vậy, yêu cầu làm rõ hồ sơ của thủ quỹ có phần hợp lý; nhưng điều đó không đồng nghĩa mọi yêu cầu về việc PHT phải ban hành thêm văn bản có dấu đều mặc nhiên đúng.** Cũng chưa nên kết luận thủ quỹ cố tình gây khó chỉ từ việc đề nghị bổ sung căn cứ. Điều cần xem xét riêng là cách nói chuyện, yêu cầu cụ thể và thái độ phối hợp.

Tôi chưa có hợp đồng và chưa xác minh được đầy đủ văn bản địa phương được viện dẫn, nên chưa thể kết luận về pháp lý rằng hồ sơ hiện có đã đủ để thu hay bắt buộc phải ban hành văn bản mới.

**2. Khi gặp mặt, PHT nên đi theo trình tự này**

**Mở đầu bằng mục tiêu chung, không nhắc hiềm khích.**

PHT có thể nói:

> “Tôi hiểu bạn cần căn cứ rõ để thu đúng và thuận tiện khi đối chiếu. Tôi cũng muốn thống nhất việc này để phụ huynh được thông tin chính xác. Mình cùng xem cụ thể nội dung nào đã rõ, nội dung nào còn cần bổ sung nhé.”

Cách mở đầu này ghi nhận trách nhiệm của người thu, nhưng không nhận rằng toàn bộ vướng mắc là lỗi của PHT.

**Thừa nhận đúng điểm chưa đồng bộ, không giải thích dài về việc ban hành gấp.**

> “Thông báo 200 đang ghi mức tiếng Anh 100.000 đồng và chính sách giảm chung; trong khi mức liên kết và chính sách từng môn có khác. Tôi ghi nhận cần thống nhất lại thông tin để bộ phận thu dễ thực hiện. Phần thuộc nhiệm vụ của tôi, tôi sẽ phối hợp hoàn thiện.”

Không nên nói: “Thông báo làm gấp nên bạn phải thông cảm”, bởi lý do gấp không giải quyết được vướng mắc của người thực hiện.

**Đề nghị thủ quỹ chỉ rõ nội dung còn thiếu.**

> “Bạn giúp tôi nêu cụ thể đang thiếu căn cứ ở mức thu, đối tượng miễn giảm, danh sách trẻ hay xác nhận của nhà trường? Nếu bạn thấy cần thêm một văn bản có dấu, mình cùng làm rõ văn bản đó cần xác nhận nội dung gì để báo cáo Hiệu trưởng quyết định.”

Đây là bước quan trọng: chuyển yêu cầu chung “phải có văn bản” thành vấn đề cụ thể có thể giải quyết.

**Trình bày chỉ đạo của Hiệu trưởng với tinh thần phối hợp.**

> “Tôi đã báo cáo và được Hiệu trưởng hướng dẫn căn cứ Kế hoạch 172 cùng các hợp đồng để thực hiện. Nếu bạn vẫn thấy hồ sơ chưa đủ rõ, tôi đề nghị mình cùng kế toán tổng hợp điểm còn vướng và xin Hiệu trưởng kết luận thống nhất, để mỗi người đều có căn cứ làm phần việc của mình.”

Tránh câu: “Hiệu trưởng nói rồi, bạn cứ làm đi.” Câu này dễ khiến thủ quỹ cảm thấy bị ép nhận trách nhiệm, trong khi điểm chưa thống nhất trong hồ sơ vẫn còn.

**3. Nếu thủ quỹ nói khó nghe hoặc chuyển sang công kích cá nhân**

PHT không cần đáp trả từng câu. Nên nói chậm, ngắn và đưa cuộc trao đổi trở lại nội dung:

| Tình huống | Cách trả lời phù hợp |
|---|---|
| “PHT làm hồ sơ như vậy là sai rồi.” | “Bạn chỉ giúp tôi cụ thể nội dung nào chưa phù hợp. Phần nào cần điều chỉnh, tôi sẽ phối hợp xử lý.” |
| “Không có văn bản có dấu thì tôi không thu.” | “Tôi ghi nhận ý kiến này. Mình tổng hợp rõ nội dung bạn cần xác nhận và cùng báo cáo Hiệu trưởng, kế toán để thống nhất cách thực hiện.” |
| “Bạn làm thì bạn tự chịu trách nhiệm.” | “Tôi chịu trách nhiệm phần việc được giao. Việc thu cần thống nhất cả căn cứ và trách nhiệm của các bộ phận, mình cùng làm rõ để thực hiện.” |
| Nhắc chuyện cũ, nhận xét tính cách hoặc năng lực | “Tôi xin tập trung vào hồ sơ ngoại khóa đang cần giải quyết. Những vấn đề khác mình trao đổi riêng vào thời điểm phù hợp.” |
| Lớn tiếng hoặc lời lẽ thiếu tôn trọng | “Tôi sẵn sàng trao đổi để giải quyết công việc, nhưng mong hai bên giữ cách nói tôn trọng nhau. Nếu lúc này chưa trao đổi bình tĩnh được, tôi đề nghị chuyển sang buổi làm việc có Hiệu trưởng và kế toán.” |

**Gặp riêng để lắng nghe là được; nhưng quyết định cách thu không nên trở thành một thỏa thuận riêng giữa PHT và thủ quỹ.** Khi còn bất đồng về hồ sơ, cần có kế toán và Hiệu trưởng cùng làm rõ.

**4. Cách chốt công việc để không kéo dài mâu thuẫn**

PHT nên mang theo một bảng đối chiếu ngắn theo từng môn, gồm: mức trong Thông báo 200, mức theo hợp đồng đã ký, chính sách miễn giảm, đối tượng áp dụng và điểm còn khác nhau. Bảng này phục vụ rà soát, không tự thay thế căn cứ thu.

Cuối buổi, cần thống nhất ba việc:

- **PHT:** cung cấp hồ sơ liên kết, phối hợp tổng hợp danh sách miễn giảm và rà lại poster.
- **Kế toán, thủ quỹ:** chỉ rõ phần hồ sơ còn thiếu hoặc chưa thống nhất, đề xuất cách hoàn thiện để thực hiện thu.
- **Hiệu trưởng:** kết luận mức thu và chính sách áp dụng; quyết định hình thức xác nhận, điều chỉnh hoặc thông tin lại cho phụ huynh.

Về quản trị, tôi nghiêng về việc **nhà trường nên có thông tin chính thức làm rõ mức thu và miễn giảm thực tế**, vì Thông báo 200 đã gửi phụ huynh có nội dung khác với hồ sơ triển khai. Hình thức cụ thể do Hiệu trưởng quyết định sau khi kế toán đối chiếu; không nhất thiết phải làm lại toàn bộ kế hoạch, cũng không nên mặc định đây là việc riêng PHT phải tự giải quyết.

PHT có thể kết thúc cuộc gặp bằng câu:

> “Tôi mong mình thống nhất để công việc thuận lợi và phụ huynh được hưởng đúng chính sách. Phần hồ sơ thuộc trách nhiệm của tôi, tôi sẽ phối hợp hoàn thiện; phần nào còn khác cách hiểu, mình cùng báo cáo Hiệu trưởng và kế toán giải quyết. Tôi cũng mong hai bên trao đổi thẳng vào công việc, trên tinh thần tôn trọng nhau.”

**PHT có thể nhận trách nhiệm phối hợp làm rõ hồ sơ mà vẫn giữ được vị thế quản lý; không cần tranh thắng, nhưng cũng không chấp nhận cách trao đổi thiếu tôn trọng.**

---

