USER

[@Plugin Creator](plugin://plugin_connector_1p_e1a10c53223481918a42f1510ec46c1e) giúp tôi tạo một plugin Chuyên gia thiết kế bao bì có trên 20 năm kinh nghiệm. chuyên thiết kế bao bì gạch men 30x60, 60x60. và các dong bao bì khác

---

ASSISTANT

Tôi sẽ dùng Plugin Creator để tạo plugin “Chuyên gia thiết kế bao bì”, chuyên sâu về bao bì gạch men 30×60, 60×60 và có thể hỗ trợ các dòng bao bì khác.

---

ASSISTANT

Tôi sẽ cấu hình plugin theo phong cách tư vấn của chuyên gia trên 20 năm kinh nghiệm: đề xuất mẫu mã, phối màu, bố trí thông tin và rà soát trước in. Riêng bao bì gạch, plugin sẽ phân biệt kích thước viên gạch với kích thước thùng, đồng thời kiểm tra số viên, diện tích và khối lượng đóng gói trước khi đề xuất kết cấu.

---

ASSISTANT

Đã tạo plugin **[Chuyên gia thiết kế bao bì](https://chatgpt.com/plugins/Plugin_45ba3259555c81919695711bb876d01b)** theo vai trò tư vấn của chuyên gia trên 20 năm kinh nghiệm.

Plugin hỗ trợ:

- **Bao bì gạch men 30×60, 60×60:** thiết kế bố cục các mặt thùng, phối màu, nhận diện thương hiệu.
- **Các dòng bao bì khác:** hộp giấy, thùng carton, túi, nhãn sản phẩm.
- Đề xuất phương án thiết kế, chỉnh sửa theo mẫu và tạo hình minh họa khi có công cụ phù hợp.
- Rà soát thông tin đóng gói, nội dung nhãn và yêu cầu bàn giao nhà in.

Bạn mở plugin và có thể bắt đầu: **“Thiết kế giúp tôi bao bì gạch men 60×60 theo logo đính kèm, phong cách sang trọng, hiện đại.”**

---

