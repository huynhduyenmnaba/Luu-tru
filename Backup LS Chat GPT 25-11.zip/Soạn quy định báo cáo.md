USER

với vai trò hiệu trưởng bạn giúp tôi soạn văn bản quy định chế độ báo cáo nhé

---

ASSISTANT

Tôi sẽ dùng kỹ năng soạn thảo văn bản mầm non để xây dựng quy định chế độ báo cáo trong nhà trường, làm rõ người thực hiện, thời hạn, nơi nhận và trách nhiệm xử lý báo cáo.

---

ASSISTANT

Dưới đây là **dự thảo Quy định chế độ thông tin, báo cáo nội bộ trường mầm non**. Các mốc thời gian là đề xuất để nhà trường thống nhất áp dụng; đối với báo cáo cấp trên, thực hiện theo thời hạn của văn bản yêu cầu.

> **writing · standard**
>
> **[CƠ QUAN CHỦ QUẢN]**  
> **TRƯỜNG MẦM NON […]**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> Số: …/QC-[…]  
> […], ngày … tháng … năm …
>
> **QUY ĐỊNH**  
> **Chế độ thông tin, báo cáo trong nhà trường**
>
> **Điều 1. Phạm vi và đối tượng áp dụng**
>
> 1. Quy định này quy định nội dung, hình thức, thời hạn, quy trình tiếp nhận và trách nhiệm thực hiện chế độ thông tin, báo cáo trong nhà trường.
>
> 2. Đối tượng thực hiện gồm Ban Giám hiệu, tổ trưởng chuyên môn, tổ trưởng văn phòng, giáo viên, nhân viên và cá nhân được giao phụ trách các lĩnh vực công tác của nhà trường.
>
> 3. Báo cáo gửi cơ quan quản lý cấp trên thực hiện theo yêu cầu của cơ quan có thẩm quyền; việc phân công chuẩn bị, kiểm tra, trình duyệt và lưu trữ được thực hiện theo Quy định này.
>
> **Điều 2. Mục đích, yêu cầu**
>
> 1. Bảo đảm Hiệu trưởng nắm bắt kịp thời tình hình hoạt động của nhà trường để chỉ đạo, giải quyết công việc; chủ động xử lý khó khăn trong công tác nuôi dưỡng, chăm sóc, giáo dục trẻ và quản lý nhà trường.
>
> 2. Thông tin, báo cáo phải trung thực, chính xác, đúng nội dung, đúng thời hạn và đúng người tiếp nhận. Người lập báo cáo chịu trách nhiệm về nội dung, số liệu thuộc phạm vi nhiệm vụ được giao.
>
> 3. Nội dung báo cáo phải ngắn gọn, rõ kết quả, rõ tồn tại và đề xuất hướng giải quyết; không liệt kê công việc chung chung, sao chép báo cáo của kỳ trước hoặc đưa số liệu chưa được kiểm tra thành số liệu chính thức.
>
> 4. Ưu tiên sử dụng dữ liệu từ hồ sơ, sổ theo dõi và phần mềm đang sử dụng. Không yêu cầu giáo viên, nhân viên lập lại thông tin đã có đầy đủ và có thể khai thác từ hệ thống chung, trừ trường hợp cần đối chiếu hoặc bổ sung.
>
> 5. Việc báo cáo, trao đổi thông tin phải bảo đảm bảo mật thông tin cá nhân của trẻ, cha mẹ trẻ và đội ngũ; chỉ chia sẻ cho người có trách nhiệm xử lý.
>
> **Điều 3. Chế độ báo cáo thường xuyên và định kỳ**
>
> **1. Thông tin hằng ngày**
>
> a) Giáo viên cập nhật tình hình trẻ đến lớp, trẻ ăn bán trú và các thay đổi liên quan đến việc tổ chức chăm sóc trẻ theo giờ chốt số lượng do nhà trường thông báo đầu năm học. Trường hợp có thay đổi sau giờ chốt phải thông tin ngay đến người phụ trách để điều chỉnh.
>
> b) Giáo viên, nhân viên chủ động thông tin những vấn đề phát sinh trong ngày thuộc phạm vi công việc, nhất là tình hình sức khỏe của trẻ, điều kiện an toàn, thực phẩm, cơ sở vật chất và những nội dung cần Ban Giám hiệu hỗ trợ.
>
> c) Thông tin thường xuyên được cập nhật trên công cụ dùng chung hoặc sổ theo dõi đang áp dụng; không lập thêm báo cáo văn bản hằng ngày khi không có yêu cầu riêng.
>
> **2. Báo cáo tuần**
>
> a) Giáo viên, nhân viên phản ánh kết quả công việc, nhiệm vụ chưa hoàn thành và khó khăn cần giải quyết đến tổ trưởng hoặc người phụ trách lĩnh vực trước **15 giờ thứ Sáu hằng tuần**. Nội dung đã được cập nhật trên công cụ dùng chung không phải gửi lại.
>
> b) Tổ trưởng tổng hợp những vấn đề cần chỉ đạo, phối hợp; gửi Phó Hiệu trưởng phụ trách hoặc Hiệu trưởng theo phân công trước **16 giờ thứ Sáu hằng tuần**.
>
> c) Báo cáo tuần trình bày ngắn gọn theo ba nội dung: kết quả công việc trọng tâm; tồn tại, vướng mắc; nhiệm vụ và đề xuất cho tuần tiếp theo. Có thể lồng ghép trong giao ban hoặc bảng theo dõi công việc chung.
>
> **3. Báo cáo tháng**
>
> a) Báo cáo tháng sử dụng số liệu từ ngày đầu tháng đến hết ngày cuối tháng; gửi theo trình tự:
>
> | Người thực hiện | Nội dung chủ yếu | Nơi nhận | Thời hạn |
> |---|---|---|---|
> | Giáo viên | Tình hình trẻ; kết quả nuôi dưỡng, chăm sóc, giáo dục; phối hợp với cha mẹ trẻ; khó khăn và đề xuất | Tổ trưởng chuyên môn | Trước 10 giờ ngày làm việc đầu tiên của tháng tiếp theo |
> | Nhân viên, cá nhân phụ trách lĩnh vực | Kết quả nhiệm vụ được giao; số liệu liên quan; tồn tại, nguyên nhân và đề xuất | Tổ trưởng hoặc Ban Giám hiệu theo phân công | Trước 10 giờ ngày làm việc đầu tiên của tháng tiếp theo |
> | Tổ trưởng | Tổng hợp kết quả của tổ; nhiệm vụ còn chậm; nội dung cần hỗ trợ, phối hợp | Phó Hiệu trưởng phụ trách hoặc Hiệu trưởng | Trong ngày làm việc thứ hai của tháng tiếp theo |
> | Phó Hiệu trưởng | Kết quả lĩnh vực phụ trách; vấn đề đã xử lý; nội dung vượt thẩm quyền và đề xuất chỉ đạo | Hiệu trưởng | Trong ngày làm việc thứ ba của tháng tiếp theo |
>
> b) Trường hợp phục vụ cuộc họp trước khi kết thúc tháng, báo cáo phải ghi rõ thời điểm chốt số liệu; nhiệm vụ chưa hoàn thành chỉ được ghi là dự kiến, không tính vào kết quả đã thực hiện.
>
> c) Báo cáo tháng có thể tích hợp trong nội dung đánh giá công tác tháng của tổ, bộ phận; không lập nhiều báo cáo riêng có nội dung trùng nhau.
>
> **4. Báo cáo sơ kết, tổng kết**
>
> a) Các tổ, bộ phận và cá nhân được phân công thực hiện báo cáo học kỳ, năm học theo đề cương và lịch chung của nhà trường.
>
> b) Nội dung tập trung vào kết quả thực hiện nhiệm vụ; đối chiếu với kế hoạch; đánh giá hạn chế, nguyên nhân; xác định nhiệm vụ và giải pháp cho giai đoạn tiếp theo.
>
> c) Thời hạn cụ thể do Hiệu trưởng thông báo phù hợp với lịch công tác và yêu cầu của cấp trên, bảo đảm có thời gian kiểm tra, đối chiếu và hoàn thiện trước khi gửi.
>
> **Điều 4. Báo cáo chuyên đề và báo cáo theo yêu cầu**
>
> 1. Báo cáo chuyên đề được thực hiện khi có yêu cầu của cấp trên hoặc yêu cầu quản lý cụ thể của Hiệu trưởng; không tự phát sinh thêm báo cáo định kỳ ngoài danh mục đã thống nhất.
>
> 2. Khi giao nhiệm vụ báo cáo, người giao phải xác định rõ:
>
> a) Nội dung, phạm vi và kỳ số liệu cần báo cáo.
>
> b) Cá nhân hoặc bộ phận chủ trì; cá nhân hoặc bộ phận phối hợp.
>
> c) Biểu mẫu, sản phẩm cần hoàn thành.
>
> d) Thời hạn cung cấp số liệu, thời hạn trình duyệt và thời hạn gửi chính thức.
>
> 3. Người chủ trì chịu trách nhiệm tổng hợp, kiểm tra tính thống nhất của số liệu và hoàn thiện dự thảo. Người phối hợp chịu trách nhiệm cung cấp đầy đủ, đúng hạn thông tin thuộc phần việc được giao.
>
> 4. Trường hợp chưa có biểu mẫu riêng, báo cáo được trình bày theo các nội dung: kết quả thực hiện; hạn chế, khó khăn và nguyên nhân; biện pháp đã thực hiện; đề xuất, kiến nghị.
>
> **Điều 5. Báo cáo đột xuất và thông tin khẩn cấp**
>
> 1. Những sự việc phải báo cáo ngay gồm:
>
> a) Tai nạn, sự cố hoặc nguy cơ ảnh hưởng đến sức khỏe, an toàn của trẻ và người trong nhà trường.
>
> b) Dấu hiệu bất thường liên quan đến an toàn thực phẩm, bệnh truyền nhiễm hoặc điều kiện tổ chức bán trú.
>
> c) Sự cố điện, nước, cháy, nổ; hư hỏng cơ sở vật chất có nguy cơ mất an toàn.
>
> d) Phản ánh, khiếu nại hoặc sự việc liên quan đến quyền lợi của trẻ, hành vi ứng xử, thu chi và hoạt động của nhà trường cần được kiểm tra, xử lý kịp thời.
>
> đ) Các tình huống khác vượt khả năng giải quyết của người trực tiếp thực hiện.
>
> 2. Người phát hiện thông tin ngay bằng điện thoại hoặc trực tiếp đến Hiệu trưởng và Phó Hiệu trưởng phụ trách. Nếu không liên hệ được, báo cho thành viên Ban Giám hiệu đang trực để xử lý; không chờ đến kỳ báo cáo hoặc chờ hoàn thành văn bản.
>
> 3. Nội dung thông tin ban đầu gồm: thời gian, địa điểm; diễn biến đã biết; người có liên quan; tình trạng hiện tại; biện pháp đã thực hiện và nhu cầu hỗ trợ. Phải phân biệt thông tin đã xác minh với thông tin đang kiểm tra.
>
> 4. Việc báo cáo được thực hiện đồng thời với các biện pháp bảo đảm an toàn cần thiết trong phạm vi trách nhiệm; không để thủ tục báo cáo làm chậm việc hỗ trợ, xử lý tình huống.
>
> 5. Sau thông tin ban đầu, người được giao tiếp tục cập nhật diễn biến và hoàn thiện báo cáo bằng văn bản theo thời hạn Ban Giám hiệu yêu cầu. Không suy đoán nguyên nhân, quy kết trách nhiệm hoặc tự ý phổ biến thông tin chưa được xác minh.
>
> **Điều 6. Hình thức gửi và yêu cầu đối với báo cáo**
>
> 1. Báo cáo được gửi qua email công vụ, phần mềm quản lý hoặc kênh làm việc do nhà trường thống nhất. Văn bản giấy chỉ thực hiện khi có yêu cầu về ký, xác nhận hoặc lưu hồ sơ theo tính chất công việc.
>
> 2. Nhóm trao đổi công việc được sử dụng để thông báo, nhắc việc và trao đổi nhanh. Đối với báo cáo chính thức, phải gửi đầy đủ tệp hoặc cập nhật đúng vị trí lưu trữ được quy định; không chỉ gửi hình ảnh rời rạc hoặc tin nhắn thiếu nội dung.
>
> 3. Báo cáo phải ghi rõ tên người hoặc bộ phận lập, nội dung, kỳ báo cáo, thời điểm chốt số liệu và ngày gửi. Số liệu phải thống nhất về đơn vị tính và có nguồn để kiểm tra khi cần.
>
> 4. Nội dung không phát sinh phải ghi “Không phát sinh”; nội dung chưa có số liệu phải nêu rõ lý do và thời điểm dự kiến bổ sung, không tự ghi bằng 0 để thay thế.
>
> 5. Khi phát hiện sai sót sau khi gửi, người lập phải thông báo ngay cho người tiếp nhận và gửi bản điều chỉnh, nêu rõ nội dung thay đổi. Không âm thầm thay số liệu khi báo cáo đã được sử dụng để tổng hợp.
>
> **Điều 7. Tiếp nhận, kiểm tra và xử lý báo cáo**
>
> 1. Người tiếp nhận kiểm tra tính đầy đủ, hợp lý của nội dung và số liệu; yêu cầu bổ sung hoặc làm rõ khi cần thiết, đồng thời thông báo cụ thể nội dung cần sửa và thời hạn hoàn thành.
>
> 2. Tổ trưởng và Phó Hiệu trưởng phải xem xét, xử lý những nội dung thuộc phạm vi phụ trách; không chỉ chuyển tiếp nguyên báo cáo lên Hiệu trưởng mà chưa kiểm tra hoặc chưa có ý kiến đề xuất.
>
> 3. Những nội dung vượt thẩm quyền phải được tổng hợp, trình Hiệu trưởng xem xét. Báo cáo đề xuất giải quyết công việc phải nêu rõ vấn đề, biện pháp đã thực hiện và nội dung cần quyết định.
>
> 4. Báo cáo gửi ra ngoài nhà trường phải được Hiệu trưởng hoặc người được giao thẩm quyền kiểm tra, phê duyệt trước khi phát hành.
>
> 5. Người được giao theo dõi báo cáo có trách nhiệm lưu bản chính thức, tài liệu liên quan và theo dõi việc thực hiện ý kiến chỉ đạo sau báo cáo. Việc lưu trữ phải thuận tiện tra cứu, có phân quyền truy cập phù hợp.
>
> **Điều 8. Trách nhiệm thực hiện**
>
> **1. Ban Giám hiệu**
>
> a) Hiệu trưởng chỉ đạo chung; thống nhất danh mục báo cáo, biểu mẫu, đầu mối và kênh tiếp nhận; xem xét, quyết định những vấn đề thuộc thẩm quyền; chịu trách nhiệm phê duyệt báo cáo của nhà trường gửi cấp trên.
>
> b) Phó Hiệu trưởng hướng dẫn, đôn đốc và kiểm tra báo cáo thuộc lĩnh vực được phân công; đối chiếu số liệu giữa các bộ phận; giải quyết công việc thuộc trách nhiệm và kịp thời tham mưu Hiệu trưởng xử lý vướng mắc.
>
> c) Rà soát, lồng ghép các báo cáo trùng nội dung; điều chỉnh cách thu thập thông tin để giáo viên, nhân viên có thời gian tập trung thực hiện nhiệm vụ chuyên môn.
>
> **2. Tổ trưởng chuyên môn, tổ trưởng văn phòng**
>
> a) Triển khai yêu cầu báo cáo đến các thành viên; hướng dẫn nội dung và theo dõi thời hạn thực hiện.
>
> b) Kiểm tra, tổng hợp thông tin của tổ; phản ánh đúng tình hình, xác định rõ vấn đề cần giải quyết.
>
> c) Theo dõi việc khắc phục tồn tại và thực hiện chỉ đạo của Ban Giám hiệu; không để cùng một vướng mắc kéo dài qua nhiều kỳ báo cáo mà không nêu nguyên nhân, biện pháp xử lý.
>
> **3. Giáo viên và nhân viên**
>
> a) Cập nhật đầy đủ thông tin thuộc nhiệm vụ được giao; chủ động báo cáo kết quả, khó khăn và đề xuất hỗ trợ.
>
> b) Thực hiện đúng thời hạn, biểu mẫu và kênh gửi; kiểm tra số liệu trước khi gửi và phối hợp giải trình khi có yêu cầu.
>
> c) Không báo cáo thay người khác khi chưa được phân công; không ký hoặc xác nhận nội dung chưa được kiểm tra.
>
> d) Khi có nguy cơ chậm hạn, phải báo ngay cho người tiếp nhận, nêu lý do, phần việc đã hoàn thành và đề xuất thời hạn bổ sung để được xem xét. Việc thông báo không đồng nghĩa với tự ý được gia hạn.
>
> **4. Người được giao công tác văn thư, tổng hợp**
>
> a) Tiếp nhận, theo dõi, phát hành và lưu trữ báo cáo theo phân công.
>
> b) Nhắc thời hạn, phản ánh trường hợp chưa gửi hoặc gửi chưa đầy đủ để người phụ trách chỉ đạo.
>
> c) Chỉ phát hành bản đã được phê duyệt; bảo đảm gửi đúng nơi nhận và lưu đúng phiên bản chính thức.
>
> **Điều 9. Tổ chức thực hiện**
>
> 1. Quy định này được thực hiện kể từ ngày … tháng … năm … và phổ biến đến toàn thể cán bộ quản lý, giáo viên, nhân viên.
>
> 2. Ban Giám hiệu thống nhất giờ chốt số trẻ hằng ngày, địa chỉ tiếp nhận báo cáo và người phụ trách từng lĩnh vực; thông báo để các tổ, cá nhân thực hiện đồng bộ.
>
> 3. Việc thực hiện chế độ báo cáo được theo dõi trong quá trình đánh giá nhiệm vụ được giao. Trường hợp chậm, thiếu hoặc sai nội dung phải được làm rõ nguyên nhân, yêu cầu khắc phục; việc xem xét trách nhiệm thực hiện theo quy định hiện hành và quy chế của nhà trường, không tự đặt hình thức phạt hoặc mức trừ điểm ngoài quy chế đã ban hành.
>
> 4. Trong quá trình thực hiện, nếu phát sinh vướng mắc, các tổ và cá nhân phản ánh về Ban Giám hiệu để tổng hợp, trình Hiệu trưởng xem xét điều chỉnh.
>
> Yêu cầu các tổ, bộ phận và toàn thể cán bộ quản lý, giáo viên, nhân viên nghiêm túc thực hiện./.
>
> **Nơi nhận:**  
> - Ban Giám hiệu;  
> - Các tổ, giáo viên, nhân viên;  
> - Lưu: VT.
>
> **HIỆU TRƯỞNG**  
> *[Họ và tên]*

---

USER

Mình gửi thêm cho bạn nội dung này được trích từ chế độ làm việc của trường. bạn hãy giúp mình hoàn chỉnh lại hé

---

ASSISTANT

Tôi sẽ đọc phần trích từ chế độ làm việc của trường và điều chỉnh dự thảo cho thống nhất về nội dung, thời hạn và trách nhiệm báo cáo.

---

ASSISTANT

Nội dung cô gửi đã xác định rõ **thời hạn báo cáo trước ngày 25 và trước ngày 28 hằng tháng**. Tôi điều chỉnh lại dự thảo theo các mốc này, đồng thời làm rõ quy trình báo cáo và xử lý văn bản; không bổ sung báo cáo tuần bắt buộc để tránh phát sinh thêm công việc.

> **writing · standard**
>
> **[CƠ QUAN CHỦ QUẢN]**  
> **TRƯỜNG MẦM NON […]**
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> Số: …/QC-[…]  
> […], ngày … tháng … năm …
>
> **QUY ĐỊNH**  
> **Chế độ báo cáo và xử lý văn bản trong nhà trường**
>
> Căn cứ Điều 14 về chế độ báo cáo, xử lý văn bản trong Quy chế làm việc của Trường Mầm non […];
>
> Nhằm bảo đảm thông tin được tiếp nhận, tổng hợp và xử lý kịp thời, phục vụ công tác quản lý, điều hành, Hiệu trưởng quy định chế độ báo cáo và xử lý văn bản trong nhà trường như sau:
>
> **Điều 1. Phạm vi, đối tượng áp dụng**
>
> 1. Quy định này cụ thể hóa nội dung, thời hạn, hình thức, trách nhiệm thực hiện chế độ báo cáo và quy trình xử lý văn bản trong nhà trường.
>
> 2. Áp dụng đối với Ban Giám hiệu, tổ trưởng, người phụ trách điểm trường, giáo viên, nhân viên và cá nhân được giao thực hiện các nhiệm vụ có liên quan.
>
> **Điều 2. Yêu cầu chung**
>
> 1. Báo cáo phải chính xác, ngắn gọn, đúng trọng tâm, phản ánh trung thực tình hình thực hiện nhiệm vụ; có số liệu, kết quả, tồn tại, giải pháp và xác định rõ người chịu trách nhiệm đối với nhiệm vụ được đề xuất.
>
> 2. Nội dung báo cáo phải thuộc phạm vi công việc được giao. Người cung cấp thông tin chịu trách nhiệm về số liệu, nội dung do mình cung cấp; người tổng hợp có trách nhiệm kiểm tra, đối chiếu trước khi trình.
>
> 3. Thông tin phải được chuyển đúng người phụ trách, đúng thời hạn. Những vấn đề cần giải quyết phải nêu rõ nội dung, biện pháp đã thực hiện và đề xuất cụ thể; không chỉ phản ánh khó khăn mà không xác định hướng xử lý.
>
> 4. Sử dụng thông tin từ hồ sơ, sổ theo dõi và phần mềm đang áp dụng; hạn chế yêu cầu cung cấp lại dữ liệu đã có đầy đủ. Không lập thêm báo cáo riêng có nội dung trùng với báo cáo đã thực hiện.
>
> 5. Văn bản và thông tin liên quan đến trẻ, cha mẹ trẻ, đội ngũ, tài chính và hoạt động nội bộ phải được quản lý, sử dụng đúng mục đích, đúng phạm vi trách nhiệm.
>
> **Điều 3. Chế độ báo cáo tháng**
>
> **1. Nội dung báo cáo**
>
> a) **Kết quả thực hiện nhiệm vụ:** Những công việc đã hoàn thành trong kỳ; mức độ thực hiện so với kế hoạch; số liệu và kết quả cụ thể thuộc lĩnh vực phụ trách.
>
> b) **Tồn tại, hạn chế:** Những nhiệm vụ chưa hoàn thành, thực hiện chậm hoặc chưa đạt yêu cầu; nguyên nhân và ảnh hưởng đến hoạt động của tổ, điểm trường hoặc nhà trường.
>
> c) **Biện pháp đã thực hiện:** Nội dung đã chủ động giải quyết, kết quả xử lý và những vấn đề còn vướng mắc.
>
> d) **Nhiệm vụ, giải pháp tiếp theo:** Công việc cần tập trung thực hiện; người hoặc bộ phận chịu trách nhiệm; thời hạn dự kiến hoàn thành.
>
> đ) **Đề xuất, kiến nghị:** Nội dung cần Ban Giám hiệu quyết định, hỗ trợ hoặc phối hợp giải quyết.
>
> **2. Trình tự và thời hạn**
>
> | Người thực hiện | Trách nhiệm | Nơi nhận | Thời hạn |
> |---|---|---|---|
> | Giáo viên, nhân viên | Cung cấp thông tin, số liệu và kết quả nhiệm vụ được giao; phản ánh khó khăn, đề xuất | Tổ trưởng hoặc người phụ trách điểm trường theo phân công | Theo lịch thu thập thông tin do người tổng hợp thông báo, bảo đảm kịp thời hạn báo cáo của tổ, điểm trường |
> | Tổ trưởng và người phụ trách điểm trường | Kiểm tra, tổng hợp báo cáo tháng về lĩnh vực phụ trách | Phó Hiệu trưởng chủ trì theo phân công của Hiệu trưởng | **Trước ngày 25 hằng tháng** |
> | Phó Hiệu trưởng | Rà soát, đối chiếu, tổng hợp báo cáo; đề xuất nội dung cần chỉ đạo, giải quyết | Hiệu trưởng | **Trước ngày 28 hằng tháng** |
>
> Trường hợp cấp trên yêu cầu sớm hơn, thực hiện theo lịch điều chỉnh do Hiệu trưởng hoặc Phó Hiệu trưởng được giao chủ trì thông báo. Lịch điều chỉnh phải xác định rõ thời hạn cung cấp số liệu, tổng hợp và trình duyệt.
>
> **3. Thống nhất số liệu báo cáo**
>
> a) Phó Hiệu trưởng chủ trì thông báo thời điểm chốt số liệu để các tổ, điểm trường và cá nhân thực hiện thống nhất.
>
> b) Báo cáo ghi rõ kỳ báo cáo và thời điểm chốt số liệu. Công việc dự kiến thực hiện sau thời điểm chốt phải được trình bày riêng, không tính vào kết quả đã hoàn thành.
>
> c) Những thay đổi quan trọng phát sinh sau khi gửi báo cáo phải được cập nhật kịp thời cho người tổng hợp; không chờ đến kỳ báo cáo sau.
>
> d) Nội dung do nhiều bộ phận cùng theo dõi phải được đối chiếu trước khi tổng hợp, nhất là số trẻ, chuyên cần, bán trú, tình hình sức khỏe, nhân sự và số liệu tài chính có liên quan.
>
> **Điều 4. Báo cáo theo yêu cầu và báo cáo đột xuất**
>
> **1. Báo cáo theo yêu cầu**
>
> a) Báo cáo chuyên đề, sơ kết, tổng kết và báo cáo phục vụ yêu cầu của cấp trên được thực hiện theo nội dung, biểu mẫu và thời hạn cụ thể của từng nhiệm vụ.
>
> b) Khi giao nhiệm vụ, phải xác định rõ người chủ trì, người phối hợp, nội dung cần cung cấp và thời hạn hoàn thành.
>
> c) Người chủ trì chịu trách nhiệm tổng hợp, kiểm tra và trình duyệt; người phối hợp chịu trách nhiệm cung cấp thông tin thuộc lĩnh vực được giao, bảo đảm chính xác, đầy đủ và đúng hạn.
>
> **2. Báo cáo đột xuất**
>
> a) Sự cố liên quan đến **an toàn trẻ, an ninh, tài chính, truyền thông phải báo cáo ngay**, không chờ báo cáo định kỳ.
>
> b) Người phát hiện hoặc trực tiếp tiếp nhận thông tin phải báo ngay cho Hiệu trưởng; đồng thời thông tin đến Phó Hiệu trưởng phụ trách để phối hợp xử lý. Nếu chưa liên hệ được Hiệu trưởng, phải báo cho thành viên Ban Giám hiệu đang trực hoặc đang điều hành để tiếp nhận, xử lý kịp thời.
>
> c) Hình thức báo cáo ban đầu bằng điện thoại hoặc trực tiếp. Không chỉ gửi tin nhắn rồi mặc nhiên xem như người có trách nhiệm đã tiếp nhận.
>
> d) Nội dung báo cáo ban đầu gồm: thời gian, địa điểm; sự việc đã xảy ra; người có liên quan; tình trạng hiện tại; biện pháp đã thực hiện và nội dung cần hỗ trợ. Phải phân biệt rõ thông tin đã xác minh và thông tin đang kiểm tra.
>
> đ) Việc báo cáo được thực hiện đồng thời với các biện pháp bảo đảm an toàn, hạn chế thiệt hại trong phạm vi trách nhiệm; không để việc chờ báo cáo hoặc chờ hoàn thiện văn bản làm chậm xử lý tình huống.
>
> e) Sau báo cáo ban đầu, cá nhân được giao tiếp tục cập nhật diễn biến và hoàn thiện báo cáo bằng văn bản theo yêu cầu của Hiệu trưởng. Không tự ý cung cấp thông tin chính thức, phát tán hình ảnh hoặc đưa ra kết luận về sự việc khi chưa được giao thẩm quyền.
>
> **Điều 5. Hình thức gửi, tiếp nhận và xử lý báo cáo**
>
> 1. Báo cáo định kỳ và báo cáo theo yêu cầu được gửi qua email, phần mềm quản lý hoặc kênh làm việc do nhà trường thống nhất. Bản giấy được thực hiện khi có yêu cầu phù hợp với tính chất hồ sơ.
>
> 2. Báo cáo phải ghi rõ người lập, bộ phận thực hiện, kỳ báo cáo và ngày gửi. Tệp báo cáo phải có tên thể hiện được nội dung, tổ hoặc điểm trường và tháng báo cáo để thuận tiện tổng hợp, tra cứu.
>
> 3. Người tiếp nhận có trách nhiệm kiểm tra nội dung, số liệu; yêu cầu làm rõ những điểm chưa đầy đủ hoặc chưa thống nhất. Yêu cầu bổ sung phải chỉ rõ nội dung cần hoàn thiện và thời hạn gửi lại.
>
> 4. Tổ trưởng, người phụ trách điểm trường và Phó Hiệu trưởng phải xử lý những nội dung thuộc trách nhiệm được giao; đối với vấn đề vượt thẩm quyền, tổng hợp và đề xuất Hiệu trưởng xem xét, quyết định.
>
> 5. Khi phát hiện báo cáo có sai sót, người lập phải thông báo ngay và gửi bản điều chỉnh, nêu rõ nội dung thay đổi để người tổng hợp cập nhật.
>
> 6. Trường hợp có nguy cơ không bảo đảm thời hạn, người được giao phải báo trước cho người phụ trách, nêu rõ lý do, tiến độ và đề xuất hướng giải quyết. Không tự ý kéo dài thời hạn báo cáo.
>
> **Điều 6. Tiếp nhận và xử lý văn bản đến**
>
> 1. **Tiếp nhận, đăng ký**
>
> Người được giao công tác văn thư tiếp nhận văn bản đến, kiểm tra nơi gửi, nơi nhận, tài liệu kèm theo; đăng ký và trình người có trách nhiệm xử lý theo quy trình văn thư của nhà trường.
>
> Trường hợp cá nhân nhận được văn bản công việc qua email hoặc kênh trao đổi khác, phải chuyển đến văn thư hoặc đầu mối được giao để theo dõi, xử lý thống nhất. Văn bản khẩn hoặc có thời hạn gấp phải được báo ngay cho Ban Giám hiệu.
>
> 2. **Phân công xử lý**
>
> Hiệu trưởng hoặc người được giao điều hành xem xét, giao người chủ trì, người phối hợp và thời hạn hoàn thành. Văn thư chuyển văn bản kèm ý kiến chỉ đạo đến đúng người được giao.
>
> 3. **Tổ chức thực hiện**
>
> Người chủ trì nghiên cứu đầy đủ văn bản và phụ lục; xác định nội dung cần thực hiện, chủ động phối hợp, chuẩn bị sản phẩm và trình đúng thời hạn. Nếu có nội dung chưa rõ hoặc khó bảo đảm tiến độ, phải báo ngay người giao nhiệm vụ để được hướng dẫn.
>
> 4. **Theo dõi kết quả**
>
> Văn thư hoặc người được giao theo dõi cập nhật tình trạng xử lý, nhắc thời hạn và báo cáo các nhiệm vụ còn chậm. Người chủ trì cung cấp kết quả thực hiện để hoàn tất hồ sơ, không xem việc đã chuyển văn bản cho người khác là đã hoàn thành nhiệm vụ.
>
> **Điều 7. Soạn thảo, phát hành và lưu trữ văn bản đi**
>
> 1. Cá nhân được giao soạn thảo chịu trách nhiệm về nội dung, số liệu, đối tượng nhận và tài liệu kèm theo; chủ động lấy ý kiến phối hợp khi văn bản liên quan đến nhiều lĩnh vực.
>
> 2. Phó Hiệu trưởng kiểm tra nội dung thuộc lĩnh vực phụ trách trước khi trình Hiệu trưởng. Người được giao công tác văn thư kiểm tra thể thức và thành phần hồ sơ theo nhiệm vụ được phân công.
>
> 3. **Chỉ người có thẩm quyền mới được ký văn bản và cung cấp thông tin chính thức của nhà trường.** Không tự ý phát hành dự thảo, sử dụng chữ ký, con dấu hoặc danh nghĩa nhà trường khi chưa được phép.
>
> 4. Văn bản sau khi ký được đăng ký, cấp số, phát hành và lưu trữ theo quy định về công tác văn thư. Văn thư kiểm tra đúng nơi nhận, đúng bản đã được ký và đầy đủ tài liệu kèm theo trước khi gửi.
>
> 5. Người chủ trì phối hợp văn thư lưu văn bản chính thức và tài liệu liên quan vào hồ sơ công việc; sắp xếp thuận tiện cho việc kiểm tra, tra cứu. Việc quản lý bản điện tử phải bảo đảm đúng phiên bản và giới hạn quyền truy cập phù hợp.
>
> **Điều 8. Trách nhiệm tổ chức thực hiện**
>
> **1. Ban Giám hiệu**
>
> a) Hiệu trưởng chỉ đạo chung; phân công đầu mối chủ trì; xem xét, giải quyết các nội dung báo cáo; phê duyệt văn bản và kiểm tra việc thực hiện.
>
> b) Phó Hiệu trưởng hướng dẫn, đôn đốc tổ trưởng, người phụ trách điểm trường và cá nhân thuộc lĩnh vực phụ trách; kiểm tra, tổng hợp báo cáo đúng thời hạn; tham mưu giải pháp đối với vấn đề phát sinh.
>
> c) Thống nhất biểu mẫu, thời điểm chốt số liệu và kênh gửi; lồng ghép các nội dung trùng nhau, bảo đảm chế độ báo cáo phục vụ thiết thực công tác điều hành.
>
> **2. Tổ trưởng và người phụ trách điểm trường**
>
> a) Triển khai yêu cầu báo cáo đến thành viên; bố trí thời gian thu thập thông tin phù hợp, bảo đảm gửi Phó Hiệu trưởng chủ trì trước ngày 25 hằng tháng.
>
> b) Kiểm tra, đối chiếu số liệu; phản ánh đầy đủ kết quả, tồn tại và đề xuất thuộc phạm vi phụ trách.
>
> c) Theo dõi việc thực hiện ý kiến chỉ đạo sau báo cáo; báo cáo lại kết quả xử lý những nội dung đã được giao.
>
> **3. Giáo viên và nhân viên**
>
> a) Cung cấp đầy đủ, kịp thời thông tin thuộc nhiệm vụ được giao; chịu trách nhiệm về tính chính xác của nội dung báo cáo.
>
> b) Chủ động phản ánh khó khăn, sự việc phát sinh; thực hiện ngay chế độ báo cáo đối với tình huống cần xử lý khẩn cấp.
>
> c) Thực hiện văn bản chỉ đạo được giao; phối hợp hoàn thiện hồ sơ và bảo mật thông tin trong quá trình thực hiện.
>
> **4. Người được giao công tác văn thư**
>
> a) Tiếp nhận, đăng ký, trình, chuyển giao, phát hành và lưu trữ văn bản theo nhiệm vụ được giao.
>
> b) Theo dõi thời hạn xử lý; nhắc việc, phản ánh kịp thời văn bản chưa được giải quyết hoặc nhiệm vụ có nguy cơ chậm hạn.
>
> c) Quản lý bản chính thức, bảo đảm văn bản được gửi đúng nơi nhận; không tự ý sửa nội dung văn bản đã được ký, phê duyệt.
>
> **Điều 9. Điều khoản thực hiện**
>
> 1. Quy định này cụ thể hóa Điều 14 của Quy chế làm việc của nhà trường và được thực hiện kể từ ngày … tháng … năm ….
>
> 2. Ban Giám hiệu phổ biến đến các tổ, điểm trường và toàn thể giáo viên, nhân viên; thống nhất đầu mối tiếp nhận, kênh gửi và biểu mẫu trước khi triển khai.
>
> 3. Những vướng mắc phát sinh được phản ánh về Phó Hiệu trưởng chủ trì để tổng hợp, trình Hiệu trưởng xem xét, giải quyết.
>
> Yêu cầu các tổ trưởng, người phụ trách điểm trường, giáo viên, nhân viên và cá nhân có liên quan nghiêm túc thực hiện./.
>
> **Nơi nhận:**  
> - Ban Giám hiệu;  
> - Các tổ, điểm trường;  
> - Giáo viên, nhân viên;  
> - Lưu: VT.
>
> **HIỆU TRƯỞNG**  
> *[Họ và tên]*
>
> ---
>
> **MẪU BÁO CÁO THÁNG**  
> *Dùng chung cho tổ và điểm trường*
>
> **Tổ/điểm trường:** ……………………………………  
> **Tháng báo cáo:** ……………………………………  
> **Kỳ số liệu: Từ ngày … đến ngày …**  
> **Người lập báo cáo:** ………………………………
>
> **1. Kết quả thực hiện nhiệm vụ**
>
> Nêu các công việc đã hoàn thành, số liệu và kết quả cụ thể; tập trung vào nhiệm vụ trọng tâm trong tháng.
>
> **2. Tồn tại, hạn chế và nguyên nhân**
>
> Nêu rõ nhiệm vụ chưa hoàn thành hoặc chưa đạt yêu cầu; nguyên nhân; biện pháp đã thực hiện và vấn đề còn cần giải quyết.
>
> **3. Nhiệm vụ, giải pháp tiếp theo**
>
> | STT | Nhiệm vụ, giải pháp | Người chịu trách nhiệm | Thời hạn hoàn thành |
> |---|---|---|---|
> | 1 | … | … | … |
> | 2 | … | … | … |
>
> **4. Đề xuất, kiến nghị**
>
> Nêu cụ thể nội dung đề nghị Ban Giám hiệu xem xét; nếu không có, ghi “Không có”.
>
> […], ngày … tháng … năm …  
> **NGƯỜI BÁO CÁO**  
> *[Họ và tên]*

---

USER

xuất file word nhé

---

ASSISTANT

Tôi sẽ xuất toàn bộ quy định và mẫu báo cáo tháng sang Word, căn chỉnh để cô thuận tiện chỉnh sửa và in ấn. Tôi dùng kỹ năng tài liệu Word và lưu tệp để cô tải về.

---

ASSISTANT

Tệp đã có đầy đủ 9 điều và mẫu báo cáo tháng, giữ nguyên mốc trước ngày 25 và trước ngày 28. Tôi đang kiểm tra ngắt trang và bảng phân công trước khi gửi cô.

---

ASSISTANT

Cô tải file Word gồm **toàn bộ quy định và mẫu báo cáo tháng**, đã căn chỉnh khổ A4 để in:

[Quy_dinh_che_do_bao_cao_va_xu_ly_van_ban.docx](sandbox:/workspace/scratch/19208c8fbb2f/Quy_dinh_che_do_bao_cao_va_xu_ly_van_ban.docx)

---

