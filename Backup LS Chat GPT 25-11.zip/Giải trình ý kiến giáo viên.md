USER

với vai trò hiệu trưởng, các văn bản  đính kèm  bạn hãy giúp tôi giải đáp các ý kiến đóng góp của giáo viên . Lặp luận chặt chẽ, logic thuyết phục, phù hợp thực tế đơn vị

---

ASSISTANT

Tôi sẽ đối chiếu từng ý kiến trong bảng góp ý của giáo viên với các dự thảo quy chế, nghị quyết và báo cáo của trường. Phần giải đáp sẽ nêu rõ ý kiến nào nên tiếp thu, ý kiến nào cần giải trình hoặc điều chỉnh, kèm lý do và cách thực hiện phù hợp với thực tế trường có ba điểm sau sáp nhập.

---

ASSISTANT

Tôi đã xác định được những nội dung cần giải trình kỹ nhất: phân công và chế độ làm việc sau sáp nhập, đánh giá viên chức theo thang 100 điểm, dân chủ trong góp ý và công khai tài chính. Tôi cũng phát hiện một số chi tiết trong dự thảo cần chỉnh trước khi ban hành để tránh gây tranh luận hoặc áp dụng bất lợi cho giáo viên.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# 📌 GIẢI TRÌNH, TIẾP THU Ý KIẾN ĐÓNG GÓP CỦA GIÁO VIÊN

**Trường Mầm non An Bình – Năm học 2026–2027**

Qua đối chiếu các dự thảo và báo cáo đính kèm, tôi đề xuất Hiệu trưởng giải đáp ý kiến giáo viên theo tinh thần: **Tôn trọng ý kiến đóng góp, bảo vệ quyền lợi chính đáng của viên chức, giữ vững nguyên tắc quản lý và đưa ra giải pháp thực hiện cụ thể.**

Đặc biệt, Trường Mầm non An Bình vừa sáp nhập từ ba đơn vị, nên cần phân biệt:

- **Những quy định pháp luật bắt buộc:** Nhà trường phải thực hiện, không thể thay đổi bằng biểu quyết tập thể.
- **Những nội dung thuộc quyền quyết định của Hiệu trưởng:** Cần xem xét ý kiến giáo viên, điều kiện thực tế và trách nhiệm quản lý trước khi quyết định.
- **Những nội dung nhà trường có thể điều chỉnh:** Nên tiếp thu khi đề xuất hợp lý, giúp giảm áp lực cho đội ngũ, nâng cao hiệu quả công việc và không ảnh hưởng chất lượng chăm sóc, giáo dục trẻ.

Một nguyên tắc rất quan trọng là: **Thống nhất quy chế không có nghĩa là phân công công việc giống hệt nhau tại ba điểm trường.** Công bằng phải dựa trên vị trí việc làm, khối lượng thực tế, điều kiện thực hiện và chế độ được hưởng.

**Phạm vi đối chiếu:** Tôi đã đọc được nội dung các văn bản Word, nhưng chưa trích xuất được các dòng góp ý cụ thể trong tệp Excel *“Copy of GÓP Ý CÁC VĂN KIỆN.xlsx”*. Vì vậy, phần dưới đây là bản giải trình theo những vấn đề có căn cứ trực tiếp trong các dự thảo, chưa phải kết quả trả lời từng giáo viên trong bảng Excel.

## 📖 Dự thảo nội dung giải trình của Hiệu trưởng

Bản dưới đây được viết theo văn phong hành chính, có thể sử dụng để chuẩn bị nội dung trả lời tại Hội nghị viên chức, người lao động và hoàn thiện sau khi đối chiếu bảng góp ý gốc.

> **writing · document**
>
> # DỰ THẢO NỘI DUNG GIẢI TRÌNH, TIẾP THU
> **Các ý kiến đóng góp đối với văn kiện Hội nghị viên chức, người lao động năm học 2026–2027**
>
> **TRƯỜNG MẦM NON AN BÌNH**
>
> ## I. QUAN ĐIỂM TIẾP THU VÀ GIẢI TRÌNH
>
> Ban Giám hiệu nhà trường trân trọng ghi nhận tinh thần trách nhiệm của đội ngũ viên chức, người lao động trong việc nghiên cứu và đóng góp ý kiến đối với các dự thảo quy chế, nghị quyết và báo cáo của nhà trường.
>
> Việc xây dựng các văn kiện năm học 2026–2027 được thực hiện trong điều kiện Trường Mầm non An Bình vừa sáp nhập từ ba đơn vị, có sự khác biệt nhất định về nhân sự, điều kiện cơ sở vật chất, tổ chức bán trú và phương thức quản lý.
>
> Do đó, yêu cầu đặt ra là vừa bảo đảm sự thống nhất trong quản lý, vừa phát huy những cách làm hiệu quả của các đơn vị trước sáp nhập, đồng thời khắc phục những nội dung chưa phù hợp.
>
> Nhà trường xác định việc xem xét các ý kiến dựa trên bốn nguyên tắc:
>
> 1. Tuân thủ quy định pháp luật, chỉ đạo của cấp có thẩm quyền và chức năng, nhiệm vụ của nhà trường.
> 2. Bảo đảm quyền, lợi ích hợp pháp của viên chức, người lao động; công bằng trong phân công, đánh giá và thực hiện chế độ chính sách.
> 3. Phù hợp điều kiện thực tế của ba điểm trường, khả năng bố trí nhân sự, kinh phí và yêu cầu bảo đảm an toàn cho trẻ.
> 4. Ý kiến được tiếp thu hoặc không tiếp thu đều phải có lý do rõ ràng; trường hợp cần điều chỉnh phải xác định nội dung, trách nhiệm và thời điểm thực hiện.
>
> ## II. NỘI DUNG GIẢI TRÌNH THEO CÁC NHÓM VẤN ĐỀ
>
> ### 1. Về yêu cầu thống nhất các quy chế sau sáp nhập
>
> **Nội dung cần giải trình:** Việc xây dựng một hệ thống quy chế chung có làm mất đi những quy định và cách làm phù hợp của các trường trước đây hay không?
>
> **Giải trình của Hiệu trưởng:**
>
> Sau sáp nhập, Trường Mầm non An Bình là một đơn vị có tổ chức quản lý thống nhất. Vì vậy, việc xây dựng quy chế chung là cần thiết nhằm xác định rõ trách nhiệm, thẩm quyền, chế độ làm việc và nguyên tắc giải quyết công việc.
>
> Tuy nhiên, thống nhất quản lý không có nghĩa là phủ nhận toàn bộ kết quả hoặc cách làm của các trường cũ. Những nội dung đã thực hiện hiệu quả, phù hợp pháp luật và điều kiện hiện nay cần được kế thừa.
>
> Đồng thời, không thể giữ nguyên mọi quy định riêng của ba đơn vị nếu dẫn đến chồng chéo, không đồng nhất hoặc tạo ra sự khác biệt thiếu căn cứ trong cùng một trường.
>
> **Hướng xử lý:** Thống nhất mục tiêu, nguyên tắc và quy trình toàn trường; cho phép tổ chức thực hiện linh hoạt theo điều kiện từng điểm trường, nhưng không làm thay đổi quyền lợi hợp pháp hoặc tiêu chuẩn chuyên môn chung.
>
> ### 2. Về phân công nhiệm vụ và bảo đảm công bằng giữa giáo viên
>
> **Nội dung cần giải trình:** Phân công công việc tại ba điểm trường như thế nào để bảo đảm công bằng, tránh nơi quá tải, nơi ít việc?
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất rằng công bằng không có nghĩa là mọi giáo viên phải được giao số lượng công việc giống nhau, mà phải được xem xét tương quan giữa nhiệm vụ, điều kiện thực hiện và trách nhiệm được giao.
>
> Đặc thù giáo dục mầm non cho thấy khối lượng công việc không chỉ phụ thuộc vào số lớp mà còn chịu ảnh hưởng của số trẻ, độ tuổi, điều kiện bán trú, trẻ cần hỗ trợ đặc biệt, số giáo viên thực tế và cơ sở vật chất tại từng điểm.
>
> Vì vậy, việc phân công phải căn cứ vị trí việc làm, năng lực chuyên môn, yêu cầu chăm sóc trẻ, số lượng nhân sự và điều kiện cụ thể. Không nên điều chỉnh nhân sự hoặc giao thêm nhiệm vụ chỉ nhằm tạo sự cân bằng về hình thức.
>
> **Hướng xử lý:** Hiệu trưởng chỉ đạo rà soát khối lượng công việc theo từng điểm trường; công khai phân công, xác định người phụ trách và xem xét điều chỉnh khi phát sinh mất cân đối có căn cứ. Các trường hợp điều chỉnh vị trí công tác phải được giải thích rõ về yêu cầu nhiệm vụ và điều kiện thực hiện.
>
> ### 3. Về thời gian làm việc, trực trưa, đón và trả trẻ
>
> **Nội dung cần giải trình:** Việc bố trí trực trưa, đón trẻ sớm, trả trẻ muộn và các nhiệm vụ khác có làm vượt thời gian làm việc của giáo viên hay không?
>
> **Giải trình của Hiệu trưởng:**
>
> Theo Thông tư số 11/2026/TT-BGDĐT, thời gian làm việc của giáo viên mầm non phải bảo đảm 40 giờ/tuần. Định mức giờ dạy của giáo viên tại nhóm, lớp học hai buổi/ngày là 5 giờ 30 phút/ngày; lớp học một buổi/ngày là 4 giờ/ngày.
>
> Cần phân biệt định mức giờ dạy với tổng thời gian làm việc. Giáo viên còn thực hiện các nhiệm vụ chuyên môn khác theo phân công, nhưng tổng thời gian làm việc và chế độ nghỉ ngơi phải được bảo đảm theo quy định.
>
> Việc tổ chức ăn, ngủ, đón và trả trẻ là nhiệm vụ có tính đặc thù, cần bố trí người chịu trách nhiệm rõ ràng. Nhà trường không được mặc nhiên coi toàn bộ thời gian giáo viên trực tiếp trông trẻ buổi trưa là thời gian nghỉ.
>
> Ngược lại, cũng không thể vì thiếu nhân sự mà yêu cầu giáo viên thường xuyên làm vượt thời gian quy định nhưng không xem xét chế độ liên quan.
>
> **Hướng xử lý:** Tiếp thu yêu cầu rà soát lịch làm việc thực tế; công khai lịch phân công theo điểm trường, bảo đảm thời gian nghỉ hợp pháp. Trường hợp phát sinh làm thêm hoặc dạy thêm giờ phải được xác định, phê duyệt và giải quyết theo đúng quy định.
>
> ### 4. Về nghỉ phép, nghỉ việc riêng và bố trí giáo viên dạy thay
>
> **Nội dung cần giải trình:** Khi giáo viên nghỉ có lý do chính đáng, ai chịu trách nhiệm bố trí người thay thế?
>
> **Giải trình của Hiệu trưởng:**
>
> Nghỉ ốm, thai sản, nghỉ lễ, nghỉ việc riêng và các chế độ nghỉ khác là quyền hợp pháp của viên chức, người lao động khi đáp ứng điều kiện tương ứng.
>
> Giáo viên có trách nhiệm thông tin, thực hiện thủ tục và bàn giao công việc phù hợp. Hiệu trưởng có trách nhiệm tổ chức nhân sự thay thế để bảo đảm hoạt động chăm sóc, giáo dục trẻ không bị gián đoạn.
>
> Do đó, không thể quy định giáo viên nghỉ hợp pháp phải tự tìm người thay hoặc tự bỏ tiền thuê người dạy thay. Việc phân công dạy thay thuộc trách nhiệm quản lý của nhà trường.
>
> Tuy nhiên, quyền nghỉ không đồng nghĩa với việc tự ý bỏ lớp hoặc nghỉ không thực hiện thủ tục khi điều kiện khách quan cho phép.
>
> **Hướng xử lý:** Giữ nguyên nguyên tắc bảo vệ quyền nghỉ hợp pháp; bổ sung quy trình thông báo, bàn giao và bố trí nhân sự thay thế. Trường hợp phát sinh dạy thêm giờ được xem xét theo khối lượng thực tế và chế độ hiện hành.
>
> ### 5. Về hồ sơ, sổ sách chuyên môn và chuyển đổi số
>
> **Nội dung cần giải trình:** Nhà trường có nên tiếp tục yêu cầu thêm nhiều loại biểu mẫu, báo cáo và minh chứng chuyên môn hay không?
>
> **Giải trình của Hiệu trưởng:**
>
> Mục tiêu quản lý hồ sơ là phục vụ công tác chăm sóc, nuôi dưỡng, giáo dục trẻ và theo dõi chất lượng chuyên môn, không phải tạo thêm thủ tục hành chính.
>
> Dự thảo Quy chế chuyên môn của trường đã xác định ba nhóm hồ sơ của giáo viên theo Điều lệ trường mầm non: kế hoạch nuôi dưỡng, chăm sóc, giáo dục nhóm/lớp; sổ theo dõi trẻ; sổ theo dõi tài sản, thiết bị, đồ chơi nhóm/lớp.
>
> Việc kiểm tra hồ sơ phải tập trung vào tính chính xác, khả năng sử dụng và hiệu quả thực tế. Không nên yêu cầu giáo viên lập thêm hồ sơ chỉ để minh chứng cho việc hoàn thành KPI hoặc phục vụ các đợt kiểm tra.
>
> Hồ sơ điện tử có giá trị hợp pháp cần được sử dụng thay thế hồ sơ giấy theo quy định, tránh bắt buộc thực hiện đồng thời hai hình thức có nội dung trùng nhau.
>
> **Hướng xử lý:** Tiếp thu chủ trương giảm tải hồ sơ; rà soát toàn bộ biểu mẫu đang sử dụng, loại bỏ yêu cầu trùng lặp và thống nhất hướng dẫn dùng chung tại ba điểm trường.
>
> ### 6. Về sinh hoạt chuyên môn, dự giờ và các phong trào
>
> **Nội dung cần giải trình:** Làm thế nào để sinh hoạt chuyên môn thực chất, không gia tăng áp lực hình thức?
>
> **Giải trình của Hiệu trưởng:**
>
> Sinh hoạt chuyên môn là nhiệm vụ thường xuyên nhằm hỗ trợ giáo viên cải tiến hoạt động chăm sóc, giáo dục trẻ.
>
> Theo Quy chế làm việc và dự thảo Nghị quyết của trường, tổ chuyên môn sinh hoạt định kỳ ít nhất hai tuần một lần; tổ văn phòng ít nhất một lần mỗi tháng.
>
> Tuy nhiên, chất lượng sinh hoạt chuyên môn không được đo bằng số lượng giấy tờ, hình ảnh hoặc các hoạt động trình diễn. Trọng tâm phải là giải quyết khó khăn thực tế, chia sẻ kinh nghiệm tổ chức hoạt động, hỗ trợ trẻ và nâng cao năng lực giáo viên.
>
> Các hội thi, phong trào cần được tổ chức đúng mục đích, phù hợp hướng dẫn của ngành; không biến các sản phẩm trang trí, đồ dùng tự làm hoặc hoạt động ngoài nhiệm vụ thành tiêu chí bắt buộc thiếu căn cứ.
>
> **Hướng xử lý:** Giữ nguyên yêu cầu sinh hoạt chuyên môn theo quy định, đồng thời tiếp thu việc đổi mới hình thức, giảm hồ sơ không cần thiết và bố trí thời gian phù hợp.
>
> ### 7. Về cơ cấu đánh giá viên chức 100 điểm
>
> **Nội dung cần giải trình:** Vì sao nhà trường áp dụng thang điểm 100 với 30 điểm tiêu chí chung và 70 điểm kết quả nhiệm vụ?
>
> **Giải trình của Hiệu trưởng:**
>
> Việc áp dụng cơ cấu 100 điểm không phải chủ trương tự đặt ra của nhà trường mà được xây dựng trên cơ sở Nghị định số 233/2026/NĐ-CP.
>
> Trong đó, 30 điểm phản ánh phẩm chất, đạo đức, trách nhiệm và các tiêu chí chung; 70 điểm phản ánh kết quả thực hiện nhiệm vụ.
>
> Cơ cấu này thể hiện yêu cầu chuyển từ đánh giá chủ yếu bằng nhận xét định tính sang đánh giá có căn cứ về khối lượng, chất lượng và tiến độ công việc.
>
> Tuy nhiên, nhà trường không thể áp dụng một bộ tiêu chí chi tiết giống hệt nhau cho giáo viên, nhân viên và viên chức quản lý, vì tính chất sản phẩm công việc của từng nhóm khác nhau.
>
> Việc đánh giá cũng không được dựa vào số lượng hồ sơ hình thức hoặc những công việc không được giao.
>
> **Hướng xử lý:** Giữ cơ cấu 30/70 theo quy định; tiếp thu việc cụ thể hóa tiêu chí theo từng nhóm vị trí việc làm, công khai cách chấm và minh chứng, bảo đảm giáo viên được tự đánh giá và giải trình khi có chênh lệch điểm.
>
> ### 8. Về xếp loại hoàn thành xuất sắc nhiệm vụ
>
> **Nội dung cần giải trình:** Giáo viên đạt từ 90 điểm có đương nhiên được xếp loại hoàn thành xuất sắc nhiệm vụ hay không?
>
> **Giải trình của Hiệu trưởng:**
>
> Điểm từ 90 trở lên là điều kiện về điểm số, nhưng chưa phải điều kiện duy nhất để được xếp loại hoàn thành xuất sắc nhiệm vụ.
>
> Nghị định số 233/2026/NĐ-CP còn quy định giới hạn tỷ lệ xếp loại hoàn thành xuất sắc nhiệm vụ trong phạm vi đơn vị và nhóm viên chức có nhiệm vụ tương đồng.
>
> Vì vậy, việc nhiều giáo viên đạt từ 90 điểm trở lên nhưng số người được xếp loại xuất sắc bị giới hạn không có nghĩa là nhà trường phủ nhận kết quả công tác của những người còn lại.
>
> Tuy nhiên, nhà trường phải bảo đảm việc lựa chọn trong phạm vi tỷ lệ được phép là khách quan, dựa trên kết quả thực chất, có minh chứng và đúng thẩm quyền; không phân chia chỉ tiêu theo cảm tính hoặc ưu tiên đơn vị cũ.
>
> **Hướng xử lý:** Giữ nguyên điều kiện và giới hạn tỷ lệ theo pháp luật; bổ sung hướng dẫn so sánh trong nhóm nhiệm vụ tương đồng và quy trình công khai, giải trình kết quả.
>
> ### 9. Về đánh giá giáo viên nghỉ thai sản, nghỉ ốm hoặc chuyển công tác sau sáp nhập
>
> **Nội dung cần giải trình:** Giáo viên nghỉ chế độ hoặc chuyển từ trường cũ sang trường mới có bị thiệt thòi khi tính điểm đánh giá hay không?
>
> **Giải trình của Hiệu trưởng:**
>
> Việc đánh giá phải căn cứ thời gian công tác thực tế và những nhiệm vụ thực sự được giao, không lấy thời gian nghỉ đúng chế độ làm căn cứ mặc nhiên đánh giá thấp viên chức.
>
> Đối với giáo viên nghỉ ốm, thai sản và các trường hợp đặc biệt, nhà trường thực hiện theo Điều 14 Nghị định số 233/2026/NĐ-CP.
>
> Đối với viên chức chuyển công tác do sắp xếp, sáp nhập, kết quả theo dõi, đánh giá của đơn vị cũ là nguồn thông tin cần được tiếp nhận, đối chiếu và sử dụng theo quy định.
>
> Không hợp lý nếu bỏ qua toàn bộ kết quả công tác trước sáp nhập; cũng không hợp lý nếu tự động chuyển các thang điểm thi đua cũ khác cấu trúc sang hệ thống đánh giá mới mà không có phương pháp đối chiếu.
>
> **Hướng xử lý:** Tiếp thu yêu cầu đánh giá theo thời gian thực tế; rà soát hồ sơ bàn giao của ba đơn vị, xác định cách tổng hợp kết quả minh bạch và thống nhất trước khi xếp loại.
>
> ### 10. Về Quy chế chi tiêu nội bộ và chế độ phúc lợi
>
> **Nội dung cần giải trình:** Nhà trường có thể duy trì hoặc nâng các khoản hỗ trợ, phúc lợi như trước khi sáp nhập hay không?
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường chia sẻ nguyện vọng được bảo đảm và từng bước cải thiện đời sống của đội ngũ viên chức, người lao động.
>
> Tuy nhiên, chế độ chi tiêu không chỉ phụ thuộc mong muốn của tập thể mà phải có nguồn kinh phí hợp pháp, căn cứ chi, dự toán và thẩm quyền quyết định.
>
> Các khoản chi bắt buộc theo chế độ cần được bảo đảm theo quy định. Đối với khoản chi phúc lợi hoặc hỗ trợ có tính chất đề xuất, mức chi phải phù hợp khả năng tài chính thực tế và cơ chế tự chủ được giao.
>
> Việc ba trường trước đây có mức chi hoặc nguồn kinh phí khác nhau không tạo ra căn cứ để tự động duy trì tất cả mức chi tại trường mới. Ngược lại, nhà trường cũng không được cắt giảm quyền lợi đã được pháp luật bảo đảm chỉ vì lý do sáp nhập.
>
> **Hướng xử lý:** Tiếp thu yêu cầu công khai nguồn kinh phí và căn cứ từng khoản chi; giao kế toán đối chiếu dự toán sau sáp nhập, xác định khoản chi bắt buộc, khoản chi có điều kiện và khoản chưa đủ cơ sở thực hiện. Không cam kết mức hỗ trợ khi chưa xác nhận nguồn kinh phí hợp pháp.
>
> ### 11. Về các khoản thu bán trú, hoạt động ngoại khóa và làm quen tiếng Anh
>
> **Nội dung cần giải trình:** Tại sao các hoạt động dịch vụ phải được quản lý thống nhất và có thể có cách tổ chức khác nhau giữa các điểm trường?
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường có trách nhiệm thực hiện chính sách miễn học phí đối với trẻ mầm non công lập theo quy định; đồng thời phân biệt rõ kinh phí ngân sách cấp bù với các khoản thu dịch vụ hợp pháp.
>
> Đối với hoạt động bán trú, ngoại khóa, làm quen tiếng Anh hoặc các dịch vụ khác, việc tổ chức phải căn cứ nhu cầu thực tế, điều kiện triển khai và quy định của cơ quan có thẩm quyền.
>
> Theo Quyết định số 105/2026/QĐ-UBND của UBND tỉnh Đồng Tháp, các khoản thu dịch vụ phải bảo đảm nguyên tắc tự nguyện, công khai, dân chủ, đúng mục đích; có dự toán thu, chi và thực hiện kế toán theo quy định.
>
> Trường có thể thống nhất quy trình quản lý nhưng không nhất thiết phải tổ chức các dịch vụ có nội dung giống nhau tại mọi điểm trường khi điều kiện và nhu cầu khác nhau.
>
> **Hướng xử lý:** Thực hiện thu, chi theo quy định hiện hành; công khai nội dung dịch vụ, mức thu, cơ sở xác định chi phí và đối tượng được miễn, giảm. Không giao chỉ tiêu ép buộc giáo viên vận động phụ huynh đăng ký hoặc đóng góp trái quy định.
>
> ### 12. Về bảo đảm an toàn cho trẻ và trách nhiệm khi xảy ra sự cố
>
> **Nội dung cần giải trình:** Khi trẻ xảy ra tai nạn hoặc sự cố, giáo viên có mặc nhiên phải chịu toàn bộ trách nhiệm hay không?
>
> **Giải trình của Hiệu trưởng:**
>
> Bảo đảm an toàn thể chất, tinh thần cho trẻ là nhiệm vụ ưu tiên hàng đầu và là trách nhiệm chung của nhà trường.
>
> Giáo viên phải thực hiện đúng quy trình chăm sóc, giám sát, phòng ngừa nguy cơ, phát hiện và xử lý kịp thời sự cố. Đây là yêu cầu không thể xem nhẹ.
>
> Tuy nhiên, cần phân biệt giữa việc xảy ra sự cố với việc đã xác định có hành vi vi phạm. Mỗi sự việc phải được xác minh khách quan, xem xét điều kiện thực tế, nguyên nhân, mức độ thực hiện nhiệm vụ và trách nhiệm của các cá nhân, bộ phận liên quan.
>
> Không thể chỉ căn cứ vào phản ánh chưa được kiểm chứng hoặc kết quả xảy ra sự cố để tự động quy kết lỗi cho giáo viên.
>
> **Hướng xử lý:** Giữ nguyên yêu cầu nghiêm ngặt về an toàn trẻ; thực hiện quy trình báo cáo, xác minh, xử lý và phòng ngừa tái diễn. Bảo đảm quyền giải trình của người liên quan và xử lý trách nhiệm đúng thẩm quyền.
>
> ### 13. Về chỉ tiêu nghị quyết và điều kiện thực hiện tại ba điểm trường
>
> **Nội dung cần giải trình:** Có nên kế thừa toàn bộ chỉ tiêu về sĩ số, phong trào, thành tích và cơ sở vật chất của ba trường cũ?
>
> **Giải trình của Hiệu trưởng:**
>
> Các chỉ tiêu trước sáp nhập được xây dựng trên quy mô và điều kiện của từng trường, với thời điểm và cách xác định số liệu có thể khác nhau.
>
> Vì vậy, việc cộng cơ học chỉ tiêu hoặc duy trì đồng thời toàn bộ mục tiêu của ba trường cũ có thể tạo ra số liệu không chính xác, chỉ tiêu không khả thi hoặc làm gia tăng áp lực thành tích.
>
> Nghị quyết mới phải dựa trên số liệu trẻ, nhóm lớp, đội ngũ, cơ sở vật chất và nguồn lực đã được đối soát, xác nhận.
>
> Đối với những nhiệm vụ chịu ảnh hưởng bởi điều kiện khách quan, nhà trường cần xác định rõ mục tiêu, lộ trình và giải pháp hỗ trợ, không giao trách nhiệm vượt quá khả năng thực hiện mà thiếu điều kiện cần thiết.
>
> **Hướng xử lý:** Tiếp thu việc rà soát chỉ tiêu; xây dựng hệ chỉ tiêu chung nhưng có phân công nhiệm vụ và giải pháp phù hợp từng điểm trường. Ưu tiên an toàn trẻ, chất lượng chăm sóc, nuôi dưỡng, giáo dục trước các chỉ tiêu mang tính thành tích.
>
> ### 14. Về quyền đóng góp ý kiến, bảo lưu ý kiến và trách nhiệm giải trình
>
> **Nội dung cần giải trình:** Giáo viên có quyền không đồng tình với một số nội dung trong dự thảo hay không?
>
> **Giải trình của Hiệu trưởng:**
>
> Viên chức, người lao động có quyền tham gia ý kiến, kiến nghị, phản ánh và bảo lưu ý kiến theo quy định pháp luật.
>
> Việc một giáo viên có quan điểm khác với đề xuất của Ban Giám hiệu không đồng nghĩa với thiếu tinh thần trách nhiệm hoặc không chấp hành quy chế.
>
> Nhà trường phải lắng nghe, nghiên cứu và giải trình khách quan. Tuy nhiên, quyền góp ý không đồng nghĩa mọi đề xuất đều bắt buộc được chấp thuận; việc quyết định cuối cùng phải tuân thủ đúng thẩm quyền và pháp luật.
>
> Khi văn bản được ban hành hợp pháp, viên chức, người lao động có trách nhiệm thực hiện; đồng thời vẫn được thực hiện quyền kiến nghị, khiếu nại hoặc phản ánh theo quy định.
>
> **Hướng xử lý:** Tiếp thu việc xây dựng quy trình phản hồi minh bạch; tổng hợp ý kiến bằng văn bản, nêu rõ lý do tiếp thu hoặc không tiếp thu, thông báo kết quả đến đội ngũ tại cả ba điểm trường.
>
> ## III. NHỮNG NỘI DUNG CẦN RÀ SOÁT, HOÀN THIỆN TRƯỚC KHI BAN HÀNH
>
> Qua đối chiếu dự thảo, cần giao các bộ phận rà soát thêm:
>
> 1. **Quy chế chi tiêu nội bộ:** Sửa lỗi tên đơn vị cũ còn xuất hiện trong văn bản, thống nhất tên và ký hiệu quyết định; kiểm tra lại các căn cứ pháp lý, nguồn kinh phí và định mức chi.
>
> 2. **Hiệu lực Quy chế chi tiêu nội bộ:** Làm rõ thời điểm áp dụng đối với giai đoạn sau sáp nhập, đặc biệt không mặc nhiên áp dụng hồi tố quy định mới làm ảnh hưởng quyền lợi hoặc xử lý các khoản chi đã phát sinh hợp pháp.
>
> 3. **Chính sách học phí:** Phân biệt kinh phí ngân sách cấp bù miễn học phí với các khoản dịch vụ do cha mẹ trẻ tự nguyện sử dụng.
>
> 4. **Quy chế chuyên môn:** Đối chiếu số, ngày quyết định ban hành với phần ghi chú tại quy chế kèm theo; rà soát các căn cứ và nội dung liên quan hồ sơ, sổ sách.
>
> 5. **Quy chế đánh giá viên chức:** Bảo đảm thống nhất thang điểm, tiêu chí, minh chứng, cách xử lý trường hợp không phát sinh nhiệm vụ, nghỉ chế độ và giới hạn tỷ lệ hoàn thành xuất sắc nhiệm vụ.
>
> 6. **Các báo cáo và nghị quyết:** Kiểm tra lại ngày ban hành, năm học và phạm vi áp dụng của nghị quyết ba trường trước sáp nhập; không sử dụng số liệu chưa được đối soát làm chỉ tiêu chính thức.
>
> 7. **Tính thống nhất giữa các quy chế:** Nội dung về thời giờ làm việc, trực trưa, dạy thay, nghỉ phép, đánh giá, chế độ tài chính và dân chủ phải thống nhất, không quy định mâu thuẫn hoặc vượt thẩm quyền.
>
> ## IV. TỔ CHỨC TIẾP THU VÀ HOÀN THIỆN
>
> Hiệu trưởng giao các Phó Hiệu trưởng, kế toán, tổ chuyên môn, tổ văn phòng và bộ phận có liên quan nghiên cứu từng ý kiến thuộc lĩnh vực phụ trách.
>
> Mỗi ý kiến cần được phân loại thành một trong các hướng xử lý: tiếp thu toàn bộ; tiếp thu một phần; không tiếp thu và giải trình; hoặc cần tiếp tục xác minh, xin ý kiến cấp có thẩm quyền.
>
> Đối với nội dung được tiếp thu, phải ghi rõ điều khoản, câu chữ hoặc biện pháp được điều chỉnh.
>
> Đối với nội dung chưa tiếp thu, phải giải thích bằng căn cứ pháp lý, yêu cầu chuyên môn hoặc điều kiện thực tế; tránh trả lời chung chung hoặc chỉ viện dẫn thẩm quyền của Hiệu trưởng.
>
> Bộ phận tổng hợp hoàn chỉnh bảng giải trình, báo cáo Hiệu trưởng xem xét và thông tin đến viên chức, người lao động trước khi hoàn thiện hồ sơ Hội nghị hoặc ban hành văn bản theo thẩm quyền.
>
> ## V. KẾT LUẬN
>
> Ban Giám hiệu nhà trường xác định rằng việc góp ý xây dựng quy chế không chỉ là thực hiện yêu cầu dân chủ mà còn là cơ hội để rà soát lại phương thức quản lý, nhận diện những bất cập và xây dựng sự đồng thuận trong tập thể sau sáp nhập.
>
> Nhà trường không đặt mục tiêu ban hành quy chế chỉ để tăng cường kiểm tra, ràng buộc trách nhiệm giáo viên, mà hướng đến tạo cơ sở làm việc rõ ràng, công bằng, minh bạch và hiệu quả.
>
> Những nội dung phù hợp sẽ được tiếp thu, những nội dung chưa phù hợp cần được giải trình thấu đáo và những vấn đề vượt thẩm quyền phải được báo cáo, xin ý kiến cơ quan có thẩm quyền.
>
> **Quan điểm xuyên suốt của nhà trường là: Quy định phải nghiêm túc, phân công phải công bằng, đánh giá phải khách quan, quyền lợi chính đáng phải được bảo đảm và mọi hoạt động quản lý phải phục vụ mục tiêu nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ.**
>
> Nhà trường mong muốn toàn thể viên chức, người lao động tiếp tục phát huy tinh thần trách nhiệm, đồng hành cùng Ban Giám hiệu xây dựng Trường Mầm non An Bình ổn định, đoàn kết và phát triển bền vững.
>
> **HIỆU TRƯỞNG**
>
> *(Dự thảo phục vụ đối chiếu, chưa phải văn bản giải trình chính thức đối với từng ý kiến trong bảng góp ý.)*

## ⚠️ Những điểm cần ưu tiên chỉnh sửa ngay

Ngoài các nội dung giải trình, tôi nhận thấy một số chi tiết cụ thể trong hồ sơ có thể làm giảm tính thuyết phục của Hiệu trưởng nếu giáo viên đối chiếu văn bản:

| Văn bản | Vấn đề phát hiện | Đề xuất |
|--------|--------|--------|
| Quy chế chi tiêu nội bộ | Ghi Luật Ngân sách nhà nước số 89/2025/QH15 với năm ban hành **2055** | Sửa thành ngày 25/6/2025. [Luật số 89/2025/QH15 của Quốc hội: Luật Ngân sách nhà nước](<https://vanban.chinhphu.vn/?classid=1&docid=214601&pageid=27160>) |
| Quy chế chi tiêu nội bộ | Quyết định dự thảo có hiệu lực từ 13/8/2026 dù đang để ngày ký dự kiến sau đó | Rà soát hiệu lực, hướng xử lý tài chính chuyển tiếp; tránh áp dụng hồi tố không có căn cứ |
| Quy chế chi tiêu nội bộ | Còn tên Trường Mầm non An Bình B và ký hiệu `QĐ-MNABB` | Sửa thống nhất tên, ký hiệu Trường Mầm non An Bình |
| Quy chế chuyên môn | Căn cứ Thông tư 28/2026/TT-BGDĐT ghi ngày 29/4/2026 | Ngày ban hành theo Cổng thông tin Chính phủ là **09/4/2026**. [Thông tư số 28/2026/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Quy định Chuẩn nghề nghiệp giáo viên mầm non](<https://vanban.chinhphu.vn/?classid=1&docid=217730&pageid=27160>) |
| Quy chế chi tiêu nội bộ | Một số khoản được diễn đạt là thu, chi học phí | Làm rõ chính sách miễn học phí của trẻ mầm non công lập và nguồn ngân sách cấp bù theo Nghị định 238/2025/NĐ-CP. [Nghị định số 238/2025/NĐ\-CP: Đối tượng được miễn, giảm học phí; hỗ trợ học phí, chi phí học tập](<https://xaydungchinhsach.chinhphu.vn/nghi-dinh-so-238-2025-nd-cp-quy-dinh-ve-chinh-sach-hoc-phi-mien-giam-ho-tro-hoc-phi-chi-phi-hoc-tap-11925090417435344.htm>) |
| Quy chế chuyên môn | Quyết định đã ghi số 78/QĐ-MNAB ngày 09/10/2026 nhưng phần quy chế kèm theo còn để trống | Hoàn thiện số, ngày tương ứng; nếu sửa nội dung đã ban hành cần thực hiện thủ tục sửa đổi |
| Báo cáo đối chiếu ba nghị quyết | Nghị quyết An Lộc ghi ngày 15/9/2026 trong hồ sơ đối chiếu nhiệm vụ năm học 2025–2026 | Kiểm tra nghị quyết gốc, ngày và năm học trước khi xác nhận là căn cứ |
| Nghị quyết Hội nghị viên chức | Dẫn chiếu các quy chế đang trong quá trình lấy ý kiến | Đồng bộ trạng thái và hiệu lực văn bản trước khi thông qua nghị quyết chính thức |

Các kết luận pháp lý trọng tâm về chế độ làm việc và đánh giá viên chức đã được đối chiếu với Thông tư 11/2026/TT-BGDĐT và Nghị định 233/2026/NĐ-CP. [TOÀN VĂN: Thông tư 11/2026/TT\-BGDĐT quy định chế độ làm việc với giáo viên mầm non](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-11-2026-tt-bgddt-quy-dinh-che-do-lam-viec-voi-giao-vien-mam-non-119260305102619461.htm>); [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=chuong_3>); [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=chuong_3>)

## ✅ Khuyến nghị cách Hiệu trưởng trả lời tại Hội nghị

Nên tránh cách giải trình chỉ dừng ở câu “đây là quy định của cấp trên nên phải thực hiện”. Đối với mỗi kiến nghị, cách trả lời thuyết phục nhất là nêu **quy định nào bắt buộc, nội dung nào nhà trường được quyết định, giáo viên được bảo đảm quyền lợi gì và nhà trường sẽ làm gì để thực hiện khả thi**.

Để hoàn thành đúng yêu cầu ban đầu của cô, bước còn thiếu là nội dung từng dòng trong bảng Excel góp ý. Khi bảng đó có thể đọc được dưới dạng PDF hoặc nội dung bảng được đưa trực tiếp vào cuộc trò chuyện, các phần giải trình mẫu trên sẽ được đối chiếu để đưa ra kết luận **tiếp thu, tiếp thu một phần hoặc không tiếp thu** cho từng ý kiến cụ thể, không gán các vấn đề dự kiến thành phát biểu thực tế của giáo viên.

---

ASSISTANT

---

ASSISTANT

Đối chiếu quy định hiện hành cho thấy hai điểm quan trọng: cơ cấu đánh giá viên chức 30 điểm tiêu chí chung và 70 điểm kết quả nhiệm vụ phù hợp Nghị định 233/2026/NĐ-CP; còn chế độ làm việc của giáo viên mầm non phải bảo đảm 40 giờ/tuần theo Thông tư 11/2026/TT-BGDĐT. Đây là cơ sở để giải đáp các ý kiến về KPI, trực trưa, dạy thay và khối lượng công việc, tránh áp dụng cứng nhắc.

---

ASSISTANT

---

ASSISTANT

---

USER

bạn giúp tôi hệ thống lại các ý kiến của từng giáo viên để dễ nắm bắt nội dung nhé

---

ASSISTANT

Tôi sẽ tập trung vào bảng “GÓP Ý CÁC VĂN KIỆN”, nhóm ý kiến theo từng giáo viên, giữ nguyên nội dung cốt lõi và ghi rõ văn bản được góp ý. Sau đó tôi sẽ lập bảng tổng hợp ngắn gọn để cô dễ theo dõi, tránh bỏ sót hoặc nhầm ý kiến giữa các giáo viên.

---

ASSISTANT

Tôi sẽ hệ thống các ý kiến theo **từng giáo viên**, giúp cô nắm nhanh ai góp ý nội dung gì, có những đề xuất nào trùng nhau và vấn đề nào Ban Giám hiệu cần tập trung giải đáp.

Tuy nhiên, tệp **“Copy of GÓP Ý CÁC VĂN KIỆN.xlsx”** cô đã gửi hiện chưa trích xuất được nội dung các ô dữ liệu. Vì vậy, tôi chưa thể xác định chính xác tên giáo viên và từng ý kiến. Tôi không muốn tự suy đoán rồi tổng hợp sai.

## 📋 Mẫu bảng tổng hợp tôi đề xuất

| STT | Họ tên giáo viên | Văn bản góp ý | Nội dung ý kiến (tóm tắt) | Đề xuất của giáo viên | Nhóm vấn đề |
|--------|--------|--------|--------|--------|--------|
| 1 | Theo bảng gốc | Tên văn bản | Nội dung chính | Kiến nghị cụ thể | Chuyên môn, chế độ... |
| 2 | Theo bảng gốc | Tên văn bản | Nội dung chính | Kiến nghị cụ thể | ... |

Tôi sẽ trình bày thành hai phần:

**Phần I – Tổng hợp theo từng giáo viên:** Mỗi giáo viên có một mục riêng, liệt kê đầy đủ các ý kiến, diễn đạt ngắn gọn, dễ hiểu nhưng không làm thay đổi quan điểm của người góp ý.

**Phần II – Tổng hợp những vấn đề chung:** Nhóm các ý kiến trùng hoặc liên quan đến nhau, xác định số giáo viên cùng góp ý và những nội dung Hiệu trưởng cần ưu tiên giải trình.

**Cô vui lòng xuất riêng bảng Excel “GÓP Ý CÁC VĂN KIỆN” sang PDF rồi gửi lại tại đây.** Không cần gửi lại tám văn bản Word vì tôi đã có nội dung để đối chiếu.

Tôi sẽ ưu tiên làm bản tổng hợp **đúng tên từng giáo viên, đủ ý kiến, rõ trọng tâm, không lẫn phần góp ý với phần giải trình của nhà trường**, để cô có thể sử dụng ngay khi chủ trì Hội nghị viên chức, người lao động.

---

USER

đâu rồi bạn?

---

ASSISTANT

Cô ơi, tôi xin lỗi cô. Phần trước tôi mới đưa ra mẫu tổng hợp, **chưa hoàn thành bảng hệ thống ý kiến của từng giáo viên** như cô yêu cầu.

Tôi đã kiểm tra lại nhưng hiện chưa đọc được dữ liệu trong tệp **“Copy of GÓP Ý CÁC VĂN KIỆN.xlsx”** cô gửi, nên chưa thể xác định chính xác từng giáo viên đã góp ý những gì.

**Cô giúp tôi xuất tệp Excel đó sang PDF hoặc chụp ảnh các trang có ý kiến rồi gửi lại nhé.** Các văn bản quy chế và nghị quyết khác tôi đã có, cô không cần gửi lại.

Tôi sẽ tổng hợp theo bảng sau:

| Giáo viên | Nội dung góp ý | Vấn đề trọng tâm | Kiến nghị cụ thể |
|--------|--------|--------|--------|
| Theo tên trong bảng gốc | Tóm tắt đầy đủ, đúng ý | Phân loại theo văn bản | Nêu rõ mong muốn của giáo viên |

Đồng thời, tôi sẽ **gộp các ý kiến trùng nhau, thống kê số giáo viên cùng quan tâm và đánh dấu những vấn đề Hiệu trưởng cần ưu tiên giải đáp**.

Tôi hiểu cô cần bảng tổng hợp thực tế để chuẩn bị Hội nghị, chứ không phải mẫu chung. Tôi sẽ bám sát đúng ý kiến gốc, không tự thêm nội dung hay suy diễn quan điểm của giáo viên.

---

USER

sao không thấy gì hết vậy?

---

ASSISTANT

Cô ơi, tôi xin lỗi vì đã để cô phải hỏi nhiều lần. Tôi hiểu cô cần **bảng tổng hợp ý kiến thực tế của từng giáo viên**, chứ không phải bảng mẫu hay nội dung giải trình chung.

Tôi đã kiểm tra lại các tệp cô gửi:

- **8 văn bản Word:** Đã đọc được nội dung.
- **File “Copy of GÓP Ý CÁC VĂN KIỆN.xlsx”:** Đã nhận được nhưng hệ thống chưa đọc được dữ liệu trong các ô. Đây chính là file cần thiết để tổng hợp ý kiến theo tên giáo viên.

Vì vậy, tôi chưa thể lập bảng chính xác mà không tự suy đoán.

**Cô vui lòng gửi lại riêng file góp ý dưới dạng PDF hoặc ảnh chụp bảng Excel.** Không cần gửi lại các văn bản khác.

Tôi sẽ trình bày kết quả trực tiếp trong cuộc trò chuyện với đầy đủ:

| Giáo viên | Nội dung góp ý | Tóm tắt trọng tâm | Ý kiến trùng với giáo viên khác |
|--------|--------|--------|--------|
| Tên theo bảng gốc | Giữ đúng nội dung | Diễn đạt ngắn gọn | Xác định các ý kiến tương đồng |

Sau bảng này, tôi sẽ tổng hợp các nhóm vấn đề mà nhiều giáo viên cùng quan tâm để cô dễ chuẩn bị nội dung trả lời tại Hội nghị.

Tôi rất xin lỗi cô vì sự bất tiện này.

---

USER

mình tổng hợp xong nè. Với vai trò hiệu trưởng, các văn bản đã gửi bạn giúp mình giải quyết các vấn đề trên nhé. Lặp luận logic, chặt chẽ, thuyết phục, bám vào các văn bản và phù hợp thực tiễn

---

ASSISTANT

Tôi đã nhận được bản tổng hợp ý kiến của giáo viên. Tôi sẽ lần lượt đối chiếu các vấn đề với quy chế, nghị quyết và báo cáo của trường; phân biệt nội dung cần tiếp thu, nội dung cần giải thích rõ và những đề xuất phải cân nhắc thêm về pháp lý, nhân sự hoặc kinh phí. Tôi cũng sẽ soạn lời giải trình theo giọng Hiệu trưởng để cô có thể sử dụng trong cuộc họp.

---

ASSISTANT

# 📌 BẢN GIẢI TRÌNH, TIẾP THU VÀ ĐỀ XUẤT GIẢI QUYẾT Ý KIẾN CỦA GIÁO VIÊN

Trường Mầm non An Bình – Năm học 2026–2027

Tôi đã đọc bản tổng hợp **“Ý kiến.docx”** và đối chiếu với các dự thảo quy chế, Nghị quyết Hội nghị viên chức, người lao động, hai báo cáo của nhà trường.

Ở góc độ Hiệu trưởng, tôi đề xuất giải quyết các ý kiến theo nguyên tắc: **Lắng nghe thực chất – tiếp thu có chọn lọc – giải trình có căn cứ – phân công trách nhiệm rõ ràng – bảo đảm thực hiện được tại cả ba điểm trường.**

Đặc biệt, cần phân biệt giữa việc giáo viên đề nghị hoàn thiện quy định và việc phản ánh một hành vi đã xảy ra. Với những ý kiến liên quan đến thái độ ứng xử của cán bộ quản lý, chúng ta cần hoàn thiện quy tắc chung, đồng thời không kết luận cá nhân nào có vi phạm khi chưa xác minh.

## 🎯 1. Những vấn đề cần ưu tiên giải quyết

Qua bản tổng hợp, các vấn đề đáng chú ý nhất là:

| Nhóm vấn đề | Nhận định quản lý | Hướng xử lý |
|--------|--------|--------|
| Ứng xử của Phó Hiệu trưởng, phân công nhiệm vụ, thái độ góp ý | Nhiều giáo viên cùng quan tâm | Tiếp thu, cụ thể hóa trách nhiệm và hành vi không được thực hiện |
| KPI, minh chứng, chấm điểm, trừ điểm | Có vướng mắc về cách hiểu và lỗi kỹ thuật thực tế | Chỉnh ngay bảng điểm, hướng dẫn quy trình và quyền giải trình |
| Luân chuyển giáo viên giữa các độ tuổi | Có lợi cho phát triển đội ngũ nhưng cần bảo đảm ổn định lớp | Tiếp thu về nguyên tắc, không bắt buộc đổi tất cả giáo viên hằng năm |
| Thời gian làm việc, trực trưa, nghỉ việc riêng | Liên quan trực tiếp chế độ chính sách | Giải thích theo từng loại chế độ, không tự đặt giới hạn trái quy định |
| Chi tiêu nội bộ, thu nhập tăng thêm, kinh phí vệ sinh | Cần làm rõ đối tượng, nguồn tiền và phương thức chi | Rà soát dự toán, công khai và sửa các điều khoản chưa rõ |
| Hồ sơ chuyên môn, AI, STEAM, hội thi | Cần giảm áp lực hành chính | Tinh giản hồ sơ, đổi mới thực chất, lập lịch dự kiến |
| Dân chủ, thống nhất hoạt động tại ba điểm trường | Phù hợp yêu cầu sau sáp nhập | Tiếp thu và xây dựng cơ chế phối hợp, phản hồi định kỳ |

**Một phát hiện cần sửa ngay:** Trong Phụ lục KPI giáo viên, nội dung góp ý của cô Huỳnh Thị Hồng Hạnh và thầy/cô Bùi Huỳnh Ngọc Tân là có cơ sở. Qua đối chiếu bảng gốc:

| Tiêu chí | Điểm tối đa đang ghi | Mức điểm cao nhất thực tế | Đề xuất sửa |
|--------|--------|--------|--------|
| A1.2 | 7 | 5 | 5 |
| B1.3 | 10 | 4 | 4 |
| B1.4 | 10 | 3 | 3 |

Sau khi sửa, nhóm A1 sẽ đạt đúng 15 điểm (6 + 5 + 4), nhóm B1 đạt đúng 20 điểm (5 + 8 + 4 + 3). Đây là lỗi kỹ thuật được xác định từ tài liệu, nên **tiếp thu và sửa trước khi áp dụng chấm điểm**, không cần chờ đến cuối năm học.  

Dưới đây là nội dung giải trình theo từng nhóm ý kiến, có nêu tên giáo viên, căn cứ văn bản, lập luận của Hiệu trưởng và hướng xử lý cụ thể.

## 📖 2. Một số căn cứ pháp lý quan trọng đã kiểm tra

Để việc trả lời giáo viên không chỉ dựa trên quan điểm quản lý của nhà trường, cần lưu ý:

**Về đánh giá viên chức:** Nghị định số 233/2026/NĐ-CP, có hiệu lực từ ngày 01/7/2026, quy định thang điểm 100 với 30 điểm tiêu chí chung và 70 điểm kết quả nhiệm vụ. Việc theo dõi có thể thực hiện theo tháng hoặc quý; kết quả đánh giá phải phù hợp nhiệm vụ được giao. [Nghị định số 233/2026/NĐ\-CP của Chính phủ: Quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức](<https://chinhphu.vn/?classid=1&docid=218616&orggroupid=2&pageid=27160>); [Nghị định 233/2026/NĐ\-CP đánh giá đơn vị sự nghiệp công lập và viên chức mới nhất](<https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-dinh-233-2026-ND-CP-danh-gia-don-vi-su-nghiep-cong-lap-va-vien-chuc-712593.aspx?anchor=chuong_3>)

**Về thời gian làm việc:** Thông tư số 11/2026/TT-BGDĐT quy định giáo viên mầm non làm việc 40 giờ/tuần, việc bố trí đón trẻ, trả trẻ và trông trẻ buổi trưa phải phù hợp thực trạng đội ngũ, công khai, công bằng. [TOÀN VĂN: Thông tư 11/2026/TT\-BGDĐT quy định chế độ làm việc với giáo viên mầm non](<https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-11-2026-tt-bgddt-quy-dinh-che-do-lam-viec-voi-giao-vien-mam-non-119260305102619461.htm>)

**Về nghỉ hè:** Nghị định số 93/2026/NĐ-CP quy định thời gian nghỉ hè của giáo viên mầm non là **08 tuần, đã bao gồm nghỉ phép hằng năm**, ngoài ra còn có các chế độ nghỉ khác theo pháp luật. Đây là căn cứ rất cụ thể để giải đáp kiến nghị của cô Nguyễn Thị Kim Liên và cô Nguyễn Thị Kim Liệp. [QUY ĐỊNH MỚI: THỜI GIAN NGHỈ HÈ hằng năm của NHÀ GIÁO](<https://xaydungchinhsach.chinhphu.vn/chinh-phu-quy-dinh-thoi-gian-nghi-he-cua-nha-giao-119260404074041813.htm>)

**Về các khoản thu dịch vụ:** Quyết định số 105/2026/QĐ-UBND của tỉnh Đồng Tháp quy định riêng dịch vụ bán trú và dịch vụ phục vụ vệ sinh lớp học. Vì vậy, nội dung 17.000 đồng/trẻ/tháng cần được làm rõ thành khoản dịch vụ cụ thể, không thể chỉ giải thích chung là phụ phí bán trú. [Quyết định 105/2026/QĐ\-UBND khoản thu chi đối với các dịch vụ phục vụ hoạt động giáo dục Đồng Tháp](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Quyet-dinh-105-2026-QD-UBND-khoan-thu-chi-doi-voi-cac-dich-vu-phuc-vu-hoat-dong-giao-duc-Dong-Thap-724669.aspx?tab=3>)

Những căn cứ này giúp Hiệu trưởng khẳng định được nội dung nào thuộc quy định bắt buộc và nội dung nào nhà trường cần tổ chức thực hiện cho phù hợp.

## 📋 3. Dự thảo giải trình chính thức theo từng nhóm ý kiến

Nội dung dưới đây được xây dựng theo hướng Hiệu trưởng có thể sử dụng trực tiếp tại Hội nghị. Tôi đã gộp những ý kiến tương đồng nhưng vẫn ghi tên giáo viên liên quan để thuận tiện đối chiếu.

> **writing · document**
>
> # DỰ THẢO BÁO CÁO
> **Giải trình, tiếp thu ý kiến đóng góp của viên chức, người lao động đối với các văn kiện Hội nghị năm học 2026–2027**
>
> **TRƯỜNG MẦM NON AN BÌNH**
>
> ## I. QUAN ĐIỂM CHUNG
>
> Ban Giám hiệu nhà trường trân trọng ghi nhận các ý kiến đóng góp của đội ngũ viên chức, người lao động đối với các dự thảo quy chế, nghị quyết và báo cáo.
>
> Nhà trường xác định các ý kiến góp ý là cơ sở quan trọng để tiếp tục rà soát, hoàn thiện văn bản, điều chỉnh phương thức quản lý và nâng cao chất lượng hoạt động sau sáp nhập.
>
> Việc xem xét, giải quyết các kiến nghị phải bảo đảm đúng pháp luật, đúng thẩm quyền, khách quan và phù hợp thực tiễn tổ chức hoạt động tại ba điểm trường.
>
> Quan điểm của nhà trường là không tiếp thu một cách hình thức, cũng không giữ nguyên quy định khi đã phát hiện những bất cập có cơ sở. Mỗi nội dung cần được xem xét trên cả ba phương diện: quy định pháp luật, yêu cầu quản lý và quyền lợi chính đáng của viên chức, người lao động.
>
> ## II. NỘI DUNG GIẢI TRÌNH, TIẾP THU
>
> ### 1. Về bổ sung quy tắc ứng xử của Phó Hiệu trưởng
>
> **Giáo viên có ý kiến:** Loan, Phương Thúy, Thái Thảo, Nguyễn Huỳnh Kim Khánh, Trần Thị Huỳnh Như (Lá 8), Cao Thị Ngọc Nga, Trương Thị Kim Trang, Phạm Thị Ngọc Yên, Nguyễn Thị Huỳnh Như (Nhà trẻ 3) và một số ý kiến liên quan đến môi trường ứng xử trong nhà trường.
>
> **Nội dung:** Đề nghị quy định cụ thể việc Phó Hiệu trưởng không quát mắng, xúc phạm, gây áp lực, lợi dụng quyền hạn, giao việc không rõ ràng rồi quy trách nhiệm tùy tiện; có trách nhiệm lắng nghe, hướng dẫn giáo viên và không gây chia rẽ nội bộ.
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất rằng xây dựng môi trường sư phạm văn minh, dân chủ, tôn trọng là trách nhiệm của mọi thành viên, trong đó cán bộ quản lý phải thể hiện tính gương mẫu.
>
> Phó Hiệu trưởng là người giúp Hiệu trưởng quản lý, điều hành các lĩnh vực được phân công. Vì vậy, bên cạnh yêu cầu về năng lực chuyên môn và trách nhiệm công việc, cán bộ quản lý phải có phương pháp giao tiếp phù hợp, biết lắng nghe, hướng dẫn, hỗ trợ và tạo động lực cho giáo viên.
>
> Việc góp ý, kiểm tra hoặc yêu cầu giáo viên khắc phục hạn chế là trách nhiệm quản lý cần thiết. Tuy nhiên, hoạt động này phải nhằm cải thiện chất lượng công việc, không được trở thành hành vi xúc phạm, gây sức ép không chính đáng hoặc quy kết trách nhiệm thiếu căn cứ.
>
> Nhà trường cũng cần phân biệt giữa việc kiểm tra, nhắc nhở đúng chức trách với hành vi thiếu chuẩn mực trong ứng xử. Không thể chỉ dựa vào cảm nhận của một bên để kết luận có vi phạm; khi phát sinh phản ánh cụ thể phải xác minh khách quan, lắng nghe các bên liên quan.
>
> **Đề xuất tiếp thu:**
>
> Bổ sung vào Điều 4 của Quy tắc ứng xử đối với Phó Hiệu trưởng:
>
> - Giao nhiệm vụ đúng chức trách, phù hợp vị trí việc làm, năng lực chuyên môn và điều kiện thực tế; bảo đảm rõ nội dung, thời hạn, trách nhiệm và kết quả cần đạt.
> - Khi hướng dẫn, góp ý, kiểm tra công việc phải có thái độ tôn trọng, khách quan, cụ thể, mang tính xây dựng; tạo điều kiện cho viên chức giải trình và khắc phục hạn chế.
> - Lắng nghe ý kiến, tâm tư, nguyện vọng chính đáng của giáo viên, nhân viên; chủ động phối hợp tháo gỡ khó khăn trong phạm vi trách nhiệm được giao.
> - Không quát mắng, xúc phạm danh dự, nhân phẩm của giáo viên, nhân viên; không lợi dụng chức vụ, quyền hạn để gây áp lực cá nhân, vụ lợi hoặc phân biệt đối xử.
> - Không giao nhiệm vụ thiếu rõ ràng rồi quy kết trách nhiệm tùy tiện; không cố ý gây chia rẽ, mất đoàn kết nội bộ; không có hành vi định kiến, gây bất lợi đối với người góp ý hợp pháp.
> - Chịu trách nhiệm trong việc tiếp nhận, nghiên cứu, triển khai văn bản thuộc lĩnh vực được giao; hướng dẫn thực hiện và kiểm tra, đôn đốc đúng chức trách.
>
> **Kết luận đề xuất: TIẾP THU.** Bổ sung quy định theo hướng áp dụng thống nhất đối với cán bộ quản lý, trong đó có Hiệu trưởng và Phó Hiệu trưởng.
>
> ### 2. Về trách nhiệm triển khai văn bản, giao việc và trao đổi công việc ngoài giờ
>
> **Giáo viên có ý kiến:** Nguyễn Huỳnh Kim Khánh, Cao Thị Ngọc Nga, Trương Thị Kim Trang.
>
> **Giải trình của Hiệu trưởng:**
>
> Ý kiến của giáo viên là có cơ sở thực tiễn. Trong điều kiện trường hoạt động tại ba điểm, thông tin có thể bị chuyển qua nhiều đầu mối. Nếu yêu cầu công việc không rõ ràng, thay đổi nhiều lần hoặc chậm hướng dẫn thì sẽ ảnh hưởng đến tiến độ, chất lượng và tâm lý của người thực hiện.
>
> Theo Quy chế làm việc, Hiệu trưởng chịu trách nhiệm điều hành chung; Phó Hiệu trưởng chịu trách nhiệm lĩnh vực được phân công; tổ trưởng tổ chức triển khai trong phạm vi nhiệm vụ.
>
> Do đó, trách nhiệm phải được xác định tương ứng với thẩm quyền từng cấp, không chuyển toàn bộ trách nhiệm tham mưu, nghiên cứu văn bản quản lý xuống giáo viên.
>
> Tuy nhiên, giáo viên vẫn có trách nhiệm chủ động nghiên cứu nội dung liên quan nhiệm vụ và báo cáo khó khăn phát sinh, không thụ động chờ hướng dẫn đối với những công việc đã được giao rõ ràng.
>
> **Hướng xử lý:**
>
> Thống nhất quy trình giao việc: người giao nhiệm vụ xác định rõ yêu cầu, sản phẩm, thời hạn; người thực hiện xác nhận và trao đổi khi chưa rõ; khi điều chỉnh nhiệm vụ phải thông tin lại yêu cầu mới.
>
> Hạn chế gửi yêu cầu xử lý, đôn đốc ngoài giờ làm việc đối với công việc thông thường. Trường hợp khẩn cấp liên quan an toàn trẻ, phòng chống thiên tai, dịch bệnh hoặc nhiệm vụ cấp bách được xử lý theo chế độ trực và quy định liên quan.
>
> **Kết luận đề xuất: TIẾP THU.** Bổ sung nội dung này vào Quy chế làm việc và Quy tắc ứng xử.
>
> ### 3. Về quyền ghi âm, ghi hình khi cần thiết
>
> **Giáo viên có ý kiến:** Nguyễn Thị Huỳnh Như (Nhà trẻ 3).
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường tôn trọng quyền phản ánh, kiến nghị, khiếu nại, tố cáo hợp pháp của viên chức, người lao động. Việc cung cấp tài liệu, thông tin, chứng cứ hợp pháp để bảo vệ quyền và lợi ích chính đáng cần được bảo đảm.
>
> Tuy nhiên, không nên quy định chung rằng giáo viên được tự do ghi âm, ghi hình trong mọi trường hợp. Hoạt động này có thể liên quan đến quyền riêng tư, dữ liệu cá nhân, hình ảnh trẻ em, thông tin nội bộ và các khu vực cần bảo mật.
>
> Nhà trường không áp dụng quy định cấm tuyệt đối việc thu thập chứng cứ hợp pháp; đồng thời không cho phép lợi dụng việc ghi âm, ghi hình để xâm phạm quyền, lợi ích hợp pháp của người khác.
>
> **Hướng xử lý:** Bổ sung nguyên tắc viên chức được sử dụng tài liệu, chứng cứ thu thập hợp pháp khi phản ánh, kiến nghị đến cơ quan có thẩm quyền; việc ghi âm, ghi hình, lưu giữ và cung cấp thông tin phải tuân thủ pháp luật về quyền riêng tư, bảo vệ dữ liệu và trẻ em.
>
> **Kết luận đề xuất: TIẾP THU MỘT PHẦN**, không quy định quyền ghi âm, ghi hình một cách tuyệt đối.
>
> ### 4. Về quy tắc ứng xử của trẻ và xử lý các vụ việc nghiêm trọng
>
> **Người góp ý:** Bùi Huỳnh Ngọc Tân.
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường đánh giá cao đề xuất phân biệt trách nhiệm thực hiện quy tắc ứng xử của người lớn với việc giáo dục hành vi giao tiếp cho trẻ mầm non.
>
> Đối với trẻ, mục tiêu là hình thành những hành vi tích cực phù hợp độ tuổi, thông qua hướng dẫn, làm mẫu, động viên và giáo dục thường xuyên, không phải áp dụng cơ chế kỷ luật nội bộ như với viên chức.
>
> Vì vậy, có thể điều chỉnh cấu trúc dự thảo theo hướng chuyển các quy định dành cho trẻ thành nội dung giáo viên có trách nhiệm hướng dẫn, giáo dục và hỗ trợ trẻ thực hiện.
>
> Về xử lý vụ việc nghiêm trọng, nhà trường thống nhất rằng phản ánh liên quan đến bạo hành, xâm hại trẻ em hoặc các nguy cơ gây tổn hại nghiêm trọng không được giải quyết khép kín trong nội bộ.
>
> **Hướng xử lý:**
>
> Bổ sung quy trình báo cáo, tiếp nhận và xử lý thông tin theo pháp luật về bảo vệ trẻ em; xác định rõ trách nhiệm thông báo kịp thời cho UBND cấp xã, cơ quan công an, Tổng đài quốc gia bảo vệ trẻ em hoặc cơ quan có thẩm quyền tương ứng với vụ việc.
>
> Không chỉ ghi cố định tên Phòng Giáo dục và Đào tạo cấp huyện khi cơ cấu quản lý giáo dục địa phương đã thay đổi.
>
> **Kết luận đề xuất: TIẾP THU**, đồng thời rà soát tên cơ quan và thẩm quyền tiếp nhận theo mô hình quản lý hiện hành.
>
> ### 5. Về thực hiện KPI theo tháng hay quý
>
> **Giáo viên có ý kiến:** Huỳnh Thị Hồng Hạnh, Châu Thị Bé Quyền, Nguyễn Thị Minh Nguyệt và các giáo viên đề nghị được hướng dẫn cụ thể như Trần Thị Huỳnh Như (Lá 8), Nguyễn Thị Thanh Nhãn, Trương Hồ Xuân Lan.
>
> **Giải trình của Hiệu trưởng:**
>
> Việc thực hiện đánh giá theo kết quả công việc là yêu cầu của Nghị định số 233/2026/NĐ-CP. Mục tiêu nhằm đánh giá thực chất, tạo động lực làm việc và xác định đúng mức độ hoàn thành nhiệm vụ.
>
> Tuy nhiên, nhà trường thống nhất với nhận định rằng việc tổ chức chấm toàn bộ tiêu chí, yêu cầu lập minh chứng đầy đủ mỗi tháng có thể gây áp lực hành chính, nhất là đối với giáo viên trực tiếp chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> Đặc thù hoạt động giáo dục mầm non có những công việc thực hiện thường xuyên, nhưng cũng có nhiệm vụ triển khai theo quý, học kỳ hoặc thời điểm trong năm học.
>
> Vì vậy, nếu yêu cầu mọi giáo viên phải có sáng kiến, sản phẩm công nghệ hoặc minh chứng đổi mới trong từng tháng thì dễ dẫn đến đánh giá hình thức, không phản ánh đúng chất lượng công việc.
>
> **Hướng xử lý:**
>
> Đề xuất tổ chức theo hai cấp độ:
>
> - **Theo dõi hằng tháng:** Ghi nhận việc thực hiện nhiệm vụ, chất lượng chăm sóc trẻ, tiến độ, ưu điểm, hạn chế và các vấn đề cần khắc phục; sử dụng dữ liệu, hồ sơ sẵn có.
> - **Tổng hợp đánh giá theo quý:** Đối chiếu kết quả công việc, tính điểm theo tiêu chí được giao, xem xét yếu tố khách quan, trao đổi với giáo viên và thông báo kết quả.
>
> Đối với nhiệm vụ thực hiện theo học kỳ hoặc cả năm, cần xác định mốc đánh giá phù hợp; không tự động cho điểm thấp chỉ vì nhiệm vụ chưa đến thời điểm thực hiện.
>
> Nếu có yêu cầu báo cáo hoặc đánh giá theo tháng từ cấp có thẩm quyền thì thực hiện đúng yêu cầu, nhưng không tự tạo thêm hồ sơ trùng lặp.
>
> **Kết luận đề xuất: TIẾP THU.** Điều chỉnh hướng dẫn thực hiện KPI theo hướng theo dõi thường xuyên, tổng hợp theo quý và xếp loại chính thức đúng thời điểm pháp luật quy định.
>
> ### 6. Về sai lệch điểm trong Phụ lục KPI
>
> **Giáo viên có ý kiến:** Huỳnh Thị Hồng Hạnh, Bùi Huỳnh Ngọc Tân.
>
> **Giải trình của Hiệu trưởng:**
>
> Qua rà soát, ý kiến phát hiện sai lệch điểm tối đa và điểm thành phần là chính xác.
>
> Cụ thể:
>
> - A1.2 đang ghi 7 điểm, trong khi mức điểm cao nhất là 5 điểm.
> - B1.3 đang ghi 10 điểm, trong khi mức điểm cao nhất là 4 điểm.
> - B1.4 đang ghi 10 điểm, trong khi mức điểm cao nhất là 3 điểm.
>
> Ngoài ra, tại A1.2 cần rà soát cách diễn đạt về số lần vi phạm, tránh trường hợp cùng một mức vi phạm lại thuộc hai khung điểm khác nhau.
>
> Đây là lỗi kỹ thuật của dự thảo, không phải lỗi của người được đánh giá. Nếu chưa điều chỉnh mà áp dụng sẽ ảnh hưởng trực tiếp đến tính chính xác của kết quả.
>
> **Hướng xử lý:** Sửa các cột điểm theo tổng điểm quy định; rà soát toàn bộ phụ lục, bảo đảm tổng điểm các nhóm khớp với thang 100 điểm. Nếu dữ liệu đã được chấm thử, cần tính lại theo bảng thống nhất.
>
> **Kết luận đề xuất: TIẾP THU TOÀN BỘ.** Hoàn thành chỉnh sửa trước khi sử dụng chính thức.
>
> ### 7. Về trừ điểm an toàn trẻ và trách nhiệm của giáo viên chung lớp
>
> **Giáo viên có ý kiến:** Bé Tý (Lá 4), Nguyễn Thị Kim Liên (Chồi 8).
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường khẳng định bảo đảm an toàn thể chất và tinh thần cho trẻ là yêu cầu bắt buộc, không thể xem nhẹ.
>
> Tuy nhiên, việc đánh giá phải dựa trên hành vi cụ thể, trách nhiệm được giao, nguyên nhân và kết quả xác minh; không đồng nhất mọi sai sót với vi phạm nghiêm trọng.
>
> Sai sót thủ tục nhẹ có thể là những thiếu sót hành chính hoặc thực hiện chưa đầy đủ thao tác theo quy trình nhưng chưa tạo ra nguy cơ đáng kể và được khắc phục kịp thời.
>
> Vi phạm nghiêm trọng là hành vi xâm hại, bạo hành trẻ, bỏ mặc trách nhiệm giám sát hoặc vi phạm quy trình gây nguy hiểm nghiêm trọng cho trẻ, được xác định qua kiểm tra, xác minh theo quy định.
>
> Đặc biệt, một hành vi có nguy cơ cao không thể chỉ vì chưa gây hậu quả mà mặc nhiên được coi là sai sót nhẹ.
>
> Đối với lớp có hai hoặc nhiều giáo viên, trách nhiệm phải được xem xét theo nhiệm vụ từng người.
>
> Ví dụ: Một giáo viên được giao điểm danh nhưng không thực hiện, giáo viên còn lại phát hiện, báo cáo và phối hợp khắc phục đúng trách nhiệm thì không thể mặc nhiên trừ điểm cả hai như nhau.
>
> Trường hợp nhiều giáo viên cùng có trách nhiệm giám sát nhưng đều không thực hiện đầy đủ thì xem xét trách nhiệm tương ứng với từng người.
>
> **Hướng xử lý:**
>
> Bổ sung hướng dẫn phân loại mức độ vi phạm, căn cứ xác minh và trách nhiệm cá nhân. Việc xem xét trừ điểm phải có ghi nhận sự việc, xác định trách nhiệm, thông báo lý do và cho người liên quan giải trình.
>
> Không trừ điểm tập thể một cách máy móc; cũng không loại trừ trách nhiệm phối hợp, giám sát chung khi có căn cứ xác định vi phạm.
>
> **Kết luận đề xuất: TIẾP THU.**
>
> ### 8. Về quyền giải trình khi bị trừ điểm KPI
>
> **Giáo viên có ý kiến:** Nguyễn Thị Huỳnh Như (Chồi 3), Châu Thị Bé Quyền, Nguyễn Thị Minh Nguyệt.
>
> **Giải trình của Hiệu trưởng:**
>
> Đánh giá viên chức phải công khai, minh bạch, có căn cứ. Việc quy định thang điểm chỉ phát huy tác dụng khi người được đánh giá hiểu rõ tiêu chí, biết kết quả và được giải thích những nội dung chưa đạt.
>
> Vì vậy, nhà trường không áp dụng hình thức thông báo điểm cuối cùng mà không trao đổi khi viên chức có ý kiến hoặc có căn cứ đề nghị xem xét lại.
>
> Đồng thời, quyền giải trình không có nghĩa là điểm số phải thay đổi theo mong muốn cá nhân; kết quả điều chỉnh phải căn cứ minh chứng và quy định chung.
>
> **Hướng xử lý:**
>
> Thống nhất quy trình: giáo viên tự đánh giá; tổ trưởng đối chiếu; người phụ trách nhận xét, chỉ rõ điểm chưa đạt; giáo viên được cung cấp minh chứng hoặc đề nghị xem xét lại; Hiệu trưởng hoặc người có thẩm quyền xem xét, quyết định và thông báo kết quả.
>
> Nội dung chấm điểm được lưu theo từng cá nhân, bảo vệ thông tin cá nhân và bảo đảm quyền kiểm tra, giám sát theo quy định.
>
> **Kết luận đề xuất: TIẾP THU.**
>
> ### 9. Về giáo viên đạt từ 90 điểm nhưng vượt tỷ lệ xếp loại xuất sắc
>
> **Giáo viên có ý kiến:** Phương Thúy (Lá 7), Nguyễn Thị Mỹ Tiên (Lá 1).
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất rằng đây là vấn đề quan trọng, cần hướng dẫn cụ thể trước khi áp dụng đánh giá cuối năm.
>
> Theo Nghị định số 233/2026/NĐ-CP, đạt từ 90 điểm trở lên là điều kiện về điểm số để xem xét xếp loại hoàn thành xuất sắc nhiệm vụ. Tuy nhiên, kết quả xếp loại còn chịu giới hạn tỷ lệ do pháp luật quy định.
>
> Như vậy, không thể đồng nhất việc đạt 90 điểm với việc đương nhiên được xếp loại xuất sắc.
>
> Trong trường hợp số người đủ điều kiện về điểm vượt số lượng được phép, nhà trường phải xem xét những cá nhân có kết quả nổi trội, sản phẩm và chất lượng công việc thực chất, tiến độ hoàn thành, mức độ đóng góp, hiệu quả cải tiến và các yếu tố đánh giá hợp pháp khác.
>
> Không bình xét theo cảm tính, không chia chỉ tiêu xuất sắc cố định cho các điểm trường cũ và không ưu tiên một cá nhân chỉ vì thâm niên hoặc vị trí công tác nếu không có căn cứ phù hợp.
>
> **Đề xuất quy trình xét chọn:**
>
> 1. Xác định số viên chức đủ điều kiện về điểm và các điều kiện pháp lý khác.
> 2. Phân nhóm viên chức có nhiệm vụ tương đồng.
> 3. Xác định số lượng được xếp loại xuất sắc theo tỷ lệ pháp luật và hướng dẫn của cơ quan có thẩm quyền.
> 4. Đối chiếu kết quả công việc và minh chứng nổi trội; lập hồ sơ đề xuất.
> 5. Thực hiện quy trình đánh giá, quyết định, thông báo và giải trình theo đúng thẩm quyền.
>
> Đối với viên chức đạt từ 90 điểm nhưng không nằm trong tỷ lệ được xếp loại xuất sắc, nhà trường không tự ý hạ điểm để phù hợp chỉ tiêu.
>
> Do quy định về khung điểm của mức hoàn thành tốt nhiệm vụ và giới hạn tỷ lệ xuất sắc cần được áp dụng thống nhất, nhà trường sẽ rà soát hướng dẫn của cơ quan có thẩm quyền để xác định mức xếp loại chính thức trong trường hợp này, không tự đặt ra cách xử lý trái quy định.
>
> **Kết luận đề xuất: TIẾP THU yêu cầu bổ sung quy trình.** Phần xử lý trường hợp vượt tỷ lệ cần được hướng dẫn, làm rõ trước kỳ xếp loại chính thức.
>
> ### 10. Về người lao động hợp đồng và đối tượng được đánh giá
>
> **Người góp ý:** Bùi Huỳnh Ngọc Tân.
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất cần phân biệt viên chức với người lao động theo hợp đồng.
>
> Viên chức được đánh giá, xếp loại chất lượng theo pháp luật về viên chức và Nghị định số 233/2026/NĐ-CP.
>
> Người lao động hợp đồng được đánh giá mức độ hoàn thành công việc trên cơ sở hợp đồng lao động, nhiệm vụ được giao và pháp luật áp dụng cho từng loại hợp đồng.
>
> Không sử dụng danh xưng hoặc kết quả xếp loại chất lượng viên chức để thay thế cơ chế đánh giá của người lao động hợp đồng khi không có căn cứ pháp luật.
>
> **Hướng xử lý:** Giữ nguyên nguyên tắc tại Điều 1 khoản 2, đồng thời bổ sung hướng dẫn riêng nếu cần thiết cho nhóm lao động hợp đồng, nhất là các vị trí bảo vệ, cấp dưỡng và phục vụ.
>
> **Kết luận đề xuất: TIẾP THU nội dung làm rõ.**
>
> ### 11. Về thay đổi giáo viên phụ trách nhóm, lớp hằng năm
>
> **Giáo viên có ý kiến:** Huỳnh Thị Cẩm Sáng, Nguyễn Thị Huỳnh Như (Nhà trẻ 3), Trần Thụy Khương Thùy (Nhà trẻ 3).
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận đề xuất luân chuyển giáo viên nhằm phát triển năng lực chuyên môn toàn diện, tạo cơ hội tiếp cận nhiều độ tuổi, hạn chế tâm lý bằng lòng với kinh nghiệm đã có và khuyến khích đổi mới phương pháp.
>
> Đây là một định hướng phù hợp với công tác phát triển đội ngũ.
>
> Tuy nhiên, việc thay đổi giáo viên đồng loạt vào mỗi năm học chưa chắc là phương án tối ưu đối với tất cả các nhóm, lớp.
>
> Đặc thù giáo dục mầm non đòi hỏi giáo viên am hiểu sự phát triển của trẻ theo độ tuổi, kỹ năng chăm sóc, tổ chức hoạt động và phối hợp với cha mẹ trẻ. Đặc biệt, trẻ nhà trẻ cần sự ổn định trong mối quan hệ chăm sóc và điều kiện sinh hoạt.
>
> Nếu luân chuyển không có kế hoạch hoặc không bảo đảm năng lực, nhân sự thay thế thì có thể ảnh hưởng đến chất lượng chăm sóc, giáo dục trẻ.
>
> Mặt khác, việc giáo viên phụ trách một độ tuổi trong nhiều năm không tự động đồng nghĩa với thiếu sáng tạo hoặc năng lực chuyên môn hạn chế. Chất lượng cần được đánh giá bằng kết quả thực tế.
>
> **Hướng xử lý:**
>
> Nhà trường xây dựng phương án phân công, điều chỉnh giáo viên theo từng năm học và kế hoạch phát triển đội ngũ, trong đó cân nhắc nguyện vọng, năng lực, kinh nghiệm, yêu cầu của từng độ tuổi, số lượng giáo viên và điều kiện các điểm trường.
>
> Ưu tiên tạo cơ hội trải nghiệm các độ tuổi cho giáo viên đủ điều kiện, kết hợp bồi dưỡng, dự giờ, sinh hoạt chuyên môn liên điểm và hỗ trợ khi thay đổi nhiệm vụ.
>
> Không quy định bắt buộc tất cả giáo viên phải chuyển lớp hằng năm.
>
> **Kết luận đề xuất: TIẾP THU MỘT PHẦN.** Tiếp thu định hướng luân phiên, không áp dụng luân chuyển đồng loạt, cứng nhắc.
>
> ### 12. Về hồ sơ chuyên môn, chuyển đổi số, AI và STEAM
>
> **Giáo viên có ý kiến:** Châu Thị Bé Quyền, Nguyễn Thị Minh Nguyệt, Trần Thị Thúy Liễu, Tưởng Thị Liễu.
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất rằng việc quản lý hồ sơ nhằm phục vụ chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ, không phải tăng số lượng giấy tờ để phục vụ kiểm tra.
>
> Quy chế chuyên môn của trường đã nêu ba nhóm hồ sơ giáo viên theo Điều lệ trường mầm non, đồng thời xác định hồ sơ điện tử hợp pháp được sử dụng thay thế hồ sơ giấy tương ứng.
>
> Như vậy, chủ trương tinh giản và sử dụng hồ sơ điện tử đã có cơ sở trong dự thảo. Vấn đề cần tập trung là hướng dẫn thực hiện thống nhất tại ba điểm trường.
>
> Đối với ứng dụng CNTT, AI và STEAM, đây là định hướng khuyến khích đổi mới, không phải yêu cầu mọi hoạt động giáo dục đều phải sử dụng công nghệ.
>
> Hoạt động giáo dục mầm non cần ưu tiên trải nghiệm trực tiếp, tương tác, vui chơi và sự tham gia tích cực của trẻ. Việc ứng dụng công nghệ chỉ có ý nghĩa khi hỗ trợ hiệu quả việc tổ chức hoạt động, không thay thế trải nghiệm thực tế hoặc gây áp lực tạo sản phẩm.
>
> **Hướng xử lý:**
>
> Ban hành danh mục hồ sơ và biểu mẫu thống nhất; không yêu cầu nộp đồng thời hai bản giấy, điện tử có nội dung trùng lặp khi hồ sơ điện tử đáp ứng điều kiện pháp lý.
>
> Rà soát tiêu chí KPI có nội dung ứng dụng AI, STEAM theo hướng khuyến khích kết quả đổi mới phù hợp; không bắt buộc mỗi tháng phải có sản phẩm công nghệ mới.
>
> Tổ chức bồi dưỡng, chia sẻ học liệu, hỗ trợ thiết bị trong khả năng nhà trường; bảo đảm bảo mật dữ liệu, hình ảnh trẻ.
>
> **Kết luận đề xuất: TIẾP THU.**
>
> ### 13. Về thời gian dự kiến tổ chức các hội thi của trẻ
>
> **Giáo viên có ý kiến:** Nguyễn Thị Thanh Thúy (Lá 1).
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất việc công bố sớm lịch dự kiến các hội thi, ngày hội, hoạt động trải nghiệm sẽ giúp giáo viên chủ động xây dựng kế hoạch, chuẩn bị học liệu và phối hợp với cha mẹ trẻ.
>
> Tuy nhiên, các hoạt động này còn phụ thuộc nhiệm vụ năm học, kế hoạch chuyên môn, chỉ đạo cấp trên và điều kiện thực tế.
>
> Vì vậy, không nên quy định cứng mọi mốc tổ chức trong Quy chế chuyên môn nếu thời gian có thể thay đổi.
>
> **Hướng xử lý:** Ban hành phụ lục lịch hoạt động chuyên môn, hội thi, ngày hội và trải nghiệm dự kiến theo tháng hoặc học kỳ; thông báo điều chỉnh kịp thời khi có thay đổi.
>
> **Kết luận đề xuất: TIẾP THU**, đưa vào kế hoạch năm học và phụ lục thực hiện chuyên môn.
>
> ### 14. Về thời gian làm việc, trực trưa và chế độ nghỉ của giáo viên
>
> **Giáo viên có ý kiến:** Nguyễn Thị Minh Nguyệt (Chồi 2), Nguyễn Thị Kim Liên (Chồi 8), Nguyễn Thị Kim Liệp (Mầm 3).
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất cần cụ thể hóa chế độ làm việc, nghỉ ngơi để giáo viên hiểu và thực hiện đúng.
>
> Theo Thông tư số 11/2026/TT-BGDĐT, thời gian làm việc của giáo viên mầm non phải bảo đảm 40 giờ/tuần, bao gồm định mức giờ dạy và các nhiệm vụ được giao theo quy định.
>
> Việc phân công đón, trả trẻ, trực trưa phải bảo đảm an toàn và phù hợp số lượng giáo viên, tình hình thực tế từng lớp.
>
> Nhà trường không mặc nhiên coi thời gian trông trẻ buổi trưa là thời gian nghỉ và không yêu cầu giáo viên làm thêm giờ mà không xem xét chế độ tương ứng.
>
> Về nghỉ hè, theo Nghị định số 93/2026/NĐ-CP, giáo viên mầm non được nghỉ hè 08 tuần, bao gồm cả nghỉ phép hằng năm. Do đó, không hiểu rằng ngoài 08 tuần nghỉ hè giáo viên đương nhiên còn một số ngày phép năm riêng biệt khác.
>
> Đối với nghỉ việc riêng, Điều 115 Bộ luật Lao động năm 2019 quy định một số trường hợp cụ thể:
>
> - Bản thân kết hôn: nghỉ 03 ngày, hưởng nguyên lương.
> - Con đẻ hoặc con nuôi kết hôn: nghỉ 01 ngày, hưởng nguyên lương.
> - Cha, mẹ; cha mẹ của vợ hoặc chồng; vợ hoặc chồng; con đẻ, con nuôi chết: nghỉ 03 ngày, hưởng nguyên lương.
> - Một số trường hợp liên quan đến ông, bà, anh chị em ruột chết hoặc kết hôn được nghỉ không hưởng lương theo quy định.
> - Những trường hợp khác được xem xét nghỉ không hưởng lương trên cơ sở thỏa thuận và quy định áp dụng.
>
> Vì nghỉ việc riêng được xác định theo từng sự kiện, không thể quy định đơn giản rằng mỗi giáo viên chỉ được nghỉ việc riêng tối đa một số ngày cố định trong năm học.
>
> **Hướng xử lý:** Bổ sung phụ lục hướng dẫn chế độ nghỉ, hồ sơ đề nghị và thẩm quyền giải quyết; phân biệt nghỉ hè, nghỉ lễ, nghỉ việc riêng, nghỉ ốm, thai sản và nghỉ không hưởng lương.
>
> Hiệu trưởng chịu trách nhiệm bố trí người thay thế; giáo viên nghỉ hợp pháp không phải tự thuê hoặc tự trả tiền cho người dạy thay.
>
> **Kết luận đề xuất: TIẾP THU.**
>
> ### 15. Về sai sót khi nộp báo cáo, kế hoạch
>
> **Giáo viên có ý kiến:** Nguyễn Thị Nhàn (Mầm 4).
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất rằng kiểm tra, đánh giá công việc không nhằm tìm lỗi để trừ điểm, mà nhằm bảo đảm chất lượng, tiến độ và giúp giáo viên khắc phục hạn chế.
>
> Trong quá trình xây dựng kế hoạch, báo cáo, việc phát sinh sai sót kỹ thuật hoặc thiếu thông tin là tình huống có thể xảy ra.
>
> Nếu sai sót không cố ý, chưa gây hậu quả nghiêm trọng và giáo viên chủ động khắc phục đúng thời hạn thì cần được xem xét phù hợp với mức độ thực tế.
>
> Tuy nhiên, đối với trường hợp thường xuyên nộp chậm, lặp lại sai sót đã được hướng dẫn hoặc cung cấp thông tin thiếu trung thực thì phải đánh giá trách nhiệm theo quy định.
>
> **Hướng xử lý:** Cho phép giáo viên chỉnh sửa, bổ sung hồ sơ khi phát hiện sai sót; người kiểm tra thông báo nội dung cần sửa và thời hạn hoàn thành. Việc chấm điểm căn cứ mức độ, nguyên nhân, tiến độ khắc phục và ảnh hưởng thực tế, không mặc nhiên xếp không hoàn thành nhiệm vụ chỉ vì một lỗi kỹ thuật.
>
> **Kết luận đề xuất: TIẾP THU.**
>
> ### 16. Về khoản kinh phí 17.000 đồng/trẻ/tháng phục vụ vệ sinh lớp học
>
> **Giáo viên có ý kiến:** Trần Thị Huỳnh Như (Lá 8).
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận đây là câu hỏi cụ thể, có liên quan trực tiếp đến tính minh bạch trong quản lý các khoản thu dịch vụ.
>
> Theo dự thảo Quy chế chi tiêu nội bộ, khoản phục vụ công tác vệ sinh lớp học được xác định 17.000 đồng/tháng/học sinh.
>
> Tuy nhiên, dự thảo chưa làm rõ đầy đủ công việc được chi từ nguồn này, đối tượng trực tiếp thực hiện, cách tổ chức dịch vụ và phương thức thanh toán.
>
> Theo Quyết định số 105/2026/QĐ-UBND của tỉnh Đồng Tháp, dịch vụ phục vụ công tác vệ sinh lớp học được quy định riêng với hoạt động bán trú.
>
> Vì vậy, cần phân biệt rõ chi phí vệ sinh lớp học với chi phí vệ sinh đồ dùng, chế biến thức ăn và những khoản phụ phí phục vụ bán trú.
>
> Nhà trường không thể chỉ dựa vào việc có quy định mức thu để mặc nhiên thu, trong khi chưa xác định rõ dịch vụ thực tế cung cấp.
>
> **Hướng xử lý:**
>
> Giao kế toán và bộ phận phụ trách bán trú, cơ sở vật chất rà soát:
>
> - Công việc vệ sinh nào thuộc dịch vụ được thu.
> - Công việc nào thuộc nhiệm vụ thường xuyên của giáo viên hoặc nhân viên theo phân công.
> - Cá nhân hoặc bộ phận thực hiện công việc vệ sinh dịch vụ.
> - Dự toán thu, chi, mức thu phù hợp địa bàn và chứng từ thanh toán.
> - Việc công khai, thỏa thuận và tổ chức dịch vụ đối với cha mẹ trẻ.
>
> Nếu nhà trường bố trí nhân sự thực hiện dịch vụ thì phải xác định rõ công việc, khối lượng và phương thức thanh toán hợp pháp.
>
> Nếu chưa tổ chức cung cấp được dịch vụ tương ứng thì chưa đủ cơ sở để thu khoản tiền này chỉ vì dự thảo có ghi mức thu.
>
> **Kết luận đề xuất: TIẾP THU YÊU CẦU GIẢI TRÌNH.** Chưa kết luận đối tượng nhận kinh phí cụ thể khi chưa đối chiếu phương án cung cấp dịch vụ và chứng từ tài chính.
>
> ### 17. Về đối tượng hưởng chế độ và tạm chi thu nhập tăng thêm hằng quý
>
> **Giáo viên có ý kiến:** Huỳnh Thị Hồng Hạnh, Nguyễn Thị Thanh Thúy, Nguyễn Thị Minh Nguyệt, Tưởng Thị Liễu và những ý kiến quan tâm đến công khai tài chính, chế độ chính sách.
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường chia sẻ nguyện vọng của giáo viên về việc xác định rõ quyền lợi, đối tượng được hưởng và tiêu chí chi trả thu nhập tăng thêm.
>
> Tuy nhiên, khoản thu nhập tăng thêm không phải là khoản tiền mặc nhiên được chi theo quý. Việc chi phụ thuộc cơ chế tự chủ tài chính, nguồn kinh phí hợp pháp, khả năng tiết kiệm và điều kiện theo quy định.
>
> Điều 28 của dự thảo đã đề cập đối tượng hưởng và hệ số phân phối theo xếp loại, nhưng Điều 29 cần cụ thể hóa thêm mối quan hệ giữa kết quả đánh giá theo quý và việc quyết định tạm chi.
>
> Đối với đơn vị sau sáp nhập, càng cần thận trọng khi xác định nguồn kinh phí tiết kiệm, vì dự toán được điều chỉnh trong năm và các nghĩa vụ tài chính cần được đối soát.
>
> **Hướng xử lý:**
>
> Bổ sung quy trình trước khi tạm chi:
>
> 1. Kế toán tổng hợp dự toán, tình hình thực hiện thu, chi và khả năng kinh phí tiết kiệm.
> 2. Xác định điều kiện tạm chi, mức tạm chi và đối tượng được hưởng theo chế độ áp dụng.
> 3. Sử dụng kết quả đánh giá công việc theo quý làm một trong các căn cứ phân phối phù hợp quy chế.
> 4. Công khai nguyên tắc, phương pháp xác định số tiền và quyết định tạm chi.
> 5. Cuối năm thực hiện đối chiếu, quyết toán và xử lý chênh lệch theo quy định.
>
> Cần quy định rõ trường hợp viên chức nghỉ chế độ hợp pháp, chuyển công tác, nghỉ hưu, lao động hợp đồng và những trường hợp có thời gian công tác thực tế khác nhau; tránh dùng cách diễn đạt chung khiến người lao động hiểu không thống nhất.
>
> Nhà trường chỉ quyết định tạm chi khi đủ điều kiện về nguồn và thẩm quyền; không cam kết một mức chi cố định khi chưa xác định được kinh phí.
>
> **Kết luận đề xuất: TIẾP THU.** Giao kế toán rà soát Điều 28, Điều 29 và đề xuất phương án chi có căn cứ, bảo đảm công khai trước khi thực hiện.
>
> ### 18. Về sửa lỗi chính tả, căn cứ pháp lý và thống nhất văn bản
>
> **Giáo viên có ý kiến:** Huỳnh Thị Hồng Hạnh, Phương Thúy, Bùi Huỳnh Ngọc Tân.
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường đánh giá cao sự cẩn trọng của giáo viên trong nghiên cứu văn bản và phát hiện lỗi kỹ thuật.
>
> Các ý kiến sửa lỗi chính tả, từ ngữ, số liệu và căn cứ pháp lý là cần thiết. Văn bản quản lý phải được kiểm tra kỹ trước khi ban hành hoặc thực hiện thủ tục chỉnh sửa phù hợp đối với văn bản đã có hiệu lực.
>
> **Hướng xử lý:**
>
> - Sửa các lỗi từ ngữ trong Quy chế chuyên môn đã được giáo viên chỉ rõ.
> - Sửa mốc năm 2055 trong căn cứ Luật Ngân sách nhà nước thành năm 2026, đồng thời kiểm tra ngày ban hành và ngày hiệu lực của luật.
> - Thống nhất tên Trường Mầm non An Bình, ký hiệu quyết định và thông tin tổ chức sau sáp nhập.
> - Rà soát phần căn cứ ban hành Quy tắc ứng xử, bổ sung đầy đủ thông tin Luật Nhà giáo.
> - Sử dụng thống nhất cụm từ “hằng tháng” khi chỉ công việc lặp lại định kỳ.
> - Kiểm tra tính đồng bộ về thời điểm, phạm vi và hiệu lực giữa các quy chế và nghị quyết.
>
> **Kết luận đề xuất: TIẾP THU TOÀN BỘ các lỗi đã được xác định.**
>
> ### 19. Về thực hiện dân chủ, đoàn kết và thống nhất hoạt động tại ba điểm trường
>
> **Giáo viên có ý kiến:** Nguyễn Thị Minh Nguyệt, Tưởng Thị Liễu, Trần Thị Thúy Liễu cùng các ý kiến thống nhất và đề nghị tiếp tục phát huy dân chủ.
>
> **Giải trình của Hiệu trưởng:**
>
> Nhà trường xác định thực hiện dân chủ không chỉ là tổ chức lấy ý kiến trước khi ban hành quy chế mà còn là quá trình công khai, tiếp nhận, xem xét, phản hồi và chịu trách nhiệm giải trình trong suốt quá trình hoạt động.
>
> Sau sáp nhập, điều quan trọng là bảo đảm giáo viên ở cả ba điểm trường được tiếp cận thông tin, thực hiện quyền góp ý và được xem xét kiến nghị một cách bình đẳng.
>
> Sự thống nhất quản lý phải gắn với điều kiện thực tế từng điểm trường. Không giao chỉ tiêu hoặc áp dụng yêu cầu thiếu căn cứ, không phù hợp điều kiện thực hiện.
>
> Bên cạnh trách nhiệm quản lý, mỗi viên chức cũng có trách nhiệm giữ gìn đoàn kết, góp ý xây dựng, phản ánh trung thực và thực hiện nhiệm vụ đã được phân công hợp pháp.
>
> **Hướng xử lý:** Thực hiện thống nhất quy trình tiếp nhận ý kiến, giao nhiệm vụ, công khai tài chính, đánh giá và kiểm tra. Định kỳ tổng hợp khó khăn của từng điểm trường; nêu rõ người tiếp nhận, trách nhiệm giải quyết và kết quả phản hồi.
>
> Đối với các ý kiến thống nhất dự thảo của Lê Thị Tường Nhi, Nguyễn Thị Thanh Nhãn và các giáo viên khác, nhà trường ghi nhận sự đồng thuận, đồng thời tiếp tục hỗ trợ đội ngũ hiểu rõ quy định để thực hiện hiệu quả.
>
> **Kết luận đề xuất: TIẾP THU.**
>
> ## III. TRÁCH NHIỆM TỔ CHỨC THỰC HIỆN
>
> **Hiệu trưởng:** Chỉ đạo rà soát toàn bộ nội dung giải trình; quyết định tiếp thu, chỉnh sửa, ban hành văn bản theo thẩm quyền; chịu trách nhiệm công khai và giải quyết kiến nghị.
>
> **Các Phó Hiệu trưởng:** Rà soát nội dung chuyên môn, phân công nhiệm vụ, quy trình kiểm tra, tiêu chí KPI và trách nhiệm phối hợp tại các điểm trường.
>
> **Kế toán:** Tham mưu sửa đổi Quy chế chi tiêu nội bộ, làm rõ nguồn thu dịch vụ, đối tượng hưởng, điều kiện tạm chi, dự toán và phương thức thanh toán.
>
> **Tổ chuyên môn, tổ văn phòng:** Tổ chức trao đổi, hướng dẫn thực hiện; tổng hợp các khó khăn và phát hiện những nội dung chưa thống nhất sau khi áp dụng.
>
> **Bộ phận văn thư:** Kiểm tra thể thức, tên đơn vị, căn cứ, số hiệu, ngày tháng và tính đồng bộ giữa các văn bản.
>
> **Viên chức, người lao động:** Tiếp tục góp ý xây dựng, thực hiện đúng quy định đã ban hành hợp pháp và phản ánh kịp thời những khó khăn hoặc bất cập trong quá trình thực hiện.
>
> ## IV. KẾT LUẬN CỦA HIỆU TRƯỞNG
>
> Ban Giám hiệu trân trọng cảm ơn các ý kiến đóng góp của viên chức, người lao động. Đây là những ý kiến có giá trị thực tiễn, phản ánh sự quan tâm và trách nhiệm của đội ngũ đối với hoạt động chung của nhà trường.
>
> Qua nghiên cứu, nhà trường xác định nhiều nội dung có cơ sở để tiếp thu, đặc biệt là yêu cầu về chuẩn mực ứng xử của cán bộ quản lý, trách nhiệm giao việc, tính chính xác của bảng điểm KPI, quyền giải trình của giáo viên, việc giảm tải hồ sơ và công khai tài chính.
>
> Đối với những kiến nghị cần cân nhắc thêm như luân chuyển giáo viên hằng năm, lựa chọn người hoàn thành xuất sắc nhiệm vụ khi vượt tỷ lệ, phương án chi trả thu nhập tăng thêm hoặc sử dụng kinh phí vệ sinh lớp học, nhà trường sẽ tiếp tục đối chiếu quy định, điều kiện thực tế và thẩm quyền để quyết định phù hợp.
>
> Nhà trường khẳng định: **Dân chủ phải đi đôi với trách nhiệm; quản lý phải đi đôi với hỗ trợ; đánh giá phải dựa trên kết quả thực chất; quyền lợi chính đáng của viên chức, người lao động phải được tôn trọng và bảo đảm theo pháp luật.**
>
> Mục tiêu cuối cùng không phải chỉ hoàn thiện hệ thống văn bản, mà là xây dựng Trường Mầm non An Bình thành một tập thể thống nhất, đoàn kết, có kỷ cương, có trách nhiệm và có môi trường làm việc tích cực, tạo điều kiện để mỗi giáo viên phát huy năng lực, yên tâm công tác và nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ.
>
> **HIỆU TRƯỞNG**
>
> *(Dự thảo đề xuất tiếp thu, giải trình; các nội dung tài chính và thẩm quyền cần hoàn tất đối chiếu trước khi phê duyệt chính thức.)*

## 💡 4. Khuyến nghị quản lý trước khi tổ chức giải đáp

Có ba nội dung tôi đề nghị cô đặc biệt quan tâm khi kết luận Hội nghị.

**Thứ nhất, đối với ý kiến về Phó Hiệu trưởng:** Nên tiếp thu ngay yêu cầu hoàn thiện chuẩn mực ứng xử. Tuy nhiên, nếu có phản ánh liên quan đến cá nhân cụ thể, nên tiếp nhận và xác minh riêng theo quy trình, không biến phần thảo luận quy chế thành cuộc kết luận đúng sai đối với người chưa được giải trình. Điều này vừa bảo vệ giáo viên, vừa bảo đảm sự công bằng cho cán bộ quản lý.

**Thứ hai, đối với KPI:** Cần sửa lỗi bảng điểm trước khi đánh giá chính thức và tập huấn bằng ví dụ thực tế. Đặc biệt, vấn đề người đạt từ 90 điểm nhưng vượt tỷ lệ hoàn thành xuất sắc nhiệm vụ chưa có hướng dẫn xử lý cụ thể trong bộ hồ sơ của trường. Tôi khuyến nghị xin ý kiến bằng văn bản của cơ quan quản lý trước khi chốt quy trình, không tự ý hạ điểm hoặc xếp loại trái khung quy định. [Các mức xếp loại chất lượng viên chức](<https://xaydungchinhsach.chinhphu.vn/cac-muc-xep-loai-chat-luong-vien-chuc-119260701155446369.htm>)

**Thứ ba, đối với tài chính:** Không nên trả lời ngay rằng khoản 17.000 đồng sẽ trả cho giáo viên hay nhân viên nào nếu chưa xác định phương án tổ chức vệ sinh. Cũng không nên cam kết tạm chi thu nhập tăng thêm theo quý khi chưa xác nhận nguồn kinh phí. Theo Quyết định 105/2026/QĐ-UBND, khoản thu dịch vụ phải có dự toán trước khi thu, được quy định cụ thể trong quy chế chi tiêu nội bộ và công khai đúng mục đích. [Quyết định 105/2026/QĐ\-UBND khoản thu chi đối với các dịch vụ phục vụ hoạt động giáo dục Đồng Tháp](<https://thuvienphapluat.vn/van-ban/Tai-chinh-nha-nuoc/Quyet-dinh-105-2026-QD-UBND-khoan-thu-chi-doi-voi-cac-dich-vu-phuc-vu-hoat-dong-giao-duc-Dong-Thap-724669.aspx?tab=3>)

Về những ý kiến liên quan Quy tắc ứng xử, tôi đã căn cứ bản tổng hợp góp ý và các quy chế quản lý đã gửi. **Bản dự thảo Quy tắc ứng xử riêng chưa có trong các tệp tôi đọc được**, nên phần đề xuất sửa Điều 4 và Điều 20 cần được đối chiếu nguyên văn trước khi đưa vào quyết định sửa đổi.

## ✅ 5. Các việc nên thực hiện ngay

| Mức ưu tiên | Công việc | Bộ phận tham mưu |
|--------|--------|--------|
| 1 | Sửa lỗi điểm KPI A1.2, B1.3, B1.4; rà soát các thang điểm còn lại | Phó Hiệu trưởng phụ trách, tổ chuyên môn |
| 1 | Làm rõ quy trình trừ điểm, giải trình, xác định trách nhiệm cá nhân | Ban Giám hiệu |
| 1 | Rà soát khoản thu vệ sinh 17.000 đồng, đối tượng hưởng và Điều 29 tạm chi | Kế toán |
| 2 | Bổ sung chuẩn mực ứng xử Phó Hiệu trưởng, trách nhiệm giao việc | Ban Giám hiệu, tổ văn phòng |
| 2 | Hướng dẫn nghỉ hè, nghỉ việc riêng, trực trưa, làm thêm giờ | Bộ phận phụ trách nhân sự |
| 2 | Tập huấn KPI, thống nhất biểu mẫu và hồ sơ điện tử | Phó Hiệu trưởng, tổ chuyên môn |
| 3 | Xây dựng kế hoạch luân phiên giáo viên, lịch hội thi dự kiến | Ban Giám hiệu |
| 3 | Hoàn thiện bảng tổng hợp tiếp thu, giải trình và thông báo kết quả cho giáo viên | Bộ phận tổng hợp, văn thư |

**Kết luận:** Với tình hình Trường Mầm non An Bình sau sáp nhập, tôi cho rằng phương án tốt nhất không phải là cố gắng bảo vệ nguyên trạng tất cả các dự thảo, mà là mạnh dạn tiếp thu những bất cập đã được chỉ rõ, giải thích dứt khoát những nội dung thuộc quy định bắt buộc và chỉ quyết định những vấn đề liên quan tiền, nhân sự, chế độ khi có đủ căn cứ.

Đó là cách để Hiệu trưởng giữ được kỷ cương quản lý nhưng vẫn tạo sự đồng thuận và niềm tin trong đội ngũ.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

USER

các giáo viên góp ý đều cùng ở 1 điểm trường cho PHT. Hiệu trưởng nhắn tin nhắc nhở, bạn trả lời thế  nào với HT cho thấu tình đạt lý.  không hạ thấp mình mà vẫn hài hòa

---

ASSISTANT

Trong tình huống này, tôi nghĩ cô nên trả lời Hiệu trưởng với thái độ **cầu thị nhưng có chính kiến, tôn trọng ý kiến giáo viên nhưng không mặc nhiên nhận mình có khuyết điểm khi chưa có sự việc cụ thể được làm rõ**.

Đặc biệt, nhiều giáo viên cùng một điểm trường góp ý về cách ứng xử của Phó Hiệu trưởng là điều cần quan tâm, nhưng cũng cần phân biệt giữa góp ý bổ sung quy tắc chung và phản ánh hành vi thực tế của một cá nhân.

Tôi đề xuất cô nhắn như sau:

> **writing · chat_message**
>
> Dạ cô, em đã đọc và ghi nhận những ý kiến đóng góp của giáo viên. Em nghĩ mỗi ý kiến đều đáng được lắng nghe, nhất là những nội dung liên quan đến cách giao việc, trao đổi và ứng xử của cán bộ quản lý.
>
> Với vai trò của mình, em luôn ý thức trách nhiệm trong công việc và cố gắng thực hiện đúng chức trách, vì nhiệm vụ chung của nhà trường. Tuy nhiên, trong quá trình quản lý, có thể cách trao đổi hoặc triển khai công việc đôi lúc chưa tạo được sự đồng thuận như mong muốn. Đây cũng là dịp để em nhìn lại và điều chỉnh cách phối hợp cho phù hợp hơn.
>
> Em cũng mong các ý kiến được nhìn nhận khách quan, trên cơ sở những sự việc cụ thể, để phân biệt giữa góp ý hoàn thiện quy định chung và những vấn đề thực tế cần làm rõ. Nếu có nội dung nào liên quan trực tiếp đến em, em rất sẵn lòng trao đổi, lắng nghe và giải trình để cô có đầy đủ thông tin trước khi đánh giá.
>
> Em trân trọng sự nhắc nhở của cô. Em sẽ tiếp tục cố gắng trong cách quản lý, giao tiếp và phối hợp với giáo viên, vừa giữ được nguyên tắc, trách nhiệm trong công việc, vừa tạo sự gần gũi và đồng thuận trong tập thể. Điều em mong muốn nhất vẫn là sự đoàn kết trong Ban Giám hiệu và đội ngũ để cùng thực hiện tốt nhiệm vụ của nhà trường ạ.

### 💡 Vì sao cách trả lời này phù hợp?

- **Không hạ thấp bản thân:** Cô không nhận mình đã quát mắng, gây áp lực hay đối xử thiếu công bằng khi chưa có sự việc được xác minh.
- **Không đối đầu với Hiệu trưởng:** Cô thể hiện sự tôn trọng và ghi nhận lời nhắc nhở.
- **Không quy chụp giáo viên:** Dù nhiều ý kiến xuất phát từ cùng một điểm trường, cô không suy diễn rằng giáo viên có sự liên kết để phản ánh mình.
- **Giữ được vị thế quản lý:** Cô khẳng định trách nhiệm thực hiện nhiệm vụ, đồng thời sẵn sàng giải trình khách quan.
- **Mở hướng giải quyết:** Cô đề nghị trao đổi những sự việc cụ thể thay vì để nhận xét chung kéo dài và ảnh hưởng mối quan hệ.

**Có một điều tôi đặc biệt muốn lưu ý:** Trong bản tổng hợp góp ý, nhiều giáo viên đề nghị bổ sung những hành vi Phó Hiệu trưởng không được thực hiện. Đây là đề xuất hoàn thiện Quy tắc ứng xử, **chưa đủ để kết luận Phó Hiệu trưởng đã thực hiện những hành vi đó**. Cô hoàn toàn có thể giữ vững quan điểm này một cách bình tĩnh, không cần phản ứng gay gắt.

### Tôi muốn hỏi cô một điều

**Hiệu trưởng đã nhắn nguyên văn như thế nào khi nhắc nhở cô?**

Nếu cô gửi lại đúng nội dung tin nhắn của Hiệu trưởng, tôi sẽ giúp cô viết câu trả lời sát tình huống hơn, vừa thể hiện bản lĩnh của một Phó Hiệu trưởng, vừa tinh tế để Hiệu trưởng hiểu và tôn trọng cô, không tạo cảm giác cô đang chống chế hay nhận lỗi về mình.

---

USER

bạn lọc ra câu trả lời cụ thể cho từng trường hợp góp ý về quy chế chuyên môn và quy chế đánh giá viên chức. Cách xử lý logic, thuyết phục, phù hợp thực tế

---

ASSISTANT

Tôi sẽ tách riêng đúng hai nhóm: **Quy chế chuyên môn** và **Quy chế đánh giá, xếp loại viên chức**. Với mỗi giáo viên, tôi sẽ nêu nội dung góp ý, câu trả lời của Hiệu trưởng và cách xử lý cụ thể; những ý kiến trùng nhau sẽ được thống nhất về nguyên tắc nhưng vẫn trả lời đúng trọng tâm từng người.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

# GIẢI TRÌNH CỤ THỂ Ý KIẾN GIÁO VIÊN VỀ HAI QUY CHẾ

**Trường Mầm non An Bình – Năm học 2026–2027**

Tôi đã lọc các ý kiến trong tài liệu *“Ý kiến.docx”*, chỉ giữ những nội dung liên quan trực tiếp đến hai quy chế cô yêu cầu.

Mỗi trường hợp được trình bày theo ba phần: **nội dung giáo viên đề xuất – câu trả lời của Hiệu trưởng – hướng xử lý cụ thể**. Các câu trả lời được viết theo tinh thần cầu thị, có lập luận và giữ được vai trò, trách nhiệm của người quản lý.

## I. GIẢI TRÌNH Ý KIẾN VỀ QUY CHẾ CHUYÊN MÔN

Căn cứ chính là Quy chế chuyên môn năm học 2026–2027 của trường, ban hành kèm Quyết định số 78/QĐ-MNAB ngày 09/10/2026; Điều 21 Điều lệ trường mầm non về hồ sơ; Kế hoạch giáo dục và Nghị quyết Hội nghị viên chức, người lao động năm học 2026–2027.  [Thông tư số 52/2020/TT\-BGDĐT của Bộ Giáo dục và Đào tạo: Ban hành Điều lệ Trường mầm non](<https://vanban.chinhphu.vn/default.aspx?docid=203047&pageid=27160>)

> **writing · document**
>
> # PHẦN I. GIẢI TRÌNH QUY CHẾ CHUYÊN MÔN
>
> ### 1. Giáo viên Huỳnh Thị Hồng Hạnh – Lá 3
>
> **Nội dung góp ý:** Đề nghị sửa các lỗi chính tả và diễn đạt tại trang 3, 8, 9, 10 của Quy chế chuyên môn.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận và thống nhất với các nội dung góp ý. Việc phát hiện, chỉnh sửa lỗi kỹ thuật trong văn bản là cần thiết nhằm bảo đảm tính chính xác, thống nhất và thuận tiện khi triển khai thực hiện.
>
> Mặc dù những lỗi này không làm thay đổi bản chất yêu cầu chuyên môn, nhà trường vẫn cần chỉnh sửa để văn bản được ban hành và sử dụng với chất lượng tốt nhất.
>
> **Hướng xử lý: TIẾP THU TOÀN BỘ.**
>
> Giao bộ phận chuyên môn phối hợp văn thư sửa:
>
> - “Từ năm năm học” thành “từ năm học”.
> - “Nhiểu năm” thành “nhiều năm”.
> - “Chuyển đối số” thành “chuyển đổi số”.
> - “Giáo dục vủa nhóm trẻ” thành “giáo dục của nhóm trẻ”.
> - “Số theo dõi trẻ em” thành “Sổ theo dõi trẻ em”.
>
> Đồng thời rà soát toàn bộ văn bản và thực hiện đính chính hoặc sửa đổi theo đúng thủ tục đối với văn bản đã ban hành.
>
> ### 2. Giáo viên Huỳnh Thị Cẩm Sáng
>
> **Nội dung góp ý:** Đề nghị thay đổi giáo viên phụ trách nhóm, lớp qua từng năm học nhằm tránh lối mòn kinh nghiệm và phát triển năng lực chuyên môn ở nhiều độ tuổi.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận đề xuất vì có ý nghĩa đối với công tác phát triển đội ngũ. Việc tạo điều kiện cho giáo viên tiếp cận nhiều độ tuổi có thể giúp mở rộng kinh nghiệm, phát triển năng lực sư phạm và tăng khả năng thích ứng với yêu cầu phân công nhiệm vụ.
>
> Tuy nhiên, cần nhìn nhận rằng giáo viên công tác lâu năm ở một độ tuổi không đồng nghĩa với thiếu sáng tạo hoặc hạn chế năng lực chuyên môn. Chất lượng giảng dạy phụ thuộc vào tinh thần học hỏi, khả năng đổi mới và kết quả thực hiện nhiệm vụ, chứ không chỉ phụ thuộc số lần thay đổi lớp phụ trách.
>
> Bên cạnh đó, việc phân công giáo viên còn phải căn cứ số lượng giáo viên, đặc điểm trẻ, năng lực chuyên môn và điều kiện tổ chức hoạt động tại từng điểm trường.
>
> Nếu thay đổi đồng loạt hằng năm, nhất là đối với nhóm nhà trẻ, có thể ảnh hưởng đến tính ổn định, sự thích nghi của trẻ và chất lượng chăm sóc.
>
> **Hướng xử lý: TIẾP THU MỘT PHẦN.**
>
> Nhà trường thực hiện rà soát, điều chỉnh phân công giáo viên hằng năm theo hướng tạo cơ hội phát triển chuyên môn, nhưng không quy định bắt buộc tất cả giáo viên phải chuyển độ tuổi mỗi năm.
>
> Phương án phân công phải dựa trên yêu cầu nhiệm vụ, năng lực, nguyện vọng phù hợp và điều kiện thực tế; được Hiệu trưởng xem xét, quyết định theo thẩm quyền.
>
> ### 3. Giáo viên Nguyễn Thị Huỳnh Như – Nhà trẻ 3
>
> **Nội dung góp ý:** Không nên để giáo viên cố định một lớp quá lâu vì dễ gây nhàm chán, giảm động lực và hạn chế đổi mới.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường chia sẻ mong muốn được thay đổi môi trường chuyên môn để tạo động lực, phát huy năng lực và tích lũy kinh nghiệm ở các độ tuổi khác nhau.
>
> Tuy nhiên, sự đổi mới không nhất thiết phải bắt đầu từ việc thay đổi lớp. Giáo viên vẫn có thể đổi mới phương pháp, hình thức tổ chức hoạt động, môi trường giáo dục và cách hỗ trợ trẻ ngay trong độ tuổi đang phụ trách.
>
> Đặc biệt, đối với nhóm nhà trẻ, kinh nghiệm chăm sóc, hiểu biết tâm sinh lý và kỹ năng xử lý tình huống của giáo viên có ý nghĩa rất quan trọng. Vì vậy, việc điều chỉnh phân công cần có sự chuẩn bị về chuyên môn, không thực hiện chỉ nhằm thay đổi vị trí.
>
> **Hướng xử lý: TIẾP THU VỀ ĐỊNH HƯỚNG.**
>
> Nhà trường tạo điều kiện cho giáo viên có nguyện vọng được trải nghiệm độ tuổi khác khi đáp ứng yêu cầu và điều kiện phân công.
>
> Đồng thời tăng cường sinh hoạt chuyên môn liên khối, dự giờ, trao đổi và chia sẻ kinh nghiệm để giáo viên phát triển năng lực ngay cả khi chưa thay đổi nhóm lớp.
>
> ### 4. Giáo viên Trần Thụy Khương Thùy – Nhà trẻ 3
>
> **Nội dung góp ý:** Đề nghị thay đổi giáo viên hằng năm để hạn chế dạy theo thói quen và khuyến khích sáng tạo.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận tinh thần mong muốn đổi mới của giáo viên. Tuy nhiên, đổi mới phương pháp cần được đánh giá thông qua chất lượng tổ chức hoạt động, mức độ phù hợp với trẻ và sự tiến bộ của trẻ.
>
> Nếu chỉ dựa vào thời gian phụ trách một độ tuổi để nhận định giáo viên thiếu sáng tạo thì chưa đủ căn cứ khách quan.
>
> Mặt khác, trong điều kiện nhà trường có ba điểm trường sau sáp nhập, việc phân công cần bảo đảm sự cân đối về nhân sự, kinh nghiệm và chuyên môn giữa các nhóm lớp.
>
> **Hướng xử lý: TIẾP THU MỘT PHẦN.**
>
> Hằng năm, nhà trường rà soát phương án bố trí giáo viên, ưu tiên điều chỉnh khi có yêu cầu chuyên môn, nguyện vọng phù hợp hoặc nhu cầu phát triển năng lực.
>
> Không quy định luân chuyển bắt buộc hằng năm vì có thể gây xáo trộn không cần thiết, ảnh hưởng đến trẻ và việc tổ chức hoạt động của nhà trường.
>
> ### 5. Giáo viên Châu Thị Bé Quyền – Chồi 1
>
> **Nội dung góp ý:** Thống nhất danh mục hồ sơ bắt buộc; giảm ghi chép trùng lặp; công nhận hồ sơ điện tử hợp lệ; ứng dụng CNTT, AI, STEAM theo hướng khuyến khích, chú trọng hiệu quả giáo dục và hỗ trợ giáo viên về thiết bị, học liệu.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất với quan điểm hồ sơ chuyên môn phải phục vụ trực tiếp hoạt động chăm sóc, nuôi dưỡng và giáo dục trẻ, không phải tạo thêm áp lực hành chính.
>
> Tại mục 4.3 Quy chế chuyên môn, nhà trường đã xác định hồ sơ của giáo viên gồm kế hoạch nuôi dưỡng, chăm sóc, giáo dục; sổ theo dõi trẻ; sổ theo dõi tài sản, thiết bị, đồ chơi của nhóm lớp. Quy chế cũng đã nêu việc sử dụng hồ sơ điện tử thay thế hồ sơ giấy khi bảo đảm tính hợp pháp.
>
> Như vậy, ý kiến của giáo viên phù hợp với định hướng đã có trong quy chế. Vấn đề cần hoàn thiện là hướng dẫn thống nhất về hình thức thực hiện, tránh mỗi điểm trường yêu cầu một cách khác nhau.
>
> Đối với ứng dụng AI, CNTT và STEAM, nhà trường xác định đây là phương tiện hỗ trợ đổi mới giáo dục, không phải mục tiêu cuối cùng. Không phải hoạt động nào có sử dụng công nghệ cũng được đánh giá cao hơn hoạt động không sử dụng công nghệ.
>
> Một hoạt động cho trẻ trải nghiệm bằng vật liệu sẵn có, phù hợp mục tiêu và đem lại hiệu quả giáo dục vẫn là hoạt động có chất lượng.
>
> Tuy nhiên, giáo viên cũng cần chủ động tự học, tiếp cận phương pháp mới, sử dụng phù hợp những điều kiện được trang bị và tích cực chia sẻ kinh nghiệm.
>
> **Hướng xử lý: TIẾP THU.**
>
> - Thống nhất danh mục và hình thức quản lý hồ sơ giáo viên tại ba điểm trường.
> - Không yêu cầu lập thêm hồ sơ, minh chứng trùng lặp ngoài quy định nếu không có căn cứ.
> - Công nhận hồ sơ điện tử đáp ứng yêu cầu pháp lý, kỹ thuật và lưu trữ.
> - Đánh giá ứng dụng AI, CNTT, STEAM theo hiệu quả, không theo số lượng sản phẩm.
> - Rà soát thiết bị, học liệu hiện có và bố trí hỗ trợ theo khả năng thực tế.
> - Hướng dẫn giáo viên bảo vệ dữ liệu cá nhân, hình ảnh và thông tin của trẻ.
>
> ### 6. Giáo viên Nguyễn Thị Thanh Thúy – Lá 1
>
> **Nội dung góp ý:** Đề nghị bổ sung thời gian dự kiến tổ chức các hội thi của trẻ để giáo viên chủ động xây dựng kế hoạch.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất rằng việc thông tin sớm lịch hội thi, ngày hội và hoạt động trải nghiệm sẽ giúp giáo viên chủ động xây dựng kế hoạch, chuẩn bị học liệu và phối hợp với cha mẹ trẻ.
>
> Tuy nhiên, Quy chế chuyên môn là văn bản quy định những nguyên tắc và yêu cầu tương đối ổn định trong năm học, còn thời điểm tổ chức từng hội thi phụ thuộc kế hoạch hoạt động, hướng dẫn của ngành và điều kiện thực tế.
>
> Nếu quy định cứng thời gian của tất cả hội thi trong quy chế thì khi có điều chỉnh sẽ gây khó khăn và phải sửa đổi văn bản không cần thiết.
>
> **Hướng xử lý: TIẾP THU VỀ NỘI DUNG, ĐIỀU CHỈNH HÌNH THỨC THỂ HIỆN.**
>
> Giao bộ phận chuyên môn xây dựng lịch dự kiến các hội thi, ngày hội, hoạt động trải nghiệm theo tháng hoặc học kỳ, đưa vào kế hoạch chuyên môn và thông báo sớm đến các tổ.
>
> Khi thay đổi do yêu cầu nhiệm vụ hoặc điều kiện khách quan, nhà trường thông tin kịp thời để giáo viên chủ động điều chỉnh kế hoạch.
>
> ### 7. Giáo viên Nguyễn Thị Minh Nguyệt – Chồi 2
>
> **Nội dung góp ý:** Đề nghị nhà trường bảo đảm đồ dùng, đồ chơi, thiết bị, học liệu; tạo điều kiện để giáo viên chủ động lựa chọn hình thức tổ chức hoạt động phù hợp với trẻ.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất đây là những điều kiện quan trọng để thực hiện Chương trình giáo dục mầm non có chất lượng.
>
> Giáo viên là người trực tiếp tổ chức hoạt động, hiểu đặc điểm, nhu cầu, khả năng và mức độ phát triển của trẻ trong lớp. Vì vậy, cần phát huy tính chủ động, sáng tạo của giáo viên trong lựa chọn phương pháp, hình thức tổ chức và sử dụng học liệu.
>
> Tuy nhiên, sự chủ động phải nằm trong mục tiêu, nội dung chương trình, kế hoạch giáo dục đã được phê duyệt và yêu cầu bảo đảm an toàn cho trẻ; không đồng nghĩa với việc tự ý thay đổi mục tiêu hoặc bỏ nội dung giáo dục bắt buộc.
>
> Đối với đồ dùng, thiết bị và học liệu, nhà trường có trách nhiệm rà soát, bố trí, bổ sung theo nhu cầu thực tế và nguồn lực. Do điều kiện ba điểm trường chưa hoàn toàn đồng đều, việc bổ sung cần xác định mức độ ưu tiên, trước hết là những điều kiện thiết yếu để bảo đảm an toàn và chất lượng giáo dục.
>
> **Hướng xử lý: TIẾP THU.**
>
> Tổ chuyên môn tổng hợp nhu cầu học liệu, thiết bị của từng nhóm lớp; Phó Hiệu trưởng phụ trách rà soát, tham mưu phương án điều phối hoặc bổ sung.
>
> Khuyến khích giáo viên lựa chọn hình thức tổ chức hoạt động linh hoạt, phù hợp đặc điểm trẻ, bảo đảm mục tiêu chương trình và điều kiện thực tế.
>
> ### 8. Giáo viên Tưởng Thị Liễu – Chồi 4
>
> **Nội dung góp ý:** Hoàn thiện quy chế chuyên môn rõ ràng, thống nhất hoạt động chăm sóc, nuôi dưỡng, giáo dục giữa các điểm trường; chia sẻ kinh nghiệm, hỗ trợ giáo viên trẻ.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận đây là góp ý phù hợp yêu cầu quản lý sau sáp nhập.
>
> Trước đây, ba trường có những cách tổ chức hoạt động và kinh nghiệm quản lý chuyên môn riêng. Sau sáp nhập, việc thống nhất những yêu cầu cốt lõi là cần thiết nhằm bảo đảm chất lượng chăm sóc, giáo dục trẻ trong cùng một đơn vị.
>
> Tuy nhiên, thống nhất chuyên môn không có nghĩa là mọi lớp, mọi điểm trường đều phải tổ chức hoạt động giống nhau về hình thức, thời gian chi tiết hoặc sử dụng cùng một loại học liệu.
>
> Nhà trường cần thống nhất về mục tiêu chương trình, yêu cầu an toàn, quy trình chăm sóc, hồ sơ và đánh giá trẻ; đồng thời cho phép giáo viên linh hoạt lựa chọn hình thức phù hợp điều kiện lớp.
>
> Việc bồi dưỡng giáo viên trẻ cũng cần phát huy kinh nghiệm của đội ngũ đi trước, nhưng phải trên tinh thần chia sẻ, hỗ trợ, không áp đặt một cách làm duy nhất.
>
> **Hướng xử lý: TIẾP THU.**
>
> Tăng cường sinh hoạt chuyên môn liên điểm trường, nghiên cứu bài học, dự giờ và trao đổi kinh nghiệm.
>
> Phân công giáo viên có kinh nghiệm hỗ trợ giáo viên cần bồi dưỡng theo nội dung cụ thể; đánh giá hiệu quả qua sự tiến bộ chuyên môn và chất lượng tổ chức hoạt động, không tăng hồ sơ hình thức.
>
> ### 9. Giáo viên Trần Thị Thúy Liễu – Mầm 2
>
> **Nội dung góp ý:** Thống nhất quy chế; đề nghị tăng cường bồi dưỡng chuyên môn, đổi mới phương pháp giáo dục lấy trẻ làm trung tâm, ứng dụng CNTT phù hợp và giảm hồ sơ không cần thiết.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận sự thống nhất và tinh thần trách nhiệm của giáo viên.
>
> Các nội dung đề xuất phù hợp với mục tiêu nâng cao chất lượng chuyên môn, phát triển đội ngũ và chuyển đổi số của nhà trường.
>
> Tuy nhiên, công tác bồi dưỡng cần xuất phát từ nhu cầu và những hạn chế thực tế của giáo viên, không chạy theo số lượng lớp tập huấn hoặc yêu cầu tất cả giáo viên tham gia cùng một nội dung khi chưa thật sự cần thiết.
>
> Tương tự, việc giảm hồ sơ không đồng nghĩa giảm yêu cầu quản lý chất lượng. Nhà trường vẫn cần bảo đảm hồ sơ bắt buộc, nhưng sử dụng hiệu quả dữ liệu đã có và hạn chế ghi chép lặp lại.
>
> **Hướng xử lý: TIẾP THU.**
>
> Giao các tổ chuyên môn khảo sát nhu cầu bồi dưỡng, xây dựng chuyên đề phù hợp; tăng cường chia sẻ học liệu, ứng dụng công nghệ và rà soát các biểu mẫu hiện có.
>
> Ưu tiên thời gian cho giáo viên trực tiếp chăm sóc, tương tác và tổ chức hoạt động giáo dục cho trẻ.
>
> ## KẾT LUẬN PHẦN QUY CHẾ CHUYÊN MÔN
>
> Nhà trường tiếp thu những kiến nghị có cơ sở, nhất là việc giảm hồ sơ trùng lặp, công nhận hồ sơ điện tử hợp lệ, hỗ trợ học liệu, nâng cao chất lượng bồi dưỡng và chủ động công bố kế hoạch hoạt động.
>
> Đối với đề xuất thay đổi giáo viên hằng năm, nhà trường ghi nhận định hướng phát triển năng lực đa độ tuổi nhưng không áp dụng bắt buộc đồng loạt. Việc phân công phải phục vụ yêu cầu chăm sóc, giáo dục trẻ, ổn định tổ chức và sử dụng hiệu quả đội ngũ.
>
> **Nguyên tắc thống nhất:** Quy chế chuyên môn phải rõ yêu cầu, phù hợp thực tiễn, phát huy tính chủ động của giáo viên và lấy chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ làm thước đo chủ yếu.

**Nhận xét quản lý:** Trong phần Quy chế chuyên môn, những ý kiến về hồ sơ, học liệu, đổi mới và lịch hội thi nên tiếp thu tương đối đầy đủ. Riêng đề xuất thay đổi giáo viên hằng năm cần giữ quyền chủ động phân công của Hiệu trưởng, nhưng nên nêu cụ thể cơ sở lựa chọn và tạo cơ hội phát triển chuyên môn để giáo viên thấy được sự công bằng.

---

## II. GIẢI TRÌNH Ý KIẾN VỀ QUY CHẾ ĐÁNH GIÁ, XẾP LOẠI VIÊN CHỨC

Phần này cần giải trình kỹ hơn vì liên quan trực tiếp đến điểm số, kết quả xếp loại, thi đua và quyền lợi của giáo viên.

Căn cứ chính là Điều 2–15 và Phụ lục I của dự thảo Quy chế đánh giá viên chức, Nghị định 233/2026/NĐ-CP có hiệu lực từ ngày 01/7/2026. [Nghị định số 233/2026/NĐ\-CP của Chính phủ: Quy định về đánh giá, xếp loại chất lượng đối với đơn vị sự nghiệp công lập và viên chức](<https://vanban.chinhphu.vn/?docid=218616&pageid=27160&typegroupid=4>); [Các mức xếp loại chất lượng viên chức](<https://xaydungchinhsach.chinhphu.vn/cac-muc-xep-loai-chat-luong-vien-chuc-119260701155446369.htm>); [Nguyên tắc, tiêu chí đánh giá viên chức](<https://xaydungchinhsach.chinhphu.vn/nguyen-tac-tieu-chi-danh-gia-vien-chuc-119260701152748166.htm>)

> **writing · document**
>
> # PHẦN II. GIẢI TRÌNH QUY CHẾ ĐÁNH GIÁ, XẾP LOẠI CHẤT LƯỢNG VIÊN CHỨC
>
> ### 1. Giáo viên Phương Thúy – Lá 7
>
> **Nội dung góp ý:** Trường hợp nhiều viên chức đạt từ 90 điểm trở lên, vượt tỷ lệ 20% hoặc 25%, nhà trường sẽ lựa chọn cá nhân hoàn thành xuất sắc nhiệm vụ như thế nào?
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận đây là vấn đề cần được làm rõ để bảo đảm công khai, minh bạch và tạo sự đồng thuận trong quá trình đánh giá.
>
> Theo Điều 3 và Điều 4 của dự thảo Quy chế đánh giá viên chức, việc xếp loại hoàn thành xuất sắc nhiệm vụ phải đồng thời xem xét điều kiện về điểm số và giới hạn tỷ lệ theo Nghị định số 233/2026/NĐ-CP.
>
> Do đó, đạt từ 90 điểm trở lên là điều kiện về điểm số, không có nghĩa mọi cá nhân đều đương nhiên được xếp loại xuất sắc khi số lượng vượt tỷ lệ pháp luật cho phép.
>
> Tuy nhiên, việc lựa chọn không thể thực hiện theo cảm tính, bình quân giữa các điểm trường hoặc chỉ dựa trên một thành tích riêng lẻ.
>
> Nhà trường cần dựa trên kết quả thực hiện nhiệm vụ, chất lượng và tiến độ công việc, những đóng góp nổi trội có minh chứng, đồng thời xem xét trong nhóm viên chức có nhiệm vụ tương đồng.
>
> **Hướng xử lý: TIẾP THU.**
>
> Bổ sung hướng dẫn xét chọn khi số cá nhân đủ điều kiện về điểm vượt tỷ lệ; làm rõ nguyên tắc so sánh kết quả, thẩm quyền quyết định và quyền được thông tin, giải trình.
>
> Đối với những vướng mắc về cách tính số lượng, làm tròn tỷ lệ và xử lý người đạt 90 điểm trở lên nhưng không được chọn, nhà trường sẽ xin hướng dẫn của cơ quan có thẩm quyền trước khi thực hiện chính thức.
>
> ### 2. Giáo viên Nguyễn Thị Mỹ Tiên – Lá 1
>
> **Nội dung góp ý:** Khi nhiều giáo viên cùng đạt trên 90 điểm, tiêu chí ưu tiên lựa chọn là gì? Những người không được xếp xuất sắc sẽ được xếp loại như thế nào?
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường chia sẻ với giáo viên rằng sự rõ ràng trong quy trình xét chọn có ý nghĩa rất quan trọng, bởi những người đạt điểm cao đều đã có nỗ lực trong thực hiện nhiệm vụ.
>
> Vì vậy, việc lựa chọn cá nhân xuất sắc cần dựa trên sự khác biệt về chất lượng và kết quả thực hiện nhiệm vụ, không dựa vào mối quan hệ cá nhân, thâm niên đơn thuần hoặc ưu tiên giáo viên ở một điểm trường nhất định.
>
> Nhà trường dự kiến xem xét các yếu tố: điểm đánh giá đã được xác nhận; kết quả nhiệm vụ nổi trội; chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ; mức độ hoàn thành nhiệm vụ kiêm nhiệm; sáng kiến hoặc giải pháp đã áp dụng hiệu quả; tinh thần phối hợp và những đóng góp được giao, được ghi nhận.
>
> Những tiêu chí này phải được cụ thể hóa, công khai trước khi xét chọn; không bổ sung tiêu chí mới sau khi đã có kết quả nhằm ưu tiên hoặc loại trừ một cá nhân.
>
> Riêng câu hỏi giáo viên đạt từ 90 điểm trở lên nhưng không nằm trong tỷ lệ xuất sắc sẽ được xếp loại gì, nhà trường không nên tự ý hạ điểm hoặc tự chuyển mức xếp loại khi Nghị định quy định khung điểm hoàn thành tốt từ 70 đến dưới 90.
>
> **Hướng xử lý: TIẾP THU.**
>
> Bổ sung quy trình xét chọn trong nhóm nhiệm vụ tương đồng. Xin ý kiến hướng dẫn của cơ quan quản lý về phương pháp xử lý trường hợp điểm từ 90 trở lên nhưng vượt tỷ lệ trước khi ban hành hướng dẫn cuối cùng.
>
> Kết quả điểm thực tế và mức xếp loại được quản lý, thông báo rõ ràng theo đúng hướng dẫn pháp luật.
>
> ### 3. Giáo viên Bé Tý – Lá 4
>
> **Nội dung góp ý:** Đề nghị làm rõ thế nào là sai sót nhẹ và vi phạm nghiêm trọng về an toàn trẻ; việc trừ điểm phải dựa trên mức độ, nguyên nhân và kết quả xác minh.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường hoàn toàn thống nhất với yêu cầu bảo đảm tính khách quan khi xem xét trách nhiệm đối với những vấn đề liên quan an toàn trẻ.
>
> An toàn thể chất và tinh thần của trẻ là nguyên tắc ưu tiên hàng đầu, vì vậy không thể xem nhẹ các sai phạm trong quá trình chăm sóc, giáo dục.
>
> Tuy nhiên, cũng cần phân biệt giữa sai sót về thao tác, thủ tục với hành vi vi phạm nghiêm trọng có nguy cơ gây tổn hại cho trẻ.
>
> Ví dụ, một thiếu sót trong ghi chép, được phát hiện và chỉnh sửa kịp thời, không ảnh hưởng việc giám sát trẻ, có thể được xem xét ở mức sai sót thủ tục nhẹ tùy tình huống.
>
> Ngược lại, hành vi bỏ mặc trẻ không có người giám sát, giao trẻ cho người không được phép đón hoặc xâm phạm thân thể trẻ có tính chất nghiêm trọng, cần xử lý theo quy định và không chỉ xem là lỗi thông thường để trừ điểm.
>
> Đặc biệt, một hành vi có nguy cơ gây hậu quả nghiêm trọng vẫn phải được xem xét đúng tính chất dù thực tế chưa xảy ra tai nạn.
>
> **Hướng xử lý: TIẾP THU.**
>
> Bổ sung hướng dẫn phân biệt mức độ sai sót ở tiêu chí B2.1 và các tiêu chí liên quan.
>
> Việc xác định mức điểm phải căn cứ trách nhiệm được giao, hành vi thực tế, mức độ nguy cơ, nguyên nhân, kết quả xác minh và khả năng khắc phục.
>
> Không kết luận vi phạm chỉ dựa trên phản ánh chưa được kiểm chứng.
>
> Trường hợp có dấu hiệu vi phạm nghiêm trọng phải ưu tiên bảo vệ trẻ, thực hiện quy trình xử lý sự việc; việc chấm KPI không thay thế trách nhiệm pháp lý hoặc quy trình xử lý vi phạm.
>
> ### 4. Giáo viên Huỳnh Thị Hồng Hạnh – Lá 3
>
> **Nội dung góp ý:** Không nên yêu cầu chấm đầy đủ KPI và lập nhiều minh chứng mỗi tháng; đề nghị theo dõi tháng, tổng hợp quý. Đồng thời chỉ ra lỗi cộng điểm A1.2, B1.3, B1.4.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường đánh giá đây là ý kiến có cơ sở chuyên môn và phù hợp với đặc thù công việc của giáo viên mầm non.
>
> Quy chế đánh giá được xây dựng nhằm phản ánh kết quả thực hiện nhiệm vụ, không nhằm tạo thêm hồ sơ hành chính.
>
> Nếu giáo viên phải liên tục lập minh chứng, tự tổng hợp và giải trình tất cả tiêu chí mỗi tháng thì có thể ảnh hưởng thời gian dành cho trẻ.
>
> Mặt khác, những hoạt động như bồi dưỡng chuyên môn, đổi mới phương pháp, thực hiện sáng kiến hoặc tổ chức chuyên đề có thể triển khai theo quý, học kỳ, không nhất thiết phát sinh hằng tháng.
>
> Vì vậy, việc đánh giá cần phân biệt nhiệm vụ thường xuyên với nhiệm vụ thực hiện theo chu kỳ.
>
> Nghị định số 233/2026/NĐ-CP cho phép sử dụng kết quả theo dõi, đánh giá hằng tháng hoặc hằng quý làm căn cứ đánh giá năm.
>
> **Hướng xử lý: TIẾP THU.**
>
> Đề xuất theo dõi tiến độ và chất lượng thực hiện nhiệm vụ hằng tháng bằng hồ sơ, dữ liệu sẵn có; tổng hợp điểm theo quý sau khi thống nhất quy chế.
>
> Đối với nhiệm vụ không phát sinh trong tháng hoặc chưa đến thời hạn thực hiện, không mặc nhiên cho điểm thấp; cách xử lý phải được quy định công khai, thống nhất.
>
> Đồng thời, nhà trường ghi nhận lỗi điểm tại A1.2, B1.3, B1.4 và chỉ đạo chỉnh sửa trước khi áp dụng.
>
> ### 5. Giáo viên Châu Thị Bé Quyền – Chồi 1
>
> **Nội dung góp ý:** Cần hướng dẫn thống nhất cách chấm điểm KPI, minh chứng cần thiết, trường hợp khách quan và quyền giải trình khi giáo viên không đồng ý với kết quả.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất rằng một bộ tiêu chí chỉ bảo đảm công bằng khi người thực hiện và người đánh giá hiểu giống nhau về yêu cầu, cách tính và minh chứng.
>
> Vì vậy, không thể chỉ công bố bảng điểm mà thiếu hướng dẫn sử dụng.
>
> Mặt khác, trong hoạt động giáo dục mầm non, nhiệm vụ từng giáo viên có thể khác nhau do nhóm tuổi, số trẻ, nhiệm vụ kiêm nhiệm, điều kiện lớp và nhiệm vụ phát sinh.
>
> Nếu chỉ so sánh số lượng sản phẩm hoặc hồ sơ theo cùng một mẫu số, kết quả chưa chắc phản ánh đúng hiệu quả công việc.
>
> Việc đánh giá phải căn cứ nhiệm vụ hợp lệ được giao, chất lượng thực hiện và các yếu tố khách quan đã được xác nhận.
>
> **Hướng xử lý: TIẾP THU.**
>
> Ban hành hướng dẫn sử dụng bảng KPI kèm ví dụ minh họa; xác định minh chứng phù hợp cho từng tiêu chí.
>
> Cho phép sử dụng hồ sơ, dữ liệu công việc đã có, không yêu cầu tạo thêm minh chứng riêng nếu không cần thiết.
>
> Quy định quy trình thông báo điểm, giải thích tiêu chí chưa đạt, tiếp nhận minh chứng bổ sung và xem xét lại kết quả khi có căn cứ.
>
> ### 6. Giáo viên Nguyễn Thị Minh Nguyệt – Chồi 2
>
> **Nội dung góp ý:** Đề nghị cách chấm điểm rõ ràng, phù hợp nhiệm vụ, tính đến khối lượng công việc, chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ và nhiệm vụ kiêm nhiệm; tránh áp lực hồ sơ.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất việc đánh giá phải đặt kết quả thực hiện nhiệm vụ làm trọng tâm, không đánh đồng số lượng giấy tờ với chất lượng công tác.
>
> Đối với giáo viên mầm non, chất lượng công việc được thể hiện trước hết ở việc bảo đảm an toàn cho trẻ, tổ chức hoạt động giáo dục phù hợp, thực hiện chăm sóc, nuôi dưỡng và theo dõi sự phát triển của trẻ.
>
> Những nhiệm vụ kiêm nhiệm được giao hợp lệ cũng cần được xem xét trong tổng thể khối lượng công việc.
>
> Tuy nhiên, việc kiêm nhiệm không đương nhiên được cộng thêm điểm ngoài thang điểm quy định. Cần xác định từ đầu nhiệm vụ nào thuộc tiêu chí đánh giá, yêu cầu chất lượng và thời hạn thực hiện.
>
> Đồng thời, các nhiệm vụ không phát sinh do nguyên nhân khách quan hoặc kế hoạch đã được điều chỉnh không nên bị tính là không hoàn thành.
>
> **Hướng xử lý: TIẾP THU.**
>
> Cụ thể hóa nhiệm vụ, sản phẩm và cách đánh giá theo từng nhóm vị trí việc làm; ghi nhận nhiệm vụ kiêm nhiệm, nhiệm vụ phát sinh được phân công.
>
> Không yêu cầu giáo viên tạo thêm hồ sơ chỉ để chứng minh kết quả đã được thể hiện trong dữ liệu chuyên môn.
>
> ### 7. Giáo viên Trần Thị Huỳnh Như – Lá 8
>
> **Nội dung góp ý:** Cơ bản không có ý kiến điều chỉnh, nhưng mong nhà trường hướng dẫn cụ thể hơn để dễ theo dõi và thực hiện.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận sự thống nhất của giáo viên.
>
> Đây là năm đầu thực hiện đánh giá theo hệ thống KPI mới, do đó việc một số giáo viên chưa nắm hết cách tính điểm và phương thức sử dụng minh chứng là điều cần được quan tâm trong công tác triển khai.
>
> Trách nhiệm của người quản lý không chỉ dừng lại ở việc ban hành quy chế mà còn phải hướng dẫn, hỗ trợ để giáo viên hiểu và thực hiện thống nhất.
>
> **Hướng xử lý: TIẾP THU.**
>
> Tổ chức hướng dẫn bảng điểm theo từng nhóm tiêu chí; giải đáp bằng các tình huống cụ thể, có ví dụ minh họa.
>
> Phân công tổ trưởng và người phụ trách hỗ trợ khi giáo viên gặp vướng mắc; kịp thời tổng hợp các trường hợp chưa rõ để hướng dẫn chung.
>
> ### 8. Giáo viên Nguyễn Thị Huỳnh Như – Chồi 3
>
> **Nội dung góp ý:** Khi bị trừ điểm, giáo viên cần biết rõ tiêu chí chưa đạt, được trao đổi, giải trình và đề nghị xem xét lại.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất việc đánh giá phải có căn cứ và giải thích rõ ràng.
>
> Việc chấm điểm không nhằm tìm lỗi để xử lý giáo viên mà nhằm xác định mức độ hoàn thành nhiệm vụ, phát hiện hạn chế và đề xuất biện pháp hỗ trợ, cải thiện.
>
> Do đó, giáo viên phải được biết nội dung chưa đạt, mức điểm được ghi nhận và lý do đánh giá.
>
> Người đánh giá có trách nhiệm đối chiếu minh chứng, phân biệt lỗi do nguyên nhân chủ quan với các yếu tố khách quan, đồng thời tạo điều kiện để giáo viên trình bày ý kiến.
>
> Tuy nhiên, quyền giải trình không có nghĩa điểm số phải được thay đổi theo yêu cầu cá nhân. Việc điều chỉnh chỉ được thực hiện khi có căn cứ xác định kết quả ban đầu chưa chính xác hoặc chưa phù hợp quy định.
>
> **Hướng xử lý: TIẾP THU.**
>
> Bổ sung hướng dẫn cụ thể về thông báo kết quả, quyền giải trình và quy trình xem xét lại điểm.
>
> Khi có chênh lệch giữa điểm giáo viên tự đánh giá và điểm người phụ trách đề xuất, cần ghi rõ tiêu chí, lý do, minh chứng và kết quả trao đổi.
>
> ### 9. Giáo viên Nguyễn Thị Thanh Nhãn – Chồi 2
>
> **Nội dung góp ý:** Thống nhất dự thảo, tiếp tục nghiên cứu để nắm rõ hơn cách thực hiện KPI.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận tinh thần chủ động nghiên cứu và sự thống nhất của giáo viên.
>
> Đây là phương thức đánh giá có nhiều nội dung mới, đòi hỏi sự phối hợp giữa người giao nhiệm vụ, người thực hiện và người đánh giá.
>
> Nhà trường khuyến khích giáo viên chủ động tìm hiểu, đồng thời xác định trách nhiệm hướng dẫn và hỗ trợ thuộc về Ban Giám hiệu, tổ chuyên môn và người được phân công.
>
> **Hướng xử lý: GHI NHẬN, TIẾP TỤC HỖ TRỢ.**
>
> Tổ chức phổ biến, hướng dẫn cách ghi nhận kết quả, lưu minh chứng và thực hiện tự đánh giá; tiếp nhận những vướng mắc phát sinh trong quá trình áp dụng.
>
> ### 10. Giáo viên Nguyễn Thị Kim Liên – Chồi 8
>
> **Nội dung góp ý:** Khi xảy ra sai sót trong lớp có hai giáo viên, nhà trường trừ điểm cả hai hay chỉ người trực tiếp vi phạm?
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất nguyên tắc đánh giá trách nhiệm cá nhân trên cơ sở nhiệm vụ được giao và mức độ thực hiện thực tế.
>
> Trong một lớp có hai hoặc nhiều giáo viên, các cô có trách nhiệm phối hợp trong chăm sóc, nuôi dưỡng, giáo dục và bảo đảm an toàn cho trẻ. Tuy nhiên, trách nhiệm phối hợp không có nghĩa tất cả đều phải chịu mức trừ điểm giống nhau khi xảy ra sai sót.
>
> Ví dụ, nếu một giáo viên được phân công thực hiện nhiệm vụ cụ thể nhưng không thực hiện đúng, còn giáo viên khác đã làm đúng trách nhiệm phối hợp, giám sát và báo cáo thì không thể mặc nhiên trừ điểm cả hai như nhau.
>
> Ngược lại, nếu sai sót phát sinh từ việc cả hai cùng không thực hiện trách nhiệm được giao, nhà trường phải xem xét trách nhiệm tương ứng của từng người.
>
> **Hướng xử lý: TIẾP THU.**
>
> Bổ sung nguyên tắc đánh giá trách nhiệm cá nhân, không trừ điểm tập thể một cách máy móc.
>
> Đối với nhiệm vụ chung, căn cứ phân công, lịch trực, hồ sơ bàn giao, diễn biến sự việc và kết quả xác minh để xác định trách nhiệm từng giáo viên.
>
> ### 11. Giáo viên Tưởng Thị Liễu – Chồi 4
>
> **Nội dung góp ý:** Đánh giá phải công khai, dân chủ, khách quan, công bằng; tiêu chí rõ ràng và phù hợp nhiệm vụ từng cá nhân.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường thống nhất đây là nguyên tắc cơ bản, đã được xác định tại Điều 2 dự thảo Quy chế đánh giá viên chức.
>
> Tuy nhiên, công bằng không có nghĩa tất cả giáo viên phải được giao khối lượng công việc giống nhau hoặc có kết quả điểm số như nhau.
>
> Trong điều kiện nhà trường có ba điểm trường, sự khác biệt về số trẻ, độ tuổi, điều kiện cơ sở vật chất và nhiệm vụ được giao phải được xem xét khi đánh giá.
>
> Điều cần thống nhất là tiêu chí, nguyên tắc, phương pháp và quy trình đánh giá; đồng thời căn cứ nhiệm vụ thực tế của từng cá nhân để xác định kết quả.
>
> **Hướng xử lý: TIẾP THU.**
>
> Công khai tiêu chí và quy trình; hướng dẫn cách chấm thống nhất toàn trường, không để mỗi điểm trường áp dụng một cách khác nhau.
>
> Tăng cường kiểm tra chéo và rà soát những trường hợp có chênh lệch bất thường hoặc phát sinh ý kiến về tính công bằng.
>
> ### 12. Giáo viên Bùi Huỳnh Ngọc Tân
>
> **Nội dung góp ý:** Sửa “hàng tháng” thành “hằng tháng”; điều chỉnh điểm B1.3, B1.4; phân biệt đánh giá viên chức với lao động hợp đồng; ghi nhận việc sử dụng hồ sơ điện tử và quy định sửa đổi, bổ sung.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận các ý kiến góp ý có cơ sở về kỹ thuật xây dựng văn bản và tính chính xác của thang điểm.
>
> Qua đối chiếu Phụ lục KPI, nhóm B1 có tổng điểm là 20 nhưng cột điểm tối đa của B1.3 và B1.4 đang ghi không phù hợp mức điểm cao nhất.
>
> Cụ thể, hai tiêu chí B1.3 và B1.4 lần lượt có mức điểm cao nhất là 4 và 3, nhưng cột điểm tối đa đều ghi 10. Đây là sai lệch cần sửa trước khi đánh giá.
>
> Việc phân biệt viên chức và người lao động hợp đồng cũng cần được thể hiện rõ nhằm bảo đảm thực hiện đúng pháp luật áp dụng cho từng đối tượng.
>
> Đối với hình thức hồ sơ điện tử và nguyên tắc áp dụng văn bản pháp luật có hiệu lực cao hơn, nhà trường thống nhất tiếp tục giữ các nội dung phù hợp trong dự thảo.
>
> **Hướng xử lý: TIẾP THU.**
>
> - Sửa B1.3 từ 10 điểm thành 4 điểm.
> - Sửa B1.4 từ 10 điểm thành 3 điểm.
> - Thống nhất tổng nhóm B1 là 5 + 8 + 4 + 3 = 20 điểm.
> - Rà soát, sử dụng thống nhất từ “hằng tháng” trong các nội dung chỉ tính chất lặp lại định kỳ.
> - Làm rõ cơ chế đánh giá người lao động hợp đồng theo quy định pháp luật và hợp đồng tương ứng.
> - Tiếp tục khuyến khích sử dụng hồ sơ điện tử hợp pháp, hạn chế trùng lặp.
>
> ### 13. Giáo viên Trương Hồ Xuân Lan – Chồi 6
>
> **Nội dung góp ý:** Chưa hiểu rõ cách đánh giá, còn băn khoăn về việc thực hiện KPI.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận ý kiến và xác định đây là vấn đề cần quan tâm trong tổ chức triển khai.
>
> Việc chuyển sang phương thức đánh giá theo thang điểm có thể làm giáo viên gặp khó khăn ban đầu, đặc biệt khi có nhiều tiêu chí, mức điểm và yêu cầu minh chứng.
>
> Vì vậy, nhà trường không xem việc giáo viên chưa hiểu đầy đủ là thiếu tinh thần trách nhiệm; đồng thời giáo viên cũng cần chủ động tham gia nghiên cứu, trao đổi những nội dung chưa rõ.
>
> Ban Giám hiệu có trách nhiệm hướng dẫn để mọi giáo viên hiểu thống nhất tiêu chí trước khi thực hiện đánh giá chính thức.
>
> **Hướng xử lý: TIẾP THU YÊU CẦU HƯỚNG DẪN.**
>
> Tổ chức một buổi sinh hoạt chuyên môn chuyên đề về KPI, hướng dẫn bằng tình huống thực tế như nộp hồ sơ chậm, nghỉ có lý do hợp pháp, nhiệm vụ chưa phát sinh, lớp có hai giáo viên và cách tính điểm theo tỷ lệ hoàn thành.
>
> Trong quá trình hướng dẫn, giáo viên được đặt câu hỏi và đề nghị làm rõ các nội dung còn vướng mắc.
>
> ### 14. Giáo viên Trần Thị Thúy Liễu – Mầm 2
>
> **Nội dung góp ý:** Thống nhất quy chế; đề nghị đánh giá khách quan, minh bạch, phù hợp nhiệm vụ, chú trọng trách nhiệm, đạo đức và sự tiến bộ của mỗi cá nhân.
>
> **Ý kiến giải trình của Hiệu trưởng:**
>
> Nhà trường ghi nhận sự đồng thuận và thống nhất với quan điểm đánh giá phải hướng đến nâng cao chất lượng đội ngũ.
>
> Kết quả đánh giá không chỉ được sử dụng để xếp loại mà còn là căn cứ xác định nhu cầu bồi dưỡng, hỗ trợ và phát triển năng lực của giáo viên.
>
> Vì vậy, bên cạnh việc ghi nhận những kết quả đạt được, người quản lý cần chỉ ra hạn chế có căn cứ, hướng dẫn biện pháp khắc phục và ghi nhận sự tiến bộ trong quá trình công tác.
>
> Tuy nhiên, sự tiến bộ của mỗi cá nhân cần được xem xét trong mối quan hệ với yêu cầu nhiệm vụ và chất lượng công việc, không thay thế các tiêu chí bắt buộc.
>
> **Hướng xử lý: TIẾP THU.**
>
> Duy trì việc nhận xét kết quả công tác gắn với hướng hỗ trợ, bồi dưỡng; đánh giá theo yêu cầu vị trí việc làm, sản phẩm, tiến độ và chất lượng thực hiện nhiệm vụ.
>
> ## KẾT LUẬN PHẦN ĐÁNH GIÁ, XẾP LOẠI VIÊN CHỨC
>
> Nhà trường thống nhất tiếp thu những kiến nghị nhằm làm rõ tiêu chí, bảo đảm tính chính xác của bảng điểm, giảm áp lực minh chứng, bảo vệ quyền giải trình và thực hiện đánh giá công bằng giữa các giáo viên.
>
> Những nội dung thuộc quy định bắt buộc của Nghị định số 233/2026/NĐ-CP phải được thực hiện đúng pháp luật.
>
> Đối với các vấn đề còn vướng mắc về áp dụng giới hạn tỷ lệ hoàn thành xuất sắc nhiệm vụ, nhà trường sẽ xin hướng dẫn của cơ quan có thẩm quyền trước khi quyết định chính thức.
>
> **Nguyên tắc thống nhất:** Đánh giá phải dựa trên nhiệm vụ được giao và kết quả thực chất, không chạy theo hình thức, không trừ điểm thiếu căn cứ, không đánh đồng trách nhiệm cá nhân với trách nhiệm tập thể và bảo đảm quyền được giải trình của viên chức.

---

## 🔍 III. Những nội dung tôi đề nghị Ban Giám hiệu chỉnh sửa ngay trong phụ lục KPI

Ngoài việc trả lời từng giáo viên, qua đối chiếu bảng KPI gốc, tôi đề nghị xử lý thêm bốn vấn đề mang tính hệ thống.

### 1. Chỉnh sửa điểm số không thống nhất

| Mã tiêu chí | Dự thảo hiện ghi | Đề xuất | Lý do |
|--------|--------|--------|--------|
| A1.2 | 7 | 5 | Để tổng A1 bằng 15 điểm |
| B1.3 | 10 | 4 | Khớp mức điểm cao nhất |
| B1.4 | 10 | 3 | Để tổng B1 bằng 20 điểm |

Đồng thời sửa điểm giao nhau của A1.2: hiện mức “2–3 vi phạm nhẹ” và “từ 3 sai sót” cùng bao gồm trường hợp 3 lần. Cần chọn một mốc phân loại rõ ràng, không để người chấm tùy nghi lựa chọn.  

### 2. Không đánh đồng việc sử dụng STEAM với chất lượng hoạt động giáo dục

Tại B2.3, dự thảo đang sử dụng tiêu chí có nội dung “lồng ghép STEAM”, đồng thời yêu cầu ít nhất hai lượt quan sát mỗi tháng, mỗi lượt năm chỉ báo. 

Tôi đề nghị viết lại theo hướng:

> Tổ chức hoạt động giáo dục lấy trẻ làm trung tâm; vận dụng linh hoạt các phương pháp giáo dục phù hợp, khuyến khích tích hợp STEM/STEAM khi có điều kiện và phù hợp mục tiêu, nội dung, độ tuổi.

Cách viết này vừa giữ định hướng đổi mới, vừa tránh hiểu rằng giáo viên phải tổ chức hoạt động STEAM mới được đánh giá tốt.

### 3. Xây dựng hướng dẫn cho nhiệm vụ không phát sinh trong kỳ

Ví dụ, tháng đó không có hội thi, chuyên đề, nhiệm vụ đột xuất hoặc hoạt động bồi dưỡng được giao thì không hợp lý nếu tự động cho giáo viên 0 điểm vì không có minh chứng.

Tôi đề nghị xác định công việc được giao theo tháng hoặc quý, không tính công việc chưa phát sinh vào mẫu số hoàn thành nhiệm vụ. Đối với tiêu chí cố định chưa phát sinh nhiệm vụ, nhà trường cần quy định trước cách xử lý điểm hoặc nhiệm vụ tương đương, công khai thống nhất, không tự điều chỉnh sau khi chấm.

### 4. Thống nhất thời điểm theo dõi và chấm điểm

Hiện Điều 11 dự thảo cho phép tổng hợp theo quý khi cần, trong khi Phụ lục I đặt tên là đánh giá hằng tháng.

Tôi đề xuất nhà trường lựa chọn rõ phương thức **theo dõi thường xuyên theo tháng, tổng hợp chấm điểm theo quý** nếu phù hợp hướng dẫn của cơ quan quản lý, sau đó điều chỉnh đồng bộ Điều 11, phụ lục, quy trình thực hiện và Nghị quyết Hội nghị.

Cách làm này giảm công việc hành chính nhưng vẫn giữ được dữ liệu đánh giá liên tục, phù hợp nguyên tắc của Nghị định 233/2026/NĐ-CP. [Các mức xếp loại chất lượng viên chức](<https://xaydungchinhsach.chinhphu.vn/cac-muc-xep-loai-chat-luong-vien-chuc-119260701155446369.htm>)

## 📋 IV. Bảng chốt phương án để Hiệu trưởng dễ quyết định

| Nội dung | Phương án đề xuất |
|--------|--------|
| Lỗi chính tả Quy chế chuyên môn | Tiếp thu, chỉnh sửa |
| Luân chuyển giáo viên hằng năm | Tiếp thu một phần, không luân chuyển bắt buộc |
| Hồ sơ chuyên môn và hồ sơ điện tử | Tiếp thu, thống nhất hướng dẫn |
| CNTT, AI, STEAM | Khuyến khích theo hiệu quả và điều kiện |
| Lịch dự kiến hội thi | Tiếp thu, đưa vào kế hoạch chuyên môn |
| Thiết bị, học liệu và quyền chủ động của giáo viên | Tiếp thu, triển khai theo điều kiện thực tế |
| KPI hằng tháng hoặc hằng quý | Đề xuất theo dõi tháng, tổng hợp quý |
| Sai điểm A1.2, B1.3, B1.4 | Sửa trước khi áp dụng |
| Phân định sai sót nhẹ, nghiêm trọng | Bổ sung hướng dẫn |
| Trừ điểm giáo viên chung lớp | Xác định trách nhiệm từng cá nhân |
| Quyền giải trình điểm KPI | Bổ sung quy trình cụ thể |
| Vượt tỷ lệ 20% hoặc 25% xuất sắc | Làm rõ cách xét; xin hướng dẫn trường hợp chưa rõ |
| Tập huấn sử dụng KPI | Tổ chức trước khi đánh giá chính thức |
| Đánh giá người lao động hợp đồng | Làm rõ cơ chế riêng phù hợp pháp luật |

## ✅ V. Đề xuất lời kết luận của Hiệu trưởng tại cuộc họp

> **writing · standard**
>
> Qua nghiên cứu các ý kiến đóng góp về Quy chế chuyên môn và Quy chế đánh giá, xếp loại chất lượng viên chức, Ban Giám hiệu ghi nhận tinh thần trách nhiệm của đội ngũ giáo viên trong việc nghiên cứu, phát hiện những nội dung chưa rõ hoặc chưa phù hợp thực tế.
>
> Nhà trường thống nhất tiếp thu những ý kiến có cơ sở để chỉnh sửa, hoàn thiện văn bản, đặc biệt là các nội dung liên quan đến hồ sơ chuyên môn, phân công nhiệm vụ, phương pháp đánh giá, cách tính điểm và quyền giải trình của giáo viên.
>
> Đối với những đề xuất chưa thể áp dụng hoàn toàn, nhà trường đã giải trình trên cơ sở yêu cầu chuyên môn, quy định pháp luật và điều kiện thực tế của đơn vị sau sáp nhập.
>
> Ban Giám hiệu xác định việc ban hành quy chế không nhằm gây thêm áp lực cho giáo viên mà để tạo sự thống nhất trong quản lý, làm rõ trách nhiệm, bảo đảm công bằng và nâng cao chất lượng thực hiện nhiệm vụ.
>
> Trong quá trình tổ chức thực hiện, nhà trường sẽ tiếp tục lắng nghe, hỗ trợ và xem xét những vấn đề phát sinh có căn cứ. Đồng thời, mỗi viên chức cần phát huy tinh thần trách nhiệm, chủ động nghiên cứu và thực hiện nghiêm túc những nội dung đã được ban hành hợp pháp.
>
> **Quan điểm của nhà trường là thống nhất trong nguyên tắc, linh hoạt trong tổ chức thực hiện, công bằng trong đánh giá và lấy chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ làm mục tiêu cao nhất.**

**Khuyến nghị của tôi:** Cô nên thống nhất trước với Hiệu trưởng ba việc: sửa bảng điểm KPI, xác định cách theo dõi tháng/tổng hợp quý và xin hướng dẫn trường hợp đạt 90 điểm nhưng vượt tỷ lệ xuất sắc. Đây là những vấn đề có khả năng phát sinh ý kiến nhiều nhất nếu chưa giải quyết dứt điểm.

Khi trình bày với giáo viên, nên giữ đúng tinh thần của hai phần giải trình trên: **tiếp thu rõ ràng những ý kiến hợp lý, giải thích có cơ sở những đề xuất chỉ tiếp thu một phần và không cam kết điều gì vượt thẩm quyền của nhà trường.**

---

ASSISTANT

---

USER

giải trình nội dung này nhé

---

ASSISTANT

Tôi sẽ đối chiếu góp ý này với Điều 11 và phụ lục KPI của trường, đồng thời kiểm tra quy định về đánh giá theo tháng hoặc quý. Phần giải trình sẽ làm rõ ý nào nên tiếp thu, cách giảm hồ sơ cho giáo viên nhưng vẫn theo dõi được chất lượng công việc, và cách sửa các lỗi điểm số được nêu.

---

ASSISTANT

---

ASSISTANT

## 📌 GIẢI TRÌNH Ý KIẾN VỀ VIỆC ÁP DỤNG KPI HẰNG THÁNG VÀ SAI LỆCH THANG ĐIỂM

**Giáo viên góp ý:** Huỳnh Thị Hồng Hạnh – Lớp Lá 3
**Văn bản:** Quy chế đánh giá, xếp loại chất lượng viên chức năm học 2026–2027.

**Quan điểm đề xuất của Hiệu trưởng: Tiếp thu ý kiến hợp lý, nhưng không bỏ việc theo dõi hằng tháng. Điều chỉnh cách tổ chức đánh giá để giảm áp lực hồ sơ, bảo đảm công bằng và đúng quy định.**

### 📖 Căn cứ giải trình

- **Nghị định số 233/2026/NĐ-CP:** Cho phép sử dụng điểm theo dõi, đánh giá viên chức hằng tháng hoặc hằng quý làm căn cứ xếp loại chất lượng viên chức. Như vậy, việc tổng hợp theo quý có cơ sở pháp lý, không bắt buộc phải chấm toàn bộ KPI mỗi tháng. [Chấm điểm, đánh giá viên chức hằng tháng hoặc hằng quý](<https://baochinhphu.vn/cham-diem-danh-gia-vien-chuc-hang-thang-hoac-hang-quy-102260630052951335.htm>)
- **Điều 10 Quy chế đánh giá của trường:** Minh chứng đánh giá phải trung thực, phù hợp và không tạo thêm hồ sơ hình thức chỉ để phục vụ chấm điểm. 
- **Điều 11 Quy chế đánh giá của trường:** Đã quy định theo dõi, đánh giá thường xuyên theo tháng; trường hợp cần thiết tổng hợp theo quý. 

Như vậy, góp ý của giáo viên **không phủ nhận yêu cầu đánh giá viên chức mà đề nghị điều chỉnh phương thức thực hiện**. Đây là ý kiến cần được xem xét tích cực để quy chế có tính khả thi cao hơn.

## 📝 Nội dung giải trình của Hiệu trưởng có thể sử dụng trực tiếp

> **writing · document**
>
> **Nội dung góp ý:** Về những bất cập khi áp dụng toàn bộ bảng KPI hằng tháng; đề xuất theo dõi tháng, tổng hợp quý và điều chỉnh các lỗi thang điểm A1.2, B1.3, B1.4.
>
> **Ý kiến giải trình, tiếp thu của nhà trường:**
>
> Nhà trường ghi nhận và đánh giá cao ý kiến đóng góp của giáo viên. Đây là ý kiến có cơ sở thực tiễn, thể hiện sự quan tâm đến tính khả thi, công bằng và hiệu quả của việc đánh giá, xếp loại chất lượng viên chức.
>
> Trước hết, cần khẳng định việc xây dựng hệ thống tiêu chí KPI không nhằm tăng thêm hồ sơ, tạo áp lực cho giáo viên mà nhằm cụ thể hóa yêu cầu đánh giá theo Nghị định số 233/2026/NĐ-CP, chuyển trọng tâm từ nhận xét chung sang đánh giá dựa trên nhiệm vụ, sản phẩm và kết quả công việc thực tế.
>
> **Thứ nhất, về áp lực hồ sơ, minh chứng và nguy cơ đánh giá hình thức:**
>
> Nhà trường thống nhất rằng nếu yêu cầu giáo viên tự chấm toàn bộ bảng KPI, lập minh chứng riêng cho từng tiêu chí và giải trình tất cả nội dung mỗi tháng thì có thể làm gia tăng công việc hành chính, ảnh hưởng thời gian dành cho hoạt động chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> Tuy nhiên, đánh giá có minh chứng là yêu cầu cần thiết để bảo đảm tính khách quan. Vấn đề không phải bỏ minh chứng mà là sử dụng minh chứng hợp lý, tránh trùng lặp.
>
> Theo Điều 10 dự thảo Quy chế đánh giá, nhà trường đã xác định không tạo thêm hồ sơ hình thức chỉ để phục vụ chấm điểm.
>
> Do đó, nhà trường sẽ hướng dẫn sử dụng các hồ sơ, dữ liệu công việc sẵn có như kế hoạch giáo dục, kết quả theo dõi trẻ, biên bản sinh hoạt chuyên môn, kết quả kiểm tra và nhiệm vụ được giao. Không yêu cầu giáo viên lập thêm báo cáo hoặc thu thập hình ảnh chỉ nhằm chứng minh một công việc đã được ghi nhận đầy đủ.
>
> **Thứ hai, về những tiêu chí không phát sinh hằng tháng:**
>
> Nhà trường thống nhất rằng các nhiệm vụ có tính chất khác nhau phải được đánh giá theo thời điểm và yêu cầu thực hiện tương ứng.
>
> Những công việc như tổ chức hoạt động chăm sóc, giáo dục, bảo đảm an toàn cho trẻ, chấp hành quy chế và thực hiện kế hoạch là nhiệm vụ thường xuyên, cần được theo dõi liên tục.
>
> Trong khi đó, các hoạt động bồi dưỡng, chuyên đề, sáng kiến, cải tiến phương pháp có thể được triển khai theo kế hoạch quý, học kỳ hoặc năm học. Không hợp lý nếu yêu cầu giáo viên phải có một sáng kiến hoặc sản phẩm đổi mới mới trong từng tháng mới được đánh giá hoàn thành tốt.
>
> Đối với nhiệm vụ chưa đến thời điểm thực hiện hoặc chưa được giao, nhà trường không mặc nhiên xác định là không hoàn thành. Việc ghi nhận, tính điểm phải căn cứ kế hoạch và nhiệm vụ thực tế, theo phương pháp được quy định thống nhất trước khi áp dụng.
>
> **Thứ ba, về tính khách quan khi khối lượng công việc không đồng đều:**
>
> Nhà trường thống nhất rằng kết quả công việc của một giáo viên không thể đánh giá đầy đủ chỉ qua một thời điểm ngắn, nhất là khi có nhiệm vụ đột xuất, nghỉ theo chế độ hợp pháp hoặc điều chỉnh kế hoạch.
>
> Vì vậy, việc đánh giá phải căn cứ vào khối lượng, chất lượng, tiến độ của các nhiệm vụ thực tế được giao; xem xét những yếu tố khách quan có căn cứ và kết quả thực hiện trong cả kỳ đánh giá.
>
> Đối với giáo viên nghỉ theo chế độ hợp pháp, nhà trường thực hiện theo quy định tương ứng, đồng thời rà soát, điều chỉnh nhiệm vụ và thời hạn thực hiện khi cần thiết; không mặc nhiên trừ điểm chỉ vì không có sản phẩm công việc trong thời gian nghỉ hợp pháp.
>
> **Thứ tư, về phương án theo dõi tháng, tổng hợp quý:**
>
> Nhà trường thống nhất đây là phương án phù hợp để tiếp tục hoàn thiện quy chế.
>
> Theo đó, hằng tháng, giáo viên và tổ chuyên môn theo dõi tiến độ, chất lượng thực hiện nhiệm vụ, ghi nhận những kết quả nổi bật và những vấn đề cần khắc phục. Việc theo dõi được thực hiện bằng hình thức ngắn gọn, tận dụng dữ liệu sẵn có.
>
> Định kỳ hằng quý, trên cơ sở kết quả công tác đã ghi nhận, nhà trường tổ chức tổng hợp, đối chiếu tiêu chí, đánh giá theo thang điểm quy định và thông báo kết quả cho viên chức.
>
> Việc thực hiện theo quý không có nghĩa là ba tháng mới kiểm tra, nhận xét một lần. Công tác kiểm tra, hướng dẫn, nhắc nhở và hỗ trợ chuyên môn vẫn được duy trì thường xuyên để kịp thời phát hiện, khắc phục hạn chế, nhất là những vấn đề liên quan đến an toàn trẻ và chất lượng chăm sóc, giáo dục.
>
> Như vậy, phương án này vừa bảo đảm tính liên tục trong quản lý, vừa giảm áp lực tổng hợp hồ sơ và tạo điều kiện đánh giá toàn diện hơn.
>
> **Thứ năm, về sai lệch điểm trong Phụ lục KPI:**
>
> Qua đối chiếu, nhà trường xác định ý kiến của giáo viên về sự chưa thống nhất giữa điểm tối đa và các mức điểm thành phần tại A1.2, B1.3 và B1.4 là chính xác.
>
> Nhà trường tiếp thu và điều chỉnh các lỗi kỹ thuật này, đồng thời rà soát toàn bộ bảng KPI để bảo đảm các tiêu chí thành phần cộng đúng điểm của từng nhóm, tổng điểm đánh giá thống nhất là 100 điểm.
>
> Việc chỉnh sửa được thực hiện trước khi áp dụng chính thức nhằm bảo đảm tính chính xác, minh bạch và quyền lợi của viên chức.
>
> **Kết luận và hướng xử lý:**
>
> Nhà trường thống nhất tiếp thu ý kiến góp ý theo hướng:
>
> 1. Duy trì theo dõi công việc hằng tháng; đề xuất tổng hợp, chấm điểm KPI theo quý theo quy định và hướng dẫn áp dụng.
> 2. Không yêu cầu tạo thêm hồ sơ, minh chứng hình thức; ưu tiên sử dụng dữ liệu chuyên môn hiện có.
> 3. Xác định thời điểm đánh giá phù hợp với từng loại nhiệm vụ, không đánh giá bất lợi khi nhiệm vụ chưa phát sinh hoặc chưa đến thời hạn thực hiện.
> 4. Xem xét đầy đủ yếu tố khách quan, nhiệm vụ được điều chỉnh và các chế độ nghỉ hợp pháp.
> 5. Chỉnh sửa sai lệch điểm A1.2, B1.3, B1.4 và rà soát toàn bộ Phụ lục KPI.
> 6. Tổ chức hướng dẫn cách chấm điểm, minh chứng và quyền giải trình trước khi triển khai chính thức.
>
> Nhà trường khẳng định việc đổi mới phương thức đánh giá phải hướng đến nâng cao chất lượng thực hiện nhiệm vụ, chứ không làm phát sinh thêm áp lực hành chính không cần thiết.
>
> **Quan điểm xuyên suốt là đánh giá phải thường xuyên nhưng không hình thức; có minh chứng nhưng không tăng hồ sơ; có thang điểm nhưng không máy móc; bảo đảm công bằng, khách quan và lấy chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ làm trọng tâm.**
>
> **Kết quả giải quyết: TIẾP THU Ý KIẾN VÀ ĐIỀU CHỈNH, HOÀN THIỆN QUY CHẾ.**

## 📋 Những lỗi điểm cần sửa cụ thể

Đối chiếu Phụ lục I của dự thảo, tôi xác nhận như sau:

| Tiêu chí | Điểm đang ghi | Điểm đề xuất sửa |
|--------|--------|--------|
| A1.2 – Chấp hành pháp luật, quy chế, nội quy | 7 | **5** |
| B1.3 – Thực hiện hồ sơ chuyên môn | 10 | **4** |
| B1.4 – Thực hiện các nhiệm vụ khác | 10 | **3** |

Sau khi sửa, nhóm A1 có tổng 15 điểm và nhóm B1 có tổng 20 điểm, đúng cơ cấu của dự thảo.  

Đặc biệt, tiêu chí **A1.2 còn có lỗi chồng lấn mức điểm**: trường hợp 3 vi phạm nhẹ vừa có thể thuộc mức 2 điểm, vừa có thể thuộc mức 0 điểm. Cần sửa lại ranh giới các mức để người chấm không hiểu khác nhau.

## 💡 Đề xuất câu chữ sửa Điều 11 Quy chế đánh giá

Để việc giải trình được thể hiện bằng thay đổi thực tế trong văn bản, tôi đề nghị sửa khoản 1 và khoản 2 Điều 11 theo hướng sau:

> **writing · document**
>
> **Điều 11. Theo dõi, đánh giá kết quả thực hiện nhiệm vụ hằng tháng, hằng quý**
>
> **1.** Nhà trường tổ chức theo dõi kết quả thực hiện nhiệm vụ của viên chức thường xuyên theo tháng; thực hiện tổng hợp, chấm điểm đánh giá định kỳ theo quý trên cơ sở nhiệm vụ được giao, chất lượng, tiến độ và kết quả công việc thực tế. Cơ cấu đánh giá gồm 30 điểm tiêu chí chung và 70 điểm kết quả thực hiện nhiệm vụ theo quy định.
>
> **2.** Việc theo dõi hằng tháng được thực hiện thông qua kế hoạch, hồ sơ chuyên môn, kết quả kiểm tra, sản phẩm công việc và dữ liệu hiện có. Không yêu cầu viên chức lập thêm hồ sơ, minh chứng trùng lặp chỉ để phục vụ đánh giá.
>
> **3.** Đối với các nhiệm vụ thực hiện theo quý, học kỳ hoặc năm học, việc xác định kết quả căn cứ thời hạn và yêu cầu đã được giao. Trường hợp nhiệm vụ chưa phát sinh, thay đổi do quyết định của cấp có thẩm quyền hoặc chịu ảnh hưởng của yếu tố khách quan, người đánh giá phải xem xét trên cơ sở thực tế và hướng dẫn chấm điểm thống nhất; không tự động xác định là không hoàn thành.
>
> **4.** Định kỳ hằng quý, viên chức tự rà soát kết quả; tổ trưởng hoặc người phụ trách nhận xét, đối chiếu minh chứng; Phó Hiệu trưởng phụ trách tổng hợp, tham mưu Hiệu trưởng xem xét theo thẩm quyền. Kết quả được thông tin đến viên chức và bảo đảm quyền giải trình, đề nghị xem xét lại khi có căn cứ.
>
> **5.** Kết quả đánh giá năm được xác định trên cơ sở kết quả theo dõi, đánh giá định kỳ theo Nghị định số 233/2026/NĐ-CP và hướng dẫn của cơ quan có thẩm quyền. Việc tổng hợp phải bảo đảm khách quan, đúng quy trình và phù hợp thời gian công tác thực tế của viên chức.

Lưu ý: Nếu chọn phương án đánh giá theo quý, nhà trường cần sửa đồng bộ tên Phụ lục I hiện đang ghi “hàng tháng”, Điều 11 và nội dung liên quan trong Nghị quyết Hội nghị. Phải thống nhất cách tính điểm quý, cách tổng hợp điểm năm trước khi áp dụng, không chỉ thay cụm từ về thời gian.

**Tôi nghiêng về phương án tiếp thu góp ý này**, bởi nó phù hợp cả Nghị định 233/2026/NĐ-CP lẫn điều kiện thực tế của Trường Mầm non An Bình: vừa có hệ thống đánh giá mới, vừa quản lý đội ngũ tại ba điểm trường sau sáp nhập. Việc giảm thủ tục không làm giảm trách nhiệm của giáo viên; ngược lại, giúp công tác đánh giá tập trung hơn vào chất lượng thực hiện nhiệm vụ.

---

ASSISTANT

---

USER

bạn có thể giải trình dễ hiểu hơn không

---

ASSISTANT

Tôi sẽ diễn đạt lại theo cách **ngắn gọn, dễ hiểu, gần gũi với giáo viên nhưng vẫn thể hiện được quan điểm và trách nhiệm của Hiệu trưởng**. Cô có thể sử dụng trực tiếp khi trả lời tại cuộc họp.

## 📌 Giải trình ý kiến của cô Huỳnh Thị Hồng Hạnh – Lá 3

**Nội dung góp ý:** Việc chấm KPI đầy đủ hằng tháng có thể làm tăng hồ sơ, gây áp lực cho giáo viên. Một số nhiệm vụ không phát sinh mỗi tháng. Đề nghị theo dõi hằng tháng, tổng hợp theo quý và sửa các lỗi cộng điểm trong bảng KPI.

> **writing · standard**
>
> **Ý kiến giải trình của nhà trường:**
>
> Nhà trường ghi nhận và thống nhất rằng những vấn đề giáo viên nêu là có cơ sở, phù hợp với thực tế công việc của giáo viên mầm non.
>
> Trước hết, nhà trường muốn làm rõ: **Mục đích của việc đánh giá KPI là ghi nhận giáo viên thực hiện công việc như thế nào, chứ không phải yêu cầu giáo viên làm thêm nhiều hồ sơ để lấy điểm.**
>
> Vì vậy, những công việc giáo viên đã thực hiện và có minh chứng trong hồ sơ chuyên môn, kế hoạch giáo dục, kết quả kiểm tra hoặc các hoạt động thực tế thì sử dụng làm căn cứ đánh giá, không cần làm thêm một bộ hồ sơ riêng chỉ để chấm KPI.
>
> **Về những tiêu chí không phát sinh hằng tháng**, nhà trường thống nhất rằng không phải tháng nào giáo viên cũng có hội thi, chuyên đề hoặc sáng kiến mới. Do đó, việc đánh giá phải căn cứ nhiệm vụ được giao và thời điểm thực hiện. Không thể vì tháng đó chưa có hội thi hoặc chưa đến thời gian thực hiện chuyên đề mà mặc nhiên đánh giá giáo viên không hoàn thành nhiệm vụ.
>
> **Về đề xuất theo dõi tháng, tổng hợp quý**, nhà trường nhận thấy đây là phương án hợp lý và sẽ xem xét điều chỉnh thống nhất trong quy chế.
>
> Cụ thể, hằng tháng, tổ trưởng và Ban Giám hiệu vẫn theo dõi việc thực hiện nhiệm vụ của giáo viên, kịp thời ghi nhận kết quả, nhắc nhở và hỗ trợ những nội dung chưa đạt. Đến cuối quý, căn cứ kết quả đã theo dõi trong ba tháng để tổng hợp, đối chiếu tiêu chí và đánh giá.
>
> Như vậy, không phải ba tháng mới kiểm tra giáo viên một lần, mà công việc vẫn được theo dõi thường xuyên, chỉ giảm việc tổng hợp, chấm điểm và lập minh chứng lặp đi lặp lại mỗi tháng.
>
> Đối với những trường hợp nghỉ chế độ hợp pháp, thay đổi kế hoạch hoặc phát sinh nhiệm vụ đột xuất, nhà trường sẽ xem xét trên cơ sở nhiệm vụ thực tế và quy định áp dụng, không đánh giá máy móc.
>
> **Về lỗi cộng điểm tại A1.2, B1.3 và B1.4**, qua rà soát, nhà trường xác định có sự chưa thống nhất giữa điểm tối đa và các mức điểm thành phần. Nhà trường tiếp thu và sẽ điều chỉnh trước khi áp dụng chính thức, bảo đảm tổng điểm chính xác và thống nhất cách chấm.
>
> **Kết luận:** Nhà trường tiếp thu ý kiến của giáo viên. Việc hoàn thiện quy chế phải bảo đảm hai yêu cầu: đánh giá đúng chất lượng công việc và không tạo thêm áp lực hồ sơ không cần thiết.
>
> Nhà trường mong giáo viên hiểu rằng KPI là công cụ để ghi nhận kết quả, khuyến khích sự cố gắng và hỗ trợ nâng cao chất lượng công việc, chứ không phải công cụ để tìm lỗi, gây áp lực hoặc làm khó giáo viên.

## 📋 Hướng xử lý cụ thể

| Ý kiến giáo viên | Nhà trường giải quyết |
|--------|--------|
| Chấm KPI hằng tháng gây nhiều hồ sơ | Dùng hồ sơ, kết quả công việc có sẵn; không yêu cầu lập thêm minh chứng trùng lặp |
| Không phải tháng nào cũng có sáng kiến, chuyên đề | Đánh giá theo kế hoạch và thời điểm nhiệm vụ được giao |
| Sợ giáo viên chạy theo điểm số | Chú trọng chất lượng chăm sóc, giáo dục trẻ, không đánh giá chỉ bằng số lượng hồ sơ |
| Công việc từng tháng không đều nhau | Xem xét nhiệm vụ thực tế, trường hợp nghỉ hợp pháp và yếu tố khách quan |
| Đề nghị theo dõi tháng, tổng hợp quý | Tiếp thu phương án, sửa đồng bộ quy chế và phụ lục trước khi áp dụng |
| A1.2, B1.3, B1.4 có lỗi cộng điểm | Sửa lần lượt thành 5 điểm, 4 điểm và 3 điểm |

### 💡 Điều tôi khuyên cô nên nhấn mạnh khi trả lời

Có một câu rất quan trọng, vừa thuyết phục giáo viên, vừa giữ đúng vai trò quản lý:

**“Nhà trường không giảm yêu cầu về chất lượng công việc, mà điều chỉnh cách đánh giá để phản ánh đúng kết quả công việc và giảm những thủ tục không cần thiết cho giáo viên.”**

Câu này giải quyết được cả hai phía: giáo viên thấy ý kiến của mình được lắng nghe, còn Ban Giám hiệu vẫn bảo đảm được trách nhiệm quản lý, kiểm tra và đánh giá theo quy định.

**Lưu ý:** Phương án tổng hợp, chấm điểm theo quý cần được sửa thống nhất tại Điều 11, các phụ lục KPI và nội dung liên quan trước khi thực hiện chính thức; không nên chỉ thống nhất bằng lời tại cuộc họp.

---

USER

---

ASSISTANT

Tôi sẽ làm rõ theo cách giáo viên dễ hiểu: đạt từ 90 điểm có đương nhiên được xếp loại xuất sắc không, nếu vượt tỷ lệ thì xét chọn theo tiêu chí nào, và ai có thẩm quyền quyết định. Tôi cũng sẽ đối chiếu quy định để tránh giải thích sai tỷ lệ 20%–25%.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Điểm cần giải thích rõ với cô Phương Thúy là: **90 điểm là điều kiện để được xem xét mức xuất sắc, nhưng còn phải đáp ứng giới hạn tỷ lệ**. Tỷ lệ 20% không tính đơn giản trên toàn bộ giáo viên; dự thảo đang áp dụng theo nhóm viên chức có nhiệm vụ tương đồng. Tôi cũng đang làm rõ trường hợp người đạt 90 điểm nhưng vượt chỉ tiêu, vì không nên tùy tiện hạ điểm của giáo viên để đủ tỷ lệ.

---

ASSISTANT

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Phương Thúy – Lớp Lá 7

**Nội dung góp ý:** Trường hợp nhiều viên chức đạt từ 90 điểm trở lên, vượt tỷ lệ 20% hoặc 25% theo quy định thì nhà trường xét chọn người hoàn thành xuất sắc nhiệm vụ như thế nào? Đề nghị quy định cụ thể hơn.

**Hướng giải quyết: Tiếp thu ý kiến, bổ sung quy trình xét chọn công khai, minh bạch.**

### Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận và thống nhất với ý kiến của giáo viên về việc cần quy định rõ cách xét chọn viên chức hoàn thành xuất sắc nhiệm vụ khi số người đạt từ 90 điểm trở lên vượt tỷ lệ quy định.
>
> Trước hết, nhà trường làm rõ: **Đạt từ 90 điểm trở lên là điều kiện về điểm số để được xem xét xếp loại hoàn thành xuất sắc nhiệm vụ, nhưng không có nghĩa tất cả những người đạt 90 điểm đều đương nhiên được xếp loại xuất sắc**, vì còn phải thực hiện giới hạn tỷ lệ theo Nghị định số 233/2026/NĐ-CP.
>
> Theo đó, tỷ lệ hoàn thành xuất sắc nhiệm vụ không vượt quá 20% số viên chức được xếp loại hoàn thành tốt nhiệm vụ trong phạm vi và nhóm nhiệm vụ tương đồng theo quy định. Trường hợp nhà trường được cấp có thẩm quyền công nhận hoàn thành xuất sắc nhiệm vụ thì có thể xem xét tỷ lệ cao hơn, nhưng không vượt quá 25%.
>
> **Nếu số viên chức đạt từ 90 điểm trở lên nhiều hơn tỷ lệ cho phép, nhà trường dự kiến thực hiện như sau:**
>
> Trước tiên, rà soát kết quả chấm điểm, đối chiếu minh chứng để bảo đảm chính xác, công bằng giữa các giáo viên.
>
> Sau đó, xem xét lựa chọn những cá nhân có kết quả thực hiện nhiệm vụ nổi trội hơn dựa trên tổng điểm đánh giá, chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ, mức độ hoàn thành nhiệm vụ được giao, hiệu quả đổi mới chuyên môn và những đóng góp thực tế cho nhà trường.
>
> Việc xét chọn phải dựa trên tiêu chí đã được công khai, có minh chứng cụ thể, được trao đổi, nhận xét và thực hiện đúng quy trình. Không lựa chọn theo cảm tính, sự ưu tiên cá nhân hoặc phân chia chỉ tiêu bình quân cho các điểm trường.
>
> Hội đồng hoặc bộ phận được giao nhiệm vụ có trách nhiệm tham mưu, tổng hợp, đề xuất; Hiệu trưởng xem xét, quyết định xếp loại viên chức thuộc thẩm quyền theo quy định.
>
> Đối với những viên chức đạt từ 90 điểm trở lên nhưng vượt tỷ lệ được xếp loại xuất sắc, nhà trường giữ nguyên điểm đánh giá thực tế, không tự ý hạ điểm để phù hợp chỉ tiêu. Việc xác định mức xếp loại chính thức đối với những trường hợp này cần thực hiện theo hướng dẫn của cơ quan có thẩm quyền.
>
> **Kết luận:** Nhà trường tiếp thu ý kiến và sẽ bổ sung quy trình xét chọn cụ thể vào Quy chế đánh giá, xếp loại viên chức nhằm bảo đảm công khai, khách quan, công bằng, ghi nhận đúng sự nỗ lực và kết quả thực hiện nhiệm vụ của từng cá nhân.

### 📖 Ví dụ dễ hiểu để giải thích tại cuộc họp

Giả sử một nhóm viên chức có nhiệm vụ tương đồng có 20 người được xếp loại hoàn thành tốt nhiệm vụ theo quy định.

Tỷ lệ thông thường 20%

# 4 người

Số lượng tối đa được xếp loại xuất sắc trong ví dụ

Tỷ lệ đặc biệt 25%

# 5 người

Chỉ khi đáp ứng điều kiện áp dụng tỷ lệ cao hơn

Nếu có nhiều người đạt từ 90 điểm, nhà trường cần lựa chọn theo kết quả nổi trội và minh chứng thực tế, không chỉ bình chọn bằng biểu quyết.

Đây chỉ là ví dụ minh họa. Khi thực hiện, **mẫu số tính tỷ lệ phải đúng khoản 6 Điều 12 Nghị định 233/2026/NĐ-CP**, không mặc nhiên tính trên tổng số giáo viên toàn trường. [Source unavailable: turn119555search2]

### ⚠️ Một điểm Hiệu trưởng cần lưu ý

Điều 12 Nghị định 233/2026/NĐ-CP quy định mức hoàn thành tốt nhiệm vụ từ 70 đến dưới 90 điểm, trong khi mức xuất sắc bắt đầu từ 90 điểm. Nghị định chưa hướng dẫn rõ cách xếp loại người đạt từ 90 điểm nhưng vượt tỷ lệ xuất sắc. Vì vậy, nhà trường **không nên tự quy định rằng tất cả những người này đương nhiên xếp loại hoàn thành tốt, hoặc tự hạ điểm xuống 89**. Cần đề nghị cơ quan quản lý có thẩm quyền hướng dẫn để bảo đảm quyền lợi viên chức. [Source unavailable: turn119555search1]

**Câu nên nhấn mạnh khi trả lời giáo viên:**

“Nhà trường bảo đảm mỗi giáo viên được ghi nhận đúng kết quả và số điểm thực tế của mình. Việc lựa chọn mức hoàn thành xuất sắc nhiệm vụ phải căn cứ kết quả nổi trội, minh chứng rõ ràng và đúng tỷ lệ pháp luật quy định, không theo cảm tính hay sự ưu tiên cá nhân.”

Cách giải trình này vừa trả lời đúng điều cô Phương Thúy quan tâm, vừa giữ được nguyên tắc quản lý và tránh cam kết một phương án xếp loại chưa đủ căn cứ pháp lý.

> Export note: Interactive layout shown as static text; dynamic content may be unavailable.

---

USER

---

ASSISTANT

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Bé Tý – Lớp Lá 4

**Nội dung góp ý:** Đề nghị làm rõ thế nào là sai sót nhẹ, thế nào là vi phạm nghiêm trọng về an toàn cho trẻ; việc trừ điểm cần căn cứ mức độ vi phạm, nguyên nhân và kết quả xác minh, tránh đánh giá chủ quan.

**Hướng giải quyết: Tiếp thu ý kiến, bổ sung hướng dẫn cụ thể để giáo viên hiểu và thực hiện thống nhất.**

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận và thống nhất với ý kiến đóng góp của giáo viên. Đây là nội dung cần được làm rõ để bảo đảm việc đánh giá khách quan, công bằng và phù hợp thực tế chăm sóc, giáo dục trẻ.
>
> Trước hết, nhà trường khẳng định **an toàn thể chất và tinh thần của trẻ là yêu cầu quan trọng hàng đầu**, vì vậy mọi giáo viên đều có trách nhiệm thực hiện nghiêm túc các quy trình bảo đảm an toàn.
>
> Tuy nhiên, nhà trường cũng thống nhất rằng không phải mọi sai sót đều có tính chất và mức độ như nhau.
>
> **Thứ nhất, về sai sót nhẹ:** Có thể hiểu là những thiếu sót mang tính thủ tục, chưa gây nguy hiểm cho trẻ, được phát hiện và khắc phục ngay. Ví dụ, giáo viên ghi thiếu một nội dung trong phiếu kiểm tra an toàn nhưng thực tế đã kiểm tra đầy đủ và bổ sung kịp thời.
>
> **Thứ hai, về vi phạm nghiêm trọng:** Là những hành vi vi phạm trách nhiệm bảo đảm an toàn, có nguy cơ gây tổn hại nghiêm trọng hoặc đã gây tổn hại cho trẻ. Ví dụ, giáo viên bỏ lớp khiến trẻ không có người giám sát, giao trẻ cho người không được phép đón hoặc có hành vi bạo hành trẻ. Những trường hợp này phải được xác minh rõ trước khi kết luận trách nhiệm.
>
> **Thứ ba, về nguyên tắc trừ điểm:** Nhà trường không căn cứ đơn thuần vào việc có xảy ra sự cố để kết luận giáo viên vi phạm. Khi xem xét phải xác định rõ sự việc, nguyên nhân, trách nhiệm của từng cá nhân, mức độ vi phạm và kết quả xác minh.
>
> Chẳng hạn, nếu trẻ bị tai nạn do nguyên nhân khách quan, giáo viên đã thực hiện đúng quy trình giám sát, phát hiện và xử lý kịp thời thì không thể mặc nhiên xem đó là lỗi của giáo viên để trừ điểm.
>
> Ngược lại, dù chưa xảy ra tai nạn nhưng giáo viên không thực hiện đúng trách nhiệm giám sát, tạo ra nguy cơ mất an toàn nghiêm trọng thì vẫn phải xem xét trách nhiệm theo quy định.
>
> Đối với lớp có hai giáo viên, việc đánh giá cũng phải căn cứ nhiệm vụ được phân công và trách nhiệm thực tế của từng người, không trừ điểm cả hai một cách máy móc.
>
> **Kết luận:** Nhà trường tiếp thu ý kiến, sẽ bổ sung hướng dẫn phân biệt các mức độ sai sót và quy trình xem xét trách nhiệm. Việc trừ điểm phải có căn cứ, có minh chứng, bảo đảm giáo viên được biết nội dung chưa đạt và có quyền giải trình.
>
> Quan điểm của nhà trường là **kiên quyết đối với hành vi vi phạm an toàn trẻ, nhưng phải công bằng đối với giáo viên; không bỏ qua sai phạm, đồng thời không quy kết trách nhiệm khi chưa đủ căn cứ.**

### 📋 Đối chiếu với bảng KPI hiện tại của nhà trường

Tại tiêu chí **B2.1 – Bảo đảm an toàn thể chất, tinh thần cho trẻ**, dự thảo đang quy định:

| Mức điểm | Quy định trong dự thảo |
|--------|--------|
| 10 điểm | Không có sai sót |
| 7 điểm | Có 1 sai sót thủ tục nhẹ, khắc phục ngay, chưa gây nguy hiểm |
| 3 điểm | Có 2 sai sót nhẹ, đã khắc phục |
| 0 điểm | Từ 3 sai sót hoặc 1 vi phạm nghiêm trọng về an toàn thuộc trách nhiệm giáo viên đã được xác minh |

Như vậy, **dự thảo đã phân chia mức điểm, nhưng chưa giải thích đủ rõ cách phân biệt sai sót nhẹ và vi phạm nghiêm trọng**. Đây chính là điểm hợp lý trong góp ý của cô Bé Tý.

### 💡 Đề xuất cách xử lý cụ thể

Tôi đề nghị nhà trường giữ thang điểm B2.1 hiện tại, nhưng bổ sung hướng dẫn thực hiện theo ba nguyên tắc:

1. **Có căn cứ mới trừ điểm:** Phải có kết quả kiểm tra, biên bản, tài liệu hoặc thông tin đã được xác minh; không trừ điểm chỉ dựa vào phản ánh một chiều.
2. **Ai có trách nhiệm thì xem xét người đó:** Xác định trách nhiệm cá nhân và trách nhiệm phối hợp, không tự động quy lỗi cho tất cả giáo viên trong lớp.
3. **Phân biệt việc trừ điểm với xử lý vi phạm:** Nếu có hành vi nghiêm trọng thì thực hiện quy trình xử lý theo quy định; không chỉ dừng ở việc cho 0 điểm tiêu chí B2.1.

Nội dung này cũng phù hợp với yêu cầu phòng ngừa, phát hiện và xử lý nguy cơ mất an toàn theo Thông tư số 45/2021/TT-BGDĐT. [Source unavailable: turn541060search0]

**Câu tôi khuyên cô nên nhấn mạnh tại cuộc họp:**

“Nhà trường không đánh giá giáo viên chỉ dựa vào kết quả xảy ra sự cố, mà phải xem xét giáo viên đã thực hiện trách nhiệm của mình như thế nào. Có sai phạm thì phải xử lý nghiêm, nhưng nếu giáo viên đã làm đúng trách nhiệm thì phải được bảo vệ bằng một quy trình đánh giá công bằng, khách quan.”

Cách giải trình này vừa giữ vững yêu cầu **an toàn tuyệt đối cho trẻ**, vừa giúp giáo viên yên tâm rằng nhà trường không trừ điểm tùy tiện hoặc quy trách nhiệm khi chưa xác minh rõ ràng.

---

USER

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Châu Thị Bé Quyền – Lớp Chồi 1

**Nội dung góp ý:** Gồm hai vấn đề: Quy chế chuyên môn và Quy chế đánh giá, xếp loại viên chức.

**Quan điểm giải quyết:** Tiếp thu những đề xuất hợp lý, làm rõ các nội dung đã có trong quy chế và bổ sung hướng dẫn thực hiện để bảo đảm thống nhất, công bằng tại ba điểm trường.

> **writing · standard**
>
> ### 1. Về Quy chế chuyên môn
>
> Nhà trường ghi nhận và thống nhất với ý kiến của giáo viên về việc giảm hồ sơ trùng lặp, sử dụng hồ sơ điện tử và đổi mới phương pháp giáo dục phù hợp thực tế.
>
> **Thứ nhất, về hồ sơ chuyên môn:**
>
> Tại mục 4.3 Quy chế chuyên môn, nhà trường đã quy định ba loại hồ sơ của giáo viên gồm: kế hoạch nuôi dưỡng, chăm sóc, giáo dục nhóm lớp; sổ theo dõi trẻ; sổ theo dõi tài sản, thiết bị, đồ chơi của nhóm lớp. Đồng thời, quy chế cũng cho phép sử dụng hồ sơ điện tử thay thế hồ sơ giấy khi bảo đảm tính hợp pháp.
>
> Như vậy, nội dung giáo viên đề xuất đã được thể hiện trong quy chế. Nhà trường sẽ tiếp tục hướng dẫn thực hiện thống nhất tại ba điểm trường, không yêu cầu giáo viên ghi chép trùng lặp hoặc thực hiện đồng thời hồ sơ giấy và hồ sơ điện tử có cùng nội dung khi hồ sơ điện tử đã đáp ứng đầy đủ yêu cầu theo quy định.
>
> **Thứ hai, về ứng dụng CNTT, AI và STEAM:**
>
> Nhà trường thống nhất rằng mục tiêu của đổi mới phương pháp là nâng cao chất lượng giáo dục và sự phát triển của trẻ, chứ không phải chạy theo số lượng sản phẩm công nghệ.
>
> Tuy nhiên, trong yêu cầu phát triển chuyên môn hiện nay, giáo viên cũng cần chủ động học hỏi, đổi mới phương pháp và ứng dụng công nghệ phù hợp với nhiệm vụ.
>
> Tại tiêu chí A4.2 của bảng KPI, nhà trường quy định việc vận dụng CNTT, STEAM, AI **hoặc cải tiến phương pháp tổ chức hoạt động giáo dục phù hợp**.
>
> Điều này có nghĩa là giáo viên không bắt buộc phải sử dụng AI hoặc tổ chức hoạt động STEAM mới được ghi nhận kết quả đổi mới. Những cải tiến trong cách tổ chức hoạt động, xây dựng môi trường giáo dục, sử dụng học liệu hoặc hỗ trợ trẻ có hiệu quả thực tế cũng được xem xét đánh giá.
>
> Chẳng hạn, giáo viên thay đổi cách tổ chức hoạt động góc giúp trẻ chủ động, hợp tác tốt hơn cũng là một hình thức đổi mới có giá trị, không nhất thiết phải tạo ra sản phẩm công nghệ.
>
> Về thiết bị và tập huấn, nhà trường sẽ rà soát điều kiện từng điểm trường, tăng cường chia sẻ học liệu dùng chung, tổ chức bồi dưỡng phù hợp và hỗ trợ trong khả năng nguồn lực của đơn vị.
>
> Đồng thời, giáo viên phải thực hiện nghiêm quy định về bảo vệ hình ảnh, thông tin cá nhân của trẻ, không tùy tiện đưa dữ liệu trẻ lên các nền tảng công nghệ hoặc công cụ AI.
>
> **Kết luận: Tiếp thu ý kiến.** Nhà trường sẽ thống nhất cách thực hiện hồ sơ điện tử, giảm ghi chép trùng lặp và đánh giá đổi mới phương pháp dựa trên hiệu quả thực tế, không chạy theo hình thức.
>
> ### 2. Về Quy chế đánh giá, xếp loại viên chức
>
> Nhà trường ghi nhận và thống nhất với ý kiến của giáo viên về việc cần hướng dẫn cụ thể cách chấm điểm KPI, minh chứng và quyền giải trình.
>
> **Thứ nhất, về cách chấm điểm và minh chứng:**
>
> Tại Điều 10 và Điều 11 dự thảo Quy chế đánh giá, nhà trường đã quy định việc đánh giá phải căn cứ nhiệm vụ được giao, kết quả thực hiện và minh chứng phù hợp.
>
> Tuy nhiên, để giáo viên dễ thực hiện, nhà trường sẽ hướng dẫn cụ thể hơn từng tiêu chí, cách xác định điểm và những minh chứng cần thiết.
>
> Minh chứng được sử dụng từ hồ sơ chuyên môn, kế hoạch giáo dục, kết quả kiểm tra và sản phẩm công việc thực tế. Không yêu cầu giáo viên tạo thêm nhiều hồ sơ chỉ để phục vụ chấm điểm.
>
> **Thứ hai, về đánh giá theo tháng hoặc quý:**
>
> Nhà trường dự kiến theo dõi kết quả công việc hằng tháng và xem xét tổng hợp, chấm điểm theo quý để đánh giá toàn diện hơn, hạn chế áp lực hồ sơ.
>
> Việc áp dụng phương án này sẽ được thống nhất trong quy chế và hướng dẫn chính thức.
>
> Đối với nhiệm vụ chưa phát sinh, thay đổi kế hoạch hoặc trường hợp giáo viên nghỉ theo chế độ hợp pháp, việc đánh giá phải căn cứ nhiệm vụ và thời gian công tác thực tế, không tự động trừ điểm một cách máy móc.
>
> **Thứ ba, về quyền giải trình:**
>
> Nhà trường khẳng định việc đánh giá phải công khai, khách quan và có căn cứ.
>
> Khi giáo viên bị trừ điểm, người đánh giá phải chỉ rõ tiêu chí chưa đạt, lý do và minh chứng liên quan. Giáo viên có quyền trao đổi, giải trình, cung cấp minh chứng bổ sung và đề nghị xem xét lại khi có căn cứ.
>
> Tuy nhiên, việc giải trình phải dựa trên kết quả công việc thực tế, không có nghĩa mọi đề nghị đều được điều chỉnh điểm.
>
> **Kết luận: Tiếp thu ý kiến.** Nhà trường sẽ bổ sung hướng dẫn chấm KPI thống nhất, bảo đảm công khai, công bằng và tạo điều kiện để giáo viên thực hiện quyền giải trình theo quy định.
>
> ### Kết luận chung
>
> Nhà trường đánh giá các ý kiến của giáo viên là phù hợp với định hướng nâng cao chất lượng chuyên môn và đổi mới công tác quản lý.
>
> Những nội dung đã có trong quy chế sẽ được hướng dẫn cụ thể hơn; những nội dung chưa rõ sẽ được rà soát, bổ sung.
>
> **Quan điểm của nhà trường là giảm những thủ tục không cần thiết nhưng không giảm yêu cầu chuyên môn; khuyến khích đổi mới nhưng không chạy theo hình thức; đánh giá có tiêu chí, có minh chứng và bảo đảm công bằng đối với mỗi giáo viên.**

### 💡 Lưu ý dành cho Hiệu trưởng

Có hai điểm cô nên nhấn mạnh khi trả lời để giáo viên hiểu đúng:

**Về AI, STEAM:** Không nên nói “AI và STEAM hoàn toàn tự nguyện, không ảnh hưởng KPI”, vì dự thảo đã có tiêu chí A4.2 về đổi mới, sáng tạo. Cần giải thích rằng **đổi mới phương pháp là yêu cầu được đánh giá, nhưng AI và STEAM không phải hai hình thức duy nhất để đạt điểm**.

**Về KPI:** Nhà trường nên ban hành hướng dẫn cụ thể cho từng tiêu chí, tránh mỗi Phó Hiệu trưởng hoặc tổ trưởng hiểu và chấm khác nhau. Đặc biệt, phải thống nhất cách xử lý nhiệm vụ chưa phát sinh và trường hợp khách quan trước khi chấm.

**Câu chốt nên dùng tại cuộc họp:**

“Nhà trường không yêu cầu giáo viên làm thêm nhiều hồ sơ hay sản phẩm công nghệ để chứng minh mình làm tốt. Điều quan trọng là giáo viên thực hiện đúng nhiệm vụ, có đổi mới phù hợp và mang lại hiệu quả thực tế cho trẻ. Khi đánh giá, nhà trường căn cứ vào kết quả đó để ghi nhận công bằng, khách quan.”

Cách giải trình này vừa thể hiện sự tiếp thu, vừa giữ được yêu cầu quản lý chuyên môn và trách nhiệm của giáo viên.

---

USER

Quy chế chuyên môn:** **&#x110;ể giúp giáo viên có sự chủ động tốt nhất trong việc xây dựng kế hoạch giáo dục, chuẩn bị đồ dùng, học liệu cũng như rèn luyện kỹ năng chi trẻ, trong quý chế chuyên môn có thể xem xét và bổ sung thêm mốc thời gian dự kiến cho hội thi của trẻ.

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Nguyễn Thị Thanh Thúy – Lớp Lá 1

**Nội dung góp ý:** Đề nghị bổ sung mốc thời gian dự kiến tổ chức các hội thi của trẻ trong Quy chế chuyên môn để giáo viên chủ động xây dựng kế hoạch giáo dục, chuẩn bị đồ dùng, học liệu và rèn luyện kỹ năng cho trẻ.

**Hướng giải quyết: Tiếp thu ý kiến, nhưng đưa thời gian dự kiến vào kế hoạch chuyên môn thay vì quy định cố định trong Quy chế chuyên môn.**

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận và thống nhất với ý kiến của giáo viên. Việc thông báo sớm thời gian dự kiến tổ chức các hội thi, ngày hội và hoạt động trải nghiệm là cần thiết, giúp giáo viên chủ động xây dựng kế hoạch, chuẩn bị đồ dùng, học liệu và tổ chức các hoạt động phù hợp cho trẻ.
>
> Tuy nhiên, nhà trường cũng làm rõ: **Quy chế chuyên môn là văn bản quy định những nguyên tắc, yêu cầu và trách nhiệm thực hiện nhiệm vụ chuyên môn; còn thời gian tổ chức các hội thi thuộc kế hoạch hoạt động cụ thể của từng năm học.**
>
> Bên cạnh đó, thời gian tổ chức hội thi có thể thay đổi theo chỉ đạo của cấp trên, nhiệm vụ chuyên môn và điều kiện thực tế của nhà trường. Vì vậy, nếu quy định cố định thời gian từng hội thi trong Quy chế chuyên môn sẽ thiếu tính linh hoạt khi tổ chức thực hiện.
>
> **Nhà trường tiếp thu ý kiến theo hướng:** Bộ phận chuyên môn xây dựng lịch dự kiến các hội thi, ngày hội và hoạt động trải nghiệm trong kế hoạch chuyên môn năm học, cụ thể theo tháng hoặc học kỳ; thông báo sớm đến các tổ chuyên môn để giáo viên chủ động chuẩn bị. Khi có điều chỉnh, nhà trường sẽ thông tin kịp thời để giáo viên sắp xếp công việc.
>
> Đồng thời, nhà trường lưu ý việc chuẩn bị cho trẻ tham gia hội thi cần được lồng ghép tự nhiên vào các hoạt động giáo dục hằng ngày, phù hợp độ tuổi và khả năng của trẻ; không tổ chức luyện tập quá mức, gây áp lực hoặc chạy theo thành tích.
>
> **Kết luận:** Nhà trường tiếp thu ý kiến về việc công bố sớm thời gian tổ chức hội thi, nhưng không bổ sung mốc thời gian cố định vào Quy chế chuyên môn mà thể hiện trong kế hoạch chuyên môn năm học để bảo đảm tính chủ động và linh hoạt khi thực hiện.

### 💡 Đề xuất bổ sung vào Quy chế chuyên môn

Để vừa tiếp thu ý kiến giáo viên vừa bảo đảm tính chặt chẽ của văn bản, cô có thể bổ sung một câu:

> “Bộ phận chuyên môn có trách nhiệm xây dựng, thông báo lịch dự kiến tổ chức các hội thi, ngày hội và hoạt động trải nghiệm trong kế hoạch chuyên môn năm học; kịp thời thông tin khi có điều chỉnh, tạo điều kiện để giáo viên chủ động xây dựng kế hoạch và chuẩn bị các điều kiện tổ chức hoạt động phù hợp với trẻ.”

**Điểm thuyết phục nhất cần nhấn mạnh:** Nhà trường không bác bỏ đề xuất của giáo viên mà lựa chọn văn bản phù hợp để thực hiện. **Quy chế quy định trách nhiệm phải thông báo lịch; kế hoạch chuyên môn xác định thời gian dự kiến cụ thể.** Cách làm này vừa đáp ứng mong muốn của giáo viên, vừa thuận lợi trong quản lý, điều hành tại ba điểm trường sau sáp nhập.

---

USER

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Nguyễn Thị Minh Nguyệt – Lớp Chồi 2

**Nội dung góp ý:** Gồm ba vấn đề: Hồ sơ và khối lượng công việc; điều kiện tổ chức thực hiện chương trình giáo dục mầm non; tiêu chí và cách chấm điểm đánh giá viên chức.

**Hướng giải quyết: Tiếp thu ý kiến, làm rõ những quy định đã có và bổ sung hướng dẫn thực hiện phù hợp điều kiện thực tế tại ba điểm trường.**

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> ### 1. Về hồ sơ chuyên môn và khối lượng công việc của giáo viên
>
> Nhà trường ghi nhận và thống nhất với ý kiến của giáo viên về việc cần giảm những hồ sơ, thủ tục trùng lặp để giáo viên có thêm thời gian tập trung chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> Thực tế, việc thực hiện hồ sơ chuyên môn là cần thiết để giáo viên xây dựng kế hoạch, theo dõi sự phát triển của trẻ và phục vụ công tác quản lý, kiểm tra. Tuy nhiên, nhà trường không chủ trương tăng thêm hồ sơ ngoài quy định hoặc yêu cầu giáo viên ghi chép nhiều lần cùng một nội dung.
>
> Tại mục 4.3 Quy chế chuyên môn, nhà trường đã xác định ba loại hồ sơ của giáo viên theo Điều lệ trường mầm non. Đồng thời, quy chế cũng quy định hồ sơ điện tử hợp pháp được sử dụng thay thế hồ sơ giấy tương ứng.
>
> Vì vậy, **nhà trường sẽ thống nhất danh mục hồ sơ, biểu mẫu, hình thức thực hiện và thời hạn hoàn thành tại cả ba điểm trường**, hạn chế tình trạng mỗi tổ, mỗi bộ phận yêu cầu một cách khác nhau.
>
> Về phân công nhiệm vụ, nhà trường thống nhất phải căn cứ vào vị trí việc làm, năng lực, khối lượng công việc và điều kiện thực tế của từng nhóm lớp. Tuy nhiên, giáo viên cũng có trách nhiệm thực hiện đầy đủ những nhiệm vụ chuyên môn và nhiệm vụ khác được phân công hợp pháp.
>
> Nhà trường sẽ rà soát để hạn chế chồng chéo, phân công rõ người, rõ việc, rõ thời hạn; tạo điều kiện cho giáo viên thực hiện tốt nhiệm vụ nhưng vẫn bảo đảm yêu cầu quản lý chung.
>
> **Kết luận: Tiếp thu ý kiến.** Nhà trường sẽ rà soát, thống nhất biểu mẫu và thời hạn thực hiện; giảm những nội dung trùng lặp, không cần thiết nhưng vẫn bảo đảm đầy đủ hồ sơ bắt buộc theo quy định.
>
> ### 2. Về đồ dùng, đồ chơi, thiết bị và quyền chủ động tổ chức hoạt động giáo dục
>
> Nhà trường thống nhất rằng đồ dùng, đồ chơi, thiết bị và học liệu là những điều kiện quan trọng để giáo viên tổ chức thực hiện Chương trình giáo dục mầm non có chất lượng.
>
> Trong Quy chế chuyên môn, nhà trường cũng đã xác định trách nhiệm của cán bộ quản lý và giáo viên trong việc tham mưu, lựa chọn, sử dụng học liệu, đồ dùng, đồ chơi phù hợp.
>
> Tuy nhiên, do nhà trường vừa sáp nhập, điều kiện cơ sở vật chất và trang thiết bị tại ba điểm trường chưa hoàn toàn đồng đều. Việc bổ sung phải căn cứ nhu cầu thực tế, mức độ cần thiết và khả năng kinh phí.
>
> Vì vậy, nhà trường sẽ rà soát những thiết bị còn thiếu, hư hỏng; ưu tiên những điều kiện phục vụ an toàn và hoạt động chăm sóc, giáo dục trẻ. Những thiết bị, học liệu có thể sử dụng chung sẽ được xem xét điều phối để khai thác hiệu quả, tránh lãng phí.
>
> **Về quyền chủ động của giáo viên**, nhà trường thống nhất khuyến khích giáo viên linh hoạt lựa chọn phương pháp, hình thức tổ chức hoạt động phù hợp với độ tuổi, khả năng, nhu cầu và hứng thú của trẻ.
>
> Tuy nhiên, sự chủ động phải bảo đảm mục tiêu, nội dung Chương trình giáo dục mầm non, kế hoạch giáo dục đã được phê duyệt và các yêu cầu về an toàn cho trẻ.
>
> Điều đó có nghĩa là nhà trường thống nhất về mục tiêu và yêu cầu chuyên môn, nhưng không bắt buộc tất cả giáo viên phải tổ chức hoạt động theo một hình thức giống nhau.
>
> **Kết luận: Tiếp thu ý kiến.** Nhà trường sẽ tiếp tục quan tâm bổ sung, điều phối thiết bị và học liệu theo điều kiện thực tế; đồng thời phát huy tính chủ động, sáng tạo của giáo viên trong tổ chức hoạt động giáo dục lấy trẻ làm trung tâm.
>
> ### 3. Về tiêu chí và cách chấm điểm đánh giá, xếp loại viên chức
>
> Nhà trường ghi nhận và thống nhất với ý kiến giáo viên về việc cần hướng dẫn cụ thể, rõ ràng cách chấm điểm KPI, bảo đảm khách quan, công bằng và phù hợp nhiệm vụ được giao.
>
> Tại Điều 7 Quy chế đánh giá, nhà trường đã xác định kết quả thực hiện nhiệm vụ của giáo viên gồm bốn nội dung: số lượng, khối lượng nhiệm vụ; chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ; tiến độ thực hiện; chuyên môn, phối hợp và đổi mới.
>
> Như vậy, **việc đánh giá không chỉ căn cứ vào hồ sơ, báo cáo mà phải xem xét toàn diện kết quả công việc thực tế của giáo viên**.
>
> Ví dụ, giáo viên thực hiện tốt việc chăm sóc, bảo đảm an toàn cho trẻ, tổ chức hoạt động giáo dục có chất lượng, hoàn thành nhiệm vụ đúng thời hạn thì những kết quả đó phải được ghi nhận. Không thể chỉ dựa vào số lượng hình ảnh, sản phẩm hoặc hồ sơ minh chứng để đánh giá chất lượng công việc.
>
> Đối với nhiệm vụ kiêm nhiệm, nhà trường sẽ căn cứ nhiệm vụ được phân công, khối lượng, chất lượng và kết quả thực hiện để đánh giá trong các tiêu chí phù hợp; không bỏ sót nhiệm vụ nhưng cũng không cộng điểm tùy tiện ngoài thang điểm quy định.
>
> Đối với những trường hợp khách quan như thay đổi kế hoạch, nhiệm vụ chưa phát sinh hoặc nghỉ theo chế độ hợp pháp, việc đánh giá phải xem xét theo quy định và nhiệm vụ thực tế, không áp dụng máy móc gây bất lợi cho giáo viên.
>
> Về minh chứng, Điều 10 của dự thảo Quy chế đánh giá đã quy định không tạo thêm hồ sơ hình thức chỉ để phục vụ chấm điểm. Vì vậy, nhà trường sẽ ưu tiên sử dụng những hồ sơ, kết quả kiểm tra và dữ liệu công việc đã có.
>
> Đồng thời, nhà trường sẽ hướng dẫn thống nhất cách chấm từng tiêu chí; giáo viên được biết kết quả, được giải thích nội dung chưa đạt và có quyền giải trình, đề nghị xem xét lại khi có căn cứ.
>
> **Kết luận: Tiếp thu ý kiến.** Nhà trường sẽ bổ sung hướng dẫn cụ thể về tiêu chí, cách chấm điểm và minh chứng để giáo viên dễ thực hiện, bảo đảm đánh giá đúng người, đúng việc, đúng kết quả.
>
> ### Kết luận chung
>
> Nhà trường đánh giá những nội dung góp ý của giáo viên là hợp lý, phù hợp với định hướng nâng cao chất lượng chuyên môn và đổi mới công tác quản lý sau sáp nhập.
>
> Những nội dung đã được quy định sẽ tiếp tục được hướng dẫn rõ hơn; những điểm chưa thống nhất trong quá trình thực hiện sẽ được rà soát, điều chỉnh phù hợp.
>
> **Quan điểm của nhà trường là giảm áp lực hành chính nhưng không giảm trách nhiệm chuyên môn; tạo điều kiện cho giáo viên chủ động, sáng tạo nhưng vẫn bảo đảm thực hiện đúng chương trình; đánh giá công bằng, có căn cứ và chú trọng hiệu quả chăm sóc, nuôi dưỡng, giáo dục trẻ.**

### 💡 Đề xuất xử lý sau giải trình

| Nội dung | Hướng xử lý cụ thể |
|--------|--------|
| Hồ sơ và khối lượng công việc | Giao Phó Hiệu trưởng chuyên môn rà soát, ban hành hướng dẫn chung về hồ sơ, biểu mẫu và thời hạn |
| Thiết bị, đồ chơi, học liệu | Tổ chuyên môn tổng hợp nhu cầu từng lớp; nhà trường kiểm kê, điều phối, bổ sung theo khả năng kinh phí |
| Chấm điểm KPI | Hướng dẫn bằng ví dụ cụ thể, thống nhất minh chứng, cách xem xét nhiệm vụ kiêm nhiệm và yếu tố khách quan |

**Điều tôi khuyên cô nên nhấn mạnh khi trả lời:** Ý kiến của cô Minh Nguyệt chủ yếu đề nghị làm rõ cách tổ chức thực hiện, chứ không yêu cầu thay đổi toàn bộ quy chế. Vì vậy, nhà trường cần **tiếp thu để hoàn thiện hướng dẫn và phương thức quản lý**, đồng thời khẳng định những nội dung phù hợp đã được quy định trong các văn bản hiện có.

Cách giải trình như vậy vừa tôn trọng ý kiến giáo viên, vừa thể hiện rằng Ban Giám hiệu đã có định hướng quản lý rõ ràng, không phải đến khi giáo viên góp ý mới quan tâm các vấn đề này.

---

USER

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Cao Thị Ngọc Nga – Lớp Chồi 8

**Nội dung góp ý:** Đề nghị quy định rõ trách nhiệm của cán bộ quản lý trong việc tiếp nhận, nghiên cứu, triển khai văn bản và phân công nhiệm vụ đúng chức trách, tránh đùn đẩy trách nhiệm cho giáo viên.

**Hướng giải quyết: Tiếp thu ý kiến, làm rõ trách nhiệm của từng vị trí và quy trình triển khai công việc.**

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận ý kiến đóng góp của giáo viên về việc làm rõ trách nhiệm của cán bộ quản lý trong tiếp nhận, nghiên cứu, triển khai văn bản và phân công nhiệm vụ.
>
> Trước hết, nhà trường thống nhất rằng **việc tiếp nhận, nghiên cứu và triển khai văn bản thuộc trách nhiệm của người được phân công phụ trách theo chức năng, nhiệm vụ và thẩm quyền**. Khi triển khai công việc, cán bộ quản lý phải xác định rõ nội dung, yêu cầu, người thực hiện và thời hạn hoàn thành; đồng thời có trách nhiệm hướng dẫn, kiểm tra, hỗ trợ trong quá trình thực hiện.
>
> Tuy nhiên, nhà trường cũng làm rõ rằng **phân công nhiệm vụ cho giáo viên thực hiện không đồng nghĩa với đùn đẩy trách nhiệm**. Trong hoạt động của nhà trường, cán bộ quản lý có trách nhiệm chỉ đạo, tổ chức thực hiện và kiểm tra; giáo viên có trách nhiệm nghiên cứu, thực hiện những nhiệm vụ thuộc vị trí việc làm và công việc được phân công hợp pháp.
>
> Ví dụ, khi có văn bản chỉ đạo về bảo đảm an toàn trường học, Phó Hiệu trưởng phụ trách phải nghiên cứu, xác định yêu cầu và hướng dẫn triển khai; giáo viên có trách nhiệm kiểm tra điều kiện an toàn tại lớp, thực hiện biện pháp phòng ngừa và báo cáo kết quả. Phó Hiệu trưởng tiếp tục theo dõi, tổng hợp và tham mưu xử lý các vấn đề thuộc trách nhiệm quản lý.
>
> Như vậy, mỗi vị trí có trách nhiệm khác nhau nhưng phải phối hợp để hoàn thành nhiệm vụ chung. Cán bộ quản lý không được chuyển những trách nhiệm thuộc thẩm quyền của mình cho giáo viên; đồng thời giáo viên cũng không thể từ chối những nhiệm vụ phù hợp chức trách chỉ vì cho rằng đó là công việc của cán bộ quản lý.
>
> **Đối chiếu Quy chế làm việc của nhà trường**, tại Điều 3 đã quy định mỗi nhiệm vụ phải có một đầu mối chịu trách nhiệm chính, không đùn đẩy công việc; Điều 4, Điều 5 xác định trách nhiệm của Hiệu trưởng và Phó Hiệu trưởng; Điều 14 quy định việc tiếp nhận, xử lý văn bản.
>
> Như vậy, những nội dung giáo viên đề xuất về cơ bản đã được thể hiện trong Quy chế làm việc. Tuy nhiên, nhà trường tiếp thu để cụ thể hóa hơn cách tổ chức thực hiện, bảo đảm mọi nhiệm vụ được giao rõ ràng, đúng chức trách và có sự phối hợp, hướng dẫn kịp thời.
>
> **Kết luận: Nhà trường tiếp thu ý kiến, tiếp tục hoàn thiện hướng dẫn triển khai văn bản và phân công công việc.** Việc giao nhiệm vụ phải rõ người, rõ việc, rõ trách nhiệm; cán bộ quản lý chịu trách nhiệm về công tác chỉ đạo, hướng dẫn, kiểm tra trong phạm vi được giao; giáo viên chịu trách nhiệm về kết quả thực hiện nhiệm vụ của mình.
>
> Mục tiêu là nâng cao hiệu quả phối hợp, tránh chồng chéo hoặc bỏ sót công việc, chứ không phải chuyển trách nhiệm từ bộ phận này sang bộ phận khác.

### 💡 Đề xuất bổ sung vào Điều 14 – Quy chế làm việc

Để giải quyết ý kiến một cách thực chất, cô có thể đề xuất bổ sung nội dung sau:

> “Hiệu trưởng, Phó Hiệu trưởng và người được giao phụ trách có trách nhiệm nghiên cứu, triển khai văn bản thuộc lĩnh vực quản lý; phân công nhiệm vụ phù hợp chức trách, xác định rõ nội dung, thời hạn, người thực hiện và trách nhiệm phối hợp; hướng dẫn, kiểm tra, đôn đốc và chịu trách nhiệm trong phạm vi được giao. Viên chức, người lao động có trách nhiệm nghiên cứu, thực hiện nhiệm vụ được phân công và kịp thời báo cáo những khó khăn, vướng mắc hoặc nội dung vượt thẩm quyền.”

### ✅ Lưu ý khi giải trình tại Hội nghị

Tôi đề nghị cô nhấn mạnh một câu:

**“Giao việc đúng chức trách là trách nhiệm quản lý; thực hiện nhiệm vụ được giao là trách nhiệm của giáo viên. Điều quan trọng là mỗi người phải làm đúng phần việc của mình, không đùn đẩy nhưng cũng không làm thay trách nhiệm của nhau.”**

Cách giải trình này có ba ưu điểm: ghi nhận ý kiến giáo viên, khẳng định những nguyên tắc đã có trong Quy chế làm việc, đồng thời làm rõ trách nhiệm hai chiều. Đặc biệt, **không mặc nhiên thừa nhận đã có tình trạng cán bộ quản lý đùn đẩy công việc khi chưa có sự việc cụ thể được xác minh**, nhưng vẫn thể hiện sự cầu thị và trách nhiệm của Ban Giám hiệu.

---

USER

bạn giải trình nội dung này nghe qua mình thấy CBQL đang đùn đầy trách nhiệm, bạn cần trả lời theo hướng của văn bàn sẽ thuyết phục hơn

---

ASSISTANT

Tôi hiểu ý cô. Với góp ý này, nếu giải trình quá nhiều về việc “không đùn đẩy trách nhiệm” sẽ dễ khiến giáo viên hiểu rằng Ban Giám hiệu đang có tình trạng đó. Trong khi **Quy chế làm việc của nhà trường đã phân định khá rõ trách nhiệm của từng vị trí**.

Vì vậy, nên trả lời theo hướng: **Ghi nhận ý kiến – dẫn chiếu những điều khoản đã quy định – làm rõ cách thực hiện – khẳng định trách nhiệm phối hợp**, thay vì giải trình theo hướng thừa nhận một tồn tại chưa được xác định.

## 📌 Giải trình ý kiến cô Cao Thị Ngọc Nga – Chồi 8

**Nội dung góp ý:** Đề nghị quy định rõ trách nhiệm của cán bộ quản lý trong việc tiếp nhận, nghiên cứu, triển khai văn bản và phân công nhiệm vụ đúng chức trách, tránh đùn đẩy trách nhiệm cho giáo viên.

> **writing · standard**
>
> **Ý kiến giải trình của nhà trường:**
>
> Nhà trường ghi nhận ý kiến đóng góp của giáo viên về việc xác định rõ trách nhiệm trong tiếp nhận, triển khai văn bản và phân công nhiệm vụ.
>
> Qua đối chiếu với Quy chế làm việc năm học 2026–2027, nhà trường đã quy định cụ thể trách nhiệm của từng vị trí:
>
> - **Điều 3:** Quy định mỗi nhiệm vụ có một đầu mối chịu trách nhiệm chính; người được giao chủ trì phải chủ động phối hợp, không đùn đẩy công việc.
> - **Điều 4:** Xác định trách nhiệm của Hiệu trưởng trong quản lý, điều hành chung và phân công nhiệm vụ.
> - **Điều 5:** Quy định Phó Hiệu trưởng chịu trách nhiệm quản lý, hướng dẫn, kiểm tra, đôn đốc và báo cáo kết quả thuộc lĩnh vực được phân công.
> - **Điều 6 và Điều 7:** Xác định trách nhiệm của tổ chuyên môn và giáo viên trong tổ chức, thực hiện nhiệm vụ.
> - **Điều 14:** Quy định việc tiếp nhận, đăng ký, trình xử lý, phát hành và lưu trữ văn bản theo quy định về công tác văn thư.
>
> Như vậy, **Quy chế đã xác định rõ trách nhiệm của cán bộ quản lý, tổ chuyên môn và giáo viên theo từng vị trí công tác**, bảo đảm mỗi nhiệm vụ đều có người phụ trách và có sự phối hợp trong quá trình thực hiện.
>
> Khi có văn bản chỉ đạo, nhà trường thực hiện tiếp nhận, xử lý và phân công theo thẩm quyền; Phó Hiệu trưởng phụ trách lĩnh vực có trách nhiệm tổ chức triển khai, hướng dẫn và kiểm tra; tổ trưởng phối hợp thực hiện; giáo viên thực hiện những nội dung thuộc nhiệm vụ chuyên môn được giao.
>
> Đây là sự phân công trách nhiệm trong tổ chức hoạt động của nhà trường, bảo đảm mỗi bộ phận thực hiện đúng chức năng, nhiệm vụ và cùng chịu trách nhiệm trong phạm vi được giao.
>
> Để việc thực hiện tại ba điểm trường được thống nhất, nhà trường sẽ tiếp tục chú trọng thông tin kịp thời, giao nhiệm vụ rõ nội dung, yêu cầu và thời hạn; đồng thời tạo điều kiện để giáo viên trao đổi khi có nội dung chưa rõ hoặc phát sinh khó khăn trong quá trình thực hiện.
>
> **Kết luận:** Nhà trường ghi nhận ý kiến của giáo viên. Nội dung đề xuất cơ bản đã được quy định tại các điều khoản của Quy chế làm việc. Vì vậy, nhà trường giữ nguyên nguyên tắc đã quy định, đồng thời tiếp tục hướng dẫn, kiểm tra việc thực hiện để bảo đảm phân công đúng chức trách, phối hợp hiệu quả và không chồng chéo nhiệm vụ.

### 💡 Vì sao tôi đề xuất cách giải trình này?

Cách trả lời trên có ba điểm thuyết phục:

**Thứ nhất, có căn cứ cụ thể.** Thay vì chỉ khẳng định Ban Giám hiệu có trách nhiệm, cô chỉ rõ Điều 3, 4, 5, 6, 7 và 14 của Quy chế đã quy định trách nhiệm như thế nào. Giáo viên thấy được nội dung kiến nghị đã được nhà trường quan tâm trong quá trình xây dựng văn bản.

**Thứ hai, giữ đúng vai trò của cán bộ quản lý.** Cán bộ quản lý chịu trách nhiệm chỉ đạo, hướng dẫn, kiểm tra; giáo viên chịu trách nhiệm thực hiện nhiệm vụ chuyên môn được giao. Đây là sự phân công theo chức năng, không nên đồng nhất với việc chuyển trách nhiệm.

**Thứ ba, vẫn thể hiện tinh thần cầu thị.** Nhà trường không bác bỏ ý kiến, mà ghi nhận để nâng cao hiệu quả triển khai, đặc biệt trong điều kiện có ba điểm trường sau sáp nhập.

**Câu chốt tôi khuyên cô dùng tại Hội nghị:**

“Quy chế làm việc đã phân định trách nhiệm cụ thể cho từng vị trí. Điều quan trọng là tổ chức thực hiện đúng quy chế, bảo đảm cán bộ quản lý làm đúng trách nhiệm quản lý, giáo viên thực hiện đúng nhiệm vụ chuyên môn và các bộ phận phối hợp hiệu quả. Nếu quá trình thực hiện có nội dung chưa rõ, nhà trường sẽ xem xét, hướng dẫn và điều chỉnh kịp thời.”

Cách trả lời này **không né tránh trách nhiệm, không mặc nhiên thừa nhận có sai phạm và cũng không tạo cảm giác đối đầu với giáo viên**. Quan trọng hơn, nó thể hiện sự nhất quán giữa văn bản đã ban hành và quan điểm điều hành của Hiệu trưởng.

---

USER

Quy chế xếp loại viên chức: Kiến nghị: Đề nghị nhà trường xem xét bổ sung quy định về việc trao đổi, giải thích rõ các nội dung bị trừ điểm trong quá trình đánh giá, xếp loại viên chức. Giáo viên cần được biết cụ thể những tiêu chí chưa đạt, có cơ hội trao đổi, cung cấp minh chứng và đề xuất xem xét lại khi cần thiết. Qua đó, giúp việc đánh giá được thực hiện công khai, khách quan, phù hợp với tình hình thực tế, tạo sự đồng thuận và động lực để giáo viên phấn đấu hoàn thành tốt nhiệm vụ.

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Nguyễn Thị Huỳnh Như – Lớp Chồi 3

**Nội dung góp ý:** Đề nghị nhà trường quy định rõ việc giải thích các tiêu chí bị trừ điểm KPI; giáo viên được cung cấp minh chứng, trao đổi và đề nghị xem xét lại kết quả đánh giá khi có căn cứ.

**Hướng giải quyết: Ghi nhận ý kiến; các nội dung cơ bản đã được quy định trong dự thảo, nhà trường tiếp tục hướng dẫn cụ thể khi thực hiện.**

### 📖 Căn cứ trong Quy chế đánh giá, xếp loại viên chức

Qua đối chiếu dự thảo, nhà trường đã có các quy định:

- **Điều 2:** Đánh giá phải dân chủ, công khai, công bằng, minh bạch và khách quan.
- **Điều 20, khoản 3:** Tổ trưởng có trách nhiệm trao đổi kịp thời với viên chức khi có hạn chế.
- **Điều 21, khoản 4:** Viên chức có quyền đề nghị làm rõ kết quả đánh giá và kiến nghị.
- **Điều 22:** Viên chức không đồng ý với kết quả xếp loại có quyền kiến nghị với người có thẩm quyền.
- **Phụ lục I, bước 4 và bước 5:** Tổ trưởng đối chiếu minh chứng, trao đổi với giáo viên; Hiệu trưởng hoặc người được phân công xem xét, thông báo kết quả và tiếp nhận giải trình.

Như vậy, quyền được biết kết quả, trao đổi và giải trình **đã được thể hiện trong Quy chế**, không phải nội dung hoàn toàn chưa được quy định.

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận ý kiến đóng góp của giáo viên về việc cần giải thích rõ các tiêu chí chưa đạt và bảo đảm quyền giải trình trong quá trình đánh giá, xếp loại viên chức.
>
> Qua đối chiếu dự thảo Quy chế đánh giá, xếp loại chất lượng viên chức năm học 2026–2027, những nội dung giáo viên đề xuất về cơ bản đã được quy định tại Điều 2, Điều 20, Điều 21, Điều 22 và quy trình đánh giá tại Phụ lục I.
>
> Theo đó, giáo viên được tự đánh giá kết quả thực hiện nhiệm vụ; tổ trưởng có trách nhiệm đối chiếu minh chứng, trao đổi và đề xuất điểm; người có thẩm quyền xem xét, thông báo kết quả và tiếp nhận giải trình.
>
> **Nhà trường làm rõ thêm: Việc chấm điểm KPI không phải là trừ điểm theo cảm nhận của người đánh giá, mà là xác định mức điểm đạt được theo từng tiêu chí, dựa trên kết quả thực hiện nhiệm vụ và minh chứng thực tế.**
>
> Trường hợp kết quả đánh giá thấp hơn mức giáo viên tự chấm, người đánh giá phải chỉ rõ tiêu chí chưa đạt, lý do và căn cứ để giáo viên biết, trao đổi và cung cấp thông tin bổ sung nếu có.
>
> Nếu có sự khác nhau trong nhận định, các bên cần đối chiếu quy định và minh chứng để làm rõ trước khi xác nhận kết quả. Trường hợp giáo viên không đồng ý với kết quả xếp loại đã được thông báo, giáo viên có quyền kiến nghị theo Điều 22 của Quy chế.
>
> Tuy nhiên, việc xem xét lại kết quả phải căn cứ nhiệm vụ được giao, mức độ hoàn thành và minh chứng cụ thể, không có nghĩa mọi trường hợp giáo viên chưa đồng ý đều phải điều chỉnh điểm.
>
> **Kết luận:** Nhà trường ghi nhận ý kiến. Nội dung đề xuất đã được quy định trong dự thảo Quy chế; nhà trường sẽ tiếp tục hướng dẫn cụ thể quy trình trao đổi, giải trình và xem xét kết quả, bảo đảm thực hiện thống nhất, khách quan, công bằng tại cả ba điểm trường.
>
> Mục tiêu của việc đánh giá không chỉ là xác định mức độ hoàn thành nhiệm vụ mà còn giúp giáo viên nhận biết ưu điểm, hạn chế để tiếp tục phát huy, khắc phục và nâng cao chất lượng công tác.

### 💡 Đề xuất hướng xử lý

Tôi đề nghị cô **không cần bổ sung một điều khoản mới có nội dung trùng lặp**, mà nên làm rõ thêm tại bước 4 của quy trình đánh giá trong Phụ lục I:

> “Trường hợp mức điểm do tổ chuyên môn đề xuất khác với mức điểm viên chức tự đánh giá, người nhận xét có trách nhiệm trao đổi, làm rõ tiêu chí, lý do và minh chứng; tiếp nhận ý kiến giải trình của viên chức trước khi tổng hợp, trình người có thẩm quyền xem xét.”

Cách bổ sung này vừa đáp ứng mong muốn của giáo viên, vừa giúp người đánh giá thực hiện đúng trách nhiệm và tránh phát sinh những tranh luận không cần thiết.

**Câu chốt nên sử dụng tại cuộc họp:**

“Nhà trường đã quy định quyền tự đánh giá, trao đổi và giải trình của giáo viên. Khi thực hiện, điểm số phải dựa trên tiêu chí và minh chứng, không phụ thuộc cảm nhận cá nhân. Giáo viên có quyền đề nghị làm rõ, người đánh giá có trách nhiệm giải thích và kết quả cuối cùng phải được quyết định đúng thẩm quyền.”

Đây là cách giải trình **bám sát văn bản, ghi nhận ý kiến mà không làm giáo viên hiểu rằng quy chế hiện tại đang thiếu công khai hoặc nhà trường chấm điểm tùy tiện**.

---

USER

\+ **Quy chế đánh giá viên chức: **&#x54;heo Điều 3, viên chức đạt từ 90 điểm trở lên thì được xếp loại “Hoàn thành xuất sắc nhiệm vụ”. Tuy nhiên, tại Điều 4 quy định tỷ lệ viên chức được xếp loại “Hoàn thành xuất sắc nhiệm vụ” không vượt quá 20% tổng số viên chức được xếp loại “Hoàn thành tốt nhiệm vụ”; trường hợp đặc biệt có thể nâng lên nhưng không vượt quá 25% theo quy định.  
 Vậy xin cho hỏi, trong trường hợp số lượng giáo viên đạt từ 90 điểm trở lên vượt quá tỷ lệ 20% hoặc 25% thì nhà trường sẽ căn cứ vào những tiêu chí cụ thể nào để lựa chọn người được xếp loại “Hoàn thành xuất sắc nhiệm vụ”? Việc lựa chọn sẽ dựa trên tổng số điểm đánh giá, mức độ hoàn thành nhiệm vụ hay các tiêu chí ưu tiên khác? Đồng thời, những giáo viên đạt từ 90 điểm trở lên nhưng không nằm trong tỷ lệ được xếp loại xuất sắc sẽ được xếp loại như thế nào? Kính mong được hướng dẫn cụ thể.

---

ASSISTANT

Tôi sẽ đối chiếu đúng Điều 3, Điều 4 trong dự thảo của trường với Nghị định 233/2026/NĐ-CP, nhất là trường hợp giáo viên đạt từ 90 điểm nhưng vượt tỷ lệ xuất sắc. Phần trả lời sẽ nêu rõ tiêu chí xét chọn, thẩm quyền quyết định và cách xử lý số điểm, tránh cam kết điều chưa có căn cứ pháp lý.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Nguyễn Thị Mỹ Tiên – Lớp Lá 1

**Nội dung góp ý:** Khi có nhiều giáo viên đạt từ 90 điểm trở lên nhưng vượt tỷ lệ 20% hoặc 25%, nhà trường căn cứ vào đâu để lựa chọn người hoàn thành xuất sắc nhiệm vụ? Những giáo viên còn lại được xếp loại như thế nào?

**Hướng giải quyết:** Ghi nhận ý kiến, bổ sung hướng dẫn xét chọn và làm rõ cách xử lý trường hợp vượt tỷ lệ theo quy định.

### 📖 Căn cứ

- **Điều 3 và Điều 4 dự thảo Quy chế của trường** đã quy định thang điểm và giới hạn tỷ lệ xếp loại xuất sắc. 
- **Khoản 1, 2 và 6 Điều 12 Nghị định 233/2026/NĐ-CP** quy định mức điểm xếp loại và tỷ lệ hoàn thành xuất sắc nhiệm vụ. Tỷ lệ thông thường không quá 20% số viên chức được xếp loại hoàn thành tốt nhiệm vụ trong phạm vi cùng đơn vị và nhóm nhiệm vụ tương đồng. Mức tối đa 25% chỉ được xem xét khi đơn vị đáp ứng điều kiện đặc biệt theo Nghị định. [Source unavailable: turn320584view1]

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận ý kiến của giáo viên. Đây là vấn đề cần được hướng dẫn cụ thể để bảo đảm công bằng, khách quan và tạo sự đồng thuận trong đánh giá, xếp loại viên chức.
>
> Trước hết, nhà trường làm rõ: **Giáo viên đạt từ 90 điểm trở lên là đạt điều kiện về điểm số để được xem xét hoàn thành xuất sắc nhiệm vụ. Tuy nhiên, việc xếp loại còn phải bảo đảm giới hạn tỷ lệ theo quy định.**
>
> Vì vậy, nếu số giáo viên đạt từ 90 điểm trở lên nhiều hơn tỷ lệ cho phép thì nhà trường phải xem xét, lựa chọn những cá nhân có kết quả thực hiện nhiệm vụ nổi trội hơn.
>
> Việc xét chọn trước hết phải căn cứ vào tổng điểm đánh giá đã được xác nhận. Trường hợp có điểm số bằng nhau hoặc chênh lệch không đáng kể, cần tiếp tục đối chiếu kết quả thực hiện nhiệm vụ, đặc biệt là chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ; mức độ hoàn thành công việc; hiệu quả đổi mới chuyên môn và những đóng góp thực tế có minh chứng.
>
> Các tiêu chí và thứ tự ưu tiên xét chọn phải được quy định, công khai trước khi thực hiện; không lựa chọn theo cảm tính, quan hệ cá nhân hoặc phân chia chỉ tiêu bình quân giữa các điểm trường.
>
> Tổ chuyên môn và bộ phận được giao nhiệm vụ có trách nhiệm nhận xét, tổng hợp kết quả, tham mưu; Hiệu trưởng xem xét, quyết định xếp loại viên chức thuộc thẩm quyền theo đúng quy định.
>
> **Đối với trường hợp giáo viên đạt từ 90 điểm trở lên nhưng vượt tỷ lệ được xếp loại xuất sắc**, nhà trường vẫn ghi nhận đúng số điểm thực tế, không tự ý hạ điểm để phù hợp chỉ tiêu.
>
> Hiện nay, Nghị định số 233/2026/NĐ-CP quy định mức hoàn thành tốt nhiệm vụ từ 70 đến dưới 90 điểm, nhưng chưa hướng dẫn cụ thể cách xếp loại trường hợp đạt từ 90 điểm trở lên mà vượt tỷ lệ xuất sắc. Vì vậy, nhà trường sẽ đề nghị cơ quan quản lý có thẩm quyền hướng dẫn để thực hiện thống nhất, bảo đảm quyền lợi chính đáng của viên chức.
>
> **Kết luận:** Nhà trường tiếp thu ý kiến, tiếp tục cụ thể hóa nguyên tắc và quy trình xét chọn trong Quy chế đánh giá viên chức. Việc đánh giá phải dựa trên kết quả công việc thực chất, có minh chứng, công khai, minh bạch và thực hiện đúng tỷ lệ pháp luật quy định.

### 💡 Đề xuất xử lý để quy chế chặt chẽ hơn

Tôi đề nghị cô lưu ý ba điểm khi hoàn thiện quy chế:

1. **Điểm số là căn cứ quan trọng đầu tiên**, nhưng khi cần lựa chọn trong số người có điểm cao, phải xem xét chất lượng thực hiện nhiệm vụ và những kết quả nổi trội đã được ghi nhận. Không nên tự đặt thêm tiêu chí ưu tiên sau khi đã có kết quả đánh giá.
2. **Không chia chỉ tiêu cho ba điểm trường theo cách bình quân.** Cần xem xét trong các nhóm viên chức có nhiệm vụ tương đồng theo đúng quy định, bảo đảm cơ hội đánh giá công bằng.
3. **Chưa tự quy định cách xếp loại người đạt 90 điểm trở lên nhưng vượt tỷ lệ.** Điều 4 khoản 3 dự thảo của trường đã xác định việc tính số lượng cụ thể theo hướng dẫn cấp có thẩm quyền. Nhà trường nên tiếp tục xin hướng dẫn bằng văn bản cho tình huống này, tránh phát sinh kiến nghị về sau.

**Câu chốt nên nhấn mạnh tại Hội nghị:**

“Nhà trường không chỉ xét ai đạt 90 điểm, mà phải xem xét ai có kết quả thực hiện nhiệm vụ nổi trội hơn trong phạm vi tỷ lệ được phép. Việc lựa chọn phải có căn cứ, minh chứng và công khai. Những giáo viên không nằm trong tỷ lệ xuất sắc vẫn được ghi nhận nguyên kết quả điểm thực tế; mức xếp loại chính thức sẽ thực hiện theo hướng dẫn của cơ quan có thẩm quyền, không tự ý điều chỉnh điểm hoặc quyền lợi của giáo viên.”

Cách giải trình này trả lời trực tiếp cả hai câu hỏi của giáo viên, đồng thời **thể hiện trách nhiệm của Hiệu trưởng mà không cam kết vượt quá thẩm quyền pháp luật**.

---

USER

Quy chế đánh giá xếp loại viên chức: Trừ điểm là trừ các cô chung lớp hay trừ cá nhân của cô đó.

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Nguyễn Thị Kim Liên – Lớp Chồi 8

**Nội dung góp ý:** Khi xảy ra sai sót, nhà trường trừ điểm cả hai giáo viên cùng lớp hay chỉ trừ điểm giáo viên trực tiếp mắc lỗi?

**Hướng giải quyết:** Làm rõ nguyên tắc đánh giá trách nhiệm cá nhân theo Quy chế, không trừ điểm chung một cách máy móc.

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận ý kiến của giáo viên và xin làm rõ như sau:
>
> Theo Điều 2 và Điều 10 của dự thảo Quy chế đánh giá, xếp loại chất lượng viên chức, việc đánh giá phải bảo đảm khách quan, công bằng, căn cứ vào vị trí việc làm, nhiệm vụ được giao và kết quả thực hiện của từng cá nhân.
>
> **Như vậy, việc chấm điểm KPI là đánh giá đối với từng giáo viên, không phải chấm điểm chung cho cả lớp.**
>
> Đối với lớp có hai giáo viên cùng phụ trách, nếu xảy ra sai sót, nhà trường sẽ xem xét căn cứ vào nhiệm vụ được phân công, trách nhiệm của từng người và kết quả kiểm tra, xác minh.
>
> Trường hợp sai sót thuộc trách nhiệm của một giáo viên thì xem xét điểm của giáo viên đó, không mặc nhiên trừ điểm giáo viên còn lại.
>
> Trường hợp cả hai giáo viên đều có trách nhiệm đối với nội dung xảy ra sai sót thì xem xét mức độ trách nhiệm của từng người, không nhất thiết áp dụng mức trừ điểm giống nhau.
>
> Ví dụ, nếu một giáo viên được phân công thực hiện hồ sơ nhưng để xảy ra thiếu sót thì việc đánh giá căn cứ trách nhiệm của người được giao. Tuy nhiên, đối với nhiệm vụ bảo đảm an toàn cho trẻ, nếu cả hai giáo viên đều không thực hiện đầy đủ trách nhiệm giám sát theo phân công thì phải xem xét trách nhiệm của cả hai.
>
> **Kết luận:** Nhà trường thực hiện đánh giá theo trách nhiệm cá nhân, có căn cứ và minh chứng cụ thể; không trừ điểm đồng loạt chỉ vì giáo viên cùng phụ trách một lớp. Đồng thời, mỗi giáo viên vẫn phải thực hiện đầy đủ trách nhiệm phối hợp trong chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> Nhà trường ghi nhận ý kiến và sẽ hướng dẫn rõ hơn nguyên tắc này để bảo đảm thống nhất, công bằng trong quá trình thực hiện.

### 📖 Căn cứ trong quy chế nhà trường

- **Điều 2:** Đánh giá khách quan, công bằng, dựa trên chức năng, nhiệm vụ và kết quả công việc.
- **Điều 10:** Giao nhiệm vụ cụ thể cho từng viên chức, xác định sản phẩm và yêu cầu thực hiện.
- **Điều 20:** Tổ trưởng nhận xét khách quan, không bình quân, cào bằng.
- **Điều 21 và Điều 22:** Viên chức chịu trách nhiệm về nhiệm vụ được giao và có quyền đề nghị làm rõ, kiến nghị kết quả đánh giá.   

### 💡 Câu chốt nên dùng tại cuộc họp

**“Nhà trường đánh giá từng giáo viên theo trách nhiệm thực tế, không phải một người sai thì cả hai cùng bị trừ điểm. Nhưng đối với nhiệm vụ chung, nếu cả hai đều có thiếu sót thì mỗi người phải chịu trách nhiệm về phần việc của mình.”**

Cách giải trình này vừa rõ ràng, bảo vệ sự công bằng cho giáo viên, vừa giữ được nguyên tắc **trách nhiệm cá nhân gắn với trách nhiệm phối hợp** trong công tác chăm sóc, giáo dục trẻ.

---

USER

+Quy chế chuyên môn: Tôi đề nghị nhà trường tiếp tục rà soát, hoàn thiện quy chế chuyên môn theo hướng rõ ràng, cụ thể, phù hợp với thực tế; thống nhất nội dung, phương pháp chăm sóc, nuôi dưỡng và giáo dục trẻ giữa các điểm trường. Đồng thời chia sẻ kinh nghiệm và phát huy chuyen mon cho giáo viên trẻ và tạo điều kiện để giáo viên thực hiện tốt nhiệm vụ được giao.

+ Quy chế đánh giá, xếp loại viên chức: Tôi đề nghị nhà trường xây dựng quy chế đánh giá, xếp loại viên chức bảo đảm công khai, dân chủ, khách quan và công bằng; các tiêu chí cần cụ thể, rõ ràng, phù hợp với nhiệm vụ của từng cá nhân.

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Tưởng Thị Liễu – Lớp Chồi 4

**Nội dung góp ý:** Gồm hai vấn đề: Hoàn thiện Quy chế chuyên môn, thống nhất hoạt động giữa các điểm trường, bồi dưỡng giáo viên trẻ; bảo đảm công khai, công bằng và phù hợp nhiệm vụ từng cá nhân trong đánh giá viên chức.

**Hướng giải quyết:** Ghi nhận ý kiến; làm rõ những nội dung đã được quy định và cụ thể hóa giải pháp tổ chức thực hiện.

> **writing · standard**
>
> ### 1. Về Quy chế chuyên môn
>
> **Ý kiến giải trình của nhà trường:**
>
> Nhà trường ghi nhận và thống nhất với ý kiến của giáo viên về việc thực hiện Quy chế chuyên môn rõ ràng, phù hợp thực tế và tăng cường chia sẻ kinh nghiệm, bồi dưỡng đội ngũ giáo viên trẻ.
>
> Qua đối chiếu, Quy chế chuyên môn năm học 2026–2027 của nhà trường đã quy định các yêu cầu chung về chăm sóc, nuôi dưỡng, giáo dục trẻ và trách nhiệm thực hiện của cán bộ quản lý, tổ chuyên môn, giáo viên, nhân viên.
>
> Sau sáp nhập, nhà trường thực hiện thống nhất các yêu cầu về chương trình giáo dục, quy trình chăm sóc, nuôi dưỡng, bảo đảm an toàn cho trẻ và công tác quản lý chuyên môn tại cả ba điểm trường.
>
> Tuy nhiên, **thống nhất chuyên môn không có nghĩa là tất cả giáo viên phải thực hiện một phương pháp hoặc tổ chức hoạt động giống nhau**. Giáo viên được chủ động lựa chọn hình thức, phương pháp giáo dục phù hợp với độ tuổi, khả năng của trẻ và điều kiện thực tế của nhóm lớp, nhưng phải bảo đảm mục tiêu, yêu cầu của Chương trình giáo dục mầm non.
>
> Về bồi dưỡng giáo viên trẻ, nhà trường tiếp tục phát huy vai trò của tổ chuyên môn, tăng cường sinh hoạt chuyên môn, dự giờ, chia sẻ kinh nghiệm; tạo điều kiện để giáo viên có kinh nghiệm hướng dẫn, hỗ trợ giáo viên trẻ trong quá trình thực hiện nhiệm vụ.
>
> Đồng thời, mỗi giáo viên cần chủ động học hỏi, trao đổi chuyên môn và vận dụng những kinh nghiệm phù hợp để nâng cao năng lực bản thân.
>
> **Kết luận:** Nhà trường ghi nhận ý kiến. Những nội dung đề xuất cơ bản đã được thể hiện trong Quy chế chuyên môn. Nhà trường tiếp tục chỉ đạo thực hiện thống nhất tại ba điểm trường, tăng cường hỗ trợ và bồi dưỡng đội ngũ, bảo đảm chất lượng chăm sóc, nuôi dưỡng và giáo dục trẻ.
>
> ### 2. Về Quy chế đánh giá, xếp loại chất lượng viên chức
>
> **Ý kiến giải trình của nhà trường:**
>
> Nhà trường ghi nhận và thống nhất với ý kiến của giáo viên về yêu cầu đánh giá viên chức công khai, dân chủ, khách quan, công bằng và phù hợp nhiệm vụ của từng cá nhân.
>
> Qua đối chiếu dự thảo Quy chế đánh giá, xếp loại chất lượng viên chức, các nguyên tắc này đã được quy định tại Điều 2. Đồng thời, Điều 5 đến Điều 9 đã xác định cơ cấu điểm và tiêu chí đánh giá phù hợp với từng nhóm viên chức quản lý, giáo viên và nhân viên.
>
> Theo đó, việc đánh giá được thực hiện trên thang điểm 100, gồm 30 điểm tiêu chí chung và 70 điểm kết quả thực hiện nhiệm vụ.
>
> **Nhà trường làm rõ rằng công bằng trong đánh giá không có nghĩa là tất cả giáo viên đều phải có khối lượng công việc hoặc kết quả điểm số giống nhau.** Việc đánh giá phải căn cứ vào nhiệm vụ được phân công, mức độ hoàn thành, chất lượng, tiến độ và kết quả công việc thực tế của từng cá nhân.
>
> Đối với giáo viên, nhà trường chú trọng kết quả chăm sóc, nuôi dưỡng, giáo dục trẻ; tinh thần trách nhiệm, thực hiện quy chế chuyên môn và các nhiệm vụ được giao. Không đánh giá chỉ dựa trên số lượng hồ sơ hoặc thành tích phong trào.
>
> Để bảo đảm thống nhất trong thực hiện, nhà trường sẽ tiếp tục rà soát, hoàn thiện hướng dẫn chấm điểm KPI, làm rõ minh chứng của từng tiêu chí và tổ chức hướng dẫn cho giáo viên. Khi có nội dung chưa thống nhất, giáo viên được trao đổi, giải trình và đề nghị xem xét kết quả theo quy chế.
>
> **Kết luận:** Nhà trường ghi nhận ý kiến. Các nguyên tắc đánh giá công khai, dân chủ, khách quan và công bằng đã được thể hiện trong dự thảo Quy chế. Nhà trường tiếp tục cụ thể hóa cách chấm điểm và hướng dẫn thực hiện thống nhất, bảo đảm đánh giá đúng nhiệm vụ, đúng kết quả và công bằng đối với từng viên chức.

### 💡 Lưu ý dành cho Hiệu trưởng khi trả lời

Ở trường hợp này, tôi đề nghị cô **không cần giải trình quá dài hoặc nhận định quy chế còn nhiều bất cập**, vì giáo viên chủ yếu góp ý mang tính định hướng, chưa chỉ ra một điều khoản cụ thể cần thay đổi.

Điểm thuyết phục là khẳng định rõ:

- **Về chuyên môn:** Nhà trường thống nhất yêu cầu và chất lượng chung, nhưng linh hoạt phương pháp theo điều kiện từng lớp; quan tâm bồi dưỡng giáo viên trẻ.
- **Về đánh giá:** Quy chế đã có nguyên tắc và tiêu chí cho từng nhóm viên chức; nhà trường sẽ hướng dẫn cụ thể để bảo đảm thực hiện thống nhất, không đánh giá theo cảm tính.

**Câu kết luận chung có thể dùng tại Hội nghị:**

“Nhà trường ghi nhận các ý kiến đóng góp. Những nội dung giáo viên đề xuất cơ bản đã được thể hiện trong các quy chế. Trong quá trình thực hiện, Ban Giám hiệu sẽ tiếp tục hướng dẫn, kiểm tra và hỗ trợ để bảo đảm thống nhất về yêu cầu chuyên môn, công bằng trong đánh giá và phù hợp với điều kiện thực tế của từng điểm trường.”

Cách trả lời này vừa thể hiện tinh thần cầu thị, vừa khẳng định **nhà trường đã có cơ sở quản lý rõ ràng trong các văn bản**, trọng tâm tiếp theo là tổ chức thực hiện hiệu quả.

---

USER

+Quy chế làm việc: Nộp báo cáo hay kế hoạch nếu lỡ sai hay thiếu xoát có cho sữa lại không hay là sai là để không hoàn thành.

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Nguyễn Thị Nhàn – Lớp Mầm 4

**Nội dung góp ý:** Khi giáo viên nộp báo cáo hoặc kế hoạch có sai sót, thiếu nội dung thì có được sửa lại không, hay chỉ cần sai một lần là bị đánh giá không hoàn thành nhiệm vụ?

**Hướng giải quyết:** Làm rõ quy định đã có; cho phép chỉnh sửa, bổ sung và đánh giá theo mức độ sai sót, thời hạn, kết quả khắc phục.

### 📖 Căn cứ trong quy chế của nhà trường

- **Điều 3 Quy chế làm việc:** Việc đánh giá phải căn cứ chức trách, nhiệm vụ và kết quả thực hiện; không quy kết trách nhiệm khi chưa đủ căn cứ.
- **Điều 14 Quy chế làm việc:** Báo cáo phải bảo đảm chính xác, đầy đủ nội dung và đúng thời hạn.
- **Điều 18 Quy chế làm việc:** Việc xem xét trách nhiệm phải căn cứ mức độ lỗi và quy trình theo quy định.
- **Tiêu chí B3.1 của dự thảo KPI:** Quy định mức điểm đối với việc nộp kế hoạch, hồ sơ, báo cáo đúng thời hạn; có xem xét trường hợp nội dung không bảo đảm.

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận ý kiến của giáo viên và làm rõ như sau:
>
> Theo Điều 14 Quy chế làm việc, việc nộp kế hoạch, báo cáo phải bảo đảm đúng thời hạn, chính xác và đáp ứng yêu cầu nội dung. Đây là trách nhiệm của mỗi viên chức trong quá trình thực hiện nhiệm vụ.
>
> Tuy nhiên, **nhà trường không quy định cứ nộp kế hoạch hoặc báo cáo có một sai sót là bị đánh giá không hoàn thành nhiệm vụ.**
>
> Trong quá trình thực hiện, nếu giáo viên có sai sót về chính tả, trình bày, thiếu một số nội dung hoặc nhầm lẫn số liệu thì được chỉnh sửa, bổ sung theo yêu cầu của người phụ trách.
>
> Nếu giáo viên chủ động phát hiện hoặc được góp ý, kịp thời chỉnh sửa đầy đủ, bảo đảm chất lượng và đúng thời hạn thì được ghi nhận kết quả thực hiện sau khi hoàn thiện.
>
> Trường hợp việc chỉnh sửa dẫn đến nộp trễ, sai sót lặp lại nhiều lần, nội dung không đáp ứng yêu cầu hoặc ảnh hưởng đến tiến độ công việc chung thì nhà trường xem xét đánh giá theo mức độ thực tế và tiêu chí đã quy định.
>
> Đối với những sai sót nghiêm trọng liên quan đến tính trung thực của số liệu, an toàn trẻ hoặc việc thực hiện nhiệm vụ, nhà trường phải xem xét trách nhiệm trên cơ sở kiểm tra, xác minh, không xem như lỗi kỹ thuật thông thường.
>
> **Như vậy, cần phân biệt giữa sai sót có thể khắc phục với việc không hoàn thành nhiệm vụ.** Một sai sót trong báo cáo hoặc kế hoạch không đồng nghĩa với việc giáo viên bị xếp loại không hoàn thành nhiệm vụ.
>
> Nhà trường cũng đề nghị giáo viên chủ động kiểm tra kỹ nội dung trước khi nộp, có trách nhiệm tiếp thu góp ý và hoàn thiện đúng thời hạn, tránh tình trạng sai sót lặp lại do thiếu kiểm tra.
>
> **Kết luận:** Nội dung về chất lượng, tiến độ công việc và nguyên tắc đánh giá đã được quy định trong các quy chế. Nhà trường ghi nhận ý kiến và sẽ hướng dẫn rõ hơn việc chỉnh sửa, bổ sung hồ sơ để giáo viên yên tâm thực hiện, đồng thời bảo đảm kỷ luật, trách nhiệm và chất lượng công việc.

### 💡 Một điểm cô nên lưu ý khi hoàn thiện quy chế

Tại tiêu chí **B3.1**, dự thảo có quy định mức 0 điểm đối với trường hợp *“nội dung không đảm bảo”*. Cụm từ này còn khá rộng, có thể khiến giáo viên hiểu rằng chỉ cần một lỗi nhỏ cũng bị 0 điểm tiêu chí.

Tôi đề nghị làm rõ bằng câu sau:

> “Trường hợp kế hoạch, hồ sơ, báo cáo có sai sót, viên chức được yêu cầu chỉnh sửa, bổ sung. Việc đánh giá căn cứ mức độ sai sót, thời hạn hoàn thiện, chất lượng kết quả và ảnh hưởng thực tế đến công việc. Những sai sót nhỏ được khắc phục kịp thời không mặc nhiên bị xác định là không hoàn thành nhiệm vụ.”

Nội dung này là **đề xuất bổ sung hướng dẫn**, chưa phải câu chữ đã có trong quy chế.

**Câu chốt nên dùng tại cuộc họp:**

“Nhà trường luôn tạo điều kiện để giáo viên chỉnh sửa, hoàn thiện công việc. Kiểm tra là để nâng cao chất lượng chứ không phải cứ phát hiện một lỗi là đánh giá không hoàn thành. Tuy nhiên, giáo viên cũng phải có trách nhiệm kiểm tra, khắc phục và hoàn thành đúng thời hạn.”

Cách trả lời này vừa giúp giáo viên yên tâm, vừa giữ được yêu cầu về chất lượng và trách nhiệm trong thực hiện nhiệm vụ.

---

USER

**Quy chế đánh giá viên chức: Chưa rõ còn hoang mang.**

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Trương Hồ Xuân Lan – Lớp Chồi 6

**Nội dung góp ý:** “Quy chế đánh giá viên chức: Chưa rõ, còn hoang mang.”

**Hướng giải quyết:** Ghi nhận ý kiến, làm rõ những nội dung đã quy định và tăng cường hướng dẫn để giáo viên hiểu, thực hiện thống nhất.

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> Nhà trường ghi nhận ý kiến của giáo viên về việc chưa hiểu rõ Quy chế đánh giá, xếp loại chất lượng viên chức.
>
> Đây là năm đầu nhà trường triển khai phương thức đánh giá theo thang điểm KPI, nên giáo viên có thể còn băn khoăn về cách chấm điểm, minh chứng và xác định kết quả đánh giá.
>
> Tuy nhiên, nhà trường cũng làm rõ rằng **các nguyên tắc, tiêu chí, thang điểm và quy trình đánh giá đã được quy định cụ thể trong dự thảo Quy chế**.
>
> Theo đó, viên chức được đánh giá trên thang điểm 100, gồm 30 điểm tiêu chí chung và 70 điểm kết quả thực hiện nhiệm vụ. Đối với giáo viên, việc đánh giá tập trung vào khối lượng, chất lượng, tiến độ công việc, đặc biệt là kết quả chăm sóc, nuôi dưỡng, giáo dục và bảo đảm an toàn cho trẻ.
>
> Việc chấm điểm phải căn cứ nhiệm vụ được giao, kết quả thực hiện và minh chứng phù hợp, không đánh giá theo cảm tính hoặc chỉ dựa vào số lượng hồ sơ.
>
> Đồng thời, quy chế đã quy định trách nhiệm của người đánh giá và quyền được trao đổi, giải trình của viên chức khi có nội dung chưa thống nhất.
>
> **Để giáo viên hiểu và thực hiện thuận lợi hơn**, nhà trường sẽ tổ chức hướng dẫn cụ thể cách chấm điểm từng tiêu chí, cách sử dụng minh chứng và giải đáp các tình huống thường gặp trong thực tế.
>
> Nhà trường cũng đề nghị giáo viên tiếp tục nghiên cứu quy chế, chủ động nêu rõ những tiêu chí hoặc nội dung còn vướng mắc để Ban Giám hiệu và tổ chuyên môn giải thích, hướng dẫn thống nhất.
>
> **Kết luận:** Nhà trường ghi nhận ý kiến. Các nguyên tắc và nội dung đánh giá cơ bản đã được thể hiện trong dự thảo Quy chế. Nhà trường sẽ tiếp tục hướng dẫn cụ thể trước khi áp dụng chính thức, bảo đảm giáo viên hiểu đúng, thực hiện đúng và được đánh giá công khai, khách quan, công bằng.

### 💡 Lưu ý khi giải trình tại cuộc họp

Với ý kiến này, tôi khuyên cô không nên nói rằng quy chế chưa rõ hoặc giáo viên chưa chịu nghiên cứu. Bởi ý kiến “chưa rõ, còn hoang mang” chưa chỉ ra điều khoản cụ thể nào bất cập.

Nên nhấn mạnh:

**“Nhà trường đã xây dựng tiêu chí và quy trình đánh giá trong dự thảo. Tuy nhiên, từ việc có quy định đến việc giáo viên hiểu và thực hiện thống nhất là trách nhiệm chung của Ban Giám hiệu, tổ chuyên môn và mỗi viên chức. Vì vậy, nhà trường sẽ tăng cường hướng dẫn bằng những ví dụ cụ thể để giáo viên nắm chắc cách thực hiện.”**

Như vậy, Hiệu trưởng vừa thể hiện sự cầu thị, vừa khẳng định cơ sở của quy chế và trách nhiệm chủ động nghiên cứu, thực hiện của giáo viên.

---

USER

Quy chế chuyên môn: Tôi thống nhất với nội dung Quy chế chuyên môn. Đề nghị nhà trường tiếp tục tạo điều kiện cho giáo viên tham gia các lớp bồi dưỡng chuyên môn, đổi mới phương pháp tổ chức các hoạt động giáo dục lấy trẻ làm trung tâm, ứng dụng công nghệ thông tin phù hợp và nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ. Đồng thời, cần giảm bớt các hồ sơ, thủ tục không cần thiết để giáo viên có thêm thời gian chăm sóc và tổ chức hoạt động cho trẻ.

+ Quy chế đánh giá, xếp loại viên chức: Đề nghị nhà trường thực hiện việc đánh giá, xếp loại viên chức bảo đảm khách quan, công khai, minh bạch, công bằng và đúng quy định. Các tiêu chí đánh giá cần phù hợp với nhiệm vụ được giao, chú trọng hiệu quả công việc, tinh thần trách nhiệm, đạo đức nghề nghiệp và sự tiến bộ của mỗi cá nhân; đồng thời tạo điều kiện để viên chức phát huy ưu điểm, khắc phục hạn chế và nâng cao năng lực chuyên môn.

---

ASSISTANT

## 📌 Giải trình ý kiến của cô Trần Thị Thúy Liễu – Lớp Mầm 2

**Nội dung góp ý:** Đề nghị tăng cường bồi dưỡng chuyên môn, đổi mới phương pháp giáo dục, giảm hồ sơ không cần thiết; đồng thời bảo đảm đánh giá viên chức công khai, khách quan, công bằng và ghi nhận sự tiến bộ của từng cá nhân.

**Hướng giải quyết:** Ghi nhận, thống nhất với ý kiến; các nội dung cơ bản đã được thể hiện trong hai quy chế. Nhà trường tiếp tục cụ thể hóa trong quá trình tổ chức thực hiện.

### 📝 Nội dung giải trình của Hiệu trưởng

> **writing · standard**
>
> ### 1. Về Quy chế chuyên môn
>
> Nhà trường ghi nhận sự thống nhất và những ý kiến đóng góp của giáo viên.
>
> Qua đối chiếu, Quy chế chuyên môn năm học 2026–2027 đã xác định việc đổi mới phương pháp giáo dục lấy trẻ làm trung tâm, ứng dụng công nghệ thông tin phù hợp, tổ chức sinh hoạt chuyên môn và nâng cao chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ là những nhiệm vụ cần thực hiện.
>
> Về bồi dưỡng chuyên môn, nhà trường tiếp tục tạo điều kiện để giáo viên tham gia các lớp tập huấn, sinh hoạt chuyên đề, dự giờ, trao đổi kinh nghiệm và học hỏi giữa các điểm trường. Tuy nhiên, việc bồi dưỡng cần căn cứ nhu cầu thực tế, năng lực của giáo viên và kế hoạch chuyên môn, bảo đảm thiết thực, hiệu quả.
>
> Bên cạnh sự hỗ trợ của nhà trường, mỗi giáo viên cũng cần phát huy tinh thần tự học, chủ động đổi mới phương pháp và vận dụng kiến thức đã được bồi dưỡng vào thực tế chăm sóc, giáo dục trẻ.
>
> **Về hồ sơ, sổ sách**, tại mục 4.3 Quy chế chuyên môn, nhà trường đã quy định các loại hồ sơ giáo viên phải thực hiện theo Điều lệ trường mầm non, đồng thời cho phép sử dụng hồ sơ điện tử hợp pháp thay thế hồ sơ giấy tương ứng.
>
> Nhà trường không chủ trương yêu cầu giáo viên thực hiện thêm những hồ sơ, thủ tục không cần thiết. Trong quá trình triển khai, Ban Giám hiệu sẽ tiếp tục rà soát, thống nhất biểu mẫu, hạn chế ghi chép trùng lặp để giáo viên có thêm thời gian chăm sóc và tổ chức hoạt động cho trẻ.
>
> **Kết luận:** Nhà trường ghi nhận và thống nhất với ý kiến góp ý. Những nội dung này cơ bản đã được thể hiện trong Quy chế chuyên môn. Nhà trường tiếp tục tổ chức thực hiện phù hợp điều kiện thực tế, tăng cường bồi dưỡng đội ngũ và giảm các thủ tục không cần thiết nhưng vẫn bảo đảm yêu cầu chuyên môn theo quy định.
>
> ### 2. Về Quy chế đánh giá, xếp loại chất lượng viên chức
>
> Nhà trường ghi nhận và thống nhất với ý kiến của giáo viên về việc đánh giá phải công khai, dân chủ, khách quan, công bằng và chú trọng hiệu quả thực hiện nhiệm vụ.
>
> Qua đối chiếu, **Điều 2 dự thảo Quy chế đánh giá đã quy định rõ các nguyên tắc này**. Đồng thời, Điều 5, Điều 6 và Điều 7 đã xác định cụ thể tiêu chí đánh giá theo thang điểm 100, gồm 30 điểm tiêu chí chung và 70 điểm kết quả thực hiện nhiệm vụ.
>
> Trong đó, các tiêu chí đã bao gồm phẩm chất đạo đức nghề nghiệp, tinh thần trách nhiệm, ý thức kỷ luật, sự phối hợp, đổi mới sáng tạo và kết quả thực hiện nhiệm vụ.
>
> Như vậy, việc đánh giá không chỉ căn cứ vào số lượng công việc hoặc hồ sơ mà còn xem xét chất lượng chăm sóc, nuôi dưỡng, giáo dục trẻ và trách nhiệm thực hiện công việc của từng giáo viên.
>
> **Về ghi nhận sự tiến bộ của cá nhân**, nhà trường thống nhất rằng đánh giá không chỉ để xác định mức độ hoàn thành nhiệm vụ mà còn giúp giáo viên nhận biết ưu điểm, hạn chế để tiếp tục phát triển chuyên môn.
>
> Nội dung này cũng đã được thể hiện tại Điều 19 và Điều 20 của dự thảo, trong đó quy định trách nhiệm của Phó Hiệu trưởng và tổ trưởng trong việc theo dõi, nhận xét, hỗ trợ viên chức khắc phục hạn chế.
>
> Tuy nhiên, việc ghi nhận sự tiến bộ phải gắn với kết quả công việc thực tế và các tiêu chí đã quy định, không thay thế yêu cầu về chất lượng, tiến độ và mức độ hoàn thành nhiệm vụ.
>
> Nhà trường sẽ tiếp tục hướng dẫn cách đánh giá, sử dụng minh chứng phù hợp và bảo đảm quyền trao đổi, giải trình của giáo viên khi có nội dung chưa thống nhất.
>
> **Kết luận:** Nhà trường ghi nhận ý kiến. Những nguyên tắc và nội dung giáo viên đề xuất đã được thể hiện trong dự thảo Quy chế đánh giá. Trọng tâm trong thời gian tới là hướng dẫn và tổ chức thực hiện thống nhất, bảo đảm đánh giá đúng nhiệm vụ, đúng kết quả, đồng thời tạo động lực để mỗi giáo viên phát huy ưu điểm, khắc phục hạn chế và nâng cao năng lực chuyên môn.

### 📖 Căn cứ đối chiếu

- **Quy chế chuyên môn:** Mục 4.3 đã quy định ba nhóm hồ sơ giáo viên và việc sử dụng hồ sơ điện tử hợp pháp thay thế hồ sơ giấy; mục 5 đề cập khai thác học liệu và ứng dụng công nghệ phục vụ giáo dục lấy trẻ làm trung tâm. 
- **Quy chế đánh giá viên chức:** Điều 2 quy định nguyên tắc đánh giá; Điều 5–7 xác định tiêu chí và cơ cấu điểm; Điều 19–20 quy định trách nhiệm hướng dẫn, nhận xét, hỗ trợ viên chức khắc phục hạn chế.  

### ✅ Câu kết luận ngắn gọn tại Hội nghị

“Nhà trường ghi nhận và thống nhất với ý kiến giáo viên. Các nội dung về bồi dưỡng chuyên môn, giảm hồ sơ, đánh giá công khai, công bằng và hỗ trợ giáo viên tiến bộ cơ bản đã được thể hiện trong hai quy chế. Vì vậy, nhà trường tiếp tục tập trung tổ chức thực hiện, hướng dẫn cụ thể và kiểm tra hiệu quả, bảo đảm quy chế không chỉ đúng trên văn bản mà còn phù hợp với thực tế của ba điểm trường.”

**Tôi đề xuất kết luận trường hợp này là: “Ghi nhận, thống nhất; tiếp tục cụ thể hóa trong quá trình tổ chức thực hiện”,** thay vì ghi “tiếp thu sửa đổi quy chế”, bởi giáo viên chủ yếu đồng thuận và kiến nghị nâng cao hiệu quả thực hiện, chưa chỉ ra điều khoản cụ thể nào cần sửa đổi.

---

USER

ngắn gọn hơn để dễ hiểu nhé

---

ASSISTANT

> **writing · standard**
>
> **1. Về Quy chế chuyên môn**
>
> Nhà trường ghi nhận và thống nhất với ý kiến giáo viên. Các nội dung về bồi dưỡng chuyên môn, đổi mới phương pháp, ứng dụng công nghệ thông tin và hồ sơ giáo viên đã được quy định trong Quy chế chuyên môn.
>
> Nhà trường sẽ tiếp tục tạo điều kiện cho giáo viên tham gia bồi dưỡng, chia sẻ kinh nghiệm; đồng thời rà soát, giảm hồ sơ trùng lặp để giáo viên tập trung chăm sóc, giáo dục trẻ.
>
> **2. Về Quy chế đánh giá, xếp loại viên chức**
>
> Nhà trường ghi nhận ý kiến. Các nguyên tắc công khai, khách quan, công bằng và tiêu chí đánh giá theo nhiệm vụ đã được quy định tại Điều 2 và các điều từ 5 đến 9 của dự thảo.
>
> Nhà trường sẽ hướng dẫn cách chấm điểm thống nhất, đánh giá dựa trên kết quả công việc thực tế, đồng thời ghi nhận sự tiến bộ và hỗ trợ giáo viên khắc phục hạn chế.
>
> **Kết luận:** Ghi nhận, thống nhất với ý kiến; tiếp tục thực hiện hiệu quả các nội dung đã quy định, phù hợp thực tế nhà trường.

---

