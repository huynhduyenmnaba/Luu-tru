USER

bạn giúp tôi cho màu đỏ nền  sáng hơn một tí. bỏ rèm bên phải. giữ lịa nội dung không thay đổi

---

ASSISTANT

---

USER

bỏ cái rèm bên trái

---

ASSISTANT

---

