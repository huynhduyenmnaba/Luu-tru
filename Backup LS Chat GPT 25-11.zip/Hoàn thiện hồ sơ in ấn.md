USER

hãy giúp mình hoàn thành nội dung này nhé. Đảm bỏa đủ thông tin và xuất sang fiel a4 để tiện in ấn

---

ASSISTANT

Mình đã xem nội dung các tệp. Có một điểm cần xử lý trước khi hoàn thiện: các dự thảo đang mang tên ba trường khác nhau (An Bình, Tràm Chim và Hướng Dương), đồng thời có một số chỗ chưa thống nhất về số văn bản, thời gian và tiêu chí xét chọn. Mình sẽ giữ đúng thông tin có căn cứ, không tự điền kết quả đánh giá hay tên người chưa được cung cấp, và chuẩn hóa nội dung theo mẫu văn bản hành chính khổ A4.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

## 📌 Rà soát và hoàn thiện bộ hồ sơ lựa chọn đối tác liên kết năm học 2026–2027

Mình đã xác định được **5 loại văn bản cần hoàn thiện** từ 6 tệp bạn gửi (trong đó có 2 bản biên bản gần như trùng nhau):

| Văn bản | Trường ghi trong nội dung |
|--------|--------|
| Quyết định thành lập Tổ đánh giá hồ sơ | Mầm non An Bình |
| Biên bản mở hồ sơ, chấm điểm và xét chọn | Mầm non Hướng Dương |
| Biên bản hậu kiểm hồ sơ | Mầm non Tràm Chim |
| Tờ trình phê duyệt kết quả | Mầm non Tràm Chim |
| Thông báo kết quả lựa chọn | Mầm non Tràm Chim |

**⚠️ Một điểm pháp lý quan trọng:** Khoản 2 Điều 4 Thông tư 120/2025/TT-BTC quy định thời gian thông báo công khai ít nhất 15 ngày trước hạn nộp hồ sơ. Trong dự thảo của Trường Mầm non Tràm Chim, thời gian từ ngày thông báo 23/10/2026 đến hạn nộp 02/11/2026 chưa đủ 15 ngày. Cần kiểm tra, xử lý vấn đề này trước khi phê duyệt và công bố kết quả. [trolyluat\.vn](<https://trolyluat.vn/van-ban/thong-tu-1202025tt-btc-huong-dan-nghi-dinh-1862025nd-cp-ve-luat-quan-ly-tai-san-cong-45703>)

Ngoài ra, phải giữ trống các thông tin thực tế chưa được xác nhận như họ tên thành viên Tổ, tên đơn vị dự tuyển, điểm chấm, kết quả hậu kiểm và số quyết định. Không nên tự tạo những dữ liệu này trong văn bản chính thức.

## 🔍 Những nội dung cần chỉnh lý trước khi in, ký

Qua đối chiếu, còn các điểm đáng lưu ý sau:

- **Trường Mầm non An Bình:** Số quyết định ở đầu văn bản ghi `232/QĐ-MNHD`, trong khi phụ lục ghi `232/QĐ-MNAB`. Cần thống nhất ký hiệu `MNAB` và sửa nơi nhận thành UBND phường An Bình.
- **Trường Mầm non Hướng Dương:** Dự thảo sử dụng lẫn các số Kế hoạch 214/317, Thông báo 215/326 và Quyết định 327. Thang điểm nhóm II, III cũng chưa thống nhất; thời gian tiếp nhận hồ sơ còn bắt đầu trước ngày thông báo.
- **Trường Mầm non Tràm Chim:** Cần bổ sung bằng chứng đăng tải, kết quả chấm điểm thực tế và kết luận hậu kiểm; không được mặc định hồ sơ đạt khi chưa kiểm chứng.
- **Cả bộ hồ sơ:** Cần đối chiếu bảng tiêu chí chấm điểm với Phụ lục I Thông tư 120/2025/TT-BTC, đặc biệt quy định về xếp hạng khi bằng điểm, điểm tối thiểu và các trường hợp phải trừ điểm. [trolyluat\.vn](<https://trolyluat.vn/van-ban/thong-tu-1202025tt-btc-huong-dan-nghi-dinh-1862025nd-cp-ve-luat-quan-ly-tai-san-cong-45703>)

Đã xác minh Quyết định 105/2026/QĐ-UBND ngày 11/9/2026 của tỉnh Đồng Tháp về các khoản thu, mức thu và cơ chế quản lý thu, chi đối với dịch vụ phục vụ giáo dục tại cơ sở công lập là văn bản có thật. Tuy nhiên, mức thu cụ thể vẫn phải đối chiếu phụ lục của quyết định và nội dung hoạt động liên kết trước khi điền. [Chi tiết văn bản \- Cổng thông tin điện tử tỉnh Đồng Tháp](<https://www.dongthap.gov.vn/web/cong-thong-tin-dtp/chi-tiet?id=11166701>)

## 📄 Nội dung chỉnh lý để sử dụng trong hồ sơ A4

Dưới đây là các nội dung và biểu mẫu đã biên tập theo hướng sử dụng thực tế. Các vị trí `[…]` là dữ liệu bắt buộc phải điền từ hồ sơ gốc hoặc kết quả làm việc của Tổ đánh giá.

### 1. Quyết định thành lập Tổ đánh giá – Trường Mầm non An Bình

Văn bản gốc đã có cơ bản đầy đủ 6 điều. Phần cần hoàn thiện quan trọng nhất là danh sách nhân sự, thống nhất số ký hiệu, địa danh và phụ lục cam kết. Dưới đây là bản nội dung có thể dùng thay thế.

> **writing · document**
>
> **UBND PHƯỜNG AN BÌNH**  
> **TRƯỜNG MẦM NON AN BÌNH**
>
> Số: 232/QĐ-MNAB
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *An Bình, ngày 12 tháng 10 năm 2026*
>
> # QUYẾT ĐỊNH
>
> **Về việc thành lập Tổ đánh giá hồ sơ lựa chọn đối tác liên kết tổ chức các hoạt động giáo dục ngoài giờ chính khóa, sử dụng tài sản công, năm học 2026–2027**
>
> **HIỆU TRƯỞNG TRƯỜNG MẦM NON AN BÌNH**
>
> Căn cứ Luật Giáo dục năm 2019 và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Luật Quản lý, sử dụng tài sản công số 15/2017/QH14 ngày 21 tháng 6 năm 2017 và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Nghị định số 186/2025/NĐ-CP ngày 01 tháng 7 năm 2025 của Chính phủ quy định chi tiết một số điều của Luật Quản lý, sử dụng tài sản công và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Thông tư số 120/2025/TT-BTC ngày 18 tháng 12 năm 2025 của Bộ trưởng Bộ Tài chính;
>
> Căn cứ Điều lệ Trường mầm non ban hành kèm theo Thông tư số 52/2020/TT-BGDĐT ngày 31 tháng 12 năm 2020, được sửa đổi, bổ sung bởi Thông tư số 51/2026/TT-BGDĐT ngày 30 tháng 6 năm 2026;
>
> Căn cứ Kế hoạch số 230/KH-MNAB ngày 12 tháng 10 năm 2026 của Trường Mầm non An Bình;
>
> Căn cứ Thông báo số 231/TB-MNAB ngày 12 tháng 10 năm 2026 của Trường Mầm non An Bình;
>
> Xét yêu cầu nhiệm vụ và năng lực của cán bộ, giáo viên, nhân viên nhà trường,
>
> **QUYẾT ĐỊNH:**
>
> **Điều 1. Thành lập Tổ đánh giá hồ sơ**
>
> Thành lập Tổ đánh giá hồ sơ lựa chọn đối tác liên kết tổ chức các hoạt động giáo dục ngoài giờ chính khóa, sử dụng tài sản công, năm học 2026–2027, gồm 05 thành viên:
>
> | STT | Họ và tên | Chức vụ | Nhiệm vụ |
> |---|---|---|---|
> | 1 | […] | Phó Hiệu trưởng | Tổ trưởng |
> | 2 | […] | Chủ tịch Công đoàn | Thành viên |
> | 3 | […] | Trưởng Ban Thanh tra nhân dân | Thành viên |
> | 4 | […] | […] | Thành viên kiêm Thư ký |
> | 5 | […] | […] | Thành viên |
>
> Các thành viên làm việc theo chế độ kiêm nhiệm, chịu trách nhiệm trước Hiệu trưởng và trước pháp luật về nhiệm vụ được phân công.
>
> **Điều 2. Nhiệm vụ của Tổ đánh giá**
>
> 1. Nghiên cứu Kế hoạch lựa chọn đối tác, Thông báo mời tham gia và các tiêu chí đánh giá đã công bố; thống nhất phương pháp thực hiện, bảo đảm không thay đổi hoặc bổ sung tiêu chí trái quy định trong quá trình xét chọn.
>
> 2. Kiểm tra Sổ tiếp nhận, Giấy biên nhận, thời điểm nộp và tình trạng niêm phong của từng hồ sơ; tổ chức mở hồ sơ công khai và lập biên bản theo quy định.
>
> 3. Kiểm tra tính đầy đủ, hợp lệ của hồ sơ và các điều kiện bắt buộc; ghi rõ căn cứ, tài liệu đối chiếu và kết quả kiểm tra từng nội dung.
>
> 4. Tổ chức đánh giá, chấm điểm độc lập theo tiêu chí, thang điểm đã được công bố hợp lệ; mỗi thành viên có phiếu đánh giá riêng và chịu trách nhiệm về nhận xét, điểm số của mình.
>
> 5. Trường hợp cần làm rõ hồ sơ, đề xuất yêu cầu đơn vị dự tuyển giải trình bằng văn bản; không tiếp nhận nội dung bổ sung, sửa đổi làm thay đổi bản chất hồ sơ hoặc ảnh hưởng đến tính công bằng.
>
> 6. Tổ chức kiểm tra, xác minh năng lực, chương trình, tài liệu, đội ngũ giáo viên, thiết bị, giải pháp tổ chức hoạt động và các nội dung khác theo hồ sơ dự tuyển.
>
> 7. Tổng hợp phiếu chấm điểm, xác định kết quả đánh giá và thứ tự xếp hạng theo quy định, tiêu chí đã công bố và các yêu cầu pháp luật có liên quan.
>
> 8. Lập biên bản xét chọn; thực hiện hậu kiểm thông tin, tài liệu của đơn vị được đề xuất lựa chọn trước khi trình Hiệu trưởng phê duyệt.
>
> 9. Báo cáo đầy đủ các nội dung chưa thống nhất, dấu hiệu vi phạm, thông tin không chính xác, xung đột lợi ích hoặc tình huống phát sinh để Hiệu trưởng xem xét, xử lý theo thẩm quyền.
>
> 10. Hoàn thiện Tờ trình, hồ sơ đề xuất kết quả lựa chọn; tham gia giải trình, xử lý kiến nghị theo phân công.
>
> 11. Bảo quản, bàn giao đầy đủ hồ sơ dự tuyển, phiếu chấm, biên bản, tài liệu đối chiếu, kết quả xác minh và văn bản liên quan để lưu trữ.
>
> **Điều 3. Phân công trách nhiệm và nguyên tắc làm việc**
>
> 1. Tổ trưởng điều hành hoạt động; phân công nhiệm vụ; chủ trì các cuộc họp, kiểm tra, xét chọn; ký biên bản và báo cáo Hiệu trưởng.
>
> 2. Thư ký chuẩn bị tài liệu, ghi biên bản, phát và thu phiếu chấm, tổng hợp kết quả, theo dõi tiến độ, quản lý hồ sơ và thực hiện công tác lưu trữ.
>
> 3. Các thành viên nghiên cứu hồ sơ, chấm điểm khách quan, độc lập, có căn cứ; ký phiếu chấm và tham gia xác minh theo phân công.
>
> 4. Tổ làm việc theo nguyên tắc công khai, minh bạch, khách quan, công bằng, bảo mật thông tin theo quy định. Mọi cuộc họp, phiên mở hồ sơ và phiên xét chọn đều phải được lập biên bản.
>
> 5. Thành viên Tổ phải ký cam kết không có xung đột lợi ích sau khi biết danh sách đơn vị dự tuyển và trước khi thực hiện đánh giá; kịp thời báo cáo nếu phát sinh quan hệ lợi ích có thể ảnh hưởng đến tính khách quan.
>
> 6. Không được nhận tiền, quà tặng, lợi ích hoặc tiếp xúc riêng với đơn vị dự tuyển về nội dung đánh giá. Mọi yêu cầu làm rõ hồ sơ được thực hiện theo hình thức chính thức, có lưu tài liệu.
>
> 7. Tổ có chức năng tham mưu, đề xuất; không tự phê duyệt kết quả, không tự thay đổi tiêu chí hoặc quyết định những vấn đề thuộc thẩm quyền Hiệu trưởng.
>
> **Điều 4. Thời gian hoạt động**
>
> Tổ đánh giá hoạt động kể từ ngày Quyết định có hiệu lực đến khi hoàn thành việc đánh giá, hậu kiểm, trình kết quả, tham gia giải quyết kiến nghị (nếu có) và bàn giao toàn bộ hồ sơ theo quy định.
>
> **Điều 5. Hiệu lực thi hành**
>
> Quyết định này có hiệu lực kể từ ngày ký.
>
> **Điều 6. Trách nhiệm thi hành**
>
> Các ông (bà) có tên tại Điều 1, các tổ chuyên môn, bộ phận văn phòng và các tổ chức, cá nhân có liên quan chịu trách nhiệm thi hành Quyết định này./.
>
> **Nơi nhận:**
> - Như Điều 6;
> - UBND phường An Bình (để báo cáo);
> - Ban đại diện cha mẹ trẻ (để biết);
> - Lưu: VT, hồ sơ lựa chọn.
>
> **HIỆU TRƯỞNG**  
> *(Ký, ghi rõ họ tên, đóng dấu)*
>
> **Huỳnh Hồng Loan**
>
> ---
>
> # PHỤ LỤC
> *Kèm theo Quyết định số 232/QĐ-MNAB ngày 12 tháng 10 năm 2026*
>
> ## BẢN CAM KẾT KHÔNG CÓ XUNG ĐỘT LỢI ÍCH
>
> Họ và tên: […]
>
> Chức vụ, đơn vị công tác: […]
>
> Nhiệm vụ trong Tổ đánh giá: […]
>
> Sau khi được công bố danh sách các đơn vị tham gia dự tuyển, tôi cam kết:
>
> 1. Không có quan hệ lợi ích trực tiếp hoặc gián tiếp có khả năng ảnh hưởng đến tính khách quan trong việc đánh giá, lựa chọn đối tác.
>
> 2. Không sử dụng nhiệm vụ được giao để tạo lợi thế cho bất kỳ đơn vị dự tuyển nào; không nhận tiền, tài sản, quà tặng hoặc lợi ích dưới bất kỳ hình thức nào từ đơn vị dự tuyển.
>
> 3. Không tham gia chấm điểm khi có căn cứ xác định xung đột lợi ích; nếu phát hiện hoặc phát sinh quan hệ lợi ích, sẽ báo cáo ngay với Hiệu trưởng để xem xét xử lý.
>
> 4. Thực hiện đánh giá độc lập, khách quan, đúng tiêu chí đã công bố; chịu trách nhiệm về nhận xét, kết quả đánh giá và nội dung ký xác nhận.
>
> 5. Bảo mật thông tin, tài liệu và nội dung làm việc theo quy định; không cung cấp thông tin trái thẩm quyền.
>
> 6. Chịu trách nhiệm trước Hiệu trưởng và trước pháp luật về tính trung thực của nội dung cam kết.
>
> *An Bình, ngày […] tháng […] năm 2026*
>
> **NGƯỜI CAM KẾT**  
> *(Ký, ghi rõ họ tên)*
>
> […]

### 2. Bộ biên bản mở hồ sơ và xét chọn – Trường Mầm non Hướng Dương

Hai biên bản được tách riêng để bảo đảm trình tự: mở hồ sơ trước, đánh giá và chấm điểm sau. Bản biên tập dưới đây giữ các thành phần kiểm tra trọng yếu, đồng thời tránh ấn định thang điểm đang mâu thuẫn giữa các dự thảo.

> **writing · document**
>
> **TRƯỜNG MẦM NON HƯỚNG DƯƠNG**  
> **TỔ ĐÁNH GIÁ HỒ SƠ**
>
> Số: […]/BB-TĐG-MNHD
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *Phường Hồng Ngự, ngày […] tháng […] năm 2026*
>
> # BIÊN BẢN MỞ HỒ SƠ DỰ TUYỂN
> **Lựa chọn đối tác liên kết tổ chức các hoạt động giáo dục ngoài giờ chính khóa, sử dụng tài sản công, năm học 2026–2027**
>
> Căn cứ Quyết định số […]/QĐ-MNHD ngày […] của Hiệu trưởng Trường Mầm non Hướng Dương về việc thành lập Tổ đánh giá hồ sơ;
>
> Căn cứ Kế hoạch số 214/KH-MNHD ngày 15/10/2026 và Thông báo số 215/TB-MNHD ngày 15/10/2026 của Trường Mầm non Hướng Dương (số hiệu cần đối chiếu với văn bản đã phát hành);
>
> Căn cứ Sổ tiếp nhận hồ sơ và các Giấy biên nhận của Nhà trường;
>
> Hôm nay, vào lúc […] giờ […] phút, ngày […] tháng […] năm 2026, tại Văn phòng Trường Mầm non Hướng Dương, Tổ đánh giá tiến hành mở hồ sơ dự tuyển.
>
> ## I. THÀNH PHẦN THAM DỰ
>
> **1. Thành viên Tổ đánh giá**
>
> | STT | Họ và tên | Chức vụ | Vai trò | Có mặt |
> |---|---|---|---|---|
> | 1 | […] | Phó Hiệu trưởng | Tổ trưởng | […] |
> | 2 | […] | Phó Hiệu trưởng | Thành viên | […] |
> | 3 | […] | Trưởng Ban Thanh tra nhân dân | Thành viên | […] |
> | 4 | […] | Tổ trưởng Tổ Văn phòng | Thành viên kiêm Thư ký | […] |
> | 5 | […] | Tổ trưởng Tổ Lá | Thành viên | […] |
>
> **2. Đại diện các đơn vị tham gia**
>
> | STT | Tên đơn vị | Họ tên người đại diện | Tư cách đại diện | Ký tên |
> |---|---|---|---|---|
> | 1 | […] | […] | […] | […] |
> | 2 | […] | […] | […] | […] |
> | 3 | […] | […] | […] | […] |
>
> Người khác tham dự (nếu có): […]
>
> ## II. NỘI DUNG THỰC HIỆN
>
> **1. Công bố nguyên tắc làm việc**
>
> Tổ trưởng công bố Quyết định thành lập Tổ đánh giá, thành phần tham dự, quy trình mở hồ sơ, nguyên tắc bảo mật, trách nhiệm của các thành viên và các quy định về phòng ngừa xung đột lợi ích.
>
> **2. Kiểm tra tính thống nhất của hồ sơ mời**
>
> Tổ đối chiếu số hiệu, ngày ban hành của Kế hoạch, Thông báo mời và Phụ lục tiêu chí chấm điểm; ghi nhận:
>
> - Văn bản, phiên bản tiêu chí được sử dụng: […]
> - Ngày đăng tải thông báo công khai: […]
> - Ngày hết hạn tiếp nhận: […]
> - Bằng chứng đăng tải, niêm yết: […]
> - Kết quả kiểm tra thời gian công khai: […]
> - Nội dung sai khác hoặc cần báo cáo Hiệu trưởng: […]
> - Văn bản chỉ đạo, xử lý của cấp có thẩm quyền (nếu có): […]
>
> Tổ không tự điều chỉnh tiêu chí, thang điểm, điều kiện lựa chọn hoặc phương pháp xếp hạng sau khi đã công bố. Trường hợp phát hiện sai khác ảnh hưởng đến kết quả, Tổ lập báo cáo đề nghị xử lý trước khi tiếp tục các bước có liên quan.
>
> **3. Kiểm tra hồ sơ tiếp nhận**
>
> | STT | Tên đơn vị | Thời điểm nhận | Hình thức nộp | Số biên nhận | Trong hạn |
> |---|---|---|---|---|---|
> | 1 | […] | […] | […] | […] | […] |
> | 2 | […] | […] | […] | […] | […] |
> | 3 | […] | […] | […] | […] | […] |
>
> Tổng số hồ sơ tiếp nhận: […] hồ sơ.
>
> Số hồ sơ trong thời hạn: […] hồ sơ.
>
> Số hồ sơ ngoài thời hạn: […] hồ sơ.
>
> Hình thức tiếp nhận khác và cách xử lý (nếu có): […]
>
> **4. Cam kết không có xung đột lợi ích**
>
> Sau khi công bố danh sách các đơn vị nộp hồ sơ, các thành viên Tổ thực hiện ký cam kết không có xung đột lợi ích trước khi tiến hành đánh giá.
>
> Kết quả: […]/05 thành viên đã ký.
>
> Trường hợp phải từ chối tham gia hoặc thay thế thành viên (nếu có): […]
>
> Văn bản xử lý của Hiệu trưởng: […]
>
> ## III. KẾT QUẢ MỞ HỒ SƠ
>
> Tổ thực hiện lần lượt theo thứ tự tiếp nhận. Đối với mỗi đơn vị, lập bảng kiểm tra riêng như sau:
>
> **Đơn vị số […]: […]**
>
> - Người đại diện có mặt: […]
> - Thời điểm bóc hồ sơ: […] giờ […] phút
> - Ngày, giờ tiếp nhận: […]
> - Số Giấy biên nhận: […]
> - Tình trạng niêm phong: […]
> - Nội dung đăng ký: […]
> - Số lượng tập hồ sơ: […]
> - Tổng số trang tài liệu: […]
>
> **Bảng kiểm đếm thành phần hồ sơ**
>
> | STT | Thành phần hồ sơ | Có/Không | Số trang, ghi chú |
> |---|---|---|---|
> | 1 | Đơn đăng ký tham gia liên kết | […] | […] |
> | 2 | Giấy tờ pháp lý, đăng ký kinh doanh, giấy phép liên quan | […] | […] |
> | 3 | Hồ sơ về chương trình, tài liệu và căn cứ được phép triển khai | […] | […] |
> | 4 | Hồ sơ năng lực, kinh nghiệm và hợp đồng tương tự | […] | […] |
> | 5 | Danh sách và giấy tờ chuyên môn của nhân sự dự kiến tham gia | […] | […] |
> | 6 | Phương án tổ chức hoạt động, học liệu, thiết bị và giải pháp số | […] | […] |
> | 7 | Phương án tài chính, mức thu, cơ cấu chi phí và nội dung phân chia | […] | […] |
>
> Hồ sơ, tài liệu khác: […]
>
> Ý kiến của đại diện đơn vị: […]
>
> Ý kiến của Tổ đánh giá: […]
>
> Kết quả kiểm đếm: […]
>
> Biên bản ghi nhận việc có hoặc không có tài liệu, chưa thay thế cho kết luận đạt hay không đạt điều kiện bắt buộc.
>
> ## IV. Ý KIẾN VÀ KIẾN NGHỊ
>
> Ý kiến của các đại diện tham dự: […]
>
> Ý kiến của các thành viên Tổ: […]
>
> Các tình huống phát sinh và hướng xử lý: […]
>
> ## V. KẾT LUẬN
>
> Tổ đánh giá đã tiến hành kiểm tra, mở công khai […] hồ sơ của […] đơn vị; ghi nhận tình trạng niêm phong, các thành phần hồ sơ và ý kiến của những người tham dự.
>
> Hồ sơ được bàn giao cho Thư ký để quản lý và thực hiện bước đánh giá tiếp theo khi bảo đảm các điều kiện cần thiết.
>
> Biên bản kết thúc vào lúc […] giờ […] phút cùng ngày; được đọc lại, thông qua và lập thành […] bản có giá trị như nhau.
>
> **THƯ KÝ**　　　　　　　　　**TỔ TRƯỞNG**  
> *(Ký, ghi rõ họ tên)*　　　　*(Ký, ghi rõ họ tên)*
>
> **CÁC THÀNH VIÊN VÀ ĐẠI DIỆN THAM DỰ**  
> *(Ký, ghi rõ họ tên hoặc ký xác nhận tại danh sách kèm theo)*
>
> ---
>
> # PHỤ LỤC A
> ## CAM KẾT KHÔNG CÓ XUNG ĐỘT LỢI ÍCH
>
> Chúng tôi là thành viên Tổ đánh giá hồ sơ theo Quyết định số […]/QĐ-MNHD ngày […] của Hiệu trưởng Trường Mầm non Hướng Dương.
>
> Sau khi được công bố danh sách các đơn vị tham gia dự tuyển, chúng tôi cam kết:
>
> 1. Không có quan hệ lợi ích làm ảnh hưởng đến tính độc lập, khách quan của việc đánh giá.
> 2. Không nhận tiền, quà tặng, tài trợ hoặc lợi ích từ các đơn vị dự tuyển.
> 3. Không tiếp xúc riêng để trao đổi nội dung đánh giá, chấm điểm hoặc kết quả lựa chọn.
> 4. Thực hiện đúng tiêu chí, phương pháp đánh giá đã công bố hợp lệ.
> 5. Bảo mật thông tin theo quy định và kịp thời báo cáo khi phát sinh xung đột lợi ích.
> 6. Chịu trách nhiệm về tính trung thực của nội dung cam kết.
>
> | STT | Họ và tên | Nhiệm vụ trong Tổ | Thời điểm ký | Ký tên |
> |---|---|---|---|---|
> | 1 | […] | Tổ trưởng | […] | |
> | 2 | […] | Thành viên | […] | |
> | 3 | […] | Thành viên | […] | |
> | 4 | […] | Thư ký | […] | |
> | 5 | […] | Thành viên | […] | |

> **writing · document**
>
> **TRƯỜNG MẦM NON HƯỚNG DƯƠNG**  
> **TỔ ĐÁNH GIÁ HỒ SƠ**
>
> Số: […]/BB-TĐG-MNHD
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *Phường Hồng Ngự, ngày […] tháng […] năm 2026*
>
> # BIÊN BẢN
> **Kiểm tra điều kiện bắt buộc, chấm điểm và xét chọn hồ sơ lựa chọn đối tác liên kết năm học 2026–2027**
>
> Căn cứ Quyết định số […]/QĐ-MNHD ngày […] về việc thành lập Tổ đánh giá hồ sơ;
>
> Căn cứ Kế hoạch, Thông báo mời và Phụ lục tiêu chí được Nhà trường công bố hợp lệ;
>
> Căn cứ Biên bản mở hồ sơ dự tuyển số […] ngày […];
>
> Hôm nay, lúc […] giờ […] phút, ngày […], tại […], Tổ đánh giá tiến hành kiểm tra, đánh giá các hồ sơ dự tuyển.
>
> ## I. THÀNH PHẦN
>
> Các thành viên Tổ đánh giá: […] người.
>
> Thành viên vắng mặt (nếu có): […]
>
> Tình trạng cam kết không có xung đột lợi ích: […]
>
> Các thành phần khác: […]
>
> ## II. NGUYÊN TẮC VÀ PHƯƠNG PHÁP ĐÁNH GIÁ
>
> 1. Đánh giá theo đúng điều kiện bắt buộc, tiêu chí, thang điểm, phương pháp xác định điểm và quy tắc xếp hạng được áp dụng hợp lệ.
>
> 2. Mỗi thành viên chấm điểm độc lập, ghi căn cứ cho điểm vào phiếu riêng và ký xác nhận.
>
> 3. Hồ sơ không đáp ứng điều kiện bắt buộc được ghi rõ lý do và căn cứ; chỉ các hồ sơ đáp ứng yêu cầu mới tiếp tục đánh giá điểm.
>
> 4. Văn bản làm rõ được ghi nhận và lưu kèm hồ sơ; không sử dụng việc làm rõ để thay đổi bản chất hồ sơ.
>
> 5. Kết quả được tổng hợp dựa trên các phiếu đánh giá và tài liệu chứng minh, có đối chiếu các trường hợp phải điều chỉnh hoặc trừ điểm theo quy định áp dụng.
>
> ## III. KIỂM TRA ĐIỀU KIỆN BẮT BUỘC
>
> **Đơn vị được đánh giá: […]**
>
> | STT | Nội dung kiểm tra | Minh chứng | Kết quả |
> |---|---|---|---|
> | 1 | Tư cách pháp lý và phạm vi hoạt động phù hợp | […] | […] |
> | 2 | Tình trạng hoạt động pháp lý, nghĩa vụ và thông tin doanh nghiệp theo yêu cầu đã công bố | […] | […] |
> | 3 | Chương trình, tài liệu, học liệu hợp pháp, phù hợp độ tuổi | […] | […] |
> | 4 | Nhân sự đủ điều kiện chuyên môn, điều kiện an toàn cho trẻ | […] | […] |
> | 5 | Mức thu, phương án tổ chức và các điều kiện bắt buộc khác đã công bố hợp lệ | […] | […] |
>
> Kết luận: […].
>
> Lý do chưa đáp ứng hoặc các vấn đề cần làm rõ: […].
>
> *Lập bảng tương tự cho từng đơn vị tham gia.*
>
> ## IV. KẾT QUẢ CHẤM ĐIỂM
>
> **1. Thang điểm được áp dụng**
>
> Văn bản xác định thang điểm và tiêu chí: […]
>
> | Nhóm tiêu chí | Điểm tối đa | Điểm tối thiểu (nếu có) |
> |---|---:|---:|
> | Nhóm I | […] | […] |
> | Nhóm II | […] | […] |
> | Nhóm III | […] | […] |
> | Nhóm IV | […] | […] |
> | Tổng số | 100 hoặc tổng điểm được xác định hợp lệ | […] |
>
> **2. Kết quả tổng hợp**
>
> | STT | Đơn vị | Nhóm I | Nhóm II | Nhóm III | Nhóm IV | Tổng điểm | Xếp hạng |
> |---|---|---:|---:|---:|---:|---:|---|
> | 1 | […] | […] | […] | […] | […] | […] | […] |
> | 2 | […] | […] | […] | […] | […] | […] | […] |
> | 3 | […] | […] | […] | […] | […] | […] | […] |
>
> Tổng số phiếu đánh giá đã thu: […].
>
> Số phiếu hợp lệ: […].
>
> Phương pháp tính điểm: […].
>
> Kết quả đối chiếu các trường hợp phải trừ điểm, điều chỉnh điểm (nếu có): […].
>
> **3. Giải trình kết quả xếp hạng**
>
> Căn cứ thứ tự tổng điểm và quy tắc xử lý trường hợp bằng điểm theo quy định áp dụng, Tổ đánh giá xác định:
>
> - Đơn vị đứng thứ nhất: […]
> - Tổng điểm: […]
> - Kết quả đáp ứng điều kiện lựa chọn: […]
> - Đơn vị xếp thứ hai: […]
> - Đơn vị xếp thứ ba: […]
>
> Căn cứ, minh chứng cho việc xếp hạng: […].
>
> ## V. KIỂM TRA, XÁC MINH BỔ SUNG
>
> Các nội dung cần đối chiếu trước khi trình Hiệu trưởng:
>
> - Tư cách và tình trạng pháp lý của đơn vị được đề xuất lựa chọn;
> - Văn bản cho phép thực hiện hoạt động giáo dục tương ứng;
> - Tính hợp pháp của chương trình, tài liệu, nhân sự;
> - Kinh nghiệm, năng lực và cam kết tài chính;
> - Điều kiện sử dụng tài sản công;
> - Các thông tin khác có ảnh hưởng đến kết quả xét chọn.
>
> Kết quả: […].
>
> Biên bản hoặc bằng chứng xác minh kèm theo: […].
>
> ## VI. KẾT LUẬN VÀ KIẾN NGHỊ
>
> Sau khi đối chiếu hồ sơ, tài liệu, các phiếu đánh giá và quy định áp dụng, Tổ thống nhất:
>
> 1. Tổng số hồ sơ được tiếp nhận: […].
> 2. Tổng số hồ sơ được đánh giá: […].
> 3. Số hồ sơ đáp ứng điều kiện bắt buộc: […].
> 4. Số hồ sơ không đáp ứng: […].
> 5. Danh sách đơn vị đủ điều kiện xem xét: […].
> 6. Đơn vị được đề xuất lựa chọn (nếu đủ căn cứ): […].
> 7. Các vấn đề cần xử lý trước khi phê duyệt: […].
>
> Tổ đánh giá kính đề nghị Hiệu trưởng xem xét hồ sơ, kết quả hậu kiểm và các vấn đề cần xử lý để quyết định theo thẩm quyền.
>
> Biên bản kết thúc lúc […] giờ […] phút, ngày […]; lập thành […] bản và được các thành viên ký xác nhận.
>
> **THƯ KÝ**　　　　　　　　　**TỔ TRƯỞNG**  
> *(Ký, ghi rõ họ tên)*　　　　*(Ký, ghi rõ họ tên)*
>
> **CÁC THÀNH VIÊN TỔ ĐÁNH GIÁ**  
> *(Ký, ghi rõ họ tên)*
>
> ---
>
> # PHỤ LỤC 1
> ## PHIẾU CHẤM ĐIỂM CÁ NHÂN
>
> Họ và tên thành viên: […]
>
> Đơn vị được chấm: […]
>
> Ngày, giờ chấm: […]
>
> | Mã tiêu chí | Nội dung theo Phụ lục tiêu chí đã công bố | Điểm tối đa | Điểm chấm | Minh chứng, lý do |
> |---|---|---:|---:|---|
> | […] | […] | […] | […] | […] |
> | […] | […] | […] | […] | […] |
> | […] | […] | […] | […] | […] |
> | […] | […] | […] | […] | […] |
>
> Tổng điểm: […].
>
> Nhận xét và kiến nghị: […].
>
> Tôi chịu trách nhiệm về tính khách quan, trung thực và căn cứ của kết quả chấm điểm trên.
>
> **NGƯỜI CHẤM ĐIỂM**  
> *(Ký, ghi rõ họ tên)*

### 3. Biên bản hậu kiểm – Trường Mầm non Tràm Chim

Nội dung giữ đủ 12 hạng mục kiểm tra theo dự thảo; bổ sung cột minh chứng và cách xử lý kết quả không phù hợp.

> **writing · document**
>
> **TRƯỜNG MẦM NON TRÀM CHIM**  
> **TỔ ĐÁNH GIÁ HỒ SƠ**
>
> Số: […]/BB-TĐG-MNTC
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *Tràm Chim, ngày […] tháng 11 năm 2026*
>
> # BIÊN BẢN HẬU KIỂM
> **Hồ sơ đơn vị xếp thứ nhất trong quá trình lựa chọn đối tác liên kết tổ chức hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh, năm học 2026–2027**
>
> Căn cứ Kế hoạch số 148/KH-MNTC ngày 14/10/2026 của Trường Mầm non Tràm Chim;
>
> Căn cứ Thông báo số 160/TB-MNTC ngày 23/10/2026 về việc công khai tiêu chí và mời tham gia liên kết;
>
> Căn cứ Quyết định số […]/QĐ-MNTC ngày […] của Hiệu trưởng về việc thành lập Tổ đánh giá hồ sơ;
>
> Căn cứ Biên bản mở hồ sơ, đánh giá, chấm điểm và xét chọn ngày 02/11/2026;
>
> Hôm nay, vào lúc […] giờ […] phút, ngày […] tháng 11 năm 2026, tại Văn phòng Trường Mầm non Tràm Chim, Tổ đánh giá tiến hành hậu kiểm hồ sơ.
>
> ## I. THÀNH PHẦN THAM DỰ
>
> | STT | Họ và tên | Chức vụ | Vai trò theo Quyết định |
> |---|---|---|---|
> | 1 | […] | […] | Tổ trưởng |
> | 2 | […] | […] | Thành viên |
> | 3 | […] | […] | Thành viên |
> | 4 | […] | […] | Thành viên |
> | 5 | […] | […] | Thư ký |
>
> Đại diện đơn vị được hậu kiểm: […].
>
> Người tham dự khác: […].
>
> Tình trạng cam kết không có xung đột lợi ích: […].
>
> ## II. THÔNG TIN ĐƠN VỊ ĐƯỢC HẬU KIỂM
>
> Tên đơn vị: […].
>
> Mã số thuế/đăng ký kinh doanh: […].
>
> Địa chỉ trụ sở: […].
>
> Người đại diện theo pháp luật: […].
>
> Số điện thoại, email: […].
>
> Nội dung tham gia: Tổ chức hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh.
>
> Tổng điểm được tổng hợp: […].
>
> Thứ tự xếp hạng: […].
>
> ## III. PHƯƠNG PHÁP HẬU KIỂM
>
> Tổ thực hiện kiểm tra, đối chiếu giữa thông tin kê khai trong hồ sơ dự tuyển với các giấy tờ hợp lệ, bản chính (nếu cần), dữ liệu điện tử và thông tin được xác minh từ cơ quan, tổ chức có thẩm quyền.
>
> Khi đối chiếu, ghi rõ:
>
> - Nguồn tài liệu hoặc cơ sở dữ liệu tra cứu.
> - Số, ngày cấp và thời hạn hiệu lực của giấy tờ.
> - Ngày, giờ, người thực hiện xác minh.
> - Nội dung khớp hoặc không khớp.
> - Ảnh chụp kết quả tra cứu, văn bản xác nhận hoặc tài liệu kèm theo.
>
> ## IV. NỘI DUNG VÀ KẾT QUẢ HẬU KIỂM
>
> | STT | Nội dung hậu kiểm | Hình thức, minh chứng | Kết quả |
> |---|---|---|---|
> | 1 | Tư cách pháp lý, đăng ký kinh doanh, ngành nghề phù hợp | […] | […] |
> | 2 | Giấy phép hoạt động liên quan đến lĩnh vực giáo dục, còn hiệu lực nếu thuộc diện phải cấp phép | […] | […] |
> | 3 | Tình trạng hoạt động, đình chỉ, thu hồi, giải thể, phá sản và thông tin nghĩa vụ thuế | […] | […] |
> | 4 | Chương trình, tài liệu làm quen với tiếng Anh và căn cứ cho phép sử dụng | […] | […] |
> | 5 | Văn bằng, chứng chỉ, tiêu chuẩn chuyên môn của giáo viên, người hướng dẫn | […] | […] |
> | 6 | Lý lịch tư pháp hoặc tài liệu chứng minh đáp ứng điều kiện theo quy định | […] | […] |
> | 7 | Giấy tờ liên quan đến giáo viên nước ngoài nếu sử dụng | […] | […] |
> | 8 | Thời gian hoạt động thực tế trong lĩnh vực giáo dục, kinh nghiệm kê khai | […] | […] |
> | 9 | Hợp đồng liên kết tương tự và tài liệu chứng minh năng lực thực hiện | […] | […] |
> | 10 | Mức thu đề xuất và căn cứ pháp lý về mức thu áp dụng | […] | […] |
> | 11 | Phương án tài chính, tỷ lệ phân chia, cam kết với Nhà trường | […] | […] |
> | 12 | Tính trung thực của các cam kết, kê khai và việc phòng ngừa xung đột lợi ích | […] | […] |
>
> **Ghi chú kết luận đối với từng mục:** Đạt/Không đạt/Không áp dụng/Chưa đủ căn cứ. Không để trống kết quả của mục có ảnh hưởng đến việc lựa chọn.
>
> ## V. KẾT QUẢ TỔNG HỢP
>
> Số nội dung đã kiểm tra: […].
>
> Số nội dung phù hợp: […].
>
> Số nội dung không phù hợp: […].
>
> Số nội dung không áp dụng: […].
>
> Số nội dung chưa đủ căn cứ xác minh: […].
>
> Các sai khác so với hồ sơ kê khai: […].
>
> Ảnh hưởng của các sai khác đến điều kiện tham gia hoặc điểm số: […].
>
> Ý kiến của đơn vị được hậu kiểm: […].
>
> Tài liệu kèm theo:
>
> 1. Bảng kê tài liệu đã đối chiếu.
> 2. Bản sao hoặc hình ảnh kết quả tra cứu.
> 3. Văn bản làm rõ, xác minh (nếu có).
> 4. Tài liệu chứng minh các nội dung liên quan đến kết quả đánh giá.
>
> ## VI. KẾT LUẬN VÀ KIẾN NGHỊ
>
> Căn cứ kết quả đối chiếu, Tổ đánh giá ghi nhận:
>
> - Mức độ trung thực, chính xác của hồ sơ: […].
> - Các điều kiện bắt buộc đã được xác minh: […].
> - Các thông tin có ảnh hưởng đến điểm số và xếp hạng: […].
> - Những vấn đề chưa thể kết luận: […].
>
> **Đề xuất của Tổ đánh giá:** […].
>
> Trường hợp hồ sơ đủ điều kiện, Tổ báo cáo và đề nghị Hiệu trưởng xem xét kết quả lựa chọn theo thẩm quyền.
>
> Trường hợp phát hiện thông tin không chính xác, giả mạo hoặc chưa đủ căn cứ xác minh, Tổ báo cáo đầy đủ nội dung, bằng chứng và kiến nghị hướng xử lý; không tự ý công nhận kết quả khi chưa có đủ cơ sở.
>
> Biên bản kết thúc lúc […] giờ […] phút cùng ngày; được đọc lại cho những người tham dự cùng nghe và ký xác nhận.
>
> Biên bản lập thành […] bản có giá trị như nhau.
>
> **THƯ KÝ**　　　　　　　　　**TỔ TRƯỞNG**  
> *(Ký, ghi rõ họ tên)*　　　　*(Ký, ghi rõ họ tên)*
>
> **CÁC THÀNH VIÊN**  
> *(Ký, ghi rõ họ tên)*
>
> **ĐẠI DIỆN ĐƠN VỊ ĐƯỢC HẬU KIỂM (NẾU CÓ)**  
> *(Ký, ghi rõ họ tên)*

### 4. Tờ trình phê duyệt kết quả – Trường Mầm non Tràm Chim

Bản này bổ sung mục rà soát điều kiện phê duyệt để Hiệu trưởng có cơ sở quyết định, tránh ký khi hồ sơ chưa đủ điều kiện.

> **writing · document**
>
> **TRƯỜNG MẦM NON TRÀM CHIM**  
> **TỔ ĐÁNH GIÁ HỒ SƠ**
>
> Số: […]/TTr-TĐG
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *Tràm Chim, ngày […] tháng 11 năm 2026*
>
> # TỜ TRÌNH
> **Về việc xem xét, phê duyệt kết quả lựa chọn đối tác liên kết tổ chức hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh, năm học 2026–2027**
>
> **Kính gửi: Hiệu trưởng Trường Mầm non Tràm Chim.**
>
> Căn cứ Luật Quản lý, sử dụng tài sản công và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Nghị định số 186/2025/NĐ-CP ngày 01/7/2025 của Chính phủ và các văn bản sửa đổi, bổ sung;
>
> Căn cứ Thông tư số 120/2025/TT-BTC ngày 18/12/2025 của Bộ trưởng Bộ Tài chính;
>
> Căn cứ Kế hoạch số 148/KH-MNTC ngày 14/10/2026 và Thông báo số 160/TB-MNTC ngày 23/10/2026;
>
> Căn cứ Quyết định số […]/QĐ-MNTC ngày […] của Hiệu trưởng về việc thành lập Tổ đánh giá hồ sơ;
>
> Căn cứ Biên bản mở hồ sơ, đánh giá, chấm điểm, xét chọn và Biên bản hậu kiểm ngày […];
>
> Tổ đánh giá báo cáo và kính trình Hiệu trưởng xem xét như sau:
>
> ## I. QUÁ TRÌNH THỰC HIỆN
>
> | Thời điểm | Nội dung công việc | Kết quả, minh chứng |
> |---|---|---|
> | 14/10/2026 | Ban hành Kế hoạch số 148/KH-MNTC | […] |
> | 23/10/2026 | Ban hành Thông báo mời số 160/TB-MNTC | […] |
> | 23/10–02/11/2026 | Tiếp nhận hồ sơ dự tuyển | […] |
> | 09h30 ngày 02/11/2026 | Mở hồ sơ, kiểm tra điều kiện và đánh giá | […] |
> | […] | Hậu kiểm hồ sơ đơn vị xếp thứ nhất | […] |
> | […] | Tổng hợp, trình kết quả | […] |
>
> Tổng số hồ sơ đã tiếp nhận: […].
>
> Số hồ sơ trong thời hạn: […].
>
> Số hồ sơ đáp ứng điều kiện bắt buộc: […].
>
> Số hồ sơ không đáp ứng: […].
>
> ## II. KẾT QUẢ ĐÁNH GIÁ
>
> **1. Kết quả kiểm tra điều kiện bắt buộc**
>
> Danh sách đơn vị đạt yêu cầu: […].
>
> Danh sách đơn vị không đạt và lý do: […].
>
> **2. Kết quả chấm điểm và xếp hạng**
>
> | STT | Tên đơn vị | Điểm đánh giá | Kết quả | Xếp hạng |
> |---|---|---|---|---|
> | 1 | […] | […] | […] | […] |
> | 2 | […] | […] | […] | […] |
> | 3 | […] | […] | […] | […] |
>
> Thang điểm, phương pháp xác định điểm và các điều kiện lựa chọn được áp dụng theo văn bản: […].
>
> Kết quả áp dụng điểm tối thiểu, điều chỉnh hoặc trừ điểm (nếu có): […].
>
> **3. Kết quả hậu kiểm**
>
> Tên đơn vị được hậu kiểm: […].
>
> Ngày thực hiện: […].
>
> Các nội dung đã xác minh: […].
>
> Kết luận hậu kiểm: […].
>
> Các sai khác, vấn đề cần làm rõ (nếu có): […].
>
> ## III. RÀ SOÁT ĐIỀU KIỆN PHÊ DUYỆT
>
> 1. **Về thời gian công khai:** Thông báo mời số 160/TB-MNTC ban hành ngày 23/10/2026, thời hạn nộp hồ sơ kết thúc ngày 02/11/2026. Tổ đề nghị Hiệu trưởng kiểm tra tính phù hợp của thời gian công khai với khoản 2 Điều 4 Thông tư số 120/2025/TT-BTC và xác định biện pháp xử lý trước khi phê duyệt.
>
> 2. **Về tiêu chí đánh giá:** Đối chiếu thang điểm, điểm tối thiểu, quy tắc lựa chọn và xếp hạng đã công bố với các quy định tại Điều 4 và Phụ lục I Thông tư số 120/2025/TT-BTC. Kết quả rà soát: […].
>
> 3. **Về điều kiện của đơn vị được đề xuất:** Kiểm tra tính hợp pháp của chương trình, đội ngũ nhân sự, tài liệu, điều kiện tổ chức hoạt động, phương án tài chính và hồ sơ chứng minh năng lực. Kết quả: […].
>
> 4. **Về sử dụng tài sản công và tài chính:** Kiểm tra căn cứ pháp lý cho việc sử dụng tài sản công, mức thu được phép áp dụng, phương án phân chia nguồn thu, nghĩa vụ tài chính và chế độ hạch toán. Kết quả: […].
>
> 5. **Về kiến nghị, phản ánh:** Các phản ánh hoặc kiến nghị đã tiếp nhận: […]; kết quả xử lý: […].
>
> ## IV. KIẾN NGHỊ, ĐỀ XUẤT
>
> Trên cơ sở kết quả đánh giá và hậu kiểm, Tổ đánh giá kính đề nghị Hiệu trưởng:
>
> 1. Xem xét toàn bộ hồ sơ và các vấn đề được nêu tại Mục III; chỉ phê duyệt kết quả lựa chọn khi đã đủ căn cứ về trình tự, tiêu chí, kết quả đánh giá và điều kiện tham gia.
>
> 2. Trường hợp quy trình lựa chọn bảo đảm điều kiện theo quy định, xem xét phê duyệt lựa chọn đơn vị […] làm đối tác liên kết tổ chức hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh, năm học 2026–2027, với tổng điểm […].
>
> 3. Trường hợp phát hiện nội dung chưa phù hợp, chỉ đạo rà soát, khắc phục hoặc tổ chức lại các bước có liên quan theo quy định, bảo đảm quyền lợi hợp pháp của các bên và tính công bằng, minh bạch.
>
> 4. Sau khi kết quả được phê duyệt hợp lệ, chỉ đạo thông báo công khai, giải quyết kiến nghị và tổ chức thương thảo, hoàn thiện hợp đồng theo quy định.
>
> Kính trình Hiệu trưởng xem xét, quyết định.
>
> **Hồ sơ gửi kèm:**
>
> 1. Biên bản mở hồ sơ và các tài liệu ghi nhận việc tiếp nhận.
> 2. Biên bản đánh giá, chấm điểm, xét chọn.
> 3. Phiếu chấm điểm của các thành viên.
> 4. Biên bản hậu kiểm và các tài liệu đối chiếu.
> 5. Dự thảo Quyết định phê duyệt kết quả và Thông báo kết quả.
> 6. Bằng chứng công khai Thông báo mời, hồ sơ làm rõ và tài liệu liên quan.
>
> **Nơi nhận:**
> - Như trên;
> - Lưu: Hồ sơ lựa chọn.
>
> **TM. TỔ ĐÁNH GIÁ HỒ SƠ**  
> **TỔ TRƯỞNG**  
> *(Ký, ghi rõ họ tên)*
>
> […]

### 5. Thông báo kết quả lựa chọn – Trường Mầm non Tràm Chim

Văn bản này là **mẫu để hoàn thiện sau khi có Quyết định phê duyệt hợp lệ**, không phải thông báo đã có hiệu lực.

> **writing · document**
>
> **UBND XÃ TRÀM CHIM**  
> **TRƯỜNG MẦM NON TRÀM CHIM**
>
> Số: […]/TB-MNTC
>
> **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
> **Độc lập – Tự do – Hạnh phúc**
>
> *Tràm Chim, ngày […] tháng 11 năm 2026*
>
> # THÔNG BÁO
> **Về kết quả lựa chọn đối tác liên kết tổ chức hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh, năm học 2026–2027**
>
> **Kính gửi: Các đơn vị đã nộp hồ sơ tham gia lựa chọn đối tác liên kết.**
>
> Thực hiện Kế hoạch số 148/KH-MNTC ngày 14/10/2026 và Thông báo số 160/TB-MNTC ngày 23/10/2026 của Trường Mầm non Tràm Chim;
>
> Căn cứ Quyết định số […]/QĐ-MNTC ngày […] tháng […] năm 2026 của Hiệu trưởng Trường Mầm non Tràm Chim về việc phê duyệt kết quả lựa chọn đối tác liên kết;
>
> Trường Mầm non Tràm Chim thông báo kết quả như sau:
>
> ## I. THÔNG TIN CHUNG
>
> 1. Đơn vị tổ chức: Trường Mầm non Tràm Chim.
>
> 2. Địa chỉ: Ấp 5, xã Tràm Chim, tỉnh Đồng Tháp.
>
> 3. Nội dung liên kết: Tổ chức hoạt động cho trẻ mẫu giáo làm quen với tiếng Anh, năm học 2026–2027.
>
> 4. Tổng số đơn vị tham gia: […].
>
> 5. Số hồ sơ đáp ứng điều kiện đánh giá: […].
>
> 6. Thời gian mở hồ sơ, đánh giá: […].
>
> 7. Thời gian hoàn thành hậu kiểm: […].
>
> 8. Ngày phê duyệt kết quả lựa chọn: […].
>
> ## II. KẾT QUẢ LỰA CHỌN
>
> | STT | Tên đơn vị | Tổng điểm | Kết quả |
> |---|---|---:|---|
> | 1 | […] | […] | […] |
> | 2 | […] | […] | […] |
> | 3 | […] | […] | […] |
>
> Việc chấm điểm và xếp hạng được thực hiện theo các tiêu chí, phương pháp và điều kiện lựa chọn áp dụng hợp lệ, thể hiện tại hồ sơ đánh giá và Quyết định phê duyệt kết quả.
>
> ## III. THÔNG TIN ĐƠN VỊ ĐƯỢC LỰA CHỌN
>
> 1. Tên đơn vị: […].
>
> 2. Mã số thuế/đăng ký kinh doanh: […].
>
> 3. Địa chỉ trụ sở: […].
>
> 4. Người đại diện theo pháp luật: […].
>
> 5. Tổng điểm đánh giá: […].
>
> 6. Nội dung cung cấp dịch vụ giáo dục: […].
>
> 7. Chương trình và tài liệu thực hiện: […].
>
> 8. Mức thu dự kiến: […] đồng/trẻ/tháng hoặc theo đơn vị tính được phê duyệt.
>
> 9. Tỷ lệ hoặc phương thức phân chia nguồn thu: […].
>
> 10. Chính sách hỗ trợ, miễn giảm: […].
>
> 11. Cam kết về đội ngũ giáo viên, trang thiết bị, tài liệu và an toàn cho trẻ: […].
>
> Các nội dung chi tiết, quyền và nghĩa vụ của các bên được xác lập trong hợp đồng liên kết theo quy định pháp luật.
>
> Việc tham gia hoạt động của trẻ trên cơ sở tự nguyện của cha mẹ trẻ; Nhà trường và đối tác có trách nhiệm thông tin công khai, đầy đủ về chương trình, mức thu, thời lượng và điều kiện tổ chức.
>
> ## IV. LÝ DO CÁC ĐƠN VỊ KHÔNG ĐƯỢC LỰA CHỌN
>
> | STT | Tên đơn vị | Lý do tóm tắt |
> |---|---|---|
> | 1 | […] | […] |
> | 2 | […] | […] |
> | 3 | […] | […] |
>
> Lý do không được lựa chọn phải căn cứ trực tiếp vào kết quả đánh giá, xếp hạng và hồ sơ đã được phê duyệt; trường hợp không đáp ứng điều kiện phải ghi rõ nội dung không đáp ứng.
>
> ## V. KẾ HOẠCH HOÀN THIỆN VÀ KÝ KẾT HỢP ĐỒNG
>
> 1. Thời gian dự kiến thương thảo: […].
>
> 2. Thời gian dự kiến ký hợp đồng: […].
>
> 3. Địa điểm: Trường Mầm non Tràm Chim.
>
> 4. Nội dung thương thảo gồm: chương trình giáo dục, đội ngũ nhân sự, thời lượng hoạt động, mức thu, cơ chế tài chính, quản lý tài sản công, trách nhiệm bảo đảm an toàn cho trẻ, kiểm tra chất lượng, xử lý vi phạm và chấm dứt hợp đồng.
>
> 5. Việc ký kết được thực hiện sau khi hoàn thành việc công khai, tiếp nhận và giải quyết kiến nghị theo quy định; hợp đồng chỉ được ký khi bảo đảm đầy đủ điều kiện pháp lý.
>
> ## VI. TIẾP NHẬN KIẾN NGHỊ
>
> Các đơn vị tham gia có quyền gửi kiến nghị bằng văn bản về kết quả lựa chọn theo thời hạn và trình tự áp dụng.
>
> Theo nội dung Kế hoạch số 148/KH-MNTC, thời gian tiếp nhận kiến nghị dự kiến là 03 ngày làm việc kể từ ngày Thông báo được đăng tải; việc trả lời bằng văn bản được thực hiện trong thời hạn 05 ngày làm việc kể từ ngày nhận kiến nghị. Các thời hạn này phải được rà soát lại với quy định áp dụng trước khi phát hành.
>
> Địa điểm tiếp nhận: Văn phòng Trường Mầm non Tràm Chim, Ấp 5, xã Tràm Chim, tỉnh Đồng Tháp.
>
> Địa chỉ thư điện tử: mntramchim.tamnong@dongthap.edu.vn.
>
> Điện thoại: 02773 827 294.
>
> ## VII. CÔNG KHAI THÔNG BÁO
>
> Nhà trường thực hiện gửi Thông báo đến các đơn vị đã tham gia lựa chọn và công khai kết quả trên các kênh theo quy định, gồm:
>
> 1. Trang thông tin điện tử của Nhà trường (nếu có).
> 2. Cổng thông tin điện tử của địa phương theo quy định.
> 3. Trang thông tin điện tử về tài sản công của Bộ Tài chính.
> 4. Các hình thức thông tin, niêm yết khác phù hợp với kế hoạch của Nhà trường.
>
> Thời hạn thực hiện theo quy định pháp luật tính từ ngày kết quả lựa chọn được phê duyệt.
>
> Trường Mầm non Tràm Chim trân trọng thông báo để các đơn vị được biết và thực hiện.
>
> **Nơi nhận:**
> - Các đơn vị đã nộp hồ sơ;
> - Cơ quan quản lý có liên quan;
> - Các kênh đăng tải, công khai theo quy định;
> - Lưu: VT, hồ sơ lựa chọn.
>
> **HIỆU TRƯỞNG**  
> *(Ký, ghi rõ họ tên, đóng dấu)*
>
> **Võ Thị Diễm**

## 📋 Thiết lập in khổ A4

Khi đưa từng văn bản trên vào Word, bạn sử dụng các thông số sau:

| Thông số | Thiết lập |
|--------|--------|
| Khổ giấy | A4 (210 × 297 mm) |
| Hướng giấy | Dọc |
| Lề trên, dưới | 20–25 mm |
| Lề trái | 30 mm |
| Lề phải | 20 mm |
| Phông chữ | Times New Roman |
| Cỡ chữ nội dung | 13 hoặc 14 |
| Giãn dòng | 1,15–1,3 |
| Tiêu đề văn bản | In hoa, đậm, căn giữa |
| Bảng biểu | Kẻ khung, lặp lại hàng tiêu đề khi qua trang |
| Số trang | Căn giữa cuối trang đối với văn bản nhiều trang |

**Lưu ý về việc xuất tệp:** Mình đã biên tập nội dung thành 6 mẫu có thể sao chép, chỉnh sửa, nhưng phiên làm việc này chưa có công cụ để tạo và đính kèm trực tiếp tệp Word/PDF A4. Vì vậy, mình không thể cung cấp một đường dẫn tải tệp đã hoàn thiện.

Để in, bạn có thể sao chép từng mẫu vào Word, thiết lập khổ A4 như trên, rồi chọn **File → Save As → PDF**.

**✅ Kết luận:** Phần nội dung và bố cục văn bản đã được chuẩn bị; riêng dữ liệu đánh giá thực tế, danh sách nhân sự, các căn cứ còn mâu thuẫn và điều kiện pháp lý của quy trình cần được xác nhận trước khi ký, đóng dấu hoặc phát hành chính thức.

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

USER

hoàn chỉnh mục II dùm mình

---

ASSISTANT

Mình đã xem tệp **“bb mo ho so.docx”** bạn vừa gửi. Mình hoàn thiện **Mục II – THỐNG NHẤT CÁCH LÀM TRƯỚC KHI MỞ HỒ SƠ** \(Biên bản 1, trang 2–4), giữ nguyên 7 nội dung trong bảng, đồng thời bổ sung cách thực hiện rõ ràng để Tổ đánh giá áp dụng.

Có một vấn đề quan trọng: dự thảo đang có hai thang điểm khác nhau. Vì đây là biên bản chính thức, mình trình bày phương án xử lý cụ thể nhưng không ghi nhận một quyết định thống nhất khi Tổ chưa thực sự thông qua.

> **writing · document**
>
> ## II. THỐNG NHẤT CÁCH LÀM TRƯỚC KHI MỞ HỒ SƠ
>
> **1. Công bố Quyết định thành lập Tổ đánh giá và nguyên tắc làm việc**
>
> Bà Nguyễn Thị Huỳnh Duyên – Phó Hiệu trưởng, Tổ trưởng Tổ đánh giá hồ sơ – công bố Quyết định số ……/QĐ-…… ngày 15 tháng 10 năm 2026 của Hiệu trưởng về việc thành lập Tổ đánh giá hồ sơ lựa chọn đối tác liên kết tổ chức các hoạt động giáo dục ngoài giờ chính khóa, sử dụng tài sản công, năm học 2026–2027.
>
> Tổ trưởng thông qua nhiệm vụ, quyền hạn và trách nhiệm của từng thành viên; phổ biến quy trình tiếp nhận, mở hồ sơ, kiểm tra điều kiện bắt buộc, chấm điểm, tổng hợp kết quả, xếp hạng và đề xuất lựa chọn đối tác.
>
> Các thành viên thực hiện nhiệm vụ trên nguyên tắc:
>
> - Bảo đảm công khai, minh bạch, khách quan, công bằng và cạnh tranh lành mạnh giữa các đơn vị tham gia.
> - Chỉ sử dụng các điều kiện, tiêu chí, thang điểm và phương pháp đánh giá đã được công bố hợp lệ; không tự ý bổ sung hoặc thay đổi tiêu chí trong quá trình xét chọn.
> - Áp dụng thống nhất một phương pháp đánh giá đối với tất cả các đơn vị tham gia cùng nội dung hoặc gói liên kết.
> - Mỗi thành viên chấm điểm độc lập, có căn cứ, ghi rõ lý do cho điểm; không trao đổi kết quả chấm điểm trước khi nộp phiếu cho Thư ký.
> - Không tiếp xúc riêng với các đơn vị tham gia để trao đổi nội dung đánh giá; không nhận tiền, quà tặng hoặc lợi ích dưới bất kỳ hình thức nào.
> - Bảo mật hồ sơ, phiếu chấm điểm và kết quả đánh giá theo quy định; kịp thời báo cáo Hiệu trưởng khi phát sinh tình huống ảnh hưởng đến tính khách quan của việc lựa chọn.
> - Mọi nội dung cần làm rõ hồ sơ phải được thực hiện bằng văn bản và lưu đầy đủ trong hồ sơ lựa chọn đối tác.
>
> **2. Thống nhất phương pháp đánh giá và xử lý các nội dung cần làm rõ**
>
> Tổ trưởng trình bày các nội dung cần thống nhất trước khi mở hồ sơ đầu tiên. Các thành viên nghiên cứu, thảo luận, đối chiếu Kế hoạch, Thông báo mời và Phụ lục tiêu chí đã công bố.
>
> Tổ thống nhất nguyên tắc xử lý từng nội dung như sau:
>
> | STT | Nội dung | Phương án xử lý, thống nhất |
> |---|---|---|
> | 1 | **Thang điểm áp dụng** | Sử dụng một thang điểm thống nhất, tổng cộng 100 điểm. Hiện Kế hoạch và Thông báo nêu: nhóm I = 20 điểm, II = 40 điểm, III = 25 điểm, IV = 15 điểm; trong khi cộng các tiêu chí chi tiết của Phụ lục được: I = 20 điểm, II = 30 điểm, III = 35 điểm, IV = 15 điểm. Tổ báo cáo Hiệu trưởng để xác nhận, xử lý sự không thống nhất bằng văn bản và công khai hợp lệ trước khi áp dụng. Không tự lựa chọn thang điểm khác với nội dung đã công bố. |
> | 2 | **Điều kiện lựa chọn** | Hồ sơ phải đáp ứng đầy đủ các điều kiện bắt buộc đã công bố mới được chuyển sang chấm điểm. Tổng điểm phải đạt từ 70/100 điểm trở lên, không có nhóm tiêu chí nào đạt 0 điểm và đồng thời đáp ứng các mức điểm tối thiểu của từng nhóm theo thang điểm được xác nhận hợp lệ. Chỉ xếp hạng các hồ sơ đáp ứng đầy đủ điều kiện lựa chọn. |
> | 3 | **Cách xếp hạng khi nhiều đơn vị đạt từ 70 điểm trở lên** | Phương án đề xuất: xếp hạng theo tổng điểm từ cao xuống thấp. Trường hợp các đơn vị có tổng điểm bằng nhau, ưu tiên đơn vị có điểm nhóm III cao hơn; nếu vẫn bằng nhau, tiếp tục xét điểm nhóm IV. Nếu tiếp tục bằng điểm, Tổ lập biên bản, báo cáo Hiệu trưởng xem xét. Phương án này cần được xác nhận phù hợp với quy tắc xếp hạng đã công bố trước khi sử dụng. |
> | 4 | **Công thức tính điểm IV.2 – Tỷ lệ trích nộp để bù đắp chi phí cho Nhà trường** | Phương án đề xuất: Điểm IV.2 = 5 × (Tỷ lệ % đề xuất của đơn vị / Tỷ lệ % cao nhất trong các hồ sơ đủ điều kiện). Đơn vị có tỷ lệ cao nhất được 5 điểm; các đơn vị còn lại được tính tương ứng. Chỉ tính cho hồ sơ đạt điều kiện bắt buộc. Trường hợp tỷ lệ cao nhất bằng 0 hoặc dữ liệu không hợp lệ, báo cáo Hiệu trưởng xử lý. Chỉ áp dụng công thức sau khi được xác nhận, công khai hợp lệ, không tự bổ sung quy tắc tính điểm sau khi mở hồ sơ. |
> | 5 | **Cách chấm IV.1 – Mức thu hợp lý, chính sách trách nhiệm xã hội** | Đánh giá trên cơ sở mức thu đề xuất, sự tương xứng với chất lượng chương trình, chính sách miễn giảm, hỗ trợ trẻ có hoàn cảnh khó khăn và các cam kết trách nhiệm xã hội có minh chứng. Điểm tối đa 10 điểm. Do Phụ lục chưa nêu mức điểm cụ thể cho từng mức đáp ứng, Tổ đề nghị Hiệu trưởng xác nhận phương pháp chấm chi tiết trước khi áp dụng; không tự chia điểm hoặc bổ sung điều kiện làm thay đổi tiêu chí đã công bố. |
> | 6 | **Lựa chọn tối đa 02 đơn vị trình diễn phần mềm học liệu** | Trường hợp có không quá 02 đơn vị đủ điều kiện thì có thể tổ chức trình diễn cho tất cả. Nếu có trên 02 đơn vị, việc lựa chọn đơn vị trình diễn phải căn cứ phương pháp khách quan được xác nhận, công khai hợp lệ; đề xuất xem xét điểm đánh giá sơ bộ ở những tiêu chí không phụ thuộc kết quả trình diễn. Thời lượng tối đa 30 phút/đơn vị. Các đơn vị được trình diễn trong điều kiện tương đương; Tổ ghi nhận chức năng, khả năng tương tác, học liệu, tính phù hợp với trẻ mầm non và minh chứng kèm theo. |
> | 7 | **Làm tròn điểm bình quân** | Phương án đề xuất: điểm bình quân của các thành viên được trình bày đến 02 chữ số thập phân, áp dụng thống nhất cho tất cả đơn vị. Thư ký lưu kết quả tính toán gốc để kiểm tra, đối chiếu; việc làm tròn không được làm thay đổi bản chất kết quả xếp hạng. |
>
> **3. Kết luận về việc thống nhất phương pháp thực hiện**
>
> Tổ đánh giá thống nhất việc mở hồ sơ phải bảo đảm đúng trình tự, thời gian, thành phần tham dự và nguyên tắc công khai, minh bạch. Từng hồ sơ được kiểm tra tình trạng niêm phong, thời điểm tiếp nhận, thành phần tài liệu và ghi nhận đầy đủ vào biên bản.
>
> Đối với các nội dung còn khác nhau giữa Kế hoạch, Thông báo mời và Phụ lục tiêu chí, Tổ lập báo cáo đề nghị Hiệu trưởng xem xét, xử lý bằng văn bản trước khi áp dụng. Không dùng việc thống nhất nội bộ để thay đổi các điều kiện, tiêu chí hoặc phương pháp đánh giá đã công bố hợp lệ.
>
> Sau khi có đủ căn cứ và hoàn tất việc xử lý các nội dung còn khác nhau, Tổ tiến hành các bước mở hồ sơ, kiểm tra điều kiện bắt buộc, chấm điểm và tổng hợp kết quả theo đúng quy định.
>
> **Ý kiến khác của các thành viên (nếu có):** ………………………………………
>
> **Kết quả thống nhất của Tổ:** ………………………………………
>
> **Văn bản xác nhận, xử lý của Hiệu trưởng (nếu có):** ………………………………………

### ⚠️ Lưu ý trước khi đưa vào biên bản chính thức

Trong tài liệu bạn gửi, mình còn thấy 3 điểm cần chỉnh sửa:

1. **Tên trường chưa thống nhất:** Phần đầu ghi Trường Mầm non Hướng Dương, nhưng phần căn cứ và địa điểm lại ghi Trường Mầm non An Bình.
2. **Ký hiệu Quyết định chưa thống nhất:** Có cả `QĐ-MNHD` và `QĐ-MNAB`.
3. **Thang điểm nhóm II, III đang mâu thuẫn:** Cần có căn cứ xác nhận chính thức trước khi chốt bảng điểm và tiến hành xét chọn.

**✅ Phần Mục II trên đã có đầy đủ nội dung chuyên môn và phương án xử lý cho cả 7 vấn đề.** Bạn có thể thay thế phần Mục II hiện tại trong Word, nhưng trước khi ký biên bản cần bổ sung quyết định thực tế của Tổ và văn bản xác nhận những nội dung còn chưa thống nhất.

---

USER

hoàn thành yêu cầu trong các ảnh này dùm mình

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

---

ASSISTANT

Mình đã xem kỹ cả hai ảnh. Dưới đây là nội dung hoàn chỉnh để điền vào **cột “Tổ thống nhất” từ STT 1 đến STT 7** của Biên bản mở hồ sơ dự tuyển.

Mình giữ cách diễn đạt ngắn gọn, phù hợp với ô trong bảng và văn phong biên bản hành chính. Đây là **phương án dự thảo để Tổ xem xét, thông qua**, không phải kết quả biểu quyết đã diễn ra.

> **writing · document**
>
> ## II. THỐNG NHẤT CÁCH LÀM TRƯỚC KHI MỞ HỒ SƠ
>
> ### Nội dung điền vào cột “Tổ thống nhất”
>
> **1. Thang điểm áp dụng**
>
> ☑ Khác: Tổ ghi nhận sự chưa thống nhất giữa Kế hoạch, Thông báo mời và Phụ lục tiêu chí.
>
> Đề nghị Hiệu trưởng rà soát, xác định thang điểm và điểm tối thiểu phù hợp quy định, thực hiện điều chỉnh, công khai hợp lệ trước khi đánh giá.
>
> Thang điểm và điểm sàn chính thức thực hiện theo văn bản được xác nhận sau khi xử lý.
>
> **2. Điều kiện chọn**
>
> ☑ Kiểm tra đồng thời cả hai điều kiện theo phương án đã công bố, sau khi được xác định phù hợp quy định:
>
> - Tổng điểm đạt từ 70/100 điểm trở lên.
> - Không có nhóm tiêu chí nào đạt 0 điểm.
> - Đạt điểm tối thiểu của từng nhóm theo thang điểm được xác nhận hợp lệ.
> - Đáp ứng đầy đủ điều kiện bắt buộc.
>
> **3. Cách xếp hạng khi nhiều đơn vị vượt 70 điểm**
>
> ☑ Phương án đề xuất: Xếp hạng theo tổng điểm từ cao xuống thấp.
>
> Trường hợp bằng tổng điểm, áp dụng thứ tự ưu tiên xử lý bằng điểm theo quy định pháp luật áp dụng. Nếu tiếp tục bằng điểm ở tất cả tiêu chí ưu tiên, tổ chức bốc thăm công khai, có đại diện các đơn vị liên quan tham dự.
>
> **4. Công thức điểm IV.2 (mức trích % cho Nhà trường)**
>
> ☑ Khác: Đề nghị đối chiếu công thức tính điểm về hiệu quả tài chính và mức chia sẻ lợi nhuận theo quy định áp dụng.
>
> Không tự sử dụng công thức nội suy theo tỷ lệ phần trăm khi chưa xác định phù hợp quy định và tiêu chí đã công bố.
>
> Áp dụng thống nhất công thức hợp lệ cho tất cả hồ sơ đủ điều kiện.
>
> **5. Cách chấm IV.1 (mức thu hợp lý, chính sách trách nhiệm xã hội)**
>
> ☑ Căn cứ: Mức thu đề xuất, chất lượng chương trình, chính sách miễn giảm, hỗ trợ trẻ có hoàn cảnh khó khăn và các cam kết trách nhiệm xã hội có minh chứng.
>
> Mức điểm: Tối đa 10 điểm theo dự thảo.
>
> Đề nghị Hiệu trưởng xác nhận thang điểm chi tiết, bảo đảm phù hợp quy định và công khai hợp lệ trước khi chấm. Không tự bổ sung mức điểm sau khi mở hồ sơ.
>
> **6. Cách chọn tối đa 02 đơn vị trình diễn phần mềm học liệu**
>
> ☑ Cách chọn: Nếu có không quá 02 đơn vị đáp ứng điều kiện thì tổ chức trình diễn cho các đơn vị đó.
>
> Nếu có trên 02 đơn vị, lựa chọn theo tiêu chí khách quan đã được xác định, công khai hợp lệ trước khi thực hiện; trường hợp chưa có tiêu chí lựa chọn thì báo cáo Hiệu trưởng xử lý.
>
> Mỗi đơn vị trình diễn không quá 30 phút, bảo đảm điều kiện và thời lượng đánh giá tương đương.
>
> **7. Làm tròn điểm bình quân**
>
> ☑ 02 chữ số thập phân.
>
> Điểm bình quân được tính theo kết quả chấm hợp lệ của các thành viên, làm tròn đến 02 chữ số thập phân theo quy tắc làm tròn số học thông thường. Thư ký lưu bảng tính gốc để đối chiếu khi cần thiết.

## ⚠️ Lưu ý quan trọng trước khi ký biên bản

Mình đã đối chiếu thêm **Điều 4 và Phụ lục I Thông tư 120/2025/TT-BTC**. Nếu Nhà trường đang thực hiện thủ tục lựa chọn đối tác liên doanh, liên kết sử dụng tài sản công thuộc phạm vi Thông tư này thì bảng tiêu chí pháp lý có 5 nhóm:

| Nhóm | Điểm tối đa |
|--------|--------|
| I. Năng lực, kinh nghiệm | 30 |
| II. Hiệu quả phương án tài chính | 35 |
| III. Cơ sở vật chất, trang thiết bị | 15 |
| IV. Phương án xử lý tài sản sau liên kết | 10 |
| V. Các tiêu chí khác | 10 |
| **Tổng** | **100** |

Thông tư còn quy định cách xử lý bằng điểm, khác với cách ưu tiên nhóm III rồi nhóm IV trong ảnh. [Source unavailable: turn615138view0]; [Source unavailable: turn327644view1]

Vì vậy, **không nên tích ngay phương án “Theo Phụ lục” ở dòng 1 hoặc “Theo gợi ý” ở dòng 4** khi chưa giải quyết sự khác biệt này. Các đề xuất về ngưỡng 70 điểm, điểm sàn từng nhóm và mức điểm IV.1 cũng cần được rà soát.

**✅ Kết luận:** Cả 7 ô đã có nội dung dự thảo để đưa vào bảng. Trước khi in và ký, Nhà trường cần thống nhất chính xác căn cứ pháp lý và thang điểm áp dụng để biên bản vừa đầy đủ về nội dung vừa không phát sinh rủi ro khi kiểm tra hồ sơ.

---

USER

nói nghe nè minh chọn cty này. bạn giúp mình điền cột tổ thống nhất cho hợp lý

---

ASSISTANT

Mình hiểu ý bạn rồi. Bạn đã có công ty dự kiến lựa chọn để liên kết với nhà trường. Mình sẽ giúp bạn **điền cả 7 ô trong cột “Tổ thống nhất”**, theo hướng rõ ràng, hợp lý, dễ đưa vào biên bản và bảo đảm kết quả lựa chọn có căn cứ.

Tuy nhiên, dù đã có công ty dự kiến, nội dung thống nhất vẫn phải áp dụng công bằng cho tất cả đơn vị tham gia, không điều chỉnh điểm để ưu tiên một công ty.

> **writing · document**
>
> ## NỘI DUNG ĐIỀN VÀO CỘT “TỔ THỐNG NHẤT”
>
> **1. Thang điểm áp dụng**
>
> ☐ Khác:
>
> Tổ thống nhất đề nghị Hiệu trưởng rà soát, xử lý sự chênh lệch giữa thang điểm trong Kế hoạch, Thông báo và Phụ lục tiêu chí; xác nhận và công khai thang điểm áp dụng hợp lệ trước khi tiến hành đánh giá.
>
> Chỉ chấm điểm sau khi đã có thang điểm và điểm tối thiểu thống nhất.
>
> **2. Điều kiện chọn**
>
> ☑ Kiểm tra đồng thời cả hai.
>
> Hồ sơ phải đạt đầy đủ điều kiện bắt buộc; tổng điểm từ 70/100 trở lên, không có nhóm tiêu chí nào đạt 0 điểm và đáp ứng điểm tối thiểu từng nhóm theo thang điểm chính thức.
>
> **3. Cách xếp hạng khi nhiều đơn vị vượt 70 điểm**
>
> ☑ Phương án (a): Xếp theo tổng điểm từ cao xuống thấp; trường hợp bằng điểm thì xét nhóm III, tiếp theo nhóm IV, nếu phù hợp quy tắc đã công bố.
>
> Trường hợp vẫn bằng điểm, Tổ báo cáo Hiệu trưởng xem xét, xử lý theo quy định áp dụng.
>
> **4. Công thức điểm IV.2 (mức trích % cho Nhà trường)**
>
> ☐ Theo gợi ý (chỉ đánh dấu khi công thức được xác nhận và công khai hợp lệ).
>
> Điểm IV.2 = 5 × (Tỷ lệ % đề xuất của đơn vị / Tỷ lệ % cao nhất của các hồ sơ đủ điều kiện).
>
> Đơn vị có tỷ lệ cao nhất được 5 điểm. Các đơn vị còn lại tính tương ứng. Chỉ áp dụng khi đã thống nhất, công khai hợp lệ trước khi đánh giá.
>
> **5. Cách chấm IV.1 (mức thu hợp lý, chính sách trách nhiệm xã hội)**
>
> ☐ Mức điểm: Tối đa 10 điểm.
>
> ☑ Căn cứ: Mức thu đề xuất phù hợp quy định; chất lượng chương trình; chính sách miễn, giảm học phí; hỗ trợ trẻ có hoàn cảnh khó khăn và các cam kết trách nhiệm xã hội có minh chứng.
>
> Điểm cụ thể thực hiện theo phương pháp chấm được phê duyệt, công khai hợp lệ; không tự đặt mức điểm mới trong quá trình xét chọn.
>
> **6. Cách chọn tối đa 02 đơn vị trình diễn phần mềm học liệu**
>
> ☐ Cách chọn:
>
> Nếu có từ 01 đến 02 đơn vị đủ điều kiện thì tổ chức cho các đơn vị đó trình diễn.
>
> Nếu có trên 02 đơn vị, đề xuất lựa chọn 02 đơn vị có điểm đánh giá sơ bộ cao nhất ở các tiêu chí không phụ thuộc kết quả trình diễn, với điều kiện phương pháp này đã được xác nhận, công khai hợp lệ.
>
> Thời gian trình diễn không quá 30 phút/đơn vị; bảo đảm nội dung và điều kiện đánh giá như nhau.
>
> **7. Làm tròn điểm bình quân**
>
> ☑ 02 chữ số thập phân.
>
> Thư ký tính điểm bình quân từ các phiếu chấm hợp lệ, làm tròn theo quy tắc số học thông thường đến 02 chữ số thập phân và lưu kết quả tính toán để đối chiếu.

### ⚠️ Mình lưu ý bạn 2 điều

**Thứ nhất:** Các ô số 1, 4, 5, 6 còn liên quan đến những nội dung chưa thống nhất trong hồ sơ gốc. Mình đã viết phương án xử lý cụ thể nhưng chưa đánh dấu xác nhận những việc mà Hiệu trưởng và Tổ chưa thực hiện.

**Thứ hai:** Nếu công ty bạn dự kiến lựa chọn là đơn vị duy nhất nộp hồ sơ, không nhất thiết phải tạo thêm đối thủ để so sánh. Tổ vẫn đánh giá đầy đủ điều kiện, tiêu chí, điểm số và chỉ đề xuất lựa chọn khi công ty thực sự đáp ứng yêu cầu.

**Mình muốn biết thêm một điều:** Công ty bạn dự kiến lựa chọn là **đơn vị duy nhất nộp hồ sơ hay có nhiều công ty cùng tham gia?** Mình sẽ căn cứ vào đó để chỉnh cách diễn đạt cột “Tổ thống nhất” sát với tình huống thực tế của trường bạn.

---

USER

mục 5 chọn mức điểm là 10. bạn viết dùm phần căn cứ

---

ASSISTANT

Bạn điền vào **Mục 5 – Cách chấm IV.1 (Mức thu hợp lý, chính sách trách nhiệm xã hội)** như sau:

> **writing · standard**
>
> ☑ **Mức điểm: 10 điểm.**
>
> ☑ **Căn cứ:** Mức thu đề xuất phù hợp với chất lượng, nội dung và thời lượng chương trình giáo dục; không vượt mức thu do UBND tỉnh Đồng Tháp quy định (nếu thuộc phạm vi áp dụng). Có chính sách miễn, giảm học phí, hỗ trợ trẻ có hoàn cảnh khó khăn; thể hiện trách nhiệm xã hội rõ ràng, thiết thực, khả thi và có cam kết, minh chứng cụ thể trong hồ sơ dự tuyển.

**Lưu ý:** Đây là căn cứ đề xuất cho mức tối đa 10 điểm. Khi chấm chính thức, Tổ chỉ ghi đơn vị đạt **10/10 điểm** nếu hồ sơ thực tế đáp ứng đầy đủ các nội dung trên và phù hợp tiêu chí đã công bố.

---

USER

hứng dẫn lại mục 6 chỗ cách chọn

---

ASSISTANT

Ở **Mục 6 – Cách chọn tối đa 02 đơn vị trình diễn phần mềm học liệu**, bạn có thể điền vào cột **“Tổ thống nhất”** như sau:

> **writing · standard**
>
> ☑ **Cách chọn:**
>
> Tổ thống nhất lựa chọn tối đa 02 đơn vị có hồ sơ đáp ứng đầy đủ điều kiện bắt buộc để trình diễn phần mềm học liệu.
>
> - Nếu có từ 01 đến 02 đơn vị đủ điều kiện: Mời tất cả các đơn vị trình diễn.
> - Nếu có trên 02 đơn vị đủ điều kiện: Đề xuất chọn 02 đơn vị có điểm đánh giá sơ bộ cao nhất ở các tiêu chí không phụ thuộc kết quả trình diễn, với điều kiện phương pháp này đã được xác nhận và công khai hợp lệ trước khi áp dụng.
>
> Mỗi đơn vị trình diễn không quá 30 phút, bảo đảm công bằng, khách quan và có biên bản ghi nhận kết quả.

**💡 Mình khuyên bạn lưu ý:** Vì trong Kế hoạch và Thông báo mời chưa quy định rõ cách chọn 02 đơn vị, Tổ cần trình Hiệu trưởng xác nhận phương pháp và bảo đảm công khai hợp lệ trước khi thực hiện. Không nên tự bổ sung cách chọn sau khi đã mở hồ sơ.

Nếu trường bạn chỉ có **01 công ty nộp hồ sơ và đạt điều kiện bắt buộc**, có thể ghi ngắn gọn hơn:

> Tổ thống nhất mời đơn vị có hồ sơ đáp ứng đầy đủ điều kiện bắt buộc tham gia trình diễn phần mềm học liệu; thời gian không quá 30 phút. Tổ đánh giá, ghi nhận kết quả dựa trên các tiêu chí đã công bố, bảo đảm khách quan, minh bạch.

---

