USER

Bạn hãy đóng vai là cán bộ tư pháp, tôi muốn thay đổi ngày tháng năm sinh phải chọn mục nào trong các câu trên

---

ASSISTANT

Mình sẽ kiểm tra ảnh để xác định đúng mục bạn cần chọn.

---

ASSISTANT

Bạn chọn **“Cải chính thông tin hộ tịch” — dòng thứ hai trong ảnh**, nếu muốn sửa **ngày, tháng, năm sinh đã ghi sai trên Giấy khai sinh**. Đây là thủ tục áp dụng khi thông tin ngày sinh đăng ký trước đó có sai sót. https://thuvienphapluat.vn/phap-luat/thu-tuc-dang-ky-cai-chinh-ho-tich-cho-nguoi-sai-ngay-sinh-trong-giay-khai-sinh-duoc-quy-dinh-nhu-th-535537-22863.html
https://thuvienphapluat.vn/phap-luat/thu-tuc-dang-ky-cai-chinh-ho-tich-cho-nguoi-sai-ngay-sinh-trong-giay-khai-sinh-duoc-quy-dinh-nhu-th-535537-22863.html?utm_source=chatgpt.com

Ở ô **“Tên Giấy tờ hộ tịch đã đăng ký”**, bạn chọn **“Giấy khai sinh”** nếu đó là giấy tờ cần sửa.

Bạn cho mình biết thêm: **Giấy khai sinh đang ghi sai ngày sinh, hay Giấy khai sinh đúng nhưng căn cước/VNeID ghi sai?** Mình sẽ hướng dẫn tiếp đúng trường hợp của bạn.

---

